// Identity macro to allow expansion of the "mutability" token tree.
macro_rules! id {
    ($e:item) => {
        $e
    };
}
