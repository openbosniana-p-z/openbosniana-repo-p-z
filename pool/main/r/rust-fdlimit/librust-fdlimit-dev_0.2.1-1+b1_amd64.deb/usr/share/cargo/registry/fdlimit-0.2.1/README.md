# fdlimit
Cross-platform raise open file descriptors limit 

[![crates.io link](https://img.shields.io/crates/v/fdlimit.svg)](https://crates.io/crates/fdlimit)

Applicable for OSX and Linux

on Windows does nothing

## Dependency

add in Cargo.toml: 
```
[dependencies]
fdlimit = "0.2.0"
```
