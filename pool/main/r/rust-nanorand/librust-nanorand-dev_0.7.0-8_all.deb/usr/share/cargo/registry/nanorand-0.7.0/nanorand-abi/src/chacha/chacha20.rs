use crate::define_c_api;

define_c_api!(chacha20, ChaCha20, 64);
