use crate::define_c_api;

define_c_api!(chacha12, ChaCha12, 64);
