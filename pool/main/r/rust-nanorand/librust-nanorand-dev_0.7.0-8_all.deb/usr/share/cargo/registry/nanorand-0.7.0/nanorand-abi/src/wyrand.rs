use crate::define_c_api;

define_c_api!(wyrand, WyRand, 8);
