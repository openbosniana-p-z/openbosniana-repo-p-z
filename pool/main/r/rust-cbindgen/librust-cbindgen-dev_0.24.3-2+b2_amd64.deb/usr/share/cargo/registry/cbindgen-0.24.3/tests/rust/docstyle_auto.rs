/// The root of all evil.
#[no_mangle]
pub extern "C" fn root() {
}
