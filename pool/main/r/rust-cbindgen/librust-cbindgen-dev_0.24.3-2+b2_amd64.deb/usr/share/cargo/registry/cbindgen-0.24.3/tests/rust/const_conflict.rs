#[repr(C)]
struct Foo {}

impl Foo {
    const FOO: i32 = 0;
}

pub const Foo_FOO: u32 = 42;

