#[derive(Copy, Clone)]
pub enum NumLit {
    U64(u64),
    F64(f64),
}
