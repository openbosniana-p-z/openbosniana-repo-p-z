# v0.1.4

- Added more documentation and examples.

# v0.1.3

- Updated documentation.

# v0.1.2

- Removed union serialization support.

# v0.1.1

- Removed "versionize" dependency.
- Added support for (de)serializing enum variants with zero or more fields.

# v0.1.0

- "versionize_derive" v0.1.0 first release.
