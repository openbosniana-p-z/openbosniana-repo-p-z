The version needs to be bumped at the following locations:

- Cargo.toml
- Cargo.lock
- fuzz/Cargo.lock (run `cargo update`)
- docs/sniffglue.1
