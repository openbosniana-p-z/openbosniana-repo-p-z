use remain::sorted;

#[sorted]
struct TestStruct {
    d: usize,
    c: usize,
    a: usize,
    b: usize,
}

fn main() {}
