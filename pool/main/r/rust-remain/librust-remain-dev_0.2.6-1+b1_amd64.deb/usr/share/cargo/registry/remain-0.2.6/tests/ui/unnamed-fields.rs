#[remain::sorted]
struct TupleStruct(usize, usize, usize);

#[remain::sorted]
struct UnitStruct;

fn main() {}
