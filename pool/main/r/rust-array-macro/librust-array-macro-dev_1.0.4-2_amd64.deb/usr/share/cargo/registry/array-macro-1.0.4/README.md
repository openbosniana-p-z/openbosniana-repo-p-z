# array-macro

Array multiple elements constructor syntax.
