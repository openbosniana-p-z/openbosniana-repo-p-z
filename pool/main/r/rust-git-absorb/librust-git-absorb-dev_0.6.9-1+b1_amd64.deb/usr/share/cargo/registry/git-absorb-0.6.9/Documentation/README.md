git-absorb manual
=================

This project's man page `git-absorb.1.gz` can be generated from `git-absorb.txt`
by running `make`.

Build dependencies
------------------

- [asciidoc][] (tested with version 8.6.10)
- GNU Make

[asciidoc]: http://www.methods.co.nz/asciidoc/
