# copied from ament_package/template/environment_hook/path.sh

ament_prepend_unique_value PATH "$AMENT_CURRENT_PREFIX/bin"
