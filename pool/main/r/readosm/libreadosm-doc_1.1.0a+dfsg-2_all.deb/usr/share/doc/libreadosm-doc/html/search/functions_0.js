var searchData=
[
  ['readosm_5fclose_0',['readosm_close',['../readosm_8h.html#a70c530eca9b20a3b3dd6cd47e8a6d5f5',1,'readosm.h']]],
  ['readosm_5fexpat_5fversion_1',['readosm_expat_version',['../readosm_8h.html#a9763aa325f7f35bd94f2b61dd6ca7b53',1,'readosm.h']]],
  ['readosm_5fopen_2',['readosm_open',['../readosm_8h.html#a9a85b0c226ebf5ff799a18ac832c3158',1,'readosm.h']]],
  ['readosm_5fparse_3',['readosm_parse',['../readosm_8h.html#a09dfad328c4fee83015c124dbc05ef10',1,'readosm.h']]],
  ['readosm_5fversion_4',['readosm_version',['../readosm_8h.html#af4ed4da896a0843b070b0d72453822ed',1,'readosm.h']]],
  ['readosm_5fzlib_5fversion_5',['readosm_zlib_version',['../readosm_8h.html#a05ef722d88c3afa2219e563eea04ea8d',1,'readosm.h']]]
];
