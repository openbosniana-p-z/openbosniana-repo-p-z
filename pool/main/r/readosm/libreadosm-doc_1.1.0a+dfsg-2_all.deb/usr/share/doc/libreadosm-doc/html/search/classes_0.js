var searchData=
[
  ['readosm_5fmember_5fstruct_0',['readosm_member_struct',['../structreadosm__member__struct.html',1,'']]],
  ['readosm_5fnode_5fstruct_1',['readosm_node_struct',['../structreadosm__node__struct.html',1,'']]],
  ['readosm_5frelation_5fstruct_2',['readosm_relation_struct',['../structreadosm__relation__struct.html',1,'']]],
  ['readosm_5ftag_5fstruct_3',['readosm_tag_struct',['../structreadosm__tag__struct.html',1,'']]],
  ['readosm_5fway_5fstruct_4',['readosm_way_struct',['../structreadosm__way__struct.html',1,'']]]
];
