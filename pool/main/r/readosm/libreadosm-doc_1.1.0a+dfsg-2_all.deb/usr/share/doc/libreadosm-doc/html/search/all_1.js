var searchData=
[
  ['changeset_0',['changeset',['../structreadosm__node__struct.html#ab9b6615174785eedd2cca6a00c651ff9',1,'readosm_node_struct::changeset()'],['../structreadosm__way__struct.html#a46dbffd5191b073fc388b69512e5ce51',1,'readosm_way_struct::changeset()'],['../structreadosm__relation__struct.html#aa7156c50315aaaa18a5c11c1387dc1b7',1,'readosm_relation_struct::changeset()']]]
];
