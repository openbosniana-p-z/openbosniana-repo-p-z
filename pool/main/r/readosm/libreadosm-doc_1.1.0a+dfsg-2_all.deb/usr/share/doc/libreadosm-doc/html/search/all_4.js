var searchData=
[
  ['latitude_0',['latitude',['../structreadosm__node__struct.html#a317b8e7fe789d70e62c0041cc9c154de',1,'readosm_node_struct']]],
  ['longitude_1',['longitude',['../structreadosm__node__struct.html#a022bee85cc4f17912a769abce814f2a1',1,'readosm_node_struct']]]
];
