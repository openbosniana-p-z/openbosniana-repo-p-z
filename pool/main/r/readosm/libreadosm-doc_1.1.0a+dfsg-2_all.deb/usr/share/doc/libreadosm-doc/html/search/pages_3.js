var searchData=
[
  ['readosm_20basic_20architecture_0',['ReadOSM basic architecture',['../readosm.html',1,'']]]
];
