var searchData=
[
  ['id_0',['id',['../structreadosm__node__struct.html#a9eec927f3592364a7a3423af88b93e4a',1,'readosm_node_struct::id()'],['../structreadosm__way__struct.html#a9ec0a8a15cf523843c1fd572baf99818',1,'readosm_way_struct::id()'],['../structreadosm__member__struct.html#ac40bbaf3961927e50c548a1b0b439b8d',1,'readosm_member_struct::id()'],['../structreadosm__relation__struct.html#a6b65b3a0ad6731d4d866721f39c1fddc',1,'readosm_relation_struct::id()']]]
];
