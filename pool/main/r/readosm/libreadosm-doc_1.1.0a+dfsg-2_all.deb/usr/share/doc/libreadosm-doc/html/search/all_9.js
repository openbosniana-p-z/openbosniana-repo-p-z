var searchData=
[
  ['tag_5fcount_0',['tag_count',['../structreadosm__node__struct.html#aa556cd9827b2a9d27feea5bccc89b12e',1,'readosm_node_struct::tag_count()'],['../structreadosm__way__struct.html#add184e8f64cf822635a571ea4c91a648',1,'readosm_way_struct::tag_count()'],['../structreadosm__relation__struct.html#a6963492e2297dbc52a99f67d9b4aae75',1,'readosm_relation_struct::tag_count()']]],
  ['tags_1',['tags',['../structreadosm__node__struct.html#a28ee2372298e11a6123372801661dc45',1,'readosm_node_struct::tags()'],['../structreadosm__way__struct.html#ac481f70038c820f696ec95794ffea94d',1,'readosm_way_struct::tags()'],['../structreadosm__relation__struct.html#a2a19ae73c82e0a80c1cbb3ce182ad3bd',1,'readosm_relation_struct::tags()']]],
  ['timestamp_2',['timestamp',['../structreadosm__node__struct.html#acffcf98cab14d23ed7566eb49afdc420',1,'readosm_node_struct::timestamp()'],['../structreadosm__way__struct.html#aa2cab6d2fd7de7bf43947d7d225b8b1f',1,'readosm_way_struct::timestamp()'],['../structreadosm__relation__struct.html#aeb778ab800017eeb7ab22be82dd63fc6',1,'readosm_relation_struct::timestamp()']]]
];
