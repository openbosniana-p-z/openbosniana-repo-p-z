var searchData=
[
  ['member_5fcount_0',['member_count',['../structreadosm__relation__struct.html#ad117d8ec3a3e825d3f215088c45500d7',1,'readosm_relation_struct']]],
  ['member_5ftype_1',['member_type',['../structreadosm__member__struct.html#a8f9f8f07a099b95212c3d217b3beeb37',1,'readosm_member_struct']]],
  ['members_2',['members',['../structreadosm__relation__struct.html#a325605fbede8b2832fffc06973b9c4c5',1,'readosm_relation_struct']]]
];
