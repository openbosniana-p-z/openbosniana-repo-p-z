var searchData=
[
  ['node_5fref_5fcount_0',['node_ref_count',['../structreadosm__way__struct.html#aabb4b16b20220c26863303eb07aa2738',1,'readosm_way_struct']]],
  ['node_5frefs_1',['node_refs',['../structreadosm__way__struct.html#a03bbcd42c4d4ed9b13c7e30e31419d72',1,'readosm_way_struct']]]
];
