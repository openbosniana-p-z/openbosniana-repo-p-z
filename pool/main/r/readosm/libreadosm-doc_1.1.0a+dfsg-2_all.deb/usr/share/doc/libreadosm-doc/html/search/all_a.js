var searchData=
[
  ['uid_0',['uid',['../structreadosm__node__struct.html#a7772e4d7c63fb29b0c0906a526a4c62c',1,'readosm_node_struct::uid()'],['../structreadosm__way__struct.html#a26408cdc931060c35362feee1dbded66',1,'readosm_way_struct::uid()'],['../structreadosm__relation__struct.html#af62f67223b4b62280d90078903d54c26',1,'readosm_relation_struct::uid()']]],
  ['user_1',['user',['../structreadosm__node__struct.html#aed5248f328cf20cd9705552fd4314d1f',1,'readosm_node_struct::user()'],['../structreadosm__way__struct.html#a22ebb1116f90476f7c2bad37eda42f27',1,'readosm_way_struct::user()'],['../structreadosm__relation__struct.html#af614ecc21aee43111dce13671eab1d27',1,'readosm_relation_struct::user()']]]
];
