var searchData=
[
  ['role_0',['role',['../structreadosm__member__struct.html#a20a3d3966f68e4f2e867782db10e37e7',1,'readosm_member_struct']]]
];
