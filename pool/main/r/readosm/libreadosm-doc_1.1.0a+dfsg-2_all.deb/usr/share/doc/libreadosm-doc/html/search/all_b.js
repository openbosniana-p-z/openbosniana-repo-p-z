var searchData=
[
  ['value_0',['value',['../structreadosm__tag__struct.html#a884e64814058418f5b299b545a50740c',1,'readosm_tag_struct']]],
  ['version_1',['version',['../structreadosm__node__struct.html#a84aeeba8aa6bf69fa82e605630522196',1,'readosm_node_struct::version()'],['../structreadosm__way__struct.html#a187d09d39bc86092001ae633dc89f35f',1,'readosm_way_struct::version()'],['../structreadosm__relation__struct.html#ac096733171e41d71d96120ca4db88195',1,'readosm_relation_struct::version()']]]
];
