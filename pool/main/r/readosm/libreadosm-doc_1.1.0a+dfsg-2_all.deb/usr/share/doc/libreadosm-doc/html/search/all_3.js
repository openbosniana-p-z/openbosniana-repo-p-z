var searchData=
[
  ['key_0',['key',['../structreadosm__tag__struct.html#a1917d162944cb30eccc4d8e1f3952943',1,'readosm_tag_struct']]]
];
