var searchData=
[
  ['about_20open_20street_20map_20datasets_0',['About Open Street Map datasets',['../intro.html',1,'']]]
];
