# rlimit

[![Latest Version]][crates.io]
[![Documentation]][docs.rs] 
![License]

Resource limits.

[crates.io]: https://crates.io/crates/rlimit
[Latest Version]: https://img.shields.io/crates/v/rlimit.svg
[Documentation]: https://docs.rs/rlimit/badge.svg
[docs.rs]: https://docs.rs/rlimit
[License]: https://img.shields.io/crates/l/rlimit.svg

Documentation: <https://docs.rs/rlimit>
