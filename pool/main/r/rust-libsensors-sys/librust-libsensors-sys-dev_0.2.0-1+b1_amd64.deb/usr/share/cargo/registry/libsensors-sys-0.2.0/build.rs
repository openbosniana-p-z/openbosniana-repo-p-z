fn main() {
    println!("cargo:rustc-link-lib=dylib=sensors");
}
