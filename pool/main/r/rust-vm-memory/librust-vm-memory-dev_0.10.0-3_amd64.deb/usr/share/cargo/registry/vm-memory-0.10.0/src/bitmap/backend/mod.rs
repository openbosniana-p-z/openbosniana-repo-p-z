// Copyright 2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0 OR BSD-3-Clause

#[cfg(any(all(test, target_has_atomic = "64"), feature = "backend-bitmap"))]
mod atomic_bitmap;
#[cfg(any(all(test, target_has_atomic = "64"), feature = "backend-bitmap"))]
mod atomic_bitmap_arc;
mod slice;

#[cfg(any(all(test, target_has_atomic = "64"), feature = "backend-bitmap"))]
pub use atomic_bitmap::AtomicBitmap;
#[cfg(any(all(test, target_has_atomic = "64"), feature = "backend-bitmap"))]
pub use atomic_bitmap_arc::AtomicBitmapArc;
pub use slice::{ArcSlice, RefSlice};
