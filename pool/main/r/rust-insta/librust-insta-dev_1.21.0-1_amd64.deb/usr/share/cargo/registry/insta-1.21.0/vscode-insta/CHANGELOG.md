# Change Log

Contains all notable changes to the vscode plugin for insta.

## 1.0.6

* Enable syntax highlighting for `.snap.new` files
* Added support for accepting/rejecting/diffing snapshots.
* Added sidebar view for pending snapshots.

## 1.0.5

* Require commas after named snapshot assertions

## 1.0.4

* Added fuzzy jump to definition

## 1.0.3

* Bugfix release

## 1.0.2

* Added jump to definition

## 1.0.1

* Improvements to the syntax grammar

## 1.0.0

* Initial release
