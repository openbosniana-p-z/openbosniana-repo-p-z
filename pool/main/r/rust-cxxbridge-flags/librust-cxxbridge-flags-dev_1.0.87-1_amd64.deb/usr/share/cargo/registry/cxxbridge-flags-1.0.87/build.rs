use std::env;

fn main() {
    println!("dh-cargo:deb-built-using=cxxbridge1=0={}", env::var("CARGO_MANIFEST_DIR").unwrap());
}
