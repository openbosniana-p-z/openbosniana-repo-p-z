# try_from

[![Travis Build Status](https://travis-ci.org/derekjw/try_from.svg?branch=master)](https://travis-ci.org/derekjw/try_from)
[![MIT licensed](https://img.shields.io/badge/license-MIT-blue.svg)](./LICENSE)
[![crates.io](http://meritbadge.herokuapp.com/try_from)](https://crates.io/crates/try_from)

TryFrom and TryInto traits for failable conversions that return a Result.
