# dbus-udisks2

A Rust API for interacting the UDisks2 DBus API. Currently provides access to information on blocks and drives, as well
as [S.M.A.R.T. data][SMART].

[SMART]: https://en.wikipedia.org/wiki/S.M.A.R.T.
