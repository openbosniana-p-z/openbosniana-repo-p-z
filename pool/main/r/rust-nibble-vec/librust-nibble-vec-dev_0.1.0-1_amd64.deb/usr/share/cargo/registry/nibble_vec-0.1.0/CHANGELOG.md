Changelog
====

0.1.0:
    * Semver-corrected re-release of 0.0.5
    * Released 28/06/2020

0.0.5 (YANKED):
    * Yanked 28/06/2020 due to semver-incompatible version change
    * Released 27/06/2020
    * Optimise implementation by using `SmallVec` (thanks @DevinR528)

0.0.4:
    * Released 07/11/2017
    * Implement `From` and `Into` conversion traits
