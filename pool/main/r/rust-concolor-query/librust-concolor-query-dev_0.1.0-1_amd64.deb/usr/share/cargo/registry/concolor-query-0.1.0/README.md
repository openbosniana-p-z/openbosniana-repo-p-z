# concolor-query

> **Low level terminal capability lookups**

[![Documentation](https://img.shields.io/badge/docs-master-blue.svg)][Documentation]
![License](https://img.shields.io/crates/l/concolor-query.svg)
[![Crates Status](https://img.shields.io/crates/v/concolor-query.svg)](https://crates.io/crates/concolor-query)

## [Contribute](../../CONTRIBUTING.md)

## License

Dual-licensed under [MIT](../../LICENSE-MIT) or [Apache 2.0](../../LICENSE-APACHE)

[Documentation]: https://docs.rs/concolor-query
