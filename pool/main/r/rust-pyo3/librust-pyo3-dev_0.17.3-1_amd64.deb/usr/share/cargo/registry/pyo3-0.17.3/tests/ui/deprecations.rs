#![deny(deprecated)]

use pyo3::prelude::*;

#[pyclass(gc)]
struct DeprecatedGc;

fn main() {

}
