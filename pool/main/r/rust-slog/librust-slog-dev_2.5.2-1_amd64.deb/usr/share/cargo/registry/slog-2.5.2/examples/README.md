This directory contains some general examples on how to use `slog`

More examples can be found in: https://github.com/slog-rs/misc/tree/master/examples

Also, some functionality-specific examples can be found in respective crates implementing them.
