Have you checked [slog-rs gitter channel][slog-rs gitter] already? Especially
if you have a question, you might get an answer much faster there.

Feel free fill an issue anyway! It's just a suggestion.

[slog-rs gitter]: https://gitter.im/slog-rs/slog
