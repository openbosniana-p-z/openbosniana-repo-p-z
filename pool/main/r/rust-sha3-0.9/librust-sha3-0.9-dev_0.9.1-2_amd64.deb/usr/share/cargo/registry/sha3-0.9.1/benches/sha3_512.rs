#![no_std]
#![feature(test)]

digest::bench!(sha3::Sha3_512);
