//! Manually niched type replacements.

#[cfg(feature = "alloc")]
pub mod option_box;
pub mod option_nonzero;
