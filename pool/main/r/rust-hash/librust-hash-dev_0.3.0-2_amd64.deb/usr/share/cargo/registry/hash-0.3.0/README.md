# Hash

Use the [md5][1] package instead.

[1]: https://crates.io/crates/md5
