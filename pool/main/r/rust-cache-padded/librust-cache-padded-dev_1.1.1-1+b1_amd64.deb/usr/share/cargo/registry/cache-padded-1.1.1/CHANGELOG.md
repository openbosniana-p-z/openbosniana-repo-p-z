# Version 1.1.1

- Forbid unsafe code.

# Version 1.1.0

- Mark `CachePadded::new()` as const fn.

# Version 1.0.0

- Initial version
