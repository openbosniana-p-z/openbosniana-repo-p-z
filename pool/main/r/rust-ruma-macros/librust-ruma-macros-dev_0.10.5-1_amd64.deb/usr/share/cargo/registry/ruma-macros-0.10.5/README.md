# ruma-macros

**ruma-macros** provides procedural macros for easily generating types for [Ruma] crates.

[Ruma]: https://github.com/ruma/ruma/
