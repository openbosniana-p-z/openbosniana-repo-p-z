# 0.1.8

* Lints about double allocation + explanation.

# 0.1.7

* Fix example.
* Move to github actions.

# 0.1.6

* Migrate to arc-swap 1.0.

# 0.1.5

* Reroute::get() to access the current logger.
* Reroute::new() (the same as default, but more discoverable).

# 0.1.4

* Dependency updates

# 0.1.3

* Dependency updates

# 0.1.2

* Flush the old logger after it gets replaced.
* Some internal cleanups.

# 0.1.1

* Dependency updates
* `deny(unsafe_code)`
* Avoids some contention by using ArcSwap::lease.
