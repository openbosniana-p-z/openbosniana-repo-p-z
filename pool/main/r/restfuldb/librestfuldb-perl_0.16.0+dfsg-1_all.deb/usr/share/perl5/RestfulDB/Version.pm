#*
#  Module to provide version number for Perl programs.
#**

package RestfulDB::Version;

our $Version = "0.16.0";

1;
