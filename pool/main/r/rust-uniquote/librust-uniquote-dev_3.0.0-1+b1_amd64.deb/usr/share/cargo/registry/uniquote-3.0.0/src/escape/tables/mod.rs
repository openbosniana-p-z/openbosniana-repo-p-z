#![allow(clippy::redundant_static_lifetimes)]
#![allow(clippy::unreadable_literal)]

mod unprintable;
pub(super) use unprintable::UNPRINTABLE;
