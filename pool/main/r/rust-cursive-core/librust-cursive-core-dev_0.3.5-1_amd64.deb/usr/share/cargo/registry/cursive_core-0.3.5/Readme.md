# Cursive-core

This crate is where most of cursive is defined, except for the backends.

Third-party libraries are encouraged to depend on this instead of `cursive`, as it should have fewer semver breaking updates.
