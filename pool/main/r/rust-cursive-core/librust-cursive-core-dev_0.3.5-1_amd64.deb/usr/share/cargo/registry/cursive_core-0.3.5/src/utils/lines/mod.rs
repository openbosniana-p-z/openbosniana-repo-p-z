//! Compute rows of text with a width constraint.

pub mod simple;
pub mod spans;
