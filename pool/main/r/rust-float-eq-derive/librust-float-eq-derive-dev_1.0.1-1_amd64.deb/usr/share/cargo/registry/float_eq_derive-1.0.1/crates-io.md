# float_eq_derive

Derive macros for the traits provided by the [float_eq] crate.

[float_eq]: https://crates.io/crates/float_eq