hidapi-sys [![WTFPL](http://img.shields.io/badge/license-WTFPL-blue.svg)](http://www.wtfpl.net/txt/copying)
==========
Bindings for hidapi with support for building sources automatically.

Requirements
------------
`gcc` and `pkg-config` are required for building source automatically.

`git` is required unless `HIDAPI_PATH` is exported to an existing checkout of
hidapi sources.
