fn main() {
    println!("cargo:rustc-link-lib=nitrokey");
}
