Changes to this crate are tracked via [GitHub Releases][releases].

[releases]: https://github.com/env-logger-rs/env_logger/releases
