use indoc::printdoc;

fn main() {
    printdoc!("", 0);
}
