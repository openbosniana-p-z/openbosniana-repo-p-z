# NTest Procedural Macro Helper

Part of the [NTest library](https://crates.io/crates/ntest). Only a helper lib for the [procedural macros](https://doc.rust-lang.org/reference/procedural-macros.html).
