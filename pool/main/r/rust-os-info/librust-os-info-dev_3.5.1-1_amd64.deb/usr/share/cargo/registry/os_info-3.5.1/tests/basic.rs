#[test]
fn get() {
    let _ = os_info::get();
}
