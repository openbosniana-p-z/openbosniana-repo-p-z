// spell-checker:ignore doctest

doc_comment::doctest!("../README.md");
