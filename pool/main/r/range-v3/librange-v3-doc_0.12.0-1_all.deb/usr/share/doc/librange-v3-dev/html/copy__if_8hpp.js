var copy__if_8hpp =
[
    [ "copy_if_result", "copy__if_8hpp.html#ga5a179c5b7b8620b7fd95dc315cab0a39", null ],
    [ "c", "copy__if_8hpp.html#ga21afc53b8dcaa3bd8a50c22de51a7055", null ],
    [ "c", "copy__if_8hpp.html#ga3aa34042b346930133867b0fc8eb125b", null ],
    [ "copy_if", "copy__if_8hpp.html#ga954fd5dd88818093bbbe8075b157ee92", null ],
    [ "copy_if", "copy__if_8hpp.html#ga5f0c860e43636786e7c00399ec450b07", null ]
];