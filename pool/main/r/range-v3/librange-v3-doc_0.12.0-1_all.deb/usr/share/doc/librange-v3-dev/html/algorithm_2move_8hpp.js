var algorithm_2move_8hpp =
[
    [ "move_result", "algorithm_2move_8hpp.html#gaa9e56e40c245536a73cd3c4479aa71f0", null ],
    [ "c", "algorithm_2move_8hpp.html#ga4e065300354d2b021e48aaf105cc16a3", null ],
    [ "c", "algorithm_2move_8hpp.html#ga68e7a73cb5306d7513e59663f426a9ec", null ],
    [ "move", "algorithm_2move_8hpp.html#ga63ac66579148767d1a0184d03231ad6a", null ],
    [ "move", "algorithm_2move_8hpp.html#ga8435ef0ae4dbfc86e34ea0831856fe1a", null ]
];