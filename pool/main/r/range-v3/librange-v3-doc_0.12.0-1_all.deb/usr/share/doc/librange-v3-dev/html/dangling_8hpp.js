var dangling_8hpp =
[
    [ "borrowed_iterator_t", "dangling_8hpp.html#ade381c95683087fb787bc32b9a9c4c94", null ],
    [ "safe_iterator_t", "dangling_8hpp.html#abc26fe04a0c57bf96762004c4f667e95", null ],
    [ "safe_iterator_t", "dangling_8hpp.html#a8ee885b2854c71b40ee066823edabac2", null ]
];