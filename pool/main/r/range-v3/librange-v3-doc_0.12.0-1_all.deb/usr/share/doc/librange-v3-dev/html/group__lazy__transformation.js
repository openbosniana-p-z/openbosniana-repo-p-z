var group__lazy__transformation =
[
    [ "accumulate", "group__lazy__transformation.html#ga96812ae7697cd753a04ebb4d231f11f8", null ],
    [ "cartesian_product", "group__lazy__transformation.html#ga7618cffe976d0c5158c683c9186c4af0", null ],
    [ "concat", "group__lazy__transformation.html#gab2a5a4b7b5c4542f2d2009a239c4fcea", null ],
    [ "drop", "group__lazy__transformation.html#ga355355c270cebd2f658951d2d0140699", null ],
    [ "filter", "group__lazy__transformation.html#ga982258533559aefa05953c94167d3a33", null ],
    [ "fold", "group__lazy__transformation.html#gac2455ade845faf232e91bfc6b1eac2da", null ],
    [ "join", "group__lazy__transformation.html#ga5292fd127ef68013889ce784822703bb", null ],
    [ "partition", "group__lazy__transformation.html#ga2410e097ab79bafcf93fa2751fce162d", null ],
    [ "pop_front", "group__lazy__transformation.html#ga583bef4b0199c43bcc502db159421510", null ],
    [ "push_back", "group__lazy__transformation.html#gac38d4ddb4e7056e78369ec580f88c663", null ],
    [ "push_front", "group__lazy__transformation.html#gaa45bedd8e345599914d393e741ca0170", null ],
    [ "replace", "group__lazy__transformation.html#gaecb65f18ce9369d7839398ad033158fa", null ],
    [ "replace_if", "group__lazy__transformation.html#ga653bec9d6d98c66bd7575237dad42c6d", null ],
    [ "reverse", "group__lazy__transformation.html#ga54897d8bfa761d847f6bc70f02d6206e", null ],
    [ "reverse_fold", "group__lazy__transformation.html#gac6a77ab5e3b23c87fb1cf37f8261354f", null ],
    [ "sort", "group__lazy__transformation.html#ga9ea8f5d01e1d1842df09e3ee6fda21d9", null ],
    [ "transform", "group__lazy__transformation.html#gaa72db1ef09f440fccb0c2ce30f61f577", null ],
    [ "transpose", "group__lazy__transformation.html#ga380ef764edf25a09e9ef20afa7daffa7", null ],
    [ "unique", "group__lazy__transformation.html#ga42f3b970e80aab370d5540b4d84ef1d4", null ],
    [ "zip", "group__lazy__transformation.html#gae296ffdc41b6cb3d3fd654c4800bb79a", null ],
    [ "zip_with", "group__lazy__transformation.html#gab8fb91e99810893e1f7675bce1e724e4", null ]
];