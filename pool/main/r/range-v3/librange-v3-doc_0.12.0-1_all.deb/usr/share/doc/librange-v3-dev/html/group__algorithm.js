var group__algorithm =
[
    [ "Query/Search", "group__query.html", "group__query" ],
    [ "Transformation", "group__transformation.html", "group__transformation" ],
    [ "Runtime", "group__runtime.html", "group__runtime" ]
];