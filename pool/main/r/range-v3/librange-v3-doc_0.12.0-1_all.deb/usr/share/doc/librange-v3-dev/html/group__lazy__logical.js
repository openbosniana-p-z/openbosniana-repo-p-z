var group__lazy__logical =
[
    [ "and_", "group__lazy__logical.html#gad308c19572f36349d611c4e5e8457550", null ],
    [ "if_", "group__lazy__logical.html#ga8c71ad12f7d1077e9680c19404ffe02c", null ],
    [ "if_c", "group__lazy__logical.html#gae00d694c7549536a491abd60eaff6c7f", null ],
    [ "not_", "group__lazy__logical.html#ga57d87f8bb1199b5748eb3fc761b467fe", null ],
    [ "or_", "group__lazy__logical.html#gac6b7cfec9bc49c4e50bd6f107db4a303", null ],
    [ "strict_and", "group__lazy__logical.html#ga6eecd0f06241492c16c9b74ecd4f2869", null ],
    [ "strict_or", "group__lazy__logical.html#ga56500e982893ce81207b25e497ab2a94", null ]
];