var partition_8hpp =
[
    [ "c", "partition_8hpp.html#gaecff17fd7ca05fac6f4a4d75b979cf10", null ]
];