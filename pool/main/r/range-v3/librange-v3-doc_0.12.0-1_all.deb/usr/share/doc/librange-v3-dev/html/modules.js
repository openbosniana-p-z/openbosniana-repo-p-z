var modules =
[
    [ "Meta", "group__meta.html", "group__meta" ],
    [ "Iterator", "group__group-iterator.html", "group__group-iterator" ],
    [ "Range", "group__group-range.html", "group__group-range" ],
    [ "Algorithms", "group__group-algorithms.html", "group__group-algorithms" ],
    [ "Views", "group__group-views.html", "group__group-views" ],
    [ "Actions", "group__group-actions.html", "group__group-actions" ],
    [ "Utility", "group__group-utility.html", "group__group-utility" ],
    [ "Functional", "group__group-functional.html", "group__group-functional" ],
    [ "Numerics", "group__group-numerics.html", "group__group-numerics" ]
];