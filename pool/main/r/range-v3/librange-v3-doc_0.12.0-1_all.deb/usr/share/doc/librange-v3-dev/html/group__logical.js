var group__logical =
[
    [ "lazy", "group__lazy__logical.html", "group__lazy__logical" ],
    [ "or_c", "structmeta_1_1or__c.html", null ],
    [ "and_", "group__logical.html#ga5fb9c50c97365f0981dceef2f2759f2e", null ],
    [ "conditional_t", "group__logical.html#ga9fbf879d37e7406c5f3c026e6ed37b59", null ],
    [ "if_", "group__logical.html#ga45b0f89c4e4d2c891cd3344d55b52627", null ],
    [ "if_c", "group__logical.html#ga54a5a3814a5d4535865dfbbf79a47bff", null ],
    [ "not_", "group__logical.html#ga72884249179b0b22a27cc0709b75f23b", null ],
    [ "not_c", "group__logical.html#gaef6022dae0f8ae9d30b3495287c734bb", null ],
    [ "or_", "group__logical.html#gab82c32064e50ad37878ef4b3d4f8be3e", null ],
    [ "strict_and_", "group__logical.html#gad6c4944687eb36519341d2ba83a10fb8", null ],
    [ "strict_or_", "group__logical.html#gaf8d3a296d5d944c83c38f70c2837889a", null ]
];