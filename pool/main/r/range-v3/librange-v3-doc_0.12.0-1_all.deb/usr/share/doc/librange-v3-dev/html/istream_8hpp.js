var istream_8hpp =
[
    [ "basic_istream_view", "istream_8hpp.html#acf53cf10bb06cfd4155c7da3bc9519cb", null ],
    [ "i", "istream_8hpp.html#ga028c70b05fce1990e6ccc34319f39d6a", null ]
];