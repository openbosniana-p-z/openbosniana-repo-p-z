var group__extension =
[
    [ "apply", "structmeta_1_1extension_1_1apply.html", null ]
];