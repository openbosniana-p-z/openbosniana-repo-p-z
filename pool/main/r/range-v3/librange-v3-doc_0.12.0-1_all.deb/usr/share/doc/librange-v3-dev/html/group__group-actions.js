var group__group_actions =
[
    [ "make_action_closure_fn", "structranges_1_1make__action__closure__fn.html", [
      [ "operator()", "structranges_1_1make__action__closure__fn.html#a7ea394935f617fa034f12b2821dcf7bf", null ]
    ] ],
    [ "push_back_fn", "structranges_1_1push__back__fn.html", [
      [ "c", "structranges_1_1push__back__fn.html#ad74de9c90505018df3bdefeb5ca08ef0", null ],
      [ "CPP_TEMPLATE_AUX_0", "structranges_1_1push__back__fn.html#a5e418df07c6bcccb760ed2ec11c45e07", null ],
      [ "operator()", "structranges_1_1push__back__fn.html#a1d26d7a23894e984c70c86b57ffef4b4", null ],
      [ "operator()", "structranges_1_1push__back__fn.html#a1fd3e7259750816a42ee321f07ebeb3c", null ],
      [ "R", "structranges_1_1push__back__fn.html#ad9d93c17184c5a5ad15fffc23a87e678", null ],
      [ "static_cast", "structranges_1_1push__back__fn.html#aa09d4aa517d05ec00d3ec839dd331d74", null ],
      [ "static_cast", "structranges_1_1push__back__fn.html#aa09d4aa517d05ec00d3ec839dd331d74", null ],
      [ "const", "structranges_1_1push__back__fn.html#a65324e181031aa7e4144daa043ca3c3c", null ],
      [ "const", "structranges_1_1push__back__fn.html#ab94a22025c8a3f19bdf3308d265eb86c", null ]
    ] ],
    [ "push_front_fn", "structranges_1_1push__front__fn.html", [
      [ "c", "structranges_1_1push__front__fn.html#aac520edf9e04c8149b6b54f4d7ccaa53", null ],
      [ "CPP_TEMPLATE_AUX_0", "structranges_1_1push__front__fn.html#aedcc7d757a02660032e758b29fe19461", null ],
      [ "operator()", "structranges_1_1push__front__fn.html#aebc142e9380e5ce81a269419dbebc00d", null ],
      [ "operator()", "structranges_1_1push__front__fn.html#a7f497ee1ad824e35c3b0e722164fc8dc", null ],
      [ "R", "structranges_1_1push__front__fn.html#aa0477047f165edaa342ec344a5ccba9e", null ],
      [ "static_cast", "structranges_1_1push__front__fn.html#a77c3067c7ccd4379c379166e1aab0188", null ],
      [ "static_cast", "structranges_1_1push__front__fn.html#a77c3067c7ccd4379c379166e1aab0188", null ],
      [ "const", "structranges_1_1push__front__fn.html#a05d11297619ffaa231c4f8b196161840", null ],
      [ "const", "structranges_1_1push__front__fn.html#a45d4355f98d11d0ed87b45540d5c5ab6", null ]
    ] ],
    [ "template", "group__group-actions.html#gaea35f609be429a87d4c869aee762c96d", null ],
    [ "iinvocable_action_closure", "group__group-actions.html#gaef95e1722c0341850d599f16f2d78312", null ],
    [ "make_action_closure", "group__group-actions.html#gaeb264d48f731e75689136caf2f888e13", null ]
];