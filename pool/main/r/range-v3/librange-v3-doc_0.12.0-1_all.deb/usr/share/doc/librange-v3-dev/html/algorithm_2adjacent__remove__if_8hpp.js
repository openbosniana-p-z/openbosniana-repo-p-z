var algorithm_2adjacent__remove__if_8hpp =
[
    [ "c", "algorithm_2adjacent__remove__if_8hpp.html#gaca16921b780f36bacbffb4bc85f1314b", null ],
    [ "Pred", "algorithm_2adjacent__remove__if_8hpp.html#ga52a87a2e5521aae2943fde050ab7db57", null ]
];