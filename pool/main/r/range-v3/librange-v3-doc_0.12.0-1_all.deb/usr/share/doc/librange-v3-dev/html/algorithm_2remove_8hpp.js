var algorithm_2remove_8hpp =
[
    [ "c", "algorithm_2remove_8hpp.html#ga8bad2ef55923aeb0c82056ba045a42ed", null ]
];