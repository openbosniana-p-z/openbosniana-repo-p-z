var drop__last_8hpp =
[
    [ "drop_last_base_fn", "structranges_1_1views_1_1drop__last__base__fn.html", "structranges_1_1views_1_1drop__last__base__fn" ],
    [ "drop_last_fn", "structranges_1_1views_1_1drop__last__fn.html", "structranges_1_1views_1_1drop__last__fn" ],
    [ "drop_last", "drop__last_8hpp.html#aec895b6e29bdf5cefa231e3491f81b50", null ],
    [ "enable_borrowed_range< drop_last_view< Rng, T > >", "drop__last_8hpp.html#ga7d46a6c5e31ef407b1b20c5a2dfb919f", null ]
];