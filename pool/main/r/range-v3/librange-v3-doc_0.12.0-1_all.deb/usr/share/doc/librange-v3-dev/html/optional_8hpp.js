var optional_8hpp =
[
    [ "bad_optional_access", "structranges_1_1bad__optional__access.html", "structranges_1_1bad__optional__access" ],
    [ "nullopt_t", "structranges_1_1nullopt__t.html", "structranges_1_1nullopt__t" ],
    [ "tag", "structranges_1_1nullopt__t_1_1tag.html", null ],
    [ "optional", "structranges_1_1optional.html", "structranges_1_1optional" ],
    [ "ooptional_should_convert", "optional_8hpp.html#a99498799e63e680a4be292ebfa07efb1", null ],
    [ "ooptional_should_convert_assign", "optional_8hpp.html#ad2a20df472424c994e24a48ad8668fca", null ]
];