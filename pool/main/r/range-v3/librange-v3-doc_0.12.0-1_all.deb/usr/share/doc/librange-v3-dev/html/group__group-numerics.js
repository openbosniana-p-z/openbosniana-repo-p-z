var group__group_numerics =
[
    [ "accumulate_fn", "structranges_1_1accumulate__fn.html", [
      [ "T", "structranges_1_1accumulate__fn.html#a756b882fda19871e496c04d3a409baf0", null ],
      [ "init", "structranges_1_1accumulate__fn.html#a43eafca2299d14d3720de37b6e27c94e", null ],
      [ "last", "structranges_1_1accumulate__fn.html#af9e1dd0689ec4840be5f30f802dccab4", null ],
      [ "op", "structranges_1_1accumulate__fn.html#a755fe7a047ef028b83a472594c985f0b", null ],
      [ "Op", "structranges_1_1accumulate__fn.html#a6d630766c646d0605a5354edbfa24060", null ],
      [ "proj", "structranges_1_1accumulate__fn.html#a0f6057a90050f94cc38af85d419a3fcc", null ],
      [ "T", "structranges_1_1accumulate__fn.html#a3f98f016f97587a1dc6db6985cb8d409", null ]
    ] ],
    [ "adjacent_difference_fn", "structranges_1_1adjacent__difference__fn.html", [
      [ "a", "structranges_1_1adjacent__difference__fn.html#adf45c877c83a264230c37ea60239fd58", null ],
      [ "a", "structranges_1_1adjacent__difference__fn.html#adbf94eac760882a2912cfecaeda6aec9", null ],
      [ "a", "structranges_1_1adjacent__difference__fn.html#a1ce672f0b809fd04f73ee301dcf56f1b", null ],
      [ "a", "structranges_1_1adjacent__difference__fn.html#a37122b51c409d8feeb0b015bd4f2fd7b", null ],
      [ "operator()", "structranges_1_1adjacent__difference__fn.html#a80052c7abc95ee9776198b12257e0e94", null ],
      [ "operator()", "structranges_1_1adjacent__difference__fn.html#a818f26ffd998f7f758e67c772e45d882", null ],
      [ "operator()", "structranges_1_1adjacent__difference__fn.html#a0e62c78513b84d607fd7bde6831ea855", null ],
      [ "operator()", "structranges_1_1adjacent__difference__fn.html#aa3185091806676a7af679053505c84ed", null ]
    ] ],
    [ "inner_product_fn", "structranges_1_1inner__product__fn.html", [
      [ "T", "structranges_1_1inner__product__fn.html#adb18cf274f8182e25dc8d68ee6af52a8", null ],
      [ "begin2", "structranges_1_1inner__product__fn.html#ae9a90edc637c37ff830d81aa4a5f5b21", null ],
      [ "bop1", "structranges_1_1inner__product__fn.html#ad13e8e4cb3a6920e90566c9708c77d3c", null ],
      [ "BOp1", "structranges_1_1inner__product__fn.html#a287a71ec47be725ca5691c1c958894e2", null ],
      [ "bop2", "structranges_1_1inner__product__fn.html#ae4727f684e5912683c5fa73078cc9668", null ],
      [ "BOp2", "structranges_1_1inner__product__fn.html#a371f14a2387b64a1923318ca538539a8", null ],
      [ "end1", "structranges_1_1inner__product__fn.html#ace90ffc074b4ad56dc85ef2bc45ec9ed", null ],
      [ "end2", "structranges_1_1inner__product__fn.html#a2e8fd589a55c7c0cd9ca71eea32e42d9", null ],
      [ "I1", "structranges_1_1inner__product__fn.html#afae637736ff9e754116f6d337fb7254f", null ],
      [ "I2", "structranges_1_1inner__product__fn.html#ae4e28c667efeca4bee7faae2a82136d9", null ],
      [ "I2Ref", "structranges_1_1inner__product__fn.html#a69f23570fd14bf9b6f42ac6a7db5b6f0", null ],
      [ "init", "structranges_1_1inner__product__fn.html#a186536a34593237f332fbd22c4fb27a4", null ],
      [ "P1", "structranges_1_1inner__product__fn.html#a3cced8d2b653b6dd13ee67ac2371b165", null ],
      [ "P2", "structranges_1_1inner__product__fn.html#affb4a4c8c9f293eb1d2e529b6370eb79", null ],
      [ "proj1", "structranges_1_1inner__product__fn.html#af9ecf9b116910e8b2bd173011704ce59", null ],
      [ "proj2", "structranges_1_1inner__product__fn.html#afe4ac6e2f896365ac68d60a97b921269", null ],
      [ "Rng2", "structranges_1_1inner__product__fn.html#a02ada316993a332168d41c498e648473", null ],
      [ "S1", "structranges_1_1inner__product__fn.html#a214bcc229654d30ba817b7ebfc1ca9ce", null ],
      [ "T", "structranges_1_1inner__product__fn.html#a8d44285c6c55bb5ae422adb9091faa25", null ]
    ] ],
    [ "iota_fn", "structranges_1_1iota__fn.html", [
      [ "b", "structranges_1_1iota__fn.html#ad661a6d194570a99686fef4036b7cdd1", null ],
      [ "O", "structranges_1_1iota__fn.html#ae90d2db2c41bf52c4d2be1b57c817e94", null ],
      [ "const", "structranges_1_1iota__fn.html#a2ef0f5abb02baa9b1176cec1d93a2e8b", null ],
      [ "const", "structranges_1_1iota__fn.html#ab0f2b697c326fda9481f96b389dd68ca", null ],
      [ "first", "structranges_1_1iota__fn.html#a5d89db82042a686ac2f25c2f5e9858b5", null ],
      [ "last", "structranges_1_1iota__fn.html#aab3e50afcaeb1c591b175b8f3ab9d9c5", null ]
    ] ],
    [ "partial_sum_fn", "structranges_1_1partial__sum__fn.html", [
      [ "operator()", "structranges_1_1partial__sum__fn.html#a5ad97ea1e3c2244a3d6a7f1a5c2cf964", null ],
      [ "operator()", "structranges_1_1partial__sum__fn.html#a981fbfbaec7cf8173289989d690a1a4c", null ],
      [ "operator()", "structranges_1_1partial__sum__fn.html#a75bb7770e87e3fbb691096d38cefc1e3", null ],
      [ "operator()", "structranges_1_1partial__sum__fn.html#a40f3ee0fe6079cca5f0106ee0e4282e4", null ],
      [ "p", "structranges_1_1partial__sum__fn.html#ac6ea6ba5272c0630f840ebb08700327f", null ],
      [ "p", "structranges_1_1partial__sum__fn.html#a49ecff948fc8ecd0649b9de422a5c67a", null ],
      [ "p", "structranges_1_1partial__sum__fn.html#adc18c3ceb362cc6d76e94de8bd96d354", null ],
      [ "p", "structranges_1_1partial__sum__fn.html#ab0a5f259825433d95aed4d38771f894a", null ]
    ] ],
    [ "ddifferenceable", "group__group-numerics.html#gac83005b3997e43dc8180d084f0c094b3", null ],
    [ "iindirect_semigroup", "group__group-numerics.html#ga9fcb90129fc5f11cafce4a568a4a413d", null ],
    [ "iinner_product_constraints", "group__group-numerics.html#ga47e49b78e5e48145df56e3e1916aad7e", null ],
    [ "ppartial_sum_constraints", "group__group-numerics.html#ga51d37ea47448a6dce9e52e288b9f534a", null ],
    [ "uniform_random_bit_generator_", "group__group-numerics.html#ga94477301c132f1d310da5aefbb46aa5b", null ],
    [ "uuniform_random_bit_generator", "group__group-numerics.html#ga51c0deacb9f13de13303b7054f2dbf63", null ]
];