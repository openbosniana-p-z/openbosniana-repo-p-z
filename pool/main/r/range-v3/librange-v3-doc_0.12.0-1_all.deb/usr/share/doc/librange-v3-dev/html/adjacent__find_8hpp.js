var adjacent__find_8hpp =
[
    [ "c", "adjacent__find_8hpp.html#ga676ff4539ca01f93dd9e4de8fe69a75c", null ],
    [ "C", "adjacent__find_8hpp.html#ga06e4553c4b8c4c24fbae93c31b17130e", null ],
    [ "last", "adjacent__find_8hpp.html#ga79f954a7c0f38a65c8e3fe4cb9b68b3a", null ],
    [ "pred", "adjacent__find_8hpp.html#gafb4da732185e112a1ee2b3500c90436b", null ],
    [ "proj", "adjacent__find_8hpp.html#ga6b339b9d38f7f1e9f7ec20809d1874c7", null ]
];