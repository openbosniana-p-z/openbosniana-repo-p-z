var minmax__element_8hpp =
[
    [ "minmax_element_result", "minmax__element_8hpp.html#ga2551631b044f18c25ebf252d89ab62d1", null ],
    [ "c", "minmax__element_8hpp.html#ga59c3d58d2328a9af9392a08f70ec0c4c", null ]
];