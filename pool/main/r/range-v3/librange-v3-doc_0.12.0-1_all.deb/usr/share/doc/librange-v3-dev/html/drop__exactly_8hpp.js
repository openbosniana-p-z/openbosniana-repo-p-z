var drop__exactly_8hpp =
[
    [ "drop_exactly_base_fn", "structranges_1_1views_1_1drop__exactly__base__fn.html", "structranges_1_1views_1_1drop__exactly__base__fn" ],
    [ "drop_exactly_fn", "structranges_1_1views_1_1drop__exactly__fn.html", "structranges_1_1views_1_1drop__exactly__fn" ],
    [ "enable_borrowed_range< drop_exactly_view< Rng > >", "drop__exactly_8hpp.html#gaa43631b723c3333f155f9f82d0104c91", null ]
];