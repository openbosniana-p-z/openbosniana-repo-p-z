var dir_b00b1d9d00cc44a1bf5374fbcb141bf4 =
[
    [ "adaptor.hpp", "adaptor_8hpp.html", "adaptor_8hpp" ],
    [ "addressof.hpp", "view_2addressof_8hpp.html", [
      [ "addressof_fn", "structranges_1_1views_1_1addressof__fn.html", "structranges_1_1views_1_1addressof__fn" ]
    ] ],
    [ "adjacent_filter.hpp", "adjacent__filter_8hpp.html", [
      [ "adjacent_filter_base_fn", "structranges_1_1views_1_1adjacent__filter__base__fn.html", "structranges_1_1views_1_1adjacent__filter__base__fn" ],
      [ "adjacent_filter_fn", "structranges_1_1views_1_1adjacent__filter__fn.html", "structranges_1_1views_1_1adjacent__filter__fn" ]
    ] ],
    [ "adjacent_remove_if.hpp", "view_2adjacent__remove__if_8hpp.html", [
      [ "adjacent_remove_if_base_fn", "structranges_1_1views_1_1adjacent__remove__if__base__fn.html", "structranges_1_1views_1_1adjacent__remove__if__base__fn" ],
      [ "adjacent_remove_if_fn", "structranges_1_1views_1_1adjacent__remove__if__fn.html", "structranges_1_1views_1_1adjacent__remove__if__fn" ]
    ] ],
    [ "all.hpp", "view_2all_8hpp.html", "view_2all_8hpp" ],
    [ "any_view.hpp", "any__view_8hpp.html", "any__view_8hpp" ],
    [ "c_str.hpp", "c__str_8hpp.html", null ],
    [ "cache1.hpp", "cache1_8hpp.html", [
      [ "cache1_fn", "structranges_1_1views_1_1cache1__fn.html", "structranges_1_1views_1_1cache1__fn" ]
    ] ],
    [ "cartesian_product.hpp", "cartesian__product_8hpp.html", "cartesian__product_8hpp" ],
    [ "chunk.hpp", "chunk_8hpp.html", "chunk_8hpp" ],
    [ "chunk_by.hpp", "chunk__by_8hpp.html", [
      [ "chunk_by_base_fn", "structranges_1_1views_1_1chunk__by__base__fn.html", "structranges_1_1views_1_1chunk__by__base__fn" ],
      [ "chunk_by_fn", "structranges_1_1views_1_1chunk__by__fn.html", "structranges_1_1views_1_1chunk__by__fn" ]
    ] ],
    [ "common.hpp", "common_8hpp.html", "common_8hpp" ],
    [ "concat.hpp", "concat_8hpp.html", [
      [ "concat_fn", "structranges_1_1views_1_1concat__fn.html", "structranges_1_1views_1_1concat__fn" ]
    ] ],
    [ "const.hpp", "const_8hpp.html", "const_8hpp" ],
    [ "counted.hpp", "counted_8hpp.html", "counted_8hpp" ],
    [ "cycle.hpp", "cycle_8hpp.html", [
      [ "cycle_fn", "structranges_1_1views_1_1cycle__fn.html", "structranges_1_1views_1_1cycle__fn" ]
    ] ],
    [ "delimit.hpp", "delimit_8hpp.html", "delimit_8hpp" ],
    [ "drop.hpp", "view_2drop_8hpp.html", "view_2drop_8hpp" ],
    [ "drop_exactly.hpp", "drop__exactly_8hpp.html", "drop__exactly_8hpp" ],
    [ "drop_last.hpp", "drop__last_8hpp.html", "drop__last_8hpp" ],
    [ "drop_while.hpp", "view_2drop__while_8hpp.html", "view_2drop__while_8hpp" ],
    [ "empty.hpp", "empty_8hpp.html", "empty_8hpp" ],
    [ "enumerate.hpp", "enumerate_8hpp.html", [
      [ "enumerate_fn", "structranges_1_1views_1_1enumerate__fn.html", "structranges_1_1views_1_1enumerate__fn" ]
    ] ],
    [ "exclusive_scan.hpp", "exclusive__scan_8hpp.html", "exclusive__scan_8hpp" ],
    [ "facade.hpp", "facade_8hpp.html", [
      [ "view_as_cursor", "structranges_1_1view__facade_1_1view__as__cursor.html", "structranges_1_1view__facade_1_1view__as__cursor" ]
    ] ],
    [ "filter.hpp", "filter_8hpp.html", "filter_8hpp" ],
    [ "for_each.hpp", "view_2for__each_8hpp.html", [
      [ "for_each_base_fn", "structranges_1_1views_1_1for__each__base__fn.html", "structranges_1_1views_1_1for__each__base__fn" ],
      [ "for_each_fn", "structranges_1_1views_1_1for__each__fn.html", "structranges_1_1views_1_1for__each__fn" ]
    ] ],
    [ "generate.hpp", "view_2generate_8hpp.html", null ],
    [ "generate_n.hpp", "view_2generate__n_8hpp.html", [
      [ "generate_n_fn", "structranges_1_1views_1_1generate__n__fn.html", "structranges_1_1views_1_1generate__n__fn" ]
    ] ],
    [ "getlines.hpp", "getlines_8hpp.html", "getlines_8hpp" ],
    [ "group_by.hpp", "group__by_8hpp.html", [
      [ "group_by_base_fn", "structranges_1_1views_1_1group__by__base__fn.html", null ],
      [ "group_by_fn", "structranges_1_1views_1_1group__by__fn.html", "structranges_1_1views_1_1group__by__fn" ]
    ] ],
    [ "indices.hpp", "indices_8hpp.html", [
      [ "closed_indices_fn", "structranges_1_1views_1_1closed__indices__fn.html", "structranges_1_1views_1_1closed__indices__fn" ],
      [ "indices_fn", "structranges_1_1views_1_1indices__fn.html", "structranges_1_1views_1_1indices__fn" ]
    ] ],
    [ "indirect.hpp", "view_2indirect_8hpp.html", null ],
    [ "interface.hpp", "interface_8hpp.html", "interface_8hpp" ],
    [ "intersperse.hpp", "intersperse_8hpp.html", "intersperse_8hpp" ],
    [ "iota.hpp", "view_2iota_8hpp.html", "view_2iota_8hpp" ],
    [ "istream.hpp", "istream_8hpp.html", "istream_8hpp" ],
    [ "join.hpp", "view_2join_8hpp.html", "view_2join_8hpp" ],
    [ "linear_distribute.hpp", "linear__distribute_8hpp.html", null ],
    [ "map.hpp", "map_8hpp.html", "map_8hpp" ],
    [ "move.hpp", "view_2move_8hpp.html", "view_2move_8hpp" ],
    [ "partial_sum.hpp", "view_2partial__sum_8hpp.html", [
      [ "partial_sum_base_fn", "structranges_1_1views_1_1partial__sum__base__fn.html", "structranges_1_1views_1_1partial__sum__base__fn" ],
      [ "partial_sum_fn", "structranges_1_1views_1_1partial__sum__fn.html", "structranges_1_1views_1_1partial__sum__fn" ]
    ] ],
    [ "ref.hpp", "ref_8hpp.html", "ref_8hpp" ],
    [ "remove.hpp", "view_2remove_8hpp.html", [
      [ "remove_base_fn", "structranges_1_1views_1_1remove__base__fn.html", "structranges_1_1views_1_1remove__base__fn" ],
      [ "remove_bind_fn", "structranges_1_1views_1_1remove__bind__fn.html", "structranges_1_1views_1_1remove__bind__fn" ],
      [ "remove_fn", "structranges_1_1views_1_1remove__fn.html", "structranges_1_1views_1_1remove__fn" ]
    ] ],
    [ "remove_if.hpp", "view_2remove__if_8hpp.html", [
      [ "remove_if_base_fn", "structranges_1_1views_1_1remove__if__base__fn.html", "structranges_1_1views_1_1remove__if__base__fn" ],
      [ "remove_if_bind_fn", "structranges_1_1views_1_1remove__if__bind__fn.html", "structranges_1_1views_1_1remove__if__bind__fn" ],
      [ "remove_if_fn", "structranges_1_1views_1_1remove__if__fn.html", "structranges_1_1views_1_1remove__if__fn" ]
    ] ],
    [ "repeat.hpp", "repeat_8hpp.html", [
      [ "repeat_fn", "structranges_1_1views_1_1repeat__fn.html", "structranges_1_1views_1_1repeat__fn" ]
    ] ],
    [ "repeat_n.hpp", "repeat__n_8hpp.html", [
      [ "repeat_n_fn", "structranges_1_1views_1_1repeat__n__fn.html", "structranges_1_1views_1_1repeat__n__fn" ]
    ] ],
    [ "replace.hpp", "view_2replace_8hpp.html", [
      [ "replace_base_fn", "structranges_1_1views_1_1replace__base__fn.html", "structranges_1_1views_1_1replace__base__fn" ],
      [ "replace_fn", "structranges_1_1views_1_1replace__fn.html", "structranges_1_1views_1_1replace__fn" ]
    ] ],
    [ "replace_if.hpp", "view_2replace__if_8hpp.html", [
      [ "replace_if_base_fn", "structranges_1_1views_1_1replace__if__base__fn.html", "structranges_1_1views_1_1replace__if__base__fn" ],
      [ "replace_if_fn", "structranges_1_1views_1_1replace__if__fn.html", "structranges_1_1views_1_1replace__if__fn" ]
    ] ],
    [ "reverse.hpp", "view_2reverse_8hpp.html", "view_2reverse_8hpp" ],
    [ "sample.hpp", "view_2sample_8hpp.html", [
      [ "sample_base_fn", "structranges_1_1views_1_1sample__base__fn.html", "structranges_1_1views_1_1sample__base__fn" ],
      [ "sample_fn", "structranges_1_1views_1_1sample__fn.html", "structranges_1_1views_1_1sample__fn" ]
    ] ],
    [ "set_algorithm.hpp", "view_2set__algorithm_8hpp.html", "view_2set__algorithm_8hpp" ],
    [ "single.hpp", "single_8hpp.html", "single_8hpp" ],
    [ "slice.hpp", "view_2slice_8hpp.html", "view_2slice_8hpp" ],
    [ "sliding.hpp", "sliding_8hpp.html", "sliding_8hpp" ],
    [ "span.hpp", "span_8hpp.html", "span_8hpp" ],
    [ "split.hpp", "view_2split_8hpp.html", "view_2split_8hpp" ],
    [ "split_when.hpp", "view_2split__when_8hpp.html", [
      [ "split_when_base_fn", "structranges_1_1views_1_1split__when__base__fn.html", "structranges_1_1views_1_1split__when__base__fn" ],
      [ "split_when_fn", "structranges_1_1views_1_1split__when__fn.html", "structranges_1_1views_1_1split__when__fn" ]
    ] ],
    [ "stride.hpp", "view_2stride_8hpp.html", [
      [ "stride_base_fn", "structranges_1_1views_1_1stride__base__fn.html", "structranges_1_1views_1_1stride__base__fn" ],
      [ "stride_fn", "structranges_1_1views_1_1stride__fn.html", "structranges_1_1views_1_1stride__fn" ]
    ] ],
    [ "subrange.hpp", "subrange_8hpp.html", "subrange_8hpp" ],
    [ "tail.hpp", "tail_8hpp.html", "tail_8hpp" ],
    [ "take.hpp", "view_2take_8hpp.html", "view_2take_8hpp" ],
    [ "take_exactly.hpp", "take__exactly_8hpp.html", [
      [ "take_exactly_base_fn", "structranges_1_1views_1_1take__exactly__base__fn.html", "structranges_1_1views_1_1take__exactly__base__fn" ],
      [ "take_exactly_fn", "structranges_1_1views_1_1take__exactly__fn.html", "structranges_1_1views_1_1take__exactly__fn" ]
    ] ],
    [ "take_last.hpp", "take__last_8hpp.html", [
      [ "take_last_base_fn", "structranges_1_1views_1_1take__last__base__fn.html", "structranges_1_1views_1_1take__last__base__fn" ],
      [ "take_last_fn", "structranges_1_1views_1_1take__last__fn.html", "structranges_1_1views_1_1take__last__fn" ]
    ] ],
    [ "take_while.hpp", "view_2take__while_8hpp.html", "view_2take__while_8hpp" ],
    [ "tokenize.hpp", "tokenize_8hpp.html", [
      [ "tokenize_base_fn", "structranges_1_1views_1_1tokenize__base__fn.html", "structranges_1_1views_1_1tokenize__base__fn" ],
      [ "tokenize_fn", "structranges_1_1views_1_1tokenize__fn.html", "structranges_1_1views_1_1tokenize__fn" ]
    ] ],
    [ "transform.hpp", "view_2transform_8hpp.html", "view_2transform_8hpp" ],
    [ "trim.hpp", "trim_8hpp.html", "trim_8hpp" ],
    [ "unique.hpp", "view_2unique_8hpp.html", [
      [ "unique_base_fn", "structranges_1_1views_1_1unique__base__fn.html", "structranges_1_1views_1_1unique__base__fn" ],
      [ "unique_fn", "structranges_1_1views_1_1unique__fn.html", "structranges_1_1views_1_1unique__fn" ]
    ] ],
    [ "view.hpp", "view_2view_8hpp.html", "view_2view_8hpp" ],
    [ "zip.hpp", "zip_8hpp.html", "zip_8hpp" ],
    [ "zip_with.hpp", "zip__with_8hpp.html", "zip__with_8hpp" ]
];