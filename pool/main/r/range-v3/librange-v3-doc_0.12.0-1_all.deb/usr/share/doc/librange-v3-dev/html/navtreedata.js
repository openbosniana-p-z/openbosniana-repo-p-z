/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Range-v3", "index.html", [
    [ "User Manual", "index.html", [
      [ "Preface", "index.html#tutorial-preface", [
        [ "Installation", "index.html#tutorial-installation", null ],
        [ "License", "index.html#tutorial-license", null ],
        [ "Supported Compilers", "index.html#tutorial-compilers", null ]
      ] ],
      [ "Quick Start", "index.html#tutorial-quick-start", [
        [ "Views", "index.html#tutorial-views", null ],
        [ "View const-ness", "index.html#autotoc_md21", null ],
        [ "View validity", "index.html#autotoc_md22", null ],
        [ "List of range views", "index.html#autotoc_md23", null ],
        [ "Actions", "index.html#tutorial-actions", null ],
        [ "List of range actions", "index.html#autotoc_md25", null ],
        [ "Utilities", "index.html#tutorial-utilities", [
          [ "Create Custom Views with view_facade", "index.html#autotoc_md27", null ],
          [ "Create Custom Views with view_adaptor", "index.html#autotoc_md28", [
            [ "view_adaptor in details", "index.html#autotoc_md29", null ]
          ] ],
          [ "Create Custom Iterators with basic_iterator", "index.html#autotoc_md30", null ]
        ] ],
        [ "Concept Checking", "index.html#tutorial-concepts", null ],
        [ "Range-v3 and the Future", "index.html#tutorial-future", null ]
      ] ]
    ] ],
    [ "Examples", "md_examples.html", [
      [ "Examples: Algorithms", "md_examples.html#example-algorithms", [
        [ "Hello, Ranges!", "md_examples.html#example-hello", null ],
        [ "any_of, all_of, none_of", "md_examples.html#example-any-all-none", null ],
        [ "count", "md_examples.html#example-count", null ],
        [ "count_if", "md_examples.html#example-count_if", null ],
        [ "find, find_if, find_if_not on sequence containers", "md_examples.html#example-find", null ],
        [ "for_each on sequence containers", "md_examples.html#example-for_each-seq", null ],
        [ "for_each on associative containers", "md_examples.html#example-for_each-assoc", null ],
        [ "is_sorted", "md_examples.html#example-is_sorted", null ]
      ] ],
      [ "Examples: Views", "md_examples.html#example-views", [
        [ "Filter and transform", "md_examples.html#example-filter-transform", null ],
        [ "Generate ints and accumulate", "md_examples.html#example-accumulate-ints", null ],
        [ "Convert a range comprehension to a vector", "md_examples.html#example-comprehension-conversion", null ]
      ] ],
      [ "Examples: Actions", "md_examples.html#example-actions", [
        [ "Remove non-unique elements from a container", "md_examples.html#example-sort-unique", null ]
      ] ],
      [ "Examples: Putting it all together", "md_examples.html#example-gestalt", [
        [ "Calendar", "md_examples.html#example-calendar", null ]
      ] ]
    ] ],
    [ "Release Notes", "release_notes.html", [
      [ "Version 0.12.0 \"Dude, Where's My Bored Ape?\"", "release_notes.html#v0-12-0", null ],
      [ "Version 0.11.0 \"Thanks, ISO\"", "release_notes.html#v0-11-0", null ],
      [ "Version 0.10.0 \"To Err is Human\"", "release_notes.html#v0-10-0", null ],
      [ "Version 0.9.1", "release_notes.html#v0-9-1", null ],
      [ "Version 0.9.0 \"Std::ranger Things\"", "release_notes.html#v0-9-0", null ],
      [ "Version 0.5.0", "release_notes.html#v0-5-0", null ],
      [ "Version 0.4.0", "release_notes.html#v0-4-0", null ],
      [ "Version 0.3.7", "release_notes.html#v0-3-7", null ],
      [ "Version 0.3.6", "release_notes.html#v0-3-6", null ],
      [ "Version 0.3.5", "release_notes.html#v0-3-5", null ],
      [ "Version 0.3.0", "release_notes.html#v0-3-0", null ],
      [ "Version 0.2.6", "release_notes.html#v0-2-6", null ],
      [ "Version 0.2.5", "release_notes.html#v0-2-5", null ],
      [ "Version 0.2.4", "release_notes.html#v0-2-4", null ],
      [ "Version 0.2.3", "release_notes.html#v0-2-3", null ],
      [ "Version 0.2.2", "release_notes.html#v0-2-2", null ],
      [ "Version 0.2.1", "release_notes.html#v0-2-1", null ],
      [ "Version 0.2.0", "release_notes.html#v0-2-0", null ],
      [ "Version 0.1.1", "release_notes.html#v0-1-1", null ],
      [ "Version 0.1.0", "release_notes.html#v0-1-0", null ]
    ] ],
    [ "Modules", "modules.html", "modules" ],
    [ "Namespaces", "namespaces.html", [
      [ "Namespace List", "namespaces.html", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Variables", "namespacemembers_vars.html", null ],
        [ "Typedefs", "namespacemembers_type.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Functions", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", null ],
        [ "Related Functions", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"",
"classranges_1_1box.html#a4225e50791f568024587574134503558",
"concepts_2concepts_8hpp.html#aea95fe74c50fffe574aaaf2da8b6ea12",
"find__end_8hpp.html#ga90e857039e7aa09e5f2d64aafd348a39",
"group__group-algorithms.html#ga6f4a8e4966791fb26e3b0c101de61859",
"group__group-iterator-concepts.html#ga3510d8739fead8c352a576826c6de14c",
"group__group-range.html#ga6d53d562fe763bdd227d1b8808fc5f86",
"group__integral.html#ga027c44ee54cc9486f9ce656f7c197c2f",
"group__logical.html#gaef6022dae0f8ae9d30b3495287c734bb",
"linear__distribute_8hpp.html",
"meta_8hpp.html#gafdb706a104cdb0d6753839332767fbd8",
"range_2traits_8hpp.html#gaadc92259a1291051a8efee7ca01168ff",
"rotate__copy_8hpp.html#gaebb905dac3fee120cf77b39e821c277c",
"structranges_1_1advance__fn.html#a37c582e82cdc22bab04e8ac31e61603c",
"structranges_1_1drop__last__view_3_01Rng_00_01detail_1_1drop__last__view_1_1mode__sized_01_4.html#a820fe8d94b2840809508aa01e95372c9",
"structranges_1_1join__view_1_1cursor.html#abd517d1a79b5fc2e767cc197203fd9d2",
"structranges_1_1raw__storage__iterator.html#a3b057967bec4e27d035cfec70706baec",
"structranges_1_1view__adaptor.html#acdf4196ea0cdbef454d032f0b86924a9",
"structranges_1_1views_1_1remove__bind__fn.html#a567232e1c43acd7ce9c73f115906b08f",
"tail_8hpp.html#ab3bae2a7f849b2cec5928faa17f19778"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';