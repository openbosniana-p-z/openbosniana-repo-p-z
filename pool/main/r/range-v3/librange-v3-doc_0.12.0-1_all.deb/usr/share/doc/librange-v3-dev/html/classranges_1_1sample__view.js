var classranges_1_1sample__view =
[
    [ "sample_view", "classranges_1_1sample__view.html#a1743dfa21125ef4b6ac7b00f4c9c6ad3", null ],
    [ "sample_view", "classranges_1_1sample__view.html#ab60a7eef1bf38e2406fa9bc05ad3e90f", null ],
    [ "base", "classranges_1_1sample__view.html#a21c9a2e3135bb00614cdffb9bca6970c", null ]
];