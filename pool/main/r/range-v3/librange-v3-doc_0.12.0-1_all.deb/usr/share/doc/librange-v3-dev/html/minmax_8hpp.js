var minmax_8hpp =
[
    [ "minmax_result", "minmax_8hpp.html#ga33d3732bfda9763bacb492f678c49ac2", null ],
    [ "c", "minmax_8hpp.html#gac8202eb7162cdeeea12e2ea18548fe61", null ]
];