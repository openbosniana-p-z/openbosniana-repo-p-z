var action_2action_8hpp =
[
    [ "action_closure", "structranges_1_1actions_1_1action__closure.html", "structranges_1_1actions_1_1action__closure" ],
    [ "action_closure_base", "structranges_1_1actions_1_1action__closure__base.html", "structranges_1_1actions_1_1action__closure__base" ],
    [ "template", "action_2action_8hpp.html#gaea35f609be429a87d4c869aee762c96d", null ],
    [ "iinvocable_action_closure", "action_2action_8hpp.html#gaef95e1722c0341850d599f16f2d78312", null ],
    [ "make_action_closure", "action_2action_8hpp.html#gaeb264d48f731e75689136caf2f888e13", null ]
];