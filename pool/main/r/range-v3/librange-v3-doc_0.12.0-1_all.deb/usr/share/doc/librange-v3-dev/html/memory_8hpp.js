var memory_8hpp =
[
    [ "i", "memory_8hpp.html#gae0211e34bd4fc9c8cf6a677d18e4bb6e", null ],
    [ "make_raw_buffer", "memory_8hpp.html#ga210213dccfbcc10d705e41e2031cadf6", null ]
];