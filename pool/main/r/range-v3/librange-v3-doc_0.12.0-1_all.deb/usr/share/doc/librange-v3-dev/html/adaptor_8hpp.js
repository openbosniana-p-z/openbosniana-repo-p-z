var adaptor_8hpp =
[
    [ "adaptor_cursor_t", "adaptor_8hpp.html#ga29a0a92c0e6587bc661eb5c461a38dc0", null ],
    [ "adaptor_sentinel_t", "adaptor_8hpp.html#ga582a83feb3d32746f52a71327fef8087", null ]
];