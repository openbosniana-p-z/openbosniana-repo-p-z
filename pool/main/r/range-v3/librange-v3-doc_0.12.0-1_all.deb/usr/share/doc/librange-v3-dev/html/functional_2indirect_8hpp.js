var functional_2indirect_8hpp =
[
    [ "indirect", "functional_2indirect_8hpp.html#ga6e7ed9065de7725a8629932a5732a6e1", null ]
];