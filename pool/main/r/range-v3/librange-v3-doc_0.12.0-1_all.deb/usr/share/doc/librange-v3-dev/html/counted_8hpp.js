var counted_8hpp =
[
    [ "counted_fn", "structranges_1_1views_1_1counted__fn.html", "structranges_1_1views_1_1counted__fn" ],
    [ "cpp20_counted_fn", "structranges_1_1views_1_1cpp20__counted__fn.html", "structranges_1_1views_1_1cpp20__counted__fn" ],
    [ "counted", "counted_8hpp.html#aeefcbe1d257a46b59afe9d1a002b86da", null ],
    [ "enable_borrowed_range< counted_view< I > >", "counted_8hpp.html#gaa119064076070f9f09f681f70f84dcec", null ]
];