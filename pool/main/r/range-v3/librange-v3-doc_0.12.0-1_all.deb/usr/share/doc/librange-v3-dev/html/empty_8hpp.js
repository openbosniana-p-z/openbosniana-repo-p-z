var empty_8hpp =
[
    [ "CPP_TEMPLATE_AUX_0", "empty_8hpp.html#aca5928d32779e18170d4a1b5b2d947bb", null ],
    [ "empty", "empty_8hpp.html#ab84e05114c699c99bb506f5406d60622", null ],
    [ "enable_borrowed_range< empty_view< T > >", "empty_8hpp.html#ga4b174095721ea9bcbe95888a0896faa8", null ]
];