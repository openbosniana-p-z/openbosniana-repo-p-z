var count__if_8hpp =
[
    [ "c", "count__if_8hpp.html#ga857a6bdde57cfeb6f4ecd7303771a6f5", null ],
    [ "R", "count__if_8hpp.html#gaf0a621cd5e153a96fedf6dda47b764f7", null ]
];