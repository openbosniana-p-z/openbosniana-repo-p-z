# talktosc

Small rust crate to do OpenPGP operations on smartcards.

This is used in [Johnny Can Encrypt](https://johnnycanencrypt.readthedocs.io/en/latest/) project.

## How to test?

```
cargo test --lib
```


## API Documentation

You can read the documentation at [docs.rs](https://docs.rs/talktosc/latest/talktosc/).

