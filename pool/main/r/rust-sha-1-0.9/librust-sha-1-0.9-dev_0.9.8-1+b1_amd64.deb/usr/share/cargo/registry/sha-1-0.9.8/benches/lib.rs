#![no_std]
#![feature(test)]

digest::bench!(sha1::Sha1);
