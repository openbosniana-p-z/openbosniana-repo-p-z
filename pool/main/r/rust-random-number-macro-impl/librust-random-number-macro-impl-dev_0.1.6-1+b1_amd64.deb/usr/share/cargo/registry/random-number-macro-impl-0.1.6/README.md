Random Number Macro Impl
====================

[![CI](https://github.com/magiclen/random-number/actions/workflows/ci.yml/badge.svg)](https://github.com/magiclen/random-number/actions/workflows/ci.yml)

See [`random-number`](https://crates.io/crates/random-number). 

## Crates.io

https://crates.io/crates/random-number

## Documentation

https://docs.rs/random-number

## License

[MIT](LICENSE)
