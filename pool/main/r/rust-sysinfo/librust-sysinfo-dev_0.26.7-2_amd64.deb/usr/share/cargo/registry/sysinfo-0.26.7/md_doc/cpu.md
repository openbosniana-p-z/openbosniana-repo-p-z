Struct containing information of a CPU.
