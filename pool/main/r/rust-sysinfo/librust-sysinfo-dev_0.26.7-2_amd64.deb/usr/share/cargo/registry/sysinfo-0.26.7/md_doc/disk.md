Struct containing a disk information.
