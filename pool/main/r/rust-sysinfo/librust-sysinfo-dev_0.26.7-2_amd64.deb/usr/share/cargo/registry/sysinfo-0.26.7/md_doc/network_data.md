Contains network interface information.
