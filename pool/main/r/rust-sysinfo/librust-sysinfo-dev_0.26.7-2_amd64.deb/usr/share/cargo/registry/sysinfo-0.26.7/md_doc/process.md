Struct containing information of a process.

## iOS

This information cannot be retrieved on iOS due to sandboxing.

## Apple app store

If you are building a macOS Apple app store, it won't be able
to retrieve this information.
