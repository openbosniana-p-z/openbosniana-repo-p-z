extern crate markdown;
#[macro_use(assert_diff)]
extern crate difference;

mod fixtures;
