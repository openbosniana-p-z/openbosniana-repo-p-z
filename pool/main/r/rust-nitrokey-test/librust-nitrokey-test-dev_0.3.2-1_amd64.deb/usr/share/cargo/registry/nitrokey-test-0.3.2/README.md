[![pipeline](https://gitlab.com/d-e-s-o/nitrokey-test/badges/master/pipeline.svg)](https://gitlab.com/d-e-s-o/nitrokey-test/commits/master)
[![crates.io](https://img.shields.io/crates/v/nitrokey-test.svg)](https://crates.io/crates/nitrokey-test)
[![Docs](https://docs.rs/nitrokey-test/badge.svg)](https://docs.rs/nitrokey-test)
[![rustc](https://img.shields.io/badge/rustc-1.31+-blue.svg)](https://blog.rust-lang.org/2018/12/06/Rust-1.31-and-rust-2018.html)
[![license](https://img.shields.io/github/license/d-e-s-o/nitrokey-test.svg)](https://github.com/d-e-s-o/nitrokey-test/blob/master/LICENSE)

nitrokey-test
=============

- [Documentation][docs-rs]
- [Changelog](https://github.com/d-e-s-o/nitrokey-test/blob/master/CHANGELOG.md)

**nitrokey-test** is a crate providing more convenient testing
capabilities for the [nitrokey][nitrokey] crate and projects building on
top of it.

[docs-rs]: https://docs.rs/crate/nitrokey-test
[nitrokey]: https://crates.io/crates/nitrokey
