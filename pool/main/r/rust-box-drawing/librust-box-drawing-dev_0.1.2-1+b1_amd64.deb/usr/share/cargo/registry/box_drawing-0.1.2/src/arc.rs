pub const DOWN_RIGHT:&str = "╭";
pub const DOWN_LEFT:&str = "╮";
pub const UP_LEFT:&str = "╯";
pub const UP_RIGHT:&str = "╰";