# `mach_o_sys`

![Build Status](https://travis-ci.org/fitzgen/mach_o_sys.svg?branch=master)

Rust bindings to the OSX mach-o system library (`/usr/include/mach-o/**.h`).
