# Changelog

## v1.0.0
### Added
  - Added a `try_array_init` function which initializes an array with a callable that may fail.
  - Added a `const-generics` feature which uses rust (unstable) `const-generics` feature to implement the initializer functions for all array sizes.
  - Added documentation