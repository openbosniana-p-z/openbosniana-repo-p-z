changelog
=========

## 0.2
Support for all Dockerfile instructions have been added.

### 0.2.1
An update to the crate's docs.

## 0.1
The initial release.

### 0.1.1
An update to the crate's docs.
