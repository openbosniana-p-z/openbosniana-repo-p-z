use interpolate_name::interpolate_name;

#[interpolate_name(one)]
fn t() {

}

fn main() {
    t_one();
}
