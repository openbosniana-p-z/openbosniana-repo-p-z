ASCII canvas is a simple library that allows you to draw lines and
colored text and then write them to the terminal. It uses the `term`
library to handle the ANSI nonsense and hence it works on Windows,
Mac, and Unix.

See [the documentation](https://docs.rs/ascii-canvas/) for more information.

ASCII canvas was originally part of the [LALRPOP parser generator](https://github.com/nikomatsakis/lalrpop).
