## v1.0.1 - March 18, 2019
- Add `LICENSE` file (#3)[https://github.com/TedDriggs/ident_case/issues/3]