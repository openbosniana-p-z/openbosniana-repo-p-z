fontconfig-sys
==============

Raw bindings to [freedesktop.org's Fontconfig library][fontconfig]. Used by the [fontconfig][fontconfig-rs] crate.

[fontconfig]: https://www.freedesktop.org/wiki/Software/fontconfig/
[fontconfig-rs]: https://crates.io/crates/fontconfig
