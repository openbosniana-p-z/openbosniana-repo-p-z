
This example displays a few compilation regexes.

To demonstrate compile time checks

- uncomment line 24
- run `cargo run`

The program should fail to check with a clear error.
