fn unpack() -> {
    unpack_lo_epi8();
    unpack_hi_epi8();
}



pub fn over() {
    alpha = expand_alpha(src)
    dst = unpack(dst);
    dst = multiply(dst, alpha);
    dst = pack(dst);
    _mm_add_epi32(src, dst);
}


