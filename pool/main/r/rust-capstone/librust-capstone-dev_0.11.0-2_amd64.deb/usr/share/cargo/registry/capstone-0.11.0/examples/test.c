#include <stdio.h>
int main(void) {
    int c = 42;
    c = c * c + 42;
    printf("Having done stuff, c is now %d\n", c);
}
