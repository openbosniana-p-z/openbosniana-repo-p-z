#![cfg(all(feature = "with-system-locale", unix))]

use std::cmp::Ordering;
use std::env;

use num_format::SystemLocale;

#[test]
fn test_unix() {
    let set = SystemLocale::available_names().unwrap();
    let mut vec = set.iter().map(|s| s.to_string()).collect::<Vec<String>>();
    vec.sort_by(|_, _| {
        if rand::random() {
            Ordering::Greater
        } else {
            Ordering::Less
        }
    });
    assert!(!vec.is_empty());
    for name in &vec {
        println!("{}", name);
        let locale1 = SystemLocale::from_name(name.to_string());
        env::set_var("LC_ALL", name);
        let locale2 = SystemLocale::default();
        assert_eq!(locale1, locale2);
        match name.as_ref() {
            "kk_KZ.rk1048" | "lzh_TW" | "zh_TW.euctw" | "unm_US" | "cmn_TW" | "nan_TW" | "hak_TW" | "ka_GE" | "tg_TJ" => {}, //locales that are known to be unsupported, either due to unsupported encodings or unsupported digit groupings.
            _ => {locale1.unwrap();}, //most locales should be parsed successfully.
        }
    }
}
