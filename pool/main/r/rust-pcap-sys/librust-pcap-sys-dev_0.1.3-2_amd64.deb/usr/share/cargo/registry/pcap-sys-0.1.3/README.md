# pcap-sys
Low-level bindings to libpcap

[![*nix build status](https://travis-ci.org/jmmk/rustcap.svg?branch=master)](https://travis-ci.org/jmmk/rustcap)
[![Windows build status](https://ci.appveyor.com/api/projects/status/6rf0ygpcww6fegt2/branch/master?svg=true)](https://ci.appveyor.com/project/jmmk/rustcap/branch/master)
[![](http://meritbadge.herokuapp.com/pcap-sys)](https://crates.io/crates/pcap-sys)
