![Rust](https://github.com/Byron/treediff-rs/workflows/Rust/badge.svg)
[![crates.io version](https://img.shields.io/crates/v/treediff.svg)](https://crates.io/crates/treediff)

A library to compare arbitrary structured data of the same type, efficiently.

Please see the [documentation](https://docs.rs/treediff/*) for more details.

# Usage

Add this to your Cargo.toml
```toml
[dependencies]
treediff = "4"
```
