# 0.2.1 (May 08, 2018)

- Fix incorrect color highlighting (thanks [Erich Gubler](https://github.com/ErichDonGubler)!)

# 0.2.0 (August 19, 2017)

- Support coloring subranges (thanks [m4b](https://github.com/m4b)!)

# 0.1.16 (May 08, 2017)

- Use dot (`.`) as the fallback character
- Make the replacement character configurable
- Improve documentation

# 0.1.15 (May 03, 2017)

- Add ASCII codepage
- Use rust's REPLACEMENT_CHARACTER as fallback character
- Add small example

# 0.1.14 (March 03, 2017)

- Fix representation of 0x20 (space) in code page 850

# 0.1.13 (March 03, 2017)

- Initial version
