# Change Log

## v0.4.3 - 2022-09-07

### Added

* Added support for parameterized structs.

## v0.4.2 - 2022-04-30

### Added

* Added support for transparent wrapper types.

## v0.4.1 - 2021-11-23

### Fixed

* Fixed handling of struct fields using raw identifiers.

## v0.4.0 - 2019-12-23

No changes

## v0.4.0-alpha.1 - 2019-10-14

* Initial release
