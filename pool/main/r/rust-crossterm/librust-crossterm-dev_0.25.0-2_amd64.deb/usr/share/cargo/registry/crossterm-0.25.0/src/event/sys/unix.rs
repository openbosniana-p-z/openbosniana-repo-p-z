#[cfg(feature = "event-stream")]
pub(crate) mod waker;

pub(crate) mod file_descriptor;
pub(crate) mod parse;
