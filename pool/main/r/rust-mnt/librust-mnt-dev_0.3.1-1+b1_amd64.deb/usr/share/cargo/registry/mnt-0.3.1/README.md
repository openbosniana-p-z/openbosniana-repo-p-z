# mnt-rs

*mnt* is a library to parse fstab-like files.
It allows to list mount points thanks to */proc/mounts*.

This library is a work in progress.
The API may change.
