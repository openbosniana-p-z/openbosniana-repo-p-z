# enum-map-derive

This is a derive macro for `enum-map`. You don't need to specify it
in dependencies as `enum-map` crate re-exports it.
