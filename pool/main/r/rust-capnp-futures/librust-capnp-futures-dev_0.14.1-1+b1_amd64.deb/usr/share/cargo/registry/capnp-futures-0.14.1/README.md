[![crates.io](http://meritbadge.herokuapp.com/capnp-futures)](https://crates.io/crates/capnp-futures)

[documentation](https://docs.capnproto-rust.org/capnp_futures/)

Asynchronous reading and writing of Cap'n Proto messages in Rust.