#![allow(dead_code)]
include!(concat!(env!("OUT_DIR"), "/pocket-resources.rs"));
