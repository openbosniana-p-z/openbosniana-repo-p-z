# magnet-uri
A library for parsing Magnet URI scheme
