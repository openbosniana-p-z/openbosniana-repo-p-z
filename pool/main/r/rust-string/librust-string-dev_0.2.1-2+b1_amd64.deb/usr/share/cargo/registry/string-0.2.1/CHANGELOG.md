# 0.2.1 (June 27, 2019)

### Fixed
- Stack overflow on `PartialEq` (#15).

# 0.2.0 (March 6, 2019)

### Changed
- Require byte store to implement `StableAsRef` (#10).

# 0.1.3 (January 10, 2019)

* Implement `Borrow`.
* Implement `PartialEq<str>`.

# 0.1.2 (November 21, 2018)

* Implement `DerefMut` and `Display` (#5).
* Implement `from_str` (#7).

# 0.1.1 (July 13, 2018)

* Fix doc gen (#2).

# 0.1.0 (January 11, 2018)

* Initial release.
