This is a slightly larger example, showing an implementation of Minesweeper.

*This is a work in progress; many features are not implemented yet.*
