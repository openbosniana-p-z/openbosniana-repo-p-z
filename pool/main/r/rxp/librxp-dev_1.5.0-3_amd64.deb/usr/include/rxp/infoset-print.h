void infoset_print(FILE16 *f, Parser p, XBit *bits, int nbits);
