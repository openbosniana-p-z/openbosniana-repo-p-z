# unix-socket

[![Build Status](https://travis-ci.org/rust-lang-nursery/unix-socket.svg?branch=master)](https://travis-ci.org/rust-lang-nursery/unix-socket) [![Latest Version](https://img.shields.io/crates/v/unix_socket.svg)](https://crates.io/crates/unix_socket)

Support for Unix domain socket clients and servers.

[Documentation](https://doc.rust-lang.org/unix-socket/doc/v0.4.6/unix_socket)
