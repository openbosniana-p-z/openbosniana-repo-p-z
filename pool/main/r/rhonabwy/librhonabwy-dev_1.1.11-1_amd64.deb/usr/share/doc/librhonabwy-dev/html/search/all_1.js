var searchData=
[
  ['aad_0',['aad',['../structjwe__t.html#acb007ce9ae718d9c4df42b8e8b32e77d',1,'jwe_t']]],
  ['aad_5fb64url_1',['aad_b64url',['../structjwe__t.html#a715ebef9d7aea218accc33da0f7d052a',1,'jwe_t']]],
  ['aad_5flen_2',['aad_len',['../structjwe__t.html#a77335324f7bc3a1aeef1667a6344112a',1,'jwe_t']]],
  ['alg_3',['alg',['../structjws__t.html#addfb16359336c010ca9d4f36444fce57',1,'jws_t::alg()'],['../structjwe__t.html#aac787ef5c8446863d21e979b7ea1123d',1,'jwe_t::alg()']]],
  ['api_2emd_4',['API.md',['../API_8md.html',1,'']]],
  ['auth_5ftag_5fb64url_5',['auth_tag_b64url',['../structjwe__t.html#a5f6e5835a8071e8205c728682f5b8837',1,'jwe_t']]]
];
