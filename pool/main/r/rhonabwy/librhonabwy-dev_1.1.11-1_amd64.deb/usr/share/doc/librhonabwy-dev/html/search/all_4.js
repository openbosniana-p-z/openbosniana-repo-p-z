var searchData=
[
  ['header_5fb64url_0',['header_b64url',['../structjws__t.html#ae0b068cd8a81e610eec5af23bf6e4dbd',1,'jws_t::header_b64url()'],['../structjwe__t.html#a8d4f5bf0ff9cab44b70c08b4ef88feae',1,'jwe_t::header_b64url()']]]
];
