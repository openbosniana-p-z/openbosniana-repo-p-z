var searchData=
[
  ['jwa_5falg_0',['jwa_alg',['../group__type.html#gaaf028013558b5ff9aa99ff4afc3ae2ea',1,'rhonabwy.h']]],
  ['jwa_5fenc_1',['jwa_enc',['../group__type.html#ga34a92d88d5befd0170a6b82ec53ef020',1,'rhonabwy.h']]]
];
