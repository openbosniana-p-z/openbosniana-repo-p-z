var searchData=
[
  ['enc_0',['enc',['../structjwe__t.html#a4c0da7817f6db262447fdde5911a857c',1,'jwe_t::enc()'],['../structjwt__t.html#a2d44a72ed387900c530c08950b49274c',1,'jwt_t::enc()']]],
  ['enc_5falg_1',['enc_alg',['../structjwt__t.html#a00873f85d3bf8c420e88fd754794fd80',1,'jwt_t']]],
  ['encrypted_5fkey_5fb64url_2',['encrypted_key_b64url',['../structjwe__t.html#af2df02ad3f8dd5e6a24d86cec1691058',1,'jwe_t']]]
];
