var searchData=
[
  ['sign_5falg_0',['sign_alg',['../structjwt__t.html#a28733efd8a116454b1686b1bd2f356a1',1,'jwt_t']]],
  ['signature_5fb64url_1',['signature_b64url',['../structjws__t.html#ad6a94617ac34db385a48138dbdad11a3',1,'jws_t']]]
];
