var searchData=
[
  ['token_5fmode_0',['token_mode',['../structjws__t.html#a0fd0f1a0cf93a482e758c8d01f2e07bf',1,'jws_t::token_mode()'],['../structjwe__t.html#afaae3646c75ade9de4f13848bd397e37',1,'jwe_t::token_mode()']]],
  ['type_1',['type',['../structjwt__t.html#a5353ce81a47a91c842c6716e02857b07',1,'jwt_t']]]
];
