rust-timerfd
============

A rust interface to the Linux kernel's timerfd API.

[Documentation](https://docs.rs/timerfd)
[![Crates.io](https://img.shields.io/crates/v/timerfd.svg?maxAge=2592000)](https://crates.io/crates/timerfd)
