# lexiclean

Lexically clean rust paths.

See [the docs](https://docs.rs/lexiclean) for more information.
