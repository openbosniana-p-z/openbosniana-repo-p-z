#include <stdio.h>
int helloWorld(){
    printf("HelloWorld, %d\n", 1);
    return 0;
}
int main(){
    helloWorld();
    printf("HelloWorld, %d\n", 1);
    return 0;
}
