pub const kPointsPerInch: ::std::os::raw::c_int = 72;
pub const kMinCredibleResolution: ::std::os::raw::c_int = 70;
pub const kMaxCredibleResolution: ::std::os::raw::c_int = 2400;
pub const kResolutionEstimationFactor: ::std::os::raw::c_int = 10;
