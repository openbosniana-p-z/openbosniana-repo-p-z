This is an internal implementation crate for `unic-langid`. Please use `unic-langid`.
