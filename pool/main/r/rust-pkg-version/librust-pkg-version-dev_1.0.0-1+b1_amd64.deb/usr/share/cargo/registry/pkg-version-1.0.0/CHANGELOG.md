# Changelog

## Unreleased

No changes.

## 1.0.0 - 2019-11-22

No changes.

## 0.1.1 - 2019-09-04

The crate now supports `#![no_std]` environments.

## 0.1.0 - 2019-05-03

Initial release.
