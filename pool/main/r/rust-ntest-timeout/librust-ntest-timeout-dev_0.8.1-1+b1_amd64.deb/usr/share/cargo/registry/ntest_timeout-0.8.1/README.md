# NTest Timeout

Part of the [NTest library](https://crates.io/crates/ntest). Add the timeout attribute to the rust test framework using 
[procedural macros](https://doc.rust-lang.org/reference/procedural-macros.html).
