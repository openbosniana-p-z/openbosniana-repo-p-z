git clone https://github.com/rurban/smhasher.git
