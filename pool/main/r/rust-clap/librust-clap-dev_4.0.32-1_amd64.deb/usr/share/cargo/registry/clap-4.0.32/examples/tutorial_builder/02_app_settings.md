```console
$ 02_app_settings --help
A simple to use, efficient, and full-featured Command Line Argument Parser

Usage: 02_app_settings[EXE] --two <VALUE> --one <VALUE>

Options:
      --two <VALUE>
          
      --one <VALUE>
          
  -h, --help
          Print help information
  -V, --version
          Print version information

```
