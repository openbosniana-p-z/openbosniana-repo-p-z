#[macro_use]
extern crate quickcheck;

extern crate crdts;

mod glist;
mod list;
mod map;
mod merkle_reg;
mod mvreg;
mod orswot;
mod vclock;
