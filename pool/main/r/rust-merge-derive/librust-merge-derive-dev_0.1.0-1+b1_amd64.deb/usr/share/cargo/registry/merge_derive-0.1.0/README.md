<!---
Copyright (C) 2020 Robin Krahl <robin.krahl@ireas.org>
SPDX-License-Identifier: CC0-1.0
-->

# merge-derive-rs

This crate provides a derive macro for the `merge::Merge` crate.  See the
[`merge`][] crate for more information.

[`merge`]: https://lib.rs/crates/merge
