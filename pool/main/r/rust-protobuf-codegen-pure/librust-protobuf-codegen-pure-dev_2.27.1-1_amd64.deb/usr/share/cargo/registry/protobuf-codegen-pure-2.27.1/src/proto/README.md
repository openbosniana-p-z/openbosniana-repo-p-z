This folder contains copy of .proto files
needed for pure codegen.

Files are copied here because when publishing to crates,
referencing files from outside is not allowed.
