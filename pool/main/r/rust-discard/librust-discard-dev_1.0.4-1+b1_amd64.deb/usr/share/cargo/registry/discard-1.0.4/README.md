Discard trait which allows for intentionally leaking memory.

See [the documentation](https://docs.rs/discard/*/discard/) for more details.
