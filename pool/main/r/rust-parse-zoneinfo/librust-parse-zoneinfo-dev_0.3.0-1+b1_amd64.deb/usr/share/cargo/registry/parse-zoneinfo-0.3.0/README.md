# parse-zoneinfo

Parse-zoneinfo is a fork of [`zoneinfo_parse`][zoneinfo_parse], with adjustments such that it no longer depends on the `Datetime` crate. It is used by [`chrono-tz`][chrono_tz].

[zoneinfo_parse]: https://github.com/rust-datetime/zoneinfo-parse
[chrono_tz]: https://github.com/djzin/chrono-tz
