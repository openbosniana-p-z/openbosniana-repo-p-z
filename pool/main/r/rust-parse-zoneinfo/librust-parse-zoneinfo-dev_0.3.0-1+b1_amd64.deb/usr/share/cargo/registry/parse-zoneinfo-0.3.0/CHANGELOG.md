Changes to parse-zoneinfo
=========================

# 0.3.0

- Support overflowing month behavior for >= and <= day in month

# 0.2.1

- Build faster by relying on fewer regex features (PR #6 by @bluetech)
