Credits
=======

The ``xml5lib`` test data is maintained by:

- Daniel Fath

Contributors
------------
