# wayland-protocols members

- EFL/Enlightenment: Mike Blumenkrantz <michael.blumenkrantz@gmail.com>
- GTK/Mutter: Jonas Ådahl <jadahl@gmail.com>,
  Carlos Garnacho <carlosg@gnome.org>
- KWin: Eike Hein <hein@kde.org>,
  David Edmundson <david@davidedmundson.co.uk>
- Mir: Christopher James Halse Rogers <raof@ubuntu.com>,
  Alan Griffiths <alan.griffiths@canonical.com>
- Qt: Eskil Abrahamsen Blomfeldt <eskil.abrahamsen-blomfeldt@qt.io>
- Weston: Pekka Paalanen <pekka.paalanen@collabora.com>,
  Daniel Stone <daniel@fooishbar.org>
- wlroots/Sway: Drew DeVault <sir@cmpwn.com>, Simon Ser <contact@emersion.fr>
