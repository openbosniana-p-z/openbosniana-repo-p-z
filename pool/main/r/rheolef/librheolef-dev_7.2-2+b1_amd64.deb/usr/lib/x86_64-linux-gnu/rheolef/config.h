/* config/acconfig.h.  Generated from acconfig.h.in by configure.  */
/* config/acconfig.h.in.  Generated from configure.ac by autoheader.  */

/* Defines the absolute top source directory during compilation - used by
   non-regression tests */
#define _RHEOLEF_ABS_TOP_SRCDIR "/build/rheolef-kEovKU/rheolef-7.2"

/* Define to 1 if using 'alloca.c'. */
/* #undef _RHEOLEF_C_ALLOCA */

/* Define the arbitrary precision */
/* #undef _RHEOLEF_DIGITS10 */

/* Defines if you have abs(double) */
#define _RHEOLEF_HAVE_ABS_DOUBLE 1

/* Define to 1 if you have 'alloca', as a function or macro. */
#define _RHEOLEF_HAVE_ALLOCA 1

/* Define to 1 if <alloca.h> works. */
#define _RHEOLEF_HAVE_ALLOCA_H 1

/* Defines if you have the basic linea algebra subroutines libraries */
#define _RHEOLEF_HAVE_BLAS 1

/* Defines if you have the basic linea algebra subroutines libraries */
#define _RHEOLEF_HAVE_BOOST 1

/* Define to 1 if you have the <boost/mpi.hpp> header file. */
#define _RHEOLEF_HAVE_BOOST_MPI_HPP 1

/* Defines if you have BSDgettimeofday(timeval*, timezone*) in <sys/time.h> */
/* #undef _RHEOLEF_HAVE_BSDGETTIMEOFDAY */

/* Defines if you have the CGAL library */
#define _RHEOLEF_HAVE_CGAL 1

/* Defines if you have cholmod library */
#define _RHEOLEF_HAVE_CHOLMOD 1

/* Defines if you have CLANG C++ compiler */
/* #undef _RHEOLEF_HAVE_CLANG_CXX */

/* Defines if you have cln library */
/* #undef _RHEOLEF_HAVE_CLN */

/* Define to 1 if your system has the clock_gettime function. */
#define _RHEOLEF_HAVE_CLOCK_GETTIME 1

/* Defines if you have a 2011 compilant c++ compiler */
/* #undef _RHEOLEF_HAVE_CXX_STD_2011 */

/* Defines if you have a 2014 compilant c++ compiler */
/* #undef _RHEOLEF_HAVE_CXX_STD_2014 */

/* Defines if you have a 2017 compilant c++ compiler */
#define _RHEOLEF_HAVE_CXX_STD_2017 1

/* Define to 1 if you have the <dlfcn.h> header file. */
#define _RHEOLEF_HAVE_DLFCN_H 1

/* Defines if you use dmalloc library */
/* #undef _RHEOLEF_HAVE_DMALLOC */

/* Defines if you have eigen library */
#define _RHEOLEF_HAVE_EIGEN 1

/* Defines if you have finite(double) in <fstream.h> */
/* #undef _RHEOLEF_HAVE_FINITE_DOUBLE */

/* Define when using the boost multiprecision with float128 GNU quadmath */
/* #undef _RHEOLEF_HAVE_FLOAT128 */

/* Defines if you have gettimeofday(timeval*, timezone*) in <sys/time.h> */
#define _RHEOLEF_HAVE_GETTIMEOFDAY 1

/* Defines if you have ginac library */
/* #undef _RHEOLEF_HAVE_GINAC */

/* Defines if you have INTEL C++ compiler */
/* #undef _RHEOLEF_HAVE_INTEL_CXX */

/* Define to 1 if you have the <inttypes.h> header file. */
#define _RHEOLEF_HAVE_INTTYPES_H 1

/* Defines if you have ios::bitalloc() in <iostream> */
/* #undef _RHEOLEF_HAVE_IOS_BITALLOC */

/* Defines if you have ios::bp in <iostream> */
/* #undef _RHEOLEF_HAVE_IOS_BP */

/* Defines if you have ios::setstate(long) in <iostream> */
/* #undef _RHEOLEF_HAVE_IOS_SETSTATE */

/* Defines if you have isinf(double) in <math.h> */
#define _RHEOLEF_HAVE_ISINF_DOUBLE 1

/* Defines if you have iostream::rdbuf(void*) in <iostream> */
/* #undef _RHEOLEF_HAVE_ISTREAM_RDBUF */

/* Define to 1 if you use long double as default float type */
/* #undef _RHEOLEF_HAVE_LONG_DOUBLE */

/* Define to 1 if the system has the type `long long int'. */
#define _RHEOLEF_HAVE_LONG_LONG_INT 1

/* Defines if you have the METIS library */
/* #undef _RHEOLEF_HAVE_METIS */

/* Defines if you have distributed environment */
#define _RHEOLEF_HAVE_MPI 1

/* Define to 1 if you have the <mpi.h> header file. */
#define _RHEOLEF_HAVE_MPI_H 1

/* Defines if you have the mumps distributed direct solver libraries */
#define _RHEOLEF_HAVE_MUMPS 1

/* Defines if you have mumps with metis support */
#define _RHEOLEF_HAVE_MUMPS_WITH_METIS 1

/* Defines if you have mumps with parmetis support */
/* #undef _RHEOLEF_HAVE_MUMPS_WITH_PARMETIS */

/* Defines if you have mumps with ptscotch support */
#define _RHEOLEF_HAVE_MUMPS_WITH_PTSCOTCH 1

/* Defines if you have mumps with scotch support */
#define _RHEOLEF_HAVE_MUMPS_WITH_SCOTCH 1

/* Defines if you have parmetis mesh partitioner libraries */
/* #undef _RHEOLEF_HAVE_PARMETIS */

/* Defines if you have the scalable linea algebra subroutines libraries */
#define _RHEOLEF_HAVE_SCALAPACK 1

/* Defines if you have the scotch distributed mesh partitioner libraries */
#define _RHEOLEF_HAVE_SCOTCH 1

/* Defines if you have sqr(double) in <math.h> */
/* #undef _RHEOLEF_HAVE_SQR_DOUBLE */

/* Define to 1 if you have the <stdint.h> header file. */
#define _RHEOLEF_HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define _RHEOLEF_HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define _RHEOLEF_HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define _RHEOLEF_HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define _RHEOLEF_HAVE_STRING_H 1

/* Defines if you have the amd suitesparse ordering library */
#define _RHEOLEF_HAVE_SUITESPARSE_AMD 1

/* Define to 1 if you have the <suitesparse/amd.h> header file. */
#define _RHEOLEF_HAVE_SUITESPARSE_AMD_H 1

/* Define to 1 if you have the <symlink.h> header file. */
/* #undef _RHEOLEF_HAVE_SYMLINK_H */

/* Define to 1 if you have the <sys/stat.h> header file. */
#define _RHEOLEF_HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define _RHEOLEF_HAVE_SYS_TYPES_H 1

/* Defines if you have the trilinos distributed direct solver libraries */
/* #undef _RHEOLEF_HAVE_TRILINOS */

/* Defines if you have umfpack library */
#define _RHEOLEF_HAVE_UMFPACK 1

/* Define to 1 if you have the <unistd.h> header file. */
#define _RHEOLEF_HAVE_UNISTD_H 1

/* Define to 1 if the system has the type `unsigned long long int'. */
#define _RHEOLEF_HAVE_UNSIGNED_LONG_LONG_INT 1

/* Defines if you have solaris gettimeofday(timeval*) in <sys/time.h>"" */
/* #undef _RHEOLEF_HAVE_WIERDGETTIMEOFDAY */

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#define _RHEOLEF_LT_OBJDIR ".libs/"

/* Defines the package major version */
#define _RHEOLEF_MAJOR_VERSION 7

/* Defines the package minor version */
#define _RHEOLEF_MINOR_VERSION 2

/* Defines mumps version major */
#define _RHEOLEF_MUMPS_VERSION_MAJOR 5

/* Defines mumps version minor */
#define _RHEOLEF_MUMPS_VERSION_MINOR 5

/* Name of package */
#define _RHEOLEF_PACKAGE "rheolef"

/* Define to the address where bug reports for this package should be sent. */
#define _RHEOLEF_PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define _RHEOLEF_PACKAGE_NAME "rheolef"

/* Define to the full name and version of this package. */
#define _RHEOLEF_PACKAGE_STRING "rheolef 7.2"

/* Define to the one symbol short name of this package. */
#define _RHEOLEF_PACKAGE_TARNAME "rheolef"

/* Define to the home page for this package. */
#define _RHEOLEF_PACKAGE_URL ""

/* Define to the version of this package. */
#define _RHEOLEF_PACKAGE_VERSION "7.2"

/* Defines it if you are parano for debug */
/* #undef _RHEOLEF_PARANO */

/* Defines the paraview major version */
#define _RHEOLEF_PARAVIEW_VERSION_MAJOR 5

/* Defines the paraview minor version */
#define _RHEOLEF_PARAVIEW_VERSION_MINOR 7

/* Defines the package data directory */
#define _RHEOLEF_PKGDATADIR "/usr/share/rheolef"

/* Defines the object code libraries directory */
#define _RHEOLEF_RHEOLEF_LIBDIR "/usr/lib/x86_64-linux-gnu"

/* If using the C implementation of alloca, define if you know the
   direction of stack growth for your system; otherwise it will be
   automatically deduced at runtime.
	STACK_DIRECTION > 0 => grows toward higher addresses
	STACK_DIRECTION < 0 => grows toward lower addresses
	STACK_DIRECTION = 0 => direction of growth unknown */
/* #undef _RHEOLEF_STACK_DIRECTION */

/* Define to 1 if all of the C90 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define _RHEOLEF_STDC_HEADERS 1

/* Version number of package */
#define _RHEOLEF_VERSION "7.2"

/* Define to `unsigned int' if <sys/types.h> does not define. */
/* #undef _RHEOLEF_size_t */
