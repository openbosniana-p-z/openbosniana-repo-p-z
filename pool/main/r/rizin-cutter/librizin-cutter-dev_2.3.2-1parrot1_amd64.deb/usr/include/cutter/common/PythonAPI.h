#ifndef PYTHONAPI_H
#define PYTHONAPI_H

#define Py_LIMITED_API 0x03050000
#include <Python.h>

PyObject *PyInit_api();

#endif // PYTHONAPI_H
