# `atlatl`

## 0.1.2

### Dependencies

- `lazy_static` → 1.1
- `num-traits` → 0.2
- `quickcheck` → 0.7
- `rand` → 0.5


## 0.1.1

### Changes
- The `serialization` feature has been renamed to `serde`, in accordance with the [Rust API guidelines](https://github.com/rust-lang-nursery/api-guidelines).


## 0.1.0

Initial release.
