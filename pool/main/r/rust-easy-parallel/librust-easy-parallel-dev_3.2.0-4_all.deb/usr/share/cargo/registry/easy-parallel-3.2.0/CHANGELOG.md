# Version 3.2.0

- Remove `T: Default` bound from `Default` impl.

# Version 3.1.0

- Add `Parallel::finish()`.

# Version 3.0.0

- Collect results in the same order closures were added.

# Version 2.2.0

- Remove `PhantomData` making `'a` invariant.

# Version 2.1.0

- Run one of the closures on the main thread.

# Version 2.0.0

- `Parallel::run()` now collects results.

# Version 1.0.1

- Remove unused `mut`.

# Version 1.0.0

- Initial version
