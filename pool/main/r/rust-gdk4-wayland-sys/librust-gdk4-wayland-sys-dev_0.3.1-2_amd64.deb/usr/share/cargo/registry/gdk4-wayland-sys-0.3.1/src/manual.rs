// Take a look at the license at the top of the repository in the LICENSE file.

#[cfg(any(feature = "v4_4", feature = "dox"))]
pub use xkbcommon_sys::xkb_keymap;
