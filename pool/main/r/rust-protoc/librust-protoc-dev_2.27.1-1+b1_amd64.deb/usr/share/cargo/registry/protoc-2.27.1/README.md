<!-- cargo-sync-readme start -->

# API to invoke `protoc` command programmatically

API to invoke `protoc` command using API (e. g. from `build.rs`).

Note that to generate `rust` code from `.proto`,
[protoc-rust](https://docs.rs/protoc-rust) crate can be used,
which does not require `protoc-gen-rust` present in `$PATH`.

<!-- cargo-sync-readme end -->
