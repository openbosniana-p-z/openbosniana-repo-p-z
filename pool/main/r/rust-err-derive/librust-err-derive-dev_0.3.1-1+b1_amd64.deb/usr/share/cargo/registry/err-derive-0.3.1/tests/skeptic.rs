#[cfg(feature = "skeptic")]
include!(concat!(env!("OUT_DIR"), "/skeptic-tests.rs"));
