<!-- file socket.rs -->
<!-- trait IntoRawFd -->
This is stub for doc generation
[Actual docs](https://doc.rust-lang.org/std/os/unix/io/trait.IntoRawFd.html)
<!-- trait FromRawFd -->
This is stub for doc generation
[Actual docs](https://doc.rust-lang.org/std/os/unix/io/trait.FromRawFd.html)
<!-- trait IntoRawSocket -->
This is stub for doc generation
[Actual docs](https://doc.rust-lang.org/std/os/windows/io/trait.IntoRawSocket.html)
<!-- trait FromRawSocket -->
This is stub for doc generation
[Actual docs](https://doc.rust-lang.org/std/os/windows/io/trait.FromRawSocket.html)
