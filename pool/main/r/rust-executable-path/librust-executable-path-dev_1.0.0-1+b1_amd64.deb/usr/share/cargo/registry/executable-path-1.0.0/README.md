rust-executable-path
====================

This library provides a single function, `executable_path`, which takes the name of a binary target and returns the path to the target's executable.

It is useful for integration tests where you wish to invoke an executable.
