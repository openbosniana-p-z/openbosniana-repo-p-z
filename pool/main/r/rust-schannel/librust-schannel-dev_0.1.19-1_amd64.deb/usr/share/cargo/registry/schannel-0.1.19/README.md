schannel-rs [![Build status](https://ci.appveyor.com/api/projects/status/vefyauaf0oj10swu/branch/master?svg=true)](https://ci.appveyor.com/project/steffengy/schannel-rs/branch/master)
=====

[Documentation](https://docs.rs/schannel/0/x86_64-pc-windows-msvc/schannel/)

Rust bindings to the Windows SChannel APIs providing TLS client and server functionality.
