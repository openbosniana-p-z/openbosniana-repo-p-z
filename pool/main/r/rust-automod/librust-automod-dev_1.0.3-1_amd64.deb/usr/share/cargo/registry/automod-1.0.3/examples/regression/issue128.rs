#[test]
fn test() {
    assert_eq!(module_path!(), "tests::regression::issue128");
}
