## Version 1.1.0
- hkdf dependency updated.
- Error properly returned when a collection is not found.
