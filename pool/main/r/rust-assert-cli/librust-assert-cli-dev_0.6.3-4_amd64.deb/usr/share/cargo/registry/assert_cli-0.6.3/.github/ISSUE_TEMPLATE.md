<!--
Hi! If you want to report a bug, request a feature, or ask a question on how to
use assert_cli, you have come to the right place!

If you want to report a bug, please fill in the following. Otherwise, feel free
to remove these lines.
-->

- `assert_cli` version:
- Rust version:
- OS and version:
