use cases_can_be_declared_on_non_test_items::normal_public_function;

fn main() {
    println!("{}", normal_public_function(12));
}
