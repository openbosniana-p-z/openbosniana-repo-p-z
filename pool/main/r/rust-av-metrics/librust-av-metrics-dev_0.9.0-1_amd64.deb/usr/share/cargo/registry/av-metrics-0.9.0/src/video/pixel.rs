//! Traits for generic code over low and high bit depth video.
//!
//! Borrowed from rav1e.

pub use v_frame::pixel::{CastFromPrimitive, Pixel};
