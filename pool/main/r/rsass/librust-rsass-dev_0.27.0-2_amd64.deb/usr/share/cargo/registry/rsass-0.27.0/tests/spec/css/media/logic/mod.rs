//! Tests auto-converted from "sass-spec/spec/css/media/logic"

#[allow(unused)]
fn runner() -> crate::TestRunner {
    super::runner().with_cwd("logic")
}

mod and;

mod and_not;

mod error;

mod nested;

mod not;

mod or;
