//! Tests auto-converted from "sass-spec/spec/core_functions/color/hwb"

#[allow(unused)]
fn runner() -> crate::TestRunner {
    super::runner().with_cwd("hwb")
}

mod error;

mod four_args;

mod one_arg;

mod three_args;
