//! Tests auto-converted from "sass-spec/spec/core_functions/color/rgb"

#[allow(unused)]
fn runner() -> crate::TestRunner {
    super::runner().with_cwd("rgb")
}

mod error;

mod four_args;

mod multi_argument_var;

mod one_arg;

mod three_args;

mod two_args;
