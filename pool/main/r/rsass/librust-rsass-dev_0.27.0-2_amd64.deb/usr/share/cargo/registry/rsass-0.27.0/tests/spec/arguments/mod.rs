//! Tests auto-converted from "sass-spec/spec/arguments"

#[allow(unused)]
fn runner() -> crate::TestRunner {
    super::runner().with_cwd("arguments")
}

mod invocation;
