//! Tests auto-converted from "sass-spec/spec/css/moz_document/functions"

#[allow(unused)]
fn runner() -> crate::TestRunner {
    super::runner().with_cwd("functions")
}

mod interpolated;

mod test_static;
