//! Tests auto-converted from "sass-spec/spec/css/moz_document"

#[allow(unused)]
fn runner() -> crate::TestRunner {
    super::runner().with_cwd("moz_document")
}

mod empty_prefix;

mod functions;

mod multi_function;
