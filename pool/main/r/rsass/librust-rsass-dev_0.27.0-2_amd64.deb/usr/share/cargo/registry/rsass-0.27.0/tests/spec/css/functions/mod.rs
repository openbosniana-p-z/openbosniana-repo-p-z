//! Tests auto-converted from "sass-spec/spec/css/functions"

#[allow(unused)]
fn runner() -> crate::TestRunner {
    super::runner().with_cwd("functions")
}

mod error;

mod special;

mod url;

mod var;
