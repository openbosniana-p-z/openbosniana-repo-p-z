//! Tests auto-converted from "sass-spec/spec/core_functions/color/hsl/one_arg"

#[allow(unused)]
fn runner() -> crate::TestRunner {
    super::runner().with_cwd("one_arg")
}

mod alpha;

mod no_alpha;

mod special_functions;
