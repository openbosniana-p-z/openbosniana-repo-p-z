//! Tests auto-converted from "sass-spec/spec/core_functions/meta/load_css"

#[allow(unused)]
fn runner() -> crate::TestRunner {
    super::runner().with_cwd("load_css")
}

mod error;

mod extend;

mod plain_css;

mod twice;

mod with;
