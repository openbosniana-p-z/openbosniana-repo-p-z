//! Tests auto-converted from "sass-spec/spec/core_functions/list/join"

#[allow(unused)]
fn runner() -> crate::TestRunner {
    super::runner().with_cwd("join")
}

mod empty;

mod error;

mod multi;

mod single;
