//! Tests auto-converted from "sass-spec/spec/core_functions/color/rgb/three_args"

#[allow(unused)]
fn runner() -> crate::TestRunner {
    super::runner().with_cwd("three_args")
}

mod percents;

mod special_functions;

mod unitless;
