//! Tests auto-converted from "sass-spec/spec/core_functions/color/rgb/four_args"

#[allow(unused)]
fn runner() -> crate::TestRunner {
    super::runner().with_cwd("four_args")
}

mod alpha;

mod clamped;

mod in_gamut;

mod special_functions;
