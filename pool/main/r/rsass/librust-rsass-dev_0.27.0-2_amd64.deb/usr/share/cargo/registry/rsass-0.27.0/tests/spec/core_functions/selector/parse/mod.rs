//! Tests auto-converted from "sass-spec/spec/core_functions/selector/parse"

#[allow(unused)]
fn runner() -> crate::TestRunner {
    super::runner().with_cwd("parse")
}

mod error;

mod named;

mod selector;

mod structure;
