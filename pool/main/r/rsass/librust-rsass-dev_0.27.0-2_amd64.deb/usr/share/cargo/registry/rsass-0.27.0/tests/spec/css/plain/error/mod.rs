//! Tests auto-converted from "sass-spec/spec/css/plain/error"

#[allow(unused)]
fn runner() -> crate::TestRunner {
    super::runner().with_cwd("error")
}

mod expression;

mod media;

mod statement;
