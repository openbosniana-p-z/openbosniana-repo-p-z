//! Tests auto-converted from "sass-spec/spec/core_functions/color/adjust_color/error"

#[allow(unused)]
fn runner() -> crate::TestRunner {
    super::runner().with_cwd("error")
}

mod args;

mod bounds;

mod mixed_formats;

mod test_type;

mod units;
