//! Tests auto-converted from "sass-spec/spec/core_functions/color/hsl/one_arg/special_functions"

#[allow(unused)]
fn runner() -> crate::TestRunner {
    super::runner().with_cwd("special_functions")
}

mod alpha;

mod no_alpha;

mod slash_list;
