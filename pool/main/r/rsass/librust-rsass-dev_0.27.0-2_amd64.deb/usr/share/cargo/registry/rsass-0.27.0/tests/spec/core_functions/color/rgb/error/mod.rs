//! Tests auto-converted from "sass-spec/spec/core_functions/color/rgb/error"

#[allow(unused)]
fn runner() -> crate::TestRunner {
    super::runner().with_cwd("error")
}

mod five_args;

mod four_args;

mod one_arg;

mod three_args;

mod two_args;

mod zero_args;
