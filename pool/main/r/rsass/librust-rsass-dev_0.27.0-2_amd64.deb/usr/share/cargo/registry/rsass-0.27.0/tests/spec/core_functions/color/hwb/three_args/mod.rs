//! Tests auto-converted from "sass-spec/spec/core_functions/color/hwb/three_args"

#[allow(unused)]
fn runner() -> crate::TestRunner {
    super::runner().with_cwd("three_args")
}

mod named;

mod units;

mod w3c;
