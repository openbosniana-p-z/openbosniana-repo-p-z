//! Tests auto-converted from "sass-spec/spec/css/media/range"

#[allow(unused)]
fn runner() -> crate::TestRunner {
    super::runner().with_cwd("range")
}

mod error;

mod from_interpolation;

mod test_static;

mod with_expressions;
