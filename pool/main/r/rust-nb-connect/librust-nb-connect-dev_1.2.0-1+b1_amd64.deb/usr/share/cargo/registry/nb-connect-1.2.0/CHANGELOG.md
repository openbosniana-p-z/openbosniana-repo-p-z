# Version 1.2.0

- **This crate is now deprecated in favor of [socket2](https://crates.io/crates/socket2).**

# Version 1.1.0

- Increase MSRV to rustc 1.46.
- Update `socket2` dependency to 0.4.

# Version 1.0.4

- Update `socket2` dependency to 0.4.

# Version 1.0.3

- Fix invalid assumption of `std::net::SocketAddrV{4,6}` layout.

# Version 1.0.2

- Update `polling` in docs.

# Version 1.0.1

- Close the socket if an error occurs before the end of connect.

# Version 1.0.0

- Initial version
