# safe-transmute-rs [![TravisCI build status](https://travis-ci.org/nabijaczleweli/safe-transmute-rs.svg?branch=master)](https://travis-ci.org/nabijaczleweli/safe-transmute-rs) [![AppVeyorCI build status](https://ci.appveyor.com/api/projects/status/cspjknvfow5gfro0/branch/master?svg=true)](https://ci.appveyor.com/project/nabijaczleweli/safe-transmute-rs/branch/master) [![Licence](https://img.shields.io/badge/license-MIT-blue.svg?style=flat)](LICENSE) [![Crates.io version](https://meritbadge.herokuapp.com/safe-transmute)](https://crates.io/crates/safe-transmute)
A safeguarded `transmute()` for Rust.

## [Documentation](https://cdn.rawgit.com/nabijaczleweli/safe-transmute-rs/doc/safe_transmute/index.html)
