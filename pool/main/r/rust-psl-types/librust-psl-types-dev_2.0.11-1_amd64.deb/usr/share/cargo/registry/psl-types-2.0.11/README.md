# PSL Types

Common types for the public suffix implementation crates.
This was made for the `psl` and `publicsuffix` crates but
it can be used by any implementation.
