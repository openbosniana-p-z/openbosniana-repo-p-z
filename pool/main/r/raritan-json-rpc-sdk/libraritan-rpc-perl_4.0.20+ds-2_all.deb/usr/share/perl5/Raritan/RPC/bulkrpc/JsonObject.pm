# SPDX-License-Identifier: BSD-3-Clause
#
# Copyright 2014 Raritan Inc. All rights reserved.

use strict;

package Raritan::RPC::bulkrpc::JsonObject;

sub encode {
    return $1;
}

sub decode {
    return $1;
}

1;
