### v2.0.0 - 2022-05-11
- support for setuid, setgid and sticky "extra" permission bits - Thanks @CozyPenguin

### v1.0.1 - 2022-01-28
- implement Into<u32>

### v1.0.0 - 2020-05-20
Official release

