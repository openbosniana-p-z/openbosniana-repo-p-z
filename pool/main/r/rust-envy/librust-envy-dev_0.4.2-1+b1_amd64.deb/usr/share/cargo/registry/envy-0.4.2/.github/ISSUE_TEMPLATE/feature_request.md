---
name: Feature request 💡
about: Suggest a new idea for envy
---

<!-- Please search existing issues to avoid creating duplicates. -->

## 💡 Feature description
<!-- Describe the feature you'd like. -->

#### 💻 Basic example
<!-- Include a basic code example if possible. Omit this section if not applicable. -->