osmesa-rs: Off-Screen Mesa bindings for Rust.
The OSMesa library is available under the MIT license.
These bindings are public domain.
