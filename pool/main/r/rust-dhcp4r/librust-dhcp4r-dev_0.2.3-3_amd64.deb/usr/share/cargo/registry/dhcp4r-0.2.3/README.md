# DHCP4r - A DHCP library written in Rust.

## Author
http://richard.warburton.it/

## Quick Start
See examples/server.rs for how to use this library to create a basic server. If you have cargo installed, you can run the example server:
```
$ cargo run --example server
```
