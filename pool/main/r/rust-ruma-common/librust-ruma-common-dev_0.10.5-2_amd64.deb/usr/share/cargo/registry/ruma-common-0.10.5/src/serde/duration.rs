//! De-/serialization functions for `std::time::Duration` objects

pub mod opt_ms;
pub mod secs;
