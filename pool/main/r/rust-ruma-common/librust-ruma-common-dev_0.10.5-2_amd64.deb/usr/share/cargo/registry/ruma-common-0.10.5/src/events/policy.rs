//! Modules for events in the `m.policy` namespace.

pub mod rule;
