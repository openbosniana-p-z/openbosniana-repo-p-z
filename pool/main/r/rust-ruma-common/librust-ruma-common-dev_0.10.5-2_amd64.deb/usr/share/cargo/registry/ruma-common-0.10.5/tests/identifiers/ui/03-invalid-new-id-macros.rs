fn main() {
    let _ = ruma_common::session_id!("invalid~");
}
