//! Module for events in the `m.secret_storage` namespace.

pub mod default_key;
pub mod key;
pub mod secret;
