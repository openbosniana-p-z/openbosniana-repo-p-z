//! Modules for events in the `m.key` namespace.

pub mod verification;
