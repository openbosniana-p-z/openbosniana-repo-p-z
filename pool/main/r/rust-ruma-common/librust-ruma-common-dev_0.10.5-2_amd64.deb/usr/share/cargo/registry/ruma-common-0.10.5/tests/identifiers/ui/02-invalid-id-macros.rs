fn main() {
    let _ = ruma_common::event_id!("39hvsi03hlne:example.com");
    let _ = ruma_common::event_id!("acR1l0raoZnm60CBwAVgqbZqoO/mYU81xysh1u7XcJk");
    let _ = ruma_common::mxc_uri!("");
    let _ = ruma_common::room_alias_id!("alias:server.tld");
    let _ = ruma_common::room_id!("1234567890:matrix.org");
    let _ = ruma_common::room_version_id!("");
    let _ = ruma_common::server_name!("");
    let _ = ruma_common::user_id!("user:ruma.io");
}
