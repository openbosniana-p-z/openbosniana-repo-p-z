//! Module for events in the `m.secret` namespace.

pub mod request;
pub mod send;
