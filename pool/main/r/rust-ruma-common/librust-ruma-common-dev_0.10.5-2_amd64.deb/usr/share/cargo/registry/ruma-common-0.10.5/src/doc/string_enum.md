<!-- Keep this comment so the content is always included as a new paragraph -->
This type can hold an arbitrary string. To build this with a custom value, convert it from a
string with `::from()` / `.into()`. To check for values that are not available as a
documented variant here, use its string representation, obtained through
[`.as_str()`](Self::as_str()).
