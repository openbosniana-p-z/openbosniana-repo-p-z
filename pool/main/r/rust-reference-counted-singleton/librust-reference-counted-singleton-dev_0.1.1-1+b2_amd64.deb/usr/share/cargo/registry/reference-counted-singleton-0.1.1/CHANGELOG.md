# Change log

This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.1] - 2021-07-28

### Changed

- Updated dependencies: `assert_matches`.

## [0.1.0] - 2021-06-09

### Added

- Initial release.
