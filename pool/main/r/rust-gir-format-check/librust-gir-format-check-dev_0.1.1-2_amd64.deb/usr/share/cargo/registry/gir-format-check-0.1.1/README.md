# file-format-check

Used to check `Gir.toml` files for `gtk-rs` crates.
