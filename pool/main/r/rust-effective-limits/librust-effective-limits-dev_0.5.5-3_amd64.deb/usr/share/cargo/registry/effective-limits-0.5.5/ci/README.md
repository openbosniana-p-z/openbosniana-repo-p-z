# CI support

This CI glue is copied liberally from rust-lang/rustup's CI glue.
