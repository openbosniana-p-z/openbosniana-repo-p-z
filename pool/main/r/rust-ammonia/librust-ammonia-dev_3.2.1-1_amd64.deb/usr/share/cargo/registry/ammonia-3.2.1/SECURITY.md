# Security Policy

## Supported Versions

Use this section to tell people about which versions of your project are
currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| 3.0     | :white_check_mark: |
| 2.0     | :white_check_mark: |
| <= 1.0  | :x:                |

## Reporting a Vulnerability

You can report security vulnerabilities to @notriddle's personal email, listed on his GitHub profile.
