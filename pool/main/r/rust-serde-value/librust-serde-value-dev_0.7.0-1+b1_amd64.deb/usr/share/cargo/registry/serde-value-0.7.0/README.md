# serde-value

[![travis-badge][]][travis] [![release-badge][]][cargo] [![docs-badge][]][docs] [![license-badge][]][license]

`serde-value` provides a way to capture serialization value trees for later processing.

[travis-badge]: https://img.shields.io/travis/arcnmx/serde-value/master.svg?style=flat-square
[travis]: https://travis-ci.org/arcnmx/serde-value
[release-badge]: https://img.shields.io/crates/v/serde-value.svg?style=flat-square
[cargo]: https://crates.io/crates/serde-value
[docs-badge]: https://img.shields.io/badge/API-docs-blue.svg?style=flat-square
[docs]: https://docs.rs/serde-value/*/serde_value/
[license-badge]: https://img.shields.io/badge/license-MIT-lightgray.svg?style=flat-square
[license]: https://github.com/arcnmx/serde-value/blob/master/COPYING
