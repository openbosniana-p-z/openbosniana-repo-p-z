# 0.1.6

* fix `TIOCGWINSZ` size issue on FreeBSD [#6](https://github.com/softprops/termsize/pull/9)

# 0.1.5

* added support for [Redox OS](https://github.com/redox-os/redox) [@ids1024](https://github.com/softprops/termsize/pull/8)

# 0.1.4

* added support for [Fuchsia](https://en.wikipedia.org/wiki/Google_Fuchsia) OS [@antiagainst](https://github.com/softprops/termsize/pull/5)

# 0.1.3

* add support for new targets arm-unknown-linux-gnueabihf and armv7-unknown-linux-gnueabihf [@wimh](https://github.com/softprops/termsize/pull/3)

# 0.1.2

* replaced hardcoded per-platform constants for TIOCGWINSZ with the one defined in libc [@antiagainst](https://github.com/softprops/termsize/pull/4)

# 0.1.1

* fixed broken windows support (added automated testing)

# 0.1.0

* initial release
