There are a lot more tests over at
[capnpc/test](/capnpc/test).