# Cap'n Proto runtime library for Rust

[![crates.io](https://img.shields.io/crates/v/capnp.svg)](https://crates.io/crates/capnp)

[documentation](https://docs.capnproto-rust.org/capnp/)