# UI tests for unstable features

These tests check how the guarantees and features provided by pin-project
interact with unstable language features.

The names of the files contained in this directory need to begin with the name
of the feature.
