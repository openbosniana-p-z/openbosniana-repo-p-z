# Changelog

## 1.0.1

* Added WASM support.
