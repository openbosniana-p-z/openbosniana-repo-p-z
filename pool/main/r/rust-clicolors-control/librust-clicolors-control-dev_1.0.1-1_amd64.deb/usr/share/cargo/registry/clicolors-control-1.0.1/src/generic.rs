pub fn is_a_terminal() -> bool {
    false
}

pub fn is_a_color_terminal() -> bool {
    false
}
