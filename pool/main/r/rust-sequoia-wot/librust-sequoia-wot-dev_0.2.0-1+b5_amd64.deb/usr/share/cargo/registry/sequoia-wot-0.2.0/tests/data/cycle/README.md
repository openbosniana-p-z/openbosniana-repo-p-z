```text
    Alice
     | 3,120
     |
     v   255,90
    Bob  -->   Carol
       ^       /
 255,120 \     v 255,60
         Dave
           |
           v  1,30
          Ed
           |
           v  0,120
         Frank
```
