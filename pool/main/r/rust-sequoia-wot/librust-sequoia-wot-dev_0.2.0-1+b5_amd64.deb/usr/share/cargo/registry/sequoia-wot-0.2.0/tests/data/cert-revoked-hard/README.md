The same as cert-revoked-soft, but using hard revocations.
