//! Test data.
//!
//! This module includes the test data from `tests/data` in a
//! structured way.

use std::fmt;
use std::collections::BTreeMap;

pub struct Test {
    path: &'static str,
    pub bytes: &'static [u8],
}

impl fmt::Display for Test {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "tests/data/{}", self.path)
    }
}

/// Returns the content of the given file below `tests/data`.
pub fn file(name: &str) -> &'static [u8] {
    lazy_static::lazy_static! {
        static ref FILES: BTreeMap<&'static str, &'static [u8]> = {
            let mut m: BTreeMap<&'static str, &'static [u8]> =
                Default::default();

            macro_rules! add {
                ( $key: expr, $path: expr ) => {
                    m.insert($key, include_bytes!($path))
                }
            }
            include!(concat!(env!("OUT_DIR"), "/tests.index.rs.inc"));

            // Sanity checks.
            assert!(m.contains_key("best-via-root/README.md"));
            assert!(m.contains_key("cliques/README.md"));
            assert!(m.contains_key("cycle/README.md"));
            assert!(m.contains_key("local-optima/README.md"));
            assert!(m.contains_key("multiple-certifications-1/README.md"));
            assert!(m.contains_key("multiple-userids-1/README.md"));
            assert!(m.contains_key("multiple-userids-2/README.md"));
            assert!(m.contains_key("regex-1/README.md"));
            assert!(m.contains_key("regex-2/README.md"));
            assert!(m.contains_key("regex-3/README.md"));
            assert!(m.contains_key("roundabout/README.md"));
            assert!(m.contains_key("simple/README.md"));

            m
        };
    }

    FILES.get(name).unwrap_or_else(|| panic!("No such file {:?}", name))
}

/// Returns the content of the given file below `tests/data`.
pub fn data(name: &str) -> &'static [u8] {
    file(&format!("{}", name))
}
