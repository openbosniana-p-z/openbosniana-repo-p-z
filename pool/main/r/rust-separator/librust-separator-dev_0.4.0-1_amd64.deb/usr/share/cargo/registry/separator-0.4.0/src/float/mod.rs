mod separatable;
mod fixed_place_separatable;

pub use self::fixed_place_separatable::FixedPlaceSeparatable;
