# Version 1.1.0

- Make the crate `#![no_std]`.

# Version 1.0.0

- Initial version.
