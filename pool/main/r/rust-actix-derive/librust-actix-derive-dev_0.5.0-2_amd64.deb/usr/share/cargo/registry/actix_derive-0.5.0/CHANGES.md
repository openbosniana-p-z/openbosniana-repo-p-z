# Changes

## 0.5.0 (2019-10-27

* Update syn & quote to 1.0

## 0.4.0 (2019-03-12)

* Added `MessageResponse` proc derive macro

## 0.3.2 (2018-11-04)

* Fix another warning in rustc 1.29 or later #12

## 0.3.1 (2018-10-28)

* Upgrade `syn` crate to 0.15

## 0.3.0 (2018-07-20)

* Fix warning in rustc 1.29.0-nightly #9

* Remove nightly support


## 0.2.0 (2018-02-xx)

* Actix 0.5 support

## 0.1.1 (2017-12-23)

* Move tests to actix

## 0.1.0 (2017-12-23)

* Added `msg` proc macro

* Added `actor` proc macro
