var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuvw~",
  1: "acdeflprstvw",
  2: "rs",
  3: "acdeflmprstvw",
  4: "acdefghilmoprstuvw~",
  5: "abcdefghilmnprstuv",
  6: "eflt",
  7: "t",
  8: "fnrs",
  9: "rs",
  10: "rsuw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Macros",
  10: "Pages"
};

