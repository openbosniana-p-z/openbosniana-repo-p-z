setup-message.txt: Taken from the autocrypt v1.0 specification.
    https://autocrypt.org/level1.html#setup-message-example
