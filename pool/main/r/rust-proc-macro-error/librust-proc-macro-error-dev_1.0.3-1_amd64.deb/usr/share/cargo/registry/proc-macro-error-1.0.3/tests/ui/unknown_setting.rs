use proc_macro_error::proc_macro_error;

#[proc_macro_error(allow_not_macro, assert_unwind_safe, trololo)]
fn main() {}
