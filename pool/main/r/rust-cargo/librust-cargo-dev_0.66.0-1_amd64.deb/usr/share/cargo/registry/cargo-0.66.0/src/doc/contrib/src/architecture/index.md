# Architecture Overview

This chapter gives a very high-level overview of Cargo's architecture. This is
intended to give you links into the code which is hopefully commented with
more in-depth information.

If you feel something is missing that would help you, feel free to ask on
Zulip.
