{{#option "`--keep-going`"}}
Build as many crates in the dependency graph as possible, rather than aborting
the build on the first one that fails to build. Unstable, requires
`-Zunstable-options`.
{{/option}}
