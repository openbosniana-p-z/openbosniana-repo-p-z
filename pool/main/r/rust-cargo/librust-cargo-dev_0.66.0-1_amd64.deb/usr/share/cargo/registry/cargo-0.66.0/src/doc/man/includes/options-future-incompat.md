{{#option "`--future-incompat-report`"}}
Displays a future-incompat report for any future-incompatible warnings
produced during execution of this command

See {{man "cargo-report" 1}}
{{/option}}
