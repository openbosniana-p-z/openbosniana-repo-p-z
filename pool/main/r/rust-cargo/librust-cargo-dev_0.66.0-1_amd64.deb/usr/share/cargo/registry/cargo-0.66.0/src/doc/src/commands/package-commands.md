# Package Commands
* [cargo init](cargo-init.md)
* [cargo install](cargo-install.md)
* [cargo new](cargo-new.md)
* [cargo search](cargo-search.md)
* [cargo uninstall](cargo-uninstall.md)
