{{#option "`--lib`" }}
{{actionverb}} the package's library.
{{/option}}

{{#option "`--bin` _name_..." }}
{{actionverb}} the specified binary. This flag may be specified multiple times
and supports common Unix glob patterns.
{{/option}}

{{#option "`--bins`" }}
{{actionverb}} all binary targets.
{{/option}}
