# Git Testament Derive

![BSD 3 Clause](https://img.shields.io/github/license/kinnison/git-testament.svg)
![Latest docs](https://docs.rs/git-testament-derive/badge.svg)
![Crates.IO](https://img.shields.io/crates/v/git-testament-derive.svg)

This is the procedural macro behind `git-testament`.

Please see [the `git-testament` crates.io page](https://crates.io/crates/git-testament)
for more information, or [the `git-testament` docs.rs page](https://docs.rs/git-testament)
for documentation.
