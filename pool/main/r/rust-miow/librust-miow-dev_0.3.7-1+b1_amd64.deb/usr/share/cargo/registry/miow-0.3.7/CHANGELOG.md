
## [v0.3.7] - 2021-03-22
### Changed
- Upgrade `rand` dev-dependency from 0.4 -> 0.8
- Upgrade `socket2` dependency from 0.3 to 0.4 and make it a dev-dependency
