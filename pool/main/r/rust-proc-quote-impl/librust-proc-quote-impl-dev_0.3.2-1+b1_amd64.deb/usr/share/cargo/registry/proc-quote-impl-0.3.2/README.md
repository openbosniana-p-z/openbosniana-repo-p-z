Rust Quasi-Quoting
==================

This crate hosts the procedural macro implementation 
[`proc-quote::quote!`](https://crates.io/crates/proc-quote), rather than the
[the original `quote!` macro](https://github.com/dtolnay/quote), implemented with `macro_rules!`.

This crate is not supposed to be used directly. Use `proc-quote` crate instead.