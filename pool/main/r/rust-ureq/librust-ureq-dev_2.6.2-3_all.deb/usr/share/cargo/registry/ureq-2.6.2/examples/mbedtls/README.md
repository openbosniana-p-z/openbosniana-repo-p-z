mbedtls-example
===============

To run this example you need to `cd` into the directory and use `cargo run`.

```
cd ureq/exampled/mbedtls
cargo run
```
