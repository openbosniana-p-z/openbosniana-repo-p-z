fn main() {
    println!("{:?}", "STDOUT".chars());
}
