package cgroups

import (
	"testing"
)

func TestParseCgroups(t *testing.T) {
	t.Skip("need to mount cgroupfs")
	cgroups, err := ParseCgroupFile("/proc/self/cgroup")
	if err != nil {
		t.Fatal(err)
	}
	if IsCgroup2UnifiedMode() {
		return
	}
	if _, ok := cgroups["cpu"]; !ok {
		t.Fail()
	}
}
