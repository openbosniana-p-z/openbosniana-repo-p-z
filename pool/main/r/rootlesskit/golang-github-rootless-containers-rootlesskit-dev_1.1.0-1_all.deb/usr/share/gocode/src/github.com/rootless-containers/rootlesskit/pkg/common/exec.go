package common

import (
	"errors"
	"io"
	"os/exec"
	"syscall"

	"github.com/sirupsen/logrus"
)

// ErrorWithSys is implemented by *exec.ExitError and *child.reaperErr
type ErrorWithSys interface {
	error
	Sys() interface{}
}

func GetExecExitStatus(err error) (int, bool) {
	err = errors.Unwrap(err)
	if err == nil {
		return 0, false
	}
	exitErr, ok := err.(ErrorWithSys)
	if !ok {
		return 0, false
	}
	status, ok := exitErr.Sys().(syscall.WaitStatus)
	if !ok {
		return 0, false
	}
	return status.ExitStatus(), true
}

func Execs(o io.Writer, env []string, cmds [][]string) error {
	for _, cmd := range cmds {
		var args []string
		if len(cmd) > 1 {
			args = cmd[1:]
		}
		x := exec.Command(cmd[0], args...)
		x.Stdin = nil
		x.Stdout = o
		x.Stderr = o
		x.Env = env
		x.SysProcAttr = &syscall.SysProcAttr{
			Pdeathsig: syscall.SIGKILL,
		}
		logrus.Debugf("executing %v", cmd)
		if err := x.Run(); err != nil {
			return err
		}
	}
	return nil
}
