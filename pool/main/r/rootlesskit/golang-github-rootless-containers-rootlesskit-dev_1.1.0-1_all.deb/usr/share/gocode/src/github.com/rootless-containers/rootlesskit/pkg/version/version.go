package version

const Version = "1.1.0"
