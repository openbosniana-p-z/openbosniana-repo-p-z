extern crate rustc_version;
extern crate semver;
use rustc_version::{version, version_meta, Channel, Version};

pub fn main() {
    let channel = match version_meta().unwrap().channel {
        Channel::Dev | Channel::Nightly => "unstable",
        Channel::Beta | Channel::Stable => "stable",
    };

    println!("cargo:rustc-cfg=extprim_channel=\"{}\"", channel);
    if version().unwrap() >= Version::parse("1.26.0").unwrap() {
        println!("cargo:rustc-cfg=extprim_has_stable_i128");
    }
}

