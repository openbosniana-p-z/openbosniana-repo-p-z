(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() :
    typeof define === 'function' && define.amd ? define(factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, global.Rainbow = factory());
})(this, (function () { 'use strict';

    function isNode$1() {
        /* globals module */
        return typeof module !== 'undefined' && typeof module.exports === 'object';
    }

    function isWorker$1() {
        return typeof document === 'undefined' && typeof self !== 'undefined';
    }

    /**
     * Browser Only - Gets the language for this block of code
     *
     * @param {Element} block
     * @return {string|null}
     */
    function getLanguageForBlock(block) {

        // If this doesn't have a language but the parent does then use that.
        //
        // This means if for example you have: <pre data-language="php">
        // with a bunch of <code> blocks inside then you do not have
        // to specify the language for each block.
        var language = block.getAttribute('data-language') || block.parentNode.getAttribute('data-language');

        // This adds support for specifying language via a CSS class.
        //
        // You can use the Google Code Prettify style: <pre class="lang-php">
        // or the HTML5 style: <pre><code class="language-php">
        if (!language) {
            var pattern = /\blang(?:uage)?-(\w+)/;
            var match = block.className.match(pattern) || block.parentNode.className.match(pattern);

            if (match) {
                language = match[1];
            }
        }

        if (language) {
            return language.toLowerCase();
        }

        return null;
    }

    /**
     * Determines if two different matches have complete overlap with each other
     *
     * @param {number} start1   start position of existing match
     * @param {number} end1     end position of existing match
     * @param {number} start2   start position of new match
     * @param {number} end2     end position of new match
     * @return {boolean}
     */
    function hasCompleteOverlap(start1, end1, start2, end2) {

        // If the starting and end positions are exactly the same
        // then the first one should stay and this one should be ignored.
        if (start2 === start1 && end2 === end1) {
            return false;
        }

        return start2 <= start1 && end2 >= end1;
    }

    /**
     * Encodes < and > as html entities
     *
     * @param {string} code
     * @return {string}
     */
    function htmlEntities(code) {
        return code.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/&(?![\w\#]+;)/g, '&amp;');
    }

    /**
     * Finds out the position of group match for a regular expression
     *
     * @see http://stackoverflow.com/questions/1985594/how-to-find-index-of-groups-in-match
     * @param {Object} match
     * @param {number} groupNumber
     * @return {number}
     */
    function indexOfGroup(match, groupNumber) {
        var index = 0;

        for (var i = 1; i < groupNumber; ++i) {
            if (match[i]) {
                index += match[i].length;
            }
        }

        return index;
    }

    /**
     * Determines if a new match intersects with an existing one
     *
     * @param {number} start1    start position of existing match
     * @param {number} end1      end position of existing match
     * @param {number} start2    start position of new match
     * @param {number} end2      end position of new match
     * @return {boolean}
     */
    function intersects(start1, end1, start2, end2) {
        if (start2 >= start1 && start2 < end1) {
            return true;
        }

        return end2 > start1 && end2 < end1;
    }

    /**
     * Sorts an objects keys by index descending
     *
     * @param {Object} object
     * @return {Array}
     */
    function keys(object) {
        var locations = [];

        for (var location in object) {
            if (object.hasOwnProperty(location)) {
                locations.push(location);
            }
        }

        // numeric descending
        return locations.sort(function (a, b) { return b - a; });
    }

    /**
     * Substring replace call to replace part of a string at a certain position
     *
     * @param {number} position         the position where the replacement
     *                                  should happen
     * @param {string} replace          the text we want to replace
     * @param {string} replaceWith      the text we want to replace it with
     * @param {string} code             the code we are doing the replacing in
     * @return {string}
     */
    function replaceAtPosition(position, replace, replaceWith, code) {
        var subString = code.substr(position);

        // This is needed to fix an issue where $ signs do not render in the
        // highlighted code
        //
        // @see https://github.com/ccampbell/rainbow/issues/208
        replaceWith = replaceWith.replace(/\$/g, '$$$$');

        return code.substr(0, position) + subString.replace(replace, replaceWith);
    }

    /**
     * Creates a usable web worker from an anonymous function
     *
     * mostly borrowed from https://github.com/zevero/worker-create
     *
     * @param {Function} fn
     * @param {Prism} Prism
     * @return {Worker}
     */
    function createWorker(fn, Prism) {
        if (isNode$1()) {
            /* globals global, require, __filename */
            global.Worker = require('web-worker');
            return new Worker(__filename);
        }

        var prismFunction = Prism.toString();

        var code = keys.toString();
        code += htmlEntities.toString();
        code += hasCompleteOverlap.toString();
        code += intersects.toString();
        code += replaceAtPosition.toString();
        code += indexOfGroup.toString();
        code += prismFunction;

        var fullString = code + "\tthis.onmessage=" + (fn.toString());

        var blob = new Blob([fullString], { type: 'text/javascript' });
        return new Worker((window.URL || window.webkitURL).createObjectURL(blob));
    }

    /**
     * Prism is a class used to highlight individual blocks of code
     *
     * @class
     */
    var Prism = function Prism(options) {
        /**
         * Object of replacements to process at the end of the processing
         *
         * @type {Object}
         */
        var replacements = {};

        /**
         * Language associated with this Prism object
         *
         * @type {string}
         */
        var currentLanguage;

        /**
         * Object of start and end positions of blocks to be replaced
         *
         * @type {Object}
         */
        var replacementPositions = {};

        /**
         * Determines if the match passed in falls inside of an existing match.
         * This prevents a regex pattern from matching inside of another pattern
         * that matches a larger amount of code.
         *
         * For example this prevents a keyword from matching `function` if there
         * is already a match for `function (.*)`.
         *
         * @param {number} startstart position of new match
         * @param {number} end  end position of new match
         * @return {boolean}
         */
        function _matchIsInsideOtherMatch(start, end) {
            for (var key in replacementPositions) {
                key = parseInt(key, 10);

                // If this block completely overlaps with another block
                // then we should remove the other block and return `false`.
                if (hasCompleteOverlap(key, replacementPositions[key], start, end)) {
                    delete replacementPositions[key];
                    delete replacements[key];
                }

                if (intersects(key, replacementPositions[key], start, end)) {
                    return true;
                }
            }

            return false;
        }

        /**
         * Takes a string of code and wraps it in a span tag based on the name
         *
         * @param {string} name    name of the pattern (ie keyword.regex)
         * @param {string} code    block of code to wrap
         * @param {string} globalClass class to apply to every span
         * @return {string}
         */
        function _wrapCodeInSpan(name, code) {
            var className = name.replace(/\./g, ' ');

            var globalClass = options.globalClass;
            if (globalClass) {
                className += " " + globalClass;
            }

            return ("<span class=\"" + className + "\">" + code + "</span>");
        }

        /**
         * Process replacements in the string of code to actually update
         * the markup
         *
         * @param {string} code     the code to process replacements in
         * @return {string}
         */
        function _processReplacements(code) {
            var positions = keys(replacements);
            for (var i = 0, list = positions; i < list.length; i += 1) {
                var position = list[i];

                var replacement = replacements[position];
                code = replaceAtPosition(position, replacement.replace, replacement.with, code);
            }
            return code;
        }

        /**
         * It is so we can create a new regex object for each call to
         * _processPattern to avoid state carrying over when running exec
         * multiple times.
         *
         * The global flag should not be carried over because we are simulating
         * it by processing the regex in a loop so we only care about the first
         * match in each string. This also seems to improve performance quite a
         * bit.
         *
         * @param {RegExp} regex
         * @return {string}
         */
        function _cloneRegex(regex) {
            var flags = '';

            if (regex.ignoreCase) {
                flags += 'i';
            }

            if (regex.multiline) {
                flags += 'm';
            }

            return new RegExp(regex.source, flags);
        }

        /**
         * Matches a regex pattern against a block of code, finds all matches
         * that should be processed, and stores the positions of where they
         * should be replaced within the string.
         *
         * This is where pretty much all the work is done but it should not
         * be called directly.
         *
         * @param {Object} pattern
         * @param {string} code
         * @param {number} offset
         * @return {mixed}
         */
        function _processPattern(pattern, code, offset) {
            if ( offset === void 0 ) offset = 0;

            var regex = pattern.pattern;
            if (!regex) {
                return false;
            }

            // Since we are simulating global regex matching we need to also
            // make sure to stop after one match if the pattern is not global
            var shouldStop = !regex.global;

            regex = _cloneRegex(regex);
            var match = regex.exec(code);
            if (!match) {
                return false;
            }

            // Treat match 0 the same way as name
            if (!pattern.name && pattern.matches && typeof pattern.matches[0] === 'string') {
                pattern.name = pattern.matches[0];
                delete pattern.matches[0];
            }

            var replacement = match[0];
            var startPos = match.index + offset;
            var endPos = match[0].length + startPos;

            // In some cases when the regex matches a group such as \s* it is
            // possible for there to be a match, but have the start position
            // equal the end position. In those cases we should be able to stop
            // matching. Otherwise this can lead to an infinite loop.
            if (startPos === endPos) {
                return false;
            }

            // If this is not a child match and it falls inside of another
            // match that already happened we should skip it and continue
            // processing.
            if (_matchIsInsideOtherMatch(startPos, endPos)) {
                return {
                    remaining: code.substr(endPos - offset),
                    offset: endPos
                };
            }

            /**
             * Callback for when a match was successfully processed
             *
             * @param {string} repl
             * @return {void}
             */
            function onMatchSuccess(repl) {

                // If this match has a name then wrap it in a span tag
                if (pattern.name) {
                    repl = _wrapCodeInSpan(pattern.name, repl);
                }

                // For debugging
                // console.log('Replace ' + match[0] + ' with ' + replacement + ' at position ' + startPos + ' to ' + endPos);

                // Store what needs to be replaced with what at this position
                replacements[startPos] = {
                    'replace': match[0],
                    'with': repl
                };

                // Store the range of this match so we can use it for
                // comparisons with other matches later.
                replacementPositions[startPos] = endPos;

                if (shouldStop) {
                    return false;
                }

                return {
                    remaining: code.substr(endPos - offset),
                    offset: endPos
                };
            }

            /**
             * Helper function for processing a sub group
             *
             * @param {number} groupKey  index of group
             * @return {void}
             */
            function _processGroup(groupKey) {
                var block = match[groupKey];

                // If there is no match here then move on
                if (!block) {
                    return;
                }

                var group = pattern.matches[groupKey];
                var language = group.language;

                /**
                 * Process group is what group we should use to actually process
                 * this match group.
                 *
                 * For example if the subgroup pattern looks like this:
                 *
                 * 2: {
                 * 'name': 'keyword',
                 * 'pattern': /true/g
                 * }
                 *
                 * then we use that as is, but if it looks like this:
                 *
                 * 2: {
                 * 'name': 'keyword',
                 * 'matches': {
                 *      'name': 'special',
                 *      'pattern': /whatever/g
                 *  }
                 * }
                 *
                 * we treat the 'matches' part as the pattern and keep
                 * the name around to wrap it with later
                 */
                var groupToProcess = group.name && group.matches ? group.matches : group;

                /**
                 * Takes the code block matched at this group, replaces it
                 * with the highlighted block, and optionally wraps it with
                 * a span with a name
                 *
                 * @param {string} passedBlock
                 * @param {string} replaceBlock
                 * @param {string|null} matchName
                 */
                var _getReplacement = function(passedBlock, replaceBlock, matchName) {
                    replacement = replaceAtPosition(indexOfGroup(match, groupKey), passedBlock, matchName ? _wrapCodeInSpan(matchName, replaceBlock) : replaceBlock, replacement);
                    return;
                };

                // If this is a string then this match is directly mapped
                // to selector so all we have to do is wrap it in a span
                // and continue.
                if (typeof group === 'string') {
                    _getReplacement(block, block, group);
                    return;
                }

                var localCode;
                var prism = new Prism(options);

                // If this is a sublanguage go and process the block using
                // that language
                if (language) {
                    localCode = prism.refract(block, language);
                    _getReplacement(block, localCode);
                    return;
                }

                // The process group can be a single pattern or an array of
                // patterns. `_processCodeWithPatterns` always expects an array
                // so we convert it here.
                localCode = prism.refract(block, currentLanguage, groupToProcess.length ? groupToProcess : [groupToProcess]);
                _getReplacement(block, localCode, group.matches ? group.name : 0);
            }

            // If this pattern has sub matches for different groups in the regex
            // then we should process them one at a time by running them through
            // the _processGroup function to generate the new replacement.
            //
            // We use the `keys` function to run through them backwards because
            // the match position of earlier matches will not change depending
            // on what gets replaced in later matches.
            var groupKeys = keys(pattern.matches);
            for (var i = 0, list = groupKeys; i < list.length; i += 1) {
                var groupKey = list[i];

                _processGroup(groupKey);
            }

            // Finally, call `onMatchSuccess` with the replacement
            return onMatchSuccess(replacement);
        }

        /**
         * Processes a block of code using specified patterns
         *
         * @param {string} code
         * @param {Array} patterns
         * @return {string}
         */
        function _processCodeWithPatterns(code, patterns) {
            for (var i = 0, list = patterns; i < list.length; i += 1) {
                var pattern = list[i];

                var result = _processPattern(pattern, code);
                while (result) {
                    result = _processPattern(pattern, result.remaining, result.offset);
                }
            }

            // We are done processing the patterns so we should actually replace
            // what needs to be replaced in the code.
            return _processReplacements(code);
        }

        /**
         * Returns a list of regex patterns for this language
         *
         * @param {string} language
         * @return {Array}
         */
        function getPatternsForLanguage(language) {
            var patterns = options.patterns[language] || [];
            while (options.inheritenceMap[language]) {
                language = options.inheritenceMap[language];
                patterns = patterns.concat(options.patterns[language] || []);
            }

            return patterns;
        }

        /**
         * Takes a string of code and highlights it according to the language
         * specified
         *
         * @param {string} code
         * @param {string} language
         * @param {object} patterns optionally specify a list of patterns
         * @return {string}
         */
        function _highlightBlockForLanguage(code, language, patterns) {
            currentLanguage = language;
            patterns = patterns || getPatternsForLanguage(language);
            return _processCodeWithPatterns(htmlEntities(code), patterns);
        }

        this.refract = _highlightBlockForLanguage;
    };

    function rainbowWorker(e) {
        var message = e.data;

        var prism = new Prism(message.options);
        var result = prism.refract(message.code, message.lang);

        function _reply() {
            self.postMessage({
                id: message.id,
                lang: message.lang,
                result: result
            });
        }

        if (message.isNode) {
            _reply();
            return;
        }

        setTimeout(function () {
            _reply();
        }, message.options.delay * 1000);
    }

    /**
     * Copyright 2012-2016 Craig Campbell
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     * http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     *
     * Rainbow is a simple code syntax highlighter
     *
     * @see rainbowco.de
     */

    /**
     * An array of the language patterns specified for each language
     *
     * @type {Object}
     */
    var patterns = {};

    /**
     * An object of languages mapping to what language they should inherit from
     *
     * @type {Object}
     */
    var inheritenceMap = {};

    /**
     * A mapping of language aliases
     *
     * @type {Object}
     */
    var aliases = {};

    /**
     * Representation of the actual rainbow object
     *
     * @type {Object}
     */
    var Rainbow = {};

    /**
     * Callback to fire after each block is highlighted
     *
     * @type {null|Function}
     */
    var onHighlightCallback;

    /**
     * Counter for block ids
     * @see https://github.com/ccampbell/rainbow/issues/207
     */
    var id = 0;

    var isNode = isNode$1();
    var isWorker = isWorker$1();

    var cachedWorker = null;
    function _getWorker() {
        if (isNode || cachedWorker === null) {
            cachedWorker = createWorker(rainbowWorker, Prism);
        }

        return cachedWorker;
    }

    /**
     * Helper for matching up callbacks directly with the
     * post message requests to a web worker.
     *
     * @param {object} message      data to send to web worker
     * @param {Function} callback   callback function for worker to reply to
     * @return {void}
     */
    function _messageWorker(message, callback) {
        var worker = _getWorker();

        function _listen(e) {
            if (e.data.id === message.id) {
                callback(e.data);
                worker.removeEventListener('message', _listen);

                // I realized down the road I might look at this and wonder what is going on
                // so probably it is not a bad idea to leave a comment.
                //
                // This is needed because right now the node library for simulating web
                // workers “web-worker” will keep the worker open and it causes
                // scripts running from the command line to hang unless the worker is
                // explicitly closed.
                //
                // This means for node we will spawn a new thread for every asynchronous
                // block we are highlighting, but in the browser we will keep a single
                // worker open for all requests.
                if (isNode) {
                    worker.terminate();
                }
            }
        }

        worker.addEventListener('message', _listen);
        worker.postMessage(message);
    }

    /**
     * Browser Only - Handles response from web worker, updates DOM with
     * resulting code, and fires callback
     *
     * @param {Element} element
     * @param {object} waitingOn
     * @param {Function} callback
     * @return {void}
     */
    function _generateHandler(element, waitingOn, callback) {
        return function _handleResponseFromWorker(data) {
            element.innerHTML = data.result;
            element.classList.remove('loading');
            element.classList.add('rainbow-show');

            if (element.parentNode.tagName === 'PRE') {
                element.parentNode.classList.remove('loading');
                element.parentNode.classList.add('rainbow-show');
            }

            // element.addEventListener('animationend', (e) => {
            //     if (e.animationName === 'fade-in') {
            //         setTimeout(() => {
            //             element.classList.remove('decrease-delay');
            //         }, 1000);
            //     }
            // });

            if (onHighlightCallback) {
                onHighlightCallback(element, data.lang);
            }

            if (--waitingOn.c === 0) {
                callback();
            }
        };
    }

    /**
     * Gets options needed to pass into Prism
     *
     * @param {object} options
     * @return {object}
     */
    function _getPrismOptions(options) {
        return {
            patterns: patterns,
            inheritenceMap: inheritenceMap,
            aliases: aliases,
            globalClass: options.globalClass,
            delay: !isNaN(options.delay) ? options.delay : 0
        };
    }

    /**
     * Gets data to send to webworker
     *
     * @param  {string} code
     * @param  {string} lang
     * @return {object}
     */
    function _getWorkerData(code, lang) {
        var options = {};
        if (typeof lang === 'object') {
            options = lang;
            lang = options.language;
        }

        lang = aliases[lang] || lang;

        var workerData = {
            id: id++,
            code: code,
            lang: lang,
            options: _getPrismOptions(options),
            isNode: isNode
        };

        return workerData;
    }

    /**
     * Browser Only - Sends messages to web worker to highlight elements passed
     * in
     *
     * @param {Array} codeBlocks
     * @param {Function} callback
     * @return {void}
     */
    function _highlightCodeBlocks(codeBlocks, callback) {
        var waitingOn = { c: 0 };
        for (var i = 0, list = codeBlocks; i < list.length; i += 1) {
            var block = list[i];

            var language = getLanguageForBlock(block);
            if (block.classList.contains('rainbow') || !language) {
                continue;
            }

            // This cancels the pending animation to fade the code in on load
            // since we want to delay doing this until it is actually
            // highlighted
            block.classList.add('loading');
            block.classList.add('rainbow');

            // We need to make sure to also add the loading class to the pre tag
            // because that is how we will know to show a preloader
            if (block.parentNode.tagName === 'PRE') {
                block.parentNode.classList.add('loading');
            }

            var globalClass = block.getAttribute('data-global-class');
            var delay = parseInt(block.getAttribute('data-delay'), 10);

            ++waitingOn.c;
            _messageWorker(_getWorkerData(block.innerHTML, { language: language, globalClass: globalClass, delay: delay }), _generateHandler(block, waitingOn, callback));
        }

        if (waitingOn.c === 0) {
            callback();
        }
    }

    function _addPreloader(preBlock) {
        var preloader = document.createElement('div');
        preloader.className = 'preloader';
        for (var i = 0; i < 7; i++) {
            preloader.appendChild(document.createElement('div'));
        }
        preBlock.appendChild(preloader);
    }

    /**
     * Browser Only - Start highlighting all the code blocks
     *
     * @param {Element} node       HTMLElement to search within
     * @param {Function} callback
     * @return {void}
     */
    function _highlight(node, callback) {
        callback = callback || function() {};

        // The first argument can be an Event or a DOM Element.
        //
        // I was originally checking instanceof Event but that made it break
        // when using mootools.
        //
        // @see https://github.com/ccampbell/rainbow/issues/32
        node = node && typeof node.getElementsByTagName === 'function' ? node : document;

        var preBlocks = node.getElementsByTagName('pre');
        var codeBlocks = node.getElementsByTagName('code');
        var finalPreBlocks = [];
        var finalCodeBlocks = [];

        // First loop through all pre blocks to find which ones to highlight
        for (var i = 0, list = preBlocks; i < list.length; i += 1) {
            var preBlock = list[i];

            _addPreloader(preBlock);

            // Strip whitespace around code tags when they are inside of a pre
            // tag.  This makes the themes look better because you can't
            // accidentally add extra linebreaks at the start and end.
            //
            // When the pre tag contains a code tag then strip any extra
            // whitespace.
            //
            // For example:
            //
            // <pre>
            //      <code>var foo = true;</code>
            // </pre>
            //
            // will become:
            //
            // <pre><code>var foo = true;</code></pre>
            //
            // If you want to preserve whitespace you can use a pre tag on
            // its own without a code tag inside of it.
            if (preBlock.getElementsByTagName('code').length) {

                // This fixes a race condition when Rainbow.color is called before
                // the previous color call has finished.
                if (!preBlock.getAttribute('data-trimmed')) {
                    preBlock.setAttribute('data-trimmed', true);
                    preBlock.innerHTML = preBlock.innerHTML.trim();
                }
                continue;
            }

            // If the pre block has no code blocks then we are going to want to
            // process it directly.
            finalPreBlocks.push(preBlock);
        }

        // @see http://stackoverflow.com/questions/2735067/how-to-convert-a-dom-node-list-to-an-array-in-javascript
        // We are going to process all <code> blocks
        for (var i$1 = 0, list$1 = codeBlocks; i$1 < list$1.length; i$1 += 1) {
            var codeBlock = list$1[i$1];

            finalCodeBlocks.push(codeBlock);
        }

        _highlightCodeBlocks(finalCodeBlocks.concat(finalPreBlocks), callback);
    }

    /**
     * Callback to let you do stuff in your app after a piece of code has
     * been highlighted
     *
     * @param {Function} callback
     * @return {void}
     */
    function onHighlight(callback) {
        onHighlightCallback = callback;
    }

    /**
     * Extends the language pattern matches
     *
     * @param {string} language            name of language
     * @param {object} languagePatterns    object of patterns to add on
     * @param {string|undefined} inherits  optional language that this language
     *                                     should inherit rules from
     */
    function extend(language, languagePatterns, inherits) {

        // If we extend a language again we shouldn't need to specify the
        // inheritence for it. For example, if you are adding special highlighting
        // for a javascript function that is not in the base javascript rules, you
        // should be able to do
        //
        // Rainbow.extend('javascript', [ … ]);
        //
        // Without specifying a language it should inherit (generic in this case)
        if (!inheritenceMap[language]) {
            inheritenceMap[language] = inherits;
        }

        patterns[language] = languagePatterns.concat(patterns[language] || []);
    }

    function remove(language) {
        delete inheritenceMap[language];
        delete patterns[language];
    }

    /**
     * Starts the magic rainbow
     *
     * @return {void}
     */
    function color() {
        var args = [], len = arguments.length;
        while ( len-- ) args[ len ] = arguments[ len ];


        // If you want to straight up highlight a string you can pass the
        // string of code, the language, and a callback function.
        //
        // Example:
        //
        // Rainbow.color(code, language, function(highlightedCode, language) {
        //     // this code block is now highlighted
        // });
        if (typeof args[0] === 'string') {
            var workerData = _getWorkerData(args[0], args[1]);
            _messageWorker(workerData, (function(cb) {
                return function(data) {
                    if (cb) {
                        cb(data.result, data.lang);
                    }
                };
            }(args[2])));
            return;
        }

        // If you pass a callback function then we rerun the color function
        // on all the code and call the callback function on complete.
        //
        // Example:
        //
        // Rainbow.color(function() {
        //     console.log('All matching tags on the page are now highlighted');
        // });
        if (typeof args[0] === 'function') {
            _highlight(0, args[0]);
            return;
        }

        // Otherwise we use whatever node you passed in with an optional
        // callback function as the second parameter.
        //
        // Example:
        //
        // var preElement = document.createElement('pre');
        // var codeElement = document.createElement('code');
        // codeElement.setAttribute('data-language', 'javascript');
        // codeElement.innerHTML = '// Here is some JavaScript';
        // preElement.appendChild(codeElement);
        // Rainbow.color(preElement, function() {
        //     // New element is now highlighted
        // });
        //
        // If you don't pass an element it will default to `document`
        _highlight(args[0], args[1]);
    }

    /**
     * Method to add an alias for an existing language.
     *
     * For example if you want to have "coffee" map to "coffeescript"
     *
     * @see https://github.com/ccampbell/rainbow/issues/154
     * @param {string} alias
     * @param {string} originalLanguage
     * @return {void}
     */
    function addAlias(alias, originalLanguage) {
        aliases[alias] = originalLanguage;
    }

    /**
     * public methods
     */
    Rainbow = {
        extend: extend,
        remove: remove,
        onHighlight: onHighlight,
        addAlias: addAlias,
        color: color
    };

    if (isNode) {
        Rainbow.colorSync = function(code, lang) {
            var workerData = _getWorkerData(code, lang);
            var prism = new Prism(workerData.options);
            return prism.refract(workerData.code, workerData.lang);
        };
    }

    // In the browser hook it up to color on page load
    if (!isNode && !isWorker) {
        document.addEventListener('DOMContentLoaded', function (event) {
            if (!Rainbow.defer) {
                Rainbow.color(event);
            }
        }, false);
    }

    // From a node worker, handle the postMessage requests to it
    if (isWorker) {
        self.onmessage = rainbowWorker;
    }

    var Rainbow$1 = Rainbow;

    return Rainbow$1;

}));
/**
 * C patterns
 *
 * @author Daniel Holden
 * @author Craig Campbell
 */
Rainbow.extend('c', [
    {
        name: 'meta.preprocessor',
        matches: {
            1: [
                {
                    matches: {
                        1: 'keyword.define',
                        2: 'entity.name'
                    },
                    pattern: /(\w+)\s(\w+)\b/g
                },
                {
                    name: 'keyword.define',
                    pattern: /endif/g
                },
                {
                    name: 'constant.numeric',
                    pattern: /\d+/g
                },
                {
                    matches: {
                        1: 'keyword.include',
                        2: 'string'
                    },
                    pattern: /(include)\s(.*?)$/g
                }
            ]
        },
        pattern: /\#([\S\s]*?)$/gm
    },
    {
        name: 'keyword',
        pattern: /\b(do|goto|typedef)\b/g
    },
    {
        name: 'entity.label',
        pattern: /\w+:/g
    },
    {
        matches: {
            1: 'storage.type',
            3: 'storage.type',
            4: 'entity.name.function'
        },
        pattern: /\b((un)?signed|const)? ?(void|char|short|int|long|float|double)\*? +((\w+)(?= ?\())?/g
    },
    {
        matches: {
            2: 'entity.name.function'
        },
        pattern: /(\w|\*) +((\w+)(?= ?\())/g
    },
    {
        name: 'storage.modifier',
        pattern: /\b(static|extern|auto|register|volatile|inline)\b/g
    },
    {
        name: 'support.type',
        pattern: /\b(struct|union|enum)\b/g
    }
], 'generic');
/**
 * Coffeescript patterns
 *
 * @author Craig Campbell
 */
Rainbow.extend('coffeescript', [
    {
        name: 'comment.block',
        pattern: /(\#{3})[\s\S]*\1/gm
    },
    {
        name: 'string.block',
        pattern: /('{3}|"{3})[\s\S]*\1/gm
    },

    /**
     * multiline regex with comments
     */
    {
        name: 'string.regex',
        matches: {
            2: {
                name: 'comment',
                pattern: /\#(.*?)(?=\n)/g
            }
        },
        pattern: /(\/{3})([\s\S]*)\1/gm
    },
    {
        matches: {
            1: 'keyword'
        },
        pattern: /\b(in|when|is|isnt|of|not|unless|until|super)(?=\b)/gi
    },
    {
        name: 'keyword.operator',
        pattern: /\?/g
    },
    {
        name: 'constant.language',
        pattern: /\b(undefined|yes|on|no|off)\b/g
    },
    {
        name: 'keyword.variable.coffee',
        pattern: /@(\w+)/gi
    },

    /**
     * reset global keywards from generic
     */
    {
        name: 'reset',
        pattern: /object|class|print/gi
    },

    /**
     * named function
     */
    {
        'matches' : {
            1: 'entity.name.function',
            2: 'keyword.operator',
            3: {
                    name: 'function.argument.coffee',
                    pattern: /([\@\w]+)/g
            },
            4: 'keyword.function'
        },
        pattern: /(\w+)\s{0,}(=|:)\s{0,}\((.*?)((-|=)&gt;)/gi
    },

    /**
     * anonymous function
     */
    {
        matches: {
            1: {
                    name: 'function.argument.coffee',
                    pattern: /([\@\w]+)/g
            },
            2: 'keyword.function'
        },
        pattern: /\s\((.*?)\)\s{0,}((-|=)&gt;)/gi
    },

    /**
     * direct function no arguments
     */
    {
        'matches' : {
            1: 'entity.name.function',
            2: 'keyword.operator',
            3: 'keyword.function'
        },
        pattern: /(\w+)\s{0,}(=|:)\s{0,}((-|=)&gt;)/gi
    },

    /**
     * class definitions
     */
    {
        matches: {
            1: 'storage.class',
            2: 'entity.name.class',
            3: 'storage.modifier.extends',
            4: 'entity.other.inherited-class'
        },
        pattern: /\b(class)\s(\w+)(\sextends\s)?([\w\\]*)?\b/g
    },

    /**
     * object instantiation
     */
    {
        matches: {
            1: 'keyword.new',
            2: {
                name: 'support.class',
                pattern: /\w+/g
            }
        },
        pattern: /\b(new)\s(.*?)(?=\s)/g
    }
], 'generic');

Rainbow.addAlias('coffee', 'coffeescript');
/**
* C# patterns
*
* @author Dan Stewart
* @version 1.0.1
*/
Rainbow.extend('csharp', [
    {
        // @see http://msdn.microsoft.com/en-us/library/23954zh5.aspx
        name: 'constant',
        pattern: /\b(false|null|true)\b/g
    },
    {
        // @see http://msdn.microsoft.com/en-us/library/x53a06bb%28v=vs.100%29.aspx
        // Does not support putting an @ in front of a keyword which makes it not a keyword anymore.
        name: 'keyword',
        pattern: /\b(abstract|add|alias|ascending|as|async|await|base|bool|break|byte|case|catch|char|checked|class|const|continue|decimal|default|delegate|descending|double|do|dynamic|else|enum|event|explicit|extern|false|finally|fixed|float|foreach|for|from|get|global|goto|group|if|implicit|int|interface|internal|into|in|is|join|let|lock|long|namespace|new|object|operator|orderby|out|override|params|partial|private|protected|public|readonly|ref|remove|return|sbyte|sealed|select|set|short|sizeof|stackalloc|static|string|struct|switch|this|throw|try|typeof|uint|unchecked|ulong|unsafe|ushort|using|value|var|virtual|void|volatile|where|while|yield)\b/g
    },
    {
        matches: {
            1: 'keyword',
            2: {
                name: 'support.class',
                pattern: /\w+/g
            }
        },
        pattern: /(typeof)\s([^\$].*?)(\)|;)/g
    },
    {
        matches: {
            1: 'keyword.namespace',
            2: {
                name: 'support.namespace',
                pattern: /\w+/g
            }
        },
        pattern: /\b(namespace)\s(.*?);/g
    },
    {
        matches: {
            1: 'storage.modifier',
            2: 'storage.class',
            3: 'entity.name.class',
            4: 'storage.modifier.extends',
            5: 'entity.other.inherited-class'
        },
        pattern: /\b(abstract|sealed)?\s?(class)\s(\w+)(\sextends\s)?([\w\\]*)?\s?\{?(\n|\})/g
    },
    {
        name: 'keyword.static',
        pattern: /\b(static)\b/g
    },
    {
        matches: {
            1: 'keyword.new',
            2: {
                name: 'support.class',
                pattern: /\w+/g
            }

        },
        pattern: /\b(new)\s([^\$].*?)(?=\)|\(|;|&)/g
    },
    {
        name: 'string',
        pattern: /(")(.*?)\1/g
    },
    {
        name: 'integer',
        pattern: /\b(0x[\da-f]+|\d+)\b/g
    },
    {
        name: 'comment',
        pattern: /\/\*[\s\S]*?\*\/|(\/\/)[\s\S]*?$/gm
    },
    {
        name: 'operator',
        // @see http://msdn.microsoft.com/en-us/library/6a71f45d%28v=vs.100%29.aspx
        // ++ += + -- -= - <<= << <= => >>= >> >= != ! ~ ^ || && &= & ?? :: : *= * |= %= |= == =
        pattern: /(\+\+|\+=|\+|--|-=|-|&lt;&lt;=|&lt;&lt;|&lt;=|=&gt;|&gt;&gt;=|&gt;&gt;|&gt;=|!=|!|~|\^|\|\||&amp;&amp;|&amp;=|&amp;|\?\?|::|:|\*=|\*|\/=|%=|\|=|==|=)/g
    },
    {
        // @see http://msdn.microsoft.com/en-us/library/ed8yd1ha%28v=vs.100%29.aspx
        name: 'preprocessor',
        pattern: /(\#if|\#else|\#elif|\#endif|\#define|\#undef|\#warning|\#error|\#line|\#region|\#endregion|\#pragma)[\s\S]*?$/gm
    }
]);
/**
 * CSS patterns
 *
 * @author Craig Campbell
 */
Rainbow.extend('css', [
    {
        name: 'comment',
        pattern: /\/\*[\s\S]*?\*\//gm
    },
    {
        name: 'constant.hex-color',
        pattern: /#([a-f0-9]{3}|[a-f0-9]{6})(?=;|\s|,|\))/gi
    },
    {
        matches: {
            1: 'constant.numeric',
            2: 'keyword.unit'
        },
        pattern: /(\d+)(px|em|cm|s|%)?/g
    },
    {
        name: 'string',
        pattern: /('|")(.*?)\1/g
    },
    {
        name: 'support.css-property',
        matches: {
            1: 'support.vendor-prefix'
        },
        pattern: /(-o-|-moz-|-webkit-|-ms-)?[\w-]+(?=\s?:)(?!.*\{)/g
    },
    {
        matches: {
            1: [
                {
                    name: 'entity.name.sass',
                    pattern: /&amp;/g
                },
                {
                    name: 'direct-descendant',
                    pattern: /&gt;/g
                },
                {
                    name: 'entity.name.class',
                    pattern: /\.[\w\-_]+/g
                },
                {
                    name: 'entity.name.id',
                    pattern: /\#[\w\-_]+/g
                },
                {
                    name: 'entity.name.pseudo',
                    pattern: /:[\w\-_]+/g
                },
                {
                    name: 'entity.name.tag',
                    pattern: /\w+/g
                }
            ]
        },
        pattern: /([\w\ ,\n:\.\#\&\;\-_]+)(?=.*\{)/g
    },
    {
        matches: {
            2: 'support.vendor-prefix',
            3: 'support.css-value'
        },
        pattern: /(:|,)\s*(-o-|-moz-|-webkit-|-ms-)?([a-zA-Z-]*)(?=\b)(?!.*\{)/g
    }
]);

Rainbow.addAlias('scss', 'css');
/**
* D patterns
*
* @author Matthew Brennan Jones
* @version 1.0.1
*/
Rainbow.extend('d', [
    {
        name: 'constant',
        pattern: /\b(false|null|true)\b/gm
    },
    {
        // http://dlang.org/lex.html
        name: 'keyword',
        pattern: /\b(abstract|alias|align|asm|assert|auto|body|bool|break|byte|case|cast|catch|cdouble|cent|cfloat|char|class|const|continue|creal|dchar|debug|default|delegate|delete|deprecated|do|double|else|enum|export|extern|final|finally|float|for|foreach|foreach_reverse|function|goto|idouble|if|ifloat|immutable|import|in|inout|int|interface|invariant|ireal|is|lazy|long|macro|mixin|module|new|nothrow|null|out|override|package|pragma|private|protected|public|pure|real|ref|return|scope|shared|short|size_t|static|string|struct|super|switch|synchronized|template|this|throw|try|typedef|typeid|typeof|ubyte|ucent|uint|ulong|union|unittest|ushort|version|void|volatile|wchar|while|with|__FILE__|__LINE__|__gshared|__traits|__vector|__parameters)\b/gm
    },
    {
        matches: {
            1: 'keyword',
            2: {
                name: 'support.class',
                pattern: /\w+/gm
            }
        },
        pattern: /(typeof)\s([^\$].*?)(\)|;)/gm
    },
    {
        matches: {
            1: 'keyword.namespace',
            2: {
                name: 'support.namespace',
                pattern: /\w+/gm
            }
        },
        pattern: /\b(namespace)\s(.*?);/gm
    },
    {
        matches: {
            1: 'storage.modifier',
            2: 'storage.class',
            3: 'entity.name.class',
            4: 'storage.modifier.extends',
            5: 'entity.other.inherited-class'
        },
        pattern: /\b(abstract|sealed)?\s?(class)\s(\w+)(\sextends\s)?([\w\\]*)?\s?\{?(\n|\})/gm
    },
    {
        name: 'keyword.static',
        pattern: /\b(static)\b/gm
    },
    {
        matches: {
            1: 'keyword.new',
            2: {
                name: 'support.class',
                pattern: /\w+/gm
            }

        },
        pattern: /\b(new)\s([^\$].*?)(?=\)|\(|;|&)/gm
    },
    {
        name: 'string',
        pattern: /("|')(.*?)\1/gm
    },
    {
        name: 'integer',
        pattern: /\b(0x[\da-f]+|\d+)\b/gm
    },
    {
        name: 'comment',
        pattern: /\/\*[\s\S]*?\*\/|\/\+[\s\S]*?\+\/|(\/\/)[\s\S]*?$/gm
    },
    {
        // http://dlang.org/operatoroverloading.html
        name: 'operator',
        //  / /= &= && & |= || | -= -- - += ++ + <= << < <<= <>= <> > >>>= >>= >= >> >>> != !<>= !<> !<= !< !>= !> ! [ ] $ == = *= * %= % ^^= ^= ^^ ^ ~= ~ @ => :
        pattern: /(\/|\/=|&amp;=|&amp;&amp;|&amp;|\|=|\|\|\||\-=|\-\-|\-|\+=|\+\+|\+|&lt;=|&lt;&lt;|&lt;|&lt;&lt;=|&lt;&gt;=|&lt;&gt;|&gt;|&gt;&gt;&gt;=|&gt;&gt;=|&gt;=|&gt;&gt;|&gt;&gt;&gt;|!=|!&lt;&gt;=|!&lt;&gt;|!&lt;=|!&lt;|!&gt;=|!&gt;|!|[|]|\$|==|=|\*=|\*|%=|%|\^\^=|\^=|\^\^|\^|~=|~|@|=&gt;|\:)/gm
    }
]);

    /**
 * Generic language patterns
 *
 * @author Craig Campbell
 */
Rainbow.extend('generic', [
    {
        matches: {
            1: [
                {
                    name: 'keyword.operator',
                    pattern: /\=|\+/g
                },
                {
                    name: 'keyword.dot',
                    pattern: /\./g
                }
            ],
            2: {
                name: 'string',
                matches: {
                    name: 'constant.character.escape',
                    pattern: /\\('|"){1}/g
                }
            }
        },
        pattern: /(\(|\s|\[|\=|:|\+|\.|\{|,)(('|")([^\\\1]|\\.)*?(\3))/gm
    },
    {
        name: 'comment',
        pattern: /\/\*[\s\S]*?\*\/|(\/\/|\#)(?!.*('|").*?[^:](\/\/|\#)).*?$/gm
    },
    {
        name: 'constant.numeric',
        pattern: /\b(\d+(\.\d+)?(e(\+|\-)?\d+)?(f|d)?|0x[\da-f]+)\b/gi
    },
    {
        matches: {
            1: 'keyword'
        },
        pattern: /\b(and|array|as|b(ool(ean)?|reak)|c(ase|atch|har|lass|on(st|tinue))|d(ef|elete|o(uble)?)|e(cho|lse(if)?|xit|xtends|xcept)|f(inally|loat|or(each)?|unction)|global|if|import|int(eger)?|long|new|object|or|pr(int|ivate|otected)|public|return|self|st(ring|ruct|atic)|switch|th(en|is|row)|try|(un)?signed|var|void|while)(?=\b)/gi
    },
    {
        name: 'constant.language',
        pattern: /true|false|null/g
    },
    {
        name: 'keyword.operator',
        pattern: /\+|\!|\-|&(gt|lt|amp);|\||\*|\=/g
    },
    {
        matches: {
            1: 'function.call'
        },
        pattern: /(\w+?)(?=\()/g
    },
    {
        matches: {
            1: 'storage.function',
            2: 'entity.name.function'
        },
        pattern: /(function)\s(.*?)(?=\()/g
    }
]);
/**
 * GO Language
 *
 * @author Javier Aguirre
 * @author Craig Campbell
 */
Rainbow.extend('go', [
    {
        matches: {
            1: [
                {
                    name: 'keyword.operator',
                    pattern: /\=|\+/g
                }
            ],
            2: {
                name: 'string',
                matches: {
                    name: 'constant.character.escape',
                    pattern: /\\(`|"){1}/g
                }
            }
        },
        pattern: /(\(|\s|\[|\=|:|\+|\{|,)((`|")([^\\\1]|\\.)*?(\3))/gm
    },
    {
        name: 'comment',
        pattern: /\/\*[\s\S]*?\*\/|(\/\/)(?!.*(`|").*?\1).*?$/gm
    },
    {
        matches: {
            1: 'keyword'
        },
        pattern: /\b(d(efault|efer)|fallthrough|go(to)?|range|select)(?=\b)/gi
    },
    {
        name: 'keyword',
        pattern: /\bpackage(?=\s*\w)/gi
    },
    {
        matches: {
            1: 'storage.type',
            2: 'entity.name.struct'
        },
        pattern: /\b(type)\s+(\w+)\b(?=\s+struct\b)/gi
    },
    {
        matches: {
            1: 'storage.type',
            2: 'entity.name.type'
        },
        pattern: /\b(type)\s+(\w+)\b/gi
    },
    {
        name: 'storage.type',
        pattern: /\b(bool|byte|complex(64|128)|float(32|64)|func|interface|map|rune|string|struct|u?int(8|16|32|64)?|var)(?=\b)/g
    },
    {
        name: 'keyword.operator.initialize',
        pattern: /\:=/g
    },
    {
        matches: {
            1: 'storage.function',
            2: 'entity.name.function'
        },
        pattern: /(func)\s+(?:\(.*?\))\s+(.*?)(?=\()/g
    },
    {
        matches: {
            1: 'storage.function',
            2: 'entity.name.function'
        },
        pattern: /(func)\s+(.*?)(?=\()/g
    }
], 'generic');
/**
 * Haskell patterns
 *
 * @author Bruno Dias
 */
//TODO: {-# ... #-} stuff...
Rainbow.extend('haskell', [
	///- Comments
	{
		name: 'comment',
		pattern: /\{\-\-[\s\S(\w+)]+[\-\-][\}$]/gm
		// /\{\-{2}[\s\S(.*)]+[\-\-][\}$]/gm [multiple lines]
	},
	{
		name: 'comment',
		pattern: /\-\-(.*)/g
		// /\-\-\s(.+)$/gm [single]
	},
	///- End Comments

	///- Namespace (module)
	{
		matches: {
			1: 'keyword',
			2: 'support.namespace'
		},
		pattern: /\b(module)\s(\w+)\s[\(]?(\w+)?[\)?]\swhere/g
	},
	///- End Namespace (module)

	///- Keywords and Operators
	{
		name: 'keyword.operator',
		pattern: /\+|\!|\-|&(gt|lt|amp);|\/\=|\||\@|\:|\.|\+{2}|\:|\*|\=|#|\.{2}|(\\)[a-zA-Z_]/g
	},
	{
		name: 'keyword',
		pattern: /\b(case|class|foreign|hiding|qualified|data|family|default|deriving|do|else|if|import|in|infix|infixl|infixr|instance|let|in|otherwise|module|newtype|of|then|type|where)\b/g
	},
	{
		name: 'keyword',
		pattern: /[\`][a-zA-Z_']*?[\`]/g
	},
	///- End Keywords and Operators


	///- Infix|Infixr|Infixl
	{
		matches: {
			1: 'keyword',
			2: 'keyword.operator'
		},
		pattern: /\b(infix|infixr|infixl)+\s\d+\s(\w+)*/g
	},
	///- End Infix|Infixr|Infixl

	{
		name: 'entity.class',
		pattern: /\b([A-Z][A-Za-z0-9_']*)/g
	},

	// From c.js
	{
		name: 'meta.preprocessor',
		matches: {
			1: [
				{
					matches: {
						1: 'keyword.define',
						2: 'entity.name'
					},
					pattern: /(\w+)\s(\w+)\b/g
				},
				{
					name: 'keyword.define',
					pattern: /endif/g
				},
				{
					name: 'constant.numeric',
					pattern: /\d+/g
				},
				{
					matches: {
						1: 'keyword.include',
						2: 'string'
					},
				 pattern: /(include)\s(.*?)$/g
				}
			]
		},
		pattern: /^\#([\S\s]*?)$/gm
	}
], 'generic');
/**
 * HTML patterns
 *
 * @author Craig Campbell
 */
Rainbow.extend('html', [
    {
        name: 'source.php.embedded',
        matches: {
            1: 'variable.language.php-tag',
            2: {
                language: 'php'
            },
            3: 'variable.language.php-tag'
        },
        pattern: /(&lt;\?php|&lt;\?=?(?!xml))([\s\S]*?)(\?&gt;)/gm
    },
    {
        name: 'source.css.embedded',
        matches: {
            1: {
                matches: {
                    1: 'support.tag.style',
                    2: [
                        {
                            name: 'entity.tag.style',
                            pattern: /^style/g
                        },
                        {
                            name: 'string',
                            pattern: /('|")(.*?)(\1)/g
                        },
                        {
                            name: 'entity.tag.style.attribute',
                            pattern: /(\w+)/g
                        }
                    ],
                    3: 'support.tag.style'
                },
                pattern: /(&lt;\/?)(style.*?)(&gt;)/g
            },
            2: {
                language: 'css'
            },
            3: 'support.tag.style',
            4: 'entity.tag.style',
            5: 'support.tag.style'
        },
        pattern: /(&lt;style.*?&gt;)([\s\S]*?)(&lt;\/)(style)(&gt;)/gm
    },
    {
        name: 'source.js.embedded',
        matches: {
            1: {
                matches: {
                    1: 'support.tag.script',
                    2: [
                        {
                            name: 'entity.tag.script',
                            pattern: /^script/g
                        },

                        {
                            name: 'string',
                            pattern: /('|")(.*?)(\1)/g
                        },
                        {
                            name: 'entity.tag.script.attribute',
                            pattern: /(\w+)/g
                        }
                    ],
                    3: 'support.tag.script'
                },
                pattern: /(&lt;\/?)(script.*?)(&gt;)/g
            },
            2: {
                language: 'javascript'
            },
            3: 'support.tag.script',
            4: 'entity.tag.script',
            5: 'support.tag.script'
        },
        pattern: /(&lt;script(?! src).*?&gt;)([\s\S]*?)(&lt;\/)(script)(&gt;)/gm
    },
    {
        name: 'comment.html',
        pattern: /&lt;\!--[\S\s]*?--&gt;/g
    },
    {
        matches: {
            1: 'support.tag.open',
            2: 'support.tag.close'
        },
        pattern: /(&lt;)|(\/?\??&gt;)/g
    },
    {
        name: 'support.tag',
        matches: {
            1: 'support.tag',
            2: 'support.tag.special',
            3: 'support.tag-name'
        },
        pattern: /(&lt;\??)(\/|\!?)(\w+)/g
    },
    {
        matches: {
            1: 'support.attribute'
        },
        pattern: /([a-z-]+)(?=\=)/gi
    },
    {
        matches: {
            1: 'support.operator',
            2: 'string.quote',
            3: 'string.value',
            4: 'string.quote'
        },
        pattern: /(=)('|")(.*?)(\2)/g
    },
    {
        matches: {
            1: 'support.operator',
            2: 'support.value'
        },
        pattern: /(=)([a-zA-Z\-0-9]*)\b/g
    },
    {
        matches: {
            1: 'support.attribute'
        },
        pattern: /\s([\w-]+)(?=\s|&gt;)(?![\s\S]*&lt;)/g
    }
]);

Rainbow.addAlias('xml', 'html');
/**
* Java patterns
*
* @author Leo Accend
* @version 1.0.0
*/
Rainbow.extend( "java", [
  {
    name: "constant",
    pattern: /\b(false|null|true|[A-Z_]+)\b/g
  },
  {
    matches: {
      1: "keyword",
      2: "support.namespace"
    },
    pattern: /(import|package)\s(.+)/g
  },
  {
    // see http://docs.oracle.com/javase/tutorial/java/nutsandbolts/_keywords.html
    name: "keyword",
    pattern: /\b(abstract|assert|boolean|break|byte|case|catch|char|class|const|continue|default|do|double|else|enum|extends|final|finally|float|for|goto|if|implements|import|instanceof|int|interface|long|native|new|package|private|protected|public|return|short|static|strictfp|super|switch|synchronized|this|throw|throws|transient|try|void|volatile|while)\b/g
  },
  {
    name: "string",
    pattern: /(".*?")/g
  },
  {
    name: "char",
    pattern: /(')(.|\\.|\\u[\dA-Fa-f]{4})\1/g
  },
  {
    name: "integer",
    pattern: /\b(0x[\da-f]+|\d+)L?\b/g
  },
  {
    name: "comment",
    pattern: /\/\*[\s\S]*?\*\/|(\/\/).*?$/gm
  },
  {
    name: "support.annotation",
    pattern: /@\w+/g
  },
  {
    matches: {
      1: "entity.function"
    },
    pattern: /([^@\.\s]+)\(/g
  },
  {
    name: "entity.class",
    pattern: /\b([A-Z]\w*)\b/g
  },
  {
    // see http://docs.oracle.com/javase/tutorial/java/nutsandbolts/operators.html
    name: "operator",
    pattern: /(\+{1,2}|-{1,2}|~|!|\*|\/|%|(?:&lt;){1,2}|(?:&gt;){1,3}|instanceof|(?:&amp;){1,2}|\^|\|{1,2}|\?|:|(?:=|!|\+|-|\*|\/|%|\^|\||(?:&lt;){1,2}|(?:&gt;){1,3})?=)/g
  }
]);
/**
 * Javascript patterns
 *
 * @author Craig Campbell
 */
Rainbow.extend('javascript', [

    /**
     * matches $. or $(
     */
    {
        name: 'selector',
        pattern: /\$(?=\.|\()/g
    },
    {
        name: 'support',
        pattern: /\b(window|document)\b/g
    },
    {
        name: 'keyword',
        pattern: /\b(export|default|from)\b/g
    },
    {
        name: 'function.call',
        pattern: /\b(then)(?=\()/g
    },
    {
        name: 'variable.language.this',
        pattern: /\bthis\b/g
    },
    {
        name: 'variable.language.super',
        pattern: /super(?=\.|\()/g
    },
    {
        name: 'storage.type',
        pattern: /\b(const|let|var)(?=\s)/g
    },
    {
        matches: {
            1: 'support.property'
        },
        pattern: /\.(length|node(Name|Value))\b/g
    },
    {
        matches: {
            1: 'support.function'
        },
        pattern: /(setTimeout|setInterval)(?=\()/g
    },
    {
        matches: {
            1: 'support.method'
        },
        pattern: /\.(getAttribute|replace|push|getElementById|getElementsByClassName|setTimeout|setInterval)(?=\()/g
    },

    /**
     * matches any escaped characters inside of a js regex pattern
     *
     * @see https://github.com/ccampbell/rainbow/issues/22
     *
     * this was causing single line comments to fail so it now makes sure
     * the opening / is not directly followed by a *
     *
     * The body of the regex to match a regex was borrowed from:
     * http://stackoverflow.com/a/17843773/421333
     */
    {
        name: 'string.regexp',
        matches: {
            1: 'string.regexp.open',
            2: {
                name: 'constant.regexp.escape',
                pattern: /\\(.){1}/g
            },
            3: 'string.regexp.close',
            4: 'string.regexp.modifier'
        },
        pattern: /(\/)((?![*+?])(?:[^\r\n\[/\\]|\\.|\[(?:[^\r\n\]\\]|\\.)*\])+)(\/)(?!\/)([igm]{0,3})/g
    },

    /**
     * matches runtime function declarations
     */
    {
        matches: {
            1: 'storage.type',
            3: 'entity.function'
        },
        pattern: /(var)?(\s|^)(\S+)(?=\s?=\s?function\()/g
    },

    /**
     * matches constructor call
     */
    {
        matches: {
            1: 'keyword',
            2: 'variable.type'
        },
        pattern: /(new)\s+(?!Promise)([^\(]*)(?=\()/g
    },

    /**
     * matches any function call in the style functionName: function()
     */
    {
        name: 'entity.function',
        pattern: /(\w+)(?=:\s{0,}function)/g
    },
    {
        name: 'constant.other',
        pattern: /\*(?= as)/g
    },
    {
        matches: {
            1: 'keyword',
            2: 'constant.other'
        },
        pattern: /(export)\s+(\*)/g
    },
    {
        matches: {
            1: 'storage.type.accessor',
            2: 'entity.name.function'
        },
        pattern: /(get|set)\s+(\w+)(?=\()/g
    },
    {
        matches: {
            2: 'entity.name.function'
        },
        pattern: /(^\s*)(\w+)(?=\([^\)]*?\)\s*\{)/gm
    },
    {
        matches: {
            1: 'storage.type.class',
            2: 'entity.name.class',
            3: 'storage.modifier.extends',
            4: 'entity.other.inherited-class'
        },
        pattern: /(class)\s+(\w+)(?:\s+(extends)\s+(\w+))?(?=\s*\{)/g
    },
    {
        name: 'storage.type.function.arrow',
        pattern: /=&gt;/g
    },
    {
        name: 'support.class.promise',
        pattern: /\bPromise(?=(\(|\.))/g
    }
], 'generic');

Rainbow.addAlias('js', 'javascript');

/**
 * JSON patterns
 *
 * @author Nijiko Yonskai
 * @author Craig Campbell
 */
Rainbow.extend('json', [
    {
        matches: {
            0: {
                name: 'string',
                matches: {
                    name: 'constant.character.escape',
                    pattern: /\\('|"){1}/g
                }
            }
        },
        pattern: /(\"|\')(\\?.)*?\1/g
    },
    {
        name: 'constant.numeric',
        pattern: /\b(-?(0x)?\d*\.?[\da-f]+|NaN|-?Infinity)\b/gi
    },
    {
        name: 'constant.language',
        pattern: /\b(true|false|null)\b/g
    }
]);
/**
 * Lua patterns
 *
 * @author Javier Aguirre
 */
Rainbow.extend('lua', [
    {
        matches: {
            1: {
                name: 'keyword.operator',
                pattern: /\=/g
            },
            2: {
                name: 'string',
                matches: {
                    name: 'constant.character.escape',
                    pattern: /\\('|"){1}/g
                }
            }
        },
        pattern: /(\(|\s|\[|\=)(('|")([^\\\1]|\\.)*?(\3))/gm
    },
    {
        name: 'comment',
        pattern: /\-{2}\[{2}\-{2}[\s\S]*?\-{2}\]{2}\-{2}|(\-{2})[\s\S]*?$/gm
    },
    {
        name: 'constant.numeric',
        pattern: /\b(\d+(\.\d+)?(e(\+|\-)?\d+)?(f|d)?|0x[\da-f]+)\b/gi
    },
    {
        matches: {
            1: 'keyword'
        },
        pattern: /\b((a|e)nd|in|repeat|break|local|return|do|for|then|else(if)?|function|not|if|or|until|while)(?=\b)/gi
    },
    {
        name: 'constant.language',
        pattern: /true|false|nil/g
    },
    {
        name: 'keyword.operator',
        pattern: /\+|\!|\-|&(gt|lt|amp);|\||\*|\=|#|\.{2}/g
    },
    {
        matches: {
            1: 'storage.function',
            2: 'entity.name.function'
        },
        pattern: /(function)\s+(\w+[\:|\.]?\w+?)(?=\()/g
    },
    {
        matches: {
            1: 'support.function'
        },
        pattern: /\b(print|require|module|\w+\.\w+)(?=\()/g
    }
]);
/**
 * PHP patterns
 *
 * @author Craig Campbell
 */
Rainbow.extend('php', [
    {
        name: 'support',
        pattern: /\becho\b/ig
    },
    {
        matches: {
            1: 'variable.dollar-sign',
            2: 'variable'
        },
        pattern: /(\$)(\w+)\b/g
    },
    {
        name: 'constant.language',
        pattern: /true|false|null/ig
    },
    {
        name: 'constant',
        pattern: /\b[A-Z0-9_]{2,}\b/g
    },
    {
        name: 'keyword.dot',
        pattern: /\./g
    },
    {
        name: 'keyword',
        pattern: /\b(die|end(for(each)?|switch|if)|case|require(_once)?|include(_once)?)(?=\b)/ig
    },
    {
        matches: {
            1: 'keyword',
            2: {
                name: 'support.class',
                pattern: /\w+/g
            }
        },
        pattern: /(instanceof)\s([^\$].*?)(\)|;)/ig
    },

    /**
     * these are the top 50 most used PHP functions
     * found from running a script and checking the frequency of each function
     * over a bunch of popular PHP frameworks then combining the results
     */
    {
        matches: {
            1: 'support.function'
        },
        pattern: /\b(array(_key_exists|_merge|_keys|_shift)?|isset|count|empty|unset|printf|is_(array|string|numeric|object)|sprintf|each|date|time|substr|pos|str(len|pos|tolower|_replace|totime)?|ord|trim|in_array|implode|end|preg_match|explode|fmod|define|link|list|get_class|serialize|file|sort|mail|dir|idate|log|intval|header|chr|function_exists|dirname|preg_replace|file_exists)(?=\()/ig
    },
    {
        name: 'variable.language.php-tag',
        pattern: /(&lt;\?(php)?|\?&gt;)/ig
    },
    {
        matches: {
            1: 'keyword.namespace',
            2: {
                name: 'support.namespace',
                pattern: /\w+/g
            }
        },
        pattern: /\b(namespace|use)\s(.*?);/ig
    },
    {
        matches: {
            1: 'storage.modifier',
            2: 'storage.class',
            3: 'entity.name.class',
            4: 'storage.modifier.extends',
            5: 'entity.other.inherited-class',
            6: 'storage.modifier.extends',
            7: 'entity.other.inherited-class'
        },
        pattern: /\b(abstract|final)?\s?(class|interface|trait)\s(\w+)(\sextends\s)?([\w\\]*)?(\simplements\s)?([\w\\]*)?\s?\{?(\n|\})/ig
    },
    {
        name: 'keyword.static',
        pattern: /self::|static::/ig
    },
    {
        matches: {
            1: 'storage.function',
            2: 'entity.name.function.magic'
        },
        pattern: /(function)\s(__.*?)(?=\()/ig
    },
    {
        matches: {
            1: 'storage.function',
            2: 'entity.name.function'
        },
        pattern: /(function)\s(.*?)(?=\()/ig
    },
    {
        matches: {
            1: 'keyword.new',
            2: {
                name: 'support.class',
                pattern: /\w+/g
            }
        },
        pattern: /\b(new)\s([^\$][a-z0-9_\\]*?)(?=\)|\(|;)/ig
    },
    {
        matches: {
            1: {
                name: 'support.class',
                pattern: /\w+/g
            },
            2: 'keyword.static'
        },
        pattern: /([\w\\]*?)(::)(?=\b|\$)/g
    },
    {
        matches: {
            2: {
                name: 'support.class',
                pattern: /\w+/g
            }
        },
        pattern: /(\(|,\s?)([\w\\]*?)(?=\s\$)/g
    }
], 'generic');
/**
 * Python patterns
 *
 * @author Craig Campbell
 */
Rainbow.extend('python', [
    /**
     * don't highlight self as a keyword
     */
    {
        name: 'variable.self',
        pattern: /self/g
    },
    {
        name: 'constant.language',
        pattern: /None|True|False|NotImplemented|\.\.\./g
    },
    {
        name: 'support.object',
        pattern: /object/g
    },

    /**
     * built in python functions
     *
     * this entire list is 580 bytes minified / 379 bytes gzipped
     *
     * @see http://docs.python.org/library/functions.html
     *
     * @todo strip some out or consolidate the regexes with matching patterns?
     */
    {
        name: 'support.function.python',
        pattern: /\b(bs|divmod|input|open|staticmethod|all|enumerate|int|ord|str|any|eval|isinstance|pow|sum|basestring|execfile|issubclass|print|super|bin|file|iter|property|tuple|bool|filter|len|range|type|bytearray|float|list|raw_input|unichr|callable|format|locals|reduce|unicode|chr|frozenset|long|reload|vars|classmethod|getattr|map|repr|xrange|cmp|globals|max|reversed|zip|compile|hasattr|memoryview|round|__import__|complex|hash|min|set|apply|delattr|help|next|setattr|buffer|dict|hex|object|slice|coerce|dir|id|oct|sorted|intern)(?=\()/g
    },
    {
        matches: {
            1: 'keyword'
        },
        pattern: /\b(pass|lambda|with|is|not|in|from|elif|raise|del)(?=\b)/g
    },
    {
        matches: {
            1: 'storage.class',
            2: 'entity.name.class',
            3: 'entity.other.inherited-class'
        },
        pattern: /(class)\s+(\w+)\((\w+?)\)/g
    },
    {
        matches: {
            1: 'storage.function',
            2: 'support.magic'
        },
        pattern: /(def)\s+(__\w+)(?=\()/g
    },
    {
        name: 'support.magic',
        pattern: /__(name)__/g
    },
    {
        matches: {
            1: 'keyword.control',
            2: 'support.exception.type'
        },
        pattern: /(except) (\w+):/g
    },
    {
        matches: {
            1: 'storage.function',
            2: 'entity.name.function'
        },
        pattern: /(def)\s+(\w+)(?=\()/g
    },
    {
        name: 'entity.name.function.decorator',
        pattern: /@([\w\.]+)/g
    },
    {
        name: 'comment.docstring',
        pattern: /('{3}|"{3})[\s\S]*?\1/gm
    }
], 'generic');
/**
 * R language patterns
 *
 * @author Simon Potter
 */
Rainbow.extend('r', [
    /**
     * Note that a valid variable name is of the form:
     * [.a-zA-Z][0-9a-zA-Z._]*
     */
    {
        matches: {
            1: {
                name: 'keyword.operator',
                pattern: /\=|<\-|&lt;-/g
            },
            2: {
                name: 'string',
                matches: {
                    name: 'constant.character.escape',
                    pattern: /\\('|"){1}/g
                }
            }
        },
        pattern: /(\(|\s|\[|\=|:)(('|")([^\\\1]|\\.)*?(\3))/gm
    },

    /**
     * Most of these are known via the Language Reference.
     * The built-in constant symbols are known via ?Constants.
     */
    {
        matches: {
            1: 'constant.language'
        },
        pattern: /\b(NULL|NA|TRUE|FALSE|T|F|NaN|Inf|NA_integer_|NA_real_|NA_complex_|NA_character_)\b/g
    },
    {
        matches: {
            1: 'constant.symbol'
        },
        pattern: /[^0-9a-zA-Z\._](LETTERS|letters|month\.(abb|name)|pi)/g
    },

    /**
     * @todo: The list subsetting operator isn't quite working properly.
     *        It includes the previous variable when it should only match [[
     */
    {
        name: 'keyword.operator',
        pattern: /&lt;-|<-|-|==|&lt;=|<=|&gt;>|>=|<|>|&amp;&amp;|&&|&amp;|&|!=|\|\|?|\*|\+|\^|\/|%%|%\/%|\=|%in%|%\*%|%o%|%x%|\$|:|~|\[{1,2}|\]{1,2}/g
    },
    {
        matches: {
            1: 'storage',
            3: 'entity.function'
        },
        pattern: /(\s|^)(.*)(?=\s?=\s?function\s\()/g
    },
    {
        matches: {
            1: 'storage.function'
        },
        pattern: /[^a-zA-Z0-9._](function)(?=\s*\()/g
    },
    {
        matches: {
            1: 'namespace',
            2: 'keyword.operator',
            3: 'function.call'
        },
        pattern: /([a-zA-Z][a-zA-Z0-9._]+)([:]{2,3})([.a-zA-Z][a-zA-Z0-9._]*(?=\s*\())\b/g
    },

    /*
     * Note that we would perhaps match more builtin functions and
     * variables, but there are so many that most are ommitted for now.
     * See ?builtins for more info.
     *
     * @todo: Fix the case where we have a function like tmp.logical().
     *        This should just be a function call, at the moment it's
     *        only partly a function all.
     */
    {
        name: 'support.function',
        pattern: /(^|[^0-9a-zA-Z\._])(array|character|complex|data\.frame|double|integer|list|logical|matrix|numeric|vector)(?=\s*\()/g
    }
], 'generic');
/**
 * Ruby patterns
 *
 * @author Matthew King
 * @author Jesse Farmer <jesse@20bits.com>
 * @author actsasflinn
 */

Rainbow.extend('ruby', [
    /**
    * __END__ DATA
    */
    {
        matches: {
            1: 'variable.language',
            2: {
              language: null
            }
        },
        //find __END__ and consume remaining text
        pattern: /^(__END__)\n((?:.*\n)*)/gm
    },
    /**
     * Strings
     *   1. No support for multi-line strings
     */
    {
        name: 'string',
        matches: {
            1: 'string.open',
            2: [{
                name: 'string.interpolation',
                matches: {
                    1: 'string.open',
                    2: {
                      language: 'ruby'
                    },
                    3: 'string.close'
                },
                pattern: /(\#\{)(.*?)(\})/g
            }],
            3: 'string.close'
        },
        pattern: /("|`)(.*?[^\\\1])?(\1)/g
    },
    {
        name: 'string',
        pattern: /('|"|`)([^\\\1\n]|\\.)*?\1/g
    },
    {
        name: 'string',
        pattern: /%[qQ](?=(\(|\[|\{|&lt;|.)(.*?)(?:'|\)|\]|\}|&gt;|\1))(?:\(\2\)|\[\2\]|\{\2\}|\&lt;\2&gt;|\1\2\1)/g
    },
    /**
     * Heredocs
     * Heredocs of the form `<<'HTML' ... HTML` are unsupported.
     */
    {
        matches: {
            1: 'string',
            2: 'string',
            3: 'string'
        },
        pattern: /(&lt;&lt;)(\w+).*?$([\s\S]*?^\2)/gm
    },
    {
        matches: {
            1: 'string',
            2: 'string',
            3: 'string'
        },
        pattern: /(&lt;&lt;\-)(\w+).*?$([\s\S]*?\2)/gm
    },
    /**
     * Regular expressions
     * Escaped delimiter (`/\//`) is unsupported.
     */
    {
        name: 'string.regexp',
        matches: {
            1: 'string.regexp',
            2: {
                name: 'string.regexp',
                pattern: /\\(.){1}/g
            },
            3: 'string.regexp',
            4: 'string.regexp'
        },
        pattern: /(\/)(.*?)(\/)([a-z]*)/g
    },
    {
        name: 'string.regexp',
        matches: {
            1: 'string.regexp',
            2: {
                name: 'string.regexp',
                pattern: /\\(.){1}/g
            },
            3: 'string.regexp',
            4: 'string.regexp'
        },
        pattern: /%r(?=(\(|\[|\{|&lt;|.)(.*?)('|\)|\]|\}|&gt;|\1))(?:\(\2\)|\[\2\]|\{\2\}|\&lt;\2&gt;|\1\2\1)([a-z]*)/g
    },
    /**
     * Comments
     */
    {
        name: 'comment',
        pattern: /#.*$/gm
    },
    {
        name: 'comment',
        pattern: /^\=begin[\s\S]*?\=end$/gm
    },
    /**
     * Symbols
     */
    {
        matches: {
            1: 'constant'
        },
        pattern: /(\w+:)[^:]/g
    },
    {
        matches: {
            1: 'constant.symbol'
        },
        pattern: /[^:](:(?:\w+|(?=['"](.*?)['"])(?:"\2"|'\2')))/g
    },
    {
        name: 'constant.numeric',
        pattern: /\b(0x[\da-f]+|[\d_]+)\b/g
    },
    {
        name: 'support.class',
        pattern: /\b[A-Z]\w*(?=((\.|::)[A-Za-z]|\[))/g
    },
    {
        name: 'constant',
        pattern: /\b[A-Z]\w*\b/g
    },
    /**
     * Keywords, variables, constants, and operators
     *   In Ruby some keywords are valid method names, e.g., MyClass#yield
     *   Don't mark those instances as "keywords"
     */
    {
        matches: {
            1: 'storage.class',
            2: 'entity.name.class',
            3: 'entity.other.inherited-class'
        },
        pattern: /\s*(class)\s+((?:(?:::)?[A-Z]\w*)+)(?:\s+&lt;\s+((?:(?:::)?[A-Z]\w*)+))?/g
    },
    {
        matches: {
            1: 'storage.module',
            2: 'entity.name.class'
        },
        pattern: /\s*(module)\s+((?:(?:::)?[A-Z]\w*)+)/g
    },
    {
        name: 'variable.global',
        pattern: /\$([a-zA-Z_]\w*)\b/g
    },
    {
        name: 'variable.class',
        pattern: /@@([a-zA-Z_]\w*)\b/g
    },
    {
        name: 'variable.instance',
        pattern: /@([a-zA-Z_]\w*)\b/g
    },
    {
        matches: {
            1: 'keyword.control'
        },
        pattern: /[^\.]\b(BEGIN|begin|case|class|do|else|elsif|END|end|ensure|for|if|in|module|rescue|then|unless|until|when|while)\b(?![?!])/g
    },
    {
        matches: {
            1: 'keyword.control.pseudo-method'
        },
        pattern: /[^\.]\b(alias|alias_method|break|next|redo|retry|return|super|undef|yield)\b(?![?!])|\bdefined\?|\bblock_given\?/g
    },
    {
        matches: {
            1: 'constant.language'
        },
        pattern: /\b(nil|true|false)\b(?![?!])/g
    },
    {
        matches: {
            1: 'variable.language'
        },
        pattern: /\b(__(FILE|LINE)__|self)\b(?![?!])/g
    },
    {
        matches: {
            1: 'keyword.special-method'
        },
        pattern: /\b(require|gem|initialize|new|loop|include|extend|raise|attr_reader|attr_writer|attr_accessor|attr|catch|throw|private|module_function|public|protected)\b(?![?!])/g
    },
    {
        name: 'keyword.operator',
        pattern: /\s\?\s|=|&lt;&lt;|&lt;&lt;=|%=|&=|\*=|\*\*=|\+=|\-=|\^=|\|{1,2}=|&lt;&lt;|&lt;=&gt;|&lt;(?!&lt;|=)|&gt;(?!&lt;|=|&gt;)|&lt;=|&gt;=|===|==|=~|!=|!~|%|&amp;|\*\*|\*|\+|\-|\/|\||~|&gt;&gt;/g
    },
    {
        matches: {
            1: 'keyword.operator.logical'
        },
        pattern: /[^\.]\b(and|not|or)\b/g
    },

    /**
    * Functions
    *   1. No support for marking function parameters
    */
    {
        matches: {
            1: 'storage.function',
            2: 'entity.name.function'
        },
        pattern: /(def)\s(.*?)(?=(\s|\())/g
    }
]);
/**
 * Scheme patterns
 *
 * @author Alex Queiroz <alex@artisancoder.com>
 */
Rainbow.extend('scheme', [
    {
        /* making peace with HTML */
        name: 'plain',
        pattern: /&gt;|&lt;/g
    },
    {
        name: 'comment',
        pattern: /;.*$/gm
    },
    {
        name: 'constant.language',
        pattern: /#t|#f|'\(\)/g
    },
    {
        name: 'constant.symbol',
        pattern: /'[^()\s#]+/g
    },
    {
        name: 'constant.number',
        pattern: /\b\d+(?:\.\d*)?\b/g
    },
    {
        name: 'string',
        pattern: /".+?"/g
    },
    {
        matches: {
            1: 'storage.function',
            2: 'variable'
        },
        pattern: /\(\s*(define)\s+\(?(\S+)/g
    },
    {
        matches: {
            1: 'keyword'
        },
        pattern: /\(\s*(begin|define\-syntax|if|lambda|quasiquote|quote|set!|syntax\-rules|and|and\-let\*|case|cond|delay|do|else|or|let|let\*|let\-syntax|letrec|letrec\-syntax)(?=[\]()\s#])/g
    },
    {
        matches: {
            1: 'entity.function'
        },
        pattern: /\(\s*(eqv\?|eq\?|equal\?|number\?|complex\?|real\?|rational\?|integer\?|exact\?|inexact\?|=|<|>|<=|>=|zero\?|positive\?|negative\?|odd\?|even\?|max|min|\+|\-|\*|\/|abs|quotient|remainder|modulo|gcd|lcm|numerator|denominator|floor|ceiling|truncate|round|rationalize|exp|log|sin|cos|tan|asin|acos|atan|sqrt|expt|make\-rectangular|make\-polar|real\-part|imag\-part|magnitude|angle|exact\->inexact|inexact\->exact|number\->string|string\->number|not|boolean\?|pair\?|cons|car|cdr|set\-car!|set\-cdr!|caar|cadr|cdar|cddr|caaar|caadr|cadar|caddr|cdaar|cdadr|cddar|cdddr|caaaar|caaadr|caadar|caaddr|cadaar|cadadr|caddar|cadddr|cdaaar|cdaadr|cdadar|cdaddr|cddaar|cddadr|cdddar|cddddr|null\?|list\?|list|length|append|reverse|list\-tail|list\-ref|memq|memv|member|assq|assv|assoc|symbol\?|symbol\->string|string\->symbol|char\?|char=\?|char<\?|char>\?|char<=\?|char>=\?|char\-ci=\?|char\-ci<\?|char\-ci>\?|char\-ci<=\?|char\-ci>=\?|char\-alphabetic\?|char\-numeric\?|char\-whitespace\?|char\-upper\-case\?|char\-lower\-case\?|char\->integer|integer\->char|char\-upcase|char\-downcase|string\?|make\-string|string|string\-length|string\-ref|string\-set!|string=\?|string\-ci=\?|string<\?|string>\?|string<=\?|string>=\?|string\-ci<\?|string\-ci>\?|string\-ci<=\?|string\-ci>=\?|substring|string\-append|string\->list|list\->string|string\-copy|string\-fill!|vector\?|make\-vector|vector|vector\-length|vector\-ref|vector\-set!|vector\->list|list\->vector|vector\-fill!|procedure\?|apply|map|for\-each|force|call\-with\-current\-continuation|call\/cc|values|call\-with\-values|dynamic\-wind|eval|scheme\-report\-environment|null\-environment|interaction\-environment|call\-with\-input\-file|call\-with\-output\-file|input\-port\?|output\-port\?|current\-input\-port|current\-output\-port|with\-input\-from\-file|with\-output\-to\-file|open\-input\-file|open\-output\-file|close\-input\-port|close\-output\-port|read|read\-char|peek\-char|eof\-object\?|char\-ready\?|write|display|newline|write\-char|load|transcript\-on|transcript\-off)(?=[\]()\s#])/g
    }
]);
/**
 * Shell patterns
 *
 * @author Matthew King
 * @author Craig Campbell
 */
Rainbow.extend('shell', [
    /**
     * This handles the case where subshells contain quotes.
     * For example: `"$(resolve_link "$name" || true)"`.
     *
     * Caveat: This really should match balanced parentheses, but cannot.
     * @see http://stackoverflow.com/questions/133601/can-regular-expressions-be-used-to-match-nested-patterns
     */
    {
        name: 'shell',
        matches: {
            1: {
                language: 'shell'
            }
        },
        pattern: /\$\(([\s\S]*?)\)/gm
    },
    {
        matches: {
            2: 'string'
        },
        pattern: /(\(|\s|\[|\=)(('|")[\s\S]*?(\3))/gm
    },
    {
        name: 'keyword.operator',
        pattern: /&lt;|&gt;|&amp;/g
    },
    {
        name: 'comment',
        pattern: /\#[\s\S]*?$/gm
    },
    {
        name: 'storage.function',
        pattern: /(.+?)(?=\(\)\s{0,}\{)/g
    },
    /**
     * Environment variables
     */
    {
        name: 'support.command',
        pattern: /\b(echo|rm|ls|(mk|rm)dir|cd|find|cp|exit|pwd|exec|trap|source|shift|unset)/g
    },
    {
        matches: {
            1: 'keyword'
        },
        pattern: /\b(break|case|continue|do|done|elif|else|esac|eval|export|fi|for|function|if|in|local|return|set|then|unset|until|while)(?=\b)/g
    }
]);
/**
 * Smalltalk patterns
 *
 * @author Frank Shearar <frank@angband.za.org>
 */
Rainbow.extend('smalltalk', [
    {
        name: 'keyword.pseudovariable',
        pattern: /self|thisContext/g
    },
    {
        name: 'keyword.constant',
        pattern: /false|nil|true/g
    },
    {
        name: 'string',
        pattern: /'([^']|'')*'/g
    },
    {
        name: 'string.symbol',
        pattern: /#\w+|#'([^']|'')*'/g
    },
    {
        name: 'string.character',
        pattern: /\$\w+/g
    },
    {
        name: 'comment',
        pattern: /"([^"]|"")*"/g
    },
    {
        name: 'constant.numeric',
        pattern: /-?\d+(\.\d+)?((r-?|s)[A-Za-z0-9]+|e-?[0-9]+)?/g
    },
    {
        name: 'entity.name.class',
        pattern: /\b[A-Z]\w*/g
    },
    {
        name: 'entity.name.function',
        pattern: /\b[a-z]\w*:?/g
    },
    {
        name: 'entity.name.binary',
        pattern: /(&lt;|&gt;|&amp;|[=~\|\\\/!@*\-_+])+/g
    },
    {
        name: 'operator.delimiter',
        pattern: /;[\(\)\[\]\{\}]|#\[|#\(^\./g
    }
]);
/**
 * SQL Language
 *
 * @author Jan Navratil
 * @author Craig Campbell
 */
Rainbow.extend('sql', [
    {
        matches: {
            2: {
                name: 'string',
                matches: {
                    name: 'constant.character.escape',
                    pattern: /\\('|"|`){1}/g
                }
            }
        },
        pattern: /(\(|\s|\[|\=|:|\+|\.|\{|,)(('|"|`)([^\\\1]|\\.)*?(\3))/gm
    },
    {
        name: 'comment',
        pattern: /--.*$|\/\*[\s\S]*?\*\/|(\/\/)[\s\S]*?$/gm
    },
    {
        name: 'constant.numeric',
        pattern: /\b(\d+(\.\d+)?(e(\+|\-)?\d+)?(f|d)?|0x[\da-f]+)\b/gi
    },
    {
        name: 'function.call',
        pattern: /(\w+?)(?=\()/g
    },
    {
        name: 'keyword',
        pattern: /\b(ABSOLUTE|ACTION|ADA|ADD|ALL|ALLOCATE|ALTER|AND|ANY|ARE|AS|ASC|ASSERTION|AT|AUTHORIZATION|AVG|BEGIN|BETWEEN|BIT|BIT_LENGTH|BOTH|BY|CASCADE|CASCADED|CASE|CAST|CATALOG|CHAR|CHARACTER|CHARACTER_LENGTH|CHAR_LENGTH|CHECK|CLOSE|COALESCE|COLLATE|COLLATION|COLUMN|COMMIT|CONNECT|CONNECTION|CONSTRAINT|CONSTRAINTS|CONTINUE|CONVERT|CORRESPONDING|COUNT|CREATE|CROSS|CURRENT|CURRENT_DATE|CURRENT_TIME|CURRENT_TIMESTAMP|CURRENT_USER|CURSOR|DATE|DAY|DEALLOCATE|DEC|DECIMAL|DECLARE|DEFAULT|DEFERRABLE|DEFERRED|DELETE|DESC|DESCRIBE|DESCRIPTOR|DIAGNOSTICS|DISCONNECT|DISTINCT|DOMAIN|DOUBLE|DROP|ELSE|END|END-EXEC|ESCAPE|EXCEPT|EXCEPTION|EXEC|EXECUTE|EXISTS|EXTERNAL|EXTRACT|FALSE|FETCH|FIRST|FLOAT|FOR|FOREIGN|FORTRAN|FOUND|FROM|FULL|GET|GLOBAL|GO|GOTO|GRANT|GROUP|HAVING|HOUR|IDENTITY|IMMEDIATE|IN|INCLUDE|INDEX|INDICATOR|INITIALLY|INNER|INPUT|INSENSITIVE|INSERT|INT|INTEGER|INTERSECT|INTERVAL|INTO|IS|ISOLATION|JOIN|KEY|LANGUAGE|LAST|LEADING|LEFT|LEVEL|LIKE|LIMIT|LOCAL|LOWER|MATCH|MAX|MIN|MINUTE|MODULE|MONTH|NAMES|NATIONAL|NATURAL|NCHAR|NEXT|NO|NONE|NOT|NULL|NULLIF|NUMERIC|OCTET_LENGTH|OF|ON|ONLY|OPEN|OPTION|OR|ORDER|OUTER|OUTPUT|OVERLAPS|PAD|PARTIAL|PASCAL|POSITION|PRECISION|PREPARE|PRESERVE|PRIMARY|PRIOR|PRIVILEGES|PROCEDURE|PUBLIC|READ|REAL|REFERENCES|RELATIVE|RESTRICT|REVOKE|RIGHT|ROLLBACK|ROWS|SCHEMA|SCROLL|SECOND|SECTION|SELECT|SESSION|SESSION_USER|SET|SIZE|SMALLINT|SOME|SPACE|SQL|SQLCA|SQLCODE|SQLERROR|SQLSTATE|SQLWARNING|SUBSTRING|SUM|SYSTEM_USER|TABLE|TEMPORARY|THEN|TIME|TIMESTAMP|TIMEZONE_HOUR|TIMEZONE_MINUTE|TO|TRAILING|TRANSACTION|TRANSLATE|TRANSLATION|TRIM|TRUE|UNION|UNIQUE|UNKNOWN|UPDATE|UPPER|USAGE|USER|USING|VALUE|VALUES|VARCHAR|VARYING|VIEW|WHEN|WHENEVER|WHERE|WITH|WORK|WRITE|YEAR|ZONE|USE)(?=\b)/gi
    },
    {
        name: 'keyword.operator',
        pattern: /\+|\!|\-|&(gt|lt|amp);|\||\*|=/g
    }
]);
