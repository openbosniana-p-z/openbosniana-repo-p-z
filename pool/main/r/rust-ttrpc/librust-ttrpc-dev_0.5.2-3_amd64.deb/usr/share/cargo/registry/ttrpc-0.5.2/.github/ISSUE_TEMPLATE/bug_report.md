---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

# Description of problem

(replace this text with the list of steps you followed)

# Expected result

(replace this text with an explanation of what you thought would happen)

# Actual result

(replace this text with details of what actually happened)
