#![cfg_attr(feature = "nightly", feature(backtrace))]

#[macro_use]
extern crate derive_more;

mod error;
