# `build_const`: crate for creating constants in your build script

Rust library for creating importable constants from build.rs or a script

See the [crate documentation](https://docs.rs/build_const)
and the crate on [crates.io](https://crates.io/crates/build_const)
