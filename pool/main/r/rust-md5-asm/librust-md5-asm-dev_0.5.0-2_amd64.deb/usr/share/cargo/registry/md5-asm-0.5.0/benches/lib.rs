#![no_std]
#![feature(test)]

extern crate test;

use test::Bencher;

#[cfg(any(target_arch = "x86_64", target_arch = "x86"))]
#[bench]
fn bench_compress(b: &mut Bencher) {
    let mut state = Default::default();
    let data = [[0u8; 64]];

    b.iter(|| {
        md5_asm::compress(&mut state, &data);
    });

    b.bytes = data.len() as u64;
}
