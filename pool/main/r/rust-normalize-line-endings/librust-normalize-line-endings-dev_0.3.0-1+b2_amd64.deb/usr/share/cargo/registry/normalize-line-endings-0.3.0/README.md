# Normalize-line-endings

Consume an `Iterator<Item=char>` and return another with normalized line
endings.

[documentation]

[documentation]: https://docs.rs/normalize-line-endings
