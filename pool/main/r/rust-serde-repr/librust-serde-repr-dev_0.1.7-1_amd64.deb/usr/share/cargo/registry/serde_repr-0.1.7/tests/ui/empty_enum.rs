use serde_repr::Serialize_repr;

#[derive(Serialize_repr)]
enum SmallPrime {}

fn main() {}
