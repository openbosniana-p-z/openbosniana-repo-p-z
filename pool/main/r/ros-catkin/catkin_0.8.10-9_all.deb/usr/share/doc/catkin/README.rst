.. image:: https://www.gravatar.com/avatar/ebfbbd6f16ce1f0dc30fc7c82c38d688
   :width: 100px

catkin
======

Catkin is a collection of cmake macros and associated python code used
to build some parts of `ROS <http://www.ros.org>`_

Documentation
-------------

http://ros.org/doc/api/catkin/html/
