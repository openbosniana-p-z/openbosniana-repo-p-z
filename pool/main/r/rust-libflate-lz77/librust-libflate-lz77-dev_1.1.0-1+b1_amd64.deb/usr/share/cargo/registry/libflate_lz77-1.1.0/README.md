libflate_lz77
=============

[![libflate_lz77](https://img.shields.io/crates/v/libflate_lz77.svg)](https://crates.io/crates/libflate_lz77)
[![Documentation](https://docs.rs/libflate_lz77/badge.svg)](https://docs.rs/libflate_lz77)
[![Build Status](https://travis-ci.org/sile/libflate.svg?branch=master)](https://travis-ci.org/sile/libflate)
[![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

The interface and implementations of LZ77 compression algorithm for [libflate].

[libflate]: https://github.com/sile/libflate
