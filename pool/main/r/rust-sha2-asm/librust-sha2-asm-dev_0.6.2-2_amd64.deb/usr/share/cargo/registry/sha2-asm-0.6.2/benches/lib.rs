#![feature(test)]

extern crate test;

use test::Bencher;

#[cfg(any(target_arch = "x86_64", target_arch = "x86", target_arch = "aarch64"))]
#[cfg(target_arch = "aarch64")]
cpufeatures::new!(hwsuitable, "sha2");
#[cfg(any(target_arch = "x86_64", target_arch = "x86"))]
cpufeatures::new!(hwsuitable, "sha", "sse2", "ssse3", "sse4.1");

#[cfg(any(target_arch = "x86_64", target_arch = "x86", target_arch = "aarch64"))]
#[bench]
fn bench_compress256(b: &mut Bencher) {
    if !hwsuitable::get() {
        println!("your hardware is not suitable for the assemnbler implementations in this crate, skipping bench");
        return;
    }
    let mut state = Default::default();
    let data = [[0u8; 64]];

    b.iter(|| {
        sha2_asm::compress256(&mut state, &data);
    });

    b.bytes = data.len() as u64;
}

#[cfg(any(target_arch = "x86_64", target_arch = "x86"))]
#[bench]
fn bench_compress512(b: &mut Bencher) {
    if !hwsuitable::get() {
        println!("your hardware is not suitable for the assemnbler implementations in this crate, skipping bench");
        return;
    }
    let mut state = Default::default();
    let data = [[0u8; 128]];

    b.iter(|| {
        sha2_asm::compress512(&mut state, &data);
    });

    b.bytes = data.len() as u64;
}
