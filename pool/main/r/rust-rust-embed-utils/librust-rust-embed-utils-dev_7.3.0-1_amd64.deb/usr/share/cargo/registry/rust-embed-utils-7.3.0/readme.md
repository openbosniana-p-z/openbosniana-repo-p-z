# Rust Embed Utilities

The utilities used by rust-embed and rust-embed-impl lie here.
