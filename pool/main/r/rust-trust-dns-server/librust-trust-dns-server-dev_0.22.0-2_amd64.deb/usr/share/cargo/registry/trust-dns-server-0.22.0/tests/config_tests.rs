/*
 * Copyright (C) 2015 Benjamin Fry <benjaminfry@me.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
use std::env;
use std::net::{Ipv4Addr, Ipv6Addr};
use std::path::{Path, PathBuf};
use std::time::Duration;

use trust_dns_server::authority::ZoneType;
use trust_dns_server::config::*;

#[test]
fn test_parse_toml() {
    let config: Config = "listen_port = 2053".parse().unwrap();
    assert_eq!(config.get_listen_port(), 2053);

    let config: Config = "listen_addrs_ipv4 = [\"0.0.0.0\"]".parse().unwrap();
    assert_eq!(
        config.get_listen_addrs_ipv4(),
        Ok(vec![Ipv4Addr::new(0, 0, 0, 0)])
    );

    let config: Config = "listen_addrs_ipv4 = [\"0.0.0.0\", \"127.0.0.1\"]"
        .parse()
        .unwrap();
    assert_eq!(
        config.get_listen_addrs_ipv4(),
        Ok(vec![Ipv4Addr::new(0, 0, 0, 0), Ipv4Addr::new(127, 0, 0, 1)])
    );

    let config: Config = "listen_addrs_ipv6 = [\"::0\"]".parse().unwrap();
    assert_eq!(
        config.get_listen_addrs_ipv6(),
        Ok(vec![Ipv6Addr::new(0, 0, 0, 0, 0, 0, 0, 0)])
    );

    let config: Config = "listen_addrs_ipv6 = [\"::0\", \"::1\"]".parse().unwrap();
    assert_eq!(
        config.get_listen_addrs_ipv6(),
        Ok(vec![
            Ipv6Addr::new(0, 0, 0, 0, 0, 0, 0, 0),
            Ipv6Addr::new(0, 0, 0, 0, 0, 0, 0, 1),
        ])
    );

    let config: Config = "tcp_request_timeout = 25".parse().unwrap();
    assert_eq!(config.get_tcp_request_timeout(), Duration::from_secs(25));

    let config: Config = "log_level = \"Debug\"".parse().unwrap();
    assert_eq!(config.get_log_level(), tracing::Level::DEBUG);

    let config: Config = "directory = \"/dev/null\"".parse().unwrap();
    assert_eq!(config.get_directory(), Path::new("/dev/null"));
}

#[cfg(feature = "dnssec")]
#[test]
fn test_parse_zone_keys() {
    use trust_dns_client::rr::dnssec::Algorithm;
    use trust_dns_client::rr::Name;

    let config: Config = "
[[zones]]
zone = \"example.com\"
zone_type = \"Primary\"
file = \"example.com.zone\"

\
         [[zones.keys]]
key_path = \"/path/to/my_ed25519.pem\"
algorithm = \"ED25519\"
\
         signer_name = \"ns.example.com.\"
is_zone_signing_key = false
is_zone_update_auth = true

[[zones.keys]]
key_path = \"/path/to/my_rsa.pem\"
algorithm = \
         \"RSASHA256\"
signer_name = \"ns.example.com.\"

"
    .parse()
    .unwrap();
    assert_eq!(
        config.get_zones()[0].get_keys()[0].key_path(),
        Path::new("/path/to/my_ed25519.pem")
    );
    assert_eq!(
        config.get_zones()[0].get_keys()[0].algorithm().unwrap(),
        Algorithm::ED25519
    );
    assert_eq!(
        config.get_zones()[0].get_keys()[0]
            .signer_name()
            .unwrap()
            .unwrap(),
        Name::parse("ns.example.com.", None).unwrap()
    );
    assert!(!config.get_zones()[0].get_keys()[0].is_zone_signing_key(),);
    assert!(config.get_zones()[0].get_keys()[0].is_zone_update_auth(),);

    assert_eq!(
        config.get_zones()[0].get_keys()[1].key_path(),
        Path::new("/path/to/my_rsa.pem")
    );
    assert_eq!(
        config.get_zones()[0].get_keys()[1].algorithm().unwrap(),
        Algorithm::RSASHA256
    );
    assert_eq!(
        config.get_zones()[0].get_keys()[1]
            .signer_name()
            .unwrap()
            .unwrap(),
        Name::parse("ns.example.com.", None).unwrap()
    );
    assert!(!config.get_zones()[0].get_keys()[1].is_zone_signing_key(),);
    assert!(!config.get_zones()[0].get_keys()[1].is_zone_update_auth(),);
}

#[test]
#[cfg(feature = "dnssec")]
fn test_parse_tls() {
    // defaults
    let config: Config = "".parse().unwrap();

    assert_eq!(config.get_tls_listen_port(), 853);
    assert_eq!(config.get_tls_cert(), None);

    let config: Config = "
tls_cert = { path = \"path/to/some.pkcs12\", endpoint_name = \"ns.example.com\" }
tls_listen_port = 8853
  "
    .parse()
    .unwrap();

    assert_eq!(config.get_tls_listen_port(), 8853);
    assert_eq!(
        config.get_tls_cert().unwrap().get_path(),
        Path::new("path/to/some.pkcs12")
    );
}
