# Changelog

## 1.0.0

* Added support for UNIX Datagram sockets.
* Update to UUID 1.0.

## 0.5.0

* File descriptors on UNIX now set `FD_CLOEXEC`.
