# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 0.5.x   | :white_check_mark: |
| < 0.5   | :x:                |

## Reporting a Vulnerability

Please email the address listed at [https://github.com/cardoe](https://github.com/cardoe)
and include the name of the crate and the fact that its security related in the subject.
