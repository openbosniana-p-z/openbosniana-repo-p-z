use log::*;

#[cfg(feature = "timestamps")]
#[test]
fn quiet_trace_level() {
    stderrlog::new()
        .module(module_path!())
        .timestamp(stderrlog::Timestamp::Second)
        .verbosity(4)
        .quiet(true)
        .init()
        .unwrap();

    error!("error msg");
    warn!("warning msg");
    info!("info msg");
    debug!("debug msg");
    trace!("trace msg");

    assert_eq!(log::LevelFilter::Off, log::max_level())
}
