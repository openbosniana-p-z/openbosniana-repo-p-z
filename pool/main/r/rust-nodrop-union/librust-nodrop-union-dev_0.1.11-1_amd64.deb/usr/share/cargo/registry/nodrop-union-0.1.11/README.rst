
Recent Changes (nodrop-union)
-----------------------

- 0.1.11

  - Mark nodrop deprecated

    With the release of arrayvec 0.5, nodrop is unused.

    With the release of Rust 1.36 and MaybeUninit, nodrop-union has no
    purpose at all (it was only for nightly releases).

- 0.1.10

  - Update to include license files in the crate by @ignatenkobrain

- 0.1.9

  - Add ``Copy, Clone`` implementations

- 0.1.8

  - Initial release

