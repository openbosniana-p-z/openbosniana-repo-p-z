# hyphenation commons

Proemial code for `hyphenation`. Mostly internal, slightly haphazard, leastly dependable.
