use crate::task::{noop_waker_ref, panic_waker_ref};
use futures_core::task::Context;

/// Create a new [`Context`](core::task::Context) where the
/// [waker](core::task::Context::waker) will panic if used.
///
pub fn panic_context() -> Context<'static> {
    Context::from_waker(panic_waker_ref())
}

/// Create a new [`Context`](core::task::Context) where the
/// [waker](core::task::Context::waker) will ignore any uses.
///
pub fn noop_context() -> Context<'static> {
    Context::from_waker(noop_waker_ref())
}
