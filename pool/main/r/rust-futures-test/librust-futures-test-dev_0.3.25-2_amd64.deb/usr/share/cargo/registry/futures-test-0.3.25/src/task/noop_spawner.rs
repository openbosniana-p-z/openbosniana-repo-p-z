use futures_task::{FutureObj, Spawn, SpawnError};

/// An implementation of [`Spawn`](futures_task::Spawn) that
/// discards spawned futures when used.
///
#[derive(Debug)]
pub struct NoopSpawner {
    _reserved: (),
}

impl NoopSpawner {
    /// Create a new instance
    pub fn new() -> Self {
        Self { _reserved: () }
    }
}

impl Spawn for NoopSpawner {
    fn spawn_obj(&self, _future: FutureObj<'static, ()>) -> Result<(), SpawnError> {
        Ok(())
    }
}

impl Default for NoopSpawner {
    fn default() -> Self {
        Self::new()
    }
}

/// Get a reference to a singleton instance of [`NoopSpawner`].
///
pub fn noop_spawner_mut() -> &'static mut NoopSpawner {
    Box::leak(Box::new(NoopSpawner::new()))
}
