use futures_task::{FutureObj, Spawn, SpawnError};

/// An implementation of [`Spawn`](futures_task::Spawn) that panics
/// when used.
///
#[derive(Debug)]
pub struct PanicSpawner {
    _reserved: (),
}

impl PanicSpawner {
    /// Create a new instance
    pub fn new() -> Self {
        Self { _reserved: () }
    }
}

impl Spawn for PanicSpawner {
    fn spawn_obj(&self, _future: FutureObj<'static, ()>) -> Result<(), SpawnError> {
        panic!("should not spawn")
    }
}

impl Default for PanicSpawner {
    fn default() -> Self {
        Self::new()
    }
}

/// Get a reference to a singleton instance of [`PanicSpawner`].
///
pub fn panic_spawner_mut() -> &'static mut PanicSpawner {
    Box::leak(Box::new(PanicSpawner::new()))
}
