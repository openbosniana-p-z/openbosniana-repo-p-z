/* Just use installed headers */
#include <zdict.h>
