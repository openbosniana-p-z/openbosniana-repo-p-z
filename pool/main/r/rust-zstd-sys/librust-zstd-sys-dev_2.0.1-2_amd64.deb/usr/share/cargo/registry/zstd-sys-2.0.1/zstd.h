/* Just use installed headers */
#include <zstd.h>
