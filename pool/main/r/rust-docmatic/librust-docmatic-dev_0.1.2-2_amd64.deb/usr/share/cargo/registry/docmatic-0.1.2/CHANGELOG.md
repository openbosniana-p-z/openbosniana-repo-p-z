<a name="0.1.2"></a>
## 0.1.2 (2018-04-25)


#### Bug Fixes

*   Remove assert_file_impl from public API ([4fa6ac1f](https://github.com/assert-rs/docmatic/commit/4fa6ac1fc6b648cc699eca9f1b098177050bf568))
* **CI:**  Bump minimum Rust version ([d5598851](https://github.com/assert-rs/docmatic/commit/d5598851752292344ef09a2e759936ef08991df3))
* **crate:**  Remove unnecessary `glob` dependency ([59bffb4b](https://github.com/assert-rs/docmatic/commit/59bffb4bbc5529bf3a7d9168ff6eb74da87735e8))

#### Features

*   Add `docmatic::Assert` type and methods ([2ee9c763](https://github.com/assert-rs/docmatic/commit/2ee9c763f200ce1ce6f2a891f6d7ccf23d53e667))



<a name="0.1.1"></a>
## 0.1.1 (2018-04-17)


#### Bug Fixes

* **crate:**  Add metadata ([8cc81d0b](https://github.com/assert-rs/docmatic/commit/8cc81d0ba675a651360dccb33cd5056bc05b1c53), closes [#1](https://github.com/assert-rs/docmatic/issues/1))



<a name="0.1.0"></a>
## 0.1.0 (2018-04-17)

*   Initial implementation ([0b0b5985](https://github.com/assert-rs/docmatic/commit/0b0b59857ee320a03a7721d131217a5f077b0954))
