module Mina
  def self.version
    "0.3.7"
  end
end
