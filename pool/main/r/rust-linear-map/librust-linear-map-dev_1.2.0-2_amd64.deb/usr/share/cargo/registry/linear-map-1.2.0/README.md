A map implemented by searching linearly in a vector.

Documentation is available at https://contain-rs.github.io/linear-map/linear_map.
