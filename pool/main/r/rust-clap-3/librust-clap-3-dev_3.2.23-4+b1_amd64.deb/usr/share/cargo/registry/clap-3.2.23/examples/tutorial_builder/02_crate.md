```console
$ 02_crate --help
clap [..]
A simple to use, efficient, and full-featured Command Line Argument Parser

USAGE:
    02_crate[EXE] --two <VALUE> --one <VALUE>

OPTIONS:
    -h, --help           Print help information
        --one <VALUE>    
        --two <VALUE>    
    -V, --version        Print version information

$ 02_crate --version
clap [..]

```
