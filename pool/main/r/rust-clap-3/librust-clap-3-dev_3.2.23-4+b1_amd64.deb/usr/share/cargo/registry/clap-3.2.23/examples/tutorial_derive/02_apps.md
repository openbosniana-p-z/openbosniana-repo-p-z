```console
$ 02_apps_derive --help
MyApp 1.0
Kevin K. <kbknapp@gmail.com>
Does awesome things

USAGE:
    02_apps_derive[EXE] --two <TWO> --one <ONE>

OPTIONS:
    -h, --help         Print help information
        --one <ONE>    
        --two <TWO>    
    -V, --version      Print version information

$ 02_apps_derive --version
MyApp 1.0

```
