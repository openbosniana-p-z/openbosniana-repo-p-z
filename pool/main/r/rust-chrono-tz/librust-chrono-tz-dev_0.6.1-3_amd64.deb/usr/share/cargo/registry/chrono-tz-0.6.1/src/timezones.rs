#![allow(non_camel_case_types, clippy::unreadable_literal)]
include!(concat!(env!("OUT_DIR"), "/timezones.rs"));
