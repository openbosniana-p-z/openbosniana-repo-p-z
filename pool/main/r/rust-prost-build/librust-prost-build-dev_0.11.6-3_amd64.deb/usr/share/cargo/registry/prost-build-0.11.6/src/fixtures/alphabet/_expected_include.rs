pub mod a {
    include!("a.rs");
}
pub mod b {
    include!("b.rs");
}
pub mod c {
    include!("c.rs");
}
pub mod d {
    include!("d.rs");
}
pub mod e {
    include!("e.rs");
}
pub mod f {
    include!("f.rs");
}
