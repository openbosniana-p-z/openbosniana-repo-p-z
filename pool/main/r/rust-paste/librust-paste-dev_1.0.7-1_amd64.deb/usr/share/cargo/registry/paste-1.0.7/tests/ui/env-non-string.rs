use paste::paste;

paste! {
    fn [<env!(1.31)>]() {}
}

fn main() {}
