use paste::paste;

paste! {
    fn [<:lower x>]() {}
}

fn main() {}
