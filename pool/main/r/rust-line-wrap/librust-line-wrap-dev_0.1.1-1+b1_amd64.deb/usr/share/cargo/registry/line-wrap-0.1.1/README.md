[![](https://img.shields.io/crates/v/line_wrap.svg)](https://crates.io/crates/line_wrap) [![](https://docs.rs/line-wrap/badge.svg)](https://docs.rs/line-wrap/) [![Build Status](https://semaphoreci.com/api/v1/marshallpierce/line-wrap-rs/branches/master/shields_badge.svg)](https://semaphoreci.com/marshallpierce/line-wrap-rs)

See the [docs](https://docs.rs/line-wrap/) for usage info.

This line-wrapping logic originally was part of [rust-base64](https://github.com/alicemaz/rust-base64).
