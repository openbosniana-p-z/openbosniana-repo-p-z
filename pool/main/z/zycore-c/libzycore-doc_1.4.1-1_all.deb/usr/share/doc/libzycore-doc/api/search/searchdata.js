var indexSectionsWithContent =
{
  0: "abcdefghlmnoprstvz",
  1: "z",
  2: "abcdflmopstvz",
  3: "z",
  4: "abcdefghmnprstv",
  5: "z",
  6: "z",
  7: "z"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Macros"
};

