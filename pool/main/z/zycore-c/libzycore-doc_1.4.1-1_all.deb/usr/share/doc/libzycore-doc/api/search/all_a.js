var searchData=
[
  ['name_0',['name',['../structZyanArgParseDefinition__.html#ac9c408dd93d8c83193cf7397729546e1',1,'ZyanArgParseDefinition_']]],
  ['next_1',['next',['../structZyanListNode__.html#a478eff1a3b0c783c74ac068b886bbcc6',1,'ZyanListNode_']]]
];
