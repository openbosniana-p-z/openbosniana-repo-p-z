//
// Copyright (c) ZeroC, Inc. All rights reserved.
//

#ifndef ICE_BT_ICE_BT_H
#define ICE_BT_ICE_BT_H

#include <IceBT/ConnectionInfo.h>
#include <IceBT/EndpointInfo.h>
#include <IceBT/Types.h>

#include <IceBT/Plugin.h>

#endif
