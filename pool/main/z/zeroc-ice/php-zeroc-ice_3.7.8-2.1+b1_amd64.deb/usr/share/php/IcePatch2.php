<?php
//
// Copyright (c) ZeroC, Inc. All rights reserved.
//

require_once 'IcePatch2/FileServer.php';
?>
