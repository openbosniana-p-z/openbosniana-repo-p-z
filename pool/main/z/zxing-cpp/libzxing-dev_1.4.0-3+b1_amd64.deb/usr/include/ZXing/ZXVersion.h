/*
* Copyright 2019 Nu-book Inc.
*/
// SPDX-License-Identifier: Apache-2.0

#pragma once

// Version numbering
#define ZXING_VERSION_MAJOR 1
#define ZXING_VERSION_MINOR 4
#define ZXING_VERSION_PATCH 0
