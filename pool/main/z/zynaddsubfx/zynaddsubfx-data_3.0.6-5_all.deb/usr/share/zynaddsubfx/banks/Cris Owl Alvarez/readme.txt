by Cris Owl Alvarez
https://musical-artifacts.com/artifacts?apps=zynaddsubfx&q=Cris+Owl+Alvarez
 GNU General Public License v2.0
Extra considerations: all patches are LGPL licensed. Use freely in your music