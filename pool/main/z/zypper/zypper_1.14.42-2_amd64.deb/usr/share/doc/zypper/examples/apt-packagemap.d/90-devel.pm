foreach(@ARGV) {
	s/-dev$/-devel/;
}
