png("[% png_fname %]",width=[% r_width %], height=[% r_height %])
[% gnu_r_plot_script %]
dev.off()
