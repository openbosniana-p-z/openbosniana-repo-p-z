var group__decoder =
[
    [ "CPU flags", "group__decoder__cpu__flags.html", "group__decoder__cpu__flags" ],
    [ "FPU flags", "group__decoder__fpu__flags.html", "group__decoder__fpu__flags" ],
    [ "ZydisDecoderDecodeFull", "group__decoder.html#ga12d3dd3cc08bac0cc816e7769b57ea5e", null ],
    [ "ZydisDecoderDecodeInstruction", "group__decoder.html#ga40060708243566f0aec7d1363ec19dfc", null ],
    [ "ZydisDecoderDecodeOperands", "group__decoder.html#gadb12684923aac6f97e8e4e975ed9b2d7", null ],
    [ "ZydisDecoderEnableMode", "group__decoder.html#gada16bca4bc67871b068aebc3495a6a94", null ],
    [ "ZydisDecoderInit", "group__decoder.html#ga5448746153e38c32f81dcdc73f177002", null ]
];