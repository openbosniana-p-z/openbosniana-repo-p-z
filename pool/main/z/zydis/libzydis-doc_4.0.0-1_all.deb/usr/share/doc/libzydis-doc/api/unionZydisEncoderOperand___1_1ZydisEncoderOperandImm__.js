var unionZydisEncoderOperand___1_1ZydisEncoderOperandImm__ =
[
    [ "s", "unionZydisEncoderOperand___1_1ZydisEncoderOperandImm__.html#af745b7150515f54ea959a4a0e3ac505d", null ],
    [ "u", "unionZydisEncoderOperand___1_1ZydisEncoderOperandImm__.html#a505b48cd3f16ab59ff0269d29fb97ad3", null ]
];