var globals_eval =
[
    [ "z", "globals_eval.html", null ]
];