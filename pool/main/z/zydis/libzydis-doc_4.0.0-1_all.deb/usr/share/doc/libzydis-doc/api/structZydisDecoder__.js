var structZydisDecoder__ =
[
    [ "decoder_mode", "structZydisDecoder__.html#aa3b103c3b0f513c7d6d7043bf89640ef", null ],
    [ "machine_mode", "structZydisDecoder__.html#a57df7a98d175d0655fdf0102b09b2a0a", null ],
    [ "stack_width", "structZydisDecoder__.html#a54f96fcd04fc7090d1cb1428fc954ca5", null ]
];