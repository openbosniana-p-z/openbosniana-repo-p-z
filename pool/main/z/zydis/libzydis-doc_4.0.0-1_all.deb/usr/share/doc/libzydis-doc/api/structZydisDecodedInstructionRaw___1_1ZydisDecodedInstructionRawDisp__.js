var structZydisDecodedInstructionRaw___1_1ZydisDecodedInstructionRawDisp__ =
[
    [ "offset", "structZydisDecodedInstructionRaw___1_1ZydisDecodedInstructionRawDisp__.html#a8d5477b227873d2ef2511b78e3221128", null ],
    [ "size", "structZydisDecodedInstructionRaw___1_1ZydisDecodedInstructionRawDisp__.html#a51dd38788728d5b76de8096e9a15c51f", null ],
    [ "value", "structZydisDecodedInstructionRaw___1_1ZydisDecodedInstructionRawDisp__.html#a59a4b593cacfc6b304dea98d3f31f1d3", null ]
];