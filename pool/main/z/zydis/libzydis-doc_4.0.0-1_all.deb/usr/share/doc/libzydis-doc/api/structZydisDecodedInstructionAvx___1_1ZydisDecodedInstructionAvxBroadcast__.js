var structZydisDecodedInstructionAvx___1_1ZydisDecodedInstructionAvxBroadcast__ =
[
    [ "is_static", "structZydisDecodedInstructionAvx___1_1ZydisDecodedInstructionAvxBroadcast__.html#add6c863de5ae246db258eb42456d705d", null ],
    [ "mode", "structZydisDecodedInstructionAvx___1_1ZydisDecodedInstructionAvxBroadcast__.html#a491024432441655d7448a0563e541f2f", null ]
];