var Defines_8h =
[
    [ "ZYDIS_EXPORT", "Defines_8h.html#a02d806fceefd826bda55d8ffdab66195", null ],
    [ "ZYDIS_NO_EXPORT", "Defines_8h.html#a6ef44e2b15885a934a3a075dbb86cf02", null ]
];