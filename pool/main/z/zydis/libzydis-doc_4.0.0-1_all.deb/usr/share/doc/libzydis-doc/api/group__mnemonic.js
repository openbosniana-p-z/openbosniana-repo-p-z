var group__mnemonic =
[
    [ "ZydisMnemonicGetString", "group__mnemonic.html#gacbf5a7e146927dae544ca74a7d908d7f", null ],
    [ "ZydisMnemonicGetStringWrapped", "group__mnemonic.html#ga4dcafdac429e61fff7c5471a1f78a442", null ]
];