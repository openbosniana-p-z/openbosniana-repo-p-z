var structZydisEncoderOperand__ =
[
    [ "ZydisEncoderOperandImm_", "unionZydisEncoderOperand___1_1ZydisEncoderOperandImm__.html", "unionZydisEncoderOperand___1_1ZydisEncoderOperandImm__" ],
    [ "ZydisEncoderOperandMem_", "structZydisEncoderOperand___1_1ZydisEncoderOperandMem__.html", "structZydisEncoderOperand___1_1ZydisEncoderOperandMem__" ],
    [ "ZydisEncoderOperandPtr_", "structZydisEncoderOperand___1_1ZydisEncoderOperandPtr__.html", "structZydisEncoderOperand___1_1ZydisEncoderOperandPtr__" ],
    [ "ZydisEncoderOperandReg_", "structZydisEncoderOperand___1_1ZydisEncoderOperandReg__.html", "structZydisEncoderOperand___1_1ZydisEncoderOperandReg__" ],
    [ "type", "structZydisEncoderOperand__.html#ae3d1db3307aa21920a70728b5b89e190", null ]
];