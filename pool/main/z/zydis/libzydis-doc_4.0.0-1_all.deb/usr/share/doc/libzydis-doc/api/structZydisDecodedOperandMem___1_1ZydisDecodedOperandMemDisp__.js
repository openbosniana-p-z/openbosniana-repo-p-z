var structZydisDecodedOperandMem___1_1ZydisDecodedOperandMemDisp__ =
[
    [ "has_displacement", "structZydisDecodedOperandMem___1_1ZydisDecodedOperandMemDisp__.html#ae659863db41ee39b566f08e4e38c0e22", null ],
    [ "value", "structZydisDecodedOperandMem___1_1ZydisDecodedOperandMemDisp__.html#a59a4b593cacfc6b304dea98d3f31f1d3", null ]
];