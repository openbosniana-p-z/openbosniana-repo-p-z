var structZydisFormatterToken__ =
[
    [ "next", "structZydisFormatterToken__.html#a739fd6e470759696bd001f9b77bc2343", null ],
    [ "type", "structZydisFormatterToken__.html#a825de1cb4ac051ad322c742091c64346", null ]
];