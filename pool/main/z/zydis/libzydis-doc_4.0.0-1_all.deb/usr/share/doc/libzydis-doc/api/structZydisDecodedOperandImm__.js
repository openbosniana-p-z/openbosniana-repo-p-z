var structZydisDecodedOperandImm__ =
[
    [ "ZydisDecodedOperandImmValue_", "unionZydisDecodedOperandImm___1_1ZydisDecodedOperandImmValue__.html", null ],
    [ "is_relative", "structZydisDecodedOperandImm__.html#a65563abb14a6a0196df0ff540b9c3fa5", null ],
    [ "is_signed", "structZydisDecodedOperandImm__.html#a6627cbb5069aea967215a9cb561ae63e", null ]
];