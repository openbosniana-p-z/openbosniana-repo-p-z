var structZydisInstructionEncodingInfo__ =
[
    [ "disp", "structZydisInstructionEncodingInfo__.html#a514768057d60e1aaead8706ebeeffcf7", null ],
    [ "flags", "structZydisInstructionEncodingInfo__.html#a53502268cea85b2fb645f0ec3648eba6", null ],
    [ "imm", "structZydisInstructionEncodingInfo__.html#ae63662a9eb044b455eb758c622fffddd", null ],
    [ "is_relative", "structZydisInstructionEncodingInfo__.html#a65563abb14a6a0196df0ff540b9c3fa5", null ],
    [ "is_signed", "structZydisInstructionEncodingInfo__.html#a6627cbb5069aea967215a9cb561ae63e", null ],
    [ "size", "structZydisInstructionEncodingInfo__.html#a67ea278b9c095eda6d3e0902fb961a3a", null ]
];