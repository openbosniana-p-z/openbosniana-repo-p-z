var Zydis_8h =
[
    [ "ZYDIS_VERSION", "group__version.html#gaeca2146e7e41ef26ebd0178e29da9093", null ],
    [ "ZYDIS_VERSION_BUILD", "group__version.html#gafcf14d477a57075339aedea719a6badc", null ],
    [ "ZYDIS_VERSION_MAJOR", "group__version.html#gae72b7484650a561930869bf50b7ae13d", null ],
    [ "ZYDIS_VERSION_MINOR", "group__version.html#ga0e2cd81d0791554eee3a44fc65dd0ec8", null ],
    [ "ZYDIS_VERSION_PATCH", "group__version.html#ga6f86775dccd32f3191a66c0492133ca6", null ],
    [ "ZydisFeature", "group__version.html#ga8a2abed7f450cb47e9c3e3bcffd9d1dc", null ],
    [ "ZydisFeature_", "group__version.html#ga5da0c2016657650ad96692861ed684ee", [
      [ "ZYDIS_FEATURE_DECODER", "group__version.html#gga5da0c2016657650ad96692861ed684eea65d31df51e88e8e55028af1da04ac287", null ],
      [ "ZYDIS_FEATURE_ENCODER", "group__version.html#gga5da0c2016657650ad96692861ed684eeaba3a961f674d54c3f70434239d250412", null ],
      [ "ZYDIS_FEATURE_FORMATTER", "group__version.html#gga5da0c2016657650ad96692861ed684eea72dd269caa2f804cea6fce2c33b09ee4", null ],
      [ "ZYDIS_FEATURE_AVX512", "group__version.html#gga5da0c2016657650ad96692861ed684eeaf66e650727b732420740a1b722dc902a", null ],
      [ "ZYDIS_FEATURE_KNC", "group__version.html#gga5da0c2016657650ad96692861ed684eea1b8b9dfa436d326646f17bca9a85aafa", null ],
      [ "ZYDIS_FEATURE_SEGMENT", "group__version.html#gga5da0c2016657650ad96692861ed684eea1a40e348b45784f03b31872971ea23c8", null ],
      [ "ZYDIS_FEATURE_MAX_VALUE", "group__version.html#gga5da0c2016657650ad96692861ed684eea2addc651697f39141c35ebeabb3e1594", null ],
      [ "ZYDIS_FEATURE_REQUIRED_BITS", "group__version.html#gga5da0c2016657650ad96692861ed684eea522d352c2111e2616de838dfedcda3aa", null ]
    ] ],
    [ "ZydisGetVersion", "group__version.html#gad52d39f94ef4a17ecfc9d53940243d91", null ],
    [ "ZydisIsFeatureEnabled", "group__version.html#ga0d2a3ce4fd00b8a5715b447a36f1f4e2", null ]
];