var structZydisEncoderLookupEntry__ =
[
    [ "encoder_reference", "structZydisEncoderLookupEntry__.html#a61b51f9ac2760a33280ed95c947f9bb8", null ],
    [ "instruction_count", "structZydisEncoderLookupEntry__.html#a941548ea872e59e6e062a2ae2955fbda", null ]
];