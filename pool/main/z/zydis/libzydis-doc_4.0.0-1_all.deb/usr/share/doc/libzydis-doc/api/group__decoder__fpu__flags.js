var group__decoder__fpu__flags =
[
    [ "ZYDIS_FPUFLAG_C0", "group__decoder__fpu__flags.html#ga198b4bb6da10fa1158241936a4b0c74c", null ],
    [ "ZYDIS_FPUFLAG_C1", "group__decoder__fpu__flags.html#ga6a14f59ac848d3ba108c885fd002d7f9", null ],
    [ "ZYDIS_FPUFLAG_C2", "group__decoder__fpu__flags.html#ga4858a86c2a4f900a10b9edafa045d015", null ],
    [ "ZYDIS_FPUFLAG_C3", "group__decoder__fpu__flags.html#gac9f9292166512edab7d4006cbdf5798d", null ]
];