var structZydisDecodedInstructionRaw___1_1ZydisDecodedInstructionModRm__ =
[
    [ "mod", "structZydisDecodedInstructionRaw___1_1ZydisDecodedInstructionModRm__.html#a48381481ab4e317449d162023f3355b1", null ],
    [ "offset", "structZydisDecodedInstructionRaw___1_1ZydisDecodedInstructionModRm__.html#a8d5477b227873d2ef2511b78e3221128", null ],
    [ "reg", "structZydisDecodedInstructionRaw___1_1ZydisDecodedInstructionModRm__.html#ae1b46f2093f94b55f68a3082b6116225", null ],
    [ "rm", "structZydisDecodedInstructionRaw___1_1ZydisDecodedInstructionModRm__.html#a085405fb2ec715526d15548547841b64", null ]
];