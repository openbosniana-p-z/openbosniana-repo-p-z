var structZydisDecodedInstructionRaw___1_1ZydisDecodedInstructionRawPrefixes__ =
[
    [ "type", "structZydisDecodedInstructionRaw___1_1ZydisDecodedInstructionRawPrefixes__.html#a02c956465c7d6a2629001b7110e87467", null ],
    [ "value", "structZydisDecodedInstructionRaw___1_1ZydisDecodedInstructionRawPrefixes__.html#a44074c0070e1ce67efc1223073f528f3", null ]
];