var structZydisEncoderOperand___1_1ZydisEncoderOperandPtr__ =
[
    [ "offset", "structZydisEncoderOperand___1_1ZydisEncoderOperandPtr__.html#a8578feeea7f157eea4b9a7cae991ea45", null ],
    [ "segment", "structZydisEncoderOperand___1_1ZydisEncoderOperandPtr__.html#af2c89ad85e3f5aa084ee9f8c8ae84358", null ]
];