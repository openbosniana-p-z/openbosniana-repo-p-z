var group__register =
[
    [ "ZydisRegisterClassGetWidth", "group__register.html#gad3a0c5a810b3891a52c1e4ab83c5e520", null ],
    [ "ZydisRegisterEncode", "group__register.html#ga3843b1fdfe0d6e573566304144ac86a8", null ],
    [ "ZydisRegisterGetClass", "group__register.html#gae73f5b01855fc4bb198295e4f72c0933", null ],
    [ "ZydisRegisterGetId", "group__register.html#ga69e1e4da1eb97949780c51aaa628bd41", null ],
    [ "ZydisRegisterGetLargestEnclosing", "group__register.html#ga64fe1f09f17c7d7f0f145e52ea934e40", null ],
    [ "ZydisRegisterGetString", "group__register.html#ga81e585d511011f8c4b6d774172c024c5", null ],
    [ "ZydisRegisterGetStringWrapped", "group__register.html#ga48f9b3bea0eb0d8337867a9cba09d22b", null ],
    [ "ZydisRegisterGetWidth", "group__register.html#gaedad4f7373e0b46d74c5216a774ce1b4", null ]
];