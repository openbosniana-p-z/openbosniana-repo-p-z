var structZydisDecodedInstructionAvx__ =
[
    [ "ZydisDecodedInstructionAvxBroadcast_", "structZydisDecodedInstructionAvx___1_1ZydisDecodedInstructionAvxBroadcast__.html", "structZydisDecodedInstructionAvx___1_1ZydisDecodedInstructionAvxBroadcast__" ],
    [ "ZydisDecodedInstructionAvxConversion_", "structZydisDecodedInstructionAvx___1_1ZydisDecodedInstructionAvxConversion__.html", "structZydisDecodedInstructionAvx___1_1ZydisDecodedInstructionAvxConversion__" ],
    [ "ZydisDecodedInstructionAvxMask_", "structZydisDecodedInstructionAvx___1_1ZydisDecodedInstructionAvxMask__.html", "structZydisDecodedInstructionAvx___1_1ZydisDecodedInstructionAvxMask__" ],
    [ "ZydisDecodedInstructionAvxRounding_", "structZydisDecodedInstructionAvx___1_1ZydisDecodedInstructionAvxRounding__.html", "structZydisDecodedInstructionAvx___1_1ZydisDecodedInstructionAvxRounding__" ],
    [ "ZydisDecodedInstructionAvxSwizzle_", "structZydisDecodedInstructionAvx___1_1ZydisDecodedInstructionAvxSwizzle__.html", "structZydisDecodedInstructionAvx___1_1ZydisDecodedInstructionAvxSwizzle__" ],
    [ "has_eviction_hint", "structZydisDecodedInstructionAvx__.html#a5648194544317373d1eea776bba38754", null ],
    [ "has_sae", "structZydisDecodedInstructionAvx__.html#ae41d8bb94402d516ea2b64a42f9dacd6", null ],
    [ "vector_length", "structZydisDecodedInstructionAvx__.html#ae394abdfab5cc4e4ef95bc6725452182", null ]
];