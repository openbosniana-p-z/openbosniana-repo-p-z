var structZydisDecoderContext__ =
[
    [ "cd8_scale", "structZydisDecoderContext__.html#a55d64267b66f7c93417d2bcd0a99b3e7", null ],
    [ "definition", "structZydisDecoderContext__.html#ad288a775b5547bfa24c8b8f88af1a536", null ],
    [ "easz_index", "structZydisDecoderContext__.html#aff49ca2e8e19f5c5264e658953de8010", null ],
    [ "element_size", "structZydisDecoderContext__.html#a5ca5a683722610242407dc5ce2a7c14e", null ],
    [ "eosz_index", "structZydisDecoderContext__.html#a95ffc78bc22be66ec9bda1376d9b50e6", null ],
    [ "evex", "structZydisDecoderContext__.html#aac4563cda185d0f58e4a8ac531be999b", null ],
    [ "functionality", "structZydisDecoderContext__.html#a0f71ce9c43ed08a36dbe1750fc2850c3", null ],
    [ "id_base", "structZydisDecoderContext__.html#a32678be7fd9a2a433453e21e7d17b821", null ],
    [ "id_index", "structZydisDecoderContext__.html#ad9b14203394e32cb9e5b77dbaa471bd5", null ],
    [ "id_ndsndd", "structZydisDecoderContext__.html#af3ae61ea6cbd17e5dbdf205d4f8ebbbd", null ],
    [ "id_reg", "structZydisDecoderContext__.html#acee4d0112dbfe82586ce27cf3031f805", null ],
    [ "id_rm", "structZydisDecoderContext__.html#aa7b1c3c9f7f10cb97797a82c232b110d", null ],
    [ "is_mod_reg", "structZydisDecoderContext__.html#ae7915ce446ff0babe6bd2aa1de529a4e", null ],
    [ "mvex", "structZydisDecoderContext__.html#a140b691ff0cd56e966c71f528f342c61", null ],
    [ "reg_info", "structZydisDecoderContext__.html#a5739ac8d3a54d54ffe2cdc1cb937813d", null ],
    [ "tuple_type", "structZydisDecoderContext__.html#a2c8fe98d4372536b70294a4e9d012904", null ],
    [ "vector_unified", "structZydisDecoderContext__.html#ad324a47e152ac5c34e90921ef72d8e69", null ]
];