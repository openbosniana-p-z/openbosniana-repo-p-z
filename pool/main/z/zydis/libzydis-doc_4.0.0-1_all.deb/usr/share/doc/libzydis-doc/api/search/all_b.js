var searchData=
[
  ['next_0',['next',['../structZydisFormatterToken__.html#a739fd6e470759696bd001f9b77bc2343',1,'ZydisFormatterToken_']]],
  ['number_5fformat_1',['number_format',['../structZydisFormatter__.html#a70eb6fef3fad632da10bba65d016f763',1,'ZydisFormatter_']]]
];
