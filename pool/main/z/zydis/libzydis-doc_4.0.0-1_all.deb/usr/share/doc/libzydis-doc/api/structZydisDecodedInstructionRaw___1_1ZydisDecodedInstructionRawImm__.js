var structZydisDecodedInstructionRaw___1_1ZydisDecodedInstructionRawImm__ =
[
    [ "ZydisDecodedInstructionRawImmValue_", "unionZydisDecodedInstructionRaw___1_1ZydisDecodedInstructionRawImm___1_1ZydisDecodedInstructionRawImmValue__.html", null ],
    [ "is_relative", "structZydisDecodedInstructionRaw___1_1ZydisDecodedInstructionRawImm__.html#a65563abb14a6a0196df0ff540b9c3fa5", null ],
    [ "is_signed", "structZydisDecodedInstructionRaw___1_1ZydisDecodedInstructionRawImm__.html#a6627cbb5069aea967215a9cb561ae63e", null ],
    [ "offset", "structZydisDecodedInstructionRaw___1_1ZydisDecodedInstructionRawImm__.html#a8d5477b227873d2ef2511b78e3221128", null ],
    [ "size", "structZydisDecodedInstructionRaw___1_1ZydisDecodedInstructionRawImm__.html#a51dd38788728d5b76de8096e9a15c51f", null ]
];