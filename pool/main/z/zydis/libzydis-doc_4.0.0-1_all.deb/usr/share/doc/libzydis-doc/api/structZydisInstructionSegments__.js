var structZydisInstructionSegments__ =
[
    [ "count", "structZydisInstructionSegments__.html#a12a9a2c82bc5e77b5e509f61a948b5cc", null ],
    [ "offset", "structZydisInstructionSegments__.html#a8d5477b227873d2ef2511b78e3221128", null ],
    [ "size", "structZydisInstructionSegments__.html#a51dd38788728d5b76de8096e9a15c51f", null ],
    [ "type", "structZydisInstructionSegments__.html#a58780ad8d182bbf5530d51b02cbf293a", null ]
];