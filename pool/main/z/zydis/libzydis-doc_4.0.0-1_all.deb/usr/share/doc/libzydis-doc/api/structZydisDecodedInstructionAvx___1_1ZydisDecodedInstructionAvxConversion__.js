var structZydisDecodedInstructionAvx___1_1ZydisDecodedInstructionAvxConversion__ =
[
    [ "mode", "structZydisDecodedInstructionAvx___1_1ZydisDecodedInstructionAvxConversion__.html#a0e2752f6c05577c7c27bf263dee350e5", null ]
];