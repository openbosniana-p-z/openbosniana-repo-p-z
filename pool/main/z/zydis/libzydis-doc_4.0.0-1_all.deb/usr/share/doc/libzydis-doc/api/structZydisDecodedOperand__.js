var structZydisDecodedOperand__ =
[
    [ "actions", "structZydisDecodedOperand__.html#a1a8b3909d3bc358831585a3ef400b31c", null ],
    [ "element_count", "structZydisDecodedOperand__.html#a0d59cd2c6059341345ce8c4477c32a0d", null ],
    [ "element_size", "structZydisDecodedOperand__.html#af6d06914f0c75722c01e410a6fe3cbeb", null ],
    [ "element_type", "structZydisDecodedOperand__.html#a520592afbc9a1cb7e28c6a6a34bbd44f", null ],
    [ "encoding", "structZydisDecodedOperand__.html#a32c5389007882ad6ac63997d76167be8", null ],
    [ "id", "structZydisDecodedOperand__.html#ae7009c1500b747ae1c5f0bb8eccb20d0", null ],
    [ "size", "structZydisDecodedOperand__.html#a021828356462c689379d21dc728e3d65", null ],
    [ "type", "structZydisDecodedOperand__.html#ae3d1db3307aa21920a70728b5b89e190", null ],
    [ "visibility", "structZydisDecodedOperand__.html#a57ab3a06a0f0e721a050e074219a3ded", null ]
];