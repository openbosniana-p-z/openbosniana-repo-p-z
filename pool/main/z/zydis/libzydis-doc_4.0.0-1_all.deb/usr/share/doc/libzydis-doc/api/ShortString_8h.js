var ShortString_8h =
[
    [ "ZydisShortString_", "structZydisShortString__.html", "structZydisShortString__" ],
    [ "ZYDIS_MAKE_SHORTSTRING", "ShortString_8h.html#a57aa557d696bb6d0a9e35994f3fca8cc", null ],
    [ "ZydisShortString", "ShortString_8h.html#a9e25ce24638faf61df2e79c53a8f11ec", null ]
];