var group__decoder__cpu__flags =
[
    [ "ZYDIS_CPUFLAG_AC", "group__decoder__cpu__flags.html#gadb1ce12be44fcbe4c08289c68bbc1680", null ],
    [ "ZYDIS_CPUFLAG_AF", "group__decoder__cpu__flags.html#gaa60e29a6ccaf40128a16f08f67badab6", null ],
    [ "ZYDIS_CPUFLAG_CF", "group__decoder__cpu__flags.html#ga519043a687ef23cdbf135f1fb843cb9c", null ],
    [ "ZYDIS_CPUFLAG_DF", "group__decoder__cpu__flags.html#ga67d8a8048192077804ce90f653797591", null ],
    [ "ZYDIS_CPUFLAG_ID", "group__decoder__cpu__flags.html#ga64da2108d35135ee9a3478c2c58a6843", null ],
    [ "ZYDIS_CPUFLAG_IF", "group__decoder__cpu__flags.html#ga5128fce16605b6c964178279d905e34a", null ],
    [ "ZYDIS_CPUFLAG_IOPL", "group__decoder__cpu__flags.html#gafebc9b6480cf253bcc5dbd765617c91f", null ],
    [ "ZYDIS_CPUFLAG_NT", "group__decoder__cpu__flags.html#gacefc583b2ed4b7f099ece4b5acdcc1f2", null ],
    [ "ZYDIS_CPUFLAG_OF", "group__decoder__cpu__flags.html#gafa3789e01df153d6eb5f8c0f253f76aa", null ],
    [ "ZYDIS_CPUFLAG_PF", "group__decoder__cpu__flags.html#ga6a8990a78c85914352ac81ace44e0003", null ],
    [ "ZYDIS_CPUFLAG_RF", "group__decoder__cpu__flags.html#gadef1102d8ca0f49da9ef771782d7c162", null ],
    [ "ZYDIS_CPUFLAG_SF", "group__decoder__cpu__flags.html#ga4f4621befc9cb3d5c498bee6723920f2", null ],
    [ "ZYDIS_CPUFLAG_TF", "group__decoder__cpu__flags.html#gaea528b63e425fd8107ef2ef99b054408", null ],
    [ "ZYDIS_CPUFLAG_VIF", "group__decoder__cpu__flags.html#ga8b57f60537f727e68db287a02e5006f1", null ],
    [ "ZYDIS_CPUFLAG_VIP", "group__decoder__cpu__flags.html#ga273eade015578fde557329e5f1cf29fa", null ],
    [ "ZYDIS_CPUFLAG_VM", "group__decoder__cpu__flags.html#ga5771b0461b0242773469c552de40134f", null ],
    [ "ZYDIS_CPUFLAG_ZF", "group__decoder__cpu__flags.html#gaa40882dac79cca8ddf066ff59b91eec4", null ]
];