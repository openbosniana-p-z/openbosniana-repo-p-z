var Utils_8h =
[
    [ "ZydisCalcAbsoluteAddress", "group__utils.html#ga276fcfaf27a9ca02647be96d98879f65", null ],
    [ "ZydisCalcAbsoluteAddressEx", "group__utils.html#ga441e1087b1d65358bfeafe09160f1322", null ]
];