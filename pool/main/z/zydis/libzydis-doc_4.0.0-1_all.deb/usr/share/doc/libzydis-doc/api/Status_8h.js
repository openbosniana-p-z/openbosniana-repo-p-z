var Status_8h =
[
    [ "ZYAN_MODULE_ZYDIS", "Status_8h.html#a6da15b3a90b37c08e6aa5bcf26983053", null ],
    [ "ZYDIS_STATUS_BAD_REGISTER", "Status_8h.html#a0e2fcbda03f8604d6e88c2bc186aa0d2", null ],
    [ "ZYDIS_STATUS_DECODING_ERROR", "Status_8h.html#a69804afd0a63032d5319ae1f81cc2d4c", null ],
    [ "ZYDIS_STATUS_ILLEGAL_LEGACY_PFX", "Status_8h.html#a0e3c0c6930cb11f313abd18255481dc8", null ],
    [ "ZYDIS_STATUS_ILLEGAL_LOCK", "Status_8h.html#a409926e936a471efe62e41240dc45be6", null ],
    [ "ZYDIS_STATUS_ILLEGAL_REX", "Status_8h.html#acb9501b6b33e45df7a8d69f7f3e1c4ec", null ],
    [ "ZYDIS_STATUS_INSTRUCTION_TOO_LONG", "Status_8h.html#adb415b41e9ba38a57b9a201d96004492", null ],
    [ "ZYDIS_STATUS_INVALID_MAP", "Status_8h.html#a7b7897b43f4af345d2f7c40eec7a2c4d", null ],
    [ "ZYDIS_STATUS_INVALID_MASK", "Status_8h.html#a586d38f245eaa524e1a317406f297914", null ],
    [ "ZYDIS_STATUS_MALFORMED_EVEX", "Status_8h.html#a72cd3d6419305098f45c1a84f7f438f3", null ],
    [ "ZYDIS_STATUS_MALFORMED_MVEX", "Status_8h.html#a5e3ebd0e9e830715c047e176e84a4cca", null ],
    [ "ZYDIS_STATUS_NO_MORE_DATA", "Status_8h.html#a4c0612793f5a26d4e075202fdd9f3ac4", null ],
    [ "ZYDIS_STATUS_SKIP_TOKEN", "Status_8h.html#a3c12349a5bdfaf8d9ce8d976ee8b04b9", null ]
];