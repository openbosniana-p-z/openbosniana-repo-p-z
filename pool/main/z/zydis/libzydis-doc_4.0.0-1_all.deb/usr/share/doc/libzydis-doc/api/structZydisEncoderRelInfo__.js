var structZydisEncoderRelInfo__ =
[
    [ "accepts_branch_hints", "structZydisEncoderRelInfo__.html#a30556133e269d9eb8a0aa500f27ad3cc", null ],
    [ "accepts_scaling_hints", "structZydisEncoderRelInfo__.html#a9b6d417b7cf1e880ef90a3d7d0853438", null ],
    [ "size", "structZydisEncoderRelInfo__.html#a116c545d35e4061c16e68578bfd31905", null ]
];