var structZydisDecodedOperandMem__ =
[
    [ "ZydisDecodedOperandMemDisp_", "structZydisDecodedOperandMem___1_1ZydisDecodedOperandMemDisp__.html", "structZydisDecodedOperandMem___1_1ZydisDecodedOperandMemDisp__" ],
    [ "base", "structZydisDecodedOperandMem__.html#a571f92b98599b56aa4e185cb32fb4ac5", null ],
    [ "index", "structZydisDecodedOperandMem__.html#ad6dc3d8c91c7cbeafcc6e2e1d2da6599", null ],
    [ "scale", "structZydisDecodedOperandMem__.html#a86db95449a20ca13162e15573acee93e", null ],
    [ "segment", "structZydisDecodedOperandMem__.html#a3307464b72e96920b5a1e85cfec15d01", null ],
    [ "type", "structZydisDecodedOperandMem__.html#a325e5174c22e2248d13bebcd07bfed87", null ]
];