var structZydisDisassembledInstruction__ =
[
    [ "info", "structZydisDisassembledInstruction__.html#ab49c5eab9e67c1d33cf1ba13cee967db", null ],
    [ "operands", "structZydisDisassembledInstruction__.html#aabe959e75d8b87f4b4c1a77d5922b31d", null ],
    [ "runtime_address", "structZydisDisassembledInstruction__.html#a8d65f7b2a44b9e84c9f48de0fec26cef", null ],
    [ "text", "structZydisDisassembledInstruction__.html#a9445d9acddfea552d3a2eb9e8982fc95", null ]
];