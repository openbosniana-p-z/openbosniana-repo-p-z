var Encoder_8h =
[
    [ "ZydisEncoderOperand_", "structZydisEncoderOperand__.html", "structZydisEncoderOperand__" ],
    [ "ZydisEncoderOperand_::ZydisEncoderOperandReg_", "structZydisEncoderOperand___1_1ZydisEncoderOperandReg__.html", "structZydisEncoderOperand___1_1ZydisEncoderOperandReg__" ],
    [ "ZydisEncoderOperand_::ZydisEncoderOperandMem_", "structZydisEncoderOperand___1_1ZydisEncoderOperandMem__.html", "structZydisEncoderOperand___1_1ZydisEncoderOperandMem__" ],
    [ "ZydisEncoderOperand_::ZydisEncoderOperandPtr_", "structZydisEncoderOperand___1_1ZydisEncoderOperandPtr__.html", "structZydisEncoderOperand___1_1ZydisEncoderOperandPtr__" ],
    [ "ZydisEncoderOperand_::ZydisEncoderOperandImm_", "unionZydisEncoderOperand___1_1ZydisEncoderOperandImm__.html", "unionZydisEncoderOperand___1_1ZydisEncoderOperandImm__" ],
    [ "ZydisEncoderRequest_", "structZydisEncoderRequest__.html", "structZydisEncoderRequest__" ],
    [ "ZydisEncoderRequest_::ZydisEncoderRequestEvexFeatures_", "structZydisEncoderRequest___1_1ZydisEncoderRequestEvexFeatures__.html", "structZydisEncoderRequest___1_1ZydisEncoderRequestEvexFeatures__" ],
    [ "ZydisEncoderRequest_::ZydisEncoderRequestMvexFeatures_", "structZydisEncoderRequest___1_1ZydisEncoderRequestMvexFeatures__.html", "structZydisEncoderRequest___1_1ZydisEncoderRequestMvexFeatures__" ],
    [ "ZYDIS_ENCODABLE_PREFIXES", "Encoder_8h.html#a5805dc83bec1afafae2a4929b51627c4", null ],
    [ "ZYDIS_ENCODER_MAX_OPERANDS", "Encoder_8h.html#a0fc11e84ed773a65f395a4040785b971", null ],
    [ "ZydisAddressSizeHint", "Encoder_8h.html#a1c1c27c7ccbca136c31a97ad05d3debf", null ],
    [ "ZydisBranchWidth", "Encoder_8h.html#a2bef5ece137461163ad5d091803a91db", null ],
    [ "ZydisEncodableEncoding", "Encoder_8h.html#aa8e652aaf9812b49a197acb1aae958f9", null ],
    [ "ZydisEncoderOperand", "Encoder_8h.html#a2e63d73cd19e7ac50ebba41a6add4dae", null ],
    [ "ZydisEncoderRequest", "Encoder_8h.html#afcfa13f326b8a7f380c79d3a14537f73", null ],
    [ "ZydisOperandSizeHint", "Encoder_8h.html#ac039983db649e70a9f4d453b5ffc71ad", null ],
    [ "ZydisAddressSizeHint_", "Encoder_8h.html#a2d7c7c878b9f460229a698a994751bcd", [
      [ "ZYDIS_ADDRESS_SIZE_HINT_NONE", "Encoder_8h.html#a2d7c7c878b9f460229a698a994751bcda3d01d1dc3fa3d14d8f9edd54c09dd8fb", null ],
      [ "ZYDIS_ADDRESS_SIZE_HINT_16", "Encoder_8h.html#a2d7c7c878b9f460229a698a994751bcda76ccf29da6f6210951a0ce61e42e2065", null ],
      [ "ZYDIS_ADDRESS_SIZE_HINT_32", "Encoder_8h.html#a2d7c7c878b9f460229a698a994751bcdaab647185c46c37f057ea3e298c5f9a0d", null ],
      [ "ZYDIS_ADDRESS_SIZE_HINT_64", "Encoder_8h.html#a2d7c7c878b9f460229a698a994751bcdaf460144c8191ab6847ac9c5f407898e8", null ],
      [ "ZYDIS_ADDRESS_SIZE_HINT_MAX_VALUE", "Encoder_8h.html#a2d7c7c878b9f460229a698a994751bcda9c9456b6e5e041a090e50f0d4b4de696", null ],
      [ "ZYDIS_ADDRESS_SIZE_HINT_REQUIRED_BITS", "Encoder_8h.html#a2d7c7c878b9f460229a698a994751bcda295ef5e10c0c3183f4c82c2e85294287", null ]
    ] ],
    [ "ZydisBranchWidth_", "Encoder_8h.html#ac18d50bda13b1a44a87b1e5331bc1e22", [
      [ "ZYDIS_BRANCH_WIDTH_NONE", "Encoder_8h.html#ac18d50bda13b1a44a87b1e5331bc1e22a02df89ecf046cea155247cc01efa1e9f", null ],
      [ "ZYDIS_BRANCH_WIDTH_8", "Encoder_8h.html#ac18d50bda13b1a44a87b1e5331bc1e22a6e11f5c10f828410ae1af888a858537a", null ],
      [ "ZYDIS_BRANCH_WIDTH_16", "Encoder_8h.html#ac18d50bda13b1a44a87b1e5331bc1e22aca33251e06acd9f77b9a91449e80adb8", null ],
      [ "ZYDIS_BRANCH_WIDTH_32", "Encoder_8h.html#ac18d50bda13b1a44a87b1e5331bc1e22a87ebcdcef5118577d356731136d17b98", null ],
      [ "ZYDIS_BRANCH_WIDTH_64", "Encoder_8h.html#ac18d50bda13b1a44a87b1e5331bc1e22af4b2fe5d9b47ba7a7ddd92aeced12ba0", null ],
      [ "ZYDIS_BRANCH_WIDTH_MAX_VALUE", "Encoder_8h.html#ac18d50bda13b1a44a87b1e5331bc1e22a46c156de20132837c381f9aac6d64a1c", null ],
      [ "ZYDIS_BRANCH_WIDTH_REQUIRED_BITS", "Encoder_8h.html#ac18d50bda13b1a44a87b1e5331bc1e22a885d1a18112dec8515a4da231b690ec3", null ]
    ] ],
    [ "ZydisEncodableEncoding_", "Encoder_8h.html#accac33d8a0e2e2a440fbb984ac1201e9", [
      [ "ZYDIS_ENCODABLE_ENCODING_DEFAULT", "Encoder_8h.html#accac33d8a0e2e2a440fbb984ac1201e9a6d64e5b772e273e63b4e93e00c362b0a", null ],
      [ "ZYDIS_ENCODABLE_ENCODING_LEGACY", "Encoder_8h.html#accac33d8a0e2e2a440fbb984ac1201e9adff133906a376f8746f1ca5621c21fab", null ],
      [ "ZYDIS_ENCODABLE_ENCODING_3DNOW", "Encoder_8h.html#accac33d8a0e2e2a440fbb984ac1201e9afc4a43e7531ac72600fd962a7d7e8bb7", null ],
      [ "ZYDIS_ENCODABLE_ENCODING_XOP", "Encoder_8h.html#accac33d8a0e2e2a440fbb984ac1201e9ad24c780646e18c06909755f12d46e1c5", null ],
      [ "ZYDIS_ENCODABLE_ENCODING_VEX", "Encoder_8h.html#accac33d8a0e2e2a440fbb984ac1201e9a92c6461ec8d8788b8ad766a75a911e0b", null ],
      [ "ZYDIS_ENCODABLE_ENCODING_EVEX", "Encoder_8h.html#accac33d8a0e2e2a440fbb984ac1201e9abfdc03a2cee6874d2fd452ce875421ee", null ],
      [ "ZYDIS_ENCODABLE_ENCODING_MVEX", "Encoder_8h.html#accac33d8a0e2e2a440fbb984ac1201e9abbc75c73bfa6277ec6370632a24eb348", null ],
      [ "ZYDIS_ENCODABLE_ENCODING_MAX_VALUE", "Encoder_8h.html#accac33d8a0e2e2a440fbb984ac1201e9a50bb7eec896b8ec8ef4ca5b04c2a1f81", null ],
      [ "ZYDIS_ENCODABLE_ENCODING_REQUIRED_BITS", "Encoder_8h.html#accac33d8a0e2e2a440fbb984ac1201e9a1d69e49ee86b66be412223835a2042cf", null ]
    ] ],
    [ "ZydisOperandSizeHint_", "Encoder_8h.html#a5d0f835003bcba95bd11566298a79820", [
      [ "ZYDIS_OPERAND_SIZE_HINT_NONE", "Encoder_8h.html#a5d0f835003bcba95bd11566298a79820a59d2fffb339a8e2f74e1efc61e972118", null ],
      [ "ZYDIS_OPERAND_SIZE_HINT_8", "Encoder_8h.html#a5d0f835003bcba95bd11566298a79820a5d24fb2900863d8ba926386765300f4e", null ],
      [ "ZYDIS_OPERAND_SIZE_HINT_16", "Encoder_8h.html#a5d0f835003bcba95bd11566298a79820a2ef91e2c020da6fb90e3bbb84a8e91e9", null ],
      [ "ZYDIS_OPERAND_SIZE_HINT_32", "Encoder_8h.html#a5d0f835003bcba95bd11566298a79820a3e5ee39dd2caa192ef458e96ab4ebd98", null ],
      [ "ZYDIS_OPERAND_SIZE_HINT_64", "Encoder_8h.html#a5d0f835003bcba95bd11566298a79820ae539addc43a96b9b373b41c45b18ade0", null ],
      [ "ZYDIS_OPERAND_SIZE_HINT_MAX_VALUE", "Encoder_8h.html#a5d0f835003bcba95bd11566298a79820a9ffe7b20a533be19188f94afa27288c4", null ],
      [ "ZYDIS_OPERAND_SIZE_HINT_REQUIRED_BITS", "Encoder_8h.html#a5d0f835003bcba95bd11566298a79820a4d00445a0e06e2b7fb97c1d3075c07bc", null ]
    ] ],
    [ "ZydisEncoderDecodedInstructionToEncoderRequest", "group__encoder.html#ga172135fe19f58ffd22099c2398f06ad8", null ],
    [ "ZydisEncoderEncodeInstruction", "group__encoder.html#ga434f4421904c352fde2820c0940e7b3b", null ],
    [ "ZydisEncoderEncodeInstructionAbsolute", "group__encoder.html#ga8c631aa30e550914d953ca7e1dea4db8", null ],
    [ "ZydisEncoderNopFill", "group__encoder.html#gad414be1437786b0cce51d6414793b3ff", null ]
];