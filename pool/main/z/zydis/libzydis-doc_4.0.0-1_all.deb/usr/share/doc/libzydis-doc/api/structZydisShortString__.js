var structZydisShortString__ =
[
    [ "data", "structZydisShortString__.html#a8f64897c7ccc5c13f276d1d07c4e7095", null ],
    [ "size", "structZydisShortString__.html#a51dd38788728d5b76de8096e9a15c51f", null ]
];