var structZydisEncoderRequest__ =
[
    [ "ZydisEncoderRequestEvexFeatures_", "structZydisEncoderRequest___1_1ZydisEncoderRequestEvexFeatures__.html", "structZydisEncoderRequest___1_1ZydisEncoderRequestEvexFeatures__" ],
    [ "ZydisEncoderRequestMvexFeatures_", "structZydisEncoderRequest___1_1ZydisEncoderRequestMvexFeatures__.html", "structZydisEncoderRequest___1_1ZydisEncoderRequestMvexFeatures__" ],
    [ "address_size_hint", "structZydisEncoderRequest__.html#adde315b18528f7d054e645653cecc4b5", null ],
    [ "allowed_encodings", "structZydisEncoderRequest__.html#a49ed45564d8b0794c2c0722d1f396597", null ],
    [ "branch_type", "structZydisEncoderRequest__.html#a0fc13a5a26ccb4d406021418c65b5556", null ],
    [ "branch_width", "structZydisEncoderRequest__.html#ad25e2147b90b2a3293b39a6de2018af4", null ],
    [ "machine_mode", "structZydisEncoderRequest__.html#a57df7a98d175d0655fdf0102b09b2a0a", null ],
    [ "mnemonic", "structZydisEncoderRequest__.html#a1409f3c79728888de80b633050ec5cc5", null ],
    [ "operand_count", "structZydisEncoderRequest__.html#ab88c7cdf4c1038993c346837450fe100", null ],
    [ "operand_size_hint", "structZydisEncoderRequest__.html#a15070bafa60027cc136c7406e98ae9ed", null ],
    [ "operands", "structZydisEncoderRequest__.html#a9eeecd91fe871fa02e6ffd5e5d916b85", null ],
    [ "prefixes", "structZydisEncoderRequest__.html#a3bec8c70f4ff18f17ee83b082f37f570", null ]
];