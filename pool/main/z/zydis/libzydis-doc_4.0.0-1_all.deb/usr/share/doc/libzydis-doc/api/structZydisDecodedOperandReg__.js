var structZydisDecodedOperandReg__ =
[
    [ "value", "structZydisDecodedOperandReg__.html#afff15511cc8333e81905217bf669f73f", null ]
];