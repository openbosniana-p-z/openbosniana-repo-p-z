var modules =
[
    [ "Instruction attributes", "group__instruction__attributes.html", "group__instruction__attributes" ],
    [ "Decoder", "group__decoder.html", "group__decoder" ],
    [ "Encoder", "group__encoder.html", "group__encoder" ],
    [ "Formatter", "group__formatter.html", "group__formatter" ],
    [ "Mnemonic", "group__mnemonic.html", "group__mnemonic" ],
    [ "Register", "group__register.html", "group__register" ],
    [ "Segment", "group__segment.html", "group__segment" ],
    [ "Utils", "group__utils.html", "group__utils" ],
    [ "Version", "group__version.html", "group__version" ]
];