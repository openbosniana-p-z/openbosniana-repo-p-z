var structZydisDecodedInstructionAvx___1_1ZydisDecodedInstructionAvxMask__ =
[
    [ "mode", "structZydisDecodedInstructionAvx___1_1ZydisDecodedInstructionAvxMask__.html#a9c79c84208b72e888c66881bd9e070d4", null ],
    [ "reg", "structZydisDecodedInstructionAvx___1_1ZydisDecodedInstructionAvxMask__.html#a26c6b755db3d4b6e281ec6328c75689d", null ]
];