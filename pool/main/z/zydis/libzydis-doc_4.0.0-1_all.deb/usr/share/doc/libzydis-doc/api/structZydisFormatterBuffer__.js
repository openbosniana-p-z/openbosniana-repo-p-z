var structZydisFormatterBuffer__ =
[
    [ "capacity", "structZydisFormatterBuffer__.html#aa5c579294bebe0bd4deaa46d8fb4c0c4", null ],
    [ "is_token_list", "structZydisFormatterBuffer__.html#ac35aa2997c8157e9fcf05b663a3511b6", null ],
    [ "string", "structZydisFormatterBuffer__.html#aa2e6fb7a114827fb81b2415c44645ece", null ]
];