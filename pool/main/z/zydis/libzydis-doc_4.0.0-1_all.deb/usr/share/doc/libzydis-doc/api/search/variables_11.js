var searchData=
[
  ['u_0',['u',['../unionZydisEncoderOperand___1_1ZydisEncoderOperandImm__.html#a505b48cd3f16ab59ff0269d29fb97ad3',1,'ZydisEncoderOperand_::ZydisEncoderOperandImm_']]],
  ['user_5fdata_1',['user_data',['../structZydisFormatterContext__.html#a0f53d287ac7c064d1a49d4bd93ca1cb9',1,'ZydisFormatterContext_']]]
];
