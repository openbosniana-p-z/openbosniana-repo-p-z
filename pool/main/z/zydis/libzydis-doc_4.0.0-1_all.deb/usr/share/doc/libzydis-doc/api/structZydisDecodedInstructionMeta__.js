var structZydisDecodedInstructionMeta__ =
[
    [ "branch_type", "structZydisDecodedInstructionMeta__.html#a0fc13a5a26ccb4d406021418c65b5556", null ],
    [ "category", "structZydisDecodedInstructionMeta__.html#afdab63bc2a807e32252282cd105b98f4", null ],
    [ "exception_class", "structZydisDecodedInstructionMeta__.html#aeebc96bfa324e071c069912972edf4e2", null ],
    [ "isa_ext", "structZydisDecodedInstructionMeta__.html#abfee6332caf51120b2f38f35c2d67c79", null ],
    [ "isa_set", "structZydisDecodedInstructionMeta__.html#ab85d7ae2707243f8756a1cbd6a40fc84", null ]
];