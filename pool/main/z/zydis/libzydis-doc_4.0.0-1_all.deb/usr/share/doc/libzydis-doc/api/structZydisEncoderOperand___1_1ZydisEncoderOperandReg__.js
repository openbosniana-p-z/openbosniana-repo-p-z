var structZydisEncoderOperand___1_1ZydisEncoderOperandReg__ =
[
    [ "is4", "structZydisEncoderOperand___1_1ZydisEncoderOperandReg__.html#a9b219501dcf5651392c04683e87ab505", null ],
    [ "value", "structZydisEncoderOperand___1_1ZydisEncoderOperandReg__.html#afff15511cc8333e81905217bf669f73f", null ]
];