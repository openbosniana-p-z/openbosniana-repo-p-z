#ifndef META_IOSTREAMS_H
#define META_IOSTREAMS_H

// Includes the different iostream libraries

#include "zipios++/zipios-config.h"

#include <iostream>
#include <fstream>
#include <sstream>

#endif
