#include <stdlib.h>

int main(void) {
	return EXIT_CODE;
}
