#include <stdlib.h>
#include <stdio.h>

#include "hello.h"

int hello(void) {
	return printf("Hello World\n");
}
