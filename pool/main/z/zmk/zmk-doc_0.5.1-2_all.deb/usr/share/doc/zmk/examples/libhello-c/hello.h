#pragma once

int hello(void);
