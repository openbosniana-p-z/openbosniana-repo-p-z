Templates can be expanded many times, as long as the last argument is
different. Each template describes a distinct set of targets, we can use
target-specific variables to pass preprocessor options unique to each program,
even though they apply to the same source file.
