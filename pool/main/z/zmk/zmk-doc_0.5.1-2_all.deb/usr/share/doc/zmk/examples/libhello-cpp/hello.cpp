#include <iostream>

#include "hello.h"

void hello(void) {
	std::cout << "Hello World" << std::endl;
}
