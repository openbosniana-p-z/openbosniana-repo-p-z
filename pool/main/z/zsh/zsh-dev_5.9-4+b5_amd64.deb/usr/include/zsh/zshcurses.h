#include <ncursesw/ncurses.h>
