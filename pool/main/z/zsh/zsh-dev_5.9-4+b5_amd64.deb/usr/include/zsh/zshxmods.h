#define LINKED_XMOD_zshQsmain 1
#ifdef DYNAMIC
# define UNLINKED_XMOD_zshQsrlimits 1
#endif
#ifdef DYNAMIC
# define UNLINKED_XMOD_zshQssched 1
#endif
#ifdef DYNAMIC
# define UNLINKED_XMOD_zshQsparamQsprivate 1
#endif
#ifdef DYNAMIC
# define UNLINKED_XMOD_zshQsparameter 1
#endif
#ifdef DYNAMIC
# define UNLINKED_XMOD_zshQstermcap 1
#endif
#ifdef DYNAMIC
# define UNLINKED_XMOD_zshQsterminfo 1
#endif
#ifdef DYNAMIC
# define UNLINKED_XMOD_zshQswatch 1
#endif
#ifdef DYNAMIC
# define UNLINKED_XMOD_zshQszutil 1
#endif
#ifdef DYNAMIC
# define UNLINKED_XMOD_zshQscompctl 1
#endif
#ifdef DYNAMIC
# define UNLINKED_XMOD_zshQscomplete 1
#endif
#ifdef DYNAMIC
# define UNLINKED_XMOD_zshQscomplist 1
#endif
#ifdef DYNAMIC
# define UNLINKED_XMOD_zshQscomputil 1
#endif
#ifdef DYNAMIC
# define UNLINKED_XMOD_zshQszle 1
#endif
#ifdef DYNAMIC
# define UNLINKED_XMOD_zshQszleparameter 1
#endif
