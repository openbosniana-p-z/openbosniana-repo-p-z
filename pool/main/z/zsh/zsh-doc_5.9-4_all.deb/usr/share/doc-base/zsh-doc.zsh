Document: zsh
Title: Z Shell Manual
Author: Z-Shell workers
Abstract: This guide documents Zsh, a freely available UNIX command
 interpreter (shell), which of the standard shells most closely
 resembles the Korn shell (ksh), although it is not completely
 compatible.
Section: Shells

Format: info
Index: /usr/share/info/zsh.info.gz
Files: /usr/share/info/zsh.info*

Format: HTML
Index: /usr/share/doc/zsh-doc/html/index.html
Files: /usr/share/doc/zsh-doc/html/*.html

Format: PDF
Files: /usr/share/doc/zsh-doc/zsh.pdf
