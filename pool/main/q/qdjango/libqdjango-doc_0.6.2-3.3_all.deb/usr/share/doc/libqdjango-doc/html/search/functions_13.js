var searchData=
[
  ['values_276',['values',['../classQDjangoQuerySet.html#a9e558d61d83f171a3e627295d544ccb1',1,'QDjangoQuerySet']]],
  ['valueslist_277',['valuesList',['../classQDjangoQuerySet.html#a7125a4bf5e722c8af322c1b6e4be05b0',1,'QDjangoQuerySet']]]
];
