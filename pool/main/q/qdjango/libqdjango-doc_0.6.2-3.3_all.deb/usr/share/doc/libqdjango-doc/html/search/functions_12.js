var searchData=
[
  ['update_274',['update',['../classQDjangoQuerySet.html#a467e97426c6f19a118d1ff77b59f9431',1,'QDjangoQuerySet']]],
  ['urls_275',['urls',['../classQDjangoFastCgiServer.html#ab36301633a1c25a5c310c9fa7b7df7a9',1,'QDjangoFastCgiServer::urls()'],['../classQDjangoHttpServer.html#aaef23baef4a4ab7b1113c7826de4e899',1,'QDjangoHttpServer::urls()']]]
];
