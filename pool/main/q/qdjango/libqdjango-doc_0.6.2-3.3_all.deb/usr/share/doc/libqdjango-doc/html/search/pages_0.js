var searchData=
[
  ['database_20configuration_310',['Database configuration',['../database.html',1,'']]],
  ['database_20models_311',['Database models',['../models.html',1,'']]]
];
