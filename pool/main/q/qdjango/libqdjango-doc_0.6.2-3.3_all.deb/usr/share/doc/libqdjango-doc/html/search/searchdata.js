var indexSectionsWithContent =
{
  0: "abcdefghilmnopqrstuvw~",
  1: "cq",
  2: "abcdefghilmnopqrstuvw~",
  3: "ci",
  4: "ho",
  5: "cegilns",
  6: "dh",
  7: "dm"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "typedefs",
  4: "enums",
  5: "enumvalues",
  6: "groups",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Typedefs",
  4: "Enumerations",
  5: "Enumerator",
  6: "Modules",
  7: "Pages"
};

