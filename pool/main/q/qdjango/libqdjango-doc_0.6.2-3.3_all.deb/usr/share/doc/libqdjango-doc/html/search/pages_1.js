var searchData=
[
  ['making_20queries_312',['Making queries',['../queries.html',1,'']]]
];
