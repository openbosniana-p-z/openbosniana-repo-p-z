#ifndef DEPRECATED_HEADER_QtWaylandClient_qwaylandclientexport_h
#define DEPRECATED_HEADER_QtWaylandClient_qwaylandclientexport_h
#if defined(__GNUC__)
#  warning Header <QtWaylandClient/qwaylandclientexport.h> is deprecated. Please include <QtWaylandClient/qtwaylandclientglobal.h> instead.
#elif defined(_MSC_VER)
#  pragma message ("Header <QtWaylandClient/qwaylandclientexport.h> is deprecated. Please include <QtWaylandClient/qtwaylandclientglobal.h> instead.")
#endif
#include <QtWaylandClient/qtwaylandclientglobal.h>
#if 0
#pragma qt_no_master_include
#endif
#endif
