var searchData=
[
  ['open_72',['open',['../classQLocalFile.html#a2898794716d4e2910fe09c0a032e0e6f',1,'QLocalFile']]]
];
