var searchData=
[
  ['badrequest_2',['BadRequest',['../classQHttpSocket.html#a199455f94e3c91ee67bb9cd0af0eb536a72ba1169441a61ec908b3971a4bc4501',1,'QHttpSocket']]],
  ['bytesavailable_3',['bytesAvailable',['../classQHttpSocket.html#a5ada6e23d298455ddd2d3369979e08a4',1,'QHttpSocket']]]
];
