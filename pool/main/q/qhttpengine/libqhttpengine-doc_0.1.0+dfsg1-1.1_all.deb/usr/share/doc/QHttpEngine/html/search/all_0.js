var searchData=
[
  ['addredirect_0',['addRedirect',['../classQHttpHandler.html#a358689d6ebeaf70ab8e2fa653827827c',1,'QHttpHandler']]],
  ['addsubhandler_1',['addSubHandler',['../classQHttpHandler.html#a61e95c830a8776cb414b221181758783',1,'QHttpHandler']]]
];
