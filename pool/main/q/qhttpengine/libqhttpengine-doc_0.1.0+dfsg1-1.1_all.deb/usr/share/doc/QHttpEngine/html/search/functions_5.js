var searchData=
[
  ['headers_67',['headers',['../classQHttpSocket.html#a0d58e0a0085b4d3650e3e7bf24090c38',1,'QHttpSocket']]],
  ['headersparsed_68',['headersParsed',['../classQHttpSocket.html#ac1dfb7fd647ebe57f29ea5c5fd2a85d1',1,'QHttpSocket']]]
];
