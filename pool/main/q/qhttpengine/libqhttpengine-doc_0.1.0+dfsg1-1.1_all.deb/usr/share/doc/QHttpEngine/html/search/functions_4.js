var searchData=
[
  ['finished_66',['finished',['../classQIODeviceCopier.html#a6394785500e4999be66daa73b19fbe3a',1,'QIODeviceCopier']]]
];
