var searchData=
[
  ['isheadersparsed_69',['isHeadersParsed',['../classQHttpSocket.html#a8615f7774f13318d3d0f90b2ead7593d',1,'QHttpSocket']]],
  ['issequential_70',['isSequential',['../classQHttpSocket.html#a3ffe149f80f22d0f52d74a3e60e5c824',1,'QHttpSocket']]]
];
