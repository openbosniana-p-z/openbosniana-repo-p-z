var searchData=
[
  ['readdata_87',['readData',['../classQHttpSocket.html#a07db9e4cac5904e9831b084e3cdf1c86',1,'QHttpSocket']]],
  ['route_88',['route',['../classQHttpHandler.html#af5d1fd21e97140b65d133224c1cbea8d',1,'QHttpHandler']]]
];
