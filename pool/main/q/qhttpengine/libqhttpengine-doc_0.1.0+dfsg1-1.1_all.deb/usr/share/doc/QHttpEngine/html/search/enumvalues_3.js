var searchData=
[
  ['methodnotallowed_106',['MethodNotAllowed',['../classQHttpSocket.html#a199455f94e3c91ee67bb9cd0af0eb536a06f9c63fbe94282681d6f72e273caa4f',1,'QHttpSocket']]],
  ['movedpermanently_107',['MovedPermanently',['../classQHttpSocket.html#a199455f94e3c91ee67bb9cd0af0eb536abc79309461a2e91d3fbc52caee5c1098',1,'QHttpSocket']]]
];
