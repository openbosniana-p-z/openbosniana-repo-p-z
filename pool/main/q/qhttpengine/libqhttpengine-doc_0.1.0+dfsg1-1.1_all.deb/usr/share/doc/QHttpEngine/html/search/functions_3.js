var searchData=
[
  ['error_65',['error',['../classQIODeviceCopier.html#adc5040cdeef7525c58652d0c33b029f1',1,'QIODeviceCopier']]]
];
