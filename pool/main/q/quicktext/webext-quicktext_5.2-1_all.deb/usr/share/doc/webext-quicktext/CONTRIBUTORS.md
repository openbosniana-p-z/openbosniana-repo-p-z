## Original Creator
* Emil Hesslow

## Current Maintainer
* John Bieling

## Contributors
* John Bieling
* Sebastian Haberey
* Emil Hesslow
* R Kent James
* Philippe Lieser
* Christian Schneider
* Janning Vygen
* bgeiring
* drakulis
* Peñalara Software S.L.
* Samuel Plentz

## Translators
* Alexey Sinitsyn (ru)
* Óvári (hu)
