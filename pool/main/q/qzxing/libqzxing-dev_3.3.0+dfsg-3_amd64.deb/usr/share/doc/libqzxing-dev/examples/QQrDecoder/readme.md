this project is deprecated thus removed. It is replaced by [QZXingLive](../QZXingLive/)

NOTE: the folder is preserved since there are links in forum threads that point to this project. Will be removed in future version