var searchData=
[
  ['offset_0',['offset',['../group__raw__connection.html#a894bdfa2d603d8343f8ef01dda6fcd23',1,'pn_raw_buffer_t']]]
];
