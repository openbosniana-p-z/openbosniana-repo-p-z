var group__types =
[
    [ "AMQP data types", "group__amqp__types.html", "group__amqp__types" ],
    [ "API data types", "group__api__types.html", "group__api__types" ]
];