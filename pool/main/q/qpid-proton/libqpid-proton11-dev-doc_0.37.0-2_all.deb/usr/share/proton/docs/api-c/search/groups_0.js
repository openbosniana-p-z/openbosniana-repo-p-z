var searchData=
[
  ['amqp_20data_20types_0',['AMQP data types',['../group__amqp__types.html',1,'']]],
  ['api_20data_20types_1',['API data types',['../group__api__types.html',1,'']]]
];
