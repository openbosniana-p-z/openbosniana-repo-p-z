var searchData=
[
  ['message_0',['Message',['../group__message.html',1,'']]],
  ['messenger_1',['Messenger',['../group__messenger.html',1,'']]]
];
