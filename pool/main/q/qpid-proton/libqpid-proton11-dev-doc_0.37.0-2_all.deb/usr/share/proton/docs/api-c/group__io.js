var group__io =
[
    [ "Proactor", "group__proactor.html", "group__proactor" ],
    [ "Proactor events", "group__proactor__events.html", null ],
    [ "Listener", "group__listener.html", "group__listener" ],
    [ "Raw connection", "group__raw__connection.html", "group__raw__connection" ],
    [ "Connection driver", "group__connection__driver.html", "group__connection__driver" ]
];