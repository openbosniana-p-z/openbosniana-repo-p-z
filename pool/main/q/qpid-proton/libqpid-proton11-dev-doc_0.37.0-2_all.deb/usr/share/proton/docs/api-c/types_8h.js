var types_8h =
[
    [ "PN_MILLIS_MAX", "group__api__types.html#ga46d74369b8b364df95fd7cfa843f6d64", null ],
    [ "pn_sequence_t", "group__api__types.html#ga0aa3ebc7c0f1f273a874dcb1553ccb0f", null ],
    [ "pn_millis_t", "group__api__types.html#ga9a701bc6dc9af9f42c3f4679172a723c", null ],
    [ "pn_seconds_t", "group__api__types.html#gafdede9be0526a8d0b9ab5d3149069af1", null ],
    [ "pn_timestamp_t", "group__amqp__types.html#gad337c365b498106064ec28e00e5fb6dd", null ],
    [ "pn_char_t", "group__amqp__types.html#gaa1713f25d484600197d2a25ace856672", null ],
    [ "pn_decimal32_t", "group__amqp__types.html#ga54d49ca7ff04ad10a57139c2d61f1d44", null ],
    [ "pn_decimal64_t", "group__amqp__types.html#ga7d8110bc953738d83ad8b9c543ef517f", null ],
    [ "pn_state_t", "group__connection.html#gaa83193a655e32bffc18624acc2c39233", null ],
    [ "pn_connection_t", "group__connection.html#ga886351d81ff3a977a284a206526c5aff", null ],
    [ "pn_session_t", "group__session.html#ga38ccb93b8f5c2892adafce5d5f0fbcd9", null ],
    [ "pn_link_t", "group__link.html#ga89dad3aa7934329a7ff467c636687bc0", null ],
    [ "pn_delivery_t", "group__delivery.html#gacdfce854066c0a4ff4db9f9a0478f340", null ],
    [ "pn_collector_t", "group__event.html#ga905cdecedb8020bc28e648e43348b5d1", null ],
    [ "pn_listener_t", "group__listener.html#ga68ac7072ae60612d0bca5470014bf216", null ],
    [ "pn_transport_t", "group__transport.html#gac26eda05f649bbf0399f3d8d78d12fa8", null ],
    [ "pn_proactor_t", "group__proactor.html#gabba42c7929dfceb9d296535bad0c93dc", null ],
    [ "pn_raw_connection_t", "group__raw__connection.html#ga771f248632968276665fb90245023e86", null ],
    [ "pn_event_batch_t", "group__proactor.html#ga6bc581dfeaa8e8d46d07d37229d565c9", null ],
    [ "pn_bytes", "group__api__types.html#gab4f7e8d204246a3702c6e31a404b0edb", null ],
    [ "pn_rwbytes", "group__api__types.html#ga9fb5bee0255a52b1b8b8fa1b8620cbca", null ]
];