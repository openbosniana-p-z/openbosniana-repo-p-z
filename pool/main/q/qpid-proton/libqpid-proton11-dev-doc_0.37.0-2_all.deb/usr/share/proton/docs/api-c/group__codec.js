var group__codec =
[
    [ "Data", "group__data.html", "group__data" ]
];