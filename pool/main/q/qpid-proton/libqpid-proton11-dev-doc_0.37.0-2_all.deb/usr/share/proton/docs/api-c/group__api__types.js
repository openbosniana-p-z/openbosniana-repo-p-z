var group__api__types =
[
    [ "pn_atom_t", "group__api__types.html#structpn__atom__t", [
      [ "type", "group__api__types.html#a27df760d7bd97cf728fc3e633a1ba604", null ]
    ] ],
    [ "pn_bytes_t", "group__api__types.html#structpn__bytes__t", null ],
    [ "pn_rwbytes_t", "group__api__types.html#structpn__rwbytes__t", null ],
    [ "PN_MILLIS_MAX", "group__api__types.html#ga46d74369b8b364df95fd7cfa843f6d64", null ],
    [ "pn_msgid_t", "group__api__types.html#ga257b206a654378e611b87b463a6f5e03", null ],
    [ "pn_sequence_t", "group__api__types.html#ga0aa3ebc7c0f1f273a874dcb1553ccb0f", null ],
    [ "pn_millis_t", "group__api__types.html#ga9a701bc6dc9af9f42c3f4679172a723c", null ],
    [ "pn_seconds_t", "group__api__types.html#gafdede9be0526a8d0b9ab5d3149069af1", null ],
    [ "pn_bytes", "group__api__types.html#gab4f7e8d204246a3702c6e31a404b0edb", null ],
    [ "pn_rwbytes", "group__api__types.html#ga9fb5bee0255a52b1b8b8fa1b8620cbca", null ]
];