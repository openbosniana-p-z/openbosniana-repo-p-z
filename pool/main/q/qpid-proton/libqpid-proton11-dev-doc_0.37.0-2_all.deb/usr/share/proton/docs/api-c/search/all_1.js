var searchData=
[
  ['buffering_0',['Buffering',['../buffering.html',1,'md__build_qpid_proton_R0zXU8_qpid_proton_0_37_0_c_docs_advanced']]],
  ['bytes_1',['bytes',['../group__raw__connection.html#adcc78999fdbb41052741a6e30b16fab5',1,'pn_raw_buffer_t']]]
];
