var group__raw__connection_structpn__raw__buffer__t =
[
    [ "context", "group__raw__connection.html#afb301b46bf1bb94237366e0db5c62810", null ],
    [ "bytes", "group__raw__connection.html#adcc78999fdbb41052741a6e30b16fab5", null ],
    [ "capacity", "group__raw__connection.html#a391c992c66c3e5540265a85ec2b9216a", null ],
    [ "size", "group__raw__connection.html#ab2c6b258f02add8fdf4cfc7c371dd772", null ],
    [ "offset", "group__raw__connection.html#a894bdfa2d603d8343f8ef01dda6fcd23", null ]
];