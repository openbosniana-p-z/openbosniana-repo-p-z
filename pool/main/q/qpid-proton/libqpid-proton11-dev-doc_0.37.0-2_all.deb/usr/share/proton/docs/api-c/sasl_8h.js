var sasl_8h =
[
    [ "pn_sasl_t", "group__sasl.html#ga4d21fddba80d3f88d0529aafe12328b0", null ],
    [ "pn_sasl_outcome_t", "group__sasl.html#gad44e79f52e0669b1930689b56dfa9c3b", [
      [ "PN_SASL_NONE", "group__sasl.html#ggad44e79f52e0669b1930689b56dfa9c3ba1c90ef54986e694f0d94036977681785", null ],
      [ "PN_SASL_OK", "group__sasl.html#ggad44e79f52e0669b1930689b56dfa9c3ba0050b91650a3826a090e13f57b3b941e", null ],
      [ "PN_SASL_AUTH", "group__sasl.html#ggad44e79f52e0669b1930689b56dfa9c3bac63734ecde7c8170554f6bf04f6ce64a", null ],
      [ "PN_SASL_SYS", "group__sasl.html#ggad44e79f52e0669b1930689b56dfa9c3bacd46a2fda23f674c23ed81e6076c1939", null ],
      [ "PN_SASL_PERM", "group__sasl.html#ggad44e79f52e0669b1930689b56dfa9c3ba03019f909ba1d98aae94437ca4bd0191", null ],
      [ "PN_SASL_TEMP", "group__sasl.html#ggad44e79f52e0669b1930689b56dfa9c3baee28d2c03fa80dccf771e37aae1bcdf3", null ]
    ] ],
    [ "pn_sasl", "group__sasl.html#ga0b287f50e0258a713710b1625ae6f2d7", null ],
    [ "pn_sasl_extended", "group__sasl.html#ga1737191972d5dded0993bf1431e71df0", null ],
    [ "pn_sasl_done", "group__sasl.html#ga0199871440c4ff89a204cc1d8a09f283", null ],
    [ "pn_sasl_outcome", "group__sasl.html#ga03b6daf742db6a07bd7d03cb197aedb6", null ],
    [ "pn_sasl_get_user", "group__sasl.html#ga7aa71eed3fd5c5e3cc59974282b78a13", null ],
    [ "pn_sasl_get_authorization", "group__sasl.html#ga26ce0a40eb719cefa43887b420cb55e9", null ],
    [ "pn_sasl_get_mech", "group__sasl.html#ga0da7bf3bb912cb9cd594261a9a5de208", null ],
    [ "pn_sasl_allowed_mechs", "group__sasl.html#ga73299a6a22e141e7911a739590032625", null ],
    [ "pn_sasl_set_allow_insecure_mechs", "group__sasl.html#gaf472325bc055bb18a5a6f5ca03eda315", null ],
    [ "pn_sasl_get_allow_insecure_mechs", "group__sasl.html#gac53ad15ee429b7ce9d0c598d1e347243", null ],
    [ "pn_sasl_config_name", "group__sasl.html#gad1a6932135165f0e5b7639b79ac71c56", null ],
    [ "pn_sasl_config_path", "group__sasl.html#gabf4176414424ce02a4e03b4338d30521", null ]
];