var searchData=
[
  ['data_0',['Data',['../group__data.html',1,'']]],
  ['delivery_1',['Delivery',['../group__delivery.html',1,'']]],
  ['delivery_2eh_2',['delivery.h',['../delivery_8h.html',1,'']]],
  ['deprecated_20list_3',['Deprecated List',['../deprecated.html',1,'']]],
  ['disposition_2eh_4',['disposition.h',['../disposition_8h.html',1,'']]]
];
