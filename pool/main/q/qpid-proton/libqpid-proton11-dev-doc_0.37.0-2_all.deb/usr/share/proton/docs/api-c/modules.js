var modules =
[
    [ "Core", "group__core.html", "group__core" ],
    [ "Types", "group__types.html", "group__types" ],
    [ "Codec", "group__codec.html", "group__codec" ],
    [ "IO", "group__io.html", "group__io" ],
    [ "Messenger", "group__messenger.html", "group__messenger" ],
    [ "URL", "group__url.html", "group__url" ],
    [ "Tls", "group__tls.html", "group__tls" ]
];