var md__build_qpid_proton_R0zXU8_qpid_proton_0_37_0_c_docs_advanced =
[
    [ "Multithreading", "threads.html", null ],
    [ "IO integration", "io_page.html", null ],
    [ "Buffering", "buffering.html", null ],
    [ "Logging", "logging.html", null ]
];