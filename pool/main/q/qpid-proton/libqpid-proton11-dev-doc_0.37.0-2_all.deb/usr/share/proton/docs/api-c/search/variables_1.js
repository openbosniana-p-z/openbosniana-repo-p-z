var searchData=
[
  ['capacity_0',['capacity',['../group__raw__connection.html#a391c992c66c3e5540265a85ec2b9216a',1,'pn_raw_buffer_t']]],
  ['context_1',['context',['../group__raw__connection.html#afb301b46bf1bb94237366e0db5c62810',1,'pn_raw_buffer_t']]]
];
