var group__session =
[
    [ "pn_session_t", "group__session.html#ga38ccb93b8f5c2892adafce5d5f0fbcd9", null ],
    [ "pn_session", "group__session.html#gaf4fc8ecfea1cc1e19f7ff656bc174a91", null ],
    [ "pn_session_free", "group__session.html#ga0f95b5177494a68991d75444c2f6f812", null ],
    [ "pn_session_get_context", "group__session.html#gaa2b355fd927f7cd900aa044da3bb2370", null ],
    [ "pn_session_set_context", "group__session.html#ga31f2e4cc76135f79e96453aa72d441b2", null ],
    [ "pn_session_attachments", "group__session.html#ga2c00f2ca6afd81597a2a4711df54fec9", null ],
    [ "pn_session_state", "group__session.html#ga7e2a4567e3488a225257e4d883a7e78f", null ],
    [ "pn_session_error", "group__session.html#gacb6ed136649d89537b588f745e7e8139", null ],
    [ "pn_session_condition", "group__session.html#ga7a12ebf13b310da343875995eed809a2", null ],
    [ "pn_session_remote_condition", "group__session.html#ga0cb34b770458ef6ebab10f35740c478d", null ],
    [ "pn_session_connection", "group__session.html#ga2073a165a6122f67f7f3e05f710185d2", null ],
    [ "pn_session_open", "group__session.html#ga2b345eada2c15249caaefaa894d1aae3", null ],
    [ "pn_session_close", "group__session.html#ga12e5c4e71b0df4087d16ccc8b63b42b5", null ],
    [ "pn_session_get_incoming_capacity", "group__session.html#ga1fdeb3d6606e869790a228d847136cb0", null ],
    [ "pn_session_set_incoming_capacity", "group__session.html#gaedc306d86e778cbf8eaaf528c3eacae9", null ],
    [ "pn_session_get_outgoing_window", "group__session.html#ga931b89bd737ab293056cb695dddd9800", null ],
    [ "pn_session_set_outgoing_window", "group__session.html#gaca5962e539688b4f31b5b91136aa3c79", null ],
    [ "pn_session_outgoing_bytes", "group__session.html#gabcae388cdcb33e976b490525ec600b50", null ],
    [ "pn_session_incoming_bytes", "group__session.html#ga55a8429e178831556844ab251ef67c77", null ],
    [ "pn_session_head", "group__session.html#ga2acb934598f2c561f5e79f5a76337254", null ],
    [ "pn_session_next", "group__session.html#ga707ab324eaf0f69a3a146ab4f9106254", null ]
];