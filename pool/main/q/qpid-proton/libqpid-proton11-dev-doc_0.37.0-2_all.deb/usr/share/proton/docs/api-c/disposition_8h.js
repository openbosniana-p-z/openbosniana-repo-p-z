var disposition_8h =
[
    [ "PN_RECEIVED", "group__delivery.html#gaae349c977b37b584aa62fff6515802ca", null ],
    [ "PN_ACCEPTED", "group__delivery.html#gac64952b813a707586c6b3898e09552e4", null ],
    [ "PN_REJECTED", "group__delivery.html#ga44a2635392fe2e6f8869a7e1cd64db2f", null ],
    [ "PN_RELEASED", "group__delivery.html#ga628179c16c4a5f5fd7734bc1bfc6edc3", null ],
    [ "PN_MODIFIED", "group__delivery.html#ga247e3d1ac7c9096cdd28424353582962", null ],
    [ "pn_disposition_t", "group__delivery.html#ga4b28f6cd033babd8a7595fc5d292dca1", null ],
    [ "pn_disposition_type", "group__delivery.html#ga42387f728f4817fdd393cc98315db332", null ],
    [ "pn_disposition_type_name", "group__delivery.html#ga5677c82342535cfd4f2a751c7b7adbe8", null ],
    [ "pn_disposition_condition", "group__delivery.html#ga8ef255eccff9aea84eb0a285b399df7b", null ],
    [ "pn_disposition_data", "group__delivery.html#gad4e0ff0a25b05eae7d30db66f09fa9ef", null ],
    [ "pn_disposition_get_section_number", "group__delivery.html#ga5d0a4239487a90010403007f6cb268f0", null ],
    [ "pn_disposition_set_section_number", "group__delivery.html#ga102eb1d46ff8fbed816d5c619e5fa52f", null ],
    [ "pn_disposition_get_section_offset", "group__delivery.html#ga7c5a14c31891750fcd211d90770a96d7", null ],
    [ "pn_disposition_set_section_offset", "group__delivery.html#ga5940110912277fbd543f8be3066be98b", null ],
    [ "pn_disposition_is_failed", "group__delivery.html#ga62d917e8a18288fdb1719bf5488c3f53", null ],
    [ "pn_disposition_set_failed", "group__delivery.html#ga8001f9574b5f37dff71ccfbc0524672e", null ],
    [ "pn_disposition_is_undeliverable", "group__delivery.html#gae4d5ce97c27e18d3dd843b829b81c585", null ],
    [ "pn_disposition_set_undeliverable", "group__delivery.html#ga805e6f4953eb559d5acfcfd7084fc4b3", null ],
    [ "pn_disposition_annotations", "group__delivery.html#ga9bdf4fb7c5ad0789917146525a552384", null ]
];