var annotated_dup =
[
    [ "pn_atom_t", "group__api__types.html#structpn__atom__t", "group__api__types_structpn__atom__t" ],
    [ "pn_bytes_t", "group__api__types.html#structpn__bytes__t", null ],
    [ "pn_connection_driver_t", "group__connection__driver.html#structpn__connection__driver__t", null ],
    [ "pn_decimal128_t", "group__amqp__types.html#structpn__decimal128__t", null ],
    [ "pn_raw_buffer_t", "group__raw__connection.html#structpn__raw__buffer__t", "group__raw__connection_structpn__raw__buffer__t" ],
    [ "pn_rwbytes_t", "group__api__types.html#structpn__rwbytes__t", null ],
    [ "pn_uuid_t", "group__amqp__types.html#structpn__uuid__t", null ]
];