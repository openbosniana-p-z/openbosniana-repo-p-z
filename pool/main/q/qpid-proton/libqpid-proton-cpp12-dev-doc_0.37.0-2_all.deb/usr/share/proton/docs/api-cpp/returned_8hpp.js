var returned_8hpp =
[
    [ "returned< T >", "classproton_1_1returned.html", "classproton_1_1returned" ]
];