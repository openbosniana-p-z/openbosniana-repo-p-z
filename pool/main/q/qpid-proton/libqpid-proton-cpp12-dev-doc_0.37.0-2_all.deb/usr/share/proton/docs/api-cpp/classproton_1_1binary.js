var classproton_1_1binary =
[
    [ "operator std::string", "classproton_1_1binary.html#a3888dcd59dd5acd1ca5b9bee4c2e252a", null ],
    [ "operator=", "classproton_1_1binary.html#a624668c3cc13104cd21fdcafcaa07982", null ]
];