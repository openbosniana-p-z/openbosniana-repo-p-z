var classproton_1_1annotation__key =
[
    [ "annotation_key", "classproton_1_1annotation__key.html#ab9ab6d802bb051debd29c75493c16dde", null ],
    [ "annotation_key", "classproton_1_1annotation__key.html#afdd676d37486aa26af7fdd588f994d26", null ],
    [ "get", "classproton_1_1annotation__key.html#ace2642bea7a7ab2d830f42390eb4a604", null ],
    [ "get", "classproton_1_1annotation__key.html#aab3f78c82556a26b3c2e8736a7d0c777", null ],
    [ "coerce", "classproton_1_1annotation__key.html#ab73c44b530463fda5e11bc403ca9edd3", null ]
];