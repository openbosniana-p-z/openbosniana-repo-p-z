var classproton_1_1listen__handler =
[
    [ "on_open", "classproton_1_1listen__handler.html#a74a2a66bb05107bd04fbb15731b0578b", null ],
    [ "on_accept", "classproton_1_1listen__handler.html#a3f8b8dc9641dc3a3ed19e2a60ec8eccc", null ],
    [ "on_error", "classproton_1_1listen__handler.html#a0969610957fd465626cfad89db38ef53", null ],
    [ "on_close", "classproton_1_1listen__handler.html#af30c2c3ffe8921962a164abb1b2a398e", null ]
];