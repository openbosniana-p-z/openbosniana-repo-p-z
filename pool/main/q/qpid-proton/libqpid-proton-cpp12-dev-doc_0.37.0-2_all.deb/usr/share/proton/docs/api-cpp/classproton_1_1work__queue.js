var classproton_1_1work__queue =
[
    [ "work_queue", "classproton_1_1work__queue.html#a1e7fdf3236c9477c0462214080c34689", null ],
    [ "work_queue", "classproton_1_1work__queue.html#a689e0d941a552db276229a9fc312e143", null ],
    [ "add", "classproton_1_1work__queue.html#a59dae2153455bc095477a3b66a0b681e", null ],
    [ "add", "classproton_1_1work__queue.html#a7525d36e11cc3eb9d483e8e81713ab6d", null ],
    [ "schedule", "classproton_1_1work__queue.html#a214d82f5924296d6fddbb8b150f8b601", null ],
    [ "schedule", "classproton_1_1work__queue.html#aee24365669f2a5d5906866d56c5b2a6e", null ]
];