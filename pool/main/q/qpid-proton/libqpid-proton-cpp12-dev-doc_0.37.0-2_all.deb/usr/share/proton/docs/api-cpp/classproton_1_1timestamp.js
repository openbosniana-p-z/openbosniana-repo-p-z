var classproton_1_1timestamp =
[
    [ "numeric_type", "classproton_1_1timestamp.html#a44829e89515fec974f57f37bbdbfaeb2", null ],
    [ "timestamp", "classproton_1_1timestamp.html#a7dd3e30aaca70057a02dca7cc5eb5b4d", null ],
    [ "operator=", "classproton_1_1timestamp.html#a6a876be088e3919994cf768127ec0be4", null ],
    [ "milliseconds", "classproton_1_1timestamp.html#afb6516c796d13a88dcbd295247f0f535", null ]
];