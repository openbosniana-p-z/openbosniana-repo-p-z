var classproton_1_1scalar =
[
    [ "scalar", "classproton_1_1scalar.html#ac06090aff8ef302b51587eb43b2ece44", null ],
    [ "scalar", "classproton_1_1scalar.html#a247e504774a50ea9baeb9330d459a486", null ],
    [ "operator=", "classproton_1_1scalar.html#a504b291a49333d9b26c3a1867a938efe", null ],
    [ "clear", "classproton_1_1scalar.html#ac8bb3912a3ce86b15842e79d0b421204", null ],
    [ "get", "classproton_1_1scalar.html#a61968283b9e1fc067dcad67e9fe58f6a", null ],
    [ "coerce", "classproton_1_1scalar.html#a59517f5cda18ae5c612f0c760398fe1d", null ],
    [ "coerce", "classproton_1_1scalar.html#a31eda8feb7c15956a8c9091737505789", null ]
];