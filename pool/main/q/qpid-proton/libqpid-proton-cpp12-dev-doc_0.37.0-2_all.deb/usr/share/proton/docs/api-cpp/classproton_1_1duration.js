var classproton_1_1duration =
[
    [ "numeric_type", "classproton_1_1duration.html#a44829e89515fec974f57f37bbdbfaeb2", null ],
    [ "duration", "classproton_1_1duration.html#aa4fb0163afbe72b04236e39e2b6d2dbf", null ],
    [ "operator=", "classproton_1_1duration.html#ab22da4f658a4d377425d67528466cfa6", null ],
    [ "milliseconds", "classproton_1_1duration.html#afb6516c796d13a88dcbd295247f0f535", null ]
];