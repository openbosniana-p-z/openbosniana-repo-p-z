var classproton_1_1transport =
[
    [ "transport", "classproton_1_1transport.html#aa1996a887a9af5c8c18c739ab08588d6", null ],
    [ "connection", "classproton_1_1transport.html#aff302bb6016f2ae29f01bb4e07389a52", null ],
    [ "ssl", "classproton_1_1transport.html#a73fe833a759ac581baa889155b7d0633", null ],
    [ "sasl", "classproton_1_1transport.html#a150f1a1b6c9cf6605d44f4cc150a11cc", null ],
    [ "error", "classproton_1_1transport.html#a090a10fab22d7faf0f74c8ccda0f1470", null ]
];