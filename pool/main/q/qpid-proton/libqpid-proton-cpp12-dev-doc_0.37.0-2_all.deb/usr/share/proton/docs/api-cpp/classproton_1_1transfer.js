var classproton_1_1transfer =
[
    [ "state", "classproton_1_1transfer.html#adc6e5733fc3c22f0a7b2914188c49c90", [
      [ "NONE", "classproton_1_1transfer.html#adc6e5733fc3c22f0a7b2914188c49c90ac157bdf0b85a40d2619cbc8bc1ae5fe2", null ],
      [ "RECEIVED", "classproton_1_1transfer.html#adc6e5733fc3c22f0a7b2914188c49c90a1cf265da0334753368223d47f242a8df", null ],
      [ "ACCEPTED", "classproton_1_1transfer.html#adc6e5733fc3c22f0a7b2914188c49c90a69c37229a15f9a89e188ad210f31c647", null ],
      [ "REJECTED", "classproton_1_1transfer.html#adc6e5733fc3c22f0a7b2914188c49c90adc7d25ac50cec5a18810f4e4f6614364", null ],
      [ "RELEASED", "classproton_1_1transfer.html#adc6e5733fc3c22f0a7b2914188c49c90aa38d18fe73a7fc82c112b6917d0b5cd0", null ],
      [ "MODIFIED", "classproton_1_1transfer.html#adc6e5733fc3c22f0a7b2914188c49c90a26d303ed91d56d618217b9a038512754", null ]
    ] ],
    [ "transfer", "classproton_1_1transfer.html#a27689e22340a12302f25eec6072c5d22", null ],
    [ "state", "classproton_1_1transfer.html#a8073c1382e7adf81536001a8007924a5", null ],
    [ "session", "classproton_1_1transfer.html#ab55cf76248b8b6e571a869c407ba39e6", null ],
    [ "connection", "classproton_1_1transfer.html#aff302bb6016f2ae29f01bb4e07389a52", null ],
    [ "work_queue", "classproton_1_1transfer.html#a9cabc5284b3663af85c596e36669df15", null ],
    [ "container", "classproton_1_1transfer.html#abae81cfa576de73a4e356fa66f74a229", null ],
    [ "settle", "classproton_1_1transfer.html#a172df06404ec241cee5281536db603a7", null ],
    [ "settled", "classproton_1_1transfer.html#ad72f81828cfabb957615d40cfdfed452", null ]
];