var searchData=
[
  ['work_5fqueue_0',['work_queue',['../classproton_1_1work__queue.html',1,'proton']]]
];
