var classproton_1_1scalar__base =
[
    [ "type", "classproton_1_1scalar__base.html#a89dd77b1757d854f49d49e379f8f9db8", null ],
    [ "empty", "classproton_1_1scalar__base.html#a644718bb2fb240de962dc3c9a1fdf0dc", null ],
    [ "operator<", "classproton_1_1scalar__base.html#a40bfb9a20944ad3d19f8a90a27a82576", null ],
    [ "operator==", "classproton_1_1scalar__base.html#a03d4c26cca0115ee1fe1c547e35ec651", null ],
    [ "operator<<", "classproton_1_1scalar__base.html#a4852ef1ab0da8ac8efba9add6be63ccc", null ]
];