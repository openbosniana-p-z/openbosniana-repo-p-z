var scalar__base_8hpp =
[
    [ "scalar_base", "classproton_1_1scalar__base.html", "classproton_1_1scalar__base" ],
    [ "to_string", "scalar__base_8hpp.html#a42d82ffe379237145a0c140b9c9f88a2", null ]
];