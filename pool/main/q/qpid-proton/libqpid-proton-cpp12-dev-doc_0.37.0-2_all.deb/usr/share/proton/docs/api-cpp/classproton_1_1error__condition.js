var classproton_1_1error__condition =
[
    [ "error_condition", "classproton_1_1error__condition.html#a37954cfca18c964f680836b837874f39", null ],
    [ "error_condition", "classproton_1_1error__condition.html#a4f32954b9494f55fa28e99c3402f254b", null ],
    [ "error_condition", "classproton_1_1error__condition.html#ab882b2726f7171112feba9d03ff9a588", null ],
    [ "error_condition", "classproton_1_1error__condition.html#a7f06478c5510128d7cf62b394161b9b3", null ],
    [ "operator bool", "classproton_1_1error__condition.html#a67b76affb3b5d35fa419ac234144038b", null ],
    [ "operator!", "classproton_1_1error__condition.html#a61efd4196a96540ee018fee8791f3f10", null ],
    [ "empty", "classproton_1_1error__condition.html#a644718bb2fb240de962dc3c9a1fdf0dc", null ],
    [ "name", "classproton_1_1error__condition.html#a1d89c28bd42ba9a52da008bb69367171", null ],
    [ "description", "classproton_1_1error__condition.html#a07ffe70037e0a16554c868bcdd8f83b5", null ],
    [ "properties", "classproton_1_1error__condition.html#ac692ae9e7014e2ef47673c9201a98cf6", null ],
    [ "what", "classproton_1_1error__condition.html#ad2e53bd52dbb1d59081ee7f9f1efc2ac", null ]
];