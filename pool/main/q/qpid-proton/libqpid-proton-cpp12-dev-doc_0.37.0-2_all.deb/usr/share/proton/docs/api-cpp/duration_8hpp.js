var duration_8hpp =
[
    [ "duration", "classproton_1_1duration.html", "classproton_1_1duration" ],
    [ "operator<<", "duration_8hpp.html#a86c8f881d0d473769044afa7613f9b2d", null ]
];