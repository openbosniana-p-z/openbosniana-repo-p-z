var searchData=
[
  ['handler_0',['handler',['../classproton_1_1connection__options.html#a6cbaba44feaf2eef9178f7deba95ce36',1,'proton::connection_options::handler()'],['../classproton_1_1receiver__options.html#a39edd76e50c71c57cdceff6932b3cc68',1,'proton::receiver_options::handler()'],['../classproton_1_1sender__options.html#ae5eb679658749726a703290bca9fecc3',1,'proton::sender_options::handler()'],['../classproton_1_1session__options.html#a059caf65a9417e22417006a8b166a54a',1,'proton::session_options::handler()']]],
  ['has_5fevents_1',['has_events',['../classproton_1_1io_1_1connection__driver.html#a8be634582ecaf2ae8d059d30fa97cf00',1,'proton::io::connection_driver']]],
  ['host_2',['host',['../classproton_1_1url.html#a5f0eba713a692bc0aa00b2b8ec0e9ba1',1,'proton::url']]],
  ['host_5fport_3',['host_port',['../classproton_1_1url.html#a0a36cd36a47626cec96d0803dd3a9594',1,'proton::url']]]
];
