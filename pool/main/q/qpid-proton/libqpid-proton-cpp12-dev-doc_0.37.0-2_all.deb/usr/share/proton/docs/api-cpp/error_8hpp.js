var error_8hpp =
[
    [ "error", "structproton_1_1error.html", "structproton_1_1error" ],
    [ "timeout_error", "structproton_1_1timeout__error.html", "structproton_1_1timeout__error" ],
    [ "conversion_error", "structproton_1_1conversion__error.html", "structproton_1_1conversion__error" ]
];