var classproton_1_1returned =
[
    [ "returned", "classproton_1_1returned.html#a7e6c2d7eb0ba9807a9fb9fee0f628508", null ],
    [ "operator T", "classproton_1_1returned.html#a54724b9dd792a6022b918eae2f393734", null ]
];