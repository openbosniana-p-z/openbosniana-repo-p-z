var classproton_1_1reconnect__options =
[
    [ "reconnect_options", "classproton_1_1reconnect__options.html#ac327dafeb06728192df6cb94dde35edc", null ],
    [ "reconnect_options", "classproton_1_1reconnect__options.html#aef23a4a6b4f399f86ba458e855e0ca08", null ],
    [ "operator=", "classproton_1_1reconnect__options.html#aff7446bebfde229c8f3f5974a16533a2", null ],
    [ "delay", "classproton_1_1reconnect__options.html#a4f0b957f7664620162e8ee04303495ef", null ],
    [ "delay_multiplier", "classproton_1_1reconnect__options.html#a07374c3e9e53ca000c2133defaef0887", null ],
    [ "max_delay", "classproton_1_1reconnect__options.html#ac74e1347cc8bbb15ac01948f999faf6e", null ],
    [ "max_attempts", "classproton_1_1reconnect__options.html#a87822533a98c456bb1e6af033744ca5a", null ],
    [ "failover_urls", "classproton_1_1reconnect__options.html#a1ad5e2e6d64336aa855effb3c1640bb6", null ]
];