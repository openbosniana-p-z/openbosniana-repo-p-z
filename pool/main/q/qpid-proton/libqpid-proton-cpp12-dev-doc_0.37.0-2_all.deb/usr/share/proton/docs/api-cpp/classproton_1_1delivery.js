var classproton_1_1delivery =
[
    [ "receiver", "classproton_1_1delivery.html#aeb4319de46c92afec4ebbb3116d67c39", null ],
    [ "accept", "classproton_1_1delivery.html#aadb9f3b844fb4cf98288cd3c60a3af91", null ],
    [ "reject", "classproton_1_1delivery.html#a84e832c2421763b25e1ae0d9a76f519c", null ],
    [ "release", "classproton_1_1delivery.html#a23b477d0e2d399f75d585d154c346591", null ],
    [ "modify", "classproton_1_1delivery.html#a7a2a3abb755d0d1a31414355520d054b", null ],
    [ "tag", "classproton_1_1delivery.html#abdd7ff3ef205a3434a5e76e4358a425a", null ]
];