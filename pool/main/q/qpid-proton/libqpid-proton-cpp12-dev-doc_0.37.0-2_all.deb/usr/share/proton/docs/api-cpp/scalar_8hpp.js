var scalar_8hpp =
[
    [ "scalar", "classproton_1_1scalar.html", "classproton_1_1scalar" ],
    [ "get", "scalar_8hpp.html#a61968283b9e1fc067dcad67e9fe58f6a", null ],
    [ "coerce", "scalar_8hpp.html#a59517f5cda18ae5c612f0c760398fe1d", null ],
    [ "coerce", "scalar_8hpp.html#a31eda8feb7c15956a8c9091737505789", null ]
];