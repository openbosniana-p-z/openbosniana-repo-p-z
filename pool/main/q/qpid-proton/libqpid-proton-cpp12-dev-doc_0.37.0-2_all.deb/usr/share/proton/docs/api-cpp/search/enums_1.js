var searchData=
[
  ['expiry_5fpolicy_0',['expiry_policy',['../classproton_1_1terminus.html#a348690a43df146eca928a8c06034a1eb',1,'proton::terminus::expiry_policy()'],['../classproton_1_1source.html#a348690a43df146eca928a8c06034a1eb',1,'proton::source::expiry_policy()'],['../classproton_1_1target.html#a348690a43df146eca928a8c06034a1eb',1,'proton::target::expiry_policy()']]]
];
