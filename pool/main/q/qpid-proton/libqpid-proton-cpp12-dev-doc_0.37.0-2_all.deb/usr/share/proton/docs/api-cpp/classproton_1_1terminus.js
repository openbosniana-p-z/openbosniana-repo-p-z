var classproton_1_1terminus =
[
    [ "durability_mode", "classproton_1_1terminus.html#a61db0571ab7d1a29ad77549ff99d6b3d", [
      [ "NONDURABLE", "classproton_1_1terminus.html#a61db0571ab7d1a29ad77549ff99d6b3dafdced71ad3dc05c5221439eddc3573e8", null ],
      [ "CONFIGURATION", "classproton_1_1terminus.html#a61db0571ab7d1a29ad77549ff99d6b3da07731dff0bf77faf2dc60a19c925e3c4", null ],
      [ "UNSETTLED_STATE", "classproton_1_1terminus.html#a61db0571ab7d1a29ad77549ff99d6b3da9a971a7b3eb61a4e22701f1f4099909f", null ]
    ] ],
    [ "expiry_policy", "classproton_1_1terminus.html#a348690a43df146eca928a8c06034a1eb", [
      [ "LINK_CLOSE", "classproton_1_1terminus.html#a348690a43df146eca928a8c06034a1eba7201cfe403ee6d4b4b717d146e38bee1", null ],
      [ "SESSION_CLOSE", "classproton_1_1terminus.html#a348690a43df146eca928a8c06034a1ebac028e516a1a662691a25993ab4f86c09", null ],
      [ "CONNECTION_CLOSE", "classproton_1_1terminus.html#a348690a43df146eca928a8c06034a1ebad1b07c50c2dc77892c0254442e206a23", null ],
      [ "NEVER", "classproton_1_1terminus.html#a348690a43df146eca928a8c06034a1eba3a267f9424d4d555780a8d26209c8118", null ]
    ] ],
    [ "expiry_policy", "classproton_1_1terminus.html#afc97dbb9b04812da5be8a41eb9434904", null ],
    [ "timeout", "classproton_1_1terminus.html#a16d54f985193a3ce6ac69ffe10e8dfb6", null ],
    [ "durability_mode", "classproton_1_1terminus.html#aeb6439d6ea5d274a59dd8e90d97f31d8", null ],
    [ "dynamic", "classproton_1_1terminus.html#adcc4ef24adb8478230018c519aa636ec", null ],
    [ "anonymous", "classproton_1_1terminus.html#a6a20cc0c11ce5a1e369fdd0a51f992f5", null ],
    [ "node_properties", "classproton_1_1terminus.html#ab503c82e36aa618e6c6fb34feaad57b8", null ],
    [ "capabilities", "classproton_1_1terminus.html#ac20890a51fbb85bad8970430a571cee1", null ],
    [ "dynamic_properties", "classproton_1_1terminus.html#a20a55b8754341f39ff3d05a082fc33fd", null ]
];