var searchData=
[
  ['ubyte_0',['UBYTE',['../namespaceproton.html#a83c2656d467d69eb49725c18f5aa13a9a29dfb12306aac24cadeaa1f6bac455be',1,'proton']]],
  ['uint_1',['UINT',['../namespaceproton.html#a83c2656d467d69eb49725c18f5aa13a9a4756f5bbd9f28d6b8905f32024b57398',1,'proton']]],
  ['ulong_2',['ULONG',['../namespaceproton.html#a83c2656d467d69eb49725c18f5aa13a9a574bf5ec73e28138b997d24464adb70c',1,'proton']]],
  ['uninitialized_3',['uninitialized',['../classproton_1_1session.html#ab51c3843057c4c187574e2d44839f815',1,'proton::session::uninitialized()'],['../classproton_1_1link.html#ab51c3843057c4c187574e2d44839f815',1,'proton::link::uninitialized()'],['../classproton_1_1connection.html#ab51c3843057c4c187574e2d44839f815',1,'proton::connection::uninitialized()'],['../classproton_1_1endpoint.html#ad8685241f060e866802c2e806135949e',1,'proton::endpoint::uninitialized()']]],
  ['unknown_4',['UNKNOWN',['../classproton_1_1ssl.html#a0d3f14f27a1e5af0a5f378fc1a8a8de4a6ce26a62afab55d7606ad4e92428b30c',1,'proton::ssl']]],
  ['unordered_5fmap_2ehpp_5',['unordered_map.hpp',['../unordered__map_8hpp.html',1,'']]],
  ['unsettled_5fstate_6',['UNSETTLED_STATE',['../classproton_1_1terminus.html#a61db0571ab7d1a29ad77549ff99d6b3da9a971a7b3eb61a4e22701f1f4099909f',1,'proton::terminus']]],
  ['unspecified_7',['UNSPECIFIED',['../classproton_1_1source.html#ad049690d03cac384636e0c2055726089aa876f4fb4e5f7f0c5c48fcf66c9ce7ce',1,'proton::source']]],
  ['update_8',['update',['../classproton_1_1connection__options.html#a9b6f2cb2216f39208aac53345da32435',1,'proton::connection_options::update()'],['../classproton_1_1receiver__options.html#a7bbed67f2faac1cd6a5c490dac90bda3',1,'proton::receiver_options::update()'],['../classproton_1_1sender__options.html#a16b609dbb6a9df5ab7e719f0de05026b',1,'proton::sender_options::update()']]],
  ['update_5foptions_9',['update_options',['../classproton_1_1connection.html#aa8322acd886ff87d19f153ba21270945',1,'proton::connection']]],
  ['url_10',['url',['../classproton_1_1url.html',1,'url'],['../classproton_1_1url.html#a2ac6e124f5c2a7a3c8464099b5c4fde7',1,'proton::url::url(const std::string &amp;url_str)'],['../classproton_1_1url.html#a0665da617d0ca28be2721c5f16368dd5',1,'proton::url::url(const url &amp;)']]],
  ['url_2ehpp_11',['url.hpp',['../url_8hpp.html',1,'']]],
  ['url_5ferror_12',['url_error',['../structproton_1_1url__error.html',1,'proton']]],
  ['user_13',['user',['../classproton_1_1connection__options.html#acefbaa7c7ee950313bc429c380856fc6',1,'proton::connection_options::user()'],['../classproton_1_1message.html#a0b0bee09eb1678dcfa1b72c0038a6c17',1,'proton::message::user(const std::string &amp;)'],['../classproton_1_1message.html#a9444df7d81bd265e0a8e1726fd12b058',1,'proton::message::user() const'],['../classproton_1_1sasl.html#a9444df7d81bd265e0a8e1726fd12b058',1,'proton::sasl::user()'],['../classproton_1_1url.html#a9444df7d81bd265e0a8e1726fd12b058',1,'proton::url::user()'],['../classproton_1_1connection.html#a9444df7d81bd265e0a8e1726fd12b058',1,'proton::connection::user()']]],
  ['ushort_14',['USHORT',['../namespaceproton.html#a83c2656d467d69eb49725c18f5aa13a9a9ae509995ac75484348487a7477900ca',1,'proton']]],
  ['uuid_15',['uuid',['../classproton_1_1uuid.html',1,'proton']]],
  ['uuid_16',['UUID',['../namespaceproton.html#a83c2656d467d69eb49725c18f5aa13a9aaf1ea4a849fa4bcb9d351a6bde6d7600',1,'proton']]],
  ['uuid_2ehpp_17',['uuid.hpp',['../uuid_8hpp.html',1,'']]]
];
