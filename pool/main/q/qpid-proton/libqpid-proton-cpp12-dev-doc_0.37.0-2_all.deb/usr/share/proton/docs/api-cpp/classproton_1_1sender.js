var classproton_1_1sender =
[
    [ "sender", "classproton_1_1sender.html#ae9ac4698541b37818867abd8d879cc29", null ],
    [ "open", "classproton_1_1sender.html#a9e8555112049fc2b4945120b3c45f8ab", null ],
    [ "open", "classproton_1_1sender.html#a0177dfbb87c4a94379c4ab6ac77a134e", null ],
    [ "send", "classproton_1_1sender.html#a214eb30b24e6831d016a47b9dddda830", null ],
    [ "source", "classproton_1_1sender.html#a91a9e8a9445b29d83dd0514cd76503ae", null ],
    [ "target", "classproton_1_1sender.html#a5f0b815f331997411a6794f8628592ba", null ],
    [ "return_credit", "classproton_1_1sender.html#abc4cb5f2f38643abb47c0b221a130bc8", null ]
];