var searchData=
[
  ['perm_0',['PERM',['../classproton_1_1sasl.html#af47997198e7e7301a1cd8602c7f02acdae0a57d717d9f8c8fdba757be1b0afdcf',1,'proton::sasl']]]
];
