var searchData=
[
  ['resume_5fstatus_0',['resume_status',['../classproton_1_1ssl.html#a0d3f14f27a1e5af0a5f378fc1a8a8de4',1,'proton::ssl']]]
];
