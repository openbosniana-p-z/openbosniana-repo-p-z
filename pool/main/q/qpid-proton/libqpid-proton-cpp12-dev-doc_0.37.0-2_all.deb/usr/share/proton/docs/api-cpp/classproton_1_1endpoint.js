var classproton_1_1endpoint =
[
    [ "uninitialized", "classproton_1_1endpoint.html#ad8685241f060e866802c2e806135949e", null ],
    [ "active", "classproton_1_1endpoint.html#a63fb7653fe206c5e9adef8f7ad6b4d7a", null ],
    [ "closed", "classproton_1_1endpoint.html#a13ef393e64458da714691f90545824e9", null ],
    [ "error", "classproton_1_1endpoint.html#a89e8462fcb53c5138e0b576122d07b32", null ],
    [ "close", "classproton_1_1endpoint.html#af6ee7eacbde6b379b68d954e44f6e549", null ],
    [ "close", "classproton_1_1endpoint.html#ad4fcddcba5b74ba7766ac6f125469644", null ]
];