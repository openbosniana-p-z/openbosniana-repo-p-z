var searchData=
[
  ['distribution_5fmode_0',['distribution_mode',['../classproton_1_1source.html#ad049690d03cac384636e0c2055726089',1,'proton::source']]],
  ['durability_5fmode_1',['durability_mode',['../classproton_1_1terminus.html#a61db0571ab7d1a29ad77549ff99d6b3d',1,'proton::terminus::durability_mode()'],['../classproton_1_1source.html#a61db0571ab7d1a29ad77549ff99d6b3d',1,'proton::source::durability_mode()'],['../classproton_1_1target.html#a61db0571ab7d1a29ad77549ff99d6b3d',1,'proton::target::durability_mode()']]]
];
