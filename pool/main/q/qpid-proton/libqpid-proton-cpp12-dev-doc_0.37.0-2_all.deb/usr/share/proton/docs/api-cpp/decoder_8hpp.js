var decoder_8hpp =
[
    [ "decoder", "classproton_1_1codec_1_1decoder.html", "classproton_1_1codec_1_1decoder" ],
    [ "operator>>", "decoder_8hpp.html#a31576613e483bf7221c60b21796b34f1", null ]
];