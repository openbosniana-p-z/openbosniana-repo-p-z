var classproton_1_1session__options =
[
    [ "session_options", "classproton_1_1session__options.html#ad0a94848bc139a7628681a3401402f7b", null ],
    [ "session_options", "classproton_1_1session__options.html#a2e138875d21432af920338badc26fefb", null ],
    [ "operator=", "classproton_1_1session__options.html#a019ce4a76f7ce2f63f001ed45018827e", null ],
    [ "handler", "classproton_1_1session__options.html#a059caf65a9417e22417006a8b166a54a", null ]
];