var reconnect__options_8hpp =
[
    [ "reconnect_options", "classproton_1_1reconnect__options.html", "classproton_1_1reconnect__options" ]
];