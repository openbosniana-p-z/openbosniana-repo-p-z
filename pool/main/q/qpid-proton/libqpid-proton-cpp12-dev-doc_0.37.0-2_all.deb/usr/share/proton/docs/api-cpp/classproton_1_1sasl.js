var classproton_1_1sasl =
[
    [ "outcome", "classproton_1_1sasl.html#af47997198e7e7301a1cd8602c7f02acd", [
      [ "NONE", "classproton_1_1sasl.html#af47997198e7e7301a1cd8602c7f02acdac157bdf0b85a40d2619cbc8bc1ae5fe2", null ],
      [ "OK", "classproton_1_1sasl.html#af47997198e7e7301a1cd8602c7f02acda2bc49ec37d6a5715dd23e85f1ff5bb59", null ],
      [ "AUTH", "classproton_1_1sasl.html#af47997198e7e7301a1cd8602c7f02acda8b22fbb60fcbd7a4a5e1e6ff6ee38218", null ],
      [ "SYS", "classproton_1_1sasl.html#af47997198e7e7301a1cd8602c7f02acda69a8d053cf3b5b28fa0c7dde6f883e10", null ],
      [ "PERM", "classproton_1_1sasl.html#af47997198e7e7301a1cd8602c7f02acdae0a57d717d9f8c8fdba757be1b0afdcf", null ],
      [ "TEMP", "classproton_1_1sasl.html#af47997198e7e7301a1cd8602c7f02acda5937389a60030a604f0efdf5e3927325", null ]
    ] ],
    [ "outcome", "classproton_1_1sasl.html#aee5a4997bbfa58f1b8176f936618de00", null ],
    [ "user", "classproton_1_1sasl.html#a9444df7d81bd265e0a8e1726fd12b058", null ],
    [ "mech", "classproton_1_1sasl.html#ae4d8c99395936130ece8495be232b9c2", null ]
];