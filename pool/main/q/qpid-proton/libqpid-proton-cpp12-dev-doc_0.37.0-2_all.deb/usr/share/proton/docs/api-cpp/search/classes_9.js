var searchData=
[
  ['receiver_0',['receiver',['../classproton_1_1receiver.html',1,'proton']]],
  ['receiver_5foptions_1',['receiver_options',['../classproton_1_1receiver__options.html',1,'proton']]],
  ['reconnect_5foptions_2',['reconnect_options',['../classproton_1_1reconnect__options.html',1,'proton']]],
  ['returned_3',['returned',['../classproton_1_1returned.html',1,'proton']]]
];
