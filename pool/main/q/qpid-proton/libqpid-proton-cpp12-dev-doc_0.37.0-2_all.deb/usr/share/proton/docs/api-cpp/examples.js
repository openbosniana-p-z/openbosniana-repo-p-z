var examples =
[
    [ "helloworld.cpp", "helloworld_8cpp-example.html", null ],
    [ "simple_send.cpp", "simple_send_8cpp-example.html", null ],
    [ "simple_recv.cpp", "simple_recv_8cpp-example.html", null ],
    [ "message_properties.cpp", "message_properties_8cpp-example.html", null ],
    [ "direct_send.cpp", "direct_send_8cpp-example.html", null ],
    [ "direct_recv.cpp", "direct_recv_8cpp-example.html", null ],
    [ "client.cpp", "client_8cpp-example.html", null ],
    [ "server.cpp", "server_8cpp-example.html", null ],
    [ "server_direct.cpp", "server_direct_8cpp-example.html", null ],
    [ "broker.cpp", "broker_8cpp-example.html", null ],
    [ "scheduled_send.cpp", "scheduled_send_8cpp-example.html", null ],
    [ "scheduled_send_03.cpp", "scheduled_send_03_8cpp-example.html", null ],
    [ "service_bus.cpp", "service_bus_8cpp-example.html", null ],
    [ "multithreaded_client.cpp", "multithreaded_client_8cpp-example.html", null ],
    [ "multithreaded_client_flow_control.cpp", "multithreaded_client_flow_control_8cpp-example.html", null ]
];