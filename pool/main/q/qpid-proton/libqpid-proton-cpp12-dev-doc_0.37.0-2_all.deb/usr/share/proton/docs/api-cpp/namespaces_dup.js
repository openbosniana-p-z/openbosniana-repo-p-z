var namespaces_dup =
[
    [ "proton", "namespaceproton.html", "namespaceproton" ]
];