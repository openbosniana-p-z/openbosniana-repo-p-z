var classproton_1_1session =
[
    [ "session", "classproton_1_1session.html#a912187b9bad05f8454864cc5eef14395", null ],
    [ "uninitialized", "classproton_1_1session.html#ab51c3843057c4c187574e2d44839f815", null ],
    [ "active", "classproton_1_1session.html#ad9735e23cb0888fb98e1c5893aecff7e", null ],
    [ "closed", "classproton_1_1session.html#ae54500202b0333927a28c440c85cf07e", null ],
    [ "error", "classproton_1_1session.html#a090a10fab22d7faf0f74c8ccda0f1470", null ],
    [ "open", "classproton_1_1session.html#a9e8555112049fc2b4945120b3c45f8ab", null ],
    [ "open", "classproton_1_1session.html#a7158346a6221ba5dad8c19464950f51b", null ],
    [ "close", "classproton_1_1session.html#a5ae591df94fc66ccb85cbb6565368bca", null ],
    [ "close", "classproton_1_1session.html#a817883d28ce0ac8a29d917d196796f68", null ],
    [ "container", "classproton_1_1session.html#abae81cfa576de73a4e356fa66f74a229", null ],
    [ "work_queue", "classproton_1_1session.html#a9cabc5284b3663af85c596e36669df15", null ],
    [ "connection", "classproton_1_1session.html#aff302bb6016f2ae29f01bb4e07389a52", null ],
    [ "open_sender", "classproton_1_1session.html#ae8eece4fd4b9e1a2531ca12d2ab57a32", null ],
    [ "open_sender", "classproton_1_1session.html#ab997a1233a3327d5ac1e63327fa62717", null ],
    [ "open_receiver", "classproton_1_1session.html#aad60d14592ee9d34caca4c61214ecd27", null ],
    [ "open_receiver", "classproton_1_1session.html#a1b4552a1ec08cdb5e76d7054dee6b538", null ],
    [ "incoming_bytes", "classproton_1_1session.html#afd0c41cf41edfc314d065e76e402fd1b", null ],
    [ "outgoing_bytes", "classproton_1_1session.html#af3f3aa5f4c2eafcab012920c3a29dae0", null ],
    [ "senders", "classproton_1_1session.html#a2e6d8395032b1d590a9e1586c7de0fb5", null ],
    [ "receivers", "classproton_1_1session.html#a634a0b14e10b9fc50cbb52251c2c8027", null ]
];