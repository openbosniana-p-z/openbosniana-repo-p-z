var classproton_1_1ssl =
[
    [ "verify_mode", "classproton_1_1ssl.html#abe68233596c90fd29d934854560ff5f3", [
      [ "VERIFY_PEER", "classproton_1_1ssl.html#abe68233596c90fd29d934854560ff5f3adb9333f2461b9f65dcb7346a8ceb185c", null ],
      [ "ANONYMOUS_PEER", "classproton_1_1ssl.html#abe68233596c90fd29d934854560ff5f3ac0c5cd6b794574267c2ad08f485bd76d", null ],
      [ "VERIFY_PEER_NAME", "classproton_1_1ssl.html#abe68233596c90fd29d934854560ff5f3a57807a2e5ed5e9858db1e84f24e91a0a", null ]
    ] ],
    [ "resume_status", "classproton_1_1ssl.html#a0d3f14f27a1e5af0a5f378fc1a8a8de4", [
      [ "UNKNOWN", "classproton_1_1ssl.html#a0d3f14f27a1e5af0a5f378fc1a8a8de4a6ce26a62afab55d7606ad4e92428b30c", null ],
      [ "NEW", "classproton_1_1ssl.html#a0d3f14f27a1e5af0a5f378fc1a8a8de4aec34b0b90541576a22697631105dc847", null ],
      [ "REUSED", "classproton_1_1ssl.html#a0d3f14f27a1e5af0a5f378fc1a8a8de4a6a8b4831d126ce349ac966f2f469413f", null ]
    ] ]
];