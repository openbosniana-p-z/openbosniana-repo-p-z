var annotation__key_8hpp =
[
    [ "annotation_key", "classproton_1_1annotation__key.html", "classproton_1_1annotation__key" ],
    [ "get< uint64_t >", "annotation__key_8hpp.html#afe991edadb78e18facab149551baf317", null ],
    [ "get< symbol >", "annotation__key_8hpp.html#a7bacee0d198b7e122d9f5f2ba2979898", null ],
    [ "coerce", "annotation__key_8hpp.html#ab73c44b530463fda5e11bc403ca9edd3", null ]
];