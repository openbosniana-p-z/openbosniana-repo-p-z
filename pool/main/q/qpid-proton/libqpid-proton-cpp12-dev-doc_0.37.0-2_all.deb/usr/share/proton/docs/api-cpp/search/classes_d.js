var searchData=
[
  ['value_0',['value',['../classproton_1_1value.html',1,'proton']]]
];
