var searchData=
[
  ['state_0',['state',['../classproton_1_1transfer.html#adc6e5733fc3c22f0a7b2914188c49c90',1,'proton::transfer']]]
];
