var classproton_1_1sender__options =
[
    [ "sender_options", "classproton_1_1sender__options.html#a619c789958ede03d0682a1a723cd7658", null ],
    [ "sender_options", "classproton_1_1sender__options.html#a258f4dd5231e0a3f048ec1f351c23cd4", null ],
    [ "operator=", "classproton_1_1sender__options.html#a83f174911b9ed9af7b86d0adb6cb0a6b", null ],
    [ "update", "classproton_1_1sender__options.html#a16b609dbb6a9df5ab7e719f0de05026b", null ],
    [ "handler", "classproton_1_1sender__options.html#ae5eb679658749726a703290bca9fecc3", null ],
    [ "delivery_mode", "classproton_1_1sender__options.html#aa737a95fac31df54863bff2b65fa4618", null ],
    [ "auto_settle", "classproton_1_1sender__options.html#afacc4451bbf925ed1619702ab13574fb", null ],
    [ "source", "classproton_1_1sender__options.html#a2d1c8f291320f51a2eb99323846d7cdc", null ],
    [ "target", "classproton_1_1sender__options.html#addb94d4642b622e243e0c2e4a2f88733", null ],
    [ "name", "classproton_1_1sender__options.html#a87f6e8a2724087349db89cc4f6d0bea6", null ],
    [ "properties", "classproton_1_1sender__options.html#a53464aada1ffe9843500caacefa7ddd3", null ]
];