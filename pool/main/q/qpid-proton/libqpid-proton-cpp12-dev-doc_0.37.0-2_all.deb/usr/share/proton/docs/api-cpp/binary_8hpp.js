var binary_8hpp =
[
    [ "binary", "classproton_1_1binary.html", "classproton_1_1binary" ],
    [ "operator<<", "binary_8hpp.html#a8e68eaf9c4d690ee78e894848103369c", null ]
];