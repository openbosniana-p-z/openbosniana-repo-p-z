#ifndef DEPRECATED_HEADER_QtSerialBus_qserialbusglobal_h
#define DEPRECATED_HEADER_QtSerialBus_qserialbusglobal_h
#if defined(__GNUC__)
#  warning Header <QtSerialBus/qserialbusglobal.h> is deprecated. Please include <QtSerialBus/qtserialbusglobal.h> instead.
#elif defined(_MSC_VER)
#  pragma message ("Header <QtSerialBus/qserialbusglobal.h> is deprecated. Please include <QtSerialBus/qtserialbusglobal.h> instead.")
#endif
#include <QtSerialBus/qtserialbusglobal.h>
#if 0
#pragma qt_no_master_include
#endif
#endif
