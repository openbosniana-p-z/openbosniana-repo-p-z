#define VERSION_MAJOR 0
#define VERSION_MINOR 11
#define VERSION_PATCH 2
#define VERSION_STRING "0.11.2"
#define LOCALE_DIRECTORY "/usr/share/locale/"
