var searchData=
[
  ['vcardupdatetype_2083',['VCardUpdateType',['../classQXmppPresence.html#a642a378dd425bbbda1de4317e2dcd199',1,'QXmppPresence']]]
];
