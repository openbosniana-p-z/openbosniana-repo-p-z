var searchData=
[
  ['q_5fdecl_5fenumerator_5fdeprecated_5fx_2163',['Q_DECL_ENUMERATOR_DEPRECATED_X',['../classQXmppStanza_1_1Error.html#abcf1cbbe7b15ec82f3ac34723b604852afe6f471a56ed0a0c6116608a393adb36',1,'QXmppStanza::Error']]]
];
