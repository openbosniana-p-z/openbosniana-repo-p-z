var searchData=
[
  ['badrequest_2092',['BadRequest',['../classQXmppStanza_1_1Error.html#abcf1cbbe7b15ec82f3ac34723b604852a807de0a00f8e309ef657db266cc00fe2',1,'QXmppStanza::Error']]],
  ['both_2093',['Both',['../classQXmppRosterIq_1_1Item.html#a0133cf9262cec7e299c4db7c247c5514ad7dc2c24e3f207106bad568b6d705df7',1,'QXmppRosterIq::Item']]]
];
