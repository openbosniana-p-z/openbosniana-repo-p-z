var searchData=
[
  ['identity_1088',['Identity',['../classQXmppDiscoveryIq_1_1Identity.html',1,'QXmppDiscoveryIq']]],
  ['item_1089',['Item',['../classQXmppDiscoveryIq_1_1Item.html',1,'QXmppDiscoveryIq::Item'],['../classQXmppRosterIq_1_1Item.html',1,'QXmppRosterIq::Item']]]
];
