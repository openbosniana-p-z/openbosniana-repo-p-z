var searchData=
[
  ['command_2062',['Command',['../classQXmppDialback.html#a0448107c56f892056f359013b80798bc',1,'QXmppDialback']]],
  ['condition_2063',['Condition',['../classQXmppStanza_1_1Error.html#abcf1cbbe7b15ec82f3ac34723b604852',1,'QXmppStanza::Error']]]
];
