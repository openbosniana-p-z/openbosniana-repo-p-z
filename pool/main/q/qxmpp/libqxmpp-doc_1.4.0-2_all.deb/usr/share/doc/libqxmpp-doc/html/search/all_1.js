var searchData=
[
  ['badrequest_52',['BadRequest',['../classQXmppStanza_1_1Error.html#abcf1cbbe7b15ec82f3ac34723b604852a807de0a00f8e309ef657db266cc00fe2',1,'QXmppStanza::Error']]],
  ['ban_53',['ban',['../classQXmppMucRoom.html#a1c4be76e72f4b3d91752e653e722ed7c',1,'QXmppMucRoom']]],
  ['barejid_54',['bareJid',['../classQXmppRosterIq_1_1Item.html#a2ff743a525a7afc9b23bf77e8a71e0a8',1,'QXmppRosterIq::Item']]],
  ['before_55',['before',['../classQXmppResultSetQuery.html#af09601eaa027009c3839f3bbeef1e979',1,'QXmppResultSetQuery']]],
  ['bind_56',['bind',['../classQXmppIceConnection.html#a21afce5d6bab75567edb2765fb2dce11',1,'QXmppIceConnection']]],
  ['birthday_57',['birthday',['../classQXmppVCardIq.html#a1aa3513fbaaf9945346a045bad940481',1,'QXmppVCardIq']]],
  ['bitsofbinarydata_58',['bitsOfBinaryData',['../classQXmppMessage.html#acb124fada1580c8be2b0a51f1b4196e4',1,'QXmppMessage::bitsOfBinaryData() const'],['../classQXmppMessage.html#a38c0fa3e01e23d00841310c56a240297',1,'QXmppMessage::bitsOfBinaryData()'],['../classQXmppRegisterIq.html#a703f31515f698a19b8765c80f57e7912',1,'QXmppRegisterIq::bitsOfBinaryData() const'],['../classQXmppRegisterIq.html#a6edc4541d2f9618ecddb62a5bbdde5da',1,'QXmppRegisterIq::bitsOfBinaryData()']]],
  ['body_59',['body',['../classQXmppArchiveMessage.html#a8dc9733bc230b83faddf8feb1ddd678c',1,'QXmppArchiveMessage::body()'],['../classQXmppMessage.html#a03ca378952b2324319afc379a66df5fb',1,'QXmppMessage::body()']]],
  ['bookmarks_60',['bookmarks',['../classQXmppBookmarkManager.html#a3a3d6a698e3826cb197b30020303d531',1,'QXmppBookmarkManager']]],
  ['bookmarksreceived_61',['bookmarksReceived',['../classQXmppBookmarkManager.html#a6b4c3ebab3bc03e313dc3b5392394a6c',1,'QXmppBookmarkManager']]],
  ['both_62',['Both',['../classQXmppRosterIq_1_1Item.html#a0133cf9262cec7e299c4db7c247c5514ad7dc2c24e3f207106bad568b6d705df7',1,'QXmppRosterIq::Item']]],
  ['by_63',['by',['../classQXmppStanza_1_1Error.html#ab760c0d46bbd60c7492f7c48148f9996',1,'QXmppStanza::Error']]]
];
