var searchData=
[
  ['action_2059',['Action',['../classQXmppJingleIq.html#accfb8d2dec7f9ee9a8de7bff4f1de1ec',1,'QXmppJingleIq::Action()'],['../classQXmppMucRoom.html#acd3129293f69d7e7cdd91b65aae0606f',1,'QXmppMucRoom::Action()']]],
  ['affiliation_2060',['Affiliation',['../classQXmppMucItem.html#a3a0d58827ab4d535326fc6d3dbcbd417',1,'QXmppMucItem']]],
  ['availablestatustype_2061',['AvailableStatusType',['../classQXmppPresence.html#ad56af0f57b732c09b080b9347c4dba94',1,'QXmppPresence']]]
];
