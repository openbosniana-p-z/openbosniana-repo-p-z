var searchData=
[
  ['xa_1057',['XA',['../classQXmppPresence.html#ad56af0f57b732c09b080b9347c4dba94af2b440870b33ce88182aaf32f871696b',1,'QXmppPresence']]],
  ['xhtml_1058',['xhtml',['../classQXmppMessage.html#a34240e4de8fbf14fc3f1e626a5cedb25',1,'QXmppMessage']]],
  ['xmpp_20extensions_1059',['XMPP Extensions',['../xep.html',1,'']]],
  ['xmppstreamerror_1060',['XmppStreamError',['../classQXmppClient.html#a7c2851d07cc33119752abc6ec8ffc47aa29f30662c97dc09858f1d7e80eb1825a',1,'QXmppClient']]],
  ['xmppstreamerror_1061',['xmppStreamError',['../classQXmppClient.html#af3a18178f3349e668f09ee46ba7d48db',1,'QXmppClient::xmppStreamError()'],['../classQXmppOutgoingClient.html#acd53efcf1903123bdf9a1294c1423428',1,'QXmppOutgoingClient::xmppStreamError()']]]
];
