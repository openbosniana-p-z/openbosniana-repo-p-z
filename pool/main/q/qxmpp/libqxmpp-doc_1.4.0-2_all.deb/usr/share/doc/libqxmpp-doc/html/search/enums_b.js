var searchData=
[
  ['state_2077',['State',['../classQXmppMessage.html#aeaa3cc5ccb7d451067a80dd1f3c7099a',1,'QXmppMessage::State()'],['../classQXmppCall.html#a90205b5034613127d2c4adc6a0252759',1,'QXmppCall::State()'],['../classQXmppClient.html#a5f4e70d508c08967f72fd41c5343ad2e',1,'QXmppClient::State()'],['../classQXmppTransferJob.html#aab5bb06ca0d2c4f1fac33b7012d1c14f',1,'QXmppTransferJob::State()']]],
  ['streammanagementstate_2078',['StreamManagementState',['../classQXmppClient.html#aab5506ec0769f208e1ccd5d23c6aaea8',1,'QXmppClient']]],
  ['streamsecuritymode_2079',['StreamSecurityMode',['../classQXmppConfiguration.html#a7c6e193a68beb792038c066cfc574a18',1,'QXmppConfiguration']]],
  ['subscriptiontype_2080',['SubscriptionType',['../classQXmppRosterIq_1_1Item.html#a0133cf9262cec7e299c4db7c247c5514',1,'QXmppRosterIq::Item']]]
];
