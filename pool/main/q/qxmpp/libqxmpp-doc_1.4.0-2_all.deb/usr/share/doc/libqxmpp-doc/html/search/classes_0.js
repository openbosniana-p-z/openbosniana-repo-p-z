var searchData=
[
  ['error_1086',['Error',['../classQXmppStanza_1_1Error.html',1,'QXmppStanza']]]
];
