var searchData=
[
  ['unavailable_1015',['Unavailable',['../classQXmppPresence.html#a47ab8dd08436f9d7c90d2990678b5a6da6188ca67163c9045eb9568deefb9a363',1,'QXmppPresence']]],
  ['undefinedcondition_1016',['UndefinedCondition',['../classQXmppStanza_1_1Error.html#abcf1cbbe7b15ec82f3ac34723b604852a33a57062632042f76793d3c07741d10a',1,'QXmppStanza::Error']]],
  ['unexpectedrequest_1017',['UnexpectedRequest',['../classQXmppStanza_1_1Error.html#abcf1cbbe7b15ec82f3ac34723b604852ac71c1b7927a3f0bbc889807c343c45ab',1,'QXmppStanza::Error']]],
  ['unit_1018',['unit',['../classQXmppVCardOrganization.html#a321f3182bca5a4fdf8f65554275aa6b5',1,'QXmppVCardOrganization']]],
  ['unknownencryption_1019',['UnknownEncryption',['../classQXmppMessage.html#a1526e753b5cfe7ed7787d035b72c3742a3d891bce95ec28f88345014011abbc5a',1,'QXmppMessage']]],
  ['unsubscribe_1020',['unsubscribe',['../classQXmppRosterManager.html#afd840ecd9179624db72c837ff948abf5',1,'QXmppRosterManager']]],
  ['unsubscribe_1021',['Unsubscribe',['../classQXmppPresence.html#a47ab8dd08436f9d7c90d2990678b5a6da20986f18e387f68a5fdfa0e67c44bc44',1,'QXmppPresence']]],
  ['unsubscribed_1022',['Unsubscribed',['../classQXmppPresence.html#a47ab8dd08436f9d7c90d2990678b5a6da63414092d2fc4b90987f56731c150623',1,'QXmppPresence']]],
  ['updatecounter_1023',['updateCounter',['../classQXmppLogger.html#a9dfaa287ed3dc1b37e9f0824f279bc9c',1,'QXmppLogger::updateCounter()'],['../classQXmppLoggable.html#aa309eaea9699e7fe652a400cef346ae2',1,'QXmppLoggable::updateCounter()']]],
  ['uploadservices_1024',['uploadServices',['../classQXmppUploadRequestManager.html#a66360385ff63f8bd46c4a5ffd879a1f3',1,'QXmppUploadRequestManager']]],
  ['uri_1025',['uri',['../classQXmppDataForm_1_1MediaSource.html#ae6ce04e06d1879fc705627df24844223',1,'QXmppDataForm::MediaSource']]],
  ['uris_1026',['uris',['../classQXmppDataForm_1_1Media.html#a7140140ee091c1b386b205cfe1bfa75f',1,'QXmppDataForm::Media']]],
  ['url_1027',['url',['../classQXmppBookmarkUrl.html#adbfb202539225d57839b566acc79ebe2',1,'QXmppBookmarkUrl::url()'],['../classQXmppVCardIq.html#a86115fa4f4dd703e3d5f12a14b01935b',1,'QXmppVCardIq::url()']]],
  ['urls_1028',['urls',['../classQXmppBookmarkSet.html#ab56aef5b2e13abd597374f8eb91e27df',1,'QXmppBookmarkSet']]],
  ['usenonsaslauthentication_1029',['useNonSASLAuthentication',['../classQXmppConfiguration.html#a9fba501e792288605ff7189ede887534',1,'QXmppConfiguration']]],
  ['user_1030',['user',['../classQXmppConfiguration.html#a66bde580f9525a5da6e133197b490d3c',1,'QXmppConfiguration']]],
  ['username_1031',['username',['../classQXmppRegisterIq.html#a10d44cb4316a1b49d1dc9e5c570972d1',1,'QXmppRegisterIq::username()'],['../classQXmppPasswordRequest.html#a7224887f9c13971c96b8e6ae73fd0a24',1,'QXmppPasswordRequest::username()']]],
  ['usesaslauthentication_1032',['useSASLAuthentication',['../classQXmppConfiguration.html#a1f5cc8a3019cfed63e85ac7087a53603',1,'QXmppConfiguration']]],
  ['using_20qxmpp_1033',['Using QXmpp',['../using.html',1,'']]],
  ['utc_1034',['utc',['../classQXmppEntityTimeIq.html#a6a2c7da5bd7663523ab6cb080669b74f',1,'QXmppEntityTimeIq']]]
];
