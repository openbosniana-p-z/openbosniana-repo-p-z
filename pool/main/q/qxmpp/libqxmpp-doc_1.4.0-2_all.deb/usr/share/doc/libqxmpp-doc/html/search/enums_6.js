var searchData=
[
  ['loggingtype_2069',['LoggingType',['../classQXmppLogger.html#a9a52fe426322ef8e10e05b7092be6c20',1,'QXmppLogger']]]
];
