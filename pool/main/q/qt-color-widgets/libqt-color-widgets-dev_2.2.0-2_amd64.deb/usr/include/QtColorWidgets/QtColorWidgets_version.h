#ifndef QtColorWidgets_VERSION_H
#define QtColorWidgets_VERSION_H


#include "QtColorWidgets/colorwidgets_global.hpp"


QCP_EXPORT unsigned int QtColorWidgets_versionMajor ();


QCP_EXPORT unsigned int QtColorWidgets_versionMinor ();


QCP_EXPORT unsigned int QtColorWidgets_versionPatch ();


QCP_EXPORT const char* QtColorWidgets_versionGitInfo ();


QCP_EXPORT const char* QtColorWidgets_versionFullString ();


#endif /* QtColorWidgets_VERSION_H */
