# quoin

This is a utility library useful in implemented template engines. I've
written a few of those, so this consolidates some useful functions
into one place to help improvements to one translate to the others. I
will be adding to this over time, I expect. I can't imagine this is of
general interest, but if you see something useful, go for it.

## Usage

Put the following in your project.clj:

```clojure
[quoin "0.1.2"]
```

## License

Copyright © 2012 David Santiago

Distributed under the Eclipse Public License, the same as Clojure.
