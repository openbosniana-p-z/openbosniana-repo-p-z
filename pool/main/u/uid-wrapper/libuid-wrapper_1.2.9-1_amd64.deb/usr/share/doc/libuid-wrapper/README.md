UID_WRAPPER
===========

This is a testing tool to fake privilege separition without being root.

DESCRIPTION
-----------

More details can be found in the manpage:

    man -l ./doc/uid_wrapper.1

or the raw text version:

    less ./doc/uid_wrapper.1.txt

For installation instructions please take a look at the README.install file.

MAILINGLIST
-----------

As the mailing list samba-technical is used and can be found here:

https://lists.samba.org/mailman/listinfo/samba-technical
