#ifndef UI_UTILCPP_VERSION_H
#define UI_UTILCPP_VERSION_H

/** @{ @brief ui-auto'mated version macros. */
#define UI_UTILCPP_VERSION "1.10.2"
#define UI_UTILCPP_VERSION_MAJOR 1
#define UI_UTILCPP_VERSION_MINOR 10
#define UI_UTILCPP_VERSION_PATCH 2
/** @} */
/** @{ @brief ui-auto'mated library version support. */
#define UI_UTILCPP_LIBVERSION "9.0.3"
#define UI_UTILCPP_LIBVERSION_MAJOR 9
#define UI_UTILCPP_LIBVERSION_MINOR 0
#define UI_UTILCPP_LIBVERSION_PATCH 3
/** @} */
#endif
