NAME='libtcc'
CFLAGS=[]
LDFLAGS=[]
LIBS=['-ltcc']
GCC_LIST=['libtcc']
