NAME='symcall'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['symcall_plugin']
