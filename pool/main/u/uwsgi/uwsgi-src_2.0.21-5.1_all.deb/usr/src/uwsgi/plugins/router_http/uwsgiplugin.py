NAME='router_http'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['router_http']
