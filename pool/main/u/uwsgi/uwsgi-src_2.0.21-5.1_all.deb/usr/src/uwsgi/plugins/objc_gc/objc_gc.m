#include <uwsgi.h>

struct uwsgi_plugin objc_gc_plugin = {
	.name = "objc_gc",
};
