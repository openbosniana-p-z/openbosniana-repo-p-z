
NAME='dummy'
CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['dummy']
