var searchData=
[
  ['connection_5finfo_5fstruct_0',['connection_info_struct',['../structconnection__info__struct.html',1,'']]]
];
