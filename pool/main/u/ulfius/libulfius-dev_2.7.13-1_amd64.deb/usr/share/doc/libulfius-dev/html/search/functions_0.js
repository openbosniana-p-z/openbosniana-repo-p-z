var searchData=
[
  ['mhd_5fredirect_5flog_0',['mhd_redirect_log',['../ulfius_8c.html#a12c6af33744e0ade9cbd2b34dd9c7345',1,'ulfius.c']]],
  ['mhd_5frequest_5fcompleted_1',['mhd_request_completed',['../group__instance.html#ga1ce1edeee56821ab3dfbe817e9dd2eda',1,'mhd_request_completed(void *cls, struct MHD_Connection *connection, void **con_cls, enum MHD_RequestTerminationCode toe):&#160;ulfius.c'],['../group__instance.html#ga1ce1edeee56821ab3dfbe817e9dd2eda',1,'mhd_request_completed(void *cls, struct MHD_Connection *connection, void **con_cls, enum MHD_RequestTerminationCode toe):&#160;ulfius.c']]]
];
