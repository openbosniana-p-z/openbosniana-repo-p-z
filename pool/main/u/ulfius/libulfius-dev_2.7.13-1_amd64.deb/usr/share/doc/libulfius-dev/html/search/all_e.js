var searchData=
[
  ['query_0',['query',['../structyuarel.html#a494ba51861c5f8c67adae9bba4c5c892',1,'yuarel']]]
];
