var searchData=
[
  ['websocket_5fhandle_0',['websocket_handle',['../struct__u__response.html#a51ddc9bddf73a26b43c414e8be47194d',1,'_u_response']]],
  ['websocket_5fhandler_1',['websocket_handler',['../struct__u__instance.html#ad018dc3a7cbee528cc67612f4a8451ae',1,'_u_instance']]]
];
