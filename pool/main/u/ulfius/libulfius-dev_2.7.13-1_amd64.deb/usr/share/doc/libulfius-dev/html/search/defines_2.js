var searchData=
[
  ['pollrdhup_0',['POLLRDHUP',['../ulfius_8h.html#acc058eb75fbe9bf75064cd675ad96d21',1,'ulfius.h']]]
];
