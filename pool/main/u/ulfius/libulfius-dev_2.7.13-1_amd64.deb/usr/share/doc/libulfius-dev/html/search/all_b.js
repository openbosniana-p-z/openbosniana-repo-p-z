var searchData=
[
  ['nb_5fcookies_0',['nb_cookies',['../struct__u__response.html#a7220facebbadbaa05d7ea4834c41aaed',1,'_u_response']]],
  ['nb_5fendpoints_1',['nb_endpoints',['../struct__u__instance.html#a985f6cb0a0aababca6d42bc5ed47403a',1,'_u_instance']]],
  ['nb_5fvalues_2',['nb_values',['../struct__u__map.html#a9b0df968cd1ee60f8dde2bc67b297536',1,'_u_map']]]
];
