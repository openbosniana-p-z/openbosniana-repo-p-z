var searchData=
[
  ['binary_5fbody_0',['binary_body',['../struct__u__request.html#a3475938cb332310fef95276c344c2ada',1,'_u_request::binary_body()'],['../struct__u__response.html#adfa9627eeb9a764eb8db6c473952625e',1,'_u_response::binary_body()']]],
  ['binary_5fbody_5flength_1',['binary_body_length',['../struct__u__request.html#a434b1e4238cbe6c1e76913dc3656e86c',1,'_u_request::binary_body_length()'],['../struct__u__response.html#a5dca74f1ac5add8cdc4770805d07b278',1,'_u_response::binary_body_length()']]],
  ['bind_5faddress_2',['bind_address',['../struct__u__instance.html#a6d9c92a91d589d7e01a1175b0ad510a2',1,'_u_instance']]],
  ['bind_5faddress6_3',['bind_address6',['../struct__u__instance.html#a8bd70f0b2d7a66cba3c379268e46f2bb',1,'_u_instance']]]
];
