var searchData=
[
  ['endpoint_5flist_0',['endpoint_list',['../struct__u__instance.html#a9753b7a56bd0633ed673a03afbd9bbce',1,'_u_instance']]],
  ['expires_1',['expires',['../struct__u__cookie.html#a88ce6125c5c18d4b5c35827997544d8d',1,'_u_cookie']]]
];
