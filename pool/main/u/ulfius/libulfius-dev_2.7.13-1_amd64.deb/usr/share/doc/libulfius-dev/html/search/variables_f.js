var searchData=
[
  ['same_5fsite_0',['same_site',['../struct__u__cookie.html#abc07323de398f3344c754788bce03975',1,'_u_cookie']]],
  ['scheme_1',['scheme',['../structyuarel.html#acae4e81e9d2fd36cdc95dc36c118708f',1,'yuarel']]],
  ['secure_2',['secure',['../struct__u__cookie.html#ab59e796c328a5b00ead21f093cb5113b',1,'_u_cookie']]],
  ['shared_5fdata_3',['shared_data',['../struct__u__response.html#af8da57093cc1478ff2e92834b7cdd608',1,'_u_response']]],
  ['size_4',['size',['../struct__u__body.html#a40ea911b5c3c6e5be4a340928e870ff6',1,'_u_body']]],
  ['status_5',['status',['../struct__u__response.html#a70d5fda4a8043f3ac6d2c30ffa106a38',1,'_u_response::status()'],['../struct__u__instance.html#a233a51ae1b61b62a693770484740e469',1,'_u_instance::status()']]],
  ['stream_5fblock_5fsize_6',['stream_block_size',['../struct__u__response.html#a054fddb0753c0ffecbe8c74eb02de118',1,'_u_response']]],
  ['stream_5fcallback_7',['stream_callback',['../struct__u__response.html#a470c3c4b25c0f773e3c879f1ad48f131',1,'_u_response']]],
  ['stream_5fcallback_5ffree_8',['stream_callback_free',['../struct__u__response.html#ad7267d722f32b17e00e20b2c46a2f2db',1,'_u_response']]],
  ['stream_5fsize_9',['stream_size',['../struct__u__response.html#a566b92ee95d13acb81770e7d2aea158c',1,'_u_response']]],
  ['stream_5fuser_5fdata_10',['stream_user_data',['../struct__u__response.html#a127aa6de650737fe956ca2689401931f',1,'_u_response']]]
];
