Markdown patterns
=================

- `code` matches inline code
- `codeblocks` matches code blocks
- `images` matches markdown and HTML images
- `links` matches markdown and HTML hyperlinks
- `sections` matches markdown sections
