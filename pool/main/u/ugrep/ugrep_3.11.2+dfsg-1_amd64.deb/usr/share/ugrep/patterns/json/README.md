JSON patterns
=============

- `keys` matches object keys
- `keys_and_values` matches key-value pairs (simple values)
- `values` matches values (simple values, not objects and arrays)
