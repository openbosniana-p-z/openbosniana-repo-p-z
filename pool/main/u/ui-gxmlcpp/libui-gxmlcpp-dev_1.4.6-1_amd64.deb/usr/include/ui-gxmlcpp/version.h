#ifndef UI_GXMLCPP_VERSION_H
#define UI_GXMLCPP_VERSION_H

/** @{ @brief ui-auto'mated version macros. */
#define UI_GXMLCPP_VERSION "1.4.6"
#define UI_GXMLCPP_VERSION_MAJOR 1
#define UI_GXMLCPP_VERSION_MINOR 4
#define UI_GXMLCPP_VERSION_PATCH 6
/** @} */
/** @{ @brief ui-auto'mated library version support. */
#define UI_GXMLCPP_LIBVERSION "5.0.2"
#define UI_GXMLCPP_LIBVERSION_MAJOR 5
#define UI_GXMLCPP_LIBVERSION_MINOR 0
#define UI_GXMLCPP_LIBVERSION_PATCH 2
/** @} */
#endif
