# README.LDAP for UIF 1.99.0

## Documentation / LDAP

There is some LDAP support built into UIF, with that you can handle a big
farm of diskles router configurations. Use uif(8) and information
provided in the doc/ directory to configure the firewall fitting your
needs.

## Call for help

The LDAP support in UIF hasn't been tested for quite a while. Most users
of UIF have use cases with local configuration files. If you feel like
contributing, please dive into the LDAP functionality of UIF and test it,
report bugs, give feedback, etc.
