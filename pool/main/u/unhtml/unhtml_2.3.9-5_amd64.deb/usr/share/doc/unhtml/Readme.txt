
========================  
Unhtml - Document Parser
========================  

Kevin Swan, 013639s@dragon.acadiau.ca
Version 2.3
Last revised: February 21, 1999

DESCRIPTION

unhtml is a program developed by me in April of 1996 to remove the
HTML formatting from documents and print the output to the standard output
stream.  It treated any occurrences of a greater than or less than sign as 
HTML tags and removes them.  In this version, it is more intelligent in the
sense that it recognizes &lt;SCRIPT&gt; blocks.

Please report any bugs you find or comments you have to
013639s@dragon.acadiau.ca

DISTRIBUTION

This software is freely distributable under the GNU Public License,
and may be altered in any way.  The only condition for redistribution is
that this README file be included with the revised/redistributed software,
with the only modifications being additions describing what's been changed.

The software's original author Kevin Swan <013639s@dragon.acadiau.ca> is
agreeing to negotiate different licensing terms with interested parties for
commercial reuse of the source code.

INSTALLATION

You can compile and install unhtml by doing the following as root:


         make && make install

Kevin Swan
