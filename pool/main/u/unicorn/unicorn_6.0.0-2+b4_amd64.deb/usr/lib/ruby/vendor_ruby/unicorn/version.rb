Unicorn::Const::UNICORN_VERSION = '6.0.0'
