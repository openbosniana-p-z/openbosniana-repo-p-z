Read structure (Klein et al)

    Read 1
    [Barcode 1 (10bp)][W1 (22bp)][Barcode 2 (8bp)][UMI (6bp)][TTT..]
    
    Read 2
    [Tag]
    
