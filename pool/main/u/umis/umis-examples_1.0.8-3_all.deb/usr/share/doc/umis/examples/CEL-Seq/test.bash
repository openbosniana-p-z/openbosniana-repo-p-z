python umicount.py fastqtrim \
--fastq1 examples/CEL-Seq/SRP036633_1.fastq \
--fastq2 examples/CEL-Seq/SRP036633_2.fastq \
--cbs 1 --cbe 8 --mbs 9 --mbe 12 \
--outfastq examples/CEL-Seq/SRP036633_trimmed.fastq
