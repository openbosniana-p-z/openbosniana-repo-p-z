Gallery of Examples of UMAP usage
---------------------------------

A small gallery collection examples of UMAP usage. Do you
have an interesting UMAP plot that uses publicly available
data? Submit a pull request to have it added as an example!