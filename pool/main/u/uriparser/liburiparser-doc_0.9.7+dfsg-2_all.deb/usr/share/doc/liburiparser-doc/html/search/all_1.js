var searchData=
[
  ['calloc_0',['calloc',['../structUriMemoryManagerStruct.html#afe3fdb86a91a00161057d150ea4665be',1,'UriMemoryManagerStruct']]]
];
