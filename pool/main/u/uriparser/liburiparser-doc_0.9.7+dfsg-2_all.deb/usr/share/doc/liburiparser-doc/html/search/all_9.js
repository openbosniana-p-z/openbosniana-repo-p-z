var searchData=
[
  ['next_0',['next',['../structUriPathSegmentStructA.html#a1a8ec2ed379ddb3c00e2d3b4d4eb79d4',1,'UriPathSegmentStructA::next()'],['../structUriQueryListStructA.html#a4430f1710b973a37317c849a2f0fc34f',1,'UriQueryListStructA::next()']]]
];
