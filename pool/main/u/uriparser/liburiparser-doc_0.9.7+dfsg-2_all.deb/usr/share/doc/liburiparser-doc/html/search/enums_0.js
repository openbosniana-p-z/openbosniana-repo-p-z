var searchData=
[
  ['uribreakconversionenum_0',['UriBreakConversionEnum',['../UriBase_8h.html#a411334aa7c810d330d05a50504a7cfcc',1,'UriBase.h']]],
  ['urinormalizationmaskenum_1',['UriNormalizationMaskEnum',['../UriBase_8h.html#ac0a876ae3fbf22bdfa8d3e4a24838400',1,'UriBase.h']]],
  ['uriresolutionoptionsenum_2',['UriResolutionOptionsEnum',['../UriBase_8h.html#a1cdbeee44519b34292fab4b7d9213df1',1,'UriBase.h']]]
];
