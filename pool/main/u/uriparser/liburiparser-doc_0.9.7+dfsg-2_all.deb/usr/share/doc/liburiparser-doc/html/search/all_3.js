var searchData=
[
  ['errorcode_0',['errorCode',['../structUriParserStateStructA.html#ab675a39a0c7f0587be9ae6734db7ac80',1,'UriParserStateStructA']]],
  ['errorpos_1',['errorPos',['../structUriParserStateStructA.html#aab55b8297cb48d34191932aff8ecf3ea',1,'UriParserStateStructA']]]
];
