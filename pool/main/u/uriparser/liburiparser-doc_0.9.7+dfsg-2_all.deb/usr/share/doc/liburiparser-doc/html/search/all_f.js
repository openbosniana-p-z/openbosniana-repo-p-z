var searchData=
[
  ['text_0',['text',['../structUriPathSegmentStructA.html#aea38e516840f13cfaa7b837e3ffb26d1',1,'UriPathSegmentStructA']]]
];
