var searchData=
[
  ['hostdata_0',['hostData',['../structUriUriStructA.html#a2d713adf6bcf52d41ad10b62df4d1353',1,'UriUriStructA']]],
  ['hosttext_1',['hostText',['../structUriUriStructA.html#a8785f975abe90491a1d2a7d10e591d74',1,'UriUriStructA']]]
];
