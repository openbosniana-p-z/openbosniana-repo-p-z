var searchData=
[
  ['owner_0',['owner',['../structUriUriStructA.html#afed82ea0451d1ca77da02168448df58a',1,'UriUriStructA']]]
];
