var searchData=
[
  ['data_0',['data',['../structUriIp4Struct.html#a1313fbf2e999ad021f220cbf61ec9688',1,'UriIp4Struct::data()'],['../structUriIp6Struct.html#a512181404219812104863ccac1feead3',1,'UriIp6Struct::data()']]],
  ['deprecated_20list_1',['Deprecated List',['../deprecated.html',1,'']]]
];
