var searchData=
[
  ['ip4_0',['ip4',['../structUriHostDataStructA.html#aac377109041d3d29e1f2b84483585cf6',1,'UriHostDataStructA']]],
  ['ip6_1',['ip6',['../structUriHostDataStructA.html#a606a6f6210f510a3c58864bfe4a9e735',1,'UriHostDataStructA']]],
  ['ipfuture_2',['ipFuture',['../structUriHostDataStructA.html#a445e6e9aa40135e8fb0354b82bea5644',1,'UriHostDataStructA']]]
];
