var searchData=
[
  ['scheme_0',['scheme',['../structUriUriStructA.html#a1a6af822570e52c9617755a351bb8729',1,'UriUriStructA']]]
];
