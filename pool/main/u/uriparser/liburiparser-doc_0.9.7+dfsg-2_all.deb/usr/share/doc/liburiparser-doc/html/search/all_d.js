var searchData=
[
  ['realloc_0',['realloc',['../structUriMemoryManagerStruct.html#a607a90ccb4b4c279b72b4cc86d43b4ed',1,'UriMemoryManagerStruct']]],
  ['reallocarray_1',['reallocarray',['../structUriMemoryManagerStruct.html#adcfd5fd83b0455d4862472e272bfbf5d',1,'UriMemoryManagerStruct']]],
  ['reserved_2',['reserved',['../structUriPathSegmentStructA.html#a4544f2a75ed89c0744fd045d631cf3d9',1,'UriPathSegmentStructA::reserved()'],['../structUriUriStructA.html#a4544f2a75ed89c0744fd045d631cf3d9',1,'UriUriStructA::reserved()'],['../structUriParserStateStructA.html#a4544f2a75ed89c0744fd045d631cf3d9',1,'UriParserStateStructA::reserved()']]]
];
