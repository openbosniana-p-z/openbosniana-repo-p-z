var searchData=
[
  ['uri_0',['uri',['../structUriParserStateStructA.html#a9a0cd66f9e53ac5d0ac2b2b8b1dd01d4',1,'UriParserStateStructA']]],
  ['userdata_1',['userData',['../structUriMemoryManagerStruct.html#a2e294dd14122c554baa0665072b4ca7a',1,'UriMemoryManagerStruct']]],
  ['userinfo_2',['userInfo',['../structUriUriStructA.html#a0d1687417e9078c3627f04a751fc531e',1,'UriUriStructA']]]
];
