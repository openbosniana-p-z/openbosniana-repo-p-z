var searchData=
[
  ['query_0',['query',['../structUriUriStructA.html#acb555eb399898672c7b069da0f444157',1,'UriUriStructA']]]
];
