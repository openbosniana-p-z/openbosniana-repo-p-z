var searchData=
[
  ['pathhead_0',['pathHead',['../structUriUriStructA.html#a818fe29f52f4b50264df4e259b85ed54',1,'UriUriStructA']]],
  ['pathtail_1',['pathTail',['../structUriUriStructA.html#a7ffeb05ecfcebe37387835679556a64d',1,'UriUriStructA']]],
  ['porttext_2',['portText',['../structUriUriStructA.html#adb6e1372050754b12e3a47602c84231f',1,'UriUriStructA']]]
];
