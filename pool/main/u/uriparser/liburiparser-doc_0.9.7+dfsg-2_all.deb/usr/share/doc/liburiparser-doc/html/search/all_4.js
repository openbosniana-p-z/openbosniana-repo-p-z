var searchData=
[
  ['first_0',['first',['../structUriTextRangeStructA.html#a6f1e1048b5e74fe6c7a680ff99138f68',1,'UriTextRangeStructA']]],
  ['fragment_1',['fragment',['../structUriUriStructA.html#aea2941812309aabad8025e582e9cc5c4',1,'UriUriStructA']]],
  ['free_2',['free',['../structUriMemoryManagerStruct.html#a4136addad3036e787852fead862cffdf',1,'UriMemoryManagerStruct']]]
];
