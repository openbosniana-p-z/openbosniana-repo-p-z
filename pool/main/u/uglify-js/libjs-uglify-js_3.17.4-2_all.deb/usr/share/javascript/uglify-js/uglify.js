// @license magnet:?xt=urn:btih:87f119ba0b429ba17a44b4bffcab33165ebdacc0&dn=freebsd.txt BSD-2-Clause
(function(b) {
    /***********************************************************************

  A JavaScript tokenizer / parser / beautifier / compressor.
  https://github.com/mishoo/UglifyJS

  -------------------------------- (C) ---------------------------------

                           Author: Mihai Bazon
                         <mihai.bazon@gmail.com>
                       http://mihai.bazon.net/blog

  Distributed under the BSD license:

    Copyright 2012 (c) Mihai Bazon <mihai.bazon@gmail.com>

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

        * Redistributions of source code must retain the above
          copyright notice, this list of conditions and the following
          disclaimer.

        * Redistributions in binary form must reproduce the above
          copyright notice, this list of conditions and the following
          disclaimer in the documentation and/or other materials
          provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER “AS IS” AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE
    LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
    OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
    TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
    THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
    SUCH DAMAGE.

 ***********************************************************************/
    "use strict";
    function n(e) {
        return e.split("");
    }
    function Jn(e, n) {
        return n.indexOf(e) >= 0;
    }
    function Xn(e, n) {
        for (var t = n.length; --t >= 0; ) if (e(n[t])) return n[t];
    }
    function t(e) {
        Object.defineProperty(e.prototype, "stack", {
            get: function() {
                var e = new Error(this.message);
                e.name = this.name;
                try {
                    throw e;
                } catch (e) {
                    return e.stack;
                }
            }
        });
    }
    function i(e, n) {
        this.message = e;
        this.defs = n;
    }
    i.prototype = Object.create(Error.prototype);
    i.prototype.constructor = i;
    i.prototype.name = "DefaultsError";
    t(i);
    function we(e, n, t) {
        if (t) for (var r in e) {
            if (it(e, r) && !it(n, r)) throw new i("`" + r + "` is not a supported option", n);
        }
        for (var r in e) {
            if (it(e, r)) n[r] = e[r];
        }
        return n;
    }
    function Kn() {}
    function hn() {
        return false;
    }
    function vn() {
        return true;
    }
    function Qn() {
        return this;
    }
    function Zn() {
        return null;
    }
    var et = function() {
        function e(e, n) {
            var t = [];
            for (var r = 0; r < e.length; r++) {
                var i = n(e[r], r);
                if (i === a) continue;
                if (i instanceof o) {
                    t.push.apply(t, i.v);
                } else {
                    t.push(i);
                }
            }
            return t;
        }
        e.is_op = function(e) {
            return e === a || e instanceof o;
        };
        e.splice = function(e) {
            return new o(e);
        };
        var a = e.skip = {};
        function o(e) {
            this.v = e;
        }
        return e;
    }();
    function nt(e, n) {
        if (e.indexOf(n) < 0) return e.push(n);
    }
    function tt(e, r) {
        return e.replace(/\{([^{}]+)\}/g, function(e, n) {
            var t = n == "this" ? r : r[n];
            if (t instanceof bn) return t.print_to_string();
            if (t instanceof te) return t.file + ":" + t.line + "," + t.col;
            return t;
        });
    }
    function rt(e, n) {
        var t = e.indexOf(n);
        if (t >= 0) e.splice(t, 1);
    }
    function mn(e) {
        if (!Array.isArray(e)) e = e.split(" ");
        var n = Object.create(null);
        e.forEach(function(e) {
            n[e] = true;
        });
        return n;
    }
    function _n(e, n) {
        for (var t = e.length; --t >= 0; ) if (!n(e[t], t)) return false;
        return true;
    }
    function gn() {
        this.values = Object.create(null);
    }
    gn.prototype = {
        set: function(e, n) {
            if (e == "__proto__") {
                this.proto_value = n;
            } else {
                this.values[e] = n;
            }
            return this;
        },
        add: function(e, n) {
            var t = this.get(e);
            if (t) {
                t.push(n);
            } else {
                this.set(e, [ n ]);
            }
            return this;
        },
        get: function(e) {
            return e == "__proto__" ? this.proto_value : this.values[e];
        },
        del: function(e) {
            if (e == "__proto__") {
                delete this.proto_value;
            } else {
                delete this.values[e];
            }
            return this;
        },
        has: function(e) {
            return e == "__proto__" ? "proto_value" in this : e in this.values;
        },
        all: function(e) {
            for (var n in this.values) if (!e(this.values[n], n)) return false;
            if ("proto_value" in this && !e(this.proto_value, "__proto__")) return false;
            return true;
        },
        each: function(e) {
            for (var n in this.values) e(this.values[n], n);
            if ("proto_value" in this) e(this.proto_value, "__proto__");
        },
        size: function() {
            return Object.keys(this.values).length + ("proto_value" in this);
        },
        map: function(e) {
            var n = [];
            for (var t in this.values) n.push(e(this.values[t], t));
            if ("proto_value" in this) n.push(e(this.proto_value, "__proto__"));
            return n;
        },
        clone: function() {
            var t = new gn();
            this.each(function(e, n) {
                t.set(n, e);
            });
            return t;
        },
        toObject: function() {
            var t = {};
            this.each(function(e, n) {
                t["$" + n] = e;
            });
            return t;
        }
    };
    gn.fromObject = function(e) {
        var n = new gn();
        for (var t in e) if (it(e, t)) n.set(t.slice(1), e[t]);
        return n;
    };
    function it(e, n) {
        return Object.prototype.hasOwnProperty.call(e, n);
    }
    function at(e, n, t) {
        var r = e.parent(-1);
        for (var i = 0, a; a = e.parent(i++); r = a) {
            if (At(a)) {
                return n && a.value === r;
            } else if (a instanceof jn) {
                if (a.left === r) continue;
            } else if (a.TYPE == "Call") {
                if (a.expression === r) continue;
            } else if (a instanceof Nn) {
                if (a.condition === r) continue;
            } else if (a instanceof vr) {
                return t;
            } else if (a instanceof $n) {
                if (a.expression === r) continue;
            } else if (a instanceof On) {
                if (a.expressions[0] === r) continue;
            } else if (a instanceof wn) {
                return true;
            } else if (a instanceof Vr) {
                if (a.tag === r) continue;
            } else if (a instanceof yr) {
                if (a.expression === r) continue;
            }
            return false;
        }
    }
    function r(r, e) {
        if (e.length > 31) throw new Error("Too many properties: " + e.length + "\n" + e.join(", "));
        e.forEach(function(e, n) {
            var t = 1 << n;
            Object.defineProperty(r.prototype, e, {
                get: function() {
                    return !!(this._bits & t);
                },
                set: function(e) {
                    if (e) this._bits |= t; else this._bits &= ~t;
                }
            });
        });
    }
    /***********************************************************************

  A JavaScript tokenizer / parser / beautifier / compressor.
  https://github.com/mishoo/UglifyJS

  -------------------------------- (C) ---------------------------------

                           Author: Mihai Bazon
                         <mihai.bazon@gmail.com>
                       http://mihai.bazon.net/blog

  Distributed under the BSD license:

    Copyright 2012 (c) Mihai Bazon <mihai.bazon@gmail.com>

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

        * Redistributions of source code must retain the above
          copyright notice, this list of conditions and the following
          disclaimer.

        * Redistributions in binary form must reproduce the above
          copyright notice, this list of conditions and the following
          disclaimer in the documentation and/or other materials
          provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER “AS IS” AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE
    LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
    OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
    TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
    THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
    SUCH DAMAGE.

 ***********************************************************************/
    "use strict";
    function e(e, n, t, r) {
        if (typeof r === "undefined") r = bn;
        n = n ? n.split(/\s+/) : [];
        var i = n;
        if (r && r.PROPS) n = n.concat(r.PROPS);
        var a = [ "return function AST_", e, "(props){", "this._bits=0;", "if(props){" ];
        n.forEach(function(e) {
            a.push("this.", e, "=props.", e, ";");
        });
        a.push("}");
        var o = Object.create(r && r.prototype);
        if (t.initialize || o.initialize) a.push("this.initialize();");
        a.push("};");
        var s = new Function(a.join(""))();
        s.prototype = o;
        s.prototype.CTOR = s;
        s.prototype.TYPE = s.TYPE = e;
        if (r) {
            s.BASE = r;
            r.SUBCLASSES.push(s);
        }
        s.DEFMETHOD = function(e, n) {
            this.prototype[e] = n;
        };
        s.PROPS = n;
        s.SELF_PROPS = i;
        s.SUBCLASSES = [];
        for (var f in t) if (it(t, f)) {
            if (/^\$/.test(f)) {
                s[f.substr(1)] = t[f];
            } else {
                s.DEFMETHOD(f, t[f]);
            }
        }
        if (typeof b !== "undefined") b["AST_" + e] = s;
        return s;
    }
    var te = e("Token", "type value line col pos endline endcol endpos nlb comments_before comments_after file raw", {}, null);
    var bn = e("Node", "start end", {
        _clone: function(e) {
            if (e) {
                var n = this.clone();
                return n.transform(new ii(function(e) {
                    if (e !== n) {
                        return e.clone(true);
                    }
                }));
            }
            return new this.CTOR(this);
        },
        clone: function(e) {
            return this._clone(e);
        },
        $documentation: "Base class of all AST nodes",
        $propdoc: {
            start: "[AST_Token] The first token of this node",
            end: "[AST_Token] The last token of this node"
        },
        equals: function(e) {
            return this.TYPE == e.TYPE && this._equals(e);
        },
        walk: function(e) {
            e.visit(this);
        },
        _validate: function() {
            if (this.TYPE == "Node") throw new Error("should not instantiate AST_Node");
        },
        validate: function() {
            var e = this.CTOR;
            do {
                e.prototype._validate.call(this);
            } while (e = e.BASE);
        },
        validate_ast: function() {
            var n = {};
            this.walk(new Gn(function(e) {
                if (e.validate_visited === n) {
                    throw new Error(tt("cannot reuse AST_{TYPE} from [{start}]", e));
                }
                e.validate_visited = n;
            }));
        }
    }, null);
    r(bn, [ "_optimized", "_squeezed", "call_only", "collapse_scanning", "defined", "evaluating", "falsy", "in_arg", "in_bool", "is_undefined", "inlined", "length_read", "nested", "new", "optional", "private", "pure", "redundant", "single_use", "static", "terminal", "truthy", "uses_eval", "uses_with" ]);
    (bn.log_function = function(n, e) {
        if (typeof n != "function") {
            bn.info = bn.warn = Kn;
            return;
        }
        var t = Object.create(null);
        bn.info = e ? function(e, n) {
            r("INFO: " + tt(e, n));
        } : Kn;
        bn.warn = function(e, n) {
            r("WARN: " + tt(e, n));
        };
        function r(e) {
            if (t[e]) return;
            t[e] = true;
            n(e);
        }
    })();
    var a = [];
    bn.enable_validation = function() {
        bn.disable_validation();
        (function e(n) {
            n.SUBCLASSES.forEach(e);
            if (!it(n.prototype, "transform")) return;
            var r = n.prototype.transform;
            n.prototype.transform = function(e, n) {
                var t = r.call(this, e, n);
                if (t instanceof bn) {
                    t.validate();
                } else if (!(t === null || n && et.is_op(t))) {
                    throw new Error("invalid transformed value: " + t);
                }
                return t;
            };
            a.push(function() {
                n.prototype.transform = r;
            });
        })(this);
    };
    bn.disable_validation = function() {
        var e;
        while (e = a.pop()) e();
    };
    function o(e, t) {
        return e.length == t.length && _n(e, function(e, n) {
            return e.equals(t[n]);
        });
    }
    function s(e, t) {
        return e.length == t.length && _n(e, function(e, n) {
            return e == t[n];
        });
    }
    function f(e, n) {
        if (e === n) return true;
        if (e == null) return n == null;
        return e instanceof bn && n instanceof bn && e.equals(n);
    }
    var ot = e("Statement", null, {
        $documentation: "Base class of all statements",
        _validate: function() {
            if (this.TYPE == "Statement") throw new Error("should not instantiate AST_Statement");
        }
    });
    var st = e("Debugger", null, {
        $documentation: "Represents a debugger statement",
        _equals: vn
    }, ot);
    var ft = e("Directive", "quote value", {
        $documentation: 'Represents a directive, like "use strict";',
        $propdoc: {
            quote: "[string?] the original quote character",
            value: "[string] The value of this directive as a plain string (it's not an AST_String!)"
        },
        _equals: function(e) {
            return this.value == e.value;
        },
        _validate: function() {
            if (this.quote != null) {
                if (typeof this.quote != "string") throw new Error("quote must be string");
                if (!/^["']$/.test(this.quote)) throw new Error("invalid quote: " + this.quote);
            }
            if (typeof this.value != "string") throw new Error("value must be string");
        }
    }, ot);
    var yn = e("EmptyStatement", null, {
        $documentation: "The empty statement (empty block or simply a semicolon)",
        _equals: vn
    }, ot);
    function ut(e) {
        return e instanceof ot && !(e instanceof Lt) && !(e instanceof Tt);
    }
    function u(e, n, t, r, i) {
        t = t ? "contain" : "be";
        if (!(e instanceof bn)) throw new Error(n + " must " + t + " AST_Node");
        if (e instanceof Dn) throw new Error(n + " cannot " + t + " AST_DefaultValue");
        if (e instanceof Yn) throw new Error(n + " cannot " + t + " AST_Destructured");
        if (e instanceof Zr && !i) throw new Error(n + " cannot " + t + " AST_Hole");
        if (e instanceof Mn && !r) throw new Error(n + " cannot " + t + " AST_Spread");
        if (ut(e)) throw new Error(n + " cannot " + t + " AST_Statement");
        if (e instanceof zr) {
            throw new Error(n + " cannot " + t + " AST_SymbolDeclaration");
        }
    }
    function c(e, n) {
        u(e[n], n);
    }
    var wn = e("SimpleStatement", "body", {
        $documentation: "A statement consisting of an expression, i.e. a = 1 + 2",
        $propdoc: {
            body: "[AST_Node] an expression node (should not be instanceof AST_Statement)"
        },
        _equals: function(e) {
            return this.body.equals(e.body);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                n.body.walk(e);
            });
        },
        _validate: function() {
            c(this, "body");
        }
    }, ot);
    var ct = e("BlockScope", "_var_names enclosed functions make_def parent_scope variables", {
        $documentation: "Base class for all statements introducing a lexical scope",
        $propdoc: {
            enclosed: "[SymbolDef*/S] a list of all symbol definitions that are accessed from this scope or any inner scopes",
            functions: "[Dictionary/S] like `variables`, but only lists function declarations",
            parent_scope: "[AST_Scope?/S] link to the parent scope",
            variables: "[Dictionary/S] a map of name ---\x3e SymbolDef for all variables/functions defined in this scope"
        },
        clone: function(e) {
            var n = this._clone(e);
            if (this.enclosed) n.enclosed = this.enclosed.slice();
            if (this.functions) n.functions = this.functions.clone();
            if (this.variables) n.variables = this.variables.clone();
            return n;
        },
        pinned: function() {
            return this.resolve().pinned();
        },
        resolve: function() {
            return this.parent_scope.resolve();
        },
        _validate: function() {
            if (this.TYPE == "BlockScope") throw new Error("should not instantiate AST_BlockScope");
            if (this.parent_scope == null) return;
            if (!(this.parent_scope instanceof ct)) throw new Error("parent_scope must be AST_BlockScope");
            if (!(this.resolve() instanceof kn)) throw new Error("must be contained within AST_Scope");
        }
    }, ot);
    function lt(e, n) {
        e.body.forEach(function(e) {
            e.walk(n);
        });
    }
    var pt = e("Block", "body", {
        $documentation: "A body of statements (usually braced)",
        $propdoc: {
            body: "[AST_Statement*] an array of statements"
        },
        _equals: function(e) {
            return o(this.body, e.body);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                lt(n, e);
            });
        },
        _validate: function() {
            if (this.TYPE == "Block") throw new Error("should not instantiate AST_Block");
            this.body.forEach(function(e) {
                if (!ut(e)) throw new Error("body must contain AST_Statement");
            });
        }
    }, ct);
    var xn = e("BlockStatement", null, {
        $documentation: "A block statement"
    }, pt);
    var N = e("StatementWithBody", "body", {
        $documentation: "Base class for all statements that contain one nested body: `For`, `ForIn`, `Do`, `While`, `With`",
        $propdoc: {
            body: "[AST_Statement] the body; this should always be present, even if it's an AST_EmptyStatement"
        },
        _validate: function() {
            if (this.TYPE == "StatementWithBody") throw new Error("should not instantiate AST_StatementWithBody");
            if (!ut(this.body)) throw new Error("body must be AST_Statement");
        }
    }, ct);
    var dt = e("LabeledStatement", "label", {
        $documentation: "Statement with a label",
        $propdoc: {
            label: "[AST_Label] a label definition"
        },
        _equals: function(e) {
            return this.label.equals(e.label) && this.body.equals(e.body);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                n.label.walk(e);
                n.body.walk(e);
            });
        },
        clone: function(e) {
            var n = this._clone(e);
            if (e) {
                var t = n.label;
                var r = this.label;
                n.walk(new Gn(function(e) {
                    if (e instanceof er) {
                        if (!e.label || e.label.thedef !== r) return;
                        e.label.thedef = t;
                        t.references.push(e);
                        return true;
                    }
                    if (e instanceof kn) return true;
                }));
            }
            return n;
        },
        _validate: function() {
            if (!(this.label instanceof Se)) throw new Error("label must be AST_Label");
        }
    }, N);
    var ht = e("IterationStatement", null, {
        $documentation: "Internal class.  All loops inherit from it.",
        _validate: function() {
            if (this.TYPE == "IterationStatement") throw new Error("should not instantiate AST_IterationStatement");
        }
    }, N);
    var vt = e("DWLoop", "condition", {
        $documentation: "Base class for do/while statements",
        $propdoc: {
            condition: "[AST_Node] the loop condition.  Should not be instanceof AST_Statement"
        },
        _equals: function(e) {
            return this.body.equals(e.body) && this.condition.equals(e.condition);
        },
        _validate: function() {
            if (this.TYPE == "DWLoop") throw new Error("should not instantiate AST_DWLoop");
            c(this, "condition");
        }
    }, ht);
    var mt = e("Do", null, {
        $documentation: "A `do` statement",
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                n.body.walk(e);
                n.condition.walk(e);
            });
        }
    }, vt);
    var _t = e("While", null, {
        $documentation: "A `while` statement",
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                n.condition.walk(e);
                n.body.walk(e);
            });
        }
    }, vt);
    var gt = e("For", "init condition step", {
        $documentation: "A `for` statement",
        $propdoc: {
            init: "[AST_Node?] the `for` initialization code, or null if empty",
            condition: "[AST_Node?] the `for` termination clause, or null if empty",
            step: "[AST_Node?] the `for` update clause, or null if empty"
        },
        _equals: function(e) {
            return f(this.init, e.init) && f(this.condition, e.condition) && f(this.step, e.step) && this.body.equals(e.body);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                if (n.init) n.init.walk(e);
                if (n.condition) n.condition.walk(e);
                if (n.step) n.step.walk(e);
                n.body.walk(e);
            });
        },
        _validate: function() {
            if (this.init != null) {
                if (!(this.init instanceof bn)) throw new Error("init must be AST_Node");
                if (ut(this.init) && !(this.init instanceof cr)) {
                    throw new Error("init cannot be AST_Statement");
                }
            }
            if (this.condition != null) c(this, "condition");
            if (this.step != null) c(this, "step");
        }
    }, ht);
    var bt = e("ForEnumeration", "init object", {
        $documentation: "Base class for enumeration loops, i.e. `for ... in`, `for ... of` & `for await ... of`",
        $propdoc: {
            init: "[AST_Node] the assignment target during iteration",
            object: "[AST_Node] the object to iterate over"
        },
        _equals: function(e) {
            return this.init.equals(e.init) && this.object.equals(e.object) && this.body.equals(e.body);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                n.init.walk(e);
                n.object.walk(e);
                n.body.walk(e);
            });
        },
        _validate: function() {
            if (this.TYPE == "ForEnumeration") throw new Error("should not instantiate AST_ForEnumeration");
            if (this.init instanceof cr) {
                if (this.init.definitions.length != 1) throw new Error("init must have single declaration");
            } else {
                p(this.init, function(e) {
                    if (!(e instanceof $n || e instanceof Ln)) {
                        throw new Error("init must be assignable: " + e.TYPE);
                    }
                });
            }
            c(this, "object");
        }
    }, ht);
    var yt = e("ForIn", null, {
        $documentation: "A `for ... in` statement"
    }, bt);
    var xe = e("ForOf", null, {
        $documentation: "A `for ... of` statement"
    }, bt);
    var wt = e("ForAwaitOf", null, {
        $documentation: "A `for await ... of` statement"
    }, xe);
    var xt = e("With", "expression", {
        $documentation: "A `with` statement",
        $propdoc: {
            expression: "[AST_Node] the `with` expression"
        },
        _equals: function(e) {
            return this.expression.equals(e.expression) && this.body.equals(e.body);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                n.expression.walk(e);
                n.body.walk(e);
            });
        },
        _validate: function() {
            c(this, "expression");
        }
    }, N);
    var kn = e("Scope", "fn_defs may_call_this uses_eval uses_with", {
        $documentation: "Base class for all statements introducing a lambda scope",
        $propdoc: {
            uses_eval: "[boolean/S] tells whether this scope contains a direct call to the global `eval`",
            uses_with: "[boolean/S] tells whether this scope uses the `with` statement"
        },
        pinned: function() {
            return this.uses_eval || this.uses_with;
        },
        resolve: Qn,
        _validate: function() {
            if (this.TYPE == "Scope") throw new Error("should not instantiate AST_Scope");
        }
    }, pt);
    var kt = e("Toplevel", "globals", {
        $documentation: "The toplevel scope",
        $propdoc: {
            globals: "[Dictionary/S] a map of name ---\x3e SymbolDef for all undeclared names"
        },
        wrap: function(e) {
            var n = this.body;
            return ci([ "(function(exports){'$ORIG';})(typeof ", e, "=='undefined'?(", e, "={}):", e, ");" ].join(""), {
                filename: "wrap=" + JSON.stringify(e)
            }).transform(new ii(function(e) {
                if (e instanceof ft && e.value == "$ORIG") {
                    return et.splice(n);
                }
            }));
        },
        enclose: function(e) {
            if (typeof e != "string") e = "";
            var n = e.indexOf(":");
            if (n < 0) n = e.length;
            var t = this.body;
            return ci([ "(function(", e.slice(0, n), '){"$ORIG"})(', e.slice(n + 1), ")" ].join(""), {
                filename: "enclose=" + JSON.stringify(e)
            }).transform(new ii(function(e) {
                if (e instanceof ft && e.value == "$ORIG") {
                    return et.splice(t);
                }
            }));
        }
    }, kn);
    var Et = e("ClassInitBlock", null, {
        $documentation: "Value for `class` static initialization blocks"
    }, kn);
    var En = e("Lambda", "argnames length_read rest safe_ids uses_arguments", {
        $documentation: "Base class for functions",
        $propdoc: {
            argnames: "[(AST_DefaultValue|AST_Destructured|AST_SymbolFunarg)*] array of function arguments and/or destructured literals",
            length_read: "[boolean/S] whether length property of this function is accessed",
            rest: "[(AST_Destructured|AST_SymbolFunarg)?] rest parameter, or null if absent",
            uses_arguments: "[boolean|number/S] whether this function accesses the arguments array"
        },
        each_argname: function(n) {
            var t = new Gn(function(e) {
                if (e instanceof Dn) {
                    e.name.walk(t);
                    return true;
                }
                if (e instanceof Er) {
                    e.value.walk(t);
                    return true;
                }
                if (e instanceof Bn) n(e);
            });
            this.argnames.forEach(function(e) {
                e.walk(t);
            });
            if (this.rest) this.rest.walk(t);
        },
        _equals: function(e) {
            return f(this.rest, e.rest) && f(this.name, e.name) && f(this.value, e.value) && o(this.argnames, e.argnames) && o(this.body, e.body);
        },
        walk: function(n) {
            var e = this;
            n.visit(e, function() {
                if (e.name) e.name.walk(n);
                e.argnames.forEach(function(e) {
                    e.walk(n);
                });
                if (e.rest) e.rest.walk(n);
                lt(e, n);
            });
        },
        _validate: function() {
            if (this.TYPE == "Lambda") throw new Error("should not instantiate AST_Lambda");
            this.argnames.forEach(function(e) {
                p(e, function(e) {
                    if (!(e instanceof Bn)) throw new Error("argnames must be AST_SymbolFunarg[]");
                }, true);
            });
            if (this.rest != null) p(this.rest, function(e) {
                if (!(e instanceof Bn)) throw new Error("rest must be AST_SymbolFunarg");
            });
        }
    }, kn);
    var St = e("Accessor", null, {
        $documentation: "A getter/setter function",
        _validate: function() {
            if (this.name != null) throw new Error("name must be null");
        }
    }, En);
    var Tt = e("LambdaExpression", "inlined", {
        $documentation: "Base class for function expressions",
        $propdoc: {
            inlined: "[boolean/S] whether this function has been inlined"
        },
        _validate: function() {
            if (this.TYPE == "LambdaExpression") throw new Error("should not instantiate AST_LambdaExpression");
        }
    }, En);
    function At(e) {
        return e instanceof $t || e instanceof zt;
    }
    function Dt(e) {
        return e instanceof zt || e instanceof Nt || e instanceof Ct || e instanceof It || e instanceof Mt;
    }
    function qt(e) {
        return e instanceof It || e instanceof Mt || e instanceof Yt || e instanceof Pt;
    }
    function Ot(e, n) {
        if (At(e) && e.value) {
            e.value.walk(n);
        } else {
            lt(e, n);
        }
    }
    var $t = e("Arrow", "value", {
        $documentation: "An arrow function expression",
        $propdoc: {
            value: "[AST_Node?] simple return expression, or null if using function body."
        },
        walk: function(n) {
            var e = this;
            n.visit(e, function() {
                e.argnames.forEach(function(e) {
                    e.walk(n);
                });
                if (e.rest) e.rest.walk(n);
                if (e.value) {
                    e.value.walk(n);
                } else {
                    lt(e, n);
                }
            });
        },
        _validate: function() {
            if (this.name != null) throw new Error("name must be null");
            if (this.uses_arguments) throw new Error("uses_arguments must be false");
            if (this.value != null) {
                c(this, "value");
                if (this.body.length) throw new Error("body must be empty if value exists");
            }
        }
    }, Tt);
    var zt = e("AsyncArrow", "value", {
        $documentation: "An asynchronous arrow function expression",
        $propdoc: {
            value: "[AST_Node?] simple return expression, or null if using function body."
        },
        walk: function(n) {
            var e = this;
            n.visit(e, function() {
                e.argnames.forEach(function(e) {
                    e.walk(n);
                });
                if (e.rest) e.rest.walk(n);
                if (e.value) {
                    e.value.walk(n);
                } else {
                    lt(e, n);
                }
            });
        },
        _validate: function() {
            if (this.name != null) throw new Error("name must be null");
            if (this.uses_arguments) throw new Error("uses_arguments must be false");
            if (this.value != null) {
                c(this, "value");
                if (this.body.length) throw new Error("body must be empty if value exists");
            }
        }
    }, Tt);
    var Ct = e("AsyncFunction", "name", {
        $documentation: "An asynchronous function expression",
        $propdoc: {
            name: "[AST_SymbolLambda?] the name of this function, or null if not specified"
        },
        _validate: function() {
            if (this.name != null) {
                if (!(this.name instanceof Nr)) throw new Error("name must be AST_SymbolLambda");
            }
        }
    }, Tt);
    var Mt = e("AsyncGeneratorFunction", "name", {
        $documentation: "An asynchronous generator function expression",
        $propdoc: {
            name: "[AST_SymbolLambda?] the name of this function, or null if not specified"
        },
        _validate: function() {
            if (this.name != null) {
                if (!(this.name instanceof Nr)) throw new Error("name must be AST_SymbolLambda");
            }
        }
    }, Tt);
    var Ft = e("Function", "name", {
        $documentation: "A function expression",
        $propdoc: {
            name: "[AST_SymbolLambda?] the name of this function, or null if not specified"
        },
        _validate: function() {
            if (this.name != null) {
                if (!(this.name instanceof Nr)) throw new Error("name must be AST_SymbolLambda");
            }
        }
    }, Tt);
    var Pt = e("GeneratorFunction", "name", {
        $documentation: "A generator function expression",
        $propdoc: {
            name: "[AST_SymbolLambda?] the name of this function, or null if not specified"
        },
        _validate: function() {
            if (this.name != null) {
                if (!(this.name instanceof Nr)) throw new Error("name must be AST_SymbolLambda");
            }
        }
    }, Tt);
    var jt = e("LambdaDefinition", "inlined name", {
        $documentation: "Base class for function definitions",
        $propdoc: {
            inlined: "[boolean/S] whether this function has been inlined",
            name: "[AST_SymbolDefun] the name of this function"
        },
        _validate: function() {
            if (this.TYPE == "LambdaDefinition") throw new Error("should not instantiate AST_LambdaDefinition");
            if (!(this.name instanceof jr)) throw new Error("name must be AST_SymbolDefun");
        }
    }, En);
    var Nt = e("AsyncDefun", null, {
        $documentation: "An asynchronous function definition"
    }, jt);
    var It = e("AsyncGeneratorDefun", null, {
        $documentation: "An asynchronous generator function definition"
    }, jt);
    var Ht = e("Defun", null, {
        $documentation: "A function definition"
    }, jt);
    var Yt = e("GeneratorDefun", null, {
        $documentation: "A generator function definition"
    }, jt);
    var Rt = e("Class", "extends name properties", {
        $documentation: "Base class for class literals",
        $propdoc: {
            extends: "[AST_Node?] the super class, or null if not specified",
            properties: "[AST_ClassProperty*] array of class properties"
        },
        _equals: function(e) {
            return f(this.name, e.name) && f(this.extends, e.extends) && o(this.properties, e.properties);
        },
        resolve: function(e) {
            return e ? this : this.parent_scope.resolve();
        },
        walk: function(n) {
            var e = this;
            n.visit(e, function() {
                if (e.name) e.name.walk(n);
                if (e.extends) e.extends.walk(n);
                e.properties.forEach(function(e) {
                    e.walk(n);
                });
            });
        },
        _validate: function() {
            if (this.TYPE == "Class") throw new Error("should not instantiate AST_Class");
            if (this.extends != null) c(this, "extends");
            this.properties.forEach(function(e) {
                if (!(e instanceof Ut)) throw new Error("properties must contain AST_ClassProperty");
            });
        }
    }, ct);
    var Bt = e("DefClass", null, {
        $documentation: "A class definition",
        $propdoc: {
            name: "[AST_SymbolDefClass] the name of this class"
        },
        _validate: function() {
            if (!(this.name instanceof Ee)) throw new Error("name must be AST_SymbolDefClass");
        }
    }, Rt);
    var Lt = e("ClassExpression", null, {
        $documentation: "A class expression",
        $propdoc: {
            name: "[AST_SymbolClass?] the name of this class, or null if not specified"
        },
        _validate: function() {
            if (this.name != null) {
                if (!(this.name instanceof Ir)) throw new Error("name must be AST_SymbolClass");
            }
        }
    }, Rt);
    var Ut = e("ClassProperty", "key private static value", {
        $documentation: "Base class for `class` properties",
        $propdoc: {
            key: "[string|AST_Node?] property name (AST_Node for computed property, null for initialization block)",
            private: "[boolean] whether this is a private property",
            static: "[boolean] whether this is a static property",
            value: "[AST_Node?] property value (AST_Accessor for getters/setters, AST_LambdaExpression for methods, null if not specified for fields)"
        },
        _equals: function(e) {
            return !this.private == !e.private && !this.static == !e.static && f(this.key, e.key) && f(this.value, e.value);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                if (n.key instanceof bn) n.key.walk(e);
                if (n.value) n.value.walk(e);
            });
        },
        _validate: function() {
            if (this.TYPE == "ClassProperty") throw new Error("should not instantiate AST_ClassProperty");
            if (this instanceof Xt) {
                if (this.key != null) throw new Error("key must be null");
            } else if (typeof this.key != "string") {
                if (!(this.key instanceof bn)) throw new Error("key must be string or AST_Node");
                c(this, "key");
            }
            if (this.value != null) {
                if (!(this.value instanceof bn)) throw new Error("value must be AST_Node");
            }
        }
    });
    var Vt = e("ClassField", null, {
        $documentation: "A `class` field",
        _validate: function() {
            if (this.value != null) c(this, "value");
        }
    }, Ut);
    var Wt = e("ClassGetter", null, {
        $documentation: "A `class` getter",
        _validate: function() {
            if (!(this.value instanceof St)) throw new Error("value must be AST_Accessor");
        }
    }, Ut);
    var Gt = e("ClassSetter", null, {
        $documentation: "A `class` setter",
        _validate: function() {
            if (!(this.value instanceof St)) throw new Error("value must be AST_Accessor");
        }
    }, Ut);
    var Jt = e("ClassMethod", null, {
        $documentation: "A `class` method",
        _validate: function() {
            if (!(this.value instanceof Tt)) throw new Error("value must be AST_LambdaExpression");
            if (At(this.value)) throw new Error("value cannot be AST_Arrow or AST_AsyncArrow");
            if (this.value.name != null) throw new Error("name of class method's lambda must be null");
        }
    }, Ut);
    var Xt = e("ClassInit", null, {
        $documentation: "A `class` static initialization block",
        _validate: function() {
            if (!this.static) throw new Error("static must be true");
            if (!(this.value instanceof Et)) throw new Error("value must be AST_ClassInitBlock");
        },
        initialize: function() {
            this.static = true;
        }
    }, Ut);
    var Kt = e("Jump", null, {
        $documentation: "Base class for “jumps” (for now that's `return`, `throw`, `break` and `continue`)",
        _validate: function() {
            if (this.TYPE == "Jump") throw new Error("should not instantiate AST_Jump");
        }
    }, ot);
    var Qt = e("Exit", "value", {
        $documentation: "Base class for “exits” (`return` and `throw`)",
        $propdoc: {
            value: "[AST_Node?] the value returned or thrown by this statement; could be null for AST_Return"
        },
        _equals: function(e) {
            return f(this.value, e.value);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                if (n.value) n.value.walk(e);
            });
        },
        _validate: function() {
            if (this.TYPE == "Exit") throw new Error("should not instantiate AST_Exit");
        }
    }, Kt);
    var Sn = e("Return", null, {
        $documentation: "A `return` statement",
        _validate: function() {
            if (this.value != null) c(this, "value");
        }
    }, Qt);
    var Zt = e("Throw", null, {
        $documentation: "A `throw` statement",
        _validate: function() {
            c(this, "value");
        }
    }, Qt);
    var er = e("LoopControl", "label", {
        $documentation: "Base class for loop control statements (`break` and `continue`)",
        $propdoc: {
            label: "[AST_LabelRef?] the label, or null if none"
        },
        _equals: function(e) {
            return f(this.label, e.label);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                if (n.label) n.label.walk(e);
            });
        },
        _validate: function() {
            if (this.TYPE == "LoopControl") throw new Error("should not instantiate AST_LoopControl");
            if (this.label != null) {
                if (!(this.label instanceof Te)) throw new Error("label must be AST_LabelRef");
            }
        }
    }, Kt);
    var nr = e("Break", null, {
        $documentation: "A `break` statement"
    }, er);
    var tr = e("Continue", null, {
        $documentation: "A `continue` statement"
    }, er);
    var Tn = e("If", "condition alternative", {
        $documentation: "A `if` statement",
        $propdoc: {
            condition: "[AST_Node] the `if` condition",
            alternative: "[AST_Statement?] the `else` part, or null if not present"
        },
        _equals: function(e) {
            return this.body.equals(e.body) && this.condition.equals(e.condition) && f(this.alternative, e.alternative);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                n.condition.walk(e);
                n.body.walk(e);
                if (n.alternative) n.alternative.walk(e);
            });
        },
        _validate: function() {
            c(this, "condition");
            if (this.alternative != null) {
                if (!ut(this.alternative)) throw new Error("alternative must be AST_Statement");
            }
        }
    }, N);
    var rr = e("Switch", "expression", {
        $documentation: "A `switch` statement",
        $propdoc: {
            expression: "[AST_Node] the `switch` “discriminant”"
        },
        _equals: function(e) {
            return this.expression.equals(e.expression) && o(this.body, e.body);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                n.expression.walk(e);
                lt(n, e);
            });
        },
        _validate: function() {
            c(this, "expression");
            this.body.forEach(function(e) {
                if (!(e instanceof ir)) throw new Error("body must be AST_SwitchBranch[]");
            });
        }
    }, pt);
    var ir = e("SwitchBranch", null, {
        $documentation: "Base class for `switch` branches",
        _validate: function() {
            if (this.TYPE == "SwitchBranch") throw new Error("should not instantiate AST_SwitchBranch");
        }
    }, pt);
    var ar = e("Default", null, {
        $documentation: "A `default` switch branch"
    }, ir);
    var or = e("Case", "expression", {
        $documentation: "A `case` switch branch",
        $propdoc: {
            expression: "[AST_Node] the `case` expression"
        },
        _equals: function(e) {
            return this.expression.equals(e.expression) && o(this.body, e.body);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                n.expression.walk(e);
                lt(n, e);
            });
        },
        _validate: function() {
            c(this, "expression");
        }
    }, ir);
    var sr = e("Try", "bcatch bfinally", {
        $documentation: "A `try` statement",
        $propdoc: {
            bcatch: "[AST_Catch?] the catch block, or null if not present",
            bfinally: "[AST_Finally?] the finally block, or null if not present"
        },
        _equals: function(e) {
            return o(this.body, e.body) && f(this.bcatch, e.bcatch) && f(this.bfinally, e.bfinally);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                lt(n, e);
                if (n.bcatch) n.bcatch.walk(e);
                if (n.bfinally) n.bfinally.walk(e);
            });
        },
        _validate: function() {
            if (this.bcatch != null) {
                if (!(this.bcatch instanceof fr)) throw new Error("bcatch must be AST_Catch");
            }
            if (this.bfinally != null) {
                if (!(this.bfinally instanceof ur)) throw new Error("bfinally must be AST_Finally");
            }
        }
    }, pt);
    var fr = e("Catch", "argname", {
        $documentation: "A `catch` node; only makes sense as part of a `try` statement",
        $propdoc: {
            argname: "[(AST_Destructured|AST_SymbolCatch)?] symbol for the exception, or null if not present"
        },
        _equals: function(e) {
            return f(this.argname, e.argname) && o(this.body, e.body);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                if (n.argname) n.argname.walk(e);
                lt(n, e);
            });
        },
        _validate: function() {
            if (this.argname != null) p(this.argname, function(e) {
                if (!(e instanceof Hr)) throw new Error("argname must be AST_SymbolCatch");
            });
        }
    }, pt);
    var ur = e("Finally", null, {
        $documentation: "A `finally` node; only makes sense as part of a `try` statement"
    }, pt);
    var cr = e("Definitions", "definitions", {
        $documentation: "Base class for `var` nodes (variable declarations/initializations)",
        $propdoc: {
            definitions: "[AST_VarDef*] array of variable definitions"
        },
        _equals: function(e) {
            return o(this.definitions, e.definitions);
        },
        walk: function(n) {
            var e = this;
            n.visit(e, function() {
                e.definitions.forEach(function(e) {
                    e.walk(n);
                });
            });
        },
        _validate: function() {
            if (this.TYPE == "Definitions") throw new Error("should not instantiate AST_Definitions");
            if (this.definitions.length < 1) throw new Error("must have at least one definition");
        }
    }, ot);
    var lr = e("Const", null, {
        $documentation: "A `const` statement",
        _validate: function() {
            this.definitions.forEach(function(e) {
                if (!(e instanceof An)) throw new Error("definitions must be AST_VarDef[]");
                p(e.name, function(e) {
                    if (!(e instanceof Cr)) throw new Error("name must be AST_SymbolConst");
                });
            });
        }
    }, cr);
    var pr = e("Let", null, {
        $documentation: "A `let` statement",
        _validate: function() {
            this.definitions.forEach(function(e) {
                if (!(e instanceof An)) throw new Error("definitions must be AST_VarDef[]");
                p(e.name, function(e) {
                    if (!(e instanceof Fr)) throw new Error("name must be AST_SymbolLet");
                });
            });
        }
    }, cr);
    var dr = e("Var", null, {
        $documentation: "A `var` statement",
        _validate: function() {
            this.definitions.forEach(function(e) {
                if (!(e instanceof An)) throw new Error("definitions must be AST_VarDef[]");
                p(e.name, function(e) {
                    if (!(e instanceof Pr)) throw new Error("name must be AST_SymbolVar");
                });
            });
        }
    }, cr);
    var An = e("VarDef", "name value", {
        $documentation: "A variable declaration; only appears in a AST_Definitions node",
        $propdoc: {
            name: "[AST_Destructured|AST_SymbolVar] name of the variable",
            value: "[AST_Node?] initializer, or null of there's no initializer"
        },
        _equals: function(e) {
            return this.name.equals(e.name) && f(this.value, e.value);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                n.name.walk(e);
                if (n.value) n.value.walk(e);
            });
        },
        _validate: function() {
            if (this.value != null) c(this, "value");
        }
    });
    var hr = e("ExportDeclaration", "body", {
        $documentation: "An `export` statement",
        $propdoc: {
            body: "[AST_DefClass|AST_Definitions|AST_LambdaDefinition] the statement to export"
        },
        _equals: function(e) {
            return this.body.equals(e.body);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                n.body.walk(e);
            });
        },
        _validate: function() {
            if (!(this.body instanceof Bt || this.body instanceof cr || this.body instanceof jt)) {
                throw new Error("body must be AST_DefClass, AST_Definitions or AST_LambdaDefinition");
            }
        }
    }, ot);
    var vr = e("ExportDefault", "body", {
        $documentation: "An `export default` statement",
        $propdoc: {
            body: "[AST_Node] the default export"
        },
        _equals: function(e) {
            return this.body.equals(e.body);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                n.body.walk(e);
            });
        },
        _validate: function() {
            if (!(this.body instanceof Bt || this.body instanceof jt)) {
                c(this, "body");
            }
        }
    }, ot);
    var ke = e("ExportForeign", "aliases keys path", {
        $documentation: "An `export ... from '...'` statement",
        $propdoc: {
            aliases: "[AST_String*] array of aliases to export",
            keys: "[AST_String*] array of keys to import",
            path: "[AST_String] the path to import module"
        },
        _equals: function(e) {
            return this.path.equals(e.path) && o(this.aliases, e.aliases) && o(this.keys, e.keys);
        },
        _validate: function() {
            if (this.aliases.length != this.keys.length) {
                throw new Error("aliases:key length mismatch: " + this.aliases.length + " != " + this.keys.length);
            }
            this.aliases.forEach(function(e) {
                if (!(e instanceof Vn)) throw new Error("aliases must contain AST_String");
            });
            this.keys.forEach(function(e) {
                if (!(e instanceof Vn)) throw new Error("keys must contain AST_String");
            });
            if (!(this.path instanceof Vn)) throw new Error("path must be AST_String");
        }
    }, ot);
    var mr = e("ExportReferences", "properties", {
        $documentation: "An `export { ... }` statement",
        $propdoc: {
            properties: "[AST_SymbolExport*] array of aliases to export"
        },
        _equals: function(e) {
            return o(this.properties, e.properties);
        },
        walk: function(n) {
            var e = this;
            n.visit(e, function() {
                e.properties.forEach(function(e) {
                    e.walk(n);
                });
            });
        },
        _validate: function() {
            this.properties.forEach(function(e) {
                if (!(e instanceof Yr)) throw new Error("properties must contain AST_SymbolExport");
            });
        }
    }, ot);
    var _r = e("Import", "all default path properties", {
        $documentation: "An `import` statement",
        $propdoc: {
            all: "[AST_SymbolImport?] the imported namespace, or null if not specified",
            default: "[AST_SymbolImport?] the alias for default `export`, or null if not specified",
            path: "[AST_String] the path to import module",
            properties: "[(AST_SymbolImport*)?] array of aliases, or null if not specified"
        },
        _equals: function(e) {
            return this.path.equals(e.path) && f(this.all, e.all) && f(this.default, e.default) && !this.properties == !e.properties && (!this.properties || o(this.properties, e.properties));
        },
        walk: function(n) {
            var e = this;
            n.visit(e, function() {
                if (e.all) e.all.walk(n);
                if (e.default) e.default.walk(n);
                if (e.properties) e.properties.forEach(function(e) {
                    e.walk(n);
                });
            });
        },
        _validate: function() {
            if (this.all != null) {
                if (!(this.all instanceof Mr)) throw new Error("all must be AST_SymbolImport");
                if (this.properties != null) throw new Error("cannot import both * and {} in the same statement");
            }
            if (this.default != null) {
                if (!(this.default instanceof Mr)) throw new Error("default must be AST_SymbolImport");
                if (this.default.key.value !== "") throw new Error("invalid default key: " + this.default.key.value);
            }
            if (!(this.path instanceof Vn)) throw new Error("path must be AST_String");
            if (this.properties != null) this.properties.forEach(function(e) {
                if (!(e instanceof Mr)) throw new Error("properties must contain AST_SymbolImport");
            });
        }
    }, ot);
    var Dn = e("DefaultValue", "name value", {
        $documentation: "A default value declaration",
        $propdoc: {
            name: "[AST_Destructured|AST_SymbolDeclaration] name of the variable",
            value: "[AST_Node] value to assign if variable is `undefined`"
        },
        _equals: function(e) {
            return this.name.equals(e.name) && this.value.equals(e.value);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                n.name.walk(e);
                n.value.walk(e);
            });
        },
        _validate: function() {
            c(this, "value");
        }
    });
    function l(e, n, t, r) {
        e[n].forEach(function(e) {
            u(e, n, true, t, r);
        });
    }
    var qn = e("Call", "args expression optional pure terminal", {
        $documentation: "A function call expression",
        $propdoc: {
            args: "[AST_Node*] array of arguments",
            expression: "[AST_Node] expression to invoke as function",
            optional: "[boolean] whether the expression is optional chaining",
            pure: "[boolean/S] marker for side-effect-free call expression",
            terminal: "[boolean] whether the chain has ended"
        },
        _equals: function(e) {
            return !this.optional == !e.optional && this.expression.equals(e.expression) && o(this.args, e.args);
        },
        walk: function(n) {
            var e = this;
            n.visit(e, function() {
                e.expression.walk(n);
                e.args.forEach(function(e) {
                    e.walk(n);
                });
            });
        },
        _validate: function() {
            c(this, "expression");
            l(this, "args", true);
        }
    });
    var gr = e("New", null, {
        $documentation: "An object instantiation.  Derives from a function call since it has exactly the same properties",
        _validate: function() {
            if (this.optional) throw new Error("optional must be false");
            if (this.terminal) throw new Error("terminal must be false");
        }
    }, qn);
    var On = e("Sequence", "expressions", {
        $documentation: "A sequence expression (comma-separated expressions)",
        $propdoc: {
            expressions: "[AST_Node*] array of expressions (at least two)"
        },
        _equals: function(e) {
            return o(this.expressions, e.expressions);
        },
        walk: function(n) {
            var e = this;
            n.visit(e, function() {
                e.expressions.forEach(function(e) {
                    e.walk(n);
                });
            });
        },
        _validate: function() {
            if (this.expressions.length < 2) throw new Error("expressions must contain multiple elements");
            l(this, "expressions");
        }
    });
    function br(e) {
        while (e instanceof $n) e = e.expression;
        return e;
    }
    var $n = e("PropAccess", "expression optional property terminal", {
        $documentation: 'Base class for property access expressions, i.e. `a.foo` or `a["foo"]`',
        $propdoc: {
            expression: "[AST_Node] the “container” expression",
            optional: "[boolean] whether the expression is optional chaining",
            property: "[AST_Node|string] the property to access.  For AST_Dot this is always a plain string, while for AST_Sub it's an arbitrary AST_Node",
            terminal: "[boolean] whether the chain has ended"
        },
        _equals: function(e) {
            return !this.optional == !e.optional && f(this.property, e.property) && this.expression.equals(e.expression);
        },
        get_property: function() {
            var e = this.property;
            if (e instanceof Un) return e.value;
            if (e instanceof Pn && e.operator == "void" && e.expression instanceof Un) return;
            return e;
        },
        _validate: function() {
            if (this.TYPE == "PropAccess") throw new Error("should not instantiate AST_PropAccess");
            c(this, "expression");
        }
    });
    var zn = e("Dot", "quoted", {
        $documentation: "A dotted property access expression",
        $propdoc: {
            quoted: "[boolean] whether property is transformed from a quoted string"
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                n.expression.walk(e);
            });
        },
        _validate: function() {
            if (typeof this.property != "string") throw new Error("property must be string");
        }
    }, $n);
    var Cn = e("Sub", null, {
        $documentation: 'Index-style property access, i.e. `a["foo"]`',
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                n.expression.walk(e);
                n.property.walk(e);
            });
        },
        _validate: function() {
            c(this, "property");
        }
    }, $n);
    var Mn = e("Spread", "expression", {
        $documentation: "Spread expression in array/object literals or function calls",
        $propdoc: {
            expression: "[AST_Node] expression to be expanded"
        },
        _equals: function(e) {
            return this.expression.equals(e.expression);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                n.expression.walk(e);
            });
        },
        _validate: function() {
            c(this, "expression");
        }
    });
    var Fn = e("Unary", "operator expression", {
        $documentation: "Base class for unary expressions",
        $propdoc: {
            operator: "[string] the operator",
            expression: "[AST_Node] expression that this unary operator applies to"
        },
        _equals: function(e) {
            return this.operator == e.operator && this.expression.equals(e.expression);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                n.expression.walk(e);
            });
        },
        _validate: function() {
            if (this.TYPE == "Unary") throw new Error("should not instantiate AST_Unary");
            if (typeof this.operator != "string") throw new Error("operator must be string");
            c(this, "expression");
        }
    });
    var Pn = e("UnaryPrefix", null, {
        $documentation: "Unary prefix expression, i.e. `typeof i` or `++i`"
    }, Fn);
    var yr = e("UnaryPostfix", null, {
        $documentation: "Unary postfix expression, i.e. `i++`"
    }, Fn);
    var jn = e("Binary", "operator left right", {
        $documentation: "Binary expression, i.e. `a + b`",
        $propdoc: {
            left: "[AST_Node] left-hand side expression",
            operator: "[string] the operator",
            right: "[AST_Node] right-hand side expression"
        },
        _equals: function(e) {
            return this.operator == e.operator && this.left.equals(e.left) && this.right.equals(e.right);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                n.left.walk(e);
                n.right.walk(e);
            });
        },
        _validate: function() {
            if (!(this instanceof In)) c(this, "left");
            if (typeof this.operator != "string") throw new Error("operator must be string");
            c(this, "right");
        }
    });
    var Nn = e("Conditional", "condition consequent alternative", {
        $documentation: "Conditional expression using the ternary operator, i.e. `a ? b : c`",
        $propdoc: {
            condition: "[AST_Node]",
            consequent: "[AST_Node]",
            alternative: "[AST_Node]"
        },
        _equals: function(e) {
            return this.condition.equals(e.condition) && this.consequent.equals(e.consequent) && this.alternative.equals(e.alternative);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                n.condition.walk(e);
                n.consequent.walk(e);
                n.alternative.walk(e);
            });
        },
        _validate: function() {
            c(this, "condition");
            c(this, "consequent");
            c(this, "alternative");
        }
    });
    var In = e("Assign", null, {
        $documentation: "An assignment expression — `a = b + 5`",
        _validate: function() {
            if (this.operator.indexOf("=") < 0) throw new Error('operator must contain "="');
            if (this.left instanceof Yn) {
                if (this.operator != "=") throw new Error("invalid destructuring operator: " + this.operator);
                p(this.left, function(e) {
                    if (!(e instanceof $n || e instanceof Ln)) {
                        throw new Error("left must be assignable: " + e.TYPE);
                    }
                });
            } else if (!(this.left instanceof ei || this.left instanceof Kr || this.left instanceof $n && !this.left.optional || this.left instanceof Ln || this.left instanceof Qr)) {
                throw new Error("left must be assignable");
            }
        }
    }, jn);
    var wr = e("Await", "expression", {
        $documentation: "An await expression",
        $propdoc: {
            expression: "[AST_Node] expression with Promise to resolve on"
        },
        _equals: function(e) {
            return this.expression.equals(e.expression);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                n.expression.walk(e);
            });
        },
        _validate: function() {
            c(this, "expression");
        }
    });
    var xr = e("Yield", "expression nested", {
        $documentation: "A yield expression",
        $propdoc: {
            expression: "[AST_Node?] return value for iterator, or null if undefined",
            nested: "[boolean] whether to iterate over expression as generator"
        },
        _equals: function(e) {
            return !this.nested == !e.nested && f(this.expression, e.expression);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                if (n.expression) n.expression.walk(e);
            });
        },
        _validate: function() {
            if (this.expression != null) {
                c(this, "expression");
            } else if (this.nested) {
                throw new Error("yield* must contain expression");
            }
        }
    });
    var Hn = e("Array", "elements", {
        $documentation: "An array literal",
        $propdoc: {
            elements: "[AST_Node*] array of elements"
        },
        _equals: function(e) {
            return o(this.elements, e.elements);
        },
        walk: function(n) {
            var e = this;
            n.visit(e, function() {
                e.elements.forEach(function(e) {
                    e.walk(n);
                });
            });
        },
        _validate: function() {
            l(this, "elements", true, true);
        }
    });
    var Yn = e("Destructured", "rest", {
        $documentation: "Base class for destructured literal",
        $propdoc: {
            rest: "[(AST_Destructured|AST_SymbolDeclaration|AST_SymbolRef)?] rest parameter, or null if absent"
        },
        _validate: function() {
            if (this.TYPE == "Destructured") throw new Error("should not instantiate AST_Destructured");
        }
    });
    function p(e, n, t) {
        if (e instanceof Dn && t) return p(e.name, n);
        if (e instanceof Yn) {
            if (e.rest != null) p(e.rest, n);
            if (e instanceof kr) return e.elements.forEach(function(e) {
                if (!(e instanceof Zr)) p(e, n, true);
            });
            if (e instanceof Sr) return e.properties.forEach(function(e) {
                p(e.value, n, true);
            });
        }
        n(e);
    }
    var kr = e("DestructuredArray", "elements", {
        $documentation: "A destructured array literal",
        $propdoc: {
            elements: "[(AST_DefaultValue|AST_Destructured|AST_SymbolDeclaration|AST_SymbolRef)*] array of elements"
        },
        _equals: function(e) {
            return f(this.rest, e.rest) && o(this.elements, e.elements);
        },
        walk: function(n) {
            var e = this;
            n.visit(e, function() {
                e.elements.forEach(function(e) {
                    e.walk(n);
                });
                if (e.rest) e.rest.walk(n);
            });
        }
    }, Yn);
    var Er = e("DestructuredKeyVal", "key value", {
        $documentation: "A key: value destructured property",
        $propdoc: {
            key: "[string|AST_Node] property name.  For computed property this is an AST_Node.",
            value: "[AST_DefaultValue|AST_Destructured|AST_SymbolDeclaration|AST_SymbolRef] property value"
        },
        _equals: function(e) {
            return f(this.key, e.key) && this.value.equals(e.value);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                if (n.key instanceof bn) n.key.walk(e);
                n.value.walk(e);
            });
        },
        _validate: function() {
            if (typeof this.key != "string") {
                if (!(this.key instanceof bn)) throw new Error("key must be string or AST_Node");
                c(this, "key");
            }
            if (!(this.value instanceof bn)) throw new Error("value must be AST_Node");
        }
    });
    var Sr = e("DestructuredObject", "properties", {
        $documentation: "A destructured object literal",
        $propdoc: {
            properties: "[AST_DestructuredKeyVal*] array of properties"
        },
        _equals: function(e) {
            return f(this.rest, e.rest) && o(this.properties, e.properties);
        },
        walk: function(n) {
            var e = this;
            n.visit(e, function() {
                e.properties.forEach(function(e) {
                    e.walk(n);
                });
                if (e.rest) e.rest.walk(n);
            });
        },
        _validate: function() {
            this.properties.forEach(function(e) {
                if (!(e instanceof Er)) throw new Error("properties must be AST_DestructuredKeyVal[]");
            });
        }
    }, Yn);
    var Rn = e("Object", "properties", {
        $documentation: "An object literal",
        $propdoc: {
            properties: "[(AST_ObjectProperty|AST_Spread)*] array of properties"
        },
        _equals: function(e) {
            return o(this.properties, e.properties);
        },
        walk: function(n) {
            var e = this;
            n.visit(e, function() {
                e.properties.forEach(function(e) {
                    e.walk(n);
                });
            });
        },
        _validate: function() {
            this.properties.forEach(function(e) {
                if (!(e instanceof Tr || e instanceof Mn)) {
                    throw new Error("properties must contain AST_ObjectProperty and/or AST_Spread only");
                }
            });
        }
    });
    var Tr = e("ObjectProperty", "key value", {
        $documentation: "Base class for literal object properties",
        $propdoc: {
            key: "[string|AST_Node] property name.  For computed property this is an AST_Node.",
            value: "[AST_Node] property value.  For getters and setters this is an AST_Accessor."
        },
        _equals: function(e) {
            return f(this.key, e.key) && this.value.equals(e.value);
        },
        walk: function(e) {
            var n = this;
            e.visit(n, function() {
                if (n.key instanceof bn) n.key.walk(e);
                n.value.walk(e);
            });
        },
        _validate: function() {
            if (this.TYPE == "ObjectProperty") throw new Error("should not instantiate AST_ObjectProperty");
            if (typeof this.key != "string") {
                if (!(this.key instanceof bn)) throw new Error("key must be string or AST_Node");
                c(this, "key");
            }
            if (!(this.value instanceof bn)) throw new Error("value must be AST_Node");
        }
    });
    var Ar = e("ObjectKeyVal", null, {
        $documentation: "A key: value object property",
        _validate: function() {
            c(this, "value");
        }
    }, Tr);
    var Dr = e("ObjectMethod", null, {
        $documentation: "A key(){} object property",
        _validate: function() {
            if (!(this.value instanceof Tt)) throw new Error("value must be AST_LambdaExpression");
            if (At(this.value)) throw new Error("value cannot be AST_Arrow or AST_AsyncArrow");
            if (this.value.name != null) throw new Error("name of object method's lambda must be null");
        }
    }, Ar);
    var qr = e("ObjectSetter", null, {
        $documentation: "An object setter property",
        _validate: function() {
            if (!(this.value instanceof St)) throw new Error("value must be AST_Accessor");
        }
    }, Tr);
    var Or = e("ObjectGetter", null, {
        $documentation: "An object getter property",
        _validate: function() {
            if (!(this.value instanceof St)) throw new Error("value must be AST_Accessor");
        }
    }, Tr);
    var $r = e("Symbol", "scope name thedef", {
        $documentation: "Base class for all symbols",
        $propdoc: {
            name: "[string] name of this symbol",
            scope: "[AST_Scope/S] the current scope (not necessarily the definition scope)",
            thedef: "[SymbolDef/S] the definition of this symbol"
        },
        _equals: function(e) {
            return this.thedef ? this.thedef === e.thedef : this.name == e.name;
        },
        _validate: function() {
            if (this.TYPE == "Symbol") throw new Error("should not instantiate AST_Symbol");
            if (typeof this.name != "string") throw new Error("name must be string");
        }
    });
    var zr = e("SymbolDeclaration", "init", {
        $documentation: "A declaration symbol (symbol in var, function name or argument, symbol in catch)"
    }, $r);
    var Cr = e("SymbolConst", null, {
        $documentation: "Symbol defining a constant"
    }, zr);
    var Mr = e("SymbolImport", "key", {
        $documentation: "Symbol defined by an `import` statement",
        $propdoc: {
            key: "[AST_String] the original `export` name"
        },
        _equals: function(e) {
            return this.name == e.name && this.key.equals(e.key);
        },
        _validate: function() {
            if (!(this.key instanceof Vn)) throw new Error("key must be AST_String");
        }
    }, Cr);
    var Fr = e("SymbolLet", null, {
        $documentation: "Symbol defining a lexical-scoped variable"
    }, zr);
    var Pr = e("SymbolVar", null, {
        $documentation: "Symbol defining a variable"
    }, zr);
    var Bn = e("SymbolFunarg", "unused", {
        $documentation: "Symbol naming a function argument"
    }, Pr);
    var jr = e("SymbolDefun", null, {
        $documentation: "Symbol defining a function"
    }, zr);
    var Nr = e("SymbolLambda", null, {
        $documentation: "Symbol naming a function expression"
    }, zr);
    var Ee = e("SymbolDefClass", null, {
        $documentation: "Symbol defining a class"
    }, Cr);
    var Ir = e("SymbolClass", null, {
        $documentation: "Symbol naming a class expression"
    }, Cr);
    var Hr = e("SymbolCatch", null, {
        $documentation: "Symbol naming the exception in catch"
    }, zr);
    var Se = e("Label", "references", {
        $documentation: "Symbol naming a label (declaration)",
        $propdoc: {
            references: "[AST_LoopControl*] a list of nodes referring to this label"
        },
        initialize: function() {
            this.references = [];
            this.thedef = this;
        }
    }, $r);
    var Ln = e("SymbolRef", "fixed in_arg redef", {
        $documentation: "Reference to some symbol (not definition/declaration)"
    }, $r);
    var Yr = e("SymbolExport", "alias", {
        $documentation: "Reference in an `export` statement",
        $propdoc: {
            alias: "[AST_String] the `export` alias"
        },
        _equals: function(e) {
            return this.name == e.name && this.alias.equals(e.alias);
        },
        _validate: function() {
            if (!(this.alias instanceof Vn)) throw new Error("alias must be AST_String");
        }
    }, Ln);
    var Te = e("LabelRef", null, {
        $documentation: "Reference to a label symbol"
    }, $r);
    var Rr = e("ObjectIdentity", null, {
        $documentation: "Base class for `super` & `this`",
        _equals: vn,
        _validate: function() {
            if (this.TYPE == "ObjectIdentity") throw new Error("should not instantiate AST_ObjectIdentity");
        }
    }, $r);
    var Br = e("Super", null, {
        $documentation: "The `super` symbol",
        _validate: function() {
            if (this.name !== "super") throw new Error('name must be "super"');
        }
    }, Rr);
    var Lr = e("This", null, {
        $documentation: "The `this` symbol",
        _validate: function() {
            if (this.TYPE == "This" && this.name !== "this") throw new Error('name must be "this"');
        }
    }, Rr);
    var Ur = e("NewTarget", null, {
        $documentation: "The `new.target` symbol",
        initialize: function() {
            this.name = "new.target";
        },
        _validate: function() {
            if (this.name !== "new.target") throw new Error('name must be "new.target": ' + this.name);
        }
    }, Lr);
    var Vr = e("Template", "expressions strings tag", {
        $documentation: "A template literal, i.e. tag`str1${expr1}...strN${exprN}strN+1`",
        $propdoc: {
            expressions: "[AST_Node*] the placeholder expressions",
            strings: "[string*] the raw text segments",
            tag: "[AST_Node?] tag function, or null if absent"
        },
        _equals: function(e) {
            return f(this.tag, e.tag) && s(this.strings, e.strings) && o(this.expressions, e.expressions);
        },
        walk: function(n) {
            var e = this;
            n.visit(e, function() {
                if (e.tag) e.tag.walk(n);
                e.expressions.forEach(function(e) {
                    e.walk(n);
                });
            });
        },
        _validate: function() {
            if (this.expressions.length + 1 != this.strings.length) {
                throw new Error("malformed template with " + this.expressions.length + " placeholder(s) but " + this.strings.length + " text segment(s)");
            }
            l(this, "expressions");
            this.strings.forEach(function(e) {
                if (typeof e != "string") throw new Error("strings must contain string");
            });
            if (this.tag != null) c(this, "tag");
        }
    });
    var Un = e("Constant", null, {
        $documentation: "Base class for all constants",
        _equals: function(e) {
            return this.value === e.value;
        },
        _validate: function() {
            if (this.TYPE == "Constant") throw new Error("should not instantiate AST_Constant");
        }
    });
    var Vn = e("String", "quote value", {
        $documentation: "A string literal",
        $propdoc: {
            quote: "[string?] the original quote character",
            value: "[string] the contents of this string"
        },
        _validate: function() {
            if (this.quote != null) {
                if (typeof this.quote != "string") throw new Error("quote must be string");
                if (!/^["']$/.test(this.quote)) throw new Error("invalid quote: " + this.quote);
            }
            if (typeof this.value != "string") throw new Error("value must be string");
        }
    }, Un);
    var Wn = e("Number", "value", {
        $documentation: "A number literal",
        $propdoc: {
            value: "[number] the numeric value"
        },
        _validate: function() {
            if (typeof this.value != "number") throw new Error("value must be number");
            if (!isFinite(this.value)) throw new Error("value must be finite");
            if (this.value < 0) throw new Error("value cannot be negative");
        }
    }, Un);
    var Wr = e("BigInt", "value", {
        $documentation: "A BigInt literal",
        $propdoc: {
            value: "[string] the numeric representation"
        },
        _validate: function() {
            if (typeof this.value != "string") throw new Error("value must be string");
            if (this.value[0] == "-") throw new Error("value cannot be negative");
        }
    }, Un);
    var Gr = e("RegExp", "value", {
        $documentation: "A regexp literal",
        $propdoc: {
            value: "[RegExp] the actual regexp"
        },
        _equals: function(e) {
            return "" + this.value == "" + e.value;
        },
        _validate: function() {
            if (!(this.value instanceof RegExp)) throw new Error("value must be RegExp");
        }
    }, Un);
    var Jr = e("Atom", null, {
        $documentation: "Base class for atoms",
        _equals: vn,
        _validate: function() {
            if (this.TYPE == "Atom") throw new Error("should not instantiate AST_Atom");
        }
    }, Un);
    var Xr = e("Null", null, {
        $documentation: "The `null` atom",
        value: null
    }, Jr);
    var Kr = e("NaN", null, {
        $documentation: "The impossible value",
        value: 0 / 0
    }, Jr);
    var Qr = e("Undefined", null, {
        $documentation: "The `undefined` value",
        value: function() {}()
    }, Jr);
    var Zr = e("Hole", null, {
        $documentation: "A hole in an array",
        value: function() {}()
    }, Jr);
    var ei = e("Infinity", null, {
        $documentation: "The `Infinity` value",
        value: 1 / 0
    }, Jr);
    var ni = e("Boolean", null, {
        $documentation: "Base class for booleans",
        _validate: function() {
            if (this.TYPE == "Boolean") throw new Error("should not instantiate AST_Boolean");
        }
    }, Jr);
    var ti = e("False", null, {
        $documentation: "The `false` atom",
        value: false
    }, ni);
    var ri = e("True", null, {
        $documentation: "The `true` atom",
        value: true
    }, ni);
    function Gn(e) {
        this.callback = e;
        this.directives = Object.create(null);
        this.stack = [];
    }
    Gn.prototype = {
        visit: function(e, n) {
            this.push(e);
            var t = this.callback(e, n || Kn);
            if (!t && n) n();
            this.pop();
        },
        parent: function(e) {
            return this.stack[this.stack.length - 2 - (e || 0)];
        },
        push: function(e) {
            var n;
            if (e instanceof Rt) {
                this.directives = Object.create(this.directives);
                n = "use strict";
            } else if (e instanceof ft) {
                n = e.value;
            } else if (e instanceof En) {
                this.directives = Object.create(this.directives);
            }
            if (n && !this.directives[n]) this.directives[n] = e;
            this.stack.push(e);
        },
        pop: function() {
            var e = this.stack.pop();
            if (e instanceof Rt || e instanceof En) {
                this.directives = Object.getPrototypeOf(this.directives);
            }
        },
        self: function() {
            return this.stack[this.stack.length - 1];
        },
        find_parent: function(e) {
            var n = this.stack;
            for (var t = n.length - 1; --t >= 0; ) {
                var r = n[t];
                if (r instanceof e) return r;
            }
        },
        has_directive: function(e) {
            var n = this.directives[e];
            if (n) return n;
            var t = this.stack[this.stack.length - 1];
            if (t instanceof kn) {
                for (var r = 0; r < t.body.length; ++r) {
                    var i = t.body[r];
                    if (!(i instanceof ft)) break;
                    if (i.value == e) return i;
                }
            }
        },
        loopcontrol_target: function(e) {
            var n = this.stack;
            if (e.label) for (var t = n.length; --t >= 0; ) {
                var r = n[t];
                if (r instanceof dt && r.label.name == e.label.name) return r.body;
            } else for (var t = n.length; --t >= 0; ) {
                var r = n[t];
                if (r instanceof ht || e instanceof nr && r instanceof rr) return r;
            }
        },
        in_boolean_context: function() {
            for (var e = true, n = 0, t, r = this.self(); t = this.parent(n++); r = t) {
                if (t instanceof jn) switch (t.operator) {
                  case "&&":
                  case "||":
                    if (t.left === r) e = false;
                    continue;

                  default:
                    return false;
                }
                if (t instanceof Nn) {
                    if (t.condition === r) return true;
                    continue;
                }
                if (t instanceof vt) return t.condition === r;
                if (t instanceof gt) return t.condition === r;
                if (t instanceof Tn) return t.condition === r;
                if (t instanceof Sn) {
                    if (t.in_bool) return true;
                    while (t = this.parent(n++)) {
                        if (t instanceof En) {
                            if (t.name) return false;
                            t = this.parent(n++);
                            if (t.TYPE != "Call") return false;
                            break;
                        }
                    }
                }
                if (t instanceof On) {
                    if (t.tail_node() === r) continue;
                    return e ? "d" : true;
                }
                if (t instanceof wn) return e ? "d" : true;
                if (t instanceof Pn) return t.operator == "!";
                return false;
            }
        }
    };
    /***********************************************************************

  A JavaScript tokenizer / parser / beautifier / compressor.
  https://github.com/mishoo/UglifyJS

  -------------------------------- (C) ---------------------------------

                           Author: Mihai Bazon
                         <mihai.bazon@gmail.com>
                       http://mihai.bazon.net/blog

  Distributed under the BSD license:

    Copyright 2012 (c) Mihai Bazon <mihai.bazon@gmail.com>

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

        * Redistributions of source code must retain the above
          copyright notice, this list of conditions and the following
          disclaimer.

        * Redistributions in binary form must reproduce the above
          copyright notice, this list of conditions and the following
          disclaimer in the documentation and/or other materials
          provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER “AS IS” AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE
    LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
    OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
    TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
    THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
    SUCH DAMAGE.

 ***********************************************************************/
    "use strict";
    function ii(e, n) {
        Gn.call(this);
        this.before = e;
        this.after = n;
    }
    ii.prototype = new Gn();
    (function(e) {
        function t(e, n) {
            return et(e, function(e) {
                return e.transform(n, true);
            });
        }
        e(bn, Kn);
        e(dt, function(e, n) {
            e.label = e.label.transform(n);
            e.body = e.body.transform(n);
        });
        e(wn, function(e, n) {
            e.body = e.body.transform(n);
        });
        e(pt, function(e, n) {
            e.body = t(e.body, n);
        });
        e(mt, function(e, n) {
            e.body = e.body.transform(n);
            e.condition = e.condition.transform(n);
        });
        e(_t, function(e, n) {
            e.condition = e.condition.transform(n);
            e.body = e.body.transform(n);
        });
        e(gt, function(e, n) {
            if (e.init) e.init = e.init.transform(n);
            if (e.condition) e.condition = e.condition.transform(n);
            if (e.step) e.step = e.step.transform(n);
            e.body = e.body.transform(n);
        });
        e(bt, function(e, n) {
            e.init = e.init.transform(n);
            e.object = e.object.transform(n);
            e.body = e.body.transform(n);
        });
        e(xt, function(e, n) {
            e.expression = e.expression.transform(n);
            e.body = e.body.transform(n);
        });
        e(Qt, function(e, n) {
            if (e.value) e.value = e.value.transform(n);
        });
        e(er, function(e, n) {
            if (e.label) e.label = e.label.transform(n);
        });
        e(Tn, function(e, n) {
            e.condition = e.condition.transform(n);
            e.body = e.body.transform(n);
            if (e.alternative) e.alternative = e.alternative.transform(n);
        });
        e(rr, function(e, n) {
            e.expression = e.expression.transform(n);
            e.body = t(e.body, n);
        });
        e(or, function(e, n) {
            e.expression = e.expression.transform(n);
            e.body = t(e.body, n);
        });
        e(sr, function(e, n) {
            e.body = t(e.body, n);
            if (e.bcatch) e.bcatch = e.bcatch.transform(n);
            if (e.bfinally) e.bfinally = e.bfinally.transform(n);
        });
        e(fr, function(e, n) {
            if (e.argname) e.argname = e.argname.transform(n);
            e.body = t(e.body, n);
        });
        e(cr, function(e, n) {
            e.definitions = t(e.definitions, n);
        });
        e(An, function(e, n) {
            e.name = e.name.transform(n);
            if (e.value) e.value = e.value.transform(n);
        });
        e(Dn, function(e, n) {
            e.name = e.name.transform(n);
            e.value = e.value.transform(n);
        });
        e(En, function(e, n) {
            if (e.name) e.name = e.name.transform(n);
            e.argnames = t(e.argnames, n);
            if (e.rest) e.rest = e.rest.transform(n);
            e.body = t(e.body, n);
        });
        function n(e, n) {
            e.argnames = t(e.argnames, n);
            if (e.rest) e.rest = e.rest.transform(n);
            if (e.value) {
                e.value = e.value.transform(n);
            } else {
                e.body = t(e.body, n);
            }
        }
        e($t, n);
        e(zt, n);
        e(Rt, function(e, n) {
            if (e.name) e.name = e.name.transform(n);
            if (e.extends) e.extends = e.extends.transform(n);
            e.properties = t(e.properties, n);
        });
        e(Ut, function(e, n) {
            if (e.key instanceof bn) e.key = e.key.transform(n);
            if (e.value) e.value = e.value.transform(n);
        });
        e(qn, function(e, n) {
            e.expression = e.expression.transform(n);
            e.args = t(e.args, n);
        });
        e(On, function(e, n) {
            e.expressions = t(e.expressions, n);
        });
        e(wr, function(e, n) {
            e.expression = e.expression.transform(n);
        });
        e(xr, function(e, n) {
            if (e.expression) e.expression = e.expression.transform(n);
        });
        e(zn, function(e, n) {
            e.expression = e.expression.transform(n);
        });
        e(Cn, function(e, n) {
            e.expression = e.expression.transform(n);
            e.property = e.property.transform(n);
        });
        e(Mn, function(e, n) {
            e.expression = e.expression.transform(n);
        });
        e(Fn, function(e, n) {
            e.expression = e.expression.transform(n);
        });
        e(jn, function(e, n) {
            e.left = e.left.transform(n);
            e.right = e.right.transform(n);
        });
        e(Nn, function(e, n) {
            e.condition = e.condition.transform(n);
            e.consequent = e.consequent.transform(n);
            e.alternative = e.alternative.transform(n);
        });
        e(Hn, function(e, n) {
            e.elements = t(e.elements, n);
        });
        e(kr, function(e, n) {
            e.elements = t(e.elements, n);
            if (e.rest) e.rest = e.rest.transform(n);
        });
        e(Er, function(e, n) {
            if (e.key instanceof bn) e.key = e.key.transform(n);
            e.value = e.value.transform(n);
        });
        e(Sr, function(e, n) {
            e.properties = t(e.properties, n);
            if (e.rest) e.rest = e.rest.transform(n);
        });
        e(Rn, function(e, n) {
            e.properties = t(e.properties, n);
        });
        e(Tr, function(e, n) {
            if (e.key instanceof bn) e.key = e.key.transform(n);
            e.value = e.value.transform(n);
        });
        e(hr, function(e, n) {
            e.body = e.body.transform(n);
        });
        e(vr, function(e, n) {
            e.body = e.body.transform(n);
        });
        e(mr, function(e, n) {
            e.properties = t(e.properties, n);
        });
        e(_r, function(e, n) {
            if (e.all) e.all = e.all.transform(n);
            if (e.default) e.default = e.default.transform(n);
            if (e.properties) e.properties = t(e.properties, n);
        });
        e(Vr, function(e, n) {
            if (e.tag) e.tag = e.tag.transform(n);
            e.expressions = t(e.expressions, n);
        });
    })(function(e, i) {
        e.DEFMETHOD("transform", function(e, n) {
            var t, r;
            e.push(this);
            if (e.before) t = e.before(this, i, n);
            if (typeof t === "undefined") {
                t = this;
                i(t, e);
                if (e.after) {
                    r = e.after(t, n);
                    if (typeof r !== "undefined") t = r;
                }
            }
            e.pop();
            return t;
        });
    });
    /***********************************************************************

  A JavaScript tokenizer / parser / beautifier / compressor.
  https://github.com/mishoo/UglifyJS

  -------------------------------- (C) ---------------------------------

                           Author: Mihai Bazon
                         <mihai.bazon@gmail.com>
                       http://mihai.bazon.net/blog

  Distributed under the BSD license:

    Copyright 2012 (c) Mihai Bazon <mihai.bazon@gmail.com>
    Parser based on parse-js (http://marijn.haverbeke.nl/parse-js/).

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

        * Redistributions of source code must retain the above
          copyright notice, this list of conditions and the following
          disclaimer.

        * Redistributions in binary form must reproduce the above
          copyright notice, this list of conditions and the following
          disclaimer in the documentation and/or other materials
          provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER “AS IS” AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE
    LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
    OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
    TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
    THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
    SUCH DAMAGE.

 ***********************************************************************/
    "use strict";
    var Ae = "break case catch class const continue debugger default delete do else extends finally for function if in instanceof new return switch throw try typeof var void while with";
    var C = "false null true";
    var I = [ "abstract async await boolean byte char double enum export final float goto implements import int interface let long native package private protected public short static super synchronized this throws transient volatile yield", C, Ae ].join(" ");
    var M = "return new delete throw else case";
    Ae = mn(Ae);
    I = mn(I);
    M = mn(M);
    C = mn(C);
    var d = /^0b([01]+)$/i;
    var h = /^0x([0-9a-f]+)$/i;
    var v = /^0o?([0-7]+)$/i;
    var F = mn([ "in", "instanceof", "typeof", "new", "void", "delete", "++", "--", "+", "-", "!", "~", "&", "|", "^", "*", "/", "%", "**", ">>", "<<", ">>>", "<", ">", "<=", ">=", "==", "===", "!=", "!==", "?", "=", "+=", "-=", "/=", "*=", "%=", "**=", ">>=", "<<=", ">>>=", "&=", "|=", "^=", "&&", "||", "??", "&&=", "||=", "??=" ]);
    var P = "\n\r\u2028\u2029";
    var j = "+-*&%=<>!?|~^";
    var m = "[{(";
    var _ = ",;:";
    var g = ")}]";
    var De = _ + g;
    var H = m + _;
    var Y = H + "`" + g;
    var R = P + "  \t\f\v​             　\ufeff";
    var B = mn(n("./'\"#" + j + Y + R));
    P = mn(n(P));
    j = mn(n(j));
    De = mn(n(De));
    H = mn(n(H));
    Y = mn(n(Y));
    R = mn(n(R));
    function re(e) {
        return e >= 55296 && e <= 56319;
    }
    function ie(e) {
        return e >= 56320 && e <= 57343;
    }
    function L(e) {
        return e >= 48 && e <= 57;
    }
    function ae(e) {
        return !B[e];
    }
    function ai(e) {
        return /^[a-z_$][a-z0-9_$]*$/i.test(e);
    }
    function oi(e) {
        switch (e[0]) {
          case "b":
            return "\b";

          case "f":
            return "\f";

          case "n":
            return "\n";

          case "r":
            return "\r";

          case "t":
            return "\t";

          case "u":
            var n;
            if (e[1] == "{" && e.slice(-1) == "}") {
                n = e.slice(2, -1);
            } else if (e.length == 5) {
                n = e.slice(1);
            } else {
                return;
            }
            var t = parseInt(n, 16);
            if (t < 0 || isNaN(t)) return;
            if (t < 65536) return String.fromCharCode(t);
            if (t > 1114111) return;
            return String.fromCharCode((t >> 10) + 55232) + String.fromCharCode((t & 1023) + 56320);

          case "v":
            return "\v";

          case "x":
            if (e.length != 3) return;
            var t = parseInt(e.slice(1), 16);
            if (t < 0 || isNaN(t)) return;
            return String.fromCharCode(t);

          case "\r":
          case "\n":
            return "";

          default:
            if (e == "0") return "\0";
            if (e[0] >= "0" && e[0] <= "9") return;
            return e;
        }
    }
    function U(e) {
        var n;
        if (n = d.exec(e)) return parseInt(n[1], 2);
        if (n = h.exec(e)) return parseInt(n[1], 16);
        if (n = v.exec(e)) return parseInt(n[1], 8);
        var t = parseFloat(e);
        if (t == e) return t;
    }
    function si(e, n, t, r, i) {
        this.message = e;
        this.filename = n;
        this.line = t;
        this.col = r;
        this.pos = i;
    }
    si.prototype = Object.create(Error.prototype);
    si.prototype.constructor = si;
    si.prototype.name = "SyntaxError";
    t(si);
    function qe(e, n, t, r, i) {
        throw new si(e, n, t, r, i);
    }
    function Oe(e, n, t) {
        return e.type == n && (t == null || e.value == t);
    }
    var V = {};
    function $e(i, a, o, s) {
        var f = {
            text: i,
            filename: a,
            pos: 0,
            tokpos: 0,
            line: 1,
            tokline: 0,
            col: 0,
            tokcol: 0,
            newline_before: false,
            regex_allowed: false,
            comments_before: [],
            directives: Object.create(null),
            read_template: n("Unterminated template literal", function(e) {
                var n = "";
                for (;;) {
                    var t = r();
                    switch (t) {
                      case "\\":
                        t += r();
                        break;

                      case "`":
                        e.push(n);
                        return;

                      case "$":
                        if (c() == "{") {
                            l();
                            e.push(n);
                            f.regex_allowed = true;
                            return true;
                        }
                    }
                    n += t;
                }
                function r() {
                    var e = l(true, true);
                    return e == "\r" ? "\n" : e;
                }
            })
        };
        var u = false;
        function c() {
            return f.text.charAt(f.pos);
        }
        function l(e, n) {
            var t = f.text.charAt(f.pos++);
            if (e && !t) throw V;
            if (P[t]) {
                f.col = 0;
                f.line++;
                if (!n) f.newline_before = true;
                if (t == "\r" && c() == "\n") {
                    f.pos++;
                    t = "\n";
                }
            } else {
                f.col++;
            }
            return t;
        }
        function p(e) {
            while (e-- > 0) l();
        }
        function d(e) {
            return f.text.substr(f.pos, e.length) == e;
        }
        function h() {
            var e = f.text;
            for (var n = f.pos; n < f.text.length; ++n) {
                if (P[e[n]]) return n;
            }
            return -1;
        }
        function r(e, n) {
            var t = f.text.indexOf(e, f.pos);
            if (n && t == -1) throw V;
            return t;
        }
        function v() {
            f.tokline = f.line;
            f.tokcol = f.col;
            f.tokpos = f.pos;
        }
        function m(e, n, t) {
            f.regex_allowed = e == "operator" && !fi[n] || e == "keyword" && M[n] || e == "punc" && H[n];
            if (e == "punc" && n == ".") u = true; else if (!t) u = false;
            var r = {
                type: e,
                value: n,
                line: f.tokline,
                col: f.tokcol,
                pos: f.tokpos,
                endline: f.line,
                endcol: f.col,
                endpos: f.pos,
                nlb: f.newline_before,
                file: a
            };
            if (/^(?:num|string|regexp)$/i.test(e)) {
                r.raw = i.substring(r.pos, r.endpos);
            }
            if (!t) {
                r.comments_before = f.comments_before;
                r.comments_after = f.comments_before = [];
            }
            f.newline_before = false;
            return new te(r);
        }
        function _() {
            while (R[c()]) l();
        }
        function g(e) {
            var n = "", t;
            while ((t = c()) && e(t, n)) n += l();
            return n;
        }
        function b(e) {
            qe(e, a, f.tokline, f.tokcol, f.tokpos);
        }
        function y(e) {
            return /^0[0-7_]+$/.test(e);
        }
        function w(e) {
            var t = false, r = false, i = false, a = e == ".";
            var n = g(function(e, n) {
                switch (e) {
                  case "x":
                  case "X":
                    return i ? false : i = true;

                  case "e":
                  case "E":
                    return i ? true : t ? false : t = r = true;

                  case "+":
                  case "-":
                    return r;

                  case r = false, ".":
                    return a || t || i || y(n) ? false : a = true;
                }
                return /[_0-9a-dfo]/i.test(e);
            });
            if (e) n = e + n;
            if (y(n)) {
                if (z.has_directive("use strict")) b("Legacy octal literals are not allowed in strict mode");
            } else {
                n = n.replace(i ? /([1-9a-f]|.0)_(?=[0-9a-f])/gi : /([1-9]|.0)_(?=[0-9])/gi, "$1");
            }
            var o = U(n);
            if (isNaN(o)) b("Invalid syntax: " + n);
            if (a || t || c() != "n") return m("num", o);
            return m("bigint", n.toLowerCase() + l());
        }
        function x(e) {
            var n = l(true, e);
            if (n >= "0" && n <= "7") return k(n);
            if (n == "u") {
                var t = l(true, e);
                n += t;
                if (t != "{") {
                    n += l(true, e) + l(true, e) + l(true, e);
                } else do {
                    t = l(true, e);
                    n += t;
                } while (t != "}");
            } else if (n == "x") {
                n += l(true, e) + l(true, e);
            }
            var r = oi(n);
            if (typeof r != "string") b("Invalid escape sequence: \\" + n);
            return r;
        }
        function k(e) {
            var n = c();
            if (n >= "0" && n <= "7") {
                e += l(true);
                if (e[0] <= "3" && (n = c()) >= "0" && n <= "7") e += l(true);
            }
            if (e === "0") return "\0";
            if (e.length > 0 && z.has_directive("use strict")) b("Legacy octal escape sequences are not allowed in strict mode");
            return String.fromCharCode(parseInt(e, 8));
        }
        var E = n("Unterminated string constant", function(e) {
            var n = l(), t = "";
            for (;;) {
                var r = l(true, true);
                if (r == "\\") r = x(true); else if (P[r]) b("Unterminated string constant"); else if (r == n) break;
                t += r;
            }
            var i = m("string", t);
            i.quote = e;
            return i;
        });
        function S(e) {
            var n = f.regex_allowed;
            var t = h(), r;
            if (t == -1) {
                r = f.text.substr(f.pos);
                f.pos = f.text.length;
            } else {
                r = f.text.substring(f.pos, t);
                f.pos = t;
            }
            f.col = f.tokcol + (f.pos - f.tokpos);
            f.comments_before.push(m(e, r, true));
            f.regex_allowed = n;
            return z;
        }
        var e = n("Unterminated multiline comment", function() {
            var e = f.regex_allowed;
            var n = r("*/", true);
            var t = f.text.substring(f.pos, n).replace(/\r\n|\r|\u2028|\u2029/g, "\n");
            p(t.length + 2);
            f.comments_before.push(m("comment2", t, true));
            f.regex_allowed = e;
            return z;
        });
        function T() {
            var e = false, n, t = false, r = c() == "#" ? l() : "";
            while (n = c()) {
                if (!e) {
                    if (n == "\\") t = e = true, l(); else if (ae(n)) r += l(); else break;
                } else {
                    if (n != "u") b("Expecting UnicodeEscapeSequence -- uXXXX");
                    n = x();
                    if (!ae(n)) b("Unicode char: " + n.charCodeAt(0) + " is not valid in identifier");
                    r += n;
                    e = false;
                }
            }
            if (Ae[r] && t) {
                var i = r.charCodeAt(0).toString(16).toUpperCase();
                r = "\\u" + "0000".substr(i.length) + i + r.slice(1);
            }
            return r;
        }
        var A = n("Unterminated regular expression", function(e) {
            var n = false, t, r = false;
            while (t = l(true)) if (P[t]) {
                b("Unexpected line terminator");
            } else if (n) {
                e += "\\" + t;
                n = false;
            } else if (t == "[") {
                r = true;
                e += t;
            } else if (t == "]" && r) {
                r = false;
                e += t;
            } else if (t == "/" && !r) {
                break;
            } else if (t == "\\") {
                n = true;
            } else {
                e += t;
            }
            var i = T();
            try {
                var a = new RegExp(e, i);
                a.raw_source = e;
                return m("regexp", a);
            } catch (e) {
                b(e.message);
            }
        });
        function D(e) {
            function t(e) {
                if (!c()) return e;
                var n = e + c();
                if (F[n]) {
                    l();
                    return t(n);
                } else {
                    return e;
                }
            }
            return m("operator", t(e || l()));
        }
        function q() {
            l();
            switch (c()) {
              case "/":
                l();
                return S("comment1");

              case "*":
                l();
                return e();
            }
            return f.regex_allowed ? A("") : D("/");
        }
        function O() {
            l();
            if (d("..")) return m("operator", "." + l() + l());
            return L(c().charCodeAt(0)) ? w(".") : m("punc", ".");
        }
        function $() {
            var e = T();
            if (u) return m("name", e);
            return C[e] ? m("atom", e) : !Ae[e] ? m("name", e) : F[e] ? m("operator", e) : m("keyword", e);
        }
        function n(n, t) {
            return function(e) {
                try {
                    return t(e);
                } catch (e) {
                    if (e === V) b(n); else throw e;
                }
            };
        }
        function z(e) {
            if (e != null) return A(e);
            if (s && f.pos == 0 && d("#!")) {
                v();
                p(2);
                S("comment5");
            }
            for (;;) {
                _();
                v();
                if (o) {
                    if (d("\x3c!--")) {
                        p(4);
                        S("comment3");
                        continue;
                    }
                    if (d("--\x3e") && f.newline_before) {
                        p(3);
                        S("comment4");
                        continue;
                    }
                }
                var n = c();
                if (!n) return m("eof");
                var t = n.charCodeAt(0);
                switch (t) {
                  case 34:
                  case 39:
                    return E(n);

                  case 46:
                    return O();

                  case 47:
                    var r = q();
                    if (r === z) continue;
                    return r;
                }
                if (L(t)) return w();
                if (Y[n]) return m("punc", l());
                if (d("=>")) return m("punc", l() + l());
                if (j[n]) return D();
                if (t == 35 || t == 92 || !B[n]) return $();
                break;
            }
            b("Unexpected character '" + n + "'");
        }
        z.context = function(e) {
            if (e) f = e;
            return f;
        };
        z.add_directive = function(e) {
            f.directives[e] = true;
        };
        z.push_directives_stack = function() {
            f.directives = Object.create(f.directives);
        };
        z.pop_directives_stack = function() {
            f.directives = Object.getPrototypeOf(f.directives);
        };
        z.has_directive = function(e) {
            return !!f.directives[e];
        };
        return z;
    }
    var ze = mn("typeof void delete -- ++ ! ~ - +");
    var fi = mn("-- ++");
    var Ce = mn("= += -= /= *= %= **= >>= <<= >>>= &= |= ^= &&= ||= ??=");
    var ui = function(e, n) {
        for (var t = 0; t < e.length; ) {
            var r = e[t++];
            for (var i = 0; i < r.length; i++) {
                n[r[i]] = t;
            }
        }
        return n;
    }([ [ "??" ], [ "||" ], [ "&&" ], [ "|" ], [ "^" ], [ "&" ], [ "==", "===", "!=", "!==" ], [ "<", ">", "<=", ">=", "in", "instanceof" ], [ ">>", "<<", ">>>" ], [ "+", "-" ], [ "*", "/", "%" ], [ "**" ] ], {});
    var Me = mn("atom bigint num regexp string");
    function ci(t, l) {
        l = we(l, {
            bare_returns: false,
            expression: false,
            filename: null,
            html5_comments: true,
            module: false,
            shebang: true,
            strict: false,
            toplevel: null
        }, true);
        var _ = {
            input: typeof t == "string" ? $e(t, l.filename, l.html5_comments, l.shebang) : t,
            in_async: false,
            in_directives: true,
            in_funarg: -1,
            in_function: 0,
            in_generator: false,
            in_loop: 0,
            labels: [],
            peeked: null,
            prev: null,
            token: null
        };
        _.token = b();
        function g(e, n) {
            return Oe(_.token, e, n);
        }
        function p() {
            return _.peeked || (_.peeked = _.input());
        }
        function b() {
            _.prev = _.token;
            if (_.peeked) {
                _.token = _.peeked;
                _.peeked = null;
            } else {
                _.token = _.input();
            }
            _.in_directives = _.in_directives && (_.token.type == "string" || g("punc", ";"));
            return _.token;
        }
        function y() {
            return _.prev;
        }
        function s(e, n, t, r) {
            var i = _.input.context();
            qe(e, i.filename, n != null ? n : i.tokline, t != null ? t : i.tokcol, r != null ? r : i.tokpos);
        }
        function o(e, n) {
            s(n, e.line, e.col);
        }
        function r(e, n) {
            return e + (n === undefined ? "" : " «" + n + "»");
        }
        function w(e) {
            if (e == null) e = _.token;
            o(e, "Unexpected token: " + r(e.type, e.value));
        }
        function f(e, n) {
            if (g(e, n)) return b();
            o(_.token, "Unexpected token: " + r(_.token.type, _.token.value) + ", expected: " + r(e, n));
        }
        function x(e) {
            return f("punc", e);
        }
        function u(e) {
            return e.nlb || !_n(e.comments_before, function(e) {
                return !e.nlb;
            });
        }
        function c() {
            return !l.strict && (g("eof") || g("punc", "}") || u(_.token));
        }
        function k(e) {
            if (g("punc", ";")) b(); else if (!e && !c()) x(";");
        }
        function d() {
            x("(");
            var e = N();
            x(")");
            return e;
        }
        function e(r) {
            return function() {
                var e = _.token;
                var n = r.apply(null, arguments);
                var t = y();
                n.start = e;
                n.end = t;
                return n;
            };
        }
        function E() {
            if (g("operator", "/") || g("operator", "/=")) {
                _.peeked = null;
                _.token = _.input(_.token.value.substr(1));
            }
        }
        var h = e(function(e) {
            E();
            switch (_.token.type) {
              case "string":
                var n = _.in_directives;
                var t = N();
                if (n) {
                    if (t instanceof Vn) {
                        var r = t.start.raw.slice(1, -1);
                        _.input.add_directive(r);
                        t.value = r;
                    } else {
                        _.in_directives = n = false;
                    }
                }
                k();
                return n ? new ft(t) : new wn({
                    body: t
                });

              case "num":
              case "bigint":
              case "regexp":
              case "operator":
              case "atom":
                return v();

              case "name":
                switch (_.token.value) {
                  case "async":
                    if (Oe(p(), "keyword", "function")) {
                        b();
                        b();
                        if (!g("operator", "*")) return A(Nt);
                        b();
                        return A(It);
                    }
                    break;

                  case "await":
                    if (_.in_async) return v();
                    break;

                  case "export":
                    if (!e && l.module !== "") w();
                    b();
                    return W();

                  case "import":
                    var i = p();
                    if (i.type == "punc" && /^[(.]$/.test(i.value)) break;
                    if (!e && l.module !== "") w();
                    b();
                    return X();

                  case "let":
                    if (ee()) {
                        b();
                        var a = te();
                        k();
                        return a;
                    }
                    break;

                  case "yield":
                    if (_.in_generator) return v();
                    break;
                }
                return Oe(p(), "punc", ":") ? H() : v();

              case "punc":
                switch (_.token.value) {
                  case "{":
                    return new xn({
                        start: _.token,
                        body: q(),
                        end: y()
                    });

                  case "[":
                  case "(":
                  case "`":
                    return v();

                  case ";":
                    _.in_directives = false;
                    b();
                    return new yn();

                  default:
                    w();
                }

              case "keyword":
                switch (_.token.value) {
                  case "break":
                    b();
                    return Y(nr);

                  case "class":
                    b();
                    return m(Bt);

                  case "const":
                    b();
                    var a = ne();
                    k();
                    return a;

                  case "continue":
                    b();
                    return Y(tr);

                  case "debugger":
                    b();
                    k();
                    return new st();

                  case "do":
                    b();
                    var t = I(h);
                    f("keyword", "while");
                    var o = d();
                    k(true);
                    return new mt({
                        body: t,
                        condition: o
                    });

                  case "while":
                    b();
                    return new _t({
                        condition: d(),
                        body: I(h)
                    });

                  case "for":
                    b();
                    return B();

                  case "function":
                    b();
                    if (!g("operator", "*")) return A(Ht);
                    b();
                    return A(Yt);

                  case "if":
                    b();
                    return L();

                  case "return":
                    if (_.in_function == 0 && !l.bare_returns) s("'return' outside of function");
                    b();
                    var r = null;
                    if (g("punc", ";")) {
                        b();
                    } else if (!c()) {
                        r = N();
                        k();
                    }
                    return new Sn({
                        value: r
                    });

                  case "switch":
                    b();
                    return new rr({
                        expression: d(),
                        body: I(K)
                    });

                  case "throw":
                    b();
                    if (u(_.token)) s("Illegal newline after 'throw'");
                    var r = N();
                    k();
                    return new Zt({
                        value: r
                    });

                  case "try":
                    b();
                    return Q();

                  case "var":
                    b();
                    var a = re();
                    k();
                    return a;

                  case "with":
                    if (_.input.has_directive("use strict")) {
                        s("Strict mode may not include a with statement");
                    }
                    b();
                    return new xt({
                        expression: d(),
                        body: h()
                    });
                }
            }
            w();
        });
        function H() {
            var n = z(Se);
            if (!_n(_.labels, function(e) {
                return e.name != n.name;
            })) {
                s("Label " + n.name + " defined twice");
            }
            x(":");
            _.labels.push(n);
            var e = h();
            _.labels.pop();
            if (!(e instanceof ht)) {
                n.references.forEach(function(e) {
                    if (e instanceof tr) {
                        o(e.label.start, "Continue label `" + n.name + "` must refer to IterationStatement");
                    }
                });
            }
            return new dt({
                body: e,
                label: n
            });
        }
        function v() {
            var e = N();
            k();
            return new wn({
                body: e
            });
        }
        function Y(e) {
            var n = null, t;
            if (!c()) {
                n = z(Te, true);
            }
            if (n != null) {
                t = Xn(function(e) {
                    return e.name == n.name;
                }, _.labels);
                if (!t) o(n.start, "Undefined label " + n.name);
                n.thedef = t;
            } else if (_.in_loop == 0) s(e.TYPE + " not inside a loop or switch");
            k();
            var r = new e({
                label: n
            });
            if (t) t.references.push(r);
            return r;
        }
        function R(e, n) {
            if (!g("name", e)) return;
            var t = p();
            if (!t) return;
            if (Oe(t, "operator", "=")) return;
            if (t.type == "punc" && /^[(;}]$/.test(t.value)) return;
            if (n && u(t)) return;
            return b();
        }
        function m(e) {
            var n = _.in_async;
            var t = _.in_generator;
            _.input.push_directives_stack();
            _.input.add_directive("use strict");
            var r;
            if (e === Bt) {
                r = z(Ee);
            } else {
                r = z(Ir, true);
            }
            var i = null;
            if (g("keyword", "extends")) {
                b();
                E();
                i = oe(true);
            }
            x("{");
            var a = [];
            while (!g("punc", "}")) {
                if (g("punc", ";")) {
                    b();
                    continue;
                }
                var o = _.token;
                var s = !!R("static");
                var f = R("async", true);
                if (g("operator", "*")) {
                    b();
                    var u = g("name") && /^#/.test(_.token.value);
                    var c = $();
                    var l = _.token;
                    var p = A(f ? Mt : Pt);
                    p.start = l;
                    p.end = y();
                    a.push(new Jt({
                        start: o,
                        static: s,
                        private: u,
                        key: c,
                        value: p,
                        end: y()
                    }));
                    continue;
                }
                if (s && g("punc", "{")) {
                    a.push(new Xt({
                        start: o,
                        value: new Et({
                            start: o,
                            body: q(),
                            end: y()
                        }),
                        end: y()
                    }));
                    continue;
                }
                var u = g("name") && /^#/.test(_.token.value);
                var c = $();
                if (g("punc", "(")) {
                    var d = _.token;
                    var h = A(f ? Ct : Ft);
                    h.start = d;
                    h.end = y();
                    a.push(new Jt({
                        start: o,
                        static: s,
                        private: u,
                        key: c,
                        value: h,
                        end: y()
                    }));
                    continue;
                }
                if (f) w(f);
                var v = null;
                if (g("operator", "=")) {
                    b();
                    _.in_async = false;
                    _.in_generator = false;
                    v = j();
                    _.in_generator = t;
                    _.in_async = n;
                } else if (!(g("punc", ";") || g("punc", "}"))) {
                    var m = null;
                    switch (c) {
                      case "get":
                        m = Wt;
                        break;

                      case "set":
                        m = Gt;
                        break;
                    }
                    if (m) {
                        a.push(new m({
                            start: o,
                            static: s,
                            private: g("name") && /^#/.test(_.token.value),
                            key: $(),
                            value: fe(),
                            end: y()
                        }));
                        continue;
                    }
                }
                k();
                a.push(new Vt({
                    start: o,
                    static: s,
                    private: u,
                    key: c,
                    value: v,
                    end: y()
                }));
            }
            b();
            _.input.pop_directives_stack();
            _.in_generator = t;
            _.in_async = n;
            return new e({
                extends: i,
                name: r,
                properties: a
            });
        }
        function B() {
            var e = g("name", "await") && b();
            x("(");
            var n = null;
            if (e || !g("punc", ";")) {
                n = g("keyword", "const") ? (b(), ne(true)) : g("name", "let") && ee() ? (b(), 
                te(true)) : g("keyword", "var") ? (b(), re(true)) : N(true);
                var t;
                if (e) {
                    f("name", "of");
                    t = wt;
                } else if (g("operator", "in")) {
                    b();
                    t = yt;
                } else if (g("name", "of")) {
                    b();
                    t = xe;
                }
                if (t) {
                    if (n instanceof cr) {
                        if (n.definitions.length > 1) {
                            o(n.start, "Only one variable declaration allowed in for..in/of loop");
                        }
                        if (t !== yt && n.definitions[0].value) {
                            o(n.definitions[0].value.start, "No initializers allowed in for..of loop");
                        }
                    } else if (!(F(n) || (n = P(n)) instanceof Yn)) {
                        o(n.start, "Invalid left-hand side in for..in/of loop");
                    }
                    return a(t, n);
                }
            }
            return i(n);
        }
        function i(e) {
            x(";");
            var n = g("punc", ";") ? null : N();
            x(";");
            var t = g("punc", ")") ? null : N();
            x(")");
            return new gt({
                init: e,
                condition: n,
                step: t,
                body: I(h)
            });
        }
        function a(e, n) {
            E();
            var t = N();
            x(")");
            return new e({
                init: n,
                object: t,
                body: I(h)
            });
        }
        function S(e) {
            if (e instanceof Hn) {
                var n = null;
                if (e.elements[e.elements.length - 1] instanceof Mn) {
                    n = S(e.elements.pop().expression);
                }
                return new kr({
                    start: e.start,
                    elements: e.elements.map(S),
                    rest: n,
                    end: e.end
                });
            }
            if (e instanceof In) return new Dn({
                start: e.start,
                name: S(e.left),
                value: e.right,
                end: e.end
            });
            if (e instanceof Dn) {
                e.name = S(e.name);
                return e;
            }
            if (e instanceof kr) {
                e.elements = e.elements.map(S);
                if (e.rest) e.rest = S(e.rest);
                return e;
            }
            if (e instanceof Sr) {
                e.properties.forEach(function(e) {
                    e.value = S(e.value);
                });
                if (e.rest) e.rest = S(e.rest);
                return e;
            }
            if (e instanceof Zr) return e;
            if (e instanceof Rn) {
                var n = null;
                if (e.properties[e.properties.length - 1] instanceof Mn) {
                    n = S(e.properties.pop().expression);
                }
                return new Sr({
                    start: e.start,
                    properties: e.properties.map(function(e) {
                        if (!(e instanceof Ar)) o(e.start, "Invalid destructuring assignment");
                        return new Er({
                            start: e.start,
                            key: e.key,
                            value: S(e.value),
                            end: e.end
                        });
                    }),
                    rest: n,
                    end: e.end
                });
            }
            if (e instanceof Bn) return e;
            if (e instanceof Ln) return new Bn(e);
            if (e instanceof xr) return new Bn({
                start: e.start,
                name: "yield",
                end: e.end
            });
            o(e.start, "Invalid arrow parameter");
        }
        function T(e, n, t) {
            var r = _.in_async;
            var i = _.in_generator;
            _.in_async = t;
            _.in_generator = false;
            var a = _.in_funarg;
            _.in_funarg = _.in_function;
            var o = e.map(S);
            var s = e.rest || null;
            if (s) s = S(s);
            _.in_funarg = a;
            x("=>");
            var f, u;
            var c = _.in_loop;
            var l = _.labels;
            ++_.in_function;
            _.input.push_directives_stack();
            _.in_loop = 0;
            _.labels = [];
            if (g("punc", "{")) {
                _.in_directives = true;
                f = q();
                u = null;
            } else {
                f = [];
                E();
                u = j();
            }
            var p = _.input.has_directive("use strict");
            _.input.pop_directives_stack();
            --_.in_function;
            _.in_loop = c;
            _.labels = l;
            _.in_generator = i;
            _.in_async = r;
            var d = new (t ? zt : $t)({
                start: n,
                argnames: o,
                rest: s,
                body: f,
                value: u,
                end: y()
            });
            if (p) d.each_argname(pe);
            return d;
        }
        var A = function(e) {
            var n = _.in_async;
            var t = _.in_generator;
            var r;
            if (/Defun$/.test(e.TYPE)) {
                r = z(jr);
                _.in_async = /^Async/.test(e.TYPE);
                _.in_generator = /Generator/.test(e.TYPE);
            } else {
                _.in_async = /^Async/.test(e.TYPE);
                _.in_generator = /Generator/.test(e.TYPE);
                r = z(Nr, true);
            }
            if (r && e !== St && !(r instanceof zr)) w(y());
            x("(");
            var i = _.in_funarg;
            _.in_funarg = _.in_function;
            var a = O(")", !l.strict, false, function() {
                return de(Bn);
            });
            _.in_funarg = i;
            var o = _.in_loop;
            var s = _.labels;
            ++_.in_function;
            _.in_directives = true;
            _.input.push_directives_stack();
            _.in_loop = 0;
            _.labels = [];
            var f = q();
            var u = _.input.has_directive("use strict");
            _.input.pop_directives_stack();
            --_.in_function;
            _.in_loop = o;
            _.labels = s;
            _.in_generator = t;
            _.in_async = n;
            var c = new e({
                name: r,
                argnames: a,
                rest: a.rest || null,
                body: f
            });
            if (u) {
                if (r) pe(r);
                c.each_argname(pe);
            }
            return c;
        };
        function L() {
            var e = d(), n = h(), t = null;
            if (g("keyword", "else")) {
                b();
                t = h();
            }
            return new Tn({
                condition: e,
                body: n,
                alternative: t
            });
        }
        function U() {
            return g("name") || g("string") || ai(_.token.value);
        }
        function D(e) {
            return new Vn({
                start: e,
                quote: e.quote,
                value: e.value,
                end: e
            });
        }
        function V() {
            var e = _.token;
            f("string");
            k();
            return D(e);
        }
        function W() {
            if (g("operator", "*")) {
                var e = _.token;
                var n = e;
                b();
                if (g("name", "as")) {
                    b();
                    if (!U()) f("name");
                    n = _.token;
                    b();
                }
                f("name", "from");
                return new ke({
                    aliases: [ D(n) ],
                    keys: [ D(e) ],
                    path: V()
                });
            }
            if (g("punc", "{")) {
                b();
                var r = [];
                var t = [];
                while (U()) {
                    var e = _.token;
                    b();
                    t.push(e);
                    if (g("name", "as")) {
                        b();
                        if (!U()) f("name");
                        r.push(_.token);
                        b();
                    } else {
                        r.push(e);
                    }
                    if (!g("punc", "}")) x(",");
                }
                x("}");
                if (g("name", "from")) {
                    b();
                    return new ke({
                        aliases: r.map(D),
                        keys: t.map(D),
                        path: V()
                    });
                }
                k();
                return new mr({
                    properties: t.map(function(e, n) {
                        if (!Oe(e, "name")) o(e, "Name expected");
                        var t = le(Yr, e);
                        t.alias = D(r[n]);
                        return t;
                    })
                });
            }
            if (g("keyword", "default")) {
                b();
                var i = _.token;
                var a = G();
                if (a) {
                    a.start = i;
                    a.end = y();
                } else {
                    E();
                    a = N();
                    k();
                }
                return new vr({
                    body: a
                });
            }
            return new hr({
                body: J()
            });
        }
        function n(e, n) {
            if (n.name) {
                n = new e(n);
                n.name = new (e === Bt ? Ee : jr)(n.name);
            }
            return n;
        }
        function G() {
            if (g("name", "async")) {
                if (!Oe(p(), "keyword", "function")) return;
                b();
                b();
                if (!g("operator", "*")) return n(Nt, A(Ct));
                b();
                return n(It, A(Mt));
            } else if (g("keyword")) switch (_.token.value) {
              case "class":
                b();
                return n(Bt, m(Lt));

              case "function":
                b();
                if (!g("operator", "*")) return n(Ht, A(Ft));
                b();
                return n(Yt, A(Pt));
            }
        }
        var J = e(function() {
            if (g("name")) switch (_.token.value) {
              case "async":
                b();
                f("keyword", "function");
                if (!g("operator", "*")) return A(Nt);
                b();
                return A(It);

              case "let":
                b();
                var e = te();
                k();
                return e;
            } else if (g("keyword")) switch (_.token.value) {
              case "class":
                b();
                return m(Bt);

              case "const":
                b();
                var e = ne();
                k();
                return e;

              case "function":
                b();
                if (!g("operator", "*")) return A(Ht);
                b();
                return A(Yt);

              case "var":
                b();
                var e = re();
                k();
                return e;
            }
            w();
        });
        function X() {
            var e = null;
            var n = z(Mr, true);
            var t = null;
            var r;
            if (n) {
                n.key = new Vn({
                    start: n.start,
                    value: "",
                    end: n.end
                });
                if (r = g("punc", ",")) b();
            } else {
                r = !g("string");
            }
            if (r) {
                if (g("operator", "*")) {
                    var i = _.token;
                    b();
                    f("name", "as");
                    e = z(Mr);
                    e.key = D(i);
                } else {
                    x("{");
                    t = [];
                    while (U()) {
                        var a;
                        if (Oe(p(), "name", "as")) {
                            var i = _.token;
                            b();
                            b();
                            a = z(Mr);
                            a.key = D(i);
                        } else {
                            a = z(Mr);
                            a.key = new Vn({
                                start: a.start,
                                value: a.name,
                                end: a.end
                            });
                        }
                        t.push(a);
                        if (!g("punc", "}")) x(",");
                    }
                    x("}");
                }
            }
            if (e || n || t) f("name", "from");
            return new _r({
                all: e,
                default: n,
                path: V(),
                properties: t
            });
        }
        function q() {
            x("{");
            var e = [];
            while (!g("punc", "}")) {
                if (g("eof")) x("}");
                e.push(h());
            }
            b();
            return e;
        }
        function K() {
            x("{");
            var e = [], n, t, r, i;
            while (!g("punc", "}")) {
                if (g("eof")) x("}");
                if (g("keyword", "case")) {
                    if (n) n.end = y();
                    t = [];
                    n = new or({
                        start: (i = _.token, b(), i),
                        expression: N(),
                        body: t
                    });
                    e.push(n);
                    x(":");
                } else if (g("keyword", "default")) {
                    if (n) n.end = y();
                    if (r) s("More than one default clause in switch statement");
                    t = [];
                    n = new ar({
                        start: (i = _.token, b(), x(":"), i),
                        body: t
                    });
                    e.push(n);
                    r = n;
                } else {
                    if (!t) w();
                    t.push(h());
                }
            }
            if (n) n.end = y();
            b();
            return e;
        }
        function Q() {
            var e = q(), n = null, t = null;
            if (g("keyword", "catch")) {
                var r = _.token;
                b();
                var i = null;
                if (g("punc", "(")) {
                    b();
                    i = C(Hr);
                    x(")");
                }
                n = new fr({
                    start: r,
                    argname: i,
                    body: q(),
                    end: y()
                });
            }
            if (g("keyword", "finally")) {
                var r = _.token;
                b();
                t = new ur({
                    start: r,
                    body: q(),
                    end: y()
                });
            }
            if (!n && !t) s("Missing catch/finally blocks");
            return new sr({
                body: e,
                bcatch: n,
                bfinally: t
            });
        }
        function Z(e, n) {
            var t = [];
            for (;;) {
                var r = _.token;
                var i = C(e);
                var a = null;
                if (g("operator", "=")) {
                    b();
                    a = j(n);
                } else if (!n && (e === Cr || i instanceof Yn)) {
                    s("Missing initializer in declaration");
                }
                t.push(new An({
                    start: r,
                    name: i,
                    value: a,
                    end: y()
                }));
                if (!g("punc", ",")) break;
                b();
            }
            return t;
        }
        function ee() {
            var e = p();
            return Oe(e, "name") || Oe(e, "punc", "[") || Oe(e, "punc", "{");
        }
        var ne = function(e) {
            return new lr({
                start: y(),
                definitions: Z(Cr, e),
                end: y()
            });
        };
        var te = function(e) {
            return new pr({
                start: y(),
                definitions: Z(Fr, e),
                end: y()
            });
        };
        var re = function(e) {
            return new dr({
                start: y(),
                definitions: Z(Pr, e),
                end: y()
            });
        };
        var ie = function(e) {
            var n = _.token;
            f("operator", "new");
            var t;
            if (g("punc", ".") && Oe(p(), "name", "target")) {
                b();
                b();
                t = new Ur();
            } else {
                var r = oe(false), i;
                if (g("punc", "(")) {
                    b();
                    i = O(")", !l.strict);
                } else {
                    i = [];
                }
                t = new gr({
                    expression: r,
                    args: i
                });
            }
            t.start = n;
            t.end = y();
            return M(t, e);
        };
        function ae() {
            var e, n = _.token, t = n.value;
            switch (n.type) {
              case "num":
                if (isFinite(t)) {
                    e = new Wn({
                        value: t
                    });
                } else {
                    e = new ei();
                    if (t < 0) e = new Pn({
                        operator: "-",
                        expression: e
                    });
                }
                break;

              case "bigint":
                e = new Wr({
                    value: t
                });
                break;

              case "string":
                e = new Vn({
                    value: t,
                    quote: n.quote
                });
                break;

              case "regexp":
                e = new Gr({
                    value: t
                });
                break;

              case "atom":
                switch (t) {
                  case "false":
                    e = new ti();
                    break;

                  case "true":
                    e = new ri();
                    break;

                  case "null":
                    e = new Xr();
                    break;

                  default:
                    w();
                }
                break;

              default:
                w();
            }
            b();
            e.start = e.end = n;
            return e;
        }
        var oe = function(e) {
            if (g("operator", "new")) {
                return ie(e);
            }
            var n = _.token;
            if (g("punc")) {
                switch (n.value) {
                  case "`":
                    return M(he(null), e);

                  case "(":
                    b();
                    if (g("punc", ")")) {
                        b();
                        return T([], n);
                    }
                    var t = N(false, true);
                    var r = n.comments_before.length;
                    [].unshift.apply(t.start.comments_before, n.comments_before);
                    n.comments_before.length = 0;
                    n.comments_before = t.start.comments_before;
                    n.comments_before_length = r;
                    if (r == 0 && n.comments_before.length > 0) {
                        var i = n.comments_before[0];
                        if (!i.nlb) {
                            i.nlb = n.nlb;
                            n.nlb = false;
                        }
                    }
                    n.comments_after = t.start.comments_after;
                    t.start = n;
                    x(")");
                    var a = y();
                    a.comments_before = t.end.comments_before;
                    a.comments_after.forEach(function(e) {
                        t.end.comments_after.push(e);
                        if (e.nlb) _.token.nlb = true;
                    });
                    a.comments_after.length = 0;
                    a.comments_after = t.end.comments_after;
                    t.end = a;
                    if (g("punc", "=>")) return T(t instanceof On ? t.expressions : [ t ], n);
                    return M(t, e);

                  case "[":
                    return M(se(), e);

                  case "{":
                    return M(ue(), e);
                }
                w();
            }
            if (g("keyword")) switch (n.value) {
              case "class":
                b();
                var o = m(Lt);
                o.start = n;
                o.end = y();
                return M(o, e);

              case "function":
                b();
                var s;
                if (g("operator", "*")) {
                    b();
                    s = A(Pt);
                } else {
                    s = A(Ft);
                }
                s.start = n;
                s.end = y();
                return M(s, e);
            }
            if (g("name")) {
                var f = le(Ln, n);
                b();
                if (f.name == "async") {
                    if (g("keyword", "function")) {
                        b();
                        var s;
                        if (g("operator", "*")) {
                            b();
                            s = A(Mt);
                        } else {
                            s = A(Ct);
                        }
                        s.start = n;
                        s.end = y();
                        return M(s, e);
                    }
                    if (g("name") && Oe(p(), "punc", "=>")) {
                        n = _.token;
                        f = le(Ln, n);
                        b();
                        return T([ f ], n, true);
                    }
                    if (g("punc", "(")) {
                        var u = M(f, e);
                        if (!g("punc", "=>")) return u;
                        var c = u.args;
                        if (c[c.length - 1] instanceof Mn) {
                            c.rest = c.pop().expression;
                        }
                        return T(c, n, true);
                    }
                }
                return g("punc", "=>") ? T([ f ], n) : M(f, e);
            }
            if (Me[_.token.type]) {
                return M(ae(), e);
            }
            w();
        };
        function O(e, n, t, r) {
            if (!r) r = j;
            var i = true, a = [];
            while (!g("punc", e)) {
                if (i) i = false; else x(",");
                if (n && g("punc", e)) break;
                if (t && g("punc", ",")) {
                    a.push(new Zr({
                        start: _.token,
                        end: _.token
                    }));
                } else if (!g("operator", "...")) {
                    a.push(r());
                } else if (r === j) {
                    a.push(new Mn({
                        start: _.token,
                        expression: (b(), r()),
                        end: y()
                    }));
                } else {
                    b();
                    a.rest = r();
                    if (a.rest instanceof Dn) o(a.rest.start, "Invalid rest parameter");
                    break;
                }
            }
            x(e);
            return a;
        }
        var se = e(function() {
            x("[");
            return new Hn({
                elements: O("]", !l.strict, true)
            });
        });
        var fe = e(function() {
            return A(St);
        });
        var ue = e(function() {
            x("{");
            var e = true, n = [];
            while (!g("punc", "}")) {
                if (e) e = false; else x(",");
                if (!l.strict && g("punc", "}")) break;
                var t = _.token;
                if (g("operator", "*")) {
                    b();
                    var r = $();
                    var i = _.token;
                    var a = A(Pt);
                    a.start = i;
                    a.end = y();
                    n.push(new Dr({
                        start: t,
                        key: r,
                        value: a,
                        end: y()
                    }));
                    continue;
                }
                if (g("operator", "...")) {
                    b();
                    n.push(new Mn({
                        start: t,
                        expression: j(),
                        end: y()
                    }));
                    continue;
                }
                if (Oe(p(), "operator", "=")) {
                    var o = z(Ln);
                    b();
                    n.push(new Ar({
                        start: t,
                        key: t.value,
                        value: new In({
                            start: t,
                            left: o,
                            operator: "=",
                            right: j(),
                            end: y()
                        }),
                        end: y()
                    }));
                    continue;
                }
                if (Oe(p(), "punc", ",") || Oe(p(), "punc", "}")) {
                    n.push(new Ar({
                        start: t,
                        key: t.value,
                        value: z(Ln),
                        end: y()
                    }));
                    continue;
                }
                var r = $();
                if (g("punc", "(")) {
                    var s = _.token;
                    var f = A(Ft);
                    f.start = s;
                    f.end = y();
                    n.push(new Dr({
                        start: t,
                        key: r,
                        value: f,
                        end: y()
                    }));
                    continue;
                }
                if (g("punc", ":")) {
                    b();
                    n.push(new Ar({
                        start: t,
                        key: r,
                        value: j(),
                        end: y()
                    }));
                    continue;
                }
                if (t.type == "name") switch (r) {
                  case "async":
                    var u = g("operator", "*") && b();
                    r = $();
                    var s = _.token;
                    var f = A(u ? Mt : Ct);
                    f.start = s;
                    f.end = y();
                    n.push(new Dr({
                        start: t,
                        key: r,
                        value: f,
                        end: y()
                    }));
                    continue;

                  case "get":
                    n.push(new Or({
                        start: t,
                        key: $(),
                        value: fe(),
                        end: y()
                    }));
                    continue;

                  case "set":
                    n.push(new qr({
                        start: t,
                        key: $(),
                        value: fe(),
                        end: y()
                    }));
                    continue;
                }
                w();
            }
            b();
            return new Rn({
                properties: n
            });
        });
        function $() {
            var e = _.token;
            switch (e.type) {
              case "operator":
                if (!Ae[e.value]) w();

              case "num":
              case "string":
              case "name":
              case "keyword":
              case "atom":
                b();
                return "" + e.value;

              case "punc":
                x("[");
                var n = j();
                x("]");
                return n;

              default:
                w();
            }
        }
        function ce() {
            var e = _.token.value;
            f("name");
            return e;
        }
        function le(e, n) {
            var t = n.value;
            switch (t) {
              case "await":
                if (_.in_async) w(n);
                break;

              case "super":
                e = Br;
                break;

              case "this":
                e = Lr;
                break;

              case "yield":
                if (_.in_generator) w(n);
                break;
            }
            return new e({
                name: "" + t,
                start: n,
                end: n
            });
        }
        function pe(e) {
            if (e.name == "arguments" || e.name == "eval" || e.name == "let") o(e.start, "Unexpected " + e.name + " in strict mode");
        }
        function z(e, n) {
            if (!g("name")) {
                if (!n) s("Name expected");
                return null;
            }
            var t = le(e, _.token);
            if (_.input.has_directive("use strict") && t instanceof zr) {
                pe(t);
            }
            b();
            return t;
        }
        function C(e) {
            var n = _.token;
            if (g("punc", "[")) {
                b();
                var t = O("]", !l.strict, true, function() {
                    return de(e);
                });
                return new kr({
                    start: n,
                    elements: t,
                    rest: t.rest || null,
                    end: y()
                });
            }
            if (g("punc", "{")) {
                b();
                var r = true, i = [], a = null;
                while (!g("punc", "}")) {
                    if (r) r = false; else x(",");
                    if (!l.strict && g("punc", "}")) break;
                    var o = _.token;
                    if (g("punc", "[") || Oe(p(), "punc", ":")) {
                        var s = $();
                        x(":");
                        i.push(new Er({
                            start: o,
                            key: s,
                            value: de(e),
                            end: y()
                        }));
                        continue;
                    }
                    if (g("operator", "...")) {
                        b();
                        a = C(e);
                        break;
                    }
                    var f = z(e);
                    if (g("operator", "=")) {
                        b();
                        f = new Dn({
                            start: f.start,
                            name: f,
                            value: j(),
                            end: y()
                        });
                    }
                    i.push(new Er({
                        start: o,
                        key: o.value,
                        value: f,
                        end: y()
                    }));
                }
                x("}");
                return new Sr({
                    start: n,
                    properties: i,
                    rest: a,
                    end: y()
                });
            }
            return z(e);
        }
        function de(e) {
            var n = _.token;
            var t = C(e);
            if (!g("operator", "=")) return t;
            b();
            return new Dn({
                start: n,
                name: t,
                value: j(),
                end: y()
            });
        }
        function he(e) {
            var n = e ? e.start : _.token;
            var t = _.input.context().read_template;
            var r = [];
            var i = [];
            while (t(r)) {
                b();
                i.push(N());
                if (!g("punc", "}")) w();
            }
            b();
            return new Vr({
                start: n,
                expressions: i,
                strings: r,
                tag: e,
                end: y()
            });
        }
        function M(e, n) {
            var t = e.start;
            var r = null;
            while (true) {
                if (g("operator", "?") && Oe(p(), "punc", ".")) {
                    b();
                    b();
                    r = e;
                }
                if (g("punc", "[")) {
                    b();
                    var i = N();
                    x("]");
                    e = new Cn({
                        start: t,
                        optional: r === e,
                        expression: e,
                        property: i,
                        end: y()
                    });
                } else if (n && g("punc", "(")) {
                    b();
                    e = new qn({
                        start: t,
                        optional: r === e,
                        expression: e,
                        args: O(")", !l.strict),
                        end: y()
                    });
                } else if (r === e || g("punc", ".")) {
                    if (r !== e) b();
                    e = new zn({
                        start: t,
                        optional: r === e,
                        expression: e,
                        property: ce(),
                        end: y()
                    });
                } else if (g("punc", "`")) {
                    if (r) s("Invalid template on optional chain");
                    e = he(e);
                } else {
                    break;
                }
            }
            if (r) e.terminal = true;
            if (e instanceof qn && !e.pure) {
                var t = e.start;
                var a = t.comments_before;
                var o = it(t, "comments_before_length") ? t.comments_before_length : a.length;
                while (--o >= 0) {
                    if (/[@#]__PURE__/.test(a[o].value)) {
                        e.pure = true;
                        break;
                    }
                }
            }
            return e;
        }
        function ve(e) {
            var n = _.token;
            if (_.in_async && g("name", "await")) {
                if (_.in_funarg === _.in_function) s("Invalid use of await in function argument");
                _.input.context().regex_allowed = true;
                b();
                return new wr({
                    start: n,
                    expression: ve(e),
                    end: y()
                });
            }
            if (_.in_generator && g("name", "yield")) {
                if (_.in_funarg === _.in_function) s("Invalid use of yield in function argument");
                _.input.context().regex_allowed = true;
                b();
                var t = null;
                var r = false;
                if (g("operator", "*")) {
                    b();
                    t = j(e);
                    r = true;
                } else if (g("punc") ? !De[_.token.value] : !c()) {
                    t = j(e);
                }
                return new xr({
                    start: n,
                    expression: t,
                    nested: r,
                    end: y()
                });
            }
            if (g("operator") && ze[n.value]) {
                b();
                E();
                var i = me(Pn, n, ve(e));
                i.start = n;
                i.end = y();
                return i;
            }
            var a = oe(true);
            while (g("operator") && fi[_.token.value] && !u(_.token)) {
                a = me(yr, _.token, a);
                a.start = n;
                a.end = _.token;
                b();
            }
            return a;
        }
        function me(e, n, t) {
            var r = n.value;
            switch (r) {
              case "++":
              case "--":
                if (!F(t)) o(n, "Invalid use of " + r + " operator");
                break;

              case "delete":
                if (t instanceof Ln && _.input.has_directive("use strict")) o(t.start, "Calling delete on expression not allowed in strict mode");
                break;
            }
            return new e({
                operator: r,
                expression: t
            });
        }
        var _e = function(e, n, t) {
            var r = g("operator") ? _.token.value : null;
            if (r == "in" && t) r = null;
            var i = r != null ? ui[r] : null;
            if (i != null && i > n) {
                b();
                var a = _e(ve(t), r == "**" ? i - 1 : i, t);
                return _e(new jn({
                    start: e.start,
                    left: e,
                    operator: r,
                    right: a,
                    end: a.end
                }), n, t);
            }
            return e;
        };
        function ge(e) {
            return _e(ve(e), 0, e);
        }
        var be = function(e) {
            var n = _.token;
            var t = ge(e);
            if (g("operator", "?")) {
                b();
                var r = j();
                x(":");
                return new Nn({
                    start: n,
                    condition: t,
                    consequent: r,
                    alternative: j(e),
                    end: y()
                });
            }
            return t;
        };
        function F(e) {
            return e instanceof $n && !e.optional || e instanceof Ln;
        }
        function P(e) {
            if (e instanceof Hn) {
                var n = null;
                if (e.elements[e.elements.length - 1] instanceof Mn) {
                    n = P(e.elements.pop().expression);
                    if (!(n instanceof Yn || F(n))) return e;
                }
                var t = e.elements.map(P);
                return _n(t, function(e) {
                    return e instanceof Dn || e instanceof Yn || e instanceof Zr || F(e);
                }) ? new kr({
                    start: e.start,
                    elements: t,
                    rest: n,
                    end: e.end
                }) : e;
            }
            if (e instanceof In) {
                var r = P(e.left);
                return r instanceof Yn || F(r) ? new Dn({
                    start: e.start,
                    name: r,
                    value: e.right,
                    end: e.end
                }) : e;
            }
            if (!(e instanceof Rn)) return e;
            var n = null;
            if (e.properties[e.properties.length - 1] instanceof Mn) {
                n = P(e.properties.pop().expression);
                if (!(n instanceof Yn || F(n))) return e;
            }
            var i = [];
            for (var a = 0; a < e.properties.length; a++) {
                var o = e.properties[a];
                if (!(o instanceof Ar)) return e;
                var s = P(o.value);
                if (!(s instanceof Dn || s instanceof Yn || F(s))) {
                    return e;
                }
                i.push(new Er({
                    start: o.start,
                    key: o.key,
                    value: s,
                    end: o.end
                }));
            }
            return new Sr({
                start: e.start,
                properties: i,
                rest: n,
                end: e.end
            });
        }
        function j(e) {
            var n = _.token;
            var t = be(e), r = _.token.value;
            if (g("operator") && Ce[r]) {
                if (F(t) || r == "=" && (t = P(t)) instanceof Yn) {
                    b();
                    return new In({
                        start: n,
                        left: t,
                        operator: r,
                        right: j(e),
                        end: y()
                    });
                }
                s("Invalid assignment");
            }
            return t;
        }
        function N(e, n) {
            var t = _.token;
            var r = [];
            while (true) {
                if (n && g("operator", "...")) {
                    b();
                    r.rest = C(Bn);
                    break;
                }
                r.push(j(e));
                if (!g("punc", ",")) break;
                b();
                if (n && g("punc", ")") && Oe(p(), "punc", "=>")) break;
            }
            return r.length == 1 && !r.rest ? r[0] : new On({
                start: t,
                expressions: r,
                end: y()
            });
        }
        function I(e) {
            ++_.in_loop;
            var n = e();
            --_.in_loop;
            return n;
        }
        if (l.expression) {
            E();
            var ye = N();
            f("eof");
            return ye;
        }
        return function() {
            var e = _.token;
            var n = [];
            if (l.module) {
                _.in_async = true;
                _.input.add_directive("use strict");
            }
            _.input.push_directives_stack();
            while (!g("eof")) n.push(h(true));
            _.input.pop_directives_stack();
            var t = y() || e;
            var r = l.toplevel;
            if (r) {
                r.body = r.body.concat(n);
                r.end = t;
            } else {
                r = new kt({
                    start: e,
                    body: n,
                    end: t
                });
            }
            return r;
        }();
    }
    /***********************************************************************

  A JavaScript tokenizer / parser / beautifier / compressor.
  https://github.com/mishoo/UglifyJS

  -------------------------------- (C) ---------------------------------

                           Author: Mihai Bazon
                         <mihai.bazon@gmail.com>
                       http://mihai.bazon.net/blog

  Distributed under the BSD license:

    Copyright 2012 (c) Mihai Bazon <mihai.bazon@gmail.com>

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

        * Redistributions of source code must retain the above
          copyright notice, this list of conditions and the following
          disclaimer.

        * Redistributions in binary form must reproduce the above
          copyright notice, this list of conditions and the following
          disclaimer in the documentation and/or other materials
          provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER “AS IS” AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE
    LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
    OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
    TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
    THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
    SUCH DAMAGE.

 ***********************************************************************/
    "use strict";
    function y(e, n, t, r) {
        this._bits = 0;
        this.defun = undefined;
        this.eliminated = 0;
        this.id = e;
        this.init = r;
        this.mangled_name = null;
        this.name = t.name;
        this.orig = [ t ];
        this.references = [];
        this.replaced = 0;
        this.safe_ids = undefined;
        this.scope = n;
    }
    y.prototype = {
        forEach: function(e) {
            this.orig.forEach(e);
            this.references.forEach(e);
        },
        mangle: function(e) {
            if (this.mangled_name) return;
            var n = this.global && e.cache && e.cache.props;
            if (n && n.has(this.name)) {
                this.mangled_name = n.get(this.name);
            } else if (this.unmangleable(e)) {
                k(this.scope, e).set(this.name, true);
            } else {
                var t = this.redefined();
                if (t) {
                    this.mangled_name = t.mangled_name || t.name;
                } else {
                    this.mangled_name = E(this, e);
                }
                if (n) n.set(this.name, this.mangled_name);
            }
        },
        redefined: function() {
            var e = this;
            var n = e.defun;
            if (!n) return;
            var t = e.name;
            var r = n.variables.get(t) || n instanceof kt && n.globals.get(t) || e.orig[0] instanceof Cr && Xn(function(e) {
                return e.name == t;
            }, n.enclosed);
            if (r && r !== e) return r.redefined() || r;
        },
        unmangleable: function(e) {
            if (this.exported) return true;
            if (this.undeclared) return true;
            if (!e.eval && this.scope.pinned()) return true;
            if (e.keep_fargs && li(this)) return true;
            if (e.keep_fnames) {
                var n = this.orig[0];
                if (n instanceof Ir) return true;
                if (n instanceof Ee) return true;
                if (n instanceof jr) return true;
                if (n instanceof Nr) return true;
            }
            if (!e.toplevel && this.global) return true;
            return false;
        }
    };
    r(y, [ "const_redefs", "cross_loop", "direct_access", "exported", "global", "undeclared" ]);
    function li(e) {
        return e.orig[0] instanceof Bn || e.orig[1] instanceof Bn;
    }
    var pi = mn("delete ++ --");
    function di(e, n) {
        if (n instanceof In) return n.left === e && e;
        if (n instanceof Dn) return n.name === e && e;
        if (n instanceof Yn) return e;
        if (n instanceof Er) return e;
        if (n instanceof bt) return n.init === e && e;
        if (n instanceof Fn) return pi[n.operator] && n.expression;
    }
    kt.DEFMETHOD("figure_out_scope", function(c) {
        c = we(c, {
            cache: null,
            ie: false
        });
        var l = this;
        var o = null;
        var s = false;
        var t = 0;
        var f = l.parent_scope = null;
        var p = new Gn(function(r, e) {
            if (r instanceof Bt) {
                var n = s;
                s = p.parent() instanceof hr;
                r.name.walk(p);
                s = n;
                a(function() {
                    if (r.extends) r.extends.walk(p);
                    r.properties.forEach(function(e) {
                        e.walk(p);
                    });
                });
                return true;
            }
            if (r instanceof cr) {
                var n = s;
                s = p.parent() instanceof hr;
                e();
                s = n;
                return true;
            }
            if (r instanceof jt) {
                var n = s;
                s = p.parent() instanceof hr;
                r.name.walk(p);
                s = n;
                a(function() {
                    r.argnames.forEach(function(e) {
                        e.walk(p);
                    });
                    if (r.rest) r.rest.walk(p);
                    lt(r, p);
                });
                return true;
            }
            if (r instanceof ir) {
                r.init_vars(f);
                e();
                return true;
            }
            if (r instanceof sr) {
                a(function() {
                    lt(r, p);
                });
                if (r.bcatch) r.bcatch.walk(p);
                if (r.bfinally) r.bfinally.walk(p);
                return true;
            }
            if (r instanceof xt) {
                var t = f;
                do {
                    t = t.resolve();
                    if (t.uses_with) break;
                    t.uses_with = true;
                } while (t = t.parent_scope);
                a(e);
                return true;
            }
            if (r instanceof ct) {
                a(e);
                return true;
            }
            if (r instanceof $r) {
                r.scope = f;
            }
            if (r instanceof Se) {
                r.thedef = r;
                r.references = [];
            }
            if (r instanceof Hr) {
                f.def_variable(r).defun = o;
            } else if (r instanceof Cr) {
                var i = f.def_variable(r);
                i.defun = o;
                if (s) i.exported = true;
            } else if (r instanceof jr) {
                var i = o.def_function(r, p.parent());
                if (s) i.exported = true;
            } else if (r instanceof Bn) {
                o.def_variable(r);
            } else if (r instanceof Nr) {
                var i = o.def_function(r, r.name == "arguments" ? undefined : o);
                if (c.ie && r.name != "arguments") i.defun = o.parent_scope.resolve();
            } else if (r instanceof Fr) {
                var i = f.def_variable(r);
                if (s) i.exported = true;
            } else if (r instanceof Pr) {
                var i = o.def_variable(r, r instanceof Mr ? undefined : null);
                if (s) i.exported = true;
            }
            function a(e) {
                r.init_vars(f);
                var n = o;
                var t = f;
                if (r instanceof kn) o = r;
                f = r;
                e();
                f = t;
                o = n;
            }
        });
        l.make_def = function(e, n) {
            return new y(++t, this, e, n);
        };
        l.walk(p);
        l.globals = new gn();
        var d = [];
        var p = new Gn(function(e) {
            if (e instanceof fr) {
                if (!(e.argname instanceof Yn)) return;
                d.push(e);
                e.argname.walk(p);
                d.pop();
                lt(e, p);
                return true;
            }
            if (e instanceof En) {
                d.push(e);
                if (e.name) e.name.walk(p);
                e.argnames.forEach(function(e) {
                    e.walk(p);
                });
                if (e.rest) e.rest.walk(p);
                d.pop();
                Ot(e, p);
                return true;
            }
            if (e instanceof er) {
                if (e.label) e.label.thedef.references.push(e);
                return true;
            }
            if (e instanceof zr) {
                var n = e.definition();
                n.preinit = n.references.length;
                if (e instanceof Hr) {
                    var t = n.redefined();
                    if (t) for (var r = e.scope; r; r = r.parent_scope) {
                        if (!nt(r.enclosed, t)) break;
                        if (r === t.scope) break;
                    }
                } else if (e instanceof Cr) {
                    var t = n.redefined();
                    if (t) t.const_redefs = true;
                } else if (n.scope !== e.scope && (e instanceof jr || e instanceof Bn || e instanceof Pr)) {
                    e.mark_enclosed(c);
                    var t = e.scope.find_variable(e.name);
                    if (e.thedef !== t) {
                        e.thedef = t;
                        t.orig.push(e);
                        e.mark_enclosed(c);
                    }
                }
                if (e.name != "arguments") return true;
                var i = e instanceof Pr && p.parent();
                if (i instanceof An && !i.value) return true;
                var a = e.scope.resolve().find_variable("arguments");
                if (a && h(a)) a.scope.uses_arguments = 3;
                return true;
            }
            if (e instanceof Ln) {
                var o = e.name;
                var a = e.scope.find_variable(o);
                for (var s = d.length; s > 0 && a; ) {
                    s = d.lastIndexOf(a.scope, s - 1);
                    if (s < 0) break;
                    var f = a.orig[0];
                    if (f instanceof Hr || f instanceof Bn || f instanceof Nr) {
                        e.in_arg = true;
                        break;
                    }
                    a = a.scope.parent_scope.find_variable(o);
                }
                if (!a) {
                    a = l.def_global(e);
                } else if (o == "arguments" && h(a)) {
                    var i = p.parent();
                    if (di(e, i)) {
                        a.scope.uses_arguments = 3;
                    } else if (a.scope.uses_arguments < 2 && !(i instanceof $n && i.expression === e)) {
                        a.scope.uses_arguments = 2;
                    } else if (!a.scope.uses_arguments) {
                        a.scope.uses_arguments = true;
                    }
                }
                if (o == "eval") {
                    var i = p.parent();
                    if (i.TYPE == "Call" && i.expression === e) {
                        var r = e.scope;
                        do {
                            r = r.resolve();
                            if (r.uses_eval) break;
                            r.uses_eval = true;
                        } while (r = r.parent_scope);
                    } else if (a.undeclared) {
                        l.uses_eval = true;
                    }
                }
                if (a.init instanceof jt && a.scope !== a.init.name.scope) {
                    var u = e.scope;
                    do {
                        if (u === a.init.name.scope) break;
                    } while (u = u.parent_scope);
                    if (!u) a.init = undefined;
                }
                e.thedef = a;
                e.reference(c);
                return true;
            }
        });
        l.walk(p);
        if (c.ie) l.walk(new Gn(function(e) {
            if (e instanceof Hr) {
                var n = e.thedef;
                var t = n.defun;
                if (n.name != "arguments" && t.name instanceof Nr && t.name.name == n.name) {
                    t = t.parent_scope.resolve();
                }
                r(e, t);
                return true;
            }
            if (e instanceof Nr) {
                var n = e.thedef;
                if (!r(e, e.scope.parent_scope.resolve())) {
                    n.defun = undefined;
                } else if (typeof e.thedef.init !== "undefined") {
                    e.thedef.init = false;
                } else if (n.init) {
                    e.thedef.init = n.init;
                }
                return true;
            }
        }));
        function h(e) {
            return e.orig[0] instanceof Bn && !(e.orig[1] instanceof Bn || e.orig[2] instanceof Bn) && !At(e.scope);
        }
        function r(e, n) {
            var t = e.name;
            var r = e.thedef;
            if (!_n(r.orig, function(e) {
                return !(e instanceof Cr || e instanceof Fr);
            })) return false;
            var i = n.find_variable(t);
            if (i) {
                var a = i.redefined();
                if (a) i = a;
            } else {
                i = l.globals.get(t);
            }
            if (i) {
                i.orig.push(e);
            } else {
                i = n.def_variable(e);
            }
            if (i.undeclared) l.variables.set(t, i);
            if (t == "arguments" && h(r) && e instanceof Nr) return true;
            r.defun = i.scope;
            r.forEach(function(e) {
                e.redef = r;
                e.thedef = i;
                e.reference(c);
            });
            return true;
        }
    });
    kt.DEFMETHOD("def_global", function(e) {
        var n = this.globals, t = e.name;
        if (n.has(t)) {
            return n.get(t);
        } else {
            var r = this.make_def(e);
            r.undeclared = true;
            r.global = true;
            n.set(t, r);
            return r;
        }
    });
    function w(e, n) {
        e.enclosed = [];
        e.parent_scope = n;
        e.functions = new gn();
        e.variables = new gn();
        if (n) e.make_def = n.make_def;
    }
    function x(e, n) {
        w(e, n);
        e.uses_eval = false;
        e.uses_with = false;
    }
    ct.DEFMETHOD("init_vars", function(e) {
        w(this, e);
    });
    kn.DEFMETHOD("init_vars", function(e) {
        x(this, e);
    });
    $t.DEFMETHOD("init_vars", function(e) {
        x(this, e);
        return this;
    });
    zt.DEFMETHOD("init_vars", function(e) {
        x(this, e);
    });
    En.DEFMETHOD("init_vars", function(e) {
        x(this, e);
        this.uses_arguments = false;
        this.def_variable(new Bn({
            name: "arguments",
            scope: this,
            start: this.start,
            end: this.end
        }));
        return this;
    });
    $r.DEFMETHOD("mark_enclosed", function(e) {
        var n = this.definition();
        for (var t = this.scope; t; t = t.parent_scope) {
            if (!nt(t.enclosed, n)) break;
            if (!e) {
                t._var_names = undefined;
            } else {
                if (e.keep_fargs && t instanceof En) t.each_argname(function(e) {
                    nt(n.scope.enclosed, e.definition());
                });
                if (e.keep_fnames) t.functions.each(function(e) {
                    nt(n.scope.enclosed, e);
                });
            }
            if (t === n.scope) break;
        }
    });
    $r.DEFMETHOD("reference", function(e) {
        this.definition().references.push(this);
        this.mark_enclosed(e);
    });
    ct.DEFMETHOD("find_variable", function(e) {
        return this.variables.get(e) || this.parent_scope && this.parent_scope.find_variable(e);
    });
    ct.DEFMETHOD("def_function", function(e, n) {
        var t = this.def_variable(e, n);
        if (!t.init || t.init instanceof jt) t.init = n;
        this.functions.set(e.name, t);
        return t;
    });
    ct.DEFMETHOD("def_variable", function(e, n) {
        var t = this.variables.get(e.name);
        if (t) {
            t.orig.push(e);
            if (t.init instanceof Tt) t.init = n;
        } else {
            t = this.make_def(e, n);
            this.variables.set(e.name, t);
            t.global = !this.parent_scope;
        }
        return e.thedef = t;
    });
    function k(e, n) {
        var t = e.names_in_use;
        if (!t) {
            e.cname = -1;
            e.cname_holes = [];
            e.names_in_use = t = new gn();
            var r = n.cache && n.cache.props;
            e.enclosed.forEach(function(e) {
                if (e.unmangleable(n)) t.set(e.name, true);
                if (e.global && r && r.has(e.name)) {
                    t.set(r.get(e.name), true);
                }
            });
        }
        return t;
    }
    function E(e, t) {
        var n = e.scope;
        var r = k(n, t);
        var i = n.cname_holes;
        var a = new gn();
        var o = [ n ];
        e.forEach(function(e) {
            var n = e.scope;
            do {
                if (Jn(n, o)) break;
                k(n, t).each(function(e, n) {
                    a.set(n, e);
                });
                o.push(n);
            } while (n = n.parent_scope);
        });
        var s;
        for (var f = 0; f < i.length; f++) {
            s = T(i[f]);
            if (a.has(s)) continue;
            i.splice(f, 1);
            r.set(s, true);
            return s;
        }
        while (true) {
            s = T(++n.cname);
            if (r.has(s) || I[s] || t.reserved.has[s]) continue;
            if (!a.has(s)) break;
            i.push(n.cname);
        }
        r.set(s, true);
        return s;
    }
    $r.DEFMETHOD("unmangleable", function(e) {
        var n = this.definition();
        return !n || n.unmangleable(e);
    });
    Se.DEFMETHOD("unmangleable", hn);
    $r.DEFMETHOD("definition", function() {
        return this.thedef;
    });
    function S(e) {
        e = we(e, {
            eval: false,
            ie: false,
            keep_fargs: false,
            keep_fnames: false,
            reserved: [],
            toplevel: false,
            v8: false,
            webkit: false
        });
        if (!Array.isArray(e.reserved)) e.reserved = [];
        nt(e.reserved, "arguments");
        e.reserved.has = mn(e.reserved);
        return e;
    }
    kt.DEFMETHOD("mangle_names", function(s) {
        s = S(s);
        if (s.cache && s.cache.props) {
            var n = k(this, s);
            s.cache.props.each(function(e) {
                n.set(e, true);
            });
        }
        var f = 36;
        var u = -1;
        var a = [];
        var c = new Gn(function(e, n) {
            var t;
            if (e instanceof ct) {
                if (e instanceof dt) t = u;
                if (s.webkit && e instanceof ht && e.init instanceof pr) {
                    e.init.definitions.forEach(function(e) {
                        e.name.match_symbol(function(e) {
                            if (!(e instanceof Fr)) return;
                            var n = e.definition();
                            var t = e.scope.parent_scope;
                            var r = t.def_variable(e);
                            e.thedef = n;
                            t.to_mangle.push(r);
                            n.redefined = function() {
                                return r;
                            };
                        });
                    }, true);
                }
                var r = e.to_mangle = [];
                e.variables.each(function(e) {
                    if (!p(e)) r.push(e);
                });
                n();
                if (s.cache && e instanceof kt) {
                    e.globals.each(l);
                }
                if (e instanceof Ht && c.has_directive("use asm")) {
                    var i = new Ln(e.name);
                    i.scope = e;
                    i.reference(s);
                }
                if (r.length > f) {
                    var a = r.map(function(e, n) {
                        return n;
                    }).sort(function(e, n) {
                        return r[n].references.length - r[e].references.length || e - n;
                    });
                    r = a.slice(0, f).sort(function(e, n) {
                        return e - n;
                    }).map(function(e) {
                        return r[e];
                    }).concat(a.slice(f).sort(function(e, n) {
                        return e - n;
                    }).map(function(e) {
                        return r[e];
                    }));
                }
                r.forEach(l);
                if (e instanceof dt && !(s.v8 && d(c))) u = t;
                return true;
            }
            if (e instanceof Se) {
                var o;
                do {
                    o = T(++u);
                } while (I[o]);
                e.mangled_name = o;
                return true;
            }
        });
        this.walk(c);
        a.forEach(l);
        function l(e) {
            if (s.reserved.has[e.name]) return;
            e.mangle(s);
        }
        function p(n) {
            var e = n.orig[0];
            var t = n.redefined();
            if (!t) {
                if (!(e instanceof Cr)) return false;
                var r = n.scope.resolve();
                if (n.scope === r) return false;
                if (n.scope.parent_scope.find_variable(e.name)) return false;
                t = r.def_variable(e);
                r.to_mangle.push(t);
            }
            a.push(n);
            n.references.forEach(i);
            if (e instanceof Hr || e instanceof Cr) {
                i(e);
                n.redefined = function() {
                    return t;
                };
            }
            return true;
            function i(e) {
                e.thedef = t;
                e.reference(s);
                e.thedef = n;
            }
        }
        function d(e) {
            var n = 0, t;
            while (t = e.parent(n++)) {
                if (t instanceof pt) return t instanceof kt && !s.toplevel;
                if (t instanceof dt) return true;
            }
        }
    });
    kt.DEFMETHOD("find_colliding_names", function(t) {
        var r = t.cache && t.cache.props;
        var n = Object.create(I);
        t.reserved.forEach(i);
        this.globals.each(a);
        this.walk(new Gn(function(e) {
            if (e instanceof ct) e.variables.each(a);
        }));
        return n;
        function i(e) {
            n[e] = true;
        }
        function a(e) {
            var n = e.name;
            if (e.global && r && r.has(n)) n = r.get(n); else if (!e.unmangleable(t)) return;
            i(n);
        }
    });
    kt.DEFMETHOD("expand_names", function(r) {
        T.reset();
        T.sort();
        r = S(r);
        var n = this.find_colliding_names(r);
        var t = 0;
        this.globals.each(a);
        this.walk(new Gn(function(e) {
            if (e instanceof ct) e.variables.each(a);
        }));
        function i() {
            var e;
            do {
                e = T(t++);
            } while (n[e]);
            return e;
        }
        function a(n) {
            if (n.global && r.cache) return;
            if (n.unmangleable(r)) return;
            if (r.reserved.has[n.name]) return;
            var e = n.redefined();
            var t = e ? e.rename || e.name : i();
            n.rename = t;
            n.forEach(function(e) {
                if (e.definition() === n) e.name = t;
            });
        }
    });
    bn.DEFMETHOD("tail_node", Qn);
    On.DEFMETHOD("tail_node", function() {
        return this.expressions[this.expressions.length - 1];
    });
    kt.DEFMETHOD("compute_char_frequency", function(e) {
        e = S(e);
        T.reset();
        var n = $r.prototype.add_source_map;
        try {
            $r.prototype.add_source_map = function() {
                if (!this.unmangleable(e)) T.consider(this.name, -1);
            };
            if (e.properties) {
                zn.prototype.add_source_map = function() {
                    T.consider(this.property, -1);
                };
                Cn.prototype.add_source_map = function() {
                    t(this.property);
                };
            }
            T.consider(this.print_to_string(), 1);
        } finally {
            $r.prototype.add_source_map = n;
            delete zn.prototype.add_source_map;
            delete Cn.prototype.add_source_map;
        }
        T.sort();
        function t(e) {
            if (e instanceof Vn) {
                T.consider(e.value, -1);
            } else if (e instanceof Nn) {
                t(e.consequent);
                t(e.alternative);
            } else if (e instanceof On) {
                t(e.tail_node());
            }
        }
    });
    var T = function() {
        var i = Object.create(null);
        function e(e) {
            var n = [];
            for (var t = 0; t < e.length; t++) {
                var r = e[t];
                n.push(r);
                i[r] = -.01 * t;
            }
            return n;
        }
        var n = e("0123456789");
        var t = e("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ$_");
        var r, a;
        function o() {
            r = null;
            a = Object.create(i);
        }
        f.consider = function(e, n) {
            for (var t = e.length; --t >= 0; ) {
                a[e[t]] += n;
            }
        };
        function s(e, n) {
            return a[n] - a[e];
        }
        f.sort = function() {
            r = t.sort(s).concat(n).sort(s);
        };
        f.reset = o;
        o();
        function f(e) {
            var n = t[e % 54];
            for (e = Math.floor(e / 54); --e >= 0; e >>= 6) {
                n += r[e & 63];
            }
            return n;
        }
        return f;
    }();
    /***********************************************************************

  A JavaScript tokenizer / parser / beautifier / compressor.
  https://github.com/mishoo/UglifyJS

  -------------------------------- (C) ---------------------------------

                           Author: Mihai Bazon
                         <mihai.bazon@gmail.com>
                       http://mihai.bazon.net/blog

  Distributed under the BSD license:

    Copyright 2012 (c) Mihai Bazon <mihai.bazon@gmail.com>

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

        * Redistributions of source code must retain the above
          copyright notice, this list of conditions and the following
          disclaimer.

        * Redistributions in binary form must reproduce the above
          copyright notice, this list of conditions and the following
          disclaimer in the documentation and/or other materials
          provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER “AS IS” AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE
    LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
    OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
    TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
    THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
    SUCH DAMAGE.

 ***********************************************************************/
    "use strict";
    function hi(e, n) {
        if (!(this instanceof hi)) return new hi(e, n);
        ii.call(this, this.before, this.after);
        this.options = we(e, {
            annotations: !n,
            arguments: !n,
            arrows: !n,
            assignments: !n,
            awaits: !n,
            booleans: !n,
            collapse_vars: !n,
            comparisons: !n,
            conditionals: !n,
            dead_code: !n,
            default_values: !n,
            directives: !n,
            drop_console: false,
            drop_debugger: !n,
            evaluate: !n,
            expression: false,
            functions: !n,
            global_defs: false,
            hoist_exports: !n,
            hoist_funs: false,
            hoist_props: !n,
            hoist_vars: false,
            ie: false,
            if_return: !n,
            imports: !n,
            inline: !n,
            join_vars: !n,
            keep_fargs: n,
            keep_fnames: false,
            keep_infinity: false,
            loops: !n,
            merge_vars: !n,
            module: false,
            negate_iife: !n,
            objects: !n,
            optional_chains: !n,
            passes: 1,
            properties: !n,
            pure_funcs: null,
            pure_getters: !n && "strict",
            reduce_funcs: !n,
            reduce_vars: !n,
            rests: !n,
            sequences: !n,
            side_effects: !n,
            spreads: !n,
            strings: !n,
            switches: !n,
            templates: !n,
            top_retain: null,
            toplevel: !!(e && (e["module"] || e["top_retain"])),
            typeofs: !n,
            unsafe: false,
            unsafe_comps: false,
            unsafe_Function: false,
            unsafe_math: false,
            unsafe_proto: false,
            unsafe_regexp: false,
            unsafe_undefined: false,
            unused: !n,
            varify: !n,
            webkit: false,
            yields: !n
        }, true);
        var t = this.options["evaluate"];
        this.eval_threshold = /eager/.test(t) ? 1 / 0 : +t;
        var r = this.options["global_defs"];
        if (typeof r == "object") for (var i in r) {
            if (/^@/.test(i) && it(r, i)) {
                r[i.slice(1)] = ci(r[i], {
                    expression: true
                });
            }
        }
        if (this.options["inline"] === true) this.options["inline"] = 4;
        this.drop_fargs = this.options["keep_fargs"] ? hn : function(e, n) {
            if (e.length_read) return false;
            var t = e.name;
            if (!t) return n && n.TYPE == "Call" && n.expression === e;
            if (t.fixed_value() !== e) return false;
            var r = t.definition();
            if (r.direct_access) return false;
            var i = r.escaped;
            return i && i.depth != 1;
        };
        if (this.options["module"]) this.directives["use strict"] = true;
        var a = this.options["pure_funcs"];
        if (typeof a == "function") {
            this.pure_funcs = a;
        } else if (typeof a == "string") {
            this.pure_funcs = function(e) {
                var n;
                if (e instanceof qn) {
                    n = e.expression;
                } else if (e instanceof Vr) {
                    n = e.tag;
                }
                return !(n && a === n.print_to_string());
            };
        } else if (Array.isArray(a)) {
            this.pure_funcs = function(e) {
                var n;
                if (e instanceof qn) {
                    n = e.expression;
                } else if (e instanceof Vr) {
                    n = e.tag;
                }
                return !(n && Jn(n.print_to_string(), a));
            };
        } else {
            this.pure_funcs = vn;
        }
        var o = this.options["sequences"];
        this.sequences_limit = o == 1 ? 800 : o | 0;
        var s = this.options["top_retain"];
        if (s instanceof RegExp) {
            this.top_retain = function(e) {
                return s.test(e.name);
            };
        } else if (typeof s == "function") {
            this.top_retain = s;
        } else if (s) {
            if (typeof s == "string") {
                s = s.split(/,/);
            }
            this.top_retain = function(e) {
                return Jn(e.name, s);
            };
        }
        var f = this.options["toplevel"];
        this.toplevel = typeof f == "string" ? {
            funcs: /funcs/.test(f),
            vars: /vars/.test(f)
        } : {
            funcs: f,
            vars: f
        };
    }
    hi.prototype = new ii(function(e, n, t) {
        if (e._squeezed) return e;
        var r = e instanceof kn;
        if (r) {
            if (this.option("arrows") && At(e) && e.value) {
                e.body = [ e.first_statement() ];
                e.value = null;
            }
            e.hoist_properties(this);
            e.hoist_declarations(this);
            e.process_returns(this);
        }
        n(e, this);
        n(e, this);
        var i = e.optimize(this);
        if (r && i === e && !this.has_directive("use asm") && !i.pinned()) {
            i.drop_unused(this);
            if (i.merge_variables(this)) i.drop_unused(this);
            n(i, this);
        }
        if (i === e) i._squeezed = true;
        return i;
    });
    hi.prototype.option = function(e) {
        return this.options[e];
    };
    hi.prototype.exposed = function(e) {
        if (e.exported) return true;
        if (e.undeclared) return true;
        if (!(e.global || e.scope.resolve() instanceof kt)) return false;
        var n = this.toplevel;
        return !_n(e.orig, function(e) {
            return n[e instanceof jr ? "funcs" : "vars"];
        });
    };
    hi.prototype.compress = function(e) {
        e = e.resolve_defines(this);
        e.hoist_exports(this);
        if (this.option("expression")) e.process_expression(true);
        var n = this.options.merge_vars;
        var t = +this.options.passes || 1;
        var r = 1 / 0;
        var i = false;
        var a = {
            ie: this.option("ie")
        };
        for (var o = 0; o < t; o++) {
            e.figure_out_scope(a);
            if (o > 0 || this.option("reduce_vars")) e.reset_opt_flags(this);
            this.options.merge_vars = n && (i || o == t - 1);
            e = e.transform(this);
            if (t > 1) {
                var s = 0;
                e.walk(new Gn(function() {
                    s++;
                }));
                bn.info("pass {pass}: last_count: {min_count}, count: {count}", {
                    pass: o,
                    min_count: r,
                    count: s
                });
                if (s < r) {
                    r = s;
                    i = false;
                } else if (i) {
                    break;
                } else {
                    i = true;
                }
            }
        }
        if (this.option("expression")) e.process_expression(false);
        return e;
    };
    (function(e) {
        e(bn, function(e, n) {
            return e;
        });
        kt.DEFMETHOD("hoist_exports", function(e) {
            if (!e.option("hoist_exports")) return;
            var n = this.body, t = [];
            for (var r = 0; r < n.length; r++) {
                var i = n[r];
                if (i instanceof hr) {
                    n[r] = i = i.body;
                    if (i instanceof cr) {
                        i.definitions.forEach(function(e) {
                            e.name.match_symbol(a, true);
                        });
                    } else {
                        a(i.name);
                    }
                } else if (i instanceof mr) {
                    n.splice(r--, 1);
                    [].push.apply(t, i.properties);
                }
            }
            if (t.length) n.push(Fe(mr, this, {
                properties: t
            }));
            function a(e) {
                if (!(e instanceof zr)) return;
                var n = Fe(Yr, e);
                n.alias = Fe(Vn, n, {
                    value: n.name
                });
                t.push(n);
            }
        });
        kn.DEFMETHOD("process_expression", function(i, a) {
            var o = this;
            var s = new ii(function(e) {
                if (i) {
                    if (e instanceof ft) e = Fe(wn, e, {
                        body: Fe(Vn, e)
                    });
                    if (e instanceof wn) {
                        return a ? a(e) : Fe(Sn, e, {
                            value: e.body
                        });
                    }
                } else if (e instanceof Sn) {
                    if (a) return a(e);
                    var n = e.value;
                    if (n instanceof Vn) return Fe(ft, n);
                    return Fe(wn, e, {
                        body: n || Fe(Pn, e, {
                            operator: "void",
                            expression: Fe(Wn, e, {
                                value: 0
                            })
                        })
                    });
                }
                if (e instanceof pt) {
                    if (e instanceof En) {
                        if (e !== o) return e;
                    } else if (i === "awaits" && e instanceof sr) {
                        if (e.bfinally) return e;
                    }
                    for (var t = e.body.length; --t >= 0; ) {
                        var r = e.body[t];
                        if (!L(r, true)) {
                            e.body[t] = r.transform(s);
                            break;
                        }
                    }
                } else if (e instanceof Tn) {
                    e.body = e.body.transform(s);
                    if (e.alternative) e.alternative = e.alternative.transform(s);
                } else if (e instanceof xt) {
                    e.body = e.body.transform(s);
                }
                return e;
            });
            o.transform(s);
        });
        kt.DEFMETHOD("unwrap_expression", function() {
            var e = this;
            switch (e.body.length) {
              case 0:
                return Fe(Pn, e, {
                    operator: "void",
                    expression: Fe(Wn, e, {
                        value: 0
                    })
                });

              case 1:
                var n = e.body[0];
                if (n instanceof ft) return Fe(Vn, n);
                if (n instanceof wn) return n.body;

              default:
                return Fe(qn, e, {
                    expression: Fe(Ft, e, {
                        argnames: [],
                        body: e.body
                    }).init_vars(e),
                    args: []
                });
            }
        });
        bn.DEFMETHOD("wrap_expression", function() {
            var e = this;
            if (!ut(e)) e = Fe(wn, e, {
                body: e
            });
            if (!(e instanceof kt)) e = Fe(kt, e, {
                body: [ e ]
            });
            return e;
        });
        function q(e, n) {
            var t = n.get_property();
            if (t instanceof bn) return;
            var r;
            if (e instanceof Hn) {
                var i = e.elements;
                if (t == "length") return fe(i.length, e);
                if (typeof t == "number" && t in i) r = i[t];
            } else if (e instanceof En) {
                if (t == "length") {
                    e.length_read = true;
                    return fe(e.argnames.length, e);
                }
            } else if (e instanceof Rn) {
                t = "" + t;
                var a = e.properties;
                for (var o = a.length; --o >= 0; ) {
                    var s = a[o];
                    if (!un(s)) return;
                    if (!r && a[o].key === t) r = a[o].value;
                }
            }
            return r instanceof Ln && r.fixed_value() || r;
        }
        function p(e, n) {
            if (e instanceof ni) return b.Boolean[n];
            if (e instanceof Wn) return b.Number[n];
            if (e instanceof Vn) return b.String[n];
            if (n == "valueOf") return false;
            if (e instanceof Hn) return b.Array[n];
            if (e instanceof En) return b.Function[n];
            if (e instanceof Rn) return b.Object[n];
            if (e instanceof Gr) return b.RegExp[n] && !e.value.global;
        }
        function $e(e, n, t, r, i, a, o) {
            var s = n.parent(i);
            if (e.option("unsafe") && s instanceof zn && p(r, s.property)) {
                return;
            }
            var f = di(t, s);
            if (f) return f;
            if (i == 0 && r && r.is_constant()) return;
            if (s instanceof Hn) return $e(e, n, s, s, i + 1);
            if (s instanceof In) switch (s.operator) {
              case "=":
                return $e(e, n, s, r, i + 1, a, o);

              case "&&=":
              case "||=":
              case "??=":
                return $e(e, n, s, s, i + 1);

              default:
                return;
            }
            if (s instanceof jn) {
                if (!He[s.operator]) return;
                return $e(e, n, s, s, i + 1);
            }
            if (s instanceof qn) {
                return !a && s.expression === t && !s.is_expr_pure(e) && (!(r instanceof Tt) || !(s instanceof gr) && r.contains_this());
            }
            if (s instanceof Nn) {
                if (s.condition === t) return;
                return $e(e, n, s, s, i + 1);
            }
            if (s instanceof bt) return s.init === t;
            if (s instanceof Ar) {
                if (s.value !== t) return;
                var u = n.parent(i + 1);
                return $e(e, n, u, u, i + 2);
            }
            if (s instanceof $n) {
                if (s.expression !== t) return;
                var c = q(r, s);
                return (!a || o) && $e(e, n, s, c, i + 1);
            }
            if (s instanceof On) {
                if (s.tail_node() !== t) return;
                return $e(e, n, s, r, i + 1, a, o);
            }
        }
        function M(e) {
            return e instanceof Rt || e instanceof En;
        }
        function Re(e) {
            return e instanceof Rt || e instanceof Ht || e instanceof Ft;
        }
        function ze(e) {
            return e.name == "arguments" && e.scope.uses_arguments;
        }
        function O(e, n) {
            do {
                if (e === n) return false;
                if (n instanceof kn) return true;
            } while (n = n.parent_scope);
        }
        function Ce(e, n, t) {
            var r = e.redef || e.definition();
            if (e.in_arg && li(r)) return false;
            return _n(r.orig, function(e) {
                if (e instanceof Cr || e instanceof Fr) {
                    if (e instanceof Mr) return true;
                    return n && ae(n, e);
                }
                return !(t && e instanceof Nr);
            });
        }
        function Be(e, n, t, r) {
            if (r instanceof In) return r.operator == "=" && r.right === t;
            if (r instanceof qn) return r.expression !== t || r instanceof gr;
            if (r instanceof Vt) return r.value === t && !r.static;
            if (r instanceof Qt) return r.value === t && n.resolve() !== e.scope.resolve();
            if (r instanceof An) return r.value === t;
        }
        function $(e, n) {
            var t = Fe(Ln, e);
            t.fixed = n || Fe(Qr, e);
            return t;
        }
        function z(r, i) {
            return function(e) {
                var n = r(e);
                var e = $(n, i);
                var t = n.definition();
                t.references.push(e);
                t.replaced++;
                return e;
            };
        }
        var C = /^(0|[1-9][0-9]*)$/;
        (function(e) {
            e(bn, Kn);
            function a(e, n, t) {
                t.assignments = 0;
                t.bool_return = 0;
                t.drop_return = 0;
                t.cross_loop = false;
                t.direct_access = false;
                t.escaped = [];
                t.fixed = !t.const_redefs && !t.scope.pinned() && !n.exposed(t) && !(t.init instanceof Tt && t.init !== t.scope) && t.init;
                t.reassigned = 0;
                t.recursive_refs = 0;
                t.references = [];
                t.single_use = undefined;
            }
            function s(n, t, e) {
                e.variables.each(function(e) {
                    a(n, t, e);
                });
            }
            function d(t, r, i) {
                i.fn_defs = [];
                i.variables.each(function(e) {
                    a(t, r, e);
                    var n = e.init;
                    if (n instanceof jt) {
                        i.fn_defs.push(n);
                        n.safe_ids = null;
                    }
                    if (e.fixed === null) {
                        e.safe_ids = t.safe_ids;
                        g(t, e);
                    } else if (e.fixed) {
                        t.loop_ids[e.id] = t.in_loop;
                        g(t, e);
                    }
                });
                i.may_call_this = function() {
                    i.may_call_this = i.contains_this() ? vn : hn;
                };
                if (i.uses_arguments) i.each_argname(function(e) {
                    e.definition().last_ref = false;
                });
                if (r.option("ie")) i.variables.each(function(e) {
                    var n = e.orig[0].definition();
                    if (n !== e) n.fixed = false;
                });
            }
            function o(e, n) {
                var t = n.safe_ids;
                return t === undefined || t === e.safe_ids;
            }
            function f(e, n) {
                var t = e.fn_scanning;
                e.fn_scanning = n;
                n.walk(e);
                e.fn_scanning = t;
            }
            function u(t, r) {
                r.enclosed.forEach(function(e) {
                    if (r.variables.get(e.name) === e) return;
                    if (y(t, e)) return;
                    e.single_use = false;
                    var n = e.fixed;
                    if (typeof n == "function") n = n();
                    if (n instanceof En && n.safe_ids !== undefined) return;
                    e.fixed = false;
                });
            }
            function h(e, n, t) {
                var r = t.safe_ids;
                if (r === undefined) return;
                if (r === false) return;
                if (t.parent_scope.resolve().may_call_this === vn) {
                    if (Jn(t, e.fn_visited)) u(e, t);
                } else if (r) {
                    var i = Jn(t, e.fn_visited);
                    if (r === e.safe_ids) {
                        if (!i) f(e, t);
                    } else if (i) {
                        u(e, t);
                    } else {
                        t.safe_ids = false;
                    }
                } else if (e.fn_scanning && e.fn_scanning !== n.scope.resolve()) {
                    t.safe_ids = false;
                } else {
                    t.safe_ids = e.safe_ids;
                    f(e, t);
                }
            }
            function v(n, e) {
                var t = e.fn_defs;
                var r = e.may_call_this === vn ? t : t.filter(function(e) {
                    if (e.safe_ids === false) return true;
                    e.safe_ids = n.safe_ids;
                    f(n, e);
                    return false;
                });
                _(n);
                r.forEach(function(e) {
                    e.safe_ids = n.safe_ids;
                    f(n, e);
                });
                t.forEach(function(e) {
                    e.safe_ids = undefined;
                });
                e.fn_defs = undefined;
                e.may_call_this = undefined;
            }
            function m(e, n) {
                var t = Object.create(e.safe_ids);
                if (!n) t.seq = {};
                e.safe_ids = t;
            }
            function _(e) {
                e.safe_ids = Object.getPrototypeOf(e.safe_ids);
            }
            function g(e, n) {
                e.safe_ids[n.id] = {};
            }
            function b(e, n) {
                e.references.push(n);
                if (e.last_ref !== false) e.last_ref = n;
            }
            function y(e, n) {
                if (n.single_use == "m") return false;
                var t = e.safe_ids[n.id];
                if (t) {
                    var r = it(e.safe_ids, n.id);
                    if (!r) {
                        var i = e.safe_ids.seq;
                        if (!t.read) {
                            t.read = i;
                        } else if (t.read !== i) {
                            t.read = true;
                        }
                    }
                    if (n.fixed == null) {
                        if (ze(n)) return false;
                        if (n.global && n.name == "arguments") return false;
                        e.loop_ids[n.id] = null;
                        n.fixed = Fe(Qr, n.orig[0]);
                        if (r) n.safe_ids = undefined;
                        return true;
                    }
                    return !t.assign || t.assign === e.safe_ids;
                }
                return n.fixed instanceof jt;
            }
            function w(e, n, t) {
                if (!t) {
                    if (li(n) && n.scope.uses_arguments && !e.has_directive("use strict")) return false;
                    if (!_n(n.orig, function(e) {
                        return !(e instanceof Cr);
                    })) return false;
                }
                if (n.fixed === undefined) return t || _n(n.orig, function(e) {
                    return !(e instanceof Fr);
                });
                if (n.fixed === false || n.fixed === 0) return false;
                var r = e.safe_ids[n.id];
                if (n.safe_ids) {
                    n.safe_ids[n.id] = false;
                    n.safe_ids = undefined;
                    return n.fixed === null || it(e.safe_ids, n.id) && !r.read;
                }
                if (!it(e.safe_ids, n.id)) {
                    if (!r) return false;
                    if (r.read || e.in_loop) {
                        var i = e.find_parent(ct);
                        if (i instanceof Rt) return false;
                        if (n.scope.resolve() !== i.resolve()) return false;
                    }
                    r.assign = r.assign && r.assign !== e.safe_ids ? true : e.safe_ids;
                }
                if (n.fixed != null && r.read) {
                    if (r.read !== e.safe_ids.seq) return false;
                    if (e.loop_ids[n.id] !== e.in_loop) return false;
                }
                return y(e, n) && _n(n.orig, function(e) {
                    return !(e instanceof Nr);
                });
            }
            function c(e, n) {
                return e.option("unused") && !n.scope.pinned() && n.single_use !== false && n.references.length - n.recursive_refs == 1 && !(li(n) && n.scope.uses_arguments);
            }
            function x(e) {
                if (!e) return false;
                if (e instanceof In) {
                    var n = e.operator;
                    return n == "=" ? x(e.right) : !He[n.slice(0, -1)];
                }
                if (e instanceof On) return x(e.tail_node());
                return e.is_constant() || M(e) || e instanceof Rr;
            }
            function l(e, n) {
                if (n instanceof Hn) return true;
                if (n instanceof jn) return He[n.operator];
                if (n instanceof Nn) return n.condition !== e;
                if (n instanceof On) return n.tail_node() === e;
                if (n instanceof Mn) return true;
            }
            function k(e, n, t, r, i, a, o) {
                var s = e.parent(a);
                if (i && i.is_constant()) return;
                if (Be(n, t, r, s)) {
                    n.escaped.push(s);
                    if (o > 1 && !(i && i.is_constant_expression(t))) o = 1;
                    if (!n.escaped.depth || n.escaped.depth > o) n.escaped.depth = o;
                    if (n.scope.resolve() !== t.resolve()) n.escaped.cross_scope = true;
                    if (n.fixed) n.fixed.escaped = n.escaped;
                    return;
                } else if (l(r, s)) {
                    k(e, n, t, s, s, a + 1, o);
                } else if (s instanceof Ar && s.value === r) {
                    var f = e.parent(a + 1);
                    k(e, n, t, f, f, a + 2, o);
                } else if (s instanceof $n && s.expression === r) {
                    i = q(i, s);
                    k(e, n, t, s, i, a + 1, o + 1);
                    if (i) return;
                }
                if (a > 0) return;
                if (s instanceof qn && s.expression === r) return;
                if (s instanceof On && s.tail_node() !== r) return;
                if (s instanceof wn) return;
                if (s instanceof Fn && !pi[s.operator]) return;
                n.direct_access = true;
                if (n.fixed) n.fixed.direct_access = true;
            }
            function E(e) {
                if (!(e instanceof Cn)) return;
                var n = e.expression;
                if (!(n instanceof Ln)) return;
                var t = n.definition();
                if (!ze(t)) return;
                var r = e.property;
                if (r.is_constant()) r = r.value;
                if (!(r instanceof bn) && !C.test(r)) return;
                t.reassigned++;
                (r instanceof bn ? t.scope.argnames : [ t.scope.argnames[r] ]).forEach(function(e) {
                    if (e instanceof Bn) e.definition().fixed = false;
                });
            }
            function p(n, t) {
                var r, i;
                return function() {
                    var e = n();
                    if (r !== e) {
                        r = e;
                        i = t(e);
                    }
                    return i;
                };
            }
            function S(t, r, i) {
                var a, o;
                return function() {
                    if (o === r) return r;
                    var e = i();
                    var n = j(t, e, true);
                    if (n instanceof bn) {
                        o = r;
                    } else if (a !== e) {
                        a = e;
                        o = n === undefined ? Pe(r, [ e, r.value ]) : e;
                    }
                    return o;
                };
            }
            function T(a, n, e, o, t) {
                var s = new Gn(function(r) {
                    if (r instanceof Dn) {
                        D(r);
                        m(a, true);
                        r.value.walk(a);
                        _(a);
                        var e = o;
                        if (e) o = S(n, r, e);
                        r.name.walk(s);
                        o = e;
                        return true;
                    }
                    if (r instanceof kr) {
                        D(r);
                        var e = o;
                        r.elements.forEach(function(n, t) {
                            if (n instanceof Zr) return D(n);
                            if (e) o = p(e, function(e) {
                                return Fe(Cn, n, {
                                    expression: e,
                                    property: Fe(Wn, n, {
                                        value: t
                                    })
                                });
                            });
                            n.walk(s);
                        });
                        if (r.rest) {
                            var i;
                            if (e) o = n.option("rests") && p(e, function(e) {
                                if (!(e instanceof Hn)) return r;
                                for (var n = 0, t = r.elements.length; n < t; n++) {
                                    if (e.elements[n] instanceof Mn) return r;
                                }
                                if (!i) i = Fe(Hn, r, {});
                                i.elements = e.elements.slice(t);
                                return i;
                            });
                            r.rest.walk(s);
                        }
                        o = e;
                        return true;
                    }
                    if (r instanceof Sr) {
                        D(r);
                        var e = o;
                        r.properties.forEach(function(r) {
                            D(r);
                            if (r.key instanceof bn) {
                                m(a);
                                r.key.walk(a);
                                _(a);
                            }
                            if (e) o = p(e, function(e) {
                                var n = r.key;
                                var t = Cn;
                                if (typeof n == "string") {
                                    if (ai(n)) {
                                        t = zn;
                                    } else {
                                        n = fe(n, r);
                                    }
                                }
                                return Fe(t, r, {
                                    expression: e,
                                    property: n
                                });
                            });
                            r.value.walk(s);
                        });
                        if (r.rest) {
                            o = false;
                            r.rest.walk(s);
                        }
                        o = e;
                        return true;
                    }
                    t(r, o, function() {
                        var e = a.stack.length;
                        for (var n = 0, t = s.stack.length - 1; n < t; n++) {
                            a.stack.push(s.stack[n]);
                        }
                        r.walk(a);
                        a.stack.length = e;
                    });
                    return true;
                });
                e.walk(s);
            }
            function A(i, e, n) {
                var a = this;
                a.inlined = false;
                var o = i.parent();
                var t = !Dt(a) && !qt(a);
                var r = !t;
                var s = false;
                a.walk(new Gn(function(e) {
                    if (r) return s = true;
                    if (e instanceof Sn) return r = true;
                    if (e instanceof kn && e !== a) return true;
                }));
                if (s) m(i, t);
                d(i, n, a);
                var f = !a.uses_arguments || i.has_directive("use strict");
                a.argnames.forEach(function(t, e) {
                    var r = o.args[e];
                    T(i, n, t, function() {
                        var e = a.argnames.indexOf(t);
                        var n = e < 0 ? r : o.args[e];
                        if (n instanceof On && n.expressions.length < 2) n = n.expressions[0];
                        return n || Fe(Qr, o);
                    }, p);
                });
                var u = a.rest, c;
                if (u) T(i, n, u, n.option("rests") && function() {
                    if (a.rest !== u) return u;
                    if (!c) c = Fe(Hn, a, {});
                    c.elements = o.args.slice(a.argnames.length);
                    return c;
                }, p);
                Ot(a, i);
                var l = i.safe_ids;
                v(i, a);
                if (!s) i.safe_ids = l;
                return true;
                function p(e, n) {
                    var t = e.definition();
                    if (n && f && t.fixed === undefined) {
                        g(i, t);
                        i.loop_ids[t.id] = i.in_loop;
                        t.fixed = n;
                        t.fixed.assigns = [ e ];
                    } else {
                        t.fixed = false;
                    }
                }
            }
            e(In, function(a, e, n) {
                var o = this;
                var s = o.left;
                var f = o.right;
                var t = s instanceof Ln && s.definition();
                var r = t || s instanceof Yn;
                switch (o.operator) {
                  case "=":
                    if (s.equals(f) && !s.has_side_effects(n)) {
                        f.walk(a);
                        l(s);
                        o.redundant = true;
                        return true;
                    }
                    if (t && f instanceof Tt) {
                        p();
                        f.parent_scope.resolve().fn_defs.push(f);
                        f.safe_ids = null;
                        if (!t.fixed || !o.write_only) h(a, t, f);
                        return true;
                    }
                    if (r) {
                        f.walk(a);
                        p();
                        return true;
                    }
                    E(s);
                    return;

                  case "&&=":
                  case "||=":
                  case "??=":
                    var i = true;

                  default:
                    if (!r) {
                        E(s);
                        return d();
                    }
                    t.assignments++;
                    var u = t.fixed;
                    if ($e(n, a, o, o, 0)) {
                        t.fixed = false;
                        return d();
                    }
                    var c = y(a, t);
                    if (i) m(a, true);
                    f.walk(a);
                    if (i) _(a);
                    if (c && !s.in_arg && w(a, t)) {
                        b(t, s);
                        g(a, t);
                        if (t.single_use) t.single_use = false;
                        s.fixed = t.fixed = function() {
                            return Fe(jn, o, {
                                operator: o.operator.slice(0, -1),
                                left: $(s, u),
                                right: o.right
                            });
                        };
                        s.fixed.assigns = !u || !u.assigns ? [ t.orig[0] ] : u.assigns.slice();
                        s.fixed.assigns.push(o);
                        s.fixed.to_binary = z(function(e) {
                            return e.left;
                        }, u);
                    } else {
                        s.walk(a);
                        t.fixed = false;
                    }
                    return true;
                }
                function l(e) {
                    D(e);
                    if (e instanceof zn) {
                        l(e.expression);
                    } else if (e instanceof Cn) {
                        l(e.expression);
                        e.property.walk(a);
                    } else if (e instanceof Ln) {
                        var n = e.definition();
                        b(n, e);
                        if (n.fixed) {
                            e.fixed = n.fixed;
                            if (e.fixed.assigns) {
                                e.fixed.assigns.push(o);
                            } else {
                                e.fixed.assigns = [ o ];
                            }
                        }
                    } else {
                        e.walk(a);
                    }
                }
                function p() {
                    var e = t && Ze(a, t);
                    var i = $e(n, a, o, f, 0, x(f), e);
                    T(a, n, s, function() {
                        return o.right;
                    }, function(e, n, t) {
                        if (!(e instanceof Ln)) {
                            E(e);
                            t();
                            return;
                        }
                        var r = e.definition();
                        r.assignments++;
                        if (!n || e.in_arg || !w(a, r)) {
                            t();
                            r.fixed = false;
                        } else {
                            b(r, e);
                            g(a, r);
                            if (s instanceof Yn || r.orig.length == 1 && r.orig[0] instanceof jr) {
                                r.single_use = false;
                            }
                            a.loop_ids[r.id] = a.in_loop;
                            r.fixed = i ? 0 : n;
                            e.fixed = n;
                            e.fixed.assigns = [ o ];
                            k(a, r, e.scope, o, f, 0, 1);
                        }
                    });
                }
                function d() {
                    if (!i) return;
                    s.walk(a);
                    m(a, true);
                    f.walk(a);
                    _(a);
                    return true;
                }
            });
            e(jn, function(e) {
                if (!He[this.operator]) return;
                this.left.walk(e);
                m(e, true);
                this.right.walk(e);
                _(e);
                return true;
            });
            e(ct, function(e, n, t) {
                s(e, t, this);
            });
            e(qn, function(n, e) {
                var t = this;
                var r = t.expression;
                if (r instanceof Tt) {
                    var i = Ve(t);
                    t.args.forEach(function(e) {
                        e.walk(n);
                        if (e instanceof Mn) i = false;
                    });
                    if (i) r.reduce_vars = A;
                    r.walk(n);
                    if (i) delete r.reduce_vars;
                    return true;
                }
                if (t.TYPE == "Call") switch (n.in_boolean_context()) {
                  case "d":
                    var a = true;

                  case true:
                    f(r, a);
                }
                r.walk(n);
                var o = t.optional;
                if (o) m(n, true);
                t.args.forEach(function(e) {
                    e.walk(n);
                });
                if (o) _(n);
                var s = r instanceof Ln && r.fixed_value();
                if (s instanceof En) {
                    h(n, r.definition(), s);
                } else {
                    n.find_parent(kn).may_call_this();
                }
                return true;
                function f(e, n) {
                    if (e instanceof In) {
                        if (e.operator != "=") return;
                        f(e.left, n);
                        f(e.right, n);
                    } else if (e instanceof jn) {
                        if (!He[e.operator]) return;
                        f(e.left, n);
                        f(e.right, n);
                    } else if (e instanceof Nn) {
                        f(e.consequent, n);
                        f(e.alternative, n);
                    } else if (e instanceof Ln) {
                        var t = e.definition();
                        t.bool_return++;
                        if (n) t.drop_return++;
                    }
                }
            });
            e(Rt, function(n, e, t) {
                var r = this;
                s(n, t, r);
                if (r.extends) r.extends.walk(n);
                var i = r.properties.filter(function(e) {
                    D(e);
                    if (e.key instanceof bn) {
                        n.push(e);
                        e.key.walk(n);
                        n.pop();
                    }
                    return e.value;
                });
                if (r.name) {
                    var a = r.name.definition();
                    var o = n.parent();
                    if (o instanceof hr || o instanceof vr) a.single_use = false;
                    if (w(n, a, true)) {
                        g(n, a);
                        n.loop_ids[a.id] = n.in_loop;
                        a.fixed = function() {
                            return r;
                        };
                        a.fixed.assigns = [ r ];
                        if (!Ye(a)) a.single_use = false;
                    } else {
                        a.fixed = false;
                    }
                }
                i.forEach(function(e) {
                    n.push(e);
                    if (!e.static || ne(e) && e.value.contains_this()) {
                        m(n);
                        e.value.walk(n);
                        _(n);
                    } else {
                        e.value.walk(n);
                    }
                    n.pop();
                });
                return true;
            });
            e(Et, function(e, n, t) {
                var r = this;
                m(e, true);
                d(e, t, r);
                n();
                v(e, r);
                return true;
            });
            e(Nn, function(e) {
                this.condition.walk(e);
                m(e, true);
                this.consequent.walk(e);
                _(e);
                m(e, true);
                this.alternative.walk(e);
                _(e);
                return true;
            });
            e(Dn, function(e) {
                m(e, true);
                this.value.walk(e);
                _(e);
                this.name.walk(e);
                return true;
            });
            e(mt, function(e) {
                var n = e.in_loop;
                e.in_loop = this;
                m(e);
                this.body.walk(e);
                if (X(this, e.parent())) {
                    _(e);
                    m(e);
                }
                this.condition.walk(e);
                _(e);
                e.in_loop = n;
                return true;
            });
            e(gt, function(e, n, t) {
                var r = this;
                s(e, t, r);
                if (r.init) r.init.walk(e);
                var i = e.in_loop;
                e.in_loop = r;
                m(e);
                if (r.condition) r.condition.walk(e);
                r.body.walk(e);
                if (r.step) {
                    if (X(r, e.parent())) {
                        _(e);
                        m(e);
                    }
                    r.step.walk(e);
                }
                _(e);
                e.in_loop = i;
                return true;
            });
            e(bt, function(e, n, t) {
                var r = this;
                s(e, t, r);
                r.object.walk(e);
                var i = e.in_loop;
                e.in_loop = r;
                m(e);
                var a = r.init;
                if (a instanceof cr) {
                    a.definitions[0].name.mark_symbol(function(e) {
                        if (e instanceof zr) {
                            var n = e.definition();
                            n.assignments++;
                            n.fixed = false;
                        }
                    }, e);
                } else if (a instanceof Yn || a instanceof Ln) {
                    a.mark_symbol(function(e) {
                        if (e instanceof Ln) {
                            var n = e.definition();
                            b(n, e);
                            n.assignments++;
                            if (!e.is_immutable()) n.fixed = false;
                        }
                    }, e);
                } else {
                    a.walk(e);
                }
                r.body.walk(e);
                _(e);
                e.in_loop = i;
                return true;
            });
            e(Tn, function(e) {
                this.condition.walk(e);
                m(e, true);
                this.body.walk(e);
                _(e);
                if (this.alternative) {
                    m(e, true);
                    this.alternative.walk(e);
                    _(e);
                }
                return true;
            });
            e(dt, function(e) {
                m(e, true);
                this.body.walk(e);
                _(e);
                return true;
            });
            e(En, function(e, n, t) {
                var r = this;
                if (!o(e, r)) return true;
                if (!nt(e.fn_visited, r)) return true;
                r.inlined = false;
                m(e);
                d(e, t, r);
                n();
                v(e, r);
                if (r.name) k(e, r.name.definition(), r, r.name, r, 0, 1);
                return true;
            });
            e(jt, function(e, n, t) {
                var r = this;
                var i = r.name.definition();
                var a = e.parent();
                if (a instanceof hr || a instanceof vr) i.single_use = false;
                if (!o(e, r)) return true;
                if (!nt(e.fn_visited, r)) return true;
                r.inlined = false;
                m(e);
                d(e, t, r);
                n();
                v(e, r);
                return true;
            });
            e(Cn, function(e) {
                if (!this.optional) return;
                this.expression.walk(e);
                m(e, true);
                this.property.walk(e);
                _(e);
                return true;
            });
            e(rr, function(n, e, t) {
                var r = this;
                s(n, t, r);
                r.expression.walk(n);
                var i = true;
                r.body.forEach(function(e) {
                    if (e instanceof ar) return;
                    e.expression.walk(n);
                    if (i) {
                        i = false;
                        m(n, true);
                    }
                });
                if (!i) _(n);
                lt(r, n);
                return true;
            });
            e(ir, function(e) {
                m(e, true);
                lt(this, e);
                _(e);
                return true;
            });
            e(Hr, function() {
                this.definition().fixed = false;
            });
            e(Mr, function() {
                this.definition().fixed = false;
            });
            e(Ln, function(r, e, n) {
                var t = this;
                var i = t.definition();
                var a = i.fixed || i.last_ref && i.last_ref.fixed;
                b(i, t);
                if (i.references.length == 1 && !i.fixed && i.orig[0] instanceof jr) {
                    r.loop_ids[i.id] = r.in_loop;
                }
                var o = Ze(r, i);
                if (o) o.enclosed.forEach(function(e) {
                    if (i === e) return;
                    if (e.scope.resolve() === o) return;
                    var n = e.fixed && e.fixed.assigns;
                    if (!n) return;
                    if (n[n.length - 1] instanceof An) return;
                    var t = r.safe_ids[e.id];
                    if (!t) return;
                    t.assign = true;
                });
                if (i.single_use == "m" && i.fixed) {
                    i.fixed = 0;
                    i.single_use = false;
                }
                switch (i.fixed) {
                  case 0:
                    if (!y(r, i)) i.fixed = false;

                  case false:
                    var s = i.redefined();
                    if (s && O(i.scope, t.scope)) s.single_use = false;
                    break;

                  case undefined:
                    i.fixed = false;
                    break;

                  default:
                    if (!y(r, i)) {
                        i.fixed = false;
                        break;
                    }
                    if (t.in_arg && i.orig[0] instanceof Nr) t.fixed = i.scope;
                    var f = t.fixed_value();
                    if (o) {
                        i.recursive_refs++;
                    } else if (f && c(n, i)) {
                        i.in_loop = r.loop_ids[i.id] !== r.in_loop;
                        i.single_use = M(f) && !f.pinned() && (!i.in_loop || r.parent() instanceof qn) || !i.in_loop && i.scope === t.scope.resolve() && f.is_constant_expression();
                    } else {
                        i.single_use = false;
                    }
                    if ($e(n, r, t, f, 0, x(f), o)) {
                        if (i.single_use) {
                            i.single_use = "m";
                        } else {
                            i.fixed = 0;
                        }
                    }
                    if (i.fixed && r.loop_ids[i.id] !== r.in_loop) i.cross_loop = true;
                    k(r, i, t.scope, t, f, 0, 1);
                    break;
                }
                if (!t.fixed) t.fixed = i.fixed === 0 ? a : i.fixed;
                var u;
                if (f instanceof En && !((u = r.parent()) instanceof qn && u.expression === t)) {
                    h(r, i, f);
                }
            });
            e(Vr, function(n, e) {
                var t = this;
                var r = t.tag;
                if (!r) return;
                if (r instanceof Tt) {
                    t.expressions.forEach(function(e) {
                        e.walk(n);
                    });
                    r.walk(n);
                    return true;
                }
                r.walk(n);
                t.expressions.forEach(function(e) {
                    e.walk(n);
                });
                var i = r instanceof Ln && r.fixed_value();
                if (i instanceof En) {
                    h(n, r.definition(), i);
                } else {
                    n.find_parent(kn).may_call_this();
                }
                return true;
            });
            e(kt, function(n, e, t) {
                var r = this;
                r.globals.each(function(e) {
                    a(n, t, e);
                });
                m(n, true);
                d(n, t, r);
                e();
                v(n, r);
                return true;
            });
            e(sr, function(e, n, t) {
                var r = this;
                s(e, t, r);
                m(e, true);
                lt(r, e);
                _(e);
                if (r.bcatch) {
                    m(e, true);
                    r.bcatch.walk(e);
                    _(e);
                }
                if (r.bfinally) r.bfinally.walk(e);
                return true;
            });
            e(Fn, function(e, n) {
                var t = this;
                if (!fi[t.operator]) return;
                var r = t.expression;
                if (!(r instanceof Ln)) {
                    E(r);
                    return;
                }
                var i = r.definition();
                i.assignments++;
                var a = i.fixed;
                if (y(e, i) && !r.in_arg && w(e, i)) {
                    b(i, r);
                    g(e, i);
                    if (i.single_use) i.single_use = false;
                    i.fixed = function() {
                        return Fe(jn, t, {
                            operator: t.operator.slice(0, -1),
                            left: Fe(Pn, t, {
                                operator: "+",
                                expression: $(r, a)
                            }),
                            right: Fe(Wn, t, {
                                value: 1
                            })
                        });
                    };
                    i.fixed.assigns = a && a.assigns ? a.assigns.slice() : [];
                    i.fixed.assigns.push(t);
                    if (t instanceof Pn) {
                        r.fixed = i.fixed;
                    } else {
                        r.fixed = function() {
                            return Fe(Pn, t, {
                                operator: "+",
                                expression: $(r, a)
                            });
                        };
                        r.fixed.assigns = a && a.assigns;
                        r.fixed.to_prefix = z(function(e) {
                            return e.expression;
                        }, i.fixed);
                    }
                } else {
                    r.walk(e);
                    i.fixed = false;
                }
                return true;
            });
            e(An, function(r, e, n) {
                var i = this;
                var t = i.value;
                if (t instanceof Tt && i.name instanceof zr) {
                    o();
                    t.parent_scope.resolve().fn_defs.push(t);
                    t.safe_ids = null;
                    var a = i.name.definition();
                    if (!a.fixed) h(r, a, t);
                } else if (t) {
                    t.walk(r);
                    o();
                } else if (r.parent() instanceof pr) {
                    o();
                }
                return true;
                function o() {
                    T(r, n, i.name, function() {
                        return i.value || Fe(Qr, i);
                    }, function(e, n) {
                        var t = e.definition();
                        if (n && w(r, t, true)) {
                            g(r, t);
                            r.loop_ids[t.id] = r.in_loop;
                            t.fixed = n;
                            t.fixed.assigns = [ i ];
                            if (e instanceof Cr && t.redefined() || !(Ce(e) || Ye(t))) {
                                t.single_use = false;
                            }
                        } else {
                            t.fixed = false;
                        }
                    });
                }
            });
            e(_t, function(e, n) {
                var t = e.in_loop;
                e.in_loop = this;
                m(e);
                n();
                _(e);
                e.in_loop = t;
                return true;
            });
        })(function(e, n) {
            e.DEFMETHOD("reduce_vars", n);
        });
        function D(e) {
            e._squeezed = false;
            e._optimized = false;
            if (e instanceof ct) e._var_names = undefined;
            if (e instanceof Ln) e.fixed = undefined;
        }
        kt.DEFMETHOD("reset_opt_flags", function(t) {
            var r = new Gn(t.option("reduce_vars") ? function(e, n) {
                D(e);
                return e.reduce_vars(r, n, t);
            } : D);
            r.fn_scanning = null;
            r.fn_visited = [];
            r.in_loop = null;
            r.loop_ids = Object.create(null);
            r.safe_ids = Object.create(null);
            r.safe_ids.seq = {};
            this.walk(r);
        });
        $r.DEFMETHOD("fixed_value", function(e) {
            var n = this.definition();
            var t = n.fixed;
            if (t) {
                if (this.fixed) t = this.fixed;
                return (t instanceof bn ? t : t()).tail_node();
            }
            t = t === 0 && this.fixed;
            if (!t) return t;
            var r = (t instanceof bn ? t : t()).tail_node();
            if (e && n.escaped.depth != 1 && F(r, true)) return r;
            if (r.is_constant()) return r;
        });
        Ln.DEFMETHOD("is_immutable", function() {
            var e = this.redef || this.definition();
            if (!(e.orig[0] instanceof Nr)) return false;
            if (e.orig.length == 1) return true;
            if (!this.in_arg) return false;
            return !(e.orig[1] instanceof Bn);
        });
        bn.DEFMETHOD("convert_symbol", Kn);
        function t(t, r) {
            return this.transform(new ii(function(e, n) {
                if (e instanceof Dn) {
                    e = e.clone();
                    e.name = e.name.transform(this);
                    return e;
                }
                if (e instanceof Yn) {
                    e = e.clone();
                    n(e, this);
                    return e;
                }
                if (e instanceof Er) {
                    e = e.clone();
                    e.value = e.value.transform(this);
                    return e;
                }
                return e.convert_symbol(t, r);
            }));
        }
        Dn.DEFMETHOD("convert_symbol", t);
        Yn.DEFMETHOD("convert_symbol", t);
        function r(e, n) {
            var t = Fe(e, this);
            return n(t, this) || t;
        }
        zr.DEFMETHOD("convert_symbol", r);
        Ln.DEFMETHOD("convert_symbol", r);
        function N(e) {
            var n = e.definition();
            n.assignments++;
            n.references.push(e);
        }
        function i(n, t) {
            var r = new Gn(function(e) {
                if (e instanceof Dn) {
                    e.value.walk(t);
                    e.name.walk(r);
                    return true;
                }
                if (e instanceof Er) {
                    if (e.key instanceof bn) e.key.walk(t);
                    e.value.walk(r);
                    return true;
                }
                return n(e);
            });
            this.walk(r);
        }
        Dn.DEFMETHOD("mark_symbol", i);
        Yn.DEFMETHOD("mark_symbol", i);
        function a(e) {
            return e(this);
        }
        zr.DEFMETHOD("mark_symbol", a);
        Ln.DEFMETHOD("mark_symbol", a);
        bn.DEFMETHOD("match_symbol", function(e) {
            return e(this);
        });
        function o(n, t) {
            var r = false;
            var i = new Gn(function(e) {
                if (r) return true;
                if (e instanceof Dn) {
                    if (!t) return r = true;
                    e.name.walk(i);
                    return true;
                }
                if (e instanceof Er) {
                    if (!t && e.key instanceof bn) return r = true;
                    e.value.walk(i);
                    return true;
                }
                if (n(e)) return r = true;
            });
            this.walk(i);
            return r;
        }
        Dn.DEFMETHOD("match_symbol", o);
        Yn.DEFMETHOD("match_symbol", o);
        function R(e) {
            return e instanceof It || e instanceof Mt;
        }
        function Me(e) {
            var n = 0, t = e.self();
            do {
                if (t.variables) return t;
            } while (t = e.parent(n++));
        }
        function Le(e, n, t, r, i, a) {
            for (var o; o = e.parent(n++); t = o) {
                if (o === r) return false;
                if (a && o instanceof En) {
                    if (o.name || Dt(o) || qt(o)) return true;
                } else if (o instanceof sr) {
                    if (o.bfinally && o.bfinally !== t) return true;
                    if (i && o.bcatch && o.bcatch !== t) return true;
                }
            }
            return false;
        }
        var me = mn("Infinity NaN undefined");
        function Ue(e, n) {
            if (e instanceof Jr) return true;
            if (e instanceof Rr) return true;
            if (e instanceof $n) {
                if (e.property === "__proto__") return true;
                e = e.expression;
                if (e instanceof Ln) {
                    if (e.is_immutable()) return false;
                    e = e.fixed_value();
                }
                if (!e) return true;
                if (e.tail_node().is_constant()) return true;
                return Ue(e, n);
            }
            if (e instanceof Ln) {
                if (e.is_immutable()) return true;
                var t = e.definition();
                return n.exposed(t) && me[t.name];
            }
            return false;
        }
        function Fe(e, n, t) {
            if (t) {
                t.start = n.start;
                t.end = n.end;
            } else {
                t = n;
            }
            return new e(t);
        }
        function Pe(e, n) {
            if (n.length == 1) return n[0];
            return Fe(On, e, {
                expressions: n.reduce(k, [])
            });
        }
        function fe(e, n) {
            switch (typeof e) {
              case "string":
                return Fe(Vn, n, {
                    value: e
                });

              case "number":
                if (isNaN(e)) return Fe(Kr, n);
                if (isFinite(e)) {
                    return 1 / e < 0 ? Fe(Pn, n, {
                        operator: "-",
                        expression: Fe(Wn, n, {
                            value: -e
                        })
                    }) : Fe(Wn, n, {
                        value: e
                    });
                }
                return e < 0 ? Fe(Pn, n, {
                    operator: "-",
                    expression: Fe(ei, n)
                }) : Fe(ei, n);

              case "boolean":
                return Fe(e ? ri : ti, n);

              case "undefined":
                return Fe(Qr, n);

              default:
                if (e === null) {
                    return Fe(Xr, n);
                }
                if (e instanceof RegExp) {
                    return Fe(Gr, n, {
                        value: e
                    });
                }
                throw new Error(tt("Can't handle constant of type: {type}", {
                    type: typeof e
                }));
            }
        }
        function _e(e) {
            return e instanceof $n || Ne(e) && e.name == "eval";
        }
        function je(e, n, t) {
            var r = false;
            if (e.TYPE == "Call") {
                r = e.expression === n && _e(t);
            } else if (e instanceof Vr) {
                r = e.tag === n && _e(t);
            } else if (e instanceof Pn) {
                r = e.operator == "delete" || e.operator == "typeof" && Ne(t);
            }
            return r ? Pe(n, [ Fe(Wn, n, {
                value: 0
            }), t ]) : t;
        }
        function B(e, n) {
            var r = new gn();
            e.walk(new Gn(function(e) {
                if (!(e instanceof Ln)) return;
                var n = e.definition();
                var t = e.fixed;
                if (!t || !r.has(n.id)) {
                    r.set(n.id, t);
                } else if (r.get(n.id) !== t) {
                    r.set(n.id, false);
                }
            }));
            if (r.size() > 0) n.walk(new Gn(function(e) {
                if (!(e instanceof Ln)) return;
                var n = e.definition();
                var t = e.fixed;
                if (!t || !r.has(n.id)) return;
                if (r.get(n.id) !== t) e.fixed = false;
            }));
            return n;
        }
        function k(e, n) {
            if (n instanceof On) {
                [].push.apply(e, n.expressions);
            } else {
                e.push(n);
            }
            return e;
        }
        function W(e) {
            return e instanceof lr || e instanceof Bt || e instanceof pr;
        }
        function S(e) {
            if (e instanceof jt) {
                var n = e.name.definition();
                var t = e.name.scope;
                return n.scope === t || _n(n.references, function(e) {
                    var n = e.scope;
                    do {
                        if (n === t) return true;
                    } while (n = n.parent_scope);
                });
            }
            return !W(e);
        }
        function G(e) {
            if (e === null) return [];
            if (e instanceof xn) return _n(e.body, S) ? e.body : [ e ];
            if (e instanceof yn) return [];
            if (ut(e)) return [ e ];
            throw new Error("Can't convert thing to statement array");
        }
        function ue(e) {
            if (e === null) return true;
            if (e instanceof yn) return true;
            if (e instanceof xn) return e.body.length == 0;
            return false;
        }
        function E(e) {
            return _n(e.body, function(e) {
                return ue(e) || e instanceof Ht || e instanceof dr && ce(e);
            });
        }
        function J(e) {
            if (e instanceof ht) {
                return e.body instanceof xn ? e.body : e;
            }
            return e;
        }
        function ge(e) {
            if (e.TYPE != "Call") return false;
            do {
                e = e.expression;
            } while (e instanceof $n);
            return e instanceof Tt ? !At(e) : ge(e);
        }
        function Ve(e) {
            var n = e.expression;
            if (n.name) return false;
            if (!(e instanceof gr)) return true;
            var t = false;
            n.walk(new Gn(function(e) {
                if (t) return true;
                if (e instanceof Ur) return t = true;
                if (e instanceof kn && e !== n) return true;
            }));
            return !t;
        }
        function Ne(e) {
            return e instanceof Ln && e.definition().undeclared;
        }
        var We = mn("Array Boolean clearInterval clearTimeout console Date decodeURI decodeURIComponent encodeURI encodeURIComponent Error escape eval EvalError Function isFinite isNaN JSON Map Math Number parseFloat parseInt RangeError ReferenceError RegExp Object Set setInterval setTimeout String SyntaxError TypeError unescape URIError WeakMap WeakSet");
        Ln.DEFMETHOD("is_declared", function(e) {
            return this.defined || !this.definition().undeclared || e.option("unsafe") && We[this.name];
        });
        function ne(e) {
            return e.static && e.value && (e instanceof Vt || e instanceof Xt);
        }
        function ce(e) {
            return _n(e.definitions, function(e) {
                return !e.value;
            });
        }
        function L(e, n) {
            if (e instanceof Bt) return n && !e.extends && _n(e.properties, function(e) {
                if (e.key instanceof bn) return false;
                return !ne(e);
            });
            if (e instanceof cr) return (n || e instanceof dr) && ce(e);
            if (e instanceof hr) return L(e.body, n);
            if (e instanceof vr) return L(e.body, n);
            return e instanceof jt;
        }
        function T(e, n) {
            var t = e.lastIndexOf(n);
            if (t < 0) return false;
            while (++t < e.length) {
                if (!L(e[t], true)) return false;
            }
            return true;
        }
        function Ge(e, n) {
            var t;
            if (e.init instanceof xn) {
                t = e.init;
                e.init = t.body.pop();
                t.body.push(e);
            }
            if (e.init instanceof Ht) {
                if (!t) t = Fe(xn, e, {
                    body: [ e ]
                });
                t.body.splice(-1, 0, e.init);
                e.init = null;
            } else if (e.init instanceof wn) {
                e.init = e.init.body;
            } else if (ue(e.init)) {
                e.init = null;
            }
            if (!t) return;
            return n ? et.splice(t.body) : t;
        }
        function l(e, s) {
            var H = Y(s, function(e) {
                return e instanceof En;
            });
            var Se, Te, Ae, De, qe, Oe;
            i();
            var n, t, r = 10;
            do {
                t = n;
                n = 0;
                if (o(e)) n = 1;
                if (!n && t == 1) break;
                if (s.option("dead_code")) {
                    if (u(e, s)) n = 2;
                    if (!n && t == 2) break;
                }
                if (s.option("if_return")) {
                    if (f(e, s)) n = 3;
                    if (!n && t == 3) break;
                }
                if (s.option("awaits") && s.option("side_effects")) {
                    if (c(e, s)) n = 4;
                    if (!n && t == 4) break;
                }
                if (s.option("inline") >= 4) {
                    if (l(e, s)) n = 5;
                    if (!n && t == 5) break;
                }
                if (s.sequences_limit > 0) {
                    if (p(e, s)) n = 6;
                    if (!n && t == 6) break;
                    if (h(e, s)) n = 7;
                    if (!n && t == 7) break;
                }
                if (s.option("join_vars")) {
                    if (w(e)) n = 8;
                    if (!n && t == 8) break;
                }
                if (s.option("collapse_vars")) {
                    if (a(e, s)) n = 9;
                }
            } while (n && r-- > 0);
            return e;
            function Y(e, n) {
                var t = e.self(), r = 0, i;
                do {
                    if (t instanceof fr) {
                        t = e.parent(r++);
                    } else if (t instanceof dt) {
                        t = t.body;
                    } else if (t instanceof ir) {
                        var a = e.parent(r);
                        if (a.body[a.body.length - 1] === t || o(t.body)) {
                            r++;
                            t = a;
                        }
                    }
                    do {
                        i = t;
                        if (n(i)) return i;
                        t = e.parent(r++);
                    } while (t instanceof Tn);
                } while (i && (t instanceof xn || t instanceof fr || t instanceof kn || t instanceof ir || t instanceof sr) && T(t.body, i));
                function o(e) {
                    for (var n = e.length; --n >= 0; ) {
                        if (e[n] instanceof nr) return true;
                    }
                    return false;
                }
            }
            function i() {
                var e = s.self(), n = 0;
                do {
                    if (!Se && e.variables) Se = e;
                    if (e instanceof fr) {
                        if (s.parent(n).bfinally) {
                            if (!qe) qe = {};
                            qe.bfinally = true;
                        }
                        n++;
                    } else if (e instanceof ur) {
                        n++;
                    } else if (e instanceof ht) {
                        De = true;
                    } else if (e instanceof kn) {
                        Oe = e;
                        break;
                    } else if (e instanceof sr) {
                        if (!qe) qe = {};
                        if (e.bcatch) qe.bcatch = true;
                        if (e.bfinally) qe.bfinally = true;
                    }
                } while (e = s.parent(n++));
            }
            function a(i, d) {
                if (Oe.pinned()) return;
                var h;
                var j = new gn();
                var v = [];
                var N = false;
                var p = new gn();
                var I;
                var a = i.length;
                var m = new ii(function(e, n) {
                    if (D) return e;
                    if (!A) {
                        if (e !== _[g]) return e;
                        g++;
                        if (g < _.length) return z(e, m);
                        A = true;
                        y = (b ? F : ie)(e, 0);
                        if (y === e) D = true;
                        return e;
                    }
                    var t = m.parent();
                    if (!w && ne(e, t)) {
                        w = t;
                    }
                    if (R && Y && O && !w && e instanceof In && e.operator != "=" && e.left.equals(x)) {
                        q++;
                        N = true;
                        bn.info("Cascading {this} [{start}]", e);
                        O = false;
                        S = _e(x);
                        e.right.transform(m);
                        he(f);
                        var r;
                        if (D) {
                            r = f;
                        } else {
                            D = true;
                            r = Fe(jn, f, {
                                operator: R,
                                left: x.fixed && x.definition().fixed ? x.fixed.to_binary(f) : x,
                                right: T
                            });
                        }
                        return Fe(In, e, {
                            operator: "=",
                            left: e.left,
                            right: Fe(jn, e, {
                                operator: e.operator.slice(0, -1),
                                left: r,
                                right: e.right
                            })
                        });
                    }
                    if (Z(e, t)) {
                        D = true;
                        return e;
                    }
                    if (e.single_use) return e;
                    var i;
                    if (!(e instanceof zr) && (Y && x.equals(e) || E && (i = E(e, this)))) {
                        if (!O || w && (i || !J || !K)) {
                            if (!i && !b) D = true;
                            return e;
                        }
                        if (di(e, t)) {
                            if (b && !i) c = true;
                            return e;
                        }
                        if (!i && H && e.fixed !== x.fixed) {
                            D = true;
                            return e;
                        }
                        if (b) {
                            if (w && u == 0) u = l - q;
                            if (!i) q++;
                            return e;
                        }
                        q++;
                        N = D = true;
                        bn.info("Collapsing {this} [{start}]", e);
                        if (f.TYPE == "Binary") {
                            ve(f, e);
                            return Fe(In, f, {
                                operator: "=",
                                left: f.right.left,
                                right: f.operator == "&&" ? Fe(Nn, f, {
                                    condition: f.left,
                                    consequent: f.right.right,
                                    alternative: e
                                }) : Fe(Nn, f, {
                                    condition: f.left,
                                    consequent: e,
                                    alternative: f.right.right
                                })
                            });
                        }
                        if (f instanceof yr) return Fe(Pn, f, {
                            operator: f.operator,
                            expression: x.fixed && x.definition().fixed ? x.fixed.to_prefix(f) : x
                        });
                        if (f instanceof Pn) {
                            he(f);
                            return f;
                        }
                        ve(T, e);
                        if (f instanceof An) {
                            var a = f.name.definition();
                            if (a.references.length - a.replaced == 1 && !d.exposed(a)) {
                                a.replaced++;
                                return je(t, e, T);
                            }
                            return Fe(In, f, {
                                operator: "=",
                                left: e,
                                right: T
                            });
                        }
                        he(T);
                        var o = f.clone();
                        o.right = T;
                        return o;
                    }
                    if (ee(e, t)) {
                        D = true;
                        return e;
                    }
                    if (te(e, t) || L(e)) {
                        y = e;
                        if (e instanceof kn) D = true;
                    }
                    if (e instanceof St) {
                        var s = O;
                        O = false;
                        n(e, m);
                        O = s;
                        return $(e);
                    }
                    if (e instanceof Yn) {
                        var s = O;
                        O = false;
                        n(e, m);
                        O = s;
                        return $(e);
                    }
                    if (e instanceof Dn) {
                        e.name = e.name.transform(m);
                        var s = O;
                        O = false;
                        e.value = e.value.transform(m);
                        O = s;
                        return $(e);
                    }
                    if (e instanceof ct && !(e instanceof kn) && !(e.variables && e.variables.all(function(e) {
                        return !W.has(e.name) && !S.has(e.name);
                    }))) {
                        var s = O;
                        O = false;
                        if (!z(e, m)) n(e, m);
                        O = s;
                        return $(e);
                    }
                    if (z(e, m)) return $(e);
                }, $);
                var r = new ii(function(e) {
                    if (D) return e;
                    if (!A) {
                        if (e !== _[g]) return e;
                        g++;
                        switch (_.length - g) {
                          case 0:
                            A = true;
                            if (c) return e;
                            if (e !== f) return e;
                            if (e instanceof An) return e;
                            s.replaced++;
                            var n = r.parent();
                            if (n instanceof On && n.tail_node() !== e) {
                                b.replaced++;
                                if (T === o) return et.skip;
                                return Pe(o, o.expressions.slice(0, -1));
                            }
                            return T;

                          case 1:
                            if (!c && e.body === f) {
                                A = true;
                                s.replaced++;
                                b.replaced++;
                                return null;
                            }

                          default:
                            return z(e, r);
                        }
                    }
                    if (e instanceof Ln && e.definition() === s) {
                        if (di(e, r.parent())) return e;
                        if (!--q) D = true;
                        bn.info("Replacing {this} [{start}]", e);
                        var t = T.clone();
                        t.scope = e.scope;
                        t.reference();
                        if (q == u) {
                            D = true;
                            return Fe(In, f, {
                                operator: "=",
                                left: e,
                                right: t
                            });
                        }
                        s.replaced++;
                        return t;
                    }
                    if (e instanceof ar || e instanceof kn) return e;
                }, function(e) {
                    return be(e, r);
                });
                while (--a >= 0) {
                    if (a == 0 && d.option("unused")) re();
                    var _ = [];
                    M(i[a]);
                    while (v.length > 0) {
                        _ = v.pop();
                        var g = 0;
                        var f = _[_.length - 1];
                        var u = -1;
                        var c = false;
                        var H = false;
                        var l;
                        var b = null;
                        var y = null;
                        var w = null;
                        var x = ue(f);
                        var k = x && x.has_side_effects(d);
                        var Y = x && (!k || x instanceof Ln) && !Ue(x, d);
                        var E = pe(f);
                        if (!Y && !E) continue;
                        var R = f instanceof In && f.operator.slice(0, -1);
                        var B = f.name instanceof Bn;
                        var L = hn;
                        if (f.may_throw(d)) {
                            if (B && Dt(Oe)) continue;
                            L = qe ? function(e) {
                                return e.has_side_effects(d);
                            } : t;
                        }
                        var U = false;
                        var V = false;
                        var W = new gn();
                        var G = true;
                        var S = _e(f);
                        var J = ye(x);
                        var o = ce(f);
                        var T = o;
                        if (!k) {
                            if (!R && T instanceof On) T = T.tail_node();
                            k = we();
                        }
                        var X = qe || !J ? function(e) {
                            return e instanceof Yn;
                        } : hn;
                        var K = xe(f);
                        var A = B;
                        var D = false;
                        var q = 0;
                        var O = !h || !A;
                        if (!O) {
                            for (var n = f.arg_index + 1; !D && n < h.length; n++) {
                                if (h[n]) h[n].transform(m);
                            }
                            O = true;
                        }
                        for (var e = a; !D && e < i.length; e++) {
                            i[e].transform(m);
                        }
                        if (b) {
                            if (!q || l > q + c) {
                                v.push(_);
                                I = true;
                                continue;
                            }
                            if (q == u) c = true;
                            var s = x.definition();
                            D = false;
                            g = 0;
                            A = B;
                            for (var e = a; !D && e < i.length; e++) {
                                if (!i[e].transform(r)) i.splice(e--, 1);
                            }
                            q = f instanceof An && f === _[_.length - 1] && s.references.length == s.replaced && !d.exposed(s);
                            b.last_ref = false;
                            b.single_use = false;
                            N = true;
                        }
                        if (q) ge(f);
                    }
                }
                return N;
                function $(e) {
                    if (D) return e;
                    if (y === e) D = true;
                    if (w === e) w = null;
                    return e;
                }
                function z(e, n) {
                    if (!(e instanceof ct)) return;
                    if (e instanceof kn) return e;
                    if (e instanceof Rt) {
                        if (e.name) e.name = e.name.transform(n);
                        if (!D && e.extends) e.extends = e.extends.transform(n);
                        var t = [], r = [];
                        for (var i = 0; !D && i < e.properties.length; i++) {
                            var a = e.properties[i];
                            if (a.key instanceof bn) a.key = a.key.transform(n);
                            if (!a.static) continue;
                            if (a instanceof Vt) {
                                if (a.value) t.push(a);
                            } else if (a instanceof Xt) {
                                [].push.apply(r, a.value.body);
                            }
                        }
                        for (var i = 0; !D && i < r.length; i++) {
                            r[i].transform(n);
                        }
                        for (var i = 0; !D && i < t.length; i++) {
                            var a = t[i];
                            a.value = a.value.transform(n);
                        }
                        return e;
                    }
                    if (e instanceof bt) {
                        e.object = e.object.transform(n);
                        D = true;
                        return e;
                    }
                    if (e instanceof rr) {
                        e.expression = e.expression.transform(n);
                        for (var i = 0; !D && i < e.body.length; i++) {
                            var o = e.body[i];
                            if (o instanceof or) {
                                if (!A) {
                                    if (o !== _[g]) continue;
                                    g++;
                                }
                                o.expression = o.expression.transform(n);
                                if (!K) break;
                                E = false;
                            }
                        }
                        D = true;
                        return e;
                    }
                }
                function Q(e, n) {
                    if (n instanceof In) return n.operator == "=" && n.left === e;
                    if (n instanceof Dn) return n.name === e;
                    if (n instanceof kr) return true;
                    if (n instanceof Er) return n.value === e;
                }
                function Z(e, n) {
                    if (e === T) return true;
                    if (n instanceof gt) {
                        if (e !== n.init) return true;
                    }
                    if (e instanceof In) {
                        return e.operator != "=" && x.equals(e.left);
                    }
                    if (e instanceof qn) {
                        if (!(x instanceof $n)) return false;
                        if (!x.equals(e.expression)) return false;
                        return !(T instanceof Tt && !T.contains_this());
                    }
                    if (e instanceof Rt) return !d.has_directive("use strict");
                    if (e instanceof st) return true;
                    if (e instanceof Ht) return B && x.name === e.name.name;
                    if (e instanceof Er) return e.key instanceof bn;
                    if (e instanceof vt) return true;
                    if (e instanceof er) return true;
                    if (e instanceof sr) return true;
                    if (e instanceof xt) return true;
                    return false;
                }
                function ee(e, n) {
                    if (!(e instanceof Ln)) return false;
                    if (e.is_declared(d)) {
                        if (e.fixed_value()) return false;
                        if (Ce(e)) {
                            return !(n instanceof $n && n.expression === e) && ze(e.definition());
                        }
                    } else if (Q(e, n)) {
                        return false;
                    }
                    if (!K) return true;
                    E = false;
                    return false;
                }
                function ne(e, n) {
                    if (n instanceof In) return n.left !== e && He[n.operator.slice(0, -1)];
                    if (n instanceof jn) return n.left !== e && He[n.operator];
                    if (n instanceof qn) return n.optional && n.expression !== e;
                    if (n instanceof or) return n.expression !== e;
                    if (n instanceof Nn) return n.condition !== e;
                    if (n instanceof Tn) return n.condition !== e;
                    if (n instanceof Cn) return n.optional && n.expression !== e;
                }
                function te(e, n) {
                    if (e instanceof wr) return true;
                    if (e.TYPE == "Binary") return !Xe(e.operator, e.right, d);
                    if (e instanceof qn) {
                        var t, r = e.expression;
                        if (r instanceof Ln) {
                            t = r.definition();
                            r = r.fixed_value();
                        }
                        if (!(r instanceof En)) return !e.is_expr_pure(d);
                        if (t && Ze(d, t, r)) return true;
                        if (r.collapse_scanning) return false;
                        r.collapse_scanning = true;
                        var i = O;
                        O = false;
                        var a = y;
                        var o = w;
                        for (var s = 0; !D && s < r.argnames.length; s++) {
                            if (C(p, r.argnames[s], e.args[s])) D = true;
                        }
                        if (!D) {
                            if (r.rest && C(p, r.rest, Fe(Hn, e, {
                                elements: e.args.slice(s)
                            }))) {
                                D = true;
                            } else if (At(r) && r.value) {
                                r.value.transform(m);
                            } else for (var s = 0; !D && s < r.body.length; s++) {
                                var f = r.body[s];
                                if (f instanceof Sn) {
                                    if (f.value) f.value.transform(m);
                                    break;
                                }
                                f.transform(m);
                            }
                        }
                        w = o;
                        y = a;
                        O = i;
                        r.collapse_scanning = false;
                        if (!D) return false;
                        D = false;
                        return true;
                    }
                    if (e instanceof Rt) {
                        if (!qe) return false;
                        var u = e.extends;
                        if (!u) return false;
                        if (u instanceof Ln) u = u.fixed_value();
                        return !Re(u);
                    }
                    if (e instanceof Qt) {
                        if (qe) {
                            if (qe.bfinally) return true;
                            if (qe.bcatch && e instanceof Zt) return true;
                        }
                        return k || x instanceof $n || Ee(x);
                    }
                    if (e instanceof Ft) {
                        return d.option("ie") && e.name && S.has(e.name.name);
                    }
                    if (e instanceof Rr) return ke(e, n);
                    if (e instanceof $n) {
                        if (k) return true;
                        var c = e.expression;
                        if (c instanceof Ln && ze(c.definition())) return true;
                        if (d.option("unsafe")) {
                            if (Ne(c) && We[c.name]) return false;
                            if (Je(c)) return false;
                        }
                        if (!G) return true;
                        if (b) return false;
                        if (!qe && J) return false;
                        if (e.optional) return false;
                        return c.may_throw_on_access(d);
                    }
                    if (e instanceof Mn) return true;
                    if (e instanceof Ln) {
                        if (ke(e, n)) return !Q(e, n);
                        if (k && Ee(e)) return true;
                        var t = e.definition();
                        return (qe || t.scope.resolve() !== Oe) && !Ce(e);
                    }
                    if (e instanceof Vr) return !e.is_expr_pure(d);
                    if (e instanceof An) {
                        if (X(e.name)) return true;
                        return (e.value || n instanceof pr) && e.name.match_symbol(function(e) {
                            return e instanceof zr && (S.has(e.name) || k && Ee(e));
                        }, true);
                    }
                    if (e instanceof xr) return true;
                    var l = di(e.left, e);
                    if (!l) return false;
                    if (l instanceof $n) return true;
                    if (X(l)) return true;
                    return l.match_symbol(function(e) {
                        return e instanceof Ln && (S.has(e.name) || U && d.exposed(e.definition()));
                    }, true);
                    function p(e) {
                        e.transform(m);
                        return D;
                    }
                }
                function C(t, e, r) {
                    if (e instanceof Dn) {
                        return t(e.value) || C(t, e.name, e.value) || !Ie(r) && C(t, e.name, r);
                    }
                    if (!r) return !(e instanceof $r);
                    if (e instanceof Yn) {
                        if (e.rest && C(t, e.rest)) return true;
                        if (e instanceof kr) {
                            if (r instanceof Hn) return !_n(e.elements, function(e, n) {
                                return !C(t, e, r[n]);
                            });
                            if (!r.is_string(d)) return true;
                            return !_n(e.elements, function(e) {
                                return !C(t, e);
                            });
                        }
                        if (e instanceof Sr) {
                            if (r.may_throw_on_access(d)) return true;
                            return !_n(e.properties, function(e) {
                                if (e.key instanceof bn && t(e.key)) return false;
                                return !C(t, e.value);
                            });
                        }
                    }
                }
                function re() {
                    if (Ae === false) return;
                    var e = d.parent(), i = d.self();
                    if (Ae === undefined) {
                        if (!(i instanceof Tt) || qt(i) || i.uses_arguments || i.pinned() || !(e instanceof qn) || e.expression !== i || !_n(e.args, function(e) {
                            return !(e instanceof Mn);
                        })) {
                            Ae = false;
                            return;
                        }
                        if (!Ve(e)) return;
                        Ae = true;
                    }
                    var a = i.in_strict_mode(d) && !i.parent_scope.resolve(true).in_strict_mode(d);
                    var o;
                    if (Dt(i)) {
                        o = function(e) {
                            return e instanceof $r && e.name == "await";
                        };
                        Te = true;
                    } else {
                        o = function(e) {
                            return e instanceof wr && !n.find_parent(kn);
                        };
                        if (Te === undefined) Te = Le(d, 1, e, null, true, true);
                    }
                    var s = null;
                    var n = new Gn(function(e, n) {
                        if (!c) return true;
                        if (o(e) || e instanceof xr) {
                            c = null;
                            return true;
                        }
                        if (e instanceof Rr) {
                            if (a || !s) c = null;
                            return true;
                        }
                        if (e instanceof Ln) {
                            var t;
                            if (e.in_arg && !Ye(e.definition()) || (t = i.variables.get(e.name)) && t !== e.definition()) {
                                c = null;
                            }
                            return true;
                        }
                        if (e instanceof kn && !At(e)) {
                            var r = s;
                            s = e;
                            n();
                            s = r;
                            return true;
                        }
                    });
                    h = e.args.slice();
                    var t = h.length;
                    var r = new gn();
                    for (var f = i.argnames.length; --f >= 0; ) {
                        var u = i.argnames[f];
                        var c = h[f];
                        var l = null;
                        if (u instanceof Dn) {
                            l = u.value;
                            u = u.name;
                            h[t + f] = l;
                        }
                        if (u instanceof Yn) {
                            if (Te && C(function(e) {
                                return e.has_side_effects(d);
                            }, u, c)) {
                                v.length = 0;
                                break;
                            }
                            h[t + f] = i.argnames[f];
                            continue;
                        }
                        if (r.has(u.name)) continue;
                        r.set(u.name, true);
                        if (l) c = Ie(c) ? l : null;
                        if (!c && !l) {
                            c = Fe(Qr, u).transform(d);
                        } else if (c instanceof En && c.pinned()) {
                            c = null;
                        } else if (c) {
                            c.walk(n);
                        }
                        if (!c) continue;
                        var p = Fe(An, u, {
                            name: u,
                            value: c
                        });
                        p.name_index = f;
                        p.arg_index = l ? t + f : f;
                        v.unshift([ p ]);
                    }
                    if (i.rest) h.push(i.rest);
                }
                function M(e, n) {
                    _.push(e);
                    if (e instanceof Hn) {
                        e.elements.forEach(function(e) {
                            M(e, n);
                        });
                    } else if (e instanceof In) {
                        var t = e.left;
                        if (!(t instanceof Yn)) v.push(_.slice());
                        M(t);
                        M(e.right);
                        if (t instanceof Ln && e.operator == "=") {
                            j.set(t.name, (j.get(t.name) || 0) + 1);
                        }
                    } else if (e instanceof wr) {
                        M(e.expression, n);
                    } else if (e instanceof jn) {
                        var r = He[e.operator];
                        if (n && r && e.operator != "??" && e.right instanceof In && e.right.operator == "=" && !(e.right.left instanceof Yn)) {
                            v.push(_.slice());
                        }
                        M(e.left, !r && n);
                        M(e.right, n);
                    } else if (e instanceof qn) {
                        M(e.expression);
                        e.args.forEach(M);
                    } else if (e instanceof or) {
                        M(e.expression);
                    } else if (e instanceof Nn) {
                        M(e.condition);
                        M(e.consequent, n);
                        M(e.alternative, n);
                    } else if (e instanceof cr) {
                        e.definitions.forEach(M);
                    } else if (e instanceof zn) {
                        M(e.expression);
                    } else if (e instanceof vt) {
                        M(e.condition);
                        if (!(e.body instanceof pt)) {
                            M(e.body);
                        }
                    } else if (e instanceof Qt) {
                        if (e.value) M(e.value);
                    } else if (e instanceof gt) {
                        if (e.init) M(e.init, true);
                        if (e.condition) M(e.condition);
                        if (e.step) M(e.step, true);
                        if (!(e.body instanceof pt)) {
                            M(e.body);
                        }
                    } else if (e instanceof bt) {
                        M(e.object);
                        if (!(e.body instanceof pt)) {
                            M(e.body);
                        }
                    } else if (e instanceof Tn) {
                        M(e.condition);
                        if (!(e.body instanceof pt)) {
                            M(e.body);
                        }
                        if (e.alternative && !(e.alternative instanceof pt)) {
                            M(e.alternative);
                        }
                    } else if (e instanceof Rn) {
                        e.properties.forEach(function(e) {
                            _.push(e);
                            if (e.key instanceof bn) M(e.key);
                            if (e instanceof Ar) M(e.value, n);
                            _.pop();
                        });
                    } else if (e instanceof On) {
                        var i = e.expressions.length - (n ? 0 : 1);
                        e.expressions.forEach(function(e, n) {
                            M(e, n < i);
                        });
                    } else if (e instanceof wn) {
                        M(e.body, true);
                    } else if (e instanceof Mn) {
                        M(e.expression);
                    } else if (e instanceof Cn) {
                        M(e.expression);
                        M(e.property);
                    } else if (e instanceof rr) {
                        M(e.expression);
                        e.body.forEach(M);
                    } else if (e instanceof Fn) {
                        if (fi[e.operator]) {
                            v.push(_.slice());
                        } else {
                            M(e.expression);
                        }
                    } else if (e instanceof An) {
                        if (e.name instanceof Pr) {
                            if (e.value) {
                                var a = e.name.definition();
                                if (a.references.length > a.replaced) {
                                    v.push(_.slice());
                                }
                            } else {
                                p.set(e.name.name, (p.get(e.name.name) || 0) + 1);
                            }
                        }
                        if (e.value) M(e.value);
                    } else if (e instanceof xr) {
                        if (e.expression) M(e.expression);
                    }
                    _.pop();
                }
                function ie(e, n) {
                    var t = m.parent(n);
                    if (t instanceof Hn) return e;
                    if (t instanceof In) return e;
                    if (t instanceof wr) return e;
                    if (t instanceof jn) return e;
                    if (t instanceof qn) return e;
                    if (t instanceof or) return e;
                    if (t instanceof Nn) return e;
                    if (t instanceof cr) return P(t, n + 1);
                    if (t instanceof Qt) return e;
                    if (t instanceof Tn) return e;
                    if (t instanceof ht) return e;
                    if (t instanceof Tr) return e;
                    if (t instanceof $n) return e;
                    if (t instanceof On) {
                        return (t.tail_node() === e ? ie : P)(t, n + 1);
                    }
                    if (t instanceof wn) return P(t, n + 1);
                    if (t instanceof Mn) return e;
                    if (t instanceof rr) return e;
                    if (t instanceof Fn) return e;
                    if (t instanceof An) return e;
                    if (t instanceof xr) return e;
                    return null;
                }
                function ae(e, n, t) {
                    var r;
                    do {
                        r = e;
                        e = m.parent(++t);
                    } while (e instanceof In && e.operator.slice(0, -1) == n || e instanceof jn && e.operator == n);
                    return r;
                }
                function oe(e, n, t, r, i) {
                    var a = O;
                    O = false;
                    var o = y;
                    var s = w;
                    var f = m.stack;
                    m.stack = [ r ];
                    e.transform(m);
                    m.stack = f;
                    w = s;
                    y = o;
                    O = a;
                    if (D) {
                        D = false;
                        return t;
                    }
                    return n(r, i + 1);
                }
                function F(e, n) {
                    var t = m.parent(n);
                    if (t instanceof Hn) return F(t, n + 1);
                    if (t instanceof In) {
                        if (L(t)) return e;
                        if (t.left.match_symbol(function(e) {
                            return e instanceof Ln && (x.name == e.name || b.name == e.name);
                        })) return e;
                        var r;
                        if (t.left === e || !He[r = t.operator.slice(0, -1)]) {
                            return F(t, n + 1);
                        }
                        return ae(t, r, n);
                    }
                    if (t instanceof wr) return F(t, n + 1);
                    if (t instanceof jn) {
                        var r;
                        if (t.left === e || !He[r = t.operator]) {
                            return F(t, n + 1);
                        }
                        return ae(t, r, n);
                    }
                    if (t instanceof qn) return t;
                    if (t instanceof or) {
                        if (t.expression !== e) return e;
                        return F(t, n + 1);
                    }
                    if (t instanceof Nn) {
                        if (t.condition !== e) return e;
                        return F(t, n + 1);
                    }
                    if (t instanceof cr) return P(t, n + 1);
                    if (t instanceof mt) return e;
                    if (t instanceof Qt) return P(t, n + 1);
                    if (t instanceof gt) {
                        if (t.init !== e && t.condition !== e) return e;
                        return F(t, n + 1);
                    }
                    if (t instanceof bt) {
                        if (t.init !== e) return e;
                        return F(t, n + 1);
                    }
                    if (t instanceof Tn) {
                        if (t.condition !== e) return e;
                        return F(t, n + 1);
                    }
                    if (t instanceof Tr) {
                        var i = m.parent(n + 1);
                        return _n(i.properties, function(e) {
                            return e instanceof Ar;
                        }) ? F(i, n + 2) : i;
                    }
                    if (t instanceof $n) {
                        var a = t.expression;
                        return a === e ? F(t, n + 1) : e;
                    }
                    if (t instanceof On) {
                        return (t.tail_node() === e ? F : P)(t, n + 1);
                    }
                    if (t instanceof wn) return P(t, n + 1);
                    if (t instanceof Mn) return F(t, n + 1);
                    if (t instanceof rr) {
                        if (t.expression !== e) return e;
                        return F(t, n + 1);
                    }
                    if (t instanceof Fn) {
                        if (t.operator == "delete") return e;
                        return F(t, n + 1);
                    }
                    if (t instanceof An) return t.name.match_symbol(function(e) {
                        return e instanceof zr && (x.name == e.name || b.name == e.name);
                    }) ? e : F(t, n + 1);
                    if (t instanceof _t) {
                        if (t.condition !== e) return e;
                        return F(t, n + 1);
                    }
                    if (t instanceof xr) return F(t, n + 1);
                    return null;
                }
                function P(n, t) {
                    var r = m.parent(t);
                    if (te(n, r)) return n;
                    if (ne(n, r)) return n;
                    if (r instanceof Hn) return P(r, t + 1);
                    if (r instanceof In) return a(r.left);
                    if (r instanceof wr) return n;
                    if (r instanceof jn) return P(r, t + 1);
                    if (r instanceof qn) return P(r, t + 1);
                    if (r instanceof or) return P(r, t + 1);
                    if (r instanceof Nn) return P(r, t + 1);
                    if (r instanceof cr) return P(r, t + 1);
                    if (r instanceof Qt) return P(r, t + 1);
                    if (r instanceof Tn) return P(r, t + 1);
                    if (r instanceof ht) return n;
                    if (r instanceof Tr) {
                        var e = m.parent(t + 1);
                        return _n(e.properties, function(e) {
                            return e instanceof Ar;
                        }) ? P(e, t + 2) : e;
                    }
                    if (r instanceof $n) {
                        var i = r.expression;
                        if (i === n) return P(r, t + 1);
                        return oe(i, P, n, r, t);
                    }
                    if (r instanceof On) return P(r, t + 1);
                    if (r instanceof wn) return P(r, t + 1);
                    if (r instanceof Mn) return n;
                    if (r instanceof rr) return P(r, t + 1);
                    if (r instanceof Fn) return P(r, t + 1);
                    if (r instanceof An) return a(r.name);
                    if (r instanceof xr) return n;
                    return null;
                    function a(e) {
                        if (L(r)) return n;
                        if (e !== n && e instanceof Yn) {
                            return oe(e, P, n, r, t);
                        }
                        return P(r, t + 1);
                    }
                }
                function se(e) {
                    if (I) {
                        I = false;
                        return;
                    }
                    if (l < 1) return;
                    e = e.tail_node();
                    var n = e instanceof In && e.operator == "=" ? e.left : e;
                    if (!(n instanceof Ln)) return;
                    var t = n.definition();
                    if (t.undeclared) return;
                    if (ze(t)) return;
                    if (n !== e) {
                        if (Ue(n, d)) return;
                        var r = t.references.length - t.replaced;
                        if (r < 2) return;
                        var i = f.clone();
                        i[i instanceof In ? "right" : "value"] = n;
                        if (f.name_index >= 0) {
                            i.name_index = f.name_index;
                            i.arg_index = f.arg_index;
                        }
                        f = i;
                    }
                    return b = t;
                }
                function fe(e) {
                    return e.references.length - e.replaced - (j.get(e.name) || 0);
                }
                function ue(t) {
                    if (t instanceof In) {
                        var r = t.left;
                        if (!(r instanceof Ln)) return r;
                        var e = r.definition();
                        if (Oe.uses_arguments && li(e)) return r;
                        if (d.exposed(e)) return r;
                        l = fe(e);
                        if (e.fixed && r.fixed) {
                            var n = e.references.filter(function(e) {
                                return e.fixed === r.fixed;
                            }).length - 1;
                            if (n < l) {
                                l = n;
                                u = 0;
                                H = true;
                            }
                        }
                        if (t.operator == "=") se(t.right);
                        return r;
                    }
                    if (t instanceof jn) return t.right.left;
                    if (t instanceof Fn) return t.expression;
                    if (t instanceof An) {
                        var r = t.name;
                        var e = r.definition();
                        if (e.const_redefs) return;
                        if (!Jn(r, e.orig)) return;
                        if (Oe.uses_arguments && li(e)) return;
                        var i = e.orig.length - e.eliminated - (p.get(e.name) || 0);
                        l = fe(e);
                        if (e.fixed) l = Math.min(l, e.references.filter(function(e) {
                            if (!e.fixed) return true;
                            if (!e.fixed.assigns) return true;
                            var n = e.fixed.assigns[0];
                            return n === r || ce(n) === t.value;
                        }).length);
                        if (i > 1 && !(r instanceof Bn)) {
                            se(t.value);
                            return Fe(Ln, r);
                        }
                        if (se(t.value) || l == 1 && !d.exposed(e)) {
                            return Fe(Ln, r);
                        }
                        return;
                    }
                }
                function ce(e) {
                    if (e instanceof In) return e.right;
                    if (e instanceof jn) {
                        var n = e.clone();
                        n.right = e.right.right;
                        return n;
                    }
                    if (e instanceof An) return e.value;
                }
                function le(e) {
                    if (e instanceof Hn) return false;
                    if (e instanceof jn && He[e.operator]) {
                        return le(e.left) && le(e.right);
                    }
                    if (e instanceof qn) return false;
                    if (e instanceof Nn) {
                        return le(e.consequent) && le(e.alternative);
                    }
                    if (e instanceof Rn) return false;
                    return !e.has_side_effects(d);
                }
                function pe(n) {
                    if (n instanceof In && n.right.single_use) return;
                    var t = Object.create(null);
                    var e = new Gn(function(e) {
                        if (e instanceof Ln) t[e.definition().id] = true;
                    });
                    while (n instanceof In && n.operator == "=") {
                        n.left.walk(e);
                        n = n.right;
                    }
                    if (n instanceof Rr) return o;
                    if (n instanceof Ln) {
                        var r = n.evaluate(d);
                        if (r === n) return o;
                        return de(r, o);
                    }
                    if (n.is_truthy()) return de(true, hn);
                    if (n.is_constant()) {
                        var i = n.evaluate(d);
                        if (!(i instanceof bn)) return de(i, o);
                    }
                    if (!(x instanceof Ln)) return false;
                    if (!le(n)) return false;
                    var a;
                    n.walk(new Gn(function(e) {
                        if (a) return true;
                        if (e instanceof Ln && t[e.definition().id]) a = true;
                    }));
                    return !a && o;
                    function o(e) {
                        return n.equals(e);
                    }
                }
                function de(r, i) {
                    return function(e, n) {
                        if (n.in_boolean_context()) {
                            if (r && e.is_truthy() && !e.has_side_effects(d)) {
                                return true;
                            }
                            if (e.is_constant()) {
                                var t = e.evaluate(d);
                                if (!(t instanceof bn)) return !t == !r;
                            }
                        }
                        return i(e);
                    };
                }
                function he(e) {
                    while (e.write_only) {
                        e.write_only = false;
                        if (!(e instanceof In)) break;
                        e = e.right;
                    }
                }
                function ve(e, n) {
                    var t = n.scope || Me(m) || Se;
                    e.walk(new Gn(function(e) {
                        if (e instanceof ct) return true;
                        if (e instanceof $r) e.scope = t;
                    }));
                }
                function me(e) {
                    if (e instanceof Ln) {
                        e = e.fixed_value();
                        if (!e) return true;
                    }
                    if (e instanceof In) return e.operator == "=" && me(e.right);
                    return e instanceof $n || e instanceof Rr;
                }
                function _e(f) {
                    var u = new gn();
                    if (f instanceof An) {
                        if (!f.name.definition().fixed) G = false;
                        u.add(f.name.name, x);
                    }
                    var c = Oe.uses_arguments && !d.has_directive("use strict");
                    var l = Oe instanceof kt;
                    var p = new Gn(function(n) {
                        var e;
                        if (n instanceof Ln) {
                            e = n.fixed_value();
                            if (!e) {
                                e = n;
                                var t = n.definition();
                                var r = n.fixed && n.fixed.escaped || t.escaped;
                                if (!t.undeclared && (t.assignments || !r || r.cross_scope) && (Be(t, n.scope, n, p.parent()) || !en(t))) {
                                    G = false;
                                }
                            }
                        } else if (n instanceof Rr) {
                            e = n;
                        }
                        if (e) {
                            u.add(n.name, $e(d, p, n, e, 0));
                        } else if (n instanceof En) {
                            for (var i = 0, a, o = n; a = p.parent(i++); o = a) {
                                if (a instanceof In) {
                                    if (a.left === o) break;
                                    if (a.operator == "=") continue;
                                    if (He[a.operator.slice(0, -1)]) continue;
                                    break;
                                }
                                if (a instanceof jn) {
                                    if (He[a.operator]) continue;
                                    break;
                                }
                                if (a instanceof qn) return;
                                if (a instanceof kn) return;
                                if (a instanceof On) {
                                    if (a.tail_node() === o) continue;
                                    break;
                                }
                                if (a instanceof Vr) {
                                    if (a.tag) return;
                                    break;
                                }
                            }
                            n.enclosed.forEach(function(e) {
                                if (e.scope !== n) W.set(e.name, true);
                            });
                            return true;
                        } else if (c && n instanceof Cn) {
                            Oe.each_argname(function(e) {
                                if (!d.option("reduce_vars") || e.definition().assignments) {
                                    if (!e.definition().fixed) G = false;
                                    u.add(e.name, true);
                                }
                            });
                            c = false;
                        }
                        if (!l) return;
                        if (n.TYPE == "Call") {
                            if (V) return;
                            var s = n.expression;
                            if (s instanceof $n) return;
                            if (s instanceof Tt && !s.contains_this()) return;
                            V = true;
                        } else if (n instanceof $n && me(n.expression)) {
                            if (n === x && !(f instanceof Fn)) {
                                V = true;
                            } else {
                                U = true;
                            }
                        }
                    });
                    f.walk(p);
                    return u;
                }
                function ge(e) {
                    var f = T === o ? null : Pe(o, o.expressions.slice(0, -1));
                    var n = e.name_index;
                    if (n >= 0) {
                        var t, r = Oe.argnames[n];
                        if (r instanceof Dn) {
                            Oe.argnames[n] = r = r.clone();
                            r.value = f || Fe(Wn, r, {
                                value: 0
                            });
                        } else if ((t = d.parent().args)[n]) {
                            Oe.argnames[n] = r.clone();
                            t[n] = f || Fe(Wn, t[n], {
                                value: 0
                            });
                        }
                        return;
                    }
                    var u = _.length - 1;
                    var c = _[u];
                    if (c instanceof An || _[u - 1].body === c) u--;
                    var l = new ii(function(e, n, t) {
                        if (A) return e;
                        if (e !== _[g]) return e;
                        g++;
                        if (g <= u) return z(e, l);
                        A = true;
                        if (e instanceof cr) {
                            p.set(c.name.name, (p.get(c.name.name) || 0) + 1);
                            if (b) b.replaced++;
                            var r = e.definitions;
                            var i = r.indexOf(c);
                            var a = c.clone();
                            a.value = null;
                            if (!f) {
                                e.definitions[i] = a;
                                return e;
                            }
                            var o = [ Fe(wn, f, {
                                body: f
                            }) ];
                            if (i > 0) {
                                var s = e.clone();
                                s.definitions = r.slice(0, i);
                                o.unshift(s);
                                e = e.clone();
                                e.definitions = r.slice(i);
                            }
                            o.push(e);
                            e.definitions[0] = a;
                            return t ? et.splice(o) : Fe(xn, e, {
                                body: o
                            });
                        }
                        if (!f) return t ? et.skip : null;
                        return ut(e) ? Fe(wn, f, {
                            body: f
                        }) : f;
                    }, function(e, n) {
                        if (e instanceof gt) return Ge(e, n);
                        return be(e, l);
                    });
                    D = false;
                    A = false;
                    g = 0;
                    if (!(i[a] = i[a].transform(l))) i.splice(a, 1);
                }
                function be(e, n) {
                    if (e instanceof On) switch (e.expressions.length) {
                      case 0:
                        return null;

                      case 1:
                        return je(n.parent(), e, e.expressions[0]);
                    }
                }
                function ye(e) {
                    var n = br(e);
                    if (!(n instanceof Ln)) return false;
                    if (n.definition().scope.resolve() !== Oe) return false;
                    if (!De) return true;
                    if (R) return false;
                    if (f instanceof Fn) return false;
                    var t = S.get(n.name);
                    return !t || t[0] === e;
                }
                function we() {
                    if (f instanceof Fn) return false;
                    return T.has_side_effects(d);
                }
                function xe(e) {
                    if (e instanceof Fn) return false;
                    if (k) return false;
                    if (b) return true;
                    if (!(x instanceof Ln)) return false;
                    var n;
                    if (e instanceof An) {
                        n = 1;
                    } else if (e.operator == "=") {
                        n = 2;
                    } else {
                        return false;
                    }
                    var t = x.definition();
                    if (t.references.length - t.replaced == n) return true;
                    if (!t.fixed) return false;
                    if (!x.fixed) return false;
                    var r = x.fixed.assigns;
                    var i = 0;
                    if (!_n(t.references, function(e, n) {
                        var t = e.fixed;
                        if (!t) return false;
                        if (t.to_binary || t.to_prefix) return false;
                        if (t === x.fixed) {
                            i++;
                            return true;
                        }
                        return r && t.assigns && r[0] !== t.assigns[0];
                    })) return false;
                    if (i != n) return false;
                    H = true;
                    return true;
                }
                function ke(e, n) {
                    var t = S.get(e.name);
                    if (!t || _n(t, function(e) {
                        return !e;
                    })) return;
                    if (t[0] !== x) return true;
                    E = false;
                }
                function Ee(e) {
                    var n = e.definition();
                    if (n.orig.length == 1 && n.orig[0] instanceof jr) return false;
                    if (n.scope.resolve() !== Oe) return true;
                    if (V && d.exposed(n)) return true;
                    return !_n(n.references, function(e) {
                        return e.scope.resolve(true) === Oe;
                    });
                }
                function t(e, n) {
                    if (e instanceof In) return t(e.left, true);
                    if (e instanceof Fn) return t(e.expression, true);
                    if (e instanceof An) return e.value && t(e.value);
                    if (n) {
                        if (e instanceof zn) return t(e.expression, true);
                        if (e instanceof Cn) return t(e.expression, true);
                        if (e instanceof Ln) return e.definition().scope.resolve() !== Oe;
                    }
                    return false;
                }
            }
            function o(e) {
                var n = false, t = [];
                for (var r = 0; r < e.length; ) {
                    var i = e[r];
                    if (i instanceof xn) {
                        if (_n(i.body, S)) {
                            n = true;
                            o(i.body);
                            [].splice.apply(e, [ r, 1 ].concat(i.body));
                            r += i.body.length;
                            continue;
                        }
                    }
                    if (i instanceof ft) {
                        if (Jn(i.value, t)) {
                            n = true;
                            e.splice(r, 1);
                            continue;
                        }
                        t.push(i.value);
                    }
                    if (i instanceof yn) {
                        n = true;
                        e.splice(r, 1);
                        continue;
                    }
                    r++;
                }
                return n;
            }
            function f(s, r) {
                var o = false;
                var i = r.parent();
                var a = r.self();
                var f, u, c;
                var e = H && i && i.TYPE == "Call" && i.expression === a;
                var n = H && r.option("conditionals") && r.option("sequences");
                var t = !(qe && qe.bfinally && R(Oe));
                var l = j(s);
                for (var p = s.length; --p >= 0; ) {
                    var d = s[p];
                    var h = M(p);
                    var v = s[h];
                    if (H && f && !v && d instanceof Sn && t && !(a instanceof ir)) {
                        var m = d.value;
                        if (!m) {
                            o = true;
                            s.splice(p, 1);
                            continue;
                        }
                        var _ = m.tail_node();
                        if (Ie(_)) {
                            o = true;
                            if (m instanceof Pn) {
                                m = m.expression;
                            } else if (_ instanceof Pn) {
                                m = m.clone();
                                m.expressions[m.expressions.length - 1] = _.expression;
                            }
                            s[p] = Fe(wn, d, {
                                body: m
                            });
                            continue;
                        }
                    }
                    if (d instanceof Tn) {
                        var g = U(d.body);
                        if (q(g)) {
                            if (g.label) rt(g.label.thedef.references, g);
                            o = true;
                            d = d.clone();
                            d.body = Fe(xn, d, {
                                body: z(d.body, g)
                            });
                            d.alternative = Fe(xn, d, {
                                body: G(d.alternative).concat(O(c, u))
                            });
                            C(g.value, c);
                            s[p] = d;
                            s[p] = d.transform(r);
                            continue;
                        }
                        if (g && !d.alternative && v instanceof Kt) {
                            var b = d.condition;
                            var y = p + 1 == h && d.body instanceof xn;
                            b = le(b, b.negate(r), y);
                            if (b !== d.condition) {
                                o = true;
                                d = d.clone();
                                d.condition = b;
                                var m = d.body;
                                d.body = Fe(xn, v, {
                                    body: O(true, null, h + 1)
                                });
                                s.splice(p, 1, d, m);
                                if (!H || a instanceof pt && a.body === s) {
                                    s[p] = d.transform(r);
                                }
                                continue;
                            }
                        }
                        var w = U(d.alternative);
                        if (q(w)) {
                            if (w.label) rt(w.label.thedef.references, w);
                            o = true;
                            d = d.clone();
                            d.body = Fe(xn, d.body, {
                                body: G(d.body).concat(O(c, u))
                            });
                            d.alternative = Fe(xn, d.alternative, {
                                body: z(d.alternative, w)
                            });
                            C(w.value, c);
                            s[p] = d;
                            s[p] = d.transform(r);
                            continue;
                        }
                        if (r.option("typeofs")) {
                            if (g && !w) {
                                var x = Fe(xn, a, {
                                    body: s.slice(p + 1)
                                });
                                V(d.condition, null, x);
                            }
                            if (!g && w) {
                                var x = Fe(xn, a, {
                                    body: s.slice(p + 1)
                                });
                                V(d.condition, x);
                            }
                        }
                    }
                    if (d instanceof Tn && d.body instanceof Sn) {
                        var k = d.body.value;
                        var P = d.body.in_bool || v instanceof Sn && v.in_bool;
                        if (!d.alternative && v instanceof Sn && (t || !k == !v.value)) {
                            o = true;
                            d = d.clone();
                            d.alternative = Fe(xn, v, {
                                body: O(true, null, h + 1)
                            });
                            s[p] = d;
                            s[p] = d.transform(r);
                            continue;
                        }
                        if (H && f && !v && !d.alternative && (P || k && l || k instanceof Nn && (Ie(k.consequent, r) || Ie(k.alternative, r)))) {
                            o = true;
                            d = d.clone();
                            d.alternative = Fe(Sn, d, {
                                value: null
                            });
                            s[p] = d;
                            s[p] = d.transform(r);
                            continue;
                        }
                        var E, S;
                        if (n && !d.alternative && (!(S = s[E = I(p)]) && e || S instanceof Tn && S.body instanceof Sn) && (!v ? !f : v instanceof wn && M(h) == s.length)) {
                            o = true;
                            var T = [];
                            d = d.clone();
                            T.push(d.condition);
                            d.condition = Pe(d, T);
                            d.alternative = Fe(xn, a, {
                                body: O().concat(Fe(Sn, a, {
                                    value: null
                                }))
                            });
                            s[p] = d.transform(r);
                            p = E + 1;
                            continue;
                        }
                    }
                    if (d instanceof nr || d instanceof Qt) {
                        u = d;
                        continue;
                    }
                    if (f && u && u === v) F(d);
                }
                return o;
                function j(e) {
                    var n = 0;
                    for (var t = e.length; --t >= 0; ) {
                        var r = e[t];
                        if (r instanceof Tn && r.body instanceof Sn) {
                            if (++n > 1) return true;
                        }
                    }
                    return false;
                }
                function A(n) {
                    return Y(r, function(e) {
                        return e === n;
                    });
                }
                function D(e, n) {
                    if (!u) return false;
                    if (u.TYPE != e.TYPE) return false;
                    var t = e.value;
                    if (!t) return false;
                    var r = u.equals(e);
                    if (!r && t instanceof On) {
                        t = t.tail_node();
                        if (u.value && u.value.equals(t)) r = 2;
                    }
                    if (!r && !n && u.value instanceof On) {
                        if (u.value.tail_node().equals(t)) r = 3;
                    }
                    return r;
                }
                function N(e) {
                    if (e instanceof Qt) {
                        if (c = D(e)) return true;
                        if (!H) return false;
                        if (!(e instanceof Sn)) return false;
                        var n = e.value;
                        if (n && !Ie(n.tail_node())) return false;
                        if (!(a instanceof ir)) return true;
                        if (!u) return false;
                        if (u instanceof Qt && u.value) return false;
                        c = 4;
                        return true;
                    }
                    if (!(e instanceof er)) return false;
                    if (a instanceof ir) {
                        if (u instanceof Qt) {
                            if (!H) return false;
                            if (u.value) return false;
                            c = true;
                        } else if (u) {
                            if (r.loopcontrol_target(u) !== i) return false;
                            c = true;
                        } else if (u === false) {
                            return false;
                        }
                    }
                    var t = r.loopcontrol_target(e);
                    if (e instanceof tr) return A(J(t));
                    if (t instanceof ht) return false;
                    return A(t);
                }
                function q(e) {
                    c = false;
                    if (!N(e)) return false;
                    for (var n = s.length; --n > p; ) {
                        var t = s[n];
                        if (t instanceof Bt) {
                            if (t.name.definition().preinit) return false;
                        } else if (t instanceof lr || t instanceof pr) {
                            if (!_n(t.definitions, function(e) {
                                return !e.name.match_symbol(function(e) {
                                    return e instanceof zr && e.definition().preinit;
                                });
                            })) return false;
                        }
                    }
                    return true;
                }
                function O(e, n, t) {
                    var r = [];
                    var i = false;
                    var a = p + 1;
                    if (!e) {
                        t = s.length;
                        u = null;
                    } else if (n) {
                        t = s.lastIndexOf(n);
                    } else {
                        n = s[t];
                        if (n !== u) u = false;
                    }
                    var o = s.splice(a, t - a).filter(function(e) {
                        if (e instanceof jt) {
                            r.push(e);
                            return false;
                        }
                        if (W(e)) i = true;
                        return true;
                    });
                    if (e === 3) {
                        o.push(Fe(wn, n.value, {
                            body: Pe(n.value, n.value.expressions.slice(0, -1))
                        }));
                        n.value = n.value.tail_node();
                    }
                    [].push.apply(i ? o : s, r);
                    return o;
                }
                function $(e, n) {
                    if (e) switch (n) {
                      case 4:
                        return e;

                      case 3:
                        if (!(e instanceof On)) break;

                      case 2:
                        return Pe(e, e.expressions.slice(0, -1));
                    }
                }
                function z(e, n) {
                    var t = G(e);
                    var r = t, i;
                    while ((i = r[r.length - 1]) !== n) {
                        r = i.body;
                    }
                    r.pop();
                    var a = n.value;
                    if (c) a = $(a, c);
                    if (a) r.push(Fe(wn, a, {
                        body: a
                    }));
                    return t;
                }
                function C(e, n) {
                    if (!n) return;
                    if (!e) return;
                    switch (n) {
                      case 4:
                        return;

                      case 3:
                      case 2:
                        e = e.tail_node();
                    }
                    B(e, u.value);
                }
                function M(e) {
                    f = true;
                    for (var n = e; ++n < s.length; ) {
                        var t = s[n];
                        if (L(t)) continue;
                        if (t instanceof dr) {
                            f = false;
                            continue;
                        }
                        break;
                    }
                    return n;
                }
                function I(e) {
                    for (var n = e; --n >= 0; ) {
                        var t = s[n];
                        if (t instanceof dr) continue;
                        if (L(t)) continue;
                        break;
                    }
                    return n;
                }
                function F(e, n, t) {
                    if (e instanceof Qt) {
                        var r = !(n && e instanceof Zt) && D(e, true);
                        if (r) {
                            o = true;
                            var i = $(e.value, r);
                            if (i) return Fe(wn, i, {
                                body: i
                            });
                            return t ? null : Fe(yn, e);
                        }
                    } else if (e instanceof Tn) {
                        e.body = F(e.body, n);
                        if (e.alternative) e.alternative = F(e.alternative, n);
                    } else if (e instanceof dt) {
                        e.body = F(e.body, n);
                    } else if (e instanceof sr) {
                        if (!e.bfinally || !u.value || u.value.is_constant()) {
                            if (e.bcatch) F(e.bcatch, n);
                            var a = F(e.body.pop(), true, true);
                            if (a) e.body.push(a);
                        }
                    } else if (e instanceof pt && !(e instanceof kn || e instanceof rr)) {
                        var a = F(e.body.pop(), n, true);
                        if (a) e.body.push(a);
                    }
                    return e;
                }
            }
            function u(n, t) {
                var e;
                var r = t.self();
                if (r instanceof fr) {
                    r = t.parent();
                } else if (r instanceof dt) {
                    r = r.body;
                }
                for (var i = 0, a = 0, o = n.length; i < o; i++) {
                    var s = n[i];
                    if (s instanceof er) {
                        var f = t.loopcontrol_target(s);
                        if (J(f) !== r || s instanceof nr && f instanceof ht) {
                            n[a++] = s;
                        } else if (s.label) {
                            rt(s.label.thedef.references, s);
                        }
                    } else {
                        n[a++] = s;
                    }
                    if (U(s)) {
                        e = n.slice(i + 1);
                        break;
                    }
                }
                n.length = a;
                if (e) e.forEach(function(e) {
                    P(t, e, n);
                });
                return n.length != o;
            }
            function c(e, n) {
                if (!H || qe && qe.bfinally) return;
                var t = false;
                for (var r = e.length; --r >= 0; ) {
                    var i = e[r];
                    if (!(i instanceof wn)) break;
                    var a = i.body;
                    if (!(a instanceof wr)) break;
                    var o = a.expression;
                    if (!x(n, o)) break;
                    t = true;
                    o = o.drop_side_effect_free(n, true);
                    if (o) {
                        i.body = o;
                        break;
                    }
                }
                e.length = r + 1;
                return t;
            }
            function l(e, n) {
                var t = false;
                var r = e.length - 1;
                if (H && r >= 0) {
                    var i = qe && qe.bfinally && R(Oe);
                    var a = e[r].try_inline(n, Se, i);
                    if (a) {
                        e[r--] = a;
                        t = true;
                    }
                }
                var o = De && qe && qe.bfinally ? "try" : De;
                for (;r >= 0; r--) {
                    var a = e[r].try_inline(n, Se, true, o);
                    if (!a) continue;
                    e[r] = a;
                    t = true;
                }
                return t;
            }
            function p(n, e) {
                if (n.length < 2) return;
                var t = [], r = 0;
                function i() {
                    if (!t.length) return;
                    var e = Pe(t[0], t);
                    n[r++] = Fe(wn, e, {
                        body: e
                    });
                    t = [];
                }
                for (var a = 0, o = n.length; a < o; a++) {
                    var s = n[a];
                    if (s instanceof wn) {
                        if (t.length >= e.sequences_limit) i();
                        k(t, s.body);
                    } else if (L(s)) {
                        n[r++] = s;
                    } else {
                        i();
                        n[r++] = s;
                    }
                }
                i();
                n.length = r;
                return r != o;
            }
            function d(e, n) {
                if (!(e instanceof xn)) return e;
                var t = null;
                for (var r = 0; r < e.body.length; r++) {
                    var i = e.body[r];
                    if (i instanceof dr && ce(i)) {
                        n.push(i);
                    } else if (t || W(i)) {
                        return false;
                    } else {
                        t = i;
                    }
                }
                return t;
            }
            function h(e, n) {
                var t = false, r = 0, i;
                for (var a = 0; a < e.length; a++) {
                    var o = e[a];
                    if (i) {
                        if (o instanceof Qt) {
                            if (o.value || !R(Oe)) {
                                o.value = p(o.value || Fe(Qr, o)).optimize(n);
                            }
                        } else if (o instanceof gt) {
                            if (!(o.init instanceof cr)) {
                                var s = false;
                                i.body.walk(new Gn(function(e) {
                                    if (s || e instanceof kn) return true;
                                    if (e instanceof jn && e.operator == "in") {
                                        s = true;
                                        return true;
                                    }
                                }));
                                if (!s) {
                                    if (o.init) o.init = p(o.init); else {
                                        o.init = i.body;
                                        r--;
                                        t = true;
                                    }
                                }
                            }
                        } else if (o instanceof yt) {
                            if (!W(o.init)) o.object = p(o.object);
                        } else if (o instanceof Tn) {
                            o.condition = p(o.condition);
                        } else if (o instanceof rr) {
                            o.expression = p(o.expression);
                        } else if (o instanceof xt) {
                            o.expression = p(o.expression);
                        }
                    }
                    if (n.option("conditionals") && o instanceof Tn) {
                        var f = [];
                        var u = d(o.body, f);
                        var c = d(o.alternative, f);
                        if (u !== false && c !== false && f.length > 0) {
                            var l = f.length;
                            f.push(Fe(Tn, o, {
                                condition: o.condition,
                                body: u || Fe(yn, o.body),
                                alternative: c
                            }));
                            f.unshift(r, 1);
                            [].splice.apply(e, f);
                            a += l;
                            r += l + 1;
                            i = null;
                            t = true;
                            continue;
                        }
                    }
                    e[r++] = o;
                    i = o instanceof wn ? o : null;
                }
                e.length = r;
                return t;
                function p(e) {
                    r--;
                    t = true;
                    var n = i.body;
                    return Pe(n, [ n, e ]);
                }
            }
            function v(e) {
                if (e instanceof In) return [ e ];
                if (e instanceof On) return e.expressions.slice();
            }
            function m(e, n, t) {
                var r = v(n);
                if (!r) return;
                t = t || 0;
                var i = false;
                for (var a = r.length - t; --a >= 0; ) {
                    var o = r[a];
                    if (!c(o)) continue;
                    var s;
                    if (o.left instanceof Ln) {
                        s = r.slice(a + 1);
                    } else if (o.left instanceof $n && c(o.left.expression)) {
                        s = r.slice(a + 1);
                        var f = o.clone();
                        o = o.left.expression;
                        f.left = f.left.clone();
                        f.left.expression = o.left.clone();
                        s.unshift(f);
                    } else {
                        continue;
                    }
                    if (s.length == 0) continue;
                    if (!y(o.left, o.right, s)) continue;
                    i = true;
                    r = r.slice(0, a).concat(o, s);
                }
                if (e instanceof cr) {
                    for (var a = e.definitions.length; --a >= 0; ) {
                        var u = e.definitions[a];
                        if (!u.value) continue;
                        if (y(u.name, u.value, r)) i = true;
                        if (g(u, r, t)) i = true;
                        break;
                    }
                    if (e instanceof dr && b(e.definitions, r, t)) i = true;
                }
                return i && r;
                function c(e) {
                    return e instanceof In && e.operator == "=";
                }
            }
            function _(e, n) {
                if (!(e instanceof wn)) return;
                if (ce(n)) return;
                var t = v(e.body);
                if (!t) return;
                var r = [];
                if (!b(r, t.reverse(), 0)) return;
                n.definitions = r.reverse().concat(n.definitions);
                return t.reverse();
            }
            function g(e, n, t) {
                if (!s.option("conditionals")) return;
                if (e.name instanceof Yn) return;
                var r = false;
                var i = e.name.definition();
                while (n.length > t) {
                    var a = se(s, i, e.value, n[0]);
                    if (!a) break;
                    e.value = a;
                    n.shift();
                    r = true;
                }
                return r;
            }
            function b(e, n, t) {
                var r = false;
                while (n.length > t) {
                    var i = n[0];
                    if (!(i instanceof In)) break;
                    if (i.operator != "=") break;
                    var a = i.left;
                    if (!(a instanceof Ln)) break;
                    if (Ne(a)) break;
                    if (a.scope.resolve() !== Oe) break;
                    var o = a.definition();
                    if (o.scope !== Oe) break;
                    if (o.orig.length > o.eliminated + 1) break;
                    if (o.orig[0].TYPE != "SymbolVar") break;
                    var s = Fe(Pr, a);
                    e.push(Fe(An, i, {
                        name: s,
                        value: i.right
                    }));
                    o.orig.push(s);
                    o.replaced++;
                    n.shift();
                    r = true;
                }
                return r;
            }
            function y(e, i, n) {
                var a = new gn();
                a.set(e.name, true);
                while (i instanceof In && i.operator == "=") {
                    if (i.left instanceof Ln) a.set(i.left.name, true);
                    i = i.right;
                }
                if (!(i instanceof Rn)) return;
                var t = false;
                do {
                    if (!o(n[0])) break;
                    n.shift();
                    t = true;
                } while (n.length);
                return t;
                function o(e) {
                    if (!(e instanceof In)) return;
                    if (e.operator != "=") return;
                    if (!(e.left instanceof $n)) return;
                    var n = e.left.expression;
                    if (!(n instanceof Ln)) return;
                    if (!a.has(n.name)) return;
                    if (!e.right.is_constant_expression(Oe)) return;
                    var t = e.left.property;
                    if (t instanceof bn) {
                        if (o(t)) t = e.left.property = t.right.clone();
                        t = t.evaluate(s);
                    }
                    if (t instanceof bn) return;
                    t = "" + t;
                    var r = t == "__proto__" || s.has_directive("use strict") ? function(e) {
                        var n = e.key;
                        return typeof n == "string" && n != t && n != "__proto__";
                    } : function(e) {
                        var n = e.key;
                        if (e instanceof Or || e instanceof qr) {
                            return typeof n == "string" && n != t;
                        }
                        return n !== "__proto__";
                    };
                    if (!_n(i.properties, r)) return;
                    i.properties.push(Fe(Ar, e, {
                        key: t,
                        value: e.right
                    }));
                    return true;
                }
            }
            function w(e) {
                var i = false, a;
                for (var n = 0, t = -1; n < e.length; n++) {
                    var r = e[n];
                    var o = e[t];
                    if (r instanceof cr) {
                        if (o && o.TYPE == r.TYPE) {
                            o.definitions = o.definitions.concat(r.definitions);
                            i = true;
                        } else if (a && a.TYPE == r.TYPE && ce(r)) {
                            a.definitions = a.definitions.concat(r.definitions);
                            i = true;
                        } else if (r instanceof dr) {
                            var s = _(o, r);
                            if (s) {
                                if (s.length) {
                                    o.body = Pe(o, s);
                                    t++;
                                }
                                i = true;
                            } else {
                                t++;
                            }
                            e[t] = a = r;
                        } else {
                            e[++t] = r;
                        }
                        continue;
                    } else if (r instanceof Qt) {
                        r.value = c(r.value);
                    } else if (r instanceof gt) {
                        var s = m(o, r.init);
                        if (s) {
                            i = true;
                            r.init = s.length ? Pe(r.init, s) : null;
                        } else if (o instanceof dr && (!r.init || r.init.TYPE == o.TYPE)) {
                            if (r.init) {
                                o.definitions = o.definitions.concat(r.init.definitions);
                            }
                            r = r.clone();
                            a = r.init = o;
                            e[t] = l(r);
                            i = true;
                            continue;
                        } else if (a && r.init && a.TYPE == r.init.TYPE && ce(r.init)) {
                            a.definitions = a.definitions.concat(r.init.definitions);
                            r.init = null;
                            i = true;
                        } else if (r.init instanceof dr) {
                            a = r.init;
                            s = _(o, r.init);
                            if (s) {
                                i = true;
                                if (s.length == 0) {
                                    e[t] = l(r);
                                    continue;
                                }
                                o.body = Pe(o, s);
                            }
                        }
                    } else if (r instanceof bt) {
                        if (a && a.TYPE == r.init.TYPE) {
                            var f = a.definitions.slice();
                            r.init = r.init.definitions[0].name.convert_symbol(Ln, function(e, n) {
                                f.push(Fe(An, n, {
                                    name: n,
                                    value: null
                                }));
                                n.definition().references.push(e);
                            });
                            a.definitions = f;
                            i = true;
                        }
                        r.object = c(r.object);
                    } else if (r instanceof Tn) {
                        r.condition = c(r.condition);
                    } else if (r instanceof wn) {
                        var s = m(o, r.body), u;
                        if (s) {
                            i = true;
                            if (!s.length) continue;
                            r.body = Pe(r.body, s);
                        } else if (o instanceof cr && (u = e[n + 1]) && o.TYPE == u.TYPE && (u = u.definitions[0]).value) {
                            i = true;
                            u.value = Pe(r, [ r.body, u.value ]);
                            continue;
                        }
                    } else if (r instanceof rr) {
                        r.expression = c(r.expression);
                    } else if (r instanceof xt) {
                        r.expression = c(r.expression);
                    }
                    e[++t] = a ? l(r) : r;
                }
                e.length = t + 1;
                return i;
                function c(e) {
                    var n = m(o, e, 1);
                    if (!n) return e;
                    i = true;
                    var t = e.tail_node();
                    if (n[n.length - 1] !== t) n.push(t.left);
                    return Pe(e, n);
                }
                function l(e) {
                    return e.transform(new ii(function(e, n, t) {
                        if (e instanceof cr) {
                            if (a === e) return e;
                            if (a.TYPE != e.TYPE) return e;
                            var r = this.parent();
                            if (r instanceof bt && r.init === e) return e;
                            if (!ce(e)) return e;
                            a.definitions = a.definitions.concat(e.definitions);
                            i = true;
                            if (r instanceof gt && r.init === e) return null;
                            return t ? et.skip : Fe(yn, e);
                        }
                        if (e instanceof hr) return e;
                        if (e instanceof kn) return e;
                        if (!ut(e)) return e;
                    }));
                }
            }
        }
        function P(i, a, o) {
            var s;
            var f = false;
            a.walk(new Gn(function(e, n) {
                if (e instanceof Bt) {
                    e.extends = null;
                    e.properties = [];
                    u(e);
                    return true;
                }
                if (e instanceof cr) {
                    var t = [];
                    if (e.remove_initializers(i, t)) {
                        bn.warn("Dropping initialization in unreachable code [{start}]", e);
                    }
                    if (t.length > 0) {
                        e.definitions = t;
                        u(e);
                    }
                    return true;
                }
                if (e instanceof jt) {
                    u(e);
                    return true;
                }
                if (e instanceof kn) return true;
                if (e instanceof ct) {
                    var r = s;
                    s = [];
                    n();
                    if (s.required) {
                        o.push(Fe(xn, a, {
                            body: s
                        }));
                    } else if (s.length) {
                        [].push.apply(o, s);
                    }
                    s = r;
                    return true;
                }
                if (!(e instanceof er)) f = true;
            }));
            if (f) bn.warn("Dropping unreachable code [{start}]", a);
            function u(e) {
                if (s) {
                    s.push(e);
                    if (!S(e)) s.required = true;
                } else {
                    o.push(e);
                }
            }
        }
        function Ie(e, n) {
            return e == null || e.is_undefined || e instanceof Qr || e instanceof Pn && e.operator == "void" && !(n && e.expression.has_side_effects(n));
        }
        (function(e) {
            e(Rt, vn);
            e(kn, function(e) {
                var n = this.body;
                for (var t = 0; t < n.length; t++) {
                    var r = n[t];
                    if (!(r instanceof ft)) break;
                    if (r.value == "use strict") return true;
                }
                var i = this.parent_scope;
                if (!i) return e.option("module");
                return i.resolve(true).in_strict_mode(e);
            });
        })(function(e, n) {
            e.DEFMETHOD("in_strict_mode", n);
        });
        (function(e) {
            e(bn, hn);
            e(Hn, vn);
            e(In, function() {
                return this.operator == "=" && this.right.is_truthy();
            });
            e(En, vn);
            e(Rn, vn);
            e(Gr, vn);
            e(On, function() {
                return this.tail_node().is_truthy();
            });
            e(Ln, function() {
                var e = this.fixed_value();
                if (!e) return false;
                this.is_truthy = hn;
                var n = e.is_truthy();
                delete this.is_truthy;
                return n;
            });
        })(function(e, n) {
            e.DEFMETHOD("is_truthy", n);
        });
        (function(e) {
            e(bn, vn);
            e(Hn, hn);
            function n(e, n, t) {
                switch (e) {
                  case "-":
                    return n.is_negative_zero() && (!(t instanceof Un) || t.value == 0);

                  case "&&":
                  case "||":
                    return n.is_negative_zero() || t.is_negative_zero();

                  case "*":
                  case "/":
                  case "%":
                  case "**":
                    return true;

                  default:
                    return false;
                }
            }
            e(In, function() {
                var e = this.operator;
                if (e == "=") return this.right.is_negative_zero();
                return n(e.slice(0, -1), this.left, this.right);
            });
            e(jn, function() {
                return n(this.operator, this.left, this.right);
            });
            e(Un, function() {
                return this.value == 0 && 1 / this.value < 0;
            });
            e(En, hn);
            e(Rn, hn);
            e(Gr, hn);
            e(On, function() {
                return this.tail_node().is_negative_zero();
            });
            e(Ln, function() {
                var e = this.fixed_value();
                if (!e) return true;
                this.is_negative_zero = vn;
                var n = e.is_negative_zero();
                delete this.is_negative_zero;
                return n;
            });
            e(Pn, function() {
                return this.operator == "+" && this.expression.is_negative_zero() || this.operator == "-";
            });
        })(function(e, n) {
            e.DEFMETHOD("is_negative_zero", n);
        });
        (function(e) {
            bn.DEFMETHOD("may_throw_on_access", function(e, n) {
                return !e.option("pure_getters") || this._dot_throw(e, n);
            });
            function i(e, n) {
                return n || /strict/.test(e.option("pure_getters"));
            }
            e(bn, i);
            e(Hn, hn);
            e(In, function(e) {
                var n = this.operator;
                var t = this.left;
                var r = this.right;
                if (n != "=") {
                    return He[n.slice(0, -1)] && (t._dot_throw(e) || r._dot_throw(e));
                }
                if (!r._dot_throw(e)) return false;
                if (!(t instanceof Ln)) return true;
                if (r instanceof jn && r.operator == "||" && t.name == r.left.name) {
                    return r.right._dot_throw(e);
                }
                return true;
            });
            e(jn, function(e) {
                return He[this.operator] && (this.left._dot_throw(e) || this.right._dot_throw(e));
            });
            e(Rt, function(e, n) {
                return i(e, n) && !_n(this.properties, function(e) {
                    if (e.private) return true;
                    if (!e.static) return true;
                    return !(e instanceof Wt || e instanceof Gt);
                });
            });
            e(Nn, function(e) {
                return this.consequent._dot_throw(e) || this.alternative._dot_throw(e);
            });
            e(Un, hn);
            e(zn, function(e, n) {
                if (!i(e, n)) return false;
                var t = this.expression;
                if (t instanceof Ln) t = t.fixed_value();
                return !(this.property == "prototype" && M(t));
            });
            e(En, hn);
            e(Xr, vn);
            e(Rn, function(n, t) {
                return i(n, t) && !_n(this.properties, function(e) {
                    if (e instanceof Or || e instanceof qr) return false;
                    return !(e.key === "__proto__" && e.value._dot_throw(n, t));
                });
            });
            e(Rr, function(e, n) {
                return i(e, n) && !this.scope.resolve().new;
            });
            e(On, function(e) {
                return this.tail_node()._dot_throw(e);
            });
            e(Ln, function(e, n) {
                if (this.is_undefined) return true;
                if (!i(e, n)) return false;
                if (Ne(this) && this.is_declared(e)) return false;
                if (this.is_immutable()) return false;
                var t = this.definition();
                if (ze(t) && !t.scope.rest && _n(t.scope.argnames, function(e) {
                    return e instanceof Bn;
                })) return t.scope.uses_arguments > 2;
                var r = this.fixed_value(true);
                if (!r) return true;
                this._dot_throw = vn;
                if (r._dot_throw(e)) {
                    delete this._dot_throw;
                    return true;
                }
                this._dot_throw = hn;
                return false;
            });
            e(Pn, function() {
                return this.operator == "void";
            });
            e(yr, hn);
            e(Qr, vn);
        })(function(e, n) {
            e.DEFMETHOD("_dot_throw", n);
        });
        (function(e) {
            e(bn, hn);
            e(Hn, vn);
            function t(e, n, t) {
                switch (n) {
                  case "&&":
                    return t.left.is_defined(e) && t.right.is_defined(e);

                  case "||":
                    return t.left.is_truthy() || t.right.is_defined(e);

                  case "??":
                    return t.left.is_defined(e) || t.right.is_defined(e);

                  default:
                    return true;
                }
            }
            e(In, function(e) {
                var n = this.operator;
                if (n == "=") return this.right.is_defined(e);
                return t(e, n.slice(0, -1), this);
            });
            e(jn, function(e) {
                return t(e, this.operator, this);
            });
            e(Nn, function(e) {
                return this.consequent.is_defined(e) && this.alternative.is_defined(e);
            });
            e(Un, vn);
            e(Zr, hn);
            e(En, vn);
            e(Rn, vn);
            e(On, function(e) {
                return this.tail_node().is_defined(e);
            });
            e(Ln, function(e) {
                if (this.is_undefined) return false;
                if (Ne(this) && this.is_declared(e)) return true;
                if (this.is_immutable()) return true;
                var n = this.fixed_value();
                if (!n) return false;
                this.is_defined = hn;
                var t = n.is_defined(e);
                delete this.is_defined;
                return t;
            });
            e(Pn, function() {
                return this.operator != "void";
            });
            e(yr, vn);
            e(Qr, hn);
        })(function(e, n) {
            e.DEFMETHOD("is_defined", n);
        });
        (function(e) {
            e(bn, hn);
            e(In, function(e) {
                return this.operator == "=" && this.right.is_boolean(e);
            });
            var n = mn("in instanceof == != === !== < <= >= >");
            e(jn, function(e) {
                return n[this.operator] || He[this.operator] && this.left.is_boolean(e) && this.right.is_boolean(e);
            });
            e(ni, vn);
            var t = mn("every hasOwnProperty isPrototypeOf propertyIsEnumerable some");
            e(qn, function(e) {
                if (!e.option("unsafe")) return false;
                var n = this.expression;
                return n instanceof zn && (t[n.property] || n.property == "test" && n.expression instanceof Gr);
            });
            e(Nn, function(e) {
                return this.consequent.is_boolean(e) && this.alternative.is_boolean(e);
            });
            e(gr, hn);
            e(On, function(e) {
                return this.tail_node().is_boolean(e);
            });
            e(Ln, function(e) {
                var n = this.fixed_value();
                if (!n) return false;
                this.is_boolean = hn;
                var t = n.is_boolean(e);
                delete this.is_boolean;
                return t;
            });
            var r = mn("! delete");
            e(Pn, function() {
                return r[this.operator];
            });
        })(function(e, n) {
            e.DEFMETHOD("is_boolean", n);
        });
        (function(e) {
            e(bn, hn);
            var n = mn("- * / % ** & | ^ << >> >>>");
            e(In, function(e) {
                return n[this.operator.slice(0, -1)] || this.operator == "=" && this.right.is_number(e);
            });
            e(jn, function(e) {
                if (n[this.operator]) return true;
                if (this.operator != "+") return false;
                return (this.left.is_boolean(e) || this.left.is_number(e)) && (this.right.is_boolean(e) || this.right.is_number(e));
            });
            var t = mn([ "charCodeAt", "getDate", "getDay", "getFullYear", "getHours", "getMilliseconds", "getMinutes", "getMonth", "getSeconds", "getTime", "getTimezoneOffset", "getUTCDate", "getUTCDay", "getUTCFullYear", "getUTCHours", "getUTCMilliseconds", "getUTCMinutes", "getUTCMonth", "getUTCSeconds", "getYear", "indexOf", "lastIndexOf", "localeCompare", "push", "search", "setDate", "setFullYear", "setHours", "setMilliseconds", "setMinutes", "setMonth", "setSeconds", "setTime", "setUTCDate", "setUTCFullYear", "setUTCHours", "setUTCMilliseconds", "setUTCMinutes", "setUTCMonth", "setUTCSeconds", "setYear" ]);
            e(qn, function(e) {
                if (!e.option("unsafe")) return false;
                var n = this.expression;
                return n instanceof zn && (t[n.property] || Ne(n.expression) && n.expression.name == "Math");
            });
            e(Nn, function(e) {
                return this.consequent.is_number(e) && this.alternative.is_number(e);
            });
            e(gr, hn);
            e(Wn, vn);
            e(On, function(e) {
                return this.tail_node().is_number(e);
            });
            e(Ln, function(e, n) {
                var t = this.fixed_value();
                if (!t) return false;
                if (n && t instanceof Pn && t.operator == "+" && t.expression.equals(this)) {
                    return false;
                }
                this.is_number = hn;
                var r = t.is_number(e);
                delete this.is_number;
                return r;
            });
            var r = mn("+ - ~ ++ --");
            e(Fn, function() {
                return r[this.operator];
            });
        })(function(e, n) {
            e.DEFMETHOD("is_number", n);
        });
        (function(e) {
            e(bn, hn);
            e(In, function(e) {
                switch (this.operator) {
                  case "+=":
                    if (this.left.is_string(e)) return true;

                  case "=":
                    return this.right.is_string(e);
                }
            });
            e(jn, function(e) {
                return this.operator == "+" && (this.left.is_string(e) || this.right.is_string(e));
            });
            var t = mn([ "charAt", "substr", "substring", "toExponential", "toFixed", "toLowerCase", "toPrecision", "toString", "toUpperCase", "trim" ]);
            e(qn, function(e) {
                if (!e.option("unsafe")) return false;
                var n = this.expression;
                return n instanceof zn && t[n.property];
            });
            e(Nn, function(e) {
                return this.consequent.is_string(e) && this.alternative.is_string(e);
            });
            e(On, function(e) {
                return this.tail_node().is_string(e);
            });
            e(Vn, vn);
            e(Ln, function(e) {
                var n = this.fixed_value();
                if (!n) return false;
                this.is_string = hn;
                var t = n.is_string(e);
                delete this.is_string;
                return t;
            });
            e(Vr, function(e) {
                return !this.tag || nn(e, this.tag);
            });
            e(Pn, function() {
                return this.operator == "typeof";
            });
        })(function(e, n) {
            e.DEFMETHOD("is_string", n);
        });
        var He = mn("&& || ??");
        (function(e) {
            function i(e, n) {
                if (e instanceof bn) return e.clone(true);
                if (Array.isArray(e)) return Fe(Hn, n, {
                    elements: e.map(function(e) {
                        return i(e, n);
                    })
                });
                if (e && typeof e == "object") {
                    var t = [];
                    for (var r in e) if (it(e, r)) {
                        t.push(Fe(Ar, n, {
                            key: r,
                            value: i(e[r], n)
                        }));
                    }
                    return Fe(Rn, n, {
                        properties: t
                    });
                }
                return fe(e, n);
            }
            function o(e) {
                bn.warn("global_defs {this} redefined [{start}]", e);
            }
            kt.DEFMETHOD("resolve_defines", function(a) {
                if (!a.option("global_defs")) return this;
                this.figure_out_scope({
                    ie: a.option("ie")
                });
                return this.transform(new ii(function(e) {
                    var n = e._find_defs(a, "");
                    if (!n) return;
                    var t = 0, r = e, i;
                    while (i = this.parent(t++)) {
                        if (!(i instanceof $n)) break;
                        if (i.expression !== r) break;
                        r = i;
                    }
                    if (di(r, i)) {
                        o(e);
                        return;
                    }
                    return n;
                }));
            });
            e(bn, Kn);
            e(zn, function(e, n) {
                return this.expression._find_defs(e, "." + this.property + n);
            });
            e(zr, function(e) {
                if (!this.definition().global) return;
                if (it(e.option("global_defs"), this.name)) o(this);
            });
            e(Ln, function(e, n) {
                if (!this.definition().global) return;
                var t = e.option("global_defs");
                var r = this.name + n;
                if (it(t, r)) return i(t[r], this);
            });
        })(function(e, n) {
            e.DEFMETHOD("_find_defs", n);
        });
        function le(e, n, t) {
            var r = n.print_to_string().length - e.print_to_string().length;
            return r < (t || 0) ? n : e;
        }
        function A(e, n, t) {
            return le(Fe(wn, e, {
                body: e
            }), Fe(wn, n, {
                body: n
            }), t).body;
        }
        function pe(e, n, t, r) {
            return (at(e) ? A : le)(n, t, r);
        }
        function s(n) {
            var t = Object.create(null);
            Object.keys(n).forEach(function(e) {
                t[e] = mn(n[e]);
            });
            return t;
        }
        function f(e) {
            for (var n = 0; n < e.length; n++) {
                var t = e[n];
                if (!(t instanceof ft)) return t;
            }
        }
        function u() {
            if (this.value) return Fe(Sn, this.value, {
                value: this.value
            });
            return f(this.body);
        }
        $t.DEFMETHOD("first_statement", u);
        zt.DEFMETHOD("first_statement", u);
        En.DEFMETHOD("first_statement", function() {
            return f(this.body);
        });
        En.DEFMETHOD("length", function() {
            var e = this.argnames;
            for (var n = 0; n < e.length; n++) {
                if (e[n] instanceof Dn) break;
            }
            return n;
        });
        function de(e, n) {
            var t = n.evaluate(e);
            if (t === n) return n;
            t = fe(t, n).optimize(e);
            return pe(e, n, t, e.eval_threshold);
        }
        var n = [ "constructor", "toString", "valueOf" ];
        var b = s({
            Array: [ "indexOf", "join", "lastIndexOf", "slice" ].concat(n),
            Boolean: n,
            Function: n,
            Number: [ "toExponential", "toFixed", "toPrecision" ].concat(n),
            Object: n,
            RegExp: [ "exec", "test" ].concat(n),
            String: [ "charAt", "charCodeAt", "concat", "indexOf", "italics", "lastIndexOf", "match", "replace", "search", "slice", "split", "substr", "substring", "toLowerCase", "toUpperCase", "trim" ].concat(n)
        });
        var w = s({
            Array: [ "isArray" ],
            Math: [ "abs", "acos", "asin", "atan", "ceil", "cos", "exp", "floor", "log", "round", "sin", "sqrt", "tan", "atan2", "pow", "max", "min" ],
            Number: [ "isFinite", "isNaN" ],
            Object: [ "create", "getOwnPropertyDescriptor", "getOwnPropertyNames", "getPrototypeOf", "isExtensible", "isFrozen", "isSealed", "keys" ],
            String: [ "fromCharCode", "raw" ]
        });
        function Je(e) {
            if (!(e instanceof zn)) return false;
            var n = e.expression;
            if (!Ne(n)) return false;
            var t = w[n.name];
            return t && (t[e.property] || n.name == "Math" && e.property == "random");
        }
        (function(e) {
            e(bn, hn);
            e(Un, vn);
            e(Gr, hn);
            var n = mn("! ~ - + void");
            e(Pn, function() {
                return n[this.operator] && this.expression instanceof Un;
            });
        })(function(e, n) {
            e.DEFMETHOD("is_constant", n);
        });
        (function(e) {
            bn.DEFMETHOD("evaluate", function(e, n) {
                if (!e.option("evaluate")) return this;
                var t = [];
                var r = this._eval(e, n, t, 1);
                t.forEach(function(e) {
                    delete e._eval;
                });
                if (n) return r;
                if (!r || r instanceof RegExp) return r;
                if (typeof r == "function" || typeof r == "object") return this;
                return r;
            });
            var m = new Gn(function(e) {
                if (e instanceof In) u(e.left);
                if (e instanceof bt) u(e.init);
                if (e instanceof Fn && fi[e.operator]) u(e.expression);
            });
            function u(e) {
                if (e instanceof kr) {
                    e.elements.forEach(u);
                } else if (e instanceof Sr) {
                    e.properties.forEach(function(e) {
                        u(e.value);
                    });
                } else if (e instanceof $n) {
                    u(e.expression);
                } else if (e instanceof Ln) {
                    e.definition().references.forEach(function(e) {
                        delete e._eval;
                    });
                }
            }
            e(ot, function() {
                throw new Error(tt("Cannot evaluate a statement [{start}]", this));
            });
            e(St, Qn);
            e(Wr, Qn);
            e(Rt, Qn);
            e(bn, Qn);
            e(Un, function() {
                return this.value;
            });
            e(In, function(e, n, t, r) {
                var i = this.left;
                if (!n) {
                    if (!(i instanceof Ln)) return this;
                    if (!it(i, "_eval")) {
                        if (!i.fixed) return this;
                        var a = i.definition();
                        if (!a.fixed) return this;
                        if (a.undeclared) return this;
                        if (a.last_ref !== i) return this;
                        if (a.single_use == "m") return this;
                        if (this.right.has_side_effects(e)) return this;
                    }
                }
                var o = this.operator;
                var s;
                if (!it(i, "_eval") && i instanceof Ln && i.fixed && i.definition().fixed) {
                    s = i;
                } else if (o == "=") {
                    s = this.right;
                } else {
                    s = Fe(jn, this, {
                        operator: o.slice(0, -1),
                        left: i,
                        right: this.right
                    });
                }
                i.walk(m);
                var f = s._eval(e, n, t, r);
                if (typeof f == "object") return this;
                u(i);
                return f;
            });
            e(On, function(e, n, t, r) {
                if (!n) return this;
                var i = this.expressions;
                for (var a = 0, o = i.length - 1; a < o; a++) {
                    i[a].walk(m);
                }
                var s = i[o];
                var f = s._eval(e, n, t, r);
                return f === s ? this : f;
            });
            e(En, function(e) {
                if (e.option("unsafe")) {
                    var n = function() {};
                    n.node = this;
                    n.toString = function() {
                        return "function(){}";
                    };
                    return n;
                }
                return this;
            });
            e(Hn, function(e, n, t, r) {
                if (e.option("unsafe")) {
                    var i = [];
                    for (var a = 0; a < this.elements.length; a++) {
                        var o = this.elements[a];
                        if (o instanceof Zr) return this;
                        var s = o._eval(e, n, t, r);
                        if (o === s) return this;
                        i.push(s);
                    }
                    return i;
                }
                return this;
            });
            e(Rn, function(e, n, t, r) {
                if (e.option("unsafe")) {
                    var i = {};
                    for (var a = 0; a < this.properties.length; a++) {
                        var o = this.properties[a];
                        if (!(o instanceof Ar)) return this;
                        var s = o.key;
                        if (s instanceof bn) {
                            s = s._eval(e, n, t, r);
                            if (s === o.key) return this;
                        }
                        switch (s) {
                          case "__proto__":
                          case "toString":
                          case "valueOf":
                            return this;
                        }
                        i[s] = o.value._eval(e, n, t, r);
                        if (i[s] === o.value) return this;
                    }
                    return i;
                }
                return this;
            });
            var f = mn("! typeof void");
            e(Pn, function(e, n, t, r) {
                var i = this.expression;
                var a = this.operator;
                if (e.option("typeofs") && a == "typeof" && (i instanceof En || i instanceof Ln && i.fixed_value() instanceof En)) {
                    return typeof function() {};
                }
                var o = i instanceof Ln && i.definition();
                if (!f[a] && !(o && o.fixed)) r++;
                i.walk(m);
                var s = i._eval(e, n, t, r);
                if (s === i) {
                    if (n && a == "void") return;
                    return this;
                }
                switch (a) {
                  case "!":
                    return !s;

                  case "typeof":
                    if (s instanceof RegExp) return this;
                    return typeof s;

                  case "void":
                    return;

                  case "~":
                    return ~s;

                  case "-":
                    return -s;

                  case "+":
                    return +s;

                  case "++":
                  case "--":
                    if (!o) return this;
                    if (!n) {
                        if (o.undeclared) return this;
                        if (o.last_ref !== i) return this;
                    }
                    if (it(i, "_eval")) s = +(a[0] + 1) + +s;
                    u(i);
                    return s;
                }
                return this;
            });
            e(yr, function(e, n, t, r) {
                var i = this.expression;
                if (!(i instanceof Ln)) {
                    if (!n) return this;
                } else if (!it(i, "_eval")) {
                    if (!i.fixed) return this;
                    if (!n) {
                        var a = i.definition();
                        if (!a.fixed) return this;
                        if (a.undeclared) return this;
                        if (a.last_ref !== i) return this;
                    }
                }
                if (!(i instanceof Ln && i.definition().fixed)) r++;
                i.walk(m);
                var o = i._eval(e, n, t, r);
                if (o === i) return this;
                u(i);
                return +o;
            });
            var c = mn("&& || === !==");
            e(jn, function(e, n, t, r) {
                if (!c[this.operator]) r++;
                var i = this.left._eval(e, n, t, r);
                if (i === this.left) return this;
                if (this.operator == (i ? "||" : "&&")) return i;
                var a = n && !(i && typeof i == "object");
                var o = this.right._eval(e, a, t, r);
                if (o === this.right) return this;
                var s;
                switch (this.operator) {
                  case "&&":
                    s = i && o;
                    break;

                  case "||":
                    s = i || o;
                    break;

                  case "??":
                    s = i == null ? o : i;
                    break;

                  case "|":
                    s = i | o;
                    break;

                  case "&":
                    s = i & o;
                    break;

                  case "^":
                    s = i ^ o;
                    break;

                  case "+":
                    s = i + o;
                    break;

                  case "-":
                    s = i - o;
                    break;

                  case "*":
                    s = i * o;
                    break;

                  case "/":
                    s = i / o;
                    break;

                  case "%":
                    s = i % o;
                    break;

                  case "<<":
                    s = i << o;
                    break;

                  case ">>":
                    s = i >> o;
                    break;

                  case ">>>":
                    s = i >>> o;
                    break;

                  case "==":
                    s = i == o;
                    break;

                  case "===":
                    s = i === o;
                    break;

                  case "!=":
                    s = i != o;
                    break;

                  case "!==":
                    s = i !== o;
                    break;

                  case "<":
                    s = i < o;
                    break;

                  case "<=":
                    s = i <= o;
                    break;

                  case ">":
                    s = i > o;
                    break;

                  case ">=":
                    s = i >= o;
                    break;

                  case "**":
                    s = Math.pow(i, o);
                    break;

                  case "in":
                    if (o && typeof o == "object" && it(o, i)) {
                        s = true;
                        break;
                    }

                  default:
                    return this;
                }
                if (isNaN(s)) return e.find_parent(xt) ? this : s;
                if (e.option("unsafe_math") && !n && s && typeof s == "number" && (this.operator == "+" || this.operator == "-")) {
                    var f = Math.max(0, u(i), u(o));
                    if (f < 16) return +s.toFixed(f);
                }
                return s;
                function u(e) {
                    var n = /(\.[0-9]*)?(e[^e]+)?$/.exec(+e);
                    return (n[1] || ".").length - 1 - (n[2] || "").slice(1);
                }
            });
            e(Nn, function(e, n, t, r) {
                var i = this.condition._eval(e, n, t, r);
                if (i === this.condition) return this;
                var a = i ? this.consequent : this.alternative;
                var o = a._eval(e, n, t, r);
                return o === a ? this : o;
            });
            function o(n, e) {
                var t = n.definition().escaped;
                switch (t.length) {
                  case 0:
                    return true;

                  case 1:
                    var r = false;
                    t[0].walk(new Gn(function(e) {
                        if (r) return true;
                        if (e === n) return r = true;
                        if (e instanceof kn) return true;
                    }));
                    return r;

                  default:
                    return e <= t.depth;
                }
            }
            e(Ln, function(e, n, t, r) {
                var i = this.fixed_value();
                if (!i) return this;
                var a;
                if (it(i, "_eval")) {
                    a = i._eval();
                } else {
                    this._eval = Qn;
                    a = i._eval(e, n, t, r);
                    delete this._eval;
                    if (a === i) return this;
                    i._eval = function() {
                        return a;
                    };
                    t.push(i);
                }
                return a && typeof a == "object" && !o(this, r) ? this : a;
            });
            var _ = {
                Array: Array,
                Math: Math,
                Number: Number,
                Object: Object,
                String: String
            };
            var l = s({
                Math: [ "E", "LN10", "LN2", "LOG2E", "LOG10E", "PI", "SQRT1_2", "SQRT2" ],
                Number: [ "MAX_VALUE", "MIN_VALUE", "NaN", "NEGATIVE_INFINITY", "POSITIVE_INFINITY" ]
            });
            var p = mn("global ignoreCase multiline source");
            e($n, function(e, n, t, r) {
                if (e.option("unsafe")) {
                    var i;
                    var a = this.expression;
                    if (!Ne(a)) {
                        i = a._eval(e, n, t, r + 1);
                        if (i == null || i === a) return this;
                    }
                    var o = this.property;
                    if (o instanceof bn) {
                        o = o._eval(e, n, t, r);
                        if (o === this.property) return this;
                    }
                    if (i === undefined) {
                        var s = l[a.name];
                        if (!s || !s[o]) return this;
                        i = _[a.name];
                    } else if (i instanceof RegExp) {
                        if (!p[o]) return this;
                    } else if (typeof i == "object") {
                        if (!it(i, o)) return this;
                    } else if (typeof i == "function") switch (o) {
                      case "name":
                        return i.node.name ? i.node.name.name : "";

                      case "length":
                        return i.node.length();

                      default:
                        return this;
                    }
                    return i[o];
                }
                return this;
            });
            function g(e, n, t, r, i) {
                var a = [];
                for (var o = 0; o < e.length; o++) {
                    var s = e[o];
                    var f = s._eval(n, t, r, i);
                    if (s === f) return;
                    a.push(f);
                }
                return a;
            }
            e(qn, function(r, i, a, o) {
                var e = this.expression;
                var n = e instanceof Ln ? e.fixed_value() : e;
                if (n instanceof $t || n instanceof Ht || n instanceof Ft) {
                    if (n.evaluating) return this;
                    if (n.name && n.name.definition().recursive_refs > 0) return this;
                    if (this.is_expr_pure(r)) return this;
                    var s = g(this.args, r, i, a, o);
                    if (!_n(n.argnames, function(e, n) {
                        if (e instanceof Dn) {
                            if (!s) return false;
                            if (s[n] === undefined) {
                                var t = e.value._eval(r, i, a, o);
                                if (t === e.value) return false;
                                s[n] = t;
                            }
                            e = e.name;
                        }
                        return !(e instanceof Yn);
                    })) return this;
                    if (n.rest instanceof Yn) return this;
                    if (!s && !i) return this;
                    var t = n.first_statement();
                    if (!(t instanceof Sn)) {
                        if (i) {
                            n.walk(m);
                            var f = false;
                            n.evaluating = true;
                            lt(n, new Gn(function(e) {
                                if (f) return true;
                                if (e instanceof Sn) {
                                    if (e.value && e.value._eval(r, true, a, o) !== undefined) {
                                        f = true;
                                    }
                                    return true;
                                }
                                if (e instanceof kn && e !== n) return true;
                            }));
                            n.evaluating = false;
                            if (!f) return;
                        }
                        return this;
                    }
                    var u = t.value;
                    if (!u) return;
                    var c = [];
                    if (!s || _n(n.argnames, function(e, n) {
                        return v(e, s[n]);
                    }) && !(n.rest && !v(n.rest, s.slice(n.argnames.length))) || i) {
                        if (i) n.argnames.forEach(function(e) {
                            if (e instanceof Dn) e.value.walk(m);
                        });
                        n.evaluating = true;
                        u = u._eval(r, i, a, o);
                        n.evaluating = false;
                    }
                    c.forEach(function(e) {
                        delete e._eval;
                    });
                    return u === t.value ? this : u;
                } else if (r.option("unsafe") && e instanceof $n) {
                    var l = e.property;
                    if (l instanceof bn) {
                        l = l._eval(r, i, a, o);
                        if (l === e.property) return this;
                    }
                    var u;
                    var p = e.expression;
                    if (Ne(p)) {
                        var d = w[p.name];
                        if (!d || !d[l]) return this;
                        u = _[p.name];
                    } else {
                        u = p._eval(r, i, a, o + 1);
                        if (u == null || u === p) return this;
                        var h = b[u.constructor.name];
                        if (!h || !h[l]) return this;
                        if (u instanceof RegExp && u.global && !(p instanceof Gr)) return this;
                    }
                    var s = g(this.args, r, i, a, o);
                    if (!s) return this;
                    if (l == "replace" && typeof s[1] == "function") return this;
                    try {
                        return u[l].apply(u, s);
                    } catch (e) {
                        bn.warn("Error evaluating {this} [{start}]", this);
                    } finally {
                        if (u instanceof RegExp) u.lastIndex = 0;
                    }
                }
                return this;
                function v(e, n) {
                    if (e instanceof Dn) e = e.name;
                    var t = e.definition();
                    if (t.orig[t.orig.length - 1] !== e) return false;
                    var r = n;
                    t.references.forEach(function(e) {
                        e._eval = function() {
                            return r;
                        };
                        c.push(e);
                    });
                    return true;
                }
            });
            e(gr, Qn);
            e(Vr, function(e, n, t, r) {
                if (!e.option("templates")) return this;
                if (this.tag) {
                    if (!nn(e, this.tag)) return this;
                    f = function(e) {
                        return e;
                    };
                }
                var i = g(this.expressions, e, n, t, r);
                if (!i) return this;
                var a = false;
                var o = f(this.strings[0]);
                for (var s = 0; s < i.length; s++) {
                    o += i[s] + f(this.strings[s + 1]);
                }
                if (!a) return o;
                this._eval = Qn;
                return this;
                function f(e) {
                    e = tn(e);
                    if (typeof e != "string") a = true;
                    return e;
                }
            });
        })(function(e, n) {
            e.DEFMETHOD("_eval", n);
        });
        (function(e) {
            function i(e) {
                return Fe(Pn, e, {
                    operator: "!",
                    expression: e
                });
            }
            function a(e, n, t) {
                var r = i(e);
                if (t) return le(r, Fe(wn, n, {
                    body: n
                })) === r ? r : n;
                return le(r, n);
            }
            e(bn, function() {
                return i(this);
            });
            e(ot, function() {
                throw new Error("Cannot negate a statement");
            });
            e(jn, function(e, n) {
                var t = this.clone(), r = this.operator;
                if (e.option("unsafe_comps")) {
                    switch (r) {
                      case "<=":
                        t.operator = ">";
                        return t;

                      case "<":
                        t.operator = ">=";
                        return t;

                      case ">=":
                        t.operator = "<";
                        return t;

                      case ">":
                        t.operator = "<=";
                        return t;
                    }
                }
                switch (r) {
                  case "==":
                    t.operator = "!=";
                    return t;

                  case "!=":
                    t.operator = "==";
                    return t;

                  case "===":
                    t.operator = "!==";
                    return t;

                  case "!==":
                    t.operator = "===";
                    return t;

                  case "&&":
                    t.operator = "||";
                    t.left = t.left.negate(e, n);
                    t.right = t.right.negate(e);
                    return a(this, t, n);

                  case "||":
                    t.operator = "&&";
                    t.left = t.left.negate(e, n);
                    t.right = t.right.negate(e);
                    return a(this, t, n);
                }
                return i(this);
            });
            e(Lt, function() {
                return i(this);
            });
            e(Nn, function(e, n) {
                var t = this.clone();
                t.consequent = t.consequent.negate(e);
                t.alternative = t.alternative.negate(e);
                return a(this, t, n);
            });
            e(Tt, function() {
                return i(this);
            });
            e(On, function(e) {
                var n = this.expressions.slice();
                n.push(n.pop().negate(e));
                return Pe(this, n);
            });
            e(Pn, function() {
                if (this.operator == "!") return this.expression;
                return i(this);
            });
        })(function(e, t) {
            e.DEFMETHOD("negate", function(e, n) {
                return t.call(this, e, n);
            });
        });
        var c = mn("Boolean decodeURI decodeURIComponent Date encodeURI encodeURIComponent Error escape EvalError isFinite isNaN Number Object parseFloat parseInt RangeError ReferenceError String SyntaxError TypeError unescape URIError");
        var d = mn("Map Set WeakMap WeakSet");
        qn.DEFMETHOD("is_expr_pure", function(e) {
            if (e.option("unsafe")) {
                var n = this.expression;
                if (Ne(n)) {
                    if (c[n.name]) return true;
                    if (this instanceof gr && d[n.name]) return true;
                }
                if (Je(n)) return true;
            }
            return e.option("annotations") && this.pure || !e.pure_funcs(this);
        });
        Vr.DEFMETHOD("is_expr_pure", function(e) {
            var n = this.tag;
            if (!n) return true;
            if (e.option("unsafe")) {
                if (Ne(n) && c[n.name]) return true;
                if (n instanceof zn && Ne(n.expression)) {
                    var t = w[n.expression.name];
                    return t && (t[n.property] || n.expression.name == "Math" && n.property == "random");
                }
            }
            return !e.pure_funcs(this);
        });
        bn.DEFMETHOD("is_call_pure", hn);
        qn.DEFMETHOD("is_call_pure", function(e) {
            if (!e.option("unsafe")) return false;
            var n = this.expression;
            if (!(n instanceof zn)) return false;
            var t = n.expression;
            var r;
            var i = n.property;
            if (t instanceof Hn) {
                r = b.Array;
            } else if (t.is_boolean(e)) {
                r = b.Boolean;
            } else if (t.is_number(e)) {
                r = b.Number;
            } else if (t instanceof Gr) {
                r = b.RegExp;
            } else if (t.is_string(e)) {
                r = b.String;
                if (i == "replace") {
                    var a = this.args[1];
                    if (a && !a.is_string(e)) return false;
                }
            } else if (!n.may_throw_on_access(e)) {
                r = b.Object;
            }
            return r && r[i];
        });
        (function(e) {
            e(bn, hn);
            e(Hn, vn);
            e(In, function() {
                switch (this.operator) {
                  case "=":
                    return this.right.safe_to_spread();

                  case "&&=":
                  case "||=":
                  case "??=":
                    return this.left.safe_to_spread() && this.right.safe_to_spread();
                }
                return true;
            });
            e(jn, function() {
                return !He[this.operator] || this.left.safe_to_spread() && this.right.safe_to_spread();
            });
            e(Un, vn);
            e(En, vn);
            e(Rn, function() {
                return _n(this.properties, function(e) {
                    return !(e instanceof Or || e instanceof Mn);
                });
            });
            e(On, function() {
                return this.tail_node().safe_to_spread();
            });
            e(Ln, function() {
                var e = this.fixed_value();
                return e && e.safe_to_spread();
            });
            e(Fn, vn);
        })(function(e, n) {
            e.DEFMETHOD("safe_to_spread", n);
        });
        (function(e) {
            function t(e, n, t) {
                return !_n(e, t ? function(e) {
                    return e instanceof Mn ? !t(e, n) : !e.has_side_effects(n);
                } : function(e) {
                    return !e.has_side_effects(n);
                });
            }
            function n(e, n) {
                var t = e.expression;
                return !t.is_string(n) || t.has_side_effects(n);
            }
            e(bn, vn);
            e(Hn, function(e) {
                return t(this.elements, e, n);
            });
            e(In, function(e) {
                var n = this.left;
                if (!(n instanceof $n)) return true;
                var t = n.expression;
                return !(t instanceof Rr) || !t.scope.resolve().new || n instanceof Cn && n.property.has_side_effects(e) || this.right.has_side_effects(e);
            });
            e(jn, function(e) {
                return this.left.has_side_effects(e) || this.right.has_side_effects(e) || !Xe(this.operator, this.right, e);
            });
            e(pt, function(e) {
                return t(this.body, e);
            });
            e(qn, function(e) {
                if (!this.is_expr_pure(e) && (!this.is_call_pure(e) || this.expression.has_side_effects(e))) {
                    return true;
                }
                return t(this.args, e, n);
            });
            e(or, function(e) {
                return this.expression.has_side_effects(e) || t(this.body, e);
            });
            e(Rt, function(e) {
                var n = this.extends;
                if (n) {
                    if (n instanceof Ln) n = n.fixed_value();
                    if (!Re(n)) return true;
                }
                return t(this.properties, e);
            });
            e(Ut, function(e) {
                return this.key instanceof bn && this.key.has_side_effects(e) || this.static && this.value && this.value.has_side_effects(e);
            });
            e(Nn, function(e) {
                return this.condition.has_side_effects(e) || this.consequent.has_side_effects(e) || this.alternative.has_side_effects(e);
            });
            e(Un, hn);
            e(cr, function(e) {
                return t(this.definitions, e);
            });
            e(kr, function(e) {
                return t(this.elements, e);
            });
            e(Er, function(e) {
                return this.key instanceof bn && this.key.has_side_effects(e) || this.value.has_side_effects(e);
            });
            e(Sr, function(e) {
                return t(this.properties, e);
            });
            e(zn, function(e) {
                return this.expression.may_throw_on_access(e) || this.expression.has_side_effects(e);
            });
            e(yn, hn);
            e(Tn, function(e) {
                return this.condition.has_side_effects(e) || this.body && this.body.has_side_effects(e) || this.alternative && this.alternative.has_side_effects(e);
            });
            e(dt, function(e) {
                return this.body.has_side_effects(e);
            });
            e(En, hn);
            e(Rn, function(e) {
                return t(this.properties, e, function(e, n) {
                    var t = e.expression;
                    return !t.safe_to_spread() || t.has_side_effects(n);
                });
            });
            e(Rr, hn);
            e(Tr, function(e) {
                return this.key instanceof bn && this.key.has_side_effects(e) || this.value.has_side_effects(e);
            });
            e(On, function(e) {
                return t(this.expressions, e);
            });
            e(wn, function(e) {
                return this.body.has_side_effects(e);
            });
            e(Cn, function(e) {
                return this.expression.may_throw_on_access(e) || this.expression.has_side_effects(e) || this.property.has_side_effects(e);
            });
            e(rr, function(e) {
                return this.expression.has_side_effects(e) || t(this.body, e);
            });
            e(zr, hn);
            e(Ln, function(e) {
                return !this.is_declared(e) || !Ce(this, e);
            });
            e(Vr, function(e) {
                return !this.is_expr_pure(e) || t(this.expressions, e);
            });
            e(sr, function(e) {
                return t(this.body, e) || this.bcatch && this.bcatch.has_side_effects(e) || this.bfinally && this.bfinally.has_side_effects(e);
            });
            e(Fn, function(e) {
                return pi[this.operator] || this.expression.has_side_effects(e);
            });
            e(An, function() {
                return this.value;
            });
        })(function(e, n) {
            e.DEFMETHOD("has_side_effects", n);
        });
        (function(e) {
            e(bn, vn);
            e(Un, hn);
            e(yn, hn);
            e(En, hn);
            e(Rr, hn);
            e(zr, hn);
            function t(e, n) {
                for (var t = e.length; --t >= 0; ) if (e[t].may_throw(n)) return true;
                return false;
            }
            function r(e, n) {
                if (e.may_throw(n)) return true;
                if (e instanceof Ln) e = e.fixed_value();
                if (!(e instanceof En)) return true;
                if (t(e.argnames, n)) return true;
                if (t(e.body, n)) return true;
                return At(e) && e.value && e.value.may_throw(n);
            }
            e(Hn, function(e) {
                return t(this.elements, e);
            });
            e(In, function(e) {
                if (this.right.may_throw(e)) return true;
                if (!e.has_directive("use strict") && this.operator == "=" && this.left instanceof Ln) {
                    return false;
                }
                return this.left.may_throw(e);
            });
            e(wr, function(e) {
                return this.expression.may_throw(e);
            });
            e(jn, function(e) {
                return this.left.may_throw(e) || this.right.may_throw(e) || !Xe(this.operator, this.right, e);
            });
            e(pt, function(e) {
                return t(this.body, e);
            });
            e(qn, function(e) {
                if (t(this.args, e)) return true;
                if (this.is_expr_pure(e)) return false;
                this.may_throw = vn;
                var n = r(this.expression, e);
                delete this.may_throw;
                return n;
            });
            e(or, function(e) {
                return this.expression.may_throw(e) || t(this.body, e);
            });
            e(Nn, function(e) {
                return this.condition.may_throw(e) || this.consequent.may_throw(e) || this.alternative.may_throw(e);
            });
            e(Dn, function(e) {
                return this.name.may_throw(e) || this.value && this.value.may_throw(e);
            });
            e(cr, function(e) {
                return t(this.definitions, e);
            });
            e(zn, function(e) {
                return !this.optional && this.expression.may_throw_on_access(e) || this.expression.may_throw(e);
            });
            e(bt, function(e) {
                if (this.init.may_throw(e)) return true;
                var n = this.object;
                if (n.may_throw(e)) return true;
                n = n.tail_node();
                if (!(n instanceof Hn || n.is_string(e))) return true;
                return this.body.may_throw(e);
            });
            e(Tn, function(e) {
                return this.condition.may_throw(e) || this.body && this.body.may_throw(e) || this.alternative && this.alternative.may_throw(e);
            });
            e(dt, function(e) {
                return this.body.may_throw(e);
            });
            e(Rn, function(e) {
                return t(this.properties, e);
            });
            e(Tr, function(e) {
                return this.value.may_throw(e) || this.key instanceof bn && this.key.may_throw(e);
            });
            e(Sn, function(e) {
                return this.value && this.value.may_throw(e);
            });
            e(On, function(e) {
                return t(this.expressions, e);
            });
            e(wn, function(e) {
                return this.body.may_throw(e);
            });
            e(Cn, function(e) {
                return !this.optional && this.expression.may_throw_on_access(e) || this.expression.may_throw(e) || this.property.may_throw(e);
            });
            e(rr, function(e) {
                return this.expression.may_throw(e) || t(this.body, e);
            });
            e(Ln, function(e) {
                return !this.is_declared(e) || !Ce(this, e);
            });
            e(Vr, function(e) {
                if (t(this.expressions, e)) return true;
                if (this.is_expr_pure(e)) return false;
                if (!this.tag) return false;
                this.may_throw = vn;
                var n = r(this.tag, e);
                delete this.may_throw;
                return n;
            });
            e(sr, function(e) {
                return (this.bcatch ? this.bcatch.may_throw(e) : t(this.body, e)) || this.bfinally && this.bfinally.may_throw(e);
            });
            e(Fn, function(e) {
                return this.expression.may_throw(e) && !(this.operator == "typeof" && this.expression instanceof Ln);
            });
            e(An, function(e) {
                return this.name.may_throw(e) || this.value && this.value.may_throw(e);
            });
        })(function(e, n) {
            e.DEFMETHOD("may_throw", n);
        });
        (function(e) {
            function t(e, n) {
                for (var t = e.length; --t >= 0; ) if (!e[t].is_constant_expression(n)) return false;
                return true;
            }
            e(bn, hn);
            e(Hn, function(e) {
                return t(this.elements, e);
            });
            e(jn, function(e) {
                return this.left.is_constant_expression(e) && this.right.is_constant_expression(e) && Xe(this.operator, this.right);
            });
            e(Rt, function(e) {
                var n = this.extends;
                if (n && !Re(n)) return false;
                return t(this.properties, e);
            });
            e(Ut, function(e) {
                return typeof this.key == "string" && (!this.value || this.value.is_constant_expression(e));
            });
            e(Un, vn);
            e(En, function(i) {
                var a = this;
                var o = true;
                var s = [];
                a.walk(new Gn(function(e, n) {
                    if (!o) return true;
                    if (e instanceof ct) {
                        if (e === a) return;
                        s.push(e);
                        n();
                        s.pop();
                        return true;
                    }
                    if (e instanceof Ln) {
                        if (a.inlined || e.redef || e.in_arg) {
                            o = false;
                            return true;
                        }
                        if (a.variables.has(e.name)) return true;
                        var t = e.definition();
                        if (Jn(t.scope, s)) return true;
                        if (i && !t.redefined()) {
                            var r = i.find_variable(e.name);
                            if (r ? r === t : t.undeclared) {
                                o = "f";
                                return true;
                            }
                        }
                        o = false;
                        return true;
                    }
                    if (e instanceof Rr) {
                        if (At(a) && _n(s, function(e) {
                            return !(e instanceof kn) || At(e);
                        })) o = false;
                        return true;
                    }
                }));
                return o;
            });
            e(Rn, function(e) {
                return t(this.properties, e);
            });
            e(Tr, function(e) {
                return typeof this.key == "string" && this.value.is_constant_expression(e);
            });
            e(Fn, function(e) {
                return this.expression.is_constant_expression(e);
            });
        })(function(e, n) {
            e.DEFMETHOD("is_constant_expression", n);
        });
        function U(e) {
            return e && e.aborts();
        }
        (function(e) {
            e(ot, Zn);
            e(Kt, Qn);
            function n() {
                var e = this.body.length;
                return e > 0 && U(this.body[e - 1]);
            }
            e(xn, n);
            e(ir, n);
            e(Tn, function() {
                return this.alternative && U(this.body) && U(this.alternative) && this;
            });
        })(function(e, n) {
            e.DEFMETHOD("aborts", n);
        });
        var h = mn([ "use asm", "use strict" ]);
        e(ft, function(e, n) {
            if (n.option("directives") && (!h[e.value] || n.has_directive(e.value) !== e)) {
                return Fe(yn, e);
            }
            return e;
        });
        e(st, function(e, n) {
            if (n.option("drop_debugger")) return Fe(yn, e);
            return e;
        });
        e(dt, function(e, n) {
            if (e.body instanceof Tn || e.body instanceof nr) {
                var t = l([ e.body ], n);
                switch (t.length) {
                  case 0:
                    e.body = Fe(yn, e);
                    break;

                  case 1:
                    e.body = t[0];
                    break;

                  default:
                    e.body = Fe(xn, e, {
                        body: t
                    });
                    break;
                }
            }
            return n.option("unused") && e.label.references.length == 0 ? e.body : e;
        });
        e(er, function(e, n) {
            if (!n.option("dead_code")) return e;
            var t = e.label;
            if (t) {
                var r = n.loopcontrol_target(e);
                e.label = null;
                if (n.loopcontrol_target(e) === r) {
                    rt(t.thedef.references, e);
                } else {
                    e.label = t;
                }
            }
            return e;
        });
        e(pt, function(e, n) {
            e.body = l(e.body, n);
            return e;
        });
        function te(e, n, t) {
            switch (e.body.length) {
              case 0:
                return t ? et.skip : Fe(yn, e);

              case 1:
                var r = e.body[0];
                if (!S(r)) return e;
                if (n instanceof ht && r instanceof jt) return e;
                return r;
            }
            return e;
        }
        e(xn, function(e, n) {
            e.body = l(e.body, n);
            return te(e, n.parent());
        });
        function v(e, n) {
            if (!n.option("rests")) return;
            if (e.uses_arguments) return;
            if (!(e.rest instanceof kr)) return;
            if (!n.drop_fargs(e, n.parent())) return;
            e.argnames = e.argnames.concat(e.rest.elements);
            e.rest = e.rest.rest;
        }
        e(En, function(e, n) {
            v(e, n);
            e.body = l(e.body, n);
            return e;
        });
        function m(e, n) {
            if (!n.option("arrows")) return e;
            v(e, n);
            if (e.value) e.body = [ e.first_statement() ];
            var t = l(e.body, n);
            switch (t.length) {
              case 1:
                var r = t[0];
                if (r instanceof Sn) {
                    e.body.length = 0;
                    e.value = r.value;
                    break;
                }

              default:
                e.body = t;
                e.value = null;
                break;
            }
            return e;
        }
        e($t, m);
        e(zt, m);
        e(Ft, function(n, e) {
            v(n, e);
            n.body = l(n.body, e);
            var t = e.parent();
            if (e.option("inline")) for (var r = 0; r < n.body.length; r++) {
                var i = n.body[r];
                if (i instanceof ft) continue;
                if (i instanceof Sn) {
                    if (r != n.body.length - 1) break;
                    var a = i.value;
                    if (!a || a.TYPE != "Call") break;
                    if (a.is_expr_pure(e)) break;
                    var o = a.expression, s;
                    if (!(o instanceof Ln)) {
                        s = o;
                    } else if (n.name && n.name.definition() === o.definition()) {
                        break;
                    } else {
                        s = o.fixed_value();
                    }
                    if (!(s instanceof Ht || s instanceof Ft)) break;
                    if (s.rest) break;
                    if (s.uses_arguments) break;
                    if (s === o) {
                        if (s.parent_scope !== n) break;
                        if (!_n(s.enclosed, function(e) {
                            return e.scope !== n;
                        })) break;
                    }
                    if ((s !== o || s.name) && (t instanceof Jt || t instanceof Dr) && t.value === e.self()) break;
                    if (s.contains_this()) break;
                    var f = s.argnames.length;
                    if (f > 0 && e.option("inline") < 2) break;
                    if (f > n.argnames.length) break;
                    if (!_n(n.argnames, function(e) {
                        return e instanceof Bn;
                    })) break;
                    if (!_n(a.args, function(e) {
                        return !(e instanceof Mn);
                    })) break;
                    for (var u = 0; u < f; u++) {
                        var c = a.args[u];
                        if (!(c instanceof Ln)) break;
                        if (c.definition() !== n.argnames[u].definition()) break;
                    }
                    if (u < f) break;
                    for (;u < a.args.length; u++) {
                        if (a.args[u].has_side_effects(e)) break;
                    }
                    if (u < a.args.length) break;
                    if (f < n.argnames.length && !e.drop_fargs(n, t)) {
                        if (!e.drop_fargs(s, a)) break;
                        do {
                            s.argnames.push(s.make_var(Bn, s, "argument_" + f));
                        } while (++f < n.argnames.length);
                    }
                    return o;
                }
                break;
            }
            return n;
        });
        var I = mn("arguments await yield");
        kn.DEFMETHOD("merge_variables", function(d) {
            if (!d.option("merge_vars")) return;
            var h = [], v, m, _ = {}, g = this;
            var s = [], f = [], u = 0;
            var b = new gn();
            var y = Object.create(null);
            var c = Object.create(null);
            var w = new Gn(function(t, e) {
                if (t instanceof In) {
                    var n = t.left;
                    var r = t.right;
                    if (n instanceof Yn) {
                        r.walk(w);
                        E(Ln, S, n);
                        return true;
                    }
                    if (He[t.operator.slice(0, -1)]) {
                        n.walk(w);
                        x();
                        r.walk(w);
                        if (n instanceof Ln) S(n);
                        k();
                        return true;
                    }
                    if (n instanceof Ln) {
                        if (t.operator != "=") S(n, true);
                        r.walk(w);
                        S(n);
                        return true;
                    }
                    return;
                }
                if (t instanceof jn) {
                    if (!He[t.operator]) return;
                    p(t);
                    return true;
                }
                if (t instanceof nr) {
                    var i = w.loopcontrol_target(t);
                    if (!(i instanceof ht)) T(i);
                    return true;
                }
                if (t instanceof qn) {
                    var a = t.expression;
                    if (a instanceof Tt) {
                        t.args.forEach(function(e) {
                            e.walk(w);
                        });
                        a.walk(w);
                    } else {
                        e();
                        l(a);
                    }
                    return true;
                }
                if (t instanceof Rt) {
                    if (t.name) t.name.walk(w);
                    if (t.extends) t.extends.walk(w);
                    t.properties.filter(function(e) {
                        if (e.key instanceof bn) e.key.walk(w);
                        return e.value;
                    }).forEach(function(e) {
                        if (e.static) {
                            e.value.walk(w);
                        } else {
                            x();
                            _.block = t;
                            e.value.walk(w);
                            k();
                        }
                    });
                    return true;
                }
                if (t instanceof Nn) {
                    p(t.condition, t.consequent, t.alternative);
                    return true;
                }
                if (t instanceof tr) {
                    var i = w.loopcontrol_target(t);
                    if (i instanceof mt) T(i);
                    return true;
                }
                if (t instanceof mt) {
                    x();
                    _.block = t;
                    _.loop = true;
                    var o = _;
                    t.body.walk(w);
                    if (_.inserted === t) _ = o;
                    t.condition.walk(w);
                    k();
                    return true;
                }
                if (t instanceof gt) {
                    if (t.init) t.init.walk(w);
                    x();
                    _.block = t;
                    _.loop = true;
                    if (t.condition) t.condition.walk(w);
                    t.body.walk(w);
                    if (t.step) t.step.walk(w);
                    k();
                    return true;
                }
                if (t instanceof bt) {
                    t.object.walk(w);
                    x();
                    _.block = t;
                    _.loop = true;
                    t.init.walk(w);
                    t.body.walk(w);
                    k();
                    return true;
                }
                if (t instanceof Tn) {
                    p(t.condition, t.body, t.alternative);
                    return true;
                }
                if (t instanceof dt) {
                    x();
                    _.block = t;
                    var o = _;
                    t.body.walk(w);
                    if (_.inserted === t) _ = o;
                    k();
                    return true;
                }
                if (t instanceof kn) {
                    x();
                    _.block = t;
                    if (t === g) m = _;
                    if (t instanceof En) {
                        if (t.name) y[t.name.definition().id] = false;
                        var s = t.uses_arguments && !w.has_directive("use strict") ? function(e) {
                            y[e.definition().id] = false;
                        } : function(e) {
                            S(e);
                        };
                        h.push(t);
                        t.argnames.forEach(function(e) {
                            E(Bn, s, e);
                        });
                        if (t.rest) E(Bn, s, t.rest);
                        h.pop();
                    }
                    Ot(t, w);
                    k();
                    return true;
                }
                if (t instanceof Cn) {
                    var a = t.expression;
                    if (t.optional) {
                        a.walk(w);
                        x();
                        t.property.walk(w);
                        k();
                    } else {
                        e();
                    }
                    l(a);
                    return true;
                }
                if (t instanceof rr) {
                    t.expression.walk(w);
                    var o = _;
                    t.body.forEach(function(e) {
                        if (e instanceof ar) return;
                        e.expression.walk(w);
                        if (o === _) x();
                    });
                    _ = o;
                    t.body.forEach(function(e) {
                        x();
                        _.block = t;
                        var n = _;
                        lt(e, w);
                        if (_.inserted === t) _ = n;
                        k();
                    });
                    return true;
                }
                if (t instanceof Cr || t instanceof Fr) {
                    y[t.definition().id] = false;
                    return true;
                }
                if (t instanceof Ln) {
                    S(t, true);
                    return true;
                }
                if (t instanceof sr) {
                    var f = v;
                    v = t;
                    lt(t, w);
                    if (t.bcatch) {
                        if (t.bcatch.argname) t.bcatch.argname.mark_symbol(function(e) {
                            if (e instanceof Hr) {
                                var n = e.definition();
                                y[n.id] = false;
                                if (n = n.redefined()) y[n.id] = false;
                            }
                        }, w);
                        if (t.bfinally || (v = f)) {
                            lt(t.bcatch, w);
                        } else {
                            x();
                            lt(t.bcatch, w);
                            k();
                        }
                    }
                    v = f;
                    if (t.bfinally) t.bfinally.walk(w);
                    return true;
                }
                if (t instanceof Fn) {
                    if (!fi[t.operator]) return;
                    var u = t.expression;
                    if (!(u instanceof Ln)) return;
                    S(u, true);
                    return true;
                }
                if (t instanceof An) {
                    var c = t.value;
                    if (c) {
                        c.walk(w);
                    } else {
                        c = _.block instanceof bt && _.block.init === w.parent();
                    }
                    E(zr, c ? function(e) {
                        if (e instanceof Pr) {
                            S(e);
                        } else {
                            e.walk(w);
                        }
                    } : function(e) {
                        if (e instanceof Pr) {
                            var n = e.definition().id;
                            var t = y[n];
                            if (t) {
                                t.push(e);
                            } else if (!(n in y)) {
                                b.add(n, e);
                            }
                        } else {
                            e.walk(w);
                        }
                    }, t.name);
                    return true;
                }
                if (t instanceof _t) {
                    x();
                    _.block = t;
                    _.loop = true;
                    e();
                    k();
                    return true;
                }
                function l(e) {
                    if (!d.option("ie")) return;
                    var n = br(e);
                    if (n instanceof Ln) n.walk(w);
                }
                function p(e, n, t) {
                    var r = _;
                    var i = [ r, r ];
                    if (e instanceof jn) switch (e.operator) {
                      case "&&":
                        i[0] = p(e.left, e.right)[0];
                        break;

                      case "||":
                      case "??":
                        i[1] = p(e.left, null, e.right)[1];
                        break;

                      default:
                        e.walk(w);
                        break;
                    } else if (e instanceof Nn) {
                        p(e.condition, e.consequent, e.alternative);
                    } else {
                        e.walk(w);
                    }
                    _ = i[0];
                    if (n) {
                        x();
                        n.walk(w);
                    }
                    i[0] = _;
                    _ = i[1];
                    if (t) {
                        x();
                        t.walk(w);
                    }
                    i[1] = _;
                    _ = r;
                    return i;
                }
            });
            w.directives = Object.create(d.directives);
            g.walk(w);
            var e = false;
            var n = Object.create(null);
            while (s.length && f.length) {
                var t = f.shift();
                if (!t) continue;
                var r = t.definition;
                var i = y[r.id];
                if (!i) continue;
                i = {
                    end: i.end
                };
                while (r.id in n) r = n[r.id];
                i.start = y[r.id].start;
                var a = [];
                do {
                    var o = s.shift();
                    if (t.index > o.index) continue;
                    var l = o.definition;
                    if (!(l.id in c)) continue;
                    var p = y[l.id];
                    if (!p) continue;
                    if (p.start.block !== i.start.block || !D(p, i) || (p.start.loop || !en(r)) && !D(i, p) || d.option("webkit") && li(r) !== li(l) || l.const_redefs || !_n(p.scopes, function(e) {
                        return e.find_variable(r.name) === r;
                    })) {
                        a.push(o);
                        continue;
                    }
                    p.forEach(function(e) {
                        e.thedef = r;
                        e.name = r.name;
                        if (e instanceof Ln) {
                            r.references.push(e);
                            l.replaced++;
                        } else {
                            r.orig.push(e);
                            l.eliminated++;
                        }
                    });
                    if (!l.fixed) r.fixed = false;
                    n[l.id] = r;
                    e = true;
                    break;
                } while (s.length);
                if (a.length) s = a.concat(s);
            }
            return e;
            function x() {
                _ = Object.create(_);
            }
            function k() {
                _ = Object.getPrototypeOf(_);
            }
            function E(n, t, e) {
                var r = new Gn(function(e) {
                    if (e instanceof Yn) return;
                    if (e instanceof Dn) {
                        x();
                        e.value.walk(w);
                        k();
                        e.name.walk(r);
                    } else if (e instanceof Er) {
                        if (!(e.key instanceof bn)) {
                            e.value.walk(r);
                        } else if (e.value instanceof $n) {
                            x();
                            _.block = e;
                            e.key.walk(w);
                            e.value.walk(r);
                            k();
                        } else {
                            e.key.walk(w);
                            e.value.walk(r);
                        }
                    } else if (e instanceof n) {
                        t(e);
                    } else {
                        e.walk(w);
                    }
                    return true;
                });
                e.walk(r);
            }
            function S(n, e) {
                var t = n.definition(), r;
                if (e && !_n(h, function(e) {
                    r = e.variables.get(n.name);
                    if (!r) return true;
                    if (!li(r)) return true;
                    return r !== t && !t.undeclared && e.parent_scope.find_variable(n.name) !== t;
                })) return y[t.id] = y[r.id] = false;
                var i = _;
                if (v) {
                    x();
                    i = _;
                    k();
                }
                if (t.id in y) {
                    var a = y[t.id];
                    if (!a) return;
                    if (a.start.block !== i.block) return y[t.id] = false;
                    o(n);
                    a.end = i;
                    if (t.id in c) {
                        f[c[t.id]] = null;
                    } else if (!e) {
                        return;
                    }
                } else if ((r = g.variables.get(t.name)) !== t) {
                    if (r && m === i) y[r.id] = false;
                    return y[t.id] = false;
                } else if (d.exposed(t) || I[n.name]) {
                    return y[t.id] = false;
                } else {
                    var a = b.get(t.id) || [];
                    a.scopes = [];
                    o(n);
                    y[t.id] = a;
                    if (!e) {
                        a.start = i;
                        return s.push({
                            index: u++,
                            definition: t
                        });
                    }
                    if (i.block !== g) return y[t.id] = false;
                    a.start = m;
                }
                c[t.id] = f.length;
                f.push({
                    index: u++,
                    definition: t
                });
                function o(e) {
                    a.push(e);
                    nt(a.scopes, e.scope);
                    var n = Me(w);
                    if (n !== e.scope) nt(a.scopes, n);
                }
            }
            function T(e) {
                var n = [];
                while (true) {
                    if (it(_, "block")) {
                        var t = _.block;
                        if (t instanceof dt) t = t.body;
                        if (t === e) break;
                    }
                    n.push(_);
                    k();
                }
                _.inserted = _.block;
                x();
                while (n.length) {
                    var r = n.pop();
                    x();
                    if (it(r, "block")) _.block = r.block;
                    if (it(r, "loop")) _.loop = r.loop;
                }
            }
            function A(e, n) {
                return e === n || e.isPrototypeOf(n);
            }
            function D(e, n) {
                return A(e.start, e.end) || A(e.start, n.start);
            }
        });
        function be(e, n) {
            for (var t = n.length; --t >= 0; ) {
                if (!n[t]) n[t] = Fe(Zr, e);
            }
        }
        function re(e, n) {
            var t = Fe(Lt, e);
            if (t.name) t.name = n ? null : Fe(Ir, t.name);
            return t;
        }
        function ye(e, n) {
            var t;
            switch (e.CTOR) {
              case Nt:
                t = Ct;
                break;

              case It:
                t = Mt;
                break;

              case Ht:
                t = Ft;
                break;

              case Yt:
                t = Pt;
                break;
            }
            var r = Fe(t, e);
            r.name = n ? null : Fe(Nr, e.name);
            return r;
        }
        kn.DEFMETHOD("drop_unused", function(z) {
            if (!z.option("unused")) return;
            var C = this;
            var M = !(C instanceof kt) || z.toplevel.funcs;
            var F = !(C instanceof kt) || z.toplevel.vars;
            var P = /keep_assign/.test(z.option("unused")) ? hn : function(e, n) {
                var t, i = false;
                if (e instanceof In) {
                    if (e.write_only || e.operator == "=") t = a(e.left, n);
                } else if (e instanceof Fn) {
                    if (e.write_only) t = a(e.expression, n);
                }
                if (!(t instanceof Ln)) return;
                var r = t.definition();
                if (o[r.id]) return;
                if (z.exposed(r)) return;
                if (!Ce(t, z, i)) return;
                return t;
                function a(e, n) {
                    if (e instanceof $n) {
                        var t = e.expression;
                        if (!t.may_throw_on_access(z, true)) {
                            i = true;
                            if (n && e instanceof Cn) n.unshift(e.property);
                            return a(t, n);
                        }
                    } else if (e instanceof In && e.operator == "=") {
                        e.write_only = "p";
                        var r = a(e.right);
                        if (!n) return r;
                        n.assign = e;
                        return r instanceof Ln ? r : e.left;
                    }
                    return e;
                }
            };
            var j = Object.create(null);
            var o = Object.create(null);
            var v = function(e) {
                v = a(C, 0, Kn);
                return v(e);
                function a(e, n, r) {
                    var i = z.parent(n);
                    if (!i) return r;
                    var t = i instanceof En && Jn(e, i.argnames);
                    return a(i, n + 1, t ? function(e) {
                        var n = r(e);
                        if (n) return n;
                        n = i.variables.get(e);
                        if (n) {
                            var t = n.orig[0];
                            if (t instanceof Bn || t instanceof Nr) return n;
                        }
                    } : i.variables ? function(e) {
                        return r(e) || i.variables.get(e);
                    } : r);
                }
            };
            var N = Object.create(null);
            var m = [];
            var I = Object.create(null);
            var _ = Object.create(null);
            var g = Object.create(null);
            var b = Object.create(null);
            var H = Object.create(null);
            if (C instanceof kt && z.top_retain) {
                C.variables.each(function(e) {
                    if (z.top_retain(e) && !(e.id in I)) {
                        bn.info("Retaining variable {name}", e);
                        I[e.id] = true;
                        m.push(e);
                    }
                });
            }
            var y = new gn();
            var w = new gn();
            var Y = this;
            var x = new Gn(function(s, e) {
                if (s instanceof En && s.uses_arguments && !x.has_directive("use strict")) {
                    s.each_argname(function(e) {
                        var n = e.definition();
                        if (!(n.id in I)) {
                            I[n.id] = true;
                            m.push(n);
                        }
                    });
                }
                if (s === C) return;
                if (Y === C) {
                    if (s instanceof Bt) {
                        var n = s.name.definition();
                        var t = M && !n.exported;
                        if (!t && !(n.id in I)) {
                            I[n.id] = true;
                            m.push(n);
                        }
                        var r = x.parent() instanceof vr;
                        if (r) {
                            o[n.id] = true;
                        } else if (t && !(n.id in _)) {
                            _[n.id] = 1;
                        }
                        if (s.extends) s.extends.walk(x);
                        var i = [];
                        s.properties.forEach(function(e) {
                            if (e.key instanceof bn) e.key.walk(x);
                            var n = e.value;
                            if (!n) return;
                            if (ne(e)) {
                                if (!r && n.contains_this()) r = true;
                                a(n);
                            } else {
                                i.push(n);
                            }
                        });
                        i.forEach(t && r ? a : function(e) {
                            w.add(n.id, e);
                        });
                        return true;
                    }
                    if (s instanceof jt) {
                        var n = s.name.definition();
                        var t = M && !n.exported;
                        if (!t && !(n.id in I)) {
                            I[n.id] = true;
                            m.push(n);
                        }
                        w.add(n.id, s);
                        if (x.parent() instanceof vr) {
                            o[n.id] = true;
                            return f(s, e, true);
                        }
                        if (t && !(n.id in _)) _[n.id] = 1;
                        return true;
                    }
                    if (s instanceof cr) {
                        s.definitions.forEach(function(r) {
                            var i = r.value;
                            var a = i && (r.name instanceof Yn || i.has_side_effects(z));
                            var o = a && i.tail_node().operator == "=";
                            r.name.mark_symbol(function(e) {
                                if (!(e instanceof zr)) return;
                                var n = e.definition();
                                H[n.id] = (H[n.id] || 0) + 1;
                                if (s instanceof dr && n.orig[0] instanceof Hr) {
                                    var t = n.redefined();
                                    if (t) H[t.id] = (H[t.id] || 0) + 1;
                                }
                                if (!(n.id in I) && (!F || n.exported || (s instanceof lr ? n.redefined() : n.const_redefs) || !(s instanceof dr || Ye(n)))) {
                                    I[n.id] = true;
                                    m.push(n);
                                }
                                if (i) {
                                    if (!a) {
                                        w.add(n.id, i);
                                    } else if (o) {
                                        S(n, e, b[n.id]);
                                    }
                                    y.add(n.id, r);
                                }
                                T(n);
                                return true;
                            }, x);
                            if (a) i.walk(x);
                        });
                        return true;
                    }
                    if (s instanceof Bn) {
                        var n = s.definition();
                        H[n.id] = (H[n.id] || 0) + 1;
                        y.add(n.id, s);
                        return true;
                    }
                    if (s instanceof Mr) {
                        var n = s.definition();
                        if (!(n.id in I) && (!F || !Ye(n))) {
                            I[n.id] = true;
                            m.push(n);
                        }
                        return true;
                    }
                }
                return f(s, e, true);
                function a(e) {
                    var n = Y;
                    Y = s;
                    e.walk(x);
                    Y = n;
                }
            });
            x.directives = Object.create(z.directives);
            C.walk(x);
            var R = z.option("keep_fnames") ? hn : z.option("ie") ? function(e) {
                return !z.exposed(e) && e.references.length == e.replaced;
            } : function(e) {
                if (!(e.id in I)) return true;
                if (e.orig.length - e.eliminated < 2) return false;
                if (e.orig[1] instanceof Bn) return true;
                return _n(e.references, function(e) {
                    return !e.in_arg;
                });
            };
            if (z.option("ie")) w.each(function(e, n) {
                if (n in I) return;
                e.forEach(function(e) {
                    e.walk(new Gn(function(e) {
                        if (e instanceof Ft && e.name && !R(e.name.definition())) {
                            e.walk(x);
                            return true;
                        }
                        if (e instanceof kn) return true;
                    }));
                });
            });
            x = new Gn(f);
            for (var e = 0; e < m.length; e++) {
                var n = w.get(m[e].id);
                if (n) n.forEach(function(e) {
                    e.walk(x);
                });
            }
            Object.keys(j).forEach(function(e) {
                var t = j[e];
                if (!t) {
                    delete j[e];
                    return;
                }
                t = t.reduce(function(n, e) {
                    e.forEach(function(e) {
                        nt(n, e);
                    });
                    return n;
                }, []);
                var n = (y.get(e) || []).filter(function(n) {
                    return Xn(n instanceof Fn ? function(e) {
                        return e === n;
                    } : function(e) {
                        if (e === n) return true;
                        if (e instanceof Fn) return false;
                        return r(e) === r(n);
                    }, t);
                });
                if (t.length == n.length) {
                    j[e] = n;
                } else {
                    delete j[e];
                }
            });
            var B = [];
            var L = [];
            var U = new ii(function(r) {
                if (r instanceof Dn) return D(U, r);
                if (r instanceof Yn && r.rest) r.rest = r.rest.transform(U);
                if (r instanceof kr) {
                    var e = !r.rest;
                    for (var n = r.elements.length; --n >= 0; ) {
                        var t = r.elements[n].transform(U);
                        if (t) {
                            r.elements[n] = t;
                            e = false;
                        } else if (e) {
                            r.elements.pop();
                        } else {
                            r.elements[n] = Fe(Zr, r.elements[n]);
                        }
                    }
                    return r;
                }
                if (r instanceof Sr) {
                    var i = [];
                    r.properties.forEach(function(e) {
                        var n = false;
                        if (e.key instanceof bn) {
                            e.key = e.key.transform(V);
                            n = e.key.has_side_effects(z);
                        }
                        if ((n || r.rest) && a(e.value)) {
                            e.value = e.value.transform(V);
                            i.push(e);
                        } else {
                            var t = e.value.transform(U);
                            if (!t && r.rest) {
                                if (e.value instanceof kr) {
                                    t = Fe(kr, e.value, {
                                        elements: []
                                    });
                                } else {
                                    t = Fe(Sr, e.value, {
                                        properties: []
                                    });
                                }
                            }
                            if (t) {
                                e.value = t;
                                i.push(e);
                            }
                        }
                    });
                    r.properties = i;
                    return r;
                }
                if (r instanceof zr) return X(r);
            });
            var V = new ii(function(_, n, e) {
                var g = V.parent();
                if (F) {
                    var t = [], r = P(_, t);
                    if (r) {
                        var i;
                        if (Z(r, _)) {
                            if (_ instanceof In) {
                                i = ee(_);
                                if (_.write_only === true) i = i.drop_side_effect_free(z);
                            }
                            if (!i) i = Fe(Wn, _, {
                                value: 0
                            });
                        }
                        if (i) {
                            if (t.assign) {
                                var a = t.assign.drop_side_effect_free(z);
                                if (a) {
                                    a.write_only = true;
                                    t.unshift(a);
                                }
                            }
                            if (!(g instanceof On) || g.tail_node() === _ || i.has_side_effects(z)) {
                                t.push(i);
                            }
                            switch (t.length) {
                              case 0:
                                return et.skip;

                              case 1:
                                return je(g, _, t[0].transform(V));

                              default:
                                return Pe(_, t.map(function(e) {
                                    return e.transform(V);
                                }));
                            }
                        }
                    } else if (_ instanceof yr && _.expression instanceof Ln && J(_.expression.definition(), _) < 0) {
                        return Fe(Pn, _, {
                            operator: "+",
                            expression: _.expression
                        });
                    }
                }
                if (_ instanceof jn && _.operator == "instanceof") {
                    var r = _.right;
                    if (!(r instanceof Ln)) return;
                    if (r.definition().id in I) return;
                    var o = _.left.drop_side_effect_free(z);
                    var i = Fe(ti, _).optimize(z);
                    return o ? Pe(_, [ o, i ]) : i;
                }
                if (_ instanceof qn) {
                    B.push(_);
                    _.args = _.args.map(function(e) {
                        return e.transform(V);
                    });
                    _.expression = _.expression.transform(V);
                    return _;
                }
                if (Y !== C) return;
                if (M && _ !== C && _ instanceof Bt) {
                    var s = _.name.definition();
                    if (!(s.id in I)) {
                        W(_.name, "Dropping unused class {name}");
                        s.eliminated++;
                        n(_, V);
                        var f = re(_, true);
                        if (g instanceof vr) return f;
                        f = f.drop_side_effect_free(z, true);
                        if (f) return Fe(wn, _, {
                            body: f
                        });
                        return e ? et.skip : Fe(yn, _);
                    }
                }
                if (_ instanceof Lt && _.name && R(_.name.definition())) {
                    _.name = null;
                }
                if (_ instanceof En) {
                    if (M && _ !== C && _ instanceof jt) {
                        var s = _.name.definition();
                        if (!(s.id in I)) {
                            W(_.name, "Dropping unused function {name}");
                            s.eliminated++;
                            if (g instanceof vr) {
                                $();
                                return ye(_, true);
                            }
                            return e ? et.skip : Fe(yn, _);
                        }
                    }
                    $();
                    if (_ instanceof Tt && _.name && R(_.name.definition())) {
                        _.name = null;
                    }
                    if (!(_ instanceof St)) {
                        var u, c, l = z.drop_fargs(_, g);
                        if (l && g instanceof qn && g.expression === _) {
                            u = g.args;
                            for (c = 0; c < u.length; c++) {
                                if (u[c] instanceof Mn) break;
                            }
                        }
                        var p = _.argnames;
                        var d = _.rest;
                        var h = false, v = false;
                        if (d) {
                            v = true;
                            if (!u || c < p.length || d instanceof Bn) {
                                d = d.transform(U);
                            } else {
                                var f = K(d, Fe(Hn, g, {
                                    elements: u.slice(p.length)
                                }), X, !_.uses_arguments, d);
                                d = f.name;
                                u.length = p.length;
                                if (f.value.elements.length) [].push.apply(u, f.value.elements);
                            }
                            if (d instanceof Yn && !d.rest) {
                                if (d instanceof kr) {
                                    if (d.elements.length == 0) d = null;
                                } else if (d.properties.length == 0) {
                                    d = null;
                                }
                            }
                            _.rest = d;
                            if (d) {
                                l = false;
                                h = true;
                            }
                        }
                        var m = l ? -1 : _.length();
                        var b = u && !_.uses_arguments && g !== z.parent();
                        for (var y = p.length; --y >= 0; ) {
                            var r = p[y];
                            if (r instanceof Bn) {
                                var s = r.definition();
                                if (s.id in I) {
                                    l = false;
                                    if (J(s, r) < 0) r.unused = null;
                                } else if (l) {
                                    W(r, "Dropping unused function argument {name}");
                                    p.pop();
                                    s.eliminated++;
                                    r.unused = true;
                                } else {
                                    r.unused = true;
                                }
                            } else {
                                v = true;
                                var w;
                                if (!u || c < y) {
                                    w = r.transform(U);
                                } else {
                                    var f = K(r, u[y], X, b, r);
                                    w = f.name;
                                    if (f.value) u[y] = f.value;
                                }
                                if (w) {
                                    l = false;
                                    p[y] = w;
                                    if (!h) h = !(w instanceof Bn);
                                } else if (l) {
                                    G(r, "Dropping unused default argument {name}");
                                    p.pop();
                                } else if (y > m) {
                                    G(r, "Dropping unused default argument assignment {name}");
                                    if (r.name instanceof Bn) {
                                        r.name.unused = true;
                                    } else {
                                        h = true;
                                    }
                                    p[y] = r.name;
                                } else {
                                    G(r, "Dropping unused default argument value {name}");
                                    p[y] = r = r.clone();
                                    r.value = Fe(Wn, r, {
                                        value: 0
                                    });
                                    h = true;
                                }
                            }
                        }
                        if (v && !h && _.uses_arguments && !V.has_directive("use strict")) {
                            _.rest = Fe(kr, _, {
                                elements: []
                            });
                        }
                        L.push(_);
                    }
                    return _;
                }
                if (_ instanceof fr && _.argname instanceof Yn) {
                    _.argname.transform(U);
                }
                if (_ instanceof cr && !(g instanceof bt && g.init === _)) {
                    var x = [], k = [], E = [];
                    var S = [];
                    var T = 0;
                    var A = _ instanceof dr;
                    _.definitions.forEach(function(t) {
                        if (t.value) t.value = t.value.transform(V);
                        var e = t.value;
                        if (t.name instanceof Yn) {
                            var n = K(t.name, e, function(e) {
                                if (!F) return e;
                                if (e.definition().id in I) return e;
                                if (v(e)) return e;
                                if (A && !Ce(e)) return e;
                                return null;
                            }, true);
                            if (n.name) {
                                t = Fe(An, t, {
                                    name: n.name,
                                    value: e = n.value
                                });
                                m();
                            } else if (n.value) {
                                S.push(n.value);
                            }
                            return;
                        }
                        var a = t.name.definition();
                        var r = A ? Ce(t.name) : Ye(a);
                        if (!r || !F || a.id in I) {
                            var i;
                            if (e && ((i = J(a, t)) < 0 || l(e.tail_node()))) {
                                t = t.clone();
                                e = e.drop_side_effect_free(z);
                                if (e) bn.warn("Side effects in definition of variable {name} [{start}]", t.name);
                                if (_ instanceof lr) {
                                    t.value = e || Fe(Wn, t, {
                                        value: 0
                                    });
                                } else {
                                    t.value = null;
                                    if (e) S.push(e);
                                }
                                e = null;
                                if (i >= 0) j[a.id][i] = t;
                            }
                            var o, s;
                            if (!e && !(_ instanceof pr)) {
                                if (g instanceof hr) {
                                    m();
                                } else if (r && H[a.id] > 1) {
                                    bn.info("Dropping declaration of variable {name} [{start}]", t.name);
                                    H[a.id]--;
                                    a.eliminated++;
                                } else {
                                    k.push(t);
                                }
                            } else if (z.option("functions") && !z.option("ie") && r && e && H[a.id] == 1 && a.assignments == 0 && (s = e.tail_node()) instanceof Tt && !ze(a) && !At(s) && p(s, a.references) && d(s) && (o = h(s, t.name.name)) !== false) {
                                bn.warn("Declaring {name} as function [{start}]", t.name);
                                var f;
                                switch (s.CTOR) {
                                  case Ct:
                                    f = Nt;
                                    break;

                                  case Mt:
                                    f = It;
                                    break;

                                  case Ft:
                                    f = Ht;
                                    break;

                                  case Pt:
                                    f = Yt;
                                    break;
                                }
                                var u = Fe(f, s);
                                u.name = Fe(jr, t.name);
                                var c = t.name.scope.resolve().def_function(u.name);
                                if (o) o.forEach(function(e) {
                                    e.name = c.name;
                                    e.thedef = c;
                                    e.reference();
                                });
                                x.push(u);
                                if (e !== s) [].push.apply(S, e.expressions.slice(0, -1));
                            } else {
                                if (r && H[a.id] > 1 && !(g instanceof hr) && a.orig.indexOf(t.name) > a.eliminated) {
                                    H[a.id]--;
                                    T++;
                                }
                                m();
                            }
                        } else if (v(t.name)) {
                            e = e && e.drop_side_effect_free(z);
                            if (e) S.push(e);
                            if (H[a.id] > 1) {
                                bn.warn("Dropping duplicated declaration of variable {name} [{start}]", t.name);
                                H[a.id]--;
                                a.eliminated++;
                            } else {
                                t.value = null;
                                k.push(t);
                            }
                        } else {
                            e = e && e.drop_side_effect_free(z);
                            if (e) {
                                bn.warn("Side effects in initialization of unused variable {name} [{start}]", t.name);
                                S.push(e);
                            } else {
                                W(t.name, "Dropping unused variable {name}");
                            }
                            a.eliminated++;
                        }
                        function l(e) {
                            return e instanceof Ln && e.definition() === a;
                        }
                        function p(n, e) {
                            if (e.length == 0) return n === t.name.fixed_value();
                            return _n(e, function(e) {
                                return n === e.fixed_value();
                            });
                        }
                        function d(e) {
                            if (!A || z.has_directive("use strict") || !(e instanceof Ft)) {
                                return g instanceof kn;
                            }
                            return g instanceof pt || g instanceof gt && g.init === _ || g instanceof Tn;
                        }
                        function h(t, r) {
                            if (!t.name) return null;
                            var e = t.name.definition();
                            if (e.orig.length > 1) return null;
                            if (e.assignments > 0) return false;
                            if (e.name == r) return e;
                            if (z.option("keep_fnames")) return false;
                            var i;
                            switch (r) {
                              case "await":
                                i = Dt;
                                break;

                              case "yield":
                                i = qt;
                                break;
                            }
                            return _n(e.references, function(e) {
                                var n = e.scope;
                                if (n.find_variable(r) !== a) return false;
                                if (i) do {
                                    n = n.resolve();
                                    if (i(n)) return false;
                                } while (n !== t && (n = n.parent_scope));
                                return true;
                            }) && e;
                        }
                        function v(e) {
                            var n = e.definition();
                            return n.orig[0] instanceof Hr && n.scope.resolve() === e.scope.resolve();
                        }
                        function m() {
                            if (S.length > 0) {
                                if (E.length == 0) {
                                    x.push(Fe(wn, _, {
                                        body: Pe(_, S)
                                    }));
                                } else if (e) {
                                    S.push(e);
                                    t.value = Pe(e, S);
                                } else {
                                    t.value = Fe(Pn, t, {
                                        operator: "void",
                                        expression: Pe(t, S)
                                    });
                                }
                                S = [];
                            }
                            E.push(t);
                        }
                    });
                    switch (k.length) {
                      case 0:
                        if (E.length == 0) break;
                        if (E.length == T) {
                            [].unshift.apply(S, E.map(function(e) {
                                bn.info("Dropping duplicated definition of variable {name} [{start}]", e.name);
                                var n = e.name.definition();
                                var t = Fe(Ln, e.name);
                                n.references.push(t);
                                var r = Fe(In, e, {
                                    operator: "=",
                                    left: t,
                                    right: e.value
                                });
                                var i = J(n, e);
                                if (i >= 0) j[n.id][i] = r;
                                n.assignments++;
                                n.eliminated++;
                                return r;
                            }));
                            break;
                        }

                      case 1:
                        if (E.length == 0) {
                            var D = k[0].name.definition().id;
                            if (D in N) {
                                _.definitions = k;
                                N[D].init = _;
                                break;
                            }
                        }

                      default:
                        var q;
                        if (E.length > 0 && (q = E[0].value) instanceof On) {
                            E[0].value = q.tail_node();
                            x.push(Fe(wn, _, {
                                body: Pe(q, q.expressions.slice(0, -1))
                            }));
                        }
                        _.definitions = k.concat(E);
                        x.push(_);
                    }
                    if (S.length > 0) {
                        x.push(Fe(wn, _, {
                            body: Pe(_, S)
                        }));
                    }
                    return Q(x, _, e);
                }
                if (_ instanceof In) {
                    n(_, V);
                    if (!(_.left instanceof Yn)) return _;
                    var f = K(_.left, _.right, function(e) {
                        return e;
                    }, _.write_only === true);
                    if (f.name) return Fe(In, _, {
                        operator: _.operator,
                        left: f.name,
                        right: f.value
                    });
                    if (f.value) return f.value;
                    if (g instanceof On && g.tail_node() !== _) return et.skip;
                    return Fe(Wn, _, {
                        value: 0
                    });
                }
                if (_ instanceof dt && _.body instanceof gt) {
                    n(_, V);
                    if (_.body instanceof xn) {
                        var O = _.body;
                        _.body = O.body.pop();
                        O.body.push(_);
                        return e ? et.splice(O.body) : O;
                    }
                    return _;
                }
                if (_ instanceof kn) {
                    $();
                    return _;
                }
                if (_ instanceof Mr) {
                    if (!z.option("imports") || _.definition().id in I) return _;
                    return e ? et.skip : null;
                }
                function $() {
                    var e = Y;
                    Y = _;
                    n(_, V);
                    Y = e;
                }
            }, function(e, n) {
                if (e instanceof xn) return te(e, V.parent(), n);
                if (e instanceof hr) {
                    var t = e.body;
                    if (!(t instanceof xn)) return;
                    e.body = t.body.pop();
                    t.body.push(e);
                    return n ? et.splice(t.body) : t;
                }
                if (e instanceof gt) return Ge(e, n);
                if (e instanceof yt) {
                    if (!F || !z.option("loops")) return;
                    if (!ue(e.body)) return;
                    var r = A(e);
                    if (!r) return;
                    var i = r.definition();
                    if (i.id in I) return;
                    W(r, "Dropping unused loop variable {name}");
                    if (N[i.id] === e) delete N[i.id];
                    var a = [];
                    var o = e.object.drop_side_effect_free(z);
                    if (o) {
                        bn.warn("Side effects in object of for-in loop [{start}]", o);
                        a.push(Fe(wn, e, {
                            body: o
                        }));
                    }
                    if (e.init instanceof cr && i.orig[0] instanceof Hr) {
                        a.push(e.init);
                    }
                    return Q(a, e, n);
                }
                if (e instanceof _r) {
                    if (e.properties && e.properties.length == 0) e.properties = null;
                    return e;
                }
                if (e instanceof On) {
                    if (e.expressions.length > 1) return;
                    return je(V.parent(), e, e.expressions[0]);
                }
            });
            V.push(z.parent());
            V.directives = Object.create(z.directives);
            C.transform(V);
            if (C instanceof En && C.body.length == 1 && C.body[0] instanceof ft && C.body[0].value == "use strict") {
                C.body.length = 0;
            }
            B.forEach(function(e) {
                ke(e, z, L);
            });
            function W(e, n) {
                bn[e.definition().references.length > 0 ? "info" : "warn"](n + " [{start}]", e);
            }
            function G(e, n) {
                if (e.name instanceof Bn) {
                    W(e.name, n);
                } else {
                    bn.info(n + " [{start}]", e);
                }
            }
            function r(e) {
                return e[e instanceof In ? "right" : "value"];
            }
            function Q(e, n, t) {
                switch (e.length) {
                  case 0:
                    return t ? et.skip : Fe(yn, n);

                  case 1:
                    return e[0];

                  default:
                    return t ? et.splice(e) : Fe(xn, n, {
                        body: e
                    });
                }
            }
            function k(e, n) {
                if (e.scope.resolve() !== C) return false;
                if (!e.fixed || !n.fixed) j[e.id] = false;
                return j[e.id] !== false;
            }
            function E(e, n) {
                if (!j[e.id]) j[e.id] = [];
                if (n.fixed.assigns) nt(j[e.id], n.fixed.assigns);
            }
            function J(e, n) {
                var t = j[e.id];
                return t && t.indexOf(n);
            }
            function T(e) {
                if (_[e.id] > 1 && !(e.id in I)) {
                    I[e.id] = true;
                    m.push(e);
                }
                _[e.id] = 0;
            }
            function S(e, n, t) {
                if (e.id in I) return;
                if (n && t) {
                    I[e.id] = n;
                    m.push(e);
                } else {
                    g[e.id] = n;
                    b[e.id] = t;
                }
            }
            function Z(e, n) {
                var t = e.definition();
                var r = I[t.id];
                if (!r) return true;
                if (n[n instanceof In ? "left" : "expression"] !== e) return false;
                return r === e && t.references.length - t.replaced == 1 || J(t, n) < 0;
            }
            function ee(e) {
                var n = e.right;
                if (!e.write_only) return n;
                if (!(n instanceof jn && He[n.operator])) return n;
                if (!(n.left instanceof Ln)) return n;
                if (!(e.left instanceof Ln)) return n;
                var t = e.left.definition();
                if (n.left.definition() !== t) return n;
                if (n.right.has_side_effects(z)) return n;
                if (k(t, n.left)) E(t, n.left);
                return n.right;
            }
            function A(e) {
                var n = e.init;
                if (n instanceof cr) {
                    n = n.definitions[0].name;
                    return n instanceof zr && n;
                }
                while (n instanceof $n) n = n.expression.tail_node();
                if (n instanceof Ln) return n;
            }
            function f(e, n, t) {
                if (e instanceof In && e.left instanceof Ln) {
                    var r = e.left.definition();
                    if (r.scope.resolve() === C) y.add(r.id, e);
                }
                if (e instanceof Ln && e.in_arg) H[e.definition().id] = 0;
                if (e instanceof Fn && e.expression instanceof Ln) {
                    var r = e.expression.definition();
                    if (r.scope.resolve() === C) y.add(r.id, e);
                }
                var i = [], a = P(e, i);
                if (a) {
                    var o = a.definition();
                    if (o.scope.resolve() !== C && C.variables.get(a.name) !== o) return;
                    if (ze(o) && !_n(C.argnames, function(e) {
                        return !e.match_symbol(function(e) {
                            if (e instanceof Bn) {
                                var n = e.definition();
                                return n.references.length > n.replaced;
                            }
                        }, true);
                    })) return;
                    if (e.write_only === "p" && e.right.may_throw_on_access(z, true)) return;
                    var s = i.assign;
                    if (s) {
                        s.write_only = true;
                        s.walk(x);
                    }
                    i.forEach(function(e) {
                        e.walk(x);
                    });
                    if (e instanceof In) {
                        var f = ee(e), u = false;
                        if (t && e.write_only === true && !f.has_side_effects(z)) {
                            w.add(o.id, f);
                        } else {
                            f.walk(x);
                            u = f.tail_node().operator == "=";
                        }
                        if (e.left === a) {
                            if (!e.write_only || u) {
                                S(o, a, b[o.id]);
                            }
                        } else {
                            var c = a.fixed_value();
                            if (!c || !c.is_constant()) {
                                S(o, g[o.id], true);
                            }
                        }
                    }
                    if (k(o, a) && di(a, e) !== a) E(o, a);
                    T(o);
                    return true;
                }
                if (e instanceof jn) {
                    if (e.operator != "instanceof") return;
                    var a = e.right;
                    if (!(a instanceof Ln)) return;
                    var l = a.definition().id;
                    if (!_[l]) return;
                    e.left.walk(x);
                    _[l]++;
                    return true;
                }
                if (e instanceof yt) {
                    if (e.init instanceof Ln && Y === C) {
                        var l = e.init.definition().id;
                        if (!(l in N)) N[l] = e;
                    }
                    if (!F || !z.option("loops")) return;
                    if (!ue(e.body)) return;
                    if (e.init.has_side_effects(z)) return;
                    var a = A(e);
                    if (!a) return;
                    var r = a.definition();
                    if (r.scope.resolve() !== C) {
                        var p = v(a.name);
                        if (p === r || p && p.redefined() === r) return;
                    }
                    e.object.walk(x);
                    return true;
                }
                if (e instanceof Ln) {
                    var o = e.definition();
                    if (!(o.id in I)) {
                        I[o.id] = true;
                        m.push(o);
                    }
                    if (O(o.scope, e.scope)) {
                        var d = o.redefined();
                        if (d && !(d.id in I)) {
                            I[d.id] = true;
                            m.push(d);
                        }
                    }
                    if (k(o, e)) E(o, e);
                    return true;
                }
                if (e instanceof kn) {
                    var h = Y;
                    Y = e;
                    n();
                    Y = h;
                    return true;
                }
            }
            function a(e) {
                return (e instanceof Dn ? e.name : e) instanceof zr;
            }
            function X(e) {
                if (e.definition().id in I) return e;
                if (e instanceof Bn) e.unused = true;
                return null;
            }
            function D(e, n) {
                n.value = n.value.transform(V);
                var t = n.name.transform(e);
                if (!t) {
                    if (n.name instanceof Yn) return null;
                    var r = n.value.drop_side_effect_free(z);
                    if (!r) return null;
                    W(n.name, "Side effects in default value of unused variable {name}");
                    n = n.clone();
                    n.name.unused = null;
                    n.value = r;
                }
                return n;
            }
            function K(e, _, g, b, y) {
                var w = new ii(function(a) {
                    if (a instanceof Dn) {
                        if (!(z.option("default_values") && _ && _.is_defined(z))) {
                            var e = b;
                            b = false;
                            var n = D(w, a);
                            b = e;
                            if (!n && b && _) _ = _.drop_side_effect_free(z);
                            return n;
                        } else if (a === y) {
                            y = a = a.name;
                        } else {
                            a = a.name;
                        }
                    }
                    if (a instanceof kr) {
                        var e = b;
                        var t = _;
                        if (_ instanceof Ln) {
                            b = false;
                            _ = _.fixed_value();
                        }
                        var r, i;
                        if (_ instanceof Hn) {
                            r = true;
                            i = _.elements;
                        } else {
                            r = _ && _.is_string(z);
                            i = false;
                        }
                        var o = [], s = b && [], f = 0;
                        a.elements.forEach(function(e, n) {
                            _ = i && i[n];
                            if (_ instanceof Zr) {
                                _ = null;
                            } else if (_ instanceof Mn) {
                                if (b) {
                                    s.length = f;
                                    be(t, s);
                                    [].push.apply(s, i.slice(n));
                                    t.elements = s;
                                }
                                _ = i = false;
                            }
                            e = e.transform(w);
                            if (e) o[f] = e;
                            if (b && _) s[f] = _;
                            if (e || _ || !b || !i) f++;
                        });
                        _ = i && Fe(Hn, t, {
                            elements: i.slice(a.elements.length)
                        });
                        if (a.rest) {
                            var u = b;
                            b = false;
                            a.rest = a.rest.transform(z.option("rests") ? w : V);
                            b = u;
                            if (a.rest) o.length = f;
                        }
                        if (b) {
                            if (_ && !a.rest) _ = _.drop_side_effect_free(z);
                            if (_ instanceof Hn) {
                                _ = _.elements;
                            } else if (_ instanceof On) {
                                _ = _.expressions;
                            } else if (_) {
                                _ = [ _ ];
                            }
                            if (_ && _.length) {
                                s.length = f;
                                [].push.apply(s, _);
                            }
                        }
                        _ = t;
                        b = e;
                        if (i && s) {
                            be(_, s);
                            _ = _.clone();
                            _.elements = s;
                        }
                        if (!r) {
                            o.length = a.elements.length;
                        } else if (!a.rest) switch (o.length) {
                          case 0:
                            if (a === y) break;
                            if (b) _ = _.drop_side_effect_free(z);
                            return null;

                          case 1:
                            if (!b) break;
                            if (a === y) break;
                            var c = o[0];
                            if (c.has_side_effects(z)) break;
                            if (_.has_side_effects(z) && c.match_symbol(function(e) {
                                return e instanceof $n;
                            })) break;
                            _ = Fe(Cn, a, {
                                expression: _,
                                property: Fe(Wn, a, {
                                    value: 0
                                })
                            });
                            return c;
                        }
                        be(a, o);
                        a.elements = o;
                        return a;
                    }
                    if (a instanceof Sr) {
                        var e = b;
                        var t = _;
                        if (_ instanceof Ln) {
                            b = false;
                            _ = _.fixed_value();
                        }
                        var l, p, i;
                        if (_ instanceof Rn) {
                            l = [];
                            p = new gn();
                            i = _.properties.map(function(e, n) {
                                e = e.clone();
                                if (e instanceof Mn) {
                                    p = false;
                                } else {
                                    var t = e.key;
                                    if (t instanceof bn) t = t.evaluate(z, true);
                                    if (t instanceof bn) {
                                        p = false;
                                    } else if (p && !(e instanceof qr)) {
                                        p.set(t, e);
                                    }
                                    l[n] = t;
                                }
                                return e;
                            });
                        }
                        if (a.rest) {
                            _ = false;
                            a.rest = a.rest.transform(z.option("rests") ? w : V);
                        }
                        var d = new gn();
                        var h = b && new gn();
                        var v = [];
                        a.properties.map(function(e) {
                            var n = e.key;
                            if (n instanceof bn) {
                                e.key = n = n.transform(V);
                                n = n.evaluate(z, true);
                            }
                            if (n instanceof bn) {
                                h = false;
                            } else {
                                d.set(n, !d.has(n));
                            }
                            return n;
                        }).forEach(function(e, n) {
                            var t = a.properties[n], r;
                            if (e instanceof bn) {
                                b = false;
                                _ = false;
                                r = t.value.transform(w) || k(t.value);
                            } else {
                                b = h && d.get(e);
                                var i = p && p.get(e);
                                if (i) {
                                    _ = i.value;
                                    if (_ instanceof St) _ = false;
                                } else {
                                    _ = false;
                                }
                                r = t.value.transform(w);
                                if (!r) {
                                    if (a.rest || x(t)) r = k(t.value);
                                    if (h && !h.has(e)) {
                                        if (i) {
                                            h.set(e, i);
                                            if (_ === null) {
                                                p.set(e, x(i) && Fe(Ar, i, {
                                                    key: i.key,
                                                    value: Fe(Wn, i, {
                                                        value: 0
                                                    })
                                                }));
                                            }
                                        } else {
                                            h.set(e, true);
                                        }
                                    }
                                } else if (h) {
                                    h.set(e, false);
                                }
                                if (_) i.value = _;
                            }
                            if (r) {
                                t.value = r;
                                v.push(t);
                            }
                        });
                        _ = t;
                        b = e;
                        if (h && l) {
                            _ = _.clone();
                            _.properties = et(i, function(e, n) {
                                if (e instanceof Mn) return e;
                                var t = l[n];
                                if (t instanceof bn) return e;
                                if (h.has(t)) {
                                    var r = h.get(t);
                                    if (!r) return e;
                                    if (r === e) return p.get(t) || et.skip;
                                } else if (a.rest) {
                                    return e;
                                }
                                var i = e.value.drop_side_effect_free(z);
                                if (i) {
                                    e.value = i;
                                    return e;
                                }
                                return x(e) ? Fe(Ar, e, {
                                    key: e.key,
                                    value: Fe(Wn, e, {
                                        value: 0
                                    })
                                }) : et.skip;
                            });
                        }
                        if (_ && !a.rest) switch (v.length) {
                          case 0:
                            if (a === y) break;
                            if (_.may_throw_on_access(z, true)) break;
                            if (b) _ = _.drop_side_effect_free(z);
                            return null;

                          case 1:
                            if (!b) break;
                            if (a === y) break;
                            var m = v[0];
                            if (m.key instanceof bn) break;
                            if (m.value.has_side_effects(z)) break;
                            if (_.has_side_effects(z) && m.value.match_symbol(function(e) {
                                return e instanceof $n;
                            })) break;
                            _ = Fe(Cn, a, {
                                expression: _,
                                property: fe(m.key, m)
                            });
                            return m.value;
                        }
                        a.properties = v;
                        return a;
                    }
                    if (a instanceof Zr) {
                        a = null;
                    } else {
                        a = g(a);
                    }
                    if (!a && b && _) _ = _.drop_side_effect_free(z);
                    return a;
                });
                return {
                    name: e.transform(w),
                    value: _
                };
                function x(e) {
                    return e.key instanceof bn && e.key.has_side_effects(z);
                }
                function n(e) {
                    if (e instanceof In) {
                        e.write_only = false;
                        n(e.right);
                    } else if (e instanceof jn) {
                        if (!He[e.operator]) return;
                        n(e.left);
                        n(e.right);
                    } else if (e instanceof Nn) {
                        n(e.consequent);
                        n(e.alternative);
                    } else if (e instanceof On) {
                        n(e.tail_node());
                    } else if (e instanceof Fn) {
                        e.write_only = false;
                    }
                }
                function k(e) {
                    if (e instanceof Dn) return k(e.name);
                    if (e instanceof Yn) {
                        if (_ === null) {
                            _ = Fe(Wn, e, {
                                value: 0
                            });
                        } else if (_) {
                            if (_.may_throw_on_access(z, true)) {
                                _ = Fe(Hn, e, {
                                    elements: _ instanceof On ? _.expressions : [ _ ]
                                });
                            } else {
                                n(_);
                            }
                        }
                        return Fe(Sr, e, {
                            properties: []
                        });
                    }
                    e.unused = null;
                    return e;
                }
            }
        });
        kn.DEFMETHOD("hoist_declarations", function(o) {
            if (o.has_directive("use asm")) return;
            var s = o.option("hoist_funs");
            var f = o.option("hoist_vars");
            var u = this;
            if (f) {
                var n = 0;
                u.walk(new Gn(function(e) {
                    if (n > 1) return true;
                    if (e instanceof hr) return true;
                    if (e instanceof kn && e !== u) return true;
                    if (e instanceof dr) {
                        n++;
                        return true;
                    }
                }));
                if (n <= 1) f = false;
            }
            if (!s && !f) return;
            var c = new gn();
            var l = [];
            var p = [];
            var d = new gn();
            var h = new ii(function(e, n, t) {
                if (e === u) return;
                if (e instanceof ft) {
                    l.push(e);
                    return t ? et.skip : Fe(yn, e);
                }
                if (e instanceof jt) {
                    if (!s) return e;
                    var r = h.parent();
                    if (r instanceof hr) return e;
                    if (r instanceof vr) return e;
                    if (r !== u && o.has_directive("use strict")) return e;
                    p.push(e);
                    return t ? et.skip : Fe(yn, e);
                }
                if (e instanceof dr) {
                    if (!f) return e;
                    var r = h.parent();
                    if (r instanceof hr) return e;
                    if (!_n(e.definitions, function(e) {
                        var n = e.name;
                        return n instanceof Pr && !c.has(n.name) && u.find_variable(n.name) === n.definition();
                    })) return e;
                    e.definitions.forEach(function(e) {
                        d.set(e.name.name, e);
                    });
                    var i = e.to_assignments();
                    if (r instanceof bt && r.init === e) {
                        if (i) return i;
                        var a = e.definitions[0].name;
                        return Fe(Ln, a);
                    }
                    if (r instanceof gt && r.init === e) return i;
                    if (!i) return t ? et.skip : Fe(yn, e);
                    return Fe(wn, e, {
                        body: i
                    });
                }
                if (e instanceof kn) return e;
                if (e instanceof Cr) {
                    c.set(e.name, true);
                    return e;
                }
            });
            u.transform(h);
            if (d.size() > 0) {
                var t = [];
                if (u instanceof En) u.each_argname(function(e) {
                    if (_n(e.definition().references, function(e) {
                        return !e.in_arg;
                    })) d.del(e.name);
                });
                d.each(function(e, n) {
                    e = e.clone();
                    e.name = e.name.clone();
                    e.value = null;
                    t.push(e);
                    d.set(n, e);
                    e.name.definition().orig.unshift(e.name);
                });
                if (t.length > 0) p.push(Fe(dr, u, {
                    definitions: t
                }));
            }
            u.body = l.concat(p, u.body);
        });
        function y(n, t) {
            n.walk(new Gn(function(e) {
                if (e instanceof Sn) {
                    t(e);
                    return true;
                }
                if (e instanceof kn && e !== n) return true;
            }));
        }
        function _(e) {
            var r = Object.create(null);
            y(e, function(e) {
                var n = e.value;
                if (n) n = n.tail_node();
                if (n instanceof Ln) {
                    var t = n.definition().id;
                    r[t] = (r[t] || 0) + 1;
                }
            });
            return r;
        }
        function g(e, n, t) {
            if (t.exposed(e)) return false;
            switch (e.references.length - e.replaced - (n[e.id] || 0)) {
              case e.drop_return:
                return "d";

              case e.bool_return:
                return true;
            }
        }
        function H(e, r) {
            y(e, function(e) {
                e.in_bool = true;
                var n = e.value;
                if (n) {
                    var t = j(r, n);
                    if (!t) {
                        n = n.drop_side_effect_free(r);
                        e.value = n ? Pe(e.value, [ n, Fe(Wn, e.value, {
                            value: 0
                        }) ]) : null;
                    } else if (!(t instanceof bn)) {
                        n = n.drop_side_effect_free(r);
                        e.value = n ? Pe(e.value, [ n, Fe(Wn, e.value, {
                            value: 1
                        }) ]) : Fe(Wn, e.value, {
                            value: 1
                        });
                    }
                }
            });
        }
        kn.DEFMETHOD("process_returns", Kn);
        Ht.DEFMETHOD("process_returns", function(e) {
            if (!e.option("booleans")) return;
            if (e.parent() instanceof vr) return;
            switch (g(this.name.definition(), _(this), e)) {
              case "d":
                Y(e, this, true);
                break;

              case true:
                H(this, e);
                break;
            }
        });
        Ft.DEFMETHOD("process_returns", function(n) {
            if (!n.option("booleans")) return;
            var t = true;
            var r = _(this);
            if (this.name && !c(this.name.definition())) return;
            var e = n.parent();
            if (e instanceof In) {
                if (e.operator != "=") return;
                var i = e.left;
                if (!(i instanceof Ln)) return;
                if (!c(i.definition())) return;
            } else if (e instanceof qn && e.expression !== this) {
                var a = e.expression;
                if (a instanceof Ln) a = a.fixed_value();
                if (!(a instanceof En)) return;
                if (a.uses_arguments || a.pinned()) return;
                var o = e.args, i;
                for (var s = 0; s < o.length; s++) {
                    var f = o[s];
                    if (f === this) {
                        i = a.argnames[s];
                        if (!i && a.rest) return;
                        break;
                    }
                    if (f instanceof Mn) return;
                }
                if (i instanceof Dn) i = i.name;
                if (i instanceof Bn && !c(i.definition())) return;
            } else if (e.TYPE == "Call") {
                n.pop();
                var u = n.in_boolean_context();
                n.push(this);
                switch (u) {
                  case true:
                    t = false;

                  case "d":
                    break;

                  default:
                    return;
                }
            } else return;
            if (t) {
                Y(n, this, true);
            } else {
                H(this, n);
            }
            function c(e) {
                switch (g(e, r, n)) {
                  case true:
                    t = false;

                  case "d":
                    return true;
                }
            }
        });
        ct.DEFMETHOD("var_names", function() {
            var t = this._var_names;
            if (!t) {
                this._var_names = t = new gn();
                this.enclosed.forEach(function(e) {
                    t.set(e.name, true);
                });
                this.variables.each(function(e, n) {
                    t.set(n, true);
                });
            }
            return t;
        });
        kn.DEFMETHOD("make_var", function(e, n, t) {
            var r = [ this ];
            if (n instanceof zr) n.definition().references.forEach(function(e) {
                var n = e.scope;
                do {
                    if (!nt(r, n)) return;
                    n = n.parent_scope;
                } while (n && n !== this);
            });
            t = t.replace(/^[^a-z_$]|[^a-z0-9_$]/gi, "_");
            var i = t;
            for (var a = 0; !_n(r, function(e) {
                return !e.var_names().has(i);
            }); a++) i = t + "$" + a;
            var o = Fe(e, n, {
                name: i,
                scope: this
            });
            var s = this.def_variable(o);
            r.forEach(function(e) {
                e.enclosed.push(s);
                e.var_names().set(i, true);
            });
            return o;
        });
        kn.DEFMETHOD("hoist_properties", function(a) {
            if (!a.option("hoist_props") || a.has_directive("use asm")) return;
            var u = this;
            if (At(u) && u.value) return;
            var o = u instanceof kt && a.top_retain || hn;
            var c = Object.create(null);
            var l = new ii(function(r, e) {
                if (r instanceof In) {
                    if (r.operator != "=") return;
                    if (!r.write_only) return;
                    if (!p(r.left, r.right, 1)) return;
                    e(r, l);
                    var i = new gn();
                    var a = [];
                    var o = [];
                    r.right.properties.forEach(function(e) {
                        var n = f(Pr, r.left, e.key);
                        o.push(Fe(An, r, {
                            name: n,
                            value: null
                        }));
                        var t = Fe(Ln, r, {
                            name: n.name,
                            scope: u,
                            thedef: n.definition()
                        });
                        t.reference();
                        a.push(Fe(In, r, {
                            operator: "=",
                            left: t,
                            right: e.value
                        }));
                    });
                    i.value = r.right;
                    c[r.left.definition().id] = i;
                    u.body.splice(u.body.indexOf(l.stack[1]) + 1, 0, Fe(dr, r, {
                        definitions: o
                    }));
                    return Pe(r, a);
                }
                if (r instanceof kn) {
                    if (r === u) return;
                    var n = l.parent();
                    if (n.TYPE == "Call" && n.expression === r) return;
                    return r;
                }
                if (r instanceof An) {
                    if (!p(r.name, r.value, 0)) return;
                    e(r, l);
                    var i = new gn();
                    var t = [];
                    var s = r.clone();
                    s.value = r.name instanceof Cr ? Fe(Wn, r, {
                        value: 0
                    }) : null;
                    t.push(s);
                    r.value.properties.forEach(function(e) {
                        t.push(Fe(An, r, {
                            name: f(r.name.CTOR, r.name, e.key),
                            value: e.value
                        }));
                    });
                    i.value = r.value;
                    c[r.name.definition().id] = i;
                    return et.splice(t);
                }
                function f(e, n, t) {
                    var r = u.make_var(e, n, n.name + "_" + t);
                    i.set(t, r.definition());
                    return r;
                }
            });
            u.transform(l);
            u.transform(new ii(function(e, n) {
                if (e instanceof $n) {
                    if (!(e.expression instanceof Ln)) return;
                    var t = c[e.expression.definition().id];
                    if (!t) return;
                    if (e.expression.fixed_value() !== t.value) return;
                    var r = t.get(e.get_property());
                    var i = Fe(Ln, e, {
                        name: r.name,
                        scope: e.expression.scope,
                        thedef: r
                    });
                    i.reference();
                    return i;
                }
                if (e instanceof Ln) {
                    var t = c[e.definition().id];
                    if (!t) return;
                    if (e.fixed_value() !== t.value) return;
                    return Fe(Rn, e, {
                        properties: []
                    });
                }
            }));
            function p(e, n, t) {
                if (!(e instanceof $r)) return;
                var r = e.definition();
                if (r.assignments != t) return;
                if (r.references.length - r.replaced == t) return;
                if (r.single_use) return;
                if (u.find_variable(e.name) !== r) return;
                if (o(r)) return;
                if (e.fixed_value() !== n) return;
                var i = e.fixed || r.fixed;
                if (i.direct_access) return;
                if (i.escaped && i.escaped.depth == 1) return;
                return n instanceof Rn && n.properties.length > 0 && Ce(e, a) && _n(n.properties, function(e) {
                    return un(e) && e.key !== "__proto__";
                });
            }
        });
        function we(e, n) {
            if (!e.name || !n.option("ie")) return true;
            var t = e.name.definition();
            if (n.exposed(t)) return false;
            return _n(t.references, function(e) {
                return !(e instanceof Ln);
            });
        }
        function Y(o, n, e) {
            if (!(n instanceof En)) return;
            var t = At(n);
            var r = Dt(n);
            var s = false;
            var i = false;
            if (t && o.option("arrows")) {
                if (!n.value) {
                    i = true;
                } else if (!r || x(o, n.value)) {
                    var a = n.value.drop_side_effect_free(o);
                    if (a !== n.value) {
                        s = true;
                        n.value = a;
                    }
                }
            } else if (!qt(n)) {
                if (!e && n.name) {
                    var f = n.name.definition();
                    i = f.references.length == f.replaced;
                } else {
                    i = true;
                }
            }
            if (i) {
                n.process_expression(false, function(e) {
                    var n = e.value;
                    if (n) {
                        if (r && !x(o, n)) return e;
                        n = n.drop_side_effect_free(o, true);
                    }
                    s = true;
                    if (!n) return Fe(yn, e);
                    return Fe(wn, e, {
                        body: n
                    });
                });
                y(n, function(e) {
                    var n = e.value;
                    if (n) {
                        if (r && !x(o, n)) return;
                        var t = n.drop_side_effect_free(o);
                        if (t !== n) {
                            s = true;
                            if (t && r && !x(o, t)) {
                                t = t.negate(o);
                            }
                            e.value = t;
                        }
                    }
                });
            }
            if (r && o.option("awaits")) {
                if (i) n.process_expression("awaits", function(e) {
                    var n = e.body;
                    if (n instanceof wr) {
                        if (x(o, n.expression)) {
                            s = true;
                            n = n.expression.drop_side_effect_free(o, true);
                            if (!n) return Fe(yn, e);
                            e.body = n;
                        }
                    } else if (n instanceof On) {
                        var t = n.expressions;
                        for (var r = t.length; --r >= 0; ) {
                            var i = t[r];
                            if (!(i instanceof wr)) break;
                            var a = i.expression;
                            if (!x(o, a)) break;
                            s = true;
                            if (t[r] = a.drop_side_effect_free(o)) break;
                        }
                        switch (r) {
                          case -1:
                            return Fe(yn, e);

                          case 0:
                            e.body = t[0];
                            break;

                          default:
                            t.length = r + 1;
                            break;
                        }
                    }
                    return e;
                });
                var u = !i && n.name || t && n.value && !x(o, n.value);
                var c = new Gn(function(e) {
                    if (u) return true;
                    if (c.parent() === n && e.may_throw(o)) return u = true;
                    if (e instanceof wr) return u = true;
                    if (e instanceof wt) return u = true;
                    if (e instanceof Sn) {
                        if (e.value && !x(o, e.value)) return u = true;
                        return;
                    }
                    if (e instanceof kn && e !== n) return true;
                });
                n.walk(c);
                if (!u) {
                    var l;
                    switch (n.CTOR) {
                      case zt:
                        l = $t;
                        break;

                      case Ct:
                        l = Ft;
                        break;

                      case Mt:
                        l = Pt;
                        break;
                    }
                    return Fe(l, n);
                }
            }
            return s && n.clone();
        }
        (function(e) {
            function d(e, n, t, r) {
                var i = e.length;
                var a = [], o = false;
                for (var s = 0; s < i; s++) {
                    var f = e[s];
                    var u;
                    if (r && f instanceof Mn) {
                        u = r(f, n, t);
                    } else {
                        u = f.drop_side_effect_free(n, t);
                    }
                    if (u !== f) o = true;
                    if (u) {
                        a.push(u);
                        t = false;
                    }
                }
                return a.length ? o ? a : e : null;
            }
            function c(e, n, t) {
                var r = e.expression;
                if (!r.is_string(n)) return e;
                return r.drop_side_effect_free(n, t);
            }
            function l(e) {
                return e instanceof Mn ? Fe(Hn, e, {
                    elements: [ e ]
                }) : e;
            }
            e(bn, Qn);
            e(St, Zn);
            e(Hn, function(e, n) {
                var t = d(this.elements, e, n, c);
                if (!t) return null;
                if (t === this.elements && _n(t, function(e) {
                    return e instanceof Mn;
                })) return this;
                return Pe(this, t.map(l));
            });
            e(In, function(e) {
                var n = this.left;
                if (n instanceof $n) {
                    var t = n.expression;
                    if (t.may_throw_on_access(e, true)) return this;
                    if (e.has_directive("use strict") && t.is_constant()) return this;
                }
                if (n.has_side_effects(e)) return this;
                if (He[this.operator.slice(0, -1)]) return this;
                this.write_only = true;
                if (!br(n).is_constant_expression(e.find_parent(kn))) return this;
                return this.right.drop_side_effect_free(e);
            });
            e(wr, function(e) {
                if (!e.option("awaits")) return this;
                var n = this.expression;
                if (!x(e, n)) return this;
                if (n instanceof Pn && n.operator == "!") n = n.expression;
                var t = n.drop_side_effect_free(e);
                if (t === n) return this;
                if (!t) {
                    t = Fe(Wn, n, {
                        value: 0
                    });
                } else if (!x(e, t)) {
                    t = t.negate(e);
                }
                var r = this.clone();
                r.expression = t;
                return r;
            });
            e(jn, function(e, n) {
                var t = this.left;
                var r = this.right;
                var i = this.operator;
                if (!Xe(i, r, e)) {
                    var a = t.drop_side_effect_free(e, n);
                    if (a === t) return this;
                    var o = this.clone();
                    o.left = a || Fe(Wn, t, {
                        value: 0
                    });
                    return o;
                }
                var s = r.drop_side_effect_free(e, n);
                if (!s) return t.drop_side_effect_free(e, n);
                if (He[i] && s.has_side_effects(e)) {
                    var o = this;
                    if (s !== r) {
                        o = o.clone();
                        o.right = s.drop_side_effect_free(e);
                    }
                    if (i == "??") return o;
                    var f = o.clone();
                    f.operator = i == "&&" ? "||" : "&&";
                    f.left = t.negate(e, n);
                    var u = f.right.tail_node();
                    if (u instanceof jn && f.operator == u.operator) Qe(f);
                    var c = n ? A : le;
                    return i == "&&" ? c(o, f) : c(f, o);
                }
                var a = t.drop_side_effect_free(e, n);
                if (!a) return s;
                s = s.drop_side_effect_free(e);
                if (!s) return a;
                return Pe(this, [ a, s ]);
            });
            function p(e, n) {
                e.new = true;
                var t = _n(e.body, function(e) {
                    return !e.has_side_effects(n);
                }) && _n(e.argnames, function(e) {
                    return !e.match_symbol(hn);
                }) && !(e.rest && e.rest.match_symbol(hn));
                e.new = false;
                return t;
            }
            e(qn, function(e, n) {
                var t = this;
                if (t.is_expr_pure(e)) {
                    if (t.pure) bn.warn("Dropping __PURE__ call [{start}]", t);
                    var r = d(t.args, e, n, c);
                    return r && Pe(t, r.map(l));
                }
                var i = t.expression;
                if (t.is_call_pure(e)) {
                    var a = t.args.slice();
                    a.unshift(i.expression);
                    a = d(a, e, n, c);
                    return a && Pe(t, a.map(l));
                }
                if (e.option("yields") && qt(i)) {
                    var o = t.clone();
                    o.expression = Fe(Ft, i);
                    o.expression.body = [];
                    var s = o.transform(e);
                    if (s !== o) return s.drop_side_effect_free(e, n);
                }
                var f = Y(e, i);
                if (f) {
                    t = t.clone();
                    t.expression = f;
                    if (i._squeezed) t.expression._squeezed = true;
                }
                if (t instanceof gr) {
                    var u = i;
                    if (u instanceof Ln) u = u.fixed_value();
                    if (u instanceof En) {
                        if (p(u, e)) {
                            var a = t.args.slice();
                            a.unshift(i);
                            a = d(a, e, n, c);
                            return a && Pe(t, a.map(l));
                        }
                        if (!u.contains_this()) {
                            t = Fe(qn, t);
                            t.expression = t.expression.clone();
                            t.args = t.args.slice();
                        }
                    }
                }
                t.call_only = true;
                return t;
            });
            e(Lt, function(e, n) {
                var t = this;
                var r = [], i = [], a = 0;
                var o = t.properties;
                for (var s = 0; s < o.length; s++) {
                    var f = o[s];
                    if (f.key instanceof bn) r.push(f.key);
                    if (!ne(f)) continue;
                    var u = f.value;
                    if (!u.has_side_effects(e)) continue;
                    if (u.contains_this()) return t;
                    if (f instanceof Xt) {
                        a++;
                        i.push(f);
                    } else {
                        i.push(u);
                    }
                }
                var c = t.extends;
                if (c) {
                    if (c instanceof Ln) c = c.fixed_value();
                    c = !Re(c);
                    if (!c) r.unshift(t.extends);
                }
                r = d(r, e, n);
                if (r) n = false;
                i = d(i, e, n);
                if (!r) {
                    if (!c && !i && !t.name) return null;
                    r = [];
                }
                if (c || t.name || !e.has_directive("use strict")) {
                    var l = re(t);
                    if (!c) l.extends = null;
                    l.properties = [];
                    if (i) {
                        if (i.length == a) {
                            if (r.length) i.unshift(Fe(Vt, t, {
                                key: Pe(t, r),
                                value: null
                            }));
                            l.properties = i;
                        } else l.properties.push(Fe(Vt, t, {
                            static: true,
                            key: r.length ? Pe(t, r) : "c",
                            value: p()
                        }));
                    } else if (r.length) l.properties.push(Fe(Jt, t, {
                        key: Pe(t, r),
                        value: Fe(Ft, t, {
                            argnames: [],
                            body: []
                        }).init_vars(l)
                    }));
                    return l;
                }
                if (i) r.push(Fe(qn, t, {
                    expression: Fe($t, t, {
                        argnames: [],
                        body: [],
                        value: p()
                    }).init_vars(t.parent_scope),
                    args: []
                }));
                return Pe(t, r);
                function p() {
                    return Pe(t, i.map(function(e) {
                        if (!(e instanceof Xt)) return e;
                        var n = Fe($t, e.value);
                        n.argnames = [];
                        return Fe(qn, e, {
                            expression: n,
                            args: []
                        });
                    }));
                }
            });
            e(Nn, function(e) {
                var n = this.consequent.drop_side_effect_free(e);
                var t = this.alternative.drop_side_effect_free(e);
                if (n === this.consequent && t === this.alternative) return this;
                var r;
                if (e.option("ie")) {
                    r = [];
                    if (n instanceof Ft) {
                        r.push(n);
                        n = null;
                    }
                    if (t instanceof Ft) {
                        r.push(t);
                        t = null;
                    }
                }
                var i;
                if (!n) {
                    i = t ? Fe(jn, this, {
                        operator: "||",
                        left: this.condition,
                        right: t
                    }) : this.condition.drop_side_effect_free(e);
                } else if (!t) {
                    i = Fe(jn, this, {
                        operator: "&&",
                        left: this.condition,
                        right: n
                    });
                } else {
                    i = this.clone();
                    i.consequent = n;
                    i.alternative = t;
                }
                if (!r) return i;
                if (i) r.push(i);
                return r.length == 0 ? null : Pe(this, r);
            });
            e(Un, Zn);
            e(zn, function(e, n) {
                var t = this.expression;
                if (t.may_throw_on_access(e)) return this;
                return t.drop_side_effect_free(e, n);
            });
            e(Ft, function(e) {
                return we(this, e) ? null : this;
            });
            e(Tt, Zn);
            e(Rn, function(e, n) {
                var t = [];
                this.properties.forEach(function(e) {
                    if (e instanceof Mn) {
                        t.push(e);
                    } else {
                        if (e.key instanceof bn) t.push(e.key);
                        t.push(e.value);
                    }
                });
                var r = d(t, e, n, function(e, n, t) {
                    var r = e.expression;
                    return r.safe_to_spread() ? r.drop_side_effect_free(n, t) : e;
                });
                if (!r) return null;
                if (r === t && !_n(r, function(e) {
                    return !(e instanceof Mn);
                })) return this;
                return Pe(this, r.map(function(e) {
                    return e instanceof Mn ? Fe(Rn, e, {
                        properties: [ e ]
                    }) : e;
                }));
            });
            e(Rr, Zn);
            e(On, function(e, n) {
                var t = d(this.expressions, e, n);
                if (!t) return null;
                var r = t.length - 1;
                var i = t[r];
                if (e.option("awaits") && r > 0 && i instanceof wr && i.expression.is_constant()) {
                    t = t.slice(0, -1);
                    r--;
                    var a = t[r];
                    i.expression = x(e, a) ? a : a.negate(e);
                    t[r] = i;
                }
                var o, s, f;
                if (e.option("conditionals") && r > 0 && (o = t[r - 1]) instanceof In && o.operator == "=" && (f = o.left) instanceof Ln && (s = se(e, f.definition(), o.right, i))) {
                    o = o.clone();
                    o.right = s;
                    t = t.slice(0, -2);
                    t.push(o.drop_side_effect_free(e, n));
                }
                return t === this.expressions ? this : Pe(this, t);
            });
            e(Cn, function(e, n) {
                var t = this.expression;
                if (t.may_throw_on_access(e)) return this;
                var r = this.property;
                t = t.drop_side_effect_free(e, n);
                if (!t) return r.drop_side_effect_free(e, n);
                r = r.drop_side_effect_free(e);
                if (!r) return t;
                return Pe(this, [ t, r ]);
            });
            e(Ln, function(e) {
                return this.is_declared(e) && Ce(this, e) ? null : this;
            });
            e(Vr, function(e, n) {
                var t = this;
                if (t.is_expr_pure(e)) {
                    var r = t.expressions;
                    if (r.length == 0) return null;
                    return Pe(t, r).drop_side_effect_free(e, n);
                }
                var i = t.tag;
                var a = Y(e, i);
                if (a) {
                    t = t.clone();
                    t.tag = a;
                    if (i._squeezed) t.tag._squeezed = true;
                }
                return t;
            });
            e(Fn, function(e, n) {
                var t = this.expression;
                if (pi[this.operator]) {
                    this.write_only = !t.has_side_effects(e);
                    return this;
                }
                if (this.operator == "typeof" && t instanceof Ln && Ce(t, e)) {
                    return null;
                }
                var r = t.drop_side_effect_free(e, n);
                if (n && r && ge(r)) {
                    if (r === t && this.operator == "!") return this;
                    return r.negate(e, n);
                }
                return r;
            });
        })(function(e, n) {
            e.DEFMETHOD("drop_side_effect_free", n);
        });
        e(wn, function(e, n) {
            if (n.option("side_effects")) {
                var t = e.body;
                var r = t.drop_side_effect_free(n, true);
                if (!r) {
                    bn.warn("Dropping side-effect-free statement [{start}]", e);
                    return Fe(yn, e);
                }
                if (r !== t) {
                    return Fe(wn, e, {
                        body: r
                    });
                }
            }
            return e;
        });
        e(_t, function(e, n) {
            return n.option("loops") ? Fe(gt, e).optimize(n) : e;
        });
        function X(n, e, t) {
            if (!t) t = er;
            var r = false;
            var i = new Gn(function(e) {
                if (r || e instanceof kn) return true;
                if (e instanceof t && i.loopcontrol_target(e) === n) {
                    return r = true;
                }
            });
            if (e instanceof dt) i.push(e);
            i.push(n);
            n.body.walk(i);
            return r;
        }
        e(mt, function(t, e) {
            if (!e.option("loops")) return t;
            var n = j(e, t.condition);
            if (!(n instanceof bn)) {
                if (n && !X(t, e.parent(), tr)) return Fe(gt, t, {
                    body: Fe(xn, t.body, {
                        body: [ t.body, Fe(wn, t.condition, {
                            body: t.condition
                        }) ]
                    })
                }).optimize(e);
                if (!X(t, e.parent())) return Fe(xn, t.body, {
                    body: [ t.body, Fe(wn, t.condition, {
                        body: t.condition
                    }) ]
                }).optimize(e);
            }
            if (t.body instanceof xn && !X(t, e.parent(), tr)) {
                var r = t.body.body;
                for (var i = r.length; --i >= 0; ) {
                    var a = r[i];
                    if (a instanceof Tn && !a.alternative && a.body instanceof nr && e.loopcontrol_target(a.body) === t) {
                        if (o(a.condition)) break;
                        t.condition = Fe(jn, t, {
                            operator: "&&",
                            left: a.condition.negate(e),
                            right: t.condition
                        });
                        r.splice(i, 1);
                    } else if (a instanceof wn) {
                        if (o(a.body)) break;
                        t.condition = Pe(t, [ a.body, t.condition ]);
                        r.splice(i, 1);
                    } else if (!L(a, true)) {
                        break;
                    }
                }
                t.body = te(t.body, e.parent());
            }
            if (t.body instanceof yn) return Fe(gt, t).optimize(e);
            if (t.body instanceof wn) return Fe(gt, t, {
                condition: Pe(t.condition, [ t.body.body, t.condition ]),
                body: Fe(yn, t)
            }).optimize(e);
            return t;
            function o(e) {
                var n = false;
                e.walk(new Gn(function(e) {
                    if (n) return true;
                    if (e instanceof Ln) {
                        if (!Jn(e.definition(), t.enclosed)) n = true;
                        return true;
                    }
                }));
                return n;
            }
        });
        function K(n, t) {
            var e = o(n.body);
            if (t.option("dead_code") && (e instanceof nr || e instanceof tr && s(e) || e instanceof Qt)) {
                var r = [];
                if (ut(n.init)) {
                    r.push(n.init);
                } else if (n.init) {
                    r.push(Fe(wn, n.init, {
                        body: n.init
                    }));
                }
                var i = s(e) || e instanceof Qt;
                if (n.condition && i) {
                    r.push(Fe(Tn, n, {
                        condition: n.condition,
                        body: e,
                        alternative: null
                    }));
                } else if (n.condition) {
                    r.push(Fe(wn, n.condition, {
                        body: n.condition
                    }));
                } else if (i) {
                    r.push(e);
                }
                P(t, n.body, r);
                return Fe(xn, n, {
                    body: r
                });
            }
            if (e instanceof Tn) {
                var a = o(e.body);
                if (a instanceof nr && !s(a)) {
                    if (n.condition) {
                        n.condition = Fe(jn, n.condition, {
                            left: n.condition,
                            operator: "&&",
                            right: e.condition.negate(t)
                        });
                    } else {
                        n.condition = e.condition.negate(t);
                    }
                    var r = G(e.alternative);
                    P(t, e.body, r);
                    return f(r);
                }
                a = o(e.alternative);
                if (a instanceof nr && !s(a)) {
                    if (n.condition) {
                        n.condition = Fe(jn, n.condition, {
                            left: n.condition,
                            operator: "&&",
                            right: e.condition
                        });
                    } else {
                        n.condition = e.condition;
                    }
                    var r = G(e.body);
                    P(t, e.alternative, r);
                    return f(r);
                }
            }
            return n;
            function o(e) {
                return e instanceof xn ? e.body[0] : e;
            }
            function s(e) {
                return t.loopcontrol_target(e) !== t.self();
            }
            function f(e) {
                if (n.body instanceof xn) {
                    n.body = n.body.clone();
                    n.body.body = e.concat(n.body.body.slice(1));
                    n.body = n.body.transform(t);
                } else {
                    n.body = Fe(xn, n.body, {
                        body: e
                    }).transform(t);
                }
                return K(n, t);
            }
        }
        e(gt, function(e, n) {
            if (!n.option("loops")) return e;
            if (n.option("side_effects")) {
                if (e.init) e.init = e.init.drop_side_effect_free(n);
                if (e.step) e.step = e.step.drop_side_effect_free(n);
            }
            if (e.condition) {
                var t = j(n, e.condition);
                if (!t) {
                    if (n.option("dead_code")) {
                        var r = [];
                        if (ut(e.init)) {
                            r.push(e.init);
                        } else if (e.init) {
                            r.push(Fe(wn, e.init, {
                                body: e.init
                            }));
                        }
                        r.push(Fe(wn, e.condition, {
                            body: e.condition
                        }));
                        P(n, e.body, r);
                        return Fe(xn, e, {
                            body: r
                        }).optimize(n);
                    }
                } else if (!(t instanceof bn)) {
                    e.body = Fe(xn, e.body, {
                        body: [ Fe(wn, e.condition, {
                            body: e.condition
                        }), e.body ]
                    });
                    e.condition = null;
                }
            }
            return K(e, n);
        });
        e(bt, function(e, t) {
            if (t.option("varify") && W(e.init)) {
                var n = e.init.definitions[0].name;
                if ((n instanceof Yn || n instanceof Fr) && !n.match_symbol(function(e) {
                    if (e instanceof zr) {
                        var n = e.definition();
                        return !en(n) || ee(t, n);
                    }
                }, true)) {
                    e.init = ie(e.init, e.resolve());
                }
            }
            return e;
        });
        function V(e, n, t) {
            if (e instanceof On) e = e.tail_node();
            if (!(e instanceof jn)) return;
            if (!(e.left instanceof Vn)) {
                switch (e.operator) {
                  case "&&":
                    V(e.left, n);
                    V(e.right, n);
                    break;

                  case "||":
                    V(p(e.left), t);
                    V(p(e.right), t);
                    break;
                }
                return;
            }
            if (!(e.right instanceof Pn)) return;
            if (e.right.operator != "typeof") return;
            var r = e.right.expression;
            if (!Ne(r)) return;
            var i;
            var a = e.left.value == "undefined";
            switch (e.operator) {
              case "==":
                i = a ? t : n;
                break;

              case "!=":
                i = a ? n : t;
                break;

              default:
                return;
            }
            if (!i) return;
            var o = false;
            var s = r.definition();
            var f;
            var u = [];
            var c = [];
            var l = new Gn(function(e, n) {
                if (o) return true;
                if (e instanceof In) {
                    var t = e.left;
                    if (!(t instanceof Ln && t.definition() === s)) return;
                    e.right.walk(l);
                    switch (e.operator) {
                      case "=":
                      case "&&=":
                        o = true;
                    }
                    return true;
                }
                if (e instanceof qn) {
                    n();
                    f = e.expression.tail_node();
                    var r;
                    if (f instanceof Ln) {
                        f = f.fixed_value();
                        r = u.length;
                    }
                    if (!(f instanceof En)) {
                        o = true;
                    } else if (nt(c, f)) {
                        f.walk(l);
                    }
                    if (r >= 0) u.length = r;
                    return true;
                }
                if (e instanceof vt) {
                    var r = u.length;
                    n();
                    if (o) u.length = r;
                    return true;
                }
                if (e instanceof gt) {
                    if (e.init) e.init.walk(l);
                    var r = u.length;
                    if (e.condition) e.condition.walk(l);
                    e.body.walk(l);
                    if (e.step) e.step.walk(l);
                    if (o) u.length = r;
                    return true;
                }
                if (e instanceof bt) {
                    e.object.walk(l);
                    var r = u.length;
                    e.init.walk(l);
                    e.body.walk(l);
                    if (o) u.length = r;
                    return true;
                }
                if (e instanceof kn) {
                    if (e === f) return;
                    return true;
                }
                if (e instanceof Ln) {
                    if (e.definition() === s) u.push(e);
                    return true;
                }
            });
            i.walk(l);
            u.forEach(function(e) {
                e.defined = true;
            });
            function p(e) {
                if (!(e instanceof jn)) return;
                switch (e.operator) {
                  case "==":
                    e = e.clone();
                    e.operator = "!=";
                    return e;

                  case "!=":
                    e = e.clone();
                    e.operator = "==";
                    return e;
                }
            }
        }
        function j(e, n, t) {
            if (n.truthy) return true;
            if (Ie(n)) return undefined;
            if (n.falsy && !t) return false;
            if (n.is_truthy()) return true;
            return n.evaluate(e, true);
        }
        function Q(e, n) {
            var t;
            var r = 0;
            var i = false;
            var a = e.self();
            if (!ut(a)) while (true) {
                t = a;
                a = e.parent(r++);
                if (a instanceof jn) {
                    switch (t) {
                      case a.left:
                        if (He[a.operator]) continue;
                        break;

                      case a.right:
                        if (s(a.left)) switch (a.operator) {
                          case "&&":
                            n[i ? "falsy" : "truthy"] = true;
                            break;

                          case "||":
                          case "??":
                            n[i ? "truthy" : "falsy"] = true;
                            break;
                        }
                        break;
                    }
                } else if (a instanceof Nn) {
                    var o = a.condition;
                    if (o === t) continue;
                    if (s(o)) switch (t) {
                      case a.consequent:
                        n[i ? "falsy" : "truthy"] = true;
                        break;

                      case a.alternative:
                        n[i ? "truthy" : "falsy"] = true;
                        break;
                    }
                } else if (a instanceof Qt) {
                    break;
                } else if (a instanceof Tn) {
                    break;
                } else if (a instanceof On) {
                    if (a.expressions[0] === t) continue;
                } else if (a instanceof wn) {
                    break;
                }
                return;
            }
            while (true) {
                t = a;
                a = e.parent(r++);
                if (a instanceof xn) {
                    if (a.body[0] === t) continue;
                } else if (a instanceof Tn) {
                    if (s(a.condition)) switch (t) {
                      case a.body:
                        n[i ? "falsy" : "truthy"] = true;
                        break;

                      case a.alternative:
                        n[i ? "truthy" : "falsy"] = true;
                        break;
                    }
                }
                return;
            }
            function s(e) {
                if (n.equals(e)) return true;
                if (!(e instanceof Pn)) return false;
                if (e.operator != "!") return false;
                if (!n.equals(e.expression)) return false;
                i = true;
                return true;
            }
        }
        e(Tn, function(e, u) {
            if (ue(e.alternative)) e.alternative = null;
            if (!u.option("conditionals")) return e;
            if (u.option("booleans") && !e.condition.has_side_effects(u)) {
                Q(u, e.condition);
            }
            if (u.option("dead_code")) {
                var n = j(u, e.condition);
                if (!n) {
                    bn.warn("Condition always false [{start}]", e.condition);
                    var t = [ Fe(wn, e.condition, {
                        body: e.condition
                    }).transform(u) ];
                    P(u, e.body, t);
                    if (e.alternative) t.push(e.alternative);
                    return Fe(xn, e, {
                        body: t
                    }).optimize(u);
                } else if (!(n instanceof bn)) {
                    bn.warn("Condition always true [{start}]", e.condition);
                    var t = [ Fe(wn, e.condition, {
                        body: e.condition
                    }).transform(u), e.body ];
                    if (e.alternative) P(u, e.alternative, t);
                    return Fe(xn, e, {
                        body: t
                    }).optimize(u);
                }
            }
            var r = e.condition.negate(u);
            var i = e.condition.print_to_string().length;
            var a = r.print_to_string().length;
            var o = a < i;
            if (e.alternative && o) {
                o = false;
                e.condition = r;
                var s = e.body;
                e.body = e.alternative;
                e.alternative = ue(s) ? null : s;
            }
            var f = [];
            var c = [];
            var l = [];
            var p = F(e.body, f, c, l);
            var d = [];
            var h = [];
            var v = [];
            var m = F(e.alternative, d, h, v);
            if (p instanceof xn || m instanceof xn) {
                var t = [], _ = [];
                if (p) {
                    [].push.apply(t, f);
                    [].push.apply(_, c);
                    if (p instanceof xn) {
                        e.body = p;
                    } else if (p.length == 0) {
                        e.body = Fe(yn, e.body);
                    } else {
                        e.body = Fe(wn, e.body, {
                            body: Pe(e.body, p)
                        });
                    }
                    l.forEach(N);
                }
                if (m) {
                    [].push.apply(t, d);
                    [].push.apply(_, h);
                    if (m instanceof xn) {
                        e.alternative = m;
                    } else if (m.length == 0) {
                        e.alternative = null;
                    } else {
                        e.alternative = Fe(wn, e.alternative, {
                            body: Pe(e.alternative, m)
                        });
                    }
                    v.forEach(N);
                }
                if (_.length > 0) t.push(Fe(dr, e, {
                    definitions: _
                }));
                if (t.length > 0) {
                    t.push(e.transform(u));
                    return Fe(xn, e, {
                        body: t
                    }).optimize(u);
                }
            } else if (p && m) {
                var t = f.concat(d);
                if (c.length > 0 || h.length > 0) t.push(Fe(dr, e, {
                    definitions: c.concat(h)
                }));
                if (p.length == 0) {
                    t.push(Fe(wn, e.condition, {
                        body: m.length > 0 ? Fe(jn, e, {
                            operator: "||",
                            left: e.condition,
                            right: Pe(e.alternative, m)
                        }).transform(u) : e.condition.clone()
                    }).optimize(u));
                } else if (m.length == 0) {
                    if (i === a && !o && e.condition instanceof jn && e.condition.operator == "||") {
                        o = true;
                    }
                    t.push(Fe(wn, e, {
                        body: Fe(jn, e, {
                            operator: o ? "||" : "&&",
                            left: o ? r : e.condition,
                            right: Pe(e.body, p)
                        }).transform(u)
                    }).optimize(u));
                } else {
                    t.push(Fe(wn, e, {
                        body: Fe(Nn, e, {
                            condition: e.condition,
                            consequent: Pe(e.body, p),
                            alternative: Pe(e.alternative, m)
                        })
                    }).optimize(u));
                }
                l.forEach(N);
                v.forEach(N);
                return Fe(xn, e, {
                    body: t
                }).optimize(u);
            }
            if (ue(e.body)) e = Fe(Tn, e, {
                condition: r,
                body: e.alternative,
                alternative: null
            });
            if (e.alternative instanceof Qt && e.body.TYPE == e.alternative.TYPE) {
                var g = e.body.value;
                var b = e.alternative.value;
                if (!g && !b) return Fe(xn, e, {
                    body: [ Fe(wn, e, {
                        body: e.condition
                    }), e.body ]
                }).optimize(u);
                if (g && b || !z()) {
                    var y = Fe(e.body.CTOR, e, {
                        value: Fe(Nn, e, {
                            condition: e.condition,
                            consequent: g || Fe(Qr, e.body).transform(u),
                            alternative: b || Fe(Qr, e.alternative).transform(u)
                        })
                    });
                    if (y instanceof Sn) y.in_bool = e.body.in_bool || e.alternative.in_bool;
                    return y;
                }
            }
            if (e.body instanceof Tn && !e.body.alternative && !e.alternative) {
                e = Fe(Tn, e, {
                    condition: Fe(jn, e.condition, {
                        operator: "&&",
                        left: e.condition,
                        right: e.body.condition
                    }),
                    body: e.body.body,
                    alternative: null
                });
            }
            if (U(e.body) && e.alternative) {
                var w = e.alternative;
                e.alternative = null;
                return Fe(xn, e, {
                    body: [ e, w ]
                }).optimize(u);
            }
            if (U(e.alternative)) {
                var t = e.body;
                e.body = e.alternative;
                e.condition = o ? r : e.condition.negate(u);
                e.alternative = null;
                return Fe(xn, e, {
                    body: [ e, t ]
                }).optimize(u);
            }
            if (e.alternative) {
                var x = $(e.body);
                var k = C(x);
                var E = $(e.alternative);
                var S = C(E);
                for (var T = []; k >= 0 && S >= 0; ) {
                    var A = x[k];
                    var D = E[S];
                    if (A.equals(D)) {
                        x.splice(k--, 1);
                        E.splice(S--, 1);
                        T.unshift(B(A, D));
                    } else {
                        if (!(A instanceof wn)) break;
                        if (!(D instanceof wn)) break;
                        var q = A.body.tail_node();
                        var O = D.body.tail_node();
                        if (!q.equals(O)) break;
                        k = M(x, A.body, k);
                        S = M(E, D.body, S);
                        T.unshift(Fe(wn, q, {
                            body: B(q, O)
                        }));
                    }
                }
                if (T.length > 0) {
                    e.body = x.length > 0 ? Fe(xn, e, {
                        body: x
                    }) : Fe(yn, e);
                    e.alternative = E.length > 0 ? Fe(xn, e, {
                        body: E
                    }) : null;
                    T.unshift(e);
                    return Fe(xn, e, {
                        body: T
                    }).optimize(u);
                }
            }
            if (u.option("typeofs")) V(e.condition, e.body, e.alternative);
            return e;
            function $(e) {
                return e instanceof xn ? e.body : [ e ];
            }
            function z() {
                var e = false, n = 0, t = u.self();
                do {
                    if (t instanceof fr) {
                        if (u.parent(n).bfinally) e = true;
                        n++;
                    } else if (t instanceof ur) {
                        n++;
                    } else if (t instanceof kn) {
                        return e && R(t);
                    } else if (t instanceof sr) {
                        if (t.bfinally) e = true;
                    }
                } while (t = u.parent(n++));
            }
            function C(e) {
                for (var n = e.length; --n >= 0; ) {
                    if (!L(e[n], true)) break;
                }
                return n;
            }
            function M(e, n, t) {
                if (n instanceof On) {
                    e[t] = Fe(wn, n, {
                        body: Pe(n, n.expressions.slice(0, -1))
                    });
                } else {
                    e.splice(t--, 1);
                }
                return t;
            }
            function F(e, n, t, r) {
                if (e == null) return [];
                if (e instanceof xn) {
                    var i = [];
                    for (var a = 0; a < e.body.length; a++) {
                        var o = e.body[a];
                        if (o instanceof yn) continue;
                        if (o instanceof Qt) {
                            if (a == 0) return;
                            if (i.length > 0) {
                                o = o.clone();
                                i.push(o.value || Fe(Qr, o).transform(u));
                                o.value = Pe(e, i);
                            }
                            var s = e.clone();
                            s.body = s.body.slice(a + 1);
                            s.body.unshift(o);
                            return s;
                        }
                        if (o instanceof jt) {
                            n.push(o);
                        } else if (o instanceof wn) {
                            if (!u.option("sequences") && i.length > 0) return;
                            i.push(o.body);
                        } else if (o instanceof dr) {
                            if (!u.option("sequences") && i.length > 0) return;
                            o.remove_initializers(u, t);
                            o.definitions.forEach(f);
                        } else {
                            return;
                        }
                    }
                    return i;
                }
                if (e instanceof jt) {
                    n.push(e);
                    return [];
                }
                if (e instanceof yn) return [];
                if (e instanceof wn) return [ e.body ];
                if (e instanceof dr) {
                    var i = [];
                    e.remove_initializers(u, t);
                    e.definitions.forEach(f);
                    return i;
                }
                function f(e) {
                    if (!e.value) return;
                    i.push(Fe(In, e, {
                        operator: "=",
                        left: e.name.convert_symbol(Ln, function(e) {
                            r.push(e);
                        }),
                        right: e.value
                    }));
                }
            }
        });
        e(rr, function(r, t) {
            if (!t.option("switches")) return r;
            if (!t.option("dead_code")) return r;
            var e = [];
            var n;
            var i = [];
            var a;
            var o;
            var s = [];
            for (var f = 0, u = r.body.length; f < u; f++) {
                n = r.body[f];
                if (n instanceof ar) {
                    var c = e[e.length - 1];
                    if (a || w(n.body[0], t) && (!c || U(c))) {
                        k(n, c);
                        continue;
                    } else {
                        a = n;
                    }
                } else {
                    var l = n.expression;
                    var p = Fe(jn, r, {
                        operator: "===",
                        left: r.expression,
                        right: l
                    }).evaluate(t, true);
                    if (!p) {
                        if (l.has_side_effects(t)) s.push(l);
                        k(n, e[e.length - 1]);
                        continue;
                    }
                    if (!(p instanceof bn)) {
                        if (a) {
                            var d = e.indexOf(a);
                            e.splice(d, 1);
                            k(a, e[d - 1]);
                            a = null;
                        }
                        if (l.has_side_effects(t)) {
                            o = n;
                        } else {
                            a = n = Fe(ar, n);
                        }
                        while (++f < u) k(r.body[f], n);
                    }
                }
                if (f + 1 >= u || U(n)) {
                    var c = e[e.length - 1];
                    var h = n.body;
                    if (U(c)) switch (c.body.length - h.length) {
                      case 1:
                        var v = c.body[c.body.length - 1];
                        if (!w(v, t)) break;
                        h = h.concat(v);

                      case 0:
                        var m = Fe(xn, c);
                        var _ = Fe(xn, n, {
                            body: h
                        });
                        if (m.equals(_)) c.body = [];
                    }
                }
                if (s.length) {
                    if (n instanceof ar) {
                        e.push(Fe(or, r, {
                            expression: Pe(r, s),
                            body: []
                        }));
                    } else {
                        s.push(n.expression);
                        n.expression = Pe(r, s);
                    }
                    s = [];
                }
                e.push(n);
            }
            if (s.length && !o) {
                e.push(Fe(or, r, {
                    expression: Pe(r, s),
                    body: []
                }));
            }
            while (n = e[e.length - 1]) {
                var v = n.body[n.body.length - 1];
                if (w(v, t)) n.body.pop();
                if (n === a) {
                    if (!E(n)) break;
                } else if (n.expression.has_side_effects(t)) {
                    break;
                } else if (a) {
                    if (!E(a)) break;
                    if (e[e.length - 2] !== a) break;
                    a.body = a.body.concat(n.body);
                    n.body = [];
                } else if (!E(n)) break;
                k(n);
                if (e.pop() === a) a = null;
            }
            if (!n) {
                i.push(Fe(wn, r.expression, {
                    body: r.expression
                }));
                if (s.length) i.push(Fe(wn, r, {
                    body: Pe(r, s)
                }));
                return Fe(xn, r, {
                    body: i
                }).optimize(t);
            }
            if (n === a) while (n = e[e.length - 2]) {
                if (n instanceof ar) break;
                if (!E(n)) break;
                var l = n.expression;
                if (l.has_side_effects(t)) {
                    var c = e[e.length - 3];
                    if (c && !U(c)) break;
                    a.body.unshift(Fe(wn, r, {
                        body: l
                    }));
                }
                k(n);
                e.splice(-2, 1);
            }
            e[0].body = i.concat(e[0].body);
            r.body = e;
            if (t.option("conditionals")) switch (e.length) {
              case 1:
                if (!x(e[0])) break;
                var l = e[0].expression;
                var h = e[0].body.slice();
                if (e[0] !== a && e[0] !== o) return Fe(Tn, r, {
                    condition: Fe(jn, r, {
                        operator: "===",
                        left: r.expression,
                        right: l
                    }),
                    body: Fe(xn, r, {
                        body: h
                    }),
                    alternative: null
                }).optimize(t);
                if (l) h.unshift(Fe(wn, l, {
                    body: l
                }));
                h.unshift(Fe(wn, r.expression, {
                    body: r.expression
                }));
                return Fe(xn, r, {
                    body: h
                }).optimize(t);

              case 2:
                if (!Jn(a, e) || !x(e[1])) break;
                var h = e[0].body.slice();
                var g = h.length && w(h[h.length - 1], t);
                if (g) h.pop();
                if (!_n(h, x)) break;
                var b = e[1].body.length && Fe(xn, e[1]);
                var y = Fe(Tn, r, {
                    condition: Fe(jn, r, e[0] === a ? {
                        operator: "!==",
                        left: r.expression,
                        right: e[1].expression
                    } : {
                        operator: "===",
                        left: r.expression,
                        right: e[0].expression
                    }),
                    body: Fe(xn, e[0], {
                        body: h
                    }),
                    alternative: g && b || null
                });
                if (!g && b) y = Fe(xn, r, {
                    body: [ y, b ]
                });
                return y.optimize(t);
            }
            return r;
            function w(e, n) {
                return e instanceof nr && n.loopcontrol_target(e) === r;
            }
            function x(e) {
                var n = false;
                var t = new Gn(function(e) {
                    if (n || e instanceof En || e instanceof wn) return true;
                    if (w(e, t)) n = true;
                });
                t.push(r);
                e.walk(t);
                return !n;
            }
            function k(e, n) {
                if (n && !U(n)) {
                    n.body = n.body.concat(e.body);
                } else {
                    P(t, e, i);
                }
            }
        });
        e(sr, function(e, n) {
            e.body = l(e.body, n);
            if (n.option("dead_code")) {
                if (E(e) && !(e.bcatch && e.bcatch.argname && e.bcatch.argname.match_symbol(function(e) {
                    return e instanceof Hr && !Ce(e);
                }, true))) {
                    var t = [];
                    if (e.bcatch) {
                        P(n, e.bcatch, t);
                        t.forEach(function(e) {
                            if (!(e instanceof dr)) return;
                            e.definitions.forEach(function(e) {
                                var n = e.name.definition().redefined();
                                if (!n) return;
                                e.name = e.name.clone();
                                e.name.thedef = n;
                            });
                        });
                    }
                    t.unshift(Fe(xn, e).optimize(n));
                    if (e.bfinally) {
                        t.push(Fe(xn, e.bfinally).optimize(n));
                    }
                    return Fe(xn, e, {
                        body: t
                    }).optimize(n);
                }
                if (e.bfinally && E(e.bfinally)) {
                    var t = Fe(xn, e.bfinally).optimize(n);
                    t = e.body.concat(t);
                    if (!e.bcatch) return Fe(xn, e, {
                        body: t
                    }).optimize(n);
                    e.body = t;
                    e.bfinally = null;
                }
            }
            return e;
        });
        function Z(i) {
            return function(n, t) {
                var r = false;
                this.definitions.forEach(function(e) {
                    if (e.value) r = true;
                    e.name.match_symbol(function(e) {
                        if (e instanceof zr) t.push(Fe(An, e, {
                            name: e,
                            value: i(n, e)
                        }));
                    }, true);
                });
                return r;
            };
        }
        lr.DEFMETHOD("remove_initializers", Z(function(e, n) {
            return Fe(Qr, n).optimize(e);
        }));
        pr.DEFMETHOD("remove_initializers", Z(Zn));
        dr.DEFMETHOD("remove_initializers", Z(Zn));
        cr.DEFMETHOD("to_assignments", function() {
            var e = this.definitions.reduce(function(e, t) {
                var r = t.name.definition();
                var n = t.value;
                if (n) {
                    if (n instanceof On) n = n.clone();
                    var i = Fe(Ln, t.name);
                    var a = Fe(In, t, {
                        operator: "=",
                        left: i,
                        right: n
                    });
                    e.push(a);
                    var o = function() {
                        return a.right;
                    };
                    o.assigns = [ a ];
                    o.direct_access = r.direct_access;
                    o.escaped = r.escaped;
                    i.fixed = o;
                    r.references.forEach(function(e) {
                        if (!e.fixed) return;
                        var n = e.fixed.assigns;
                        if (!n) return;
                        if (n[0] !== t) return;
                        if (n.length > 1 || e.fixed.to_binary || e.fixed.to_prefix) {
                            n[0] = a;
                        } else {
                            e.fixed = o;
                            if (r.fixed === e.fixed) r.fixed = o;
                        }
                    });
                    r.references.push(i);
                }
                r.assignments++;
                r.eliminated++;
                r.single_use = false;
                return e;
            }, []);
            if (e.length == 0) return null;
            return Pe(this, e);
        });
        function Ye(e) {
            return e.name != "arguments" && e.orig.length < (e.orig[0] instanceof Nr ? 3 : 2);
        }
        function ee(e, n) {
            if (e.exposed(n)) return true;
            var t = n.scope.resolve();
            for (var r = n.scope; r !== t; ) {
                r = r.parent_scope;
                if (r.var_names().has(n.name)) return true;
            }
        }
        function ie(e, r) {
            return Fe(dr, e, {
                definitions: e.definitions.map(function(e) {
                    return Fe(An, e, {
                        name: e.name.convert_symbol(Pr, function(e, n) {
                            var t = e.definition();
                            t.orig[t.orig.indexOf(n)] = e;
                            if (t.scope === r) return;
                            t.scope = r;
                            r.variables.set(t.name, t);
                            r.enclosed.push(t);
                            r.var_names().set(t.name, true);
                        }),
                        value: e.value
                    });
                })
            });
        }
        function ae(e, n) {
            var t = n.definition();
            return (t.fixed || t.fixed === 0) && Ye(t) && en(t) && !ee(e, t);
        }
        function oe(e, n) {
            return n.option("varify") && _n(e.definitions, function(e) {
                return !e.name.match_symbol(function(e) {
                    if (e instanceof zr) return !ae(n, e);
                }, true);
            }) ? ie(e, n.find_parent(kn)) : e;
        }
        e(lr, oe);
        e(pr, oe);
        function xe(e, n) {
            if (!n.option("optional_chains")) return;
            if (e.terminal) do {
                var t = e.expression;
                if (e.optional) {
                    var r = j(n, t, true);
                    if (r == null) return Fe(Pn, e, {
                        operator: "void",
                        expression: t
                    }).optimize(n);
                    if (!(r instanceof bn)) e.optional = false;
                }
                e = t;
            } while ((e.TYPE == "Call" || e instanceof $n) && !e.terminal);
        }
        function he(e, n) {
            var t = e.expression;
            if (!(t instanceof On)) return e;
            var r = t.expressions.slice();
            var i = e.clone();
            i.expression = r.pop();
            r.push(i);
            return Pe(e, r);
        }
        function ke(e, t, n) {
            var r = e.expression;
            var i = r instanceof Ln ? r.fixed_value() : r;
            if (!(i instanceof En)) return;
            if (i.uses_arguments) return;
            if (i.pinned()) return;
            if (n && n.indexOf(i) < 0) return;
            var a = e.args;
            if (!_n(a, function(e) {
                return !(e instanceof Mn);
            })) return;
            var o = i.argnames;
            var s = i === r && !i.name;
            if (i.rest) {
                if (!(s && t.option("rests"))) return;
                var f = o.length;
                a = a.slice(0, f);
                while (a.length < f) a.push(Fe(Qr, e).optimize(t));
                a.push(Fe(Hn, e, {
                    elements: e.args.slice(f)
                }));
                o = o.concat(i.rest);
                i.rest = null;
            } else {
                a = a.slice();
                o = o.slice();
            }
            var u = 0, c = 0;
            var l = s && t.option("default_values");
            var p = s && t.drop_fargs(i, e) ? function(e, n) {
                if (!e) return true;
                if (e instanceof kr) {
                    return e.elements.length == 0 && !e.rest && n instanceof Hn;
                }
                if (e instanceof Sr) {
                    return e.properties.length == 0 && !e.rest && n && !n.may_throw_on_access(t);
                }
                return e.unused;
            } : hn;
            var d = [];
            for (var h = 0; h < a.length; h++) {
                var v = o[h];
                if (l && v instanceof Dn && a[h].is_defined(t)) {
                    o[h] = v = v.name;
                }
                if (!v || v.unused !== undefined) {
                    var m = a[h].drop_side_effect_free(t);
                    if (p(v)) {
                        if (v) o.splice(h, 1);
                        a.splice(h, 1);
                        if (m) d.push(m);
                        h--;
                        continue;
                    } else if (m) {
                        d.push(m);
                        a[u++] = Pe(e, d);
                        d = [];
                    } else if (v) {
                        if (d.length) {
                            a[u++] = Pe(e, d);
                            d = [];
                        } else {
                            a[u++] = Fe(Wn, a[h], {
                                value: 0
                            });
                            continue;
                        }
                    }
                } else if (p(v, a[h])) {
                    var m = a[h].drop_side_effect_free(t);
                    o.splice(h, 1);
                    a.splice(h, 1);
                    if (m) d.push(m);
                    h--;
                    continue;
                } else {
                    d.push(a[h]);
                    a[u++] = Pe(e, d);
                    d = [];
                }
                c = u;
            }
            for (;h < o.length; h++) {
                if (p(o[h])) o.splice(h--, 1);
            }
            i.argnames = o;
            a.length = c;
            e.args = a;
            if (!d.length) return;
            var _ = Pe(e, d);
            a.push(a.length < o.length ? Fe(Pn, e, {
                operator: "void",
                expression: _
            }) : _);
        }
        function ve(e, n) {
            if (!n) n = e.find_parent(kn);
            var t = [];
            if (Dt(n) || n instanceof kt && e.option("module")) {
                t.push("await");
            }
            if (qt(n)) t.push("yield");
            return t.length && mn(t);
        }
        function Ee(t, r) {
            if (!r) return true;
            var i = true;
            var a = new Gn(function(e) {
                if (!i) return true;
                if (e instanceof kn) {
                    if (e === t) return;
                    if (At(e)) {
                        for (var n = 0; i && n < e.argnames.length; n++) e.argnames[n].walk(a);
                    } else if (e instanceof jt && r[e.name.name]) {
                        i = false;
                    }
                    return true;
                }
                if (e instanceof $r && r[e.name] && e !== t.name) i = false;
            });
            t.walk(a);
            return i;
        }
        function Se(e, n) {
            return e.in_strict_mode(n) || !n.has_directive("use strict");
        }
        e(qn, function(p, c) {
            var a = p.expression;
            var P = xe(p, c);
            if (P) return P;
            if (c.option("sequences")) {
                if (a instanceof $n) {
                    var e = he(a, c);
                    if (e !== a) {
                        var n = p.clone();
                        n.expression = e.expressions.pop();
                        e.expressions.push(n);
                        return e.optimize(c);
                    }
                } else if (!_e(a.tail_node())) {
                    var e = he(p, c);
                    if (e !== p) return e.optimize(c);
                }
            }
            if (c.option("unused")) ke(p, c);
            if (c.option("unsafe")) {
                if (Ne(a)) switch (a.name) {
                  case "Array":
                    if (p.args.length == 1) {
                        var t = p.args[0];
                        if (t instanceof Wn) try {
                            var r = t.value;
                            if (r > 6) break;
                            var i = Array(r);
                            for (var o = 0; o < r; o++) i[o] = Fe(Zr, p);
                            return Fe(Hn, p, {
                                elements: i
                            });
                        } catch (e) {
                            bn.warn("Invalid array length: {length} [{start}]", {
                                length: r,
                                start: p.start
                            });
                            break;
                        }
                        if (!t.is_boolean(c) && !t.is_string(c)) break;
                    }
                    return Fe(Hn, p, {
                        elements: p.args
                    });

                  case "Object":
                    if (p.args.length == 0) return Fe(Rn, p, {
                        properties: []
                    });
                    break;

                  case "String":
                    if (p.args.length == 0) return Fe(Vn, p, {
                        value: ""
                    });
                    if (p.args.length == 1) return Fe(jn, p, {
                        operator: "+",
                        left: Fe(Vn, p, {
                            value: ""
                        }),
                        right: p.args[0]
                    }).optimize(c);
                    break;

                  case "Number":
                    if (p.args.length == 0) return Fe(Wn, p, {
                        value: 0
                    });
                    if (p.args.length == 1) return Fe(Pn, p, {
                        operator: "+",
                        expression: Fe(jn, p, {
                            operator: "+",
                            left: Fe(Vn, p, {
                                value: ""
                            }),
                            right: p.args[0]
                        })
                    }).optimize(c);
                    break;

                  case "Boolean":
                    if (p.args.length == 0) return Fe(ti, p).optimize(c);
                    if (p.args.length == 1) return Fe(Pn, p, {
                        operator: "!",
                        expression: Fe(Pn, p, {
                            operator: "!",
                            expression: p.args[0]
                        })
                    }).optimize(c);
                    break;

                  case "RegExp":
                    var j = [];
                    if (_n(p.args, function(e) {
                        var n = e.evaluate(c);
                        j.unshift(n);
                        return e !== n;
                    })) try {
                        return pe(c, p, Fe(Gr, p, {
                            value: RegExp.apply(RegExp, j)
                        }));
                    } catch (e) {
                        bn.warn("Error converting {this} [{start}]", p);
                    }
                    break;
                } else if (a instanceof zn) switch (a.property) {
                  case "toString":
                    var s = a.expression;
                    if (p.args.length == 0 && !(s.may_throw_on_access(c) || s instanceof Br)) {
                        return Fe(jn, p, {
                            operator: "+",
                            left: Fe(Vn, p, {
                                value: ""
                            }),
                            right: s
                        }).optimize(c);
                    }
                    break;

                  case "join":
                    if (a.expression instanceof Hn && p.args.length < 2) e: {
                        var f = p.args[0];
                        if (a.expression.elements.length == 0 && !(f instanceof Mn)) {
                            return f ? Pe(p, [ f, Fe(Vn, p, {
                                value: ""
                            }) ]).optimize(c) : Fe(Vn, p, {
                                value: ""
                            });
                        }
                        if (f) {
                            f = f.evaluate(c);
                            if (f instanceof bn) break e;
                        }
                        var i = [];
                        var u = [];
                        for (var o = 0; o < a.expression.elements.length; o++) {
                            var l = a.expression.elements[o];
                            var d = l.evaluate(c);
                            if (d !== l) {
                                u.push(d);
                            } else if (l instanceof Mn) {
                                break e;
                            } else {
                                if (u.length > 0) {
                                    i.push(Fe(Vn, p, {
                                        value: u.join(f)
                                    }));
                                    u.length = 0;
                                }
                                i.push(l);
                            }
                        }
                        if (u.length > 0) i.push(Fe(Vn, p, {
                            value: u.join(f)
                        }));
                        if (i.length == 1) {
                            if (i[0].is_string(c)) return i[0];
                            return Fe(jn, i[0], {
                                operator: "+",
                                left: Fe(Vn, p, {
                                    value: ""
                                }),
                                right: i[0]
                            });
                        }
                        if (f == "") {
                            var t;
                            if (i[0].is_string(c) || i[1].is_string(c)) {
                                t = i.shift();
                            } else {
                                t = Fe(Vn, p, {
                                    value: ""
                                });
                            }
                            return i.reduce(function(e, n) {
                                return Fe(jn, n, {
                                    operator: "+",
                                    left: e,
                                    right: n
                                });
                            }, t).optimize(c);
                        }
                        var h = p.clone();
                        h.expression = h.expression.clone();
                        h.expression.expression = h.expression.expression.clone();
                        h.expression.expression.elements = i;
                        return pe(c, p, h);
                    }
                    break;

                  case "charAt":
                    if (p.args.length < 2) {
                        var h = Fe(jn, p, {
                            operator: "||",
                            left: Fe(Cn, p, {
                                expression: a.expression,
                                property: p.args.length ? Fe(jn, p.args[0], {
                                    operator: "|",
                                    left: Fe(Wn, p, {
                                        value: 0
                                    }),
                                    right: p.args[0]
                                }) : Fe(Wn, p, {
                                    value: 0
                                })
                            }).optimize(c),
                            right: Fe(Vn, p, {
                                value: ""
                            })
                        });
                        h.is_string = vn;
                        return h.optimize(c);
                    }
                    break;

                  case "apply":
                    if (p.args.length == 2 && p.args[1] instanceof Hn) {
                        var v = p.args[1].elements.slice();
                        v.unshift(p.args[0]);
                        return Fe(qn, p, {
                            expression: Fe(zn, a, {
                                expression: a.expression,
                                property: "call"
                            }),
                            args: v
                        }).optimize(c);
                    }
                    break;

                  case "call":
                    var m = a.expression;
                    if (m instanceof Ln) {
                        m = m.fixed_value();
                    }
                    if (m instanceof En && !m.contains_this()) {
                        return (p.args.length ? Pe(p, [ p.args[0], Fe(qn, p, {
                            expression: a.expression,
                            args: p.args.slice(1)
                        }) ]) : Fe(qn, p, {
                            expression: a.expression,
                            args: []
                        })).optimize(c);
                    }
                    break;
                } else if (c.option("side_effects") && a instanceof qn && a.args.length == 1 && Ne(a.expression) && a.expression.name == "Object") {
                    var n = p.clone();
                    n.expression = je(p, a, a.args[0]);
                    return n.optimize(c);
                }
            }
            if (c.option("unsafe_Function") && Ne(a) && a.name == "Function") {
                if (p.args.length == 0) return Fe(Ft, p, {
                    argnames: [],
                    body: []
                }).init_vars(a.scope);
                if (_n(p.args, function(e) {
                    return e instanceof Vn;
                })) {
                    try {
                        var _ = "n(function(" + p.args.slice(0, -1).map(function(e) {
                            return e.value;
                        }).join() + "){" + p.args[p.args.length - 1].value + "})";
                        var g = ci(_);
                        var b = {
                            ie: c.option("ie")
                        };
                        g.figure_out_scope(b);
                        var N = new hi(c.options);
                        g = g.transform(N);
                        g.figure_out_scope(b);
                        g.compute_char_frequency(b);
                        g.mangle_names(b);
                        var y;
                        g.walk(new Gn(function(e) {
                            if (y) return true;
                            if (e instanceof En) {
                                y = e;
                                return true;
                            }
                        }));
                        var _ = vi();
                        xn.prototype._codegen.call(y, _);
                        p.args = [ Fe(Vn, p, {
                            value: y.argnames.map(function(e) {
                                return e.print_to_string();
                            }).join()
                        }), Fe(Vn, p.args[p.args.length - 1], {
                            value: _.get().replace(/^\{|\}$/g, "")
                        }) ];
                        return p;
                    } catch (e) {
                        if (e instanceof si) {
                            bn.warn("Error parsing code passed to new Function [{start}]", p.args[p.args.length - 1]);
                            bn.warn(e.toString());
                        } else {
                            throw e;
                        }
                    }
                }
            }
            var w = a instanceof Ln ? a.fixed_value() : a;
            var x = c.parent(), k = c.self();
            var E = w instanceof En && (!Dt(w) || c.option("awaits") && x instanceof wr) && (!qt(w) || c.option("yields") && k instanceof xr && k.nested);
            var S = E && w.first_statement();
            var T = 0, A = false;
            var D = !_n(p.args, function(e) {
                return !(e instanceof Mn);
            });
            var I = E && _n(w.argnames, function(e, n) {
                if (T == 1 && p.args[n] instanceof Mn) T = 2;
                if (e instanceof Dn) {
                    if (!T) T = 1;
                    var t = T == 1 && p.args[n];
                    if (!Ie(t)) T = 2;
                    if (ln(w, e.value)) return false;
                    e = e.name;
                }
                if (e instanceof Yn) {
                    A = true;
                    if (ln(w, e)) return false;
                }
                return true;
            }) && !(w.rest instanceof Yn && ln(w, w.rest));
            var H = I && c.option("inline") && !p.is_expr_pure(c) && (a === w || Se(w, c));
            if (H && S instanceof Sn) {
                var d = S.value;
                if (a === w && !w.name && (!d || d.is_constant_expression()) && Ee(w, ve(c))) {
                    return Pe(p, G(d)).optimize(c);
                }
            }
            if (E && !w.contains_this()) {
                var q, d, O = false;
                if (H && !w.uses_arguments && !w.pinned() && !(w.name && w instanceof Tt) && (a === w || !Ze(c, q = a.definition(), w) && w.is_constant_expression(Me(c))) && (d = K(S))) {
                    var Y = a === w || q.single_use && q.references.length - q.replaced == 1;
                    if (Z()) {
                        var v = p.args.slice();
                        var R = [];
                        var B = d.clone(true).transform(new ii(function(e) {
                            if (e instanceof Ln) {
                                var n = e.definition();
                                if (w.variables.get(e.name) !== n) {
                                    R.push(e);
                                    return e;
                                }
                                var t = Q(n);
                                var r = v[t];
                                if (!r) return Fe(Qr, p);
                                v[t] = null;
                                var i = this.parent();
                                return i ? je(i, e, r) : r;
                            }
                        }));
                        var L = w.inlined;
                        if (a !== w) w.inlined = true;
                        var U = [];
                        v.forEach(function(e) {
                            if (!e) return;
                            e = e.clone(true);
                            e.walk(new Gn(function(e) {
                                if (e instanceof Ln) R.push(e);
                            }));
                            U.push(e);
                        }, []);
                        U.push(B);
                        var h = Pe(p, U).optimize(c);
                        w.inlined = L;
                        h = je(x, k, h);
                        if (Y || le(h, p) === h) {
                            R.forEach(function(e) {
                                e.scope = a === w ? w.parent_scope : a.scope;
                                e.reference();
                                var n = e.definition();
                                if (Y) n.replaced++;
                                n.single_use = false;
                            });
                            return h;
                        } else if (!h.has_side_effects(c)) {
                            p.drop_side_effect_free = function(e, n) {
                                var t = this;
                                var r = t.args.slice();
                                r.unshift(t.expression);
                                return Pe(t, r).drop_side_effect_free(e, n);
                            };
                        }
                    }
                    var $, V, z, C;
                    if (Y && re()) {
                        w._squeezed = true;
                        if (a !== w) w.parent_scope = a.scope;
                        var h = Pe(p, se()).optimize(c);
                        return je(x, k, h);
                    }
                }
                if (c.option("side_effects") && I && _n(w.body, ue) && (w === a ? we(w, c) : !T && !A && !w.rest) && !(At(w) && w.value) && Ee(w, ve(c))) {
                    return Pe(p, G()).optimize(c);
                }
            }
            if (c.option("drop_console")) {
                if (a instanceof $n) {
                    var M = a.expression;
                    while (M.expression) {
                        M = M.expression;
                    }
                    if (Ne(M) && M.name == "console") {
                        return Fe(Qr, p).optimize(c);
                    }
                }
            }
            if (c.option("negate_iife") && x instanceof wn && ge(k)) {
                return p.negate(c, true);
            }
            return de(c, p);
            function W(e) {
                return Fe(Cn, e, {
                    expression: Fe(Hn, e, {
                        elements: []
                    }),
                    property: Fe(Wn, e, {
                        value: 0
                    })
                });
            }
            function G(e) {
                var n = p.args.slice();
                var t = T > 1 || A || w.rest;
                if (t || D) n = [ Fe(Hn, p, {
                    elements: n
                }) ];
                if (t) {
                    var o = new ii(function(r, e) {
                        if (r instanceof Dn) return Fe(Dn, r, {
                            name: r.name.transform(o) || W(r),
                            value: r.value
                        });
                        if (r instanceof kr) {
                            var t = [];
                            r.elements.forEach(function(e, n) {
                                e = e.transform(o);
                                if (e) t[n] = e;
                            });
                            be(r, t);
                            return Fe(kr, r, {
                                elements: t
                            });
                        }
                        if (r instanceof Sr) {
                            var i = [], a = [];
                            r.properties.forEach(function(e) {
                                var n = e.key;
                                var t = e.value.transform(o);
                                if (t) {
                                    if (a.length) {
                                        if (!(n instanceof bn)) n = fe(n, e);
                                        a.push(n);
                                        n = Pe(r, a);
                                        a = [];
                                    }
                                    i.push(Fe(Er, e, {
                                        key: n,
                                        value: t
                                    }));
                                } else if (n instanceof bn) {
                                    a.push(n);
                                }
                            });
                            if (a.length) i.push(Fe(Er, r, {
                                key: Pe(r, a),
                                value: W(r)
                            }));
                            return Fe(Sr, r, {
                                properties: i
                            });
                        }
                        if (r instanceof Bn) return null;
                    });
                    var r = [];
                    w.argnames.forEach(function(e, n) {
                        e = e.transform(o);
                        if (e) r[n] = e;
                    });
                    var i = w.rest && w.rest.transform(o);
                    if (i) r.length = w.argnames.length;
                    be(w, r);
                    n[0] = Fe(In, p, {
                        operator: "=",
                        left: Fe(kr, w, {
                            elements: r,
                            rest: i
                        }),
                        right: n[0]
                    });
                } else w.argnames.forEach(function(e) {
                    if (e instanceof Dn) n.push(e.value);
                });
                n.push(e || Fe(Qr, p));
                return n;
            }
            function J() {
                return p.call_only ? Fe(Wn, p, {
                    value: 0
                }) : Fe(Qr, p);
            }
            function X(e) {
                if (!e) return J();
                if (e instanceof Sn) return e.value || J();
                if (e instanceof wn) {
                    return p.call_only ? e.body : Fe(Pn, e, {
                        operator: "void",
                        expression: e.body
                    });
                }
            }
            function K(e) {
                var n = w.body.length;
                if (n < 2) {
                    e = X(e);
                    if (e) return e;
                }
                if (c.option("inline") < 3) return false;
                e = null;
                for (var t = 0; t < n; t++) {
                    var r = w.body[t];
                    if (r instanceof dr) {
                        if (O) {
                            if (!e) continue;
                            if (!(e instanceof wn)) return false;
                            if (!ce(r)) e = null;
                        } else if (!ce(r)) {
                            if (e && !(e instanceof wn)) return false;
                            e = null;
                            O = true;
                        }
                    } else if (r instanceof Nt || r instanceof Ht || r instanceof yn) {
                        continue;
                    } else if (e) {
                        return false;
                    } else {
                        e = r;
                    }
                }
                return X(e);
            }
            function Q(e) {
                for (var n = w.argnames.length; --n >= 0; ) {
                    if (w.argnames[n].definition() === e) return n;
                }
            }
            function Z() {
                if (T || A || D || O || w.rest) return;
                if (c.option("inline") < 2 && w.argnames.length) return;
                if (!w.variables.all(function(e) {
                    return e.references.length - e.replaced < 2 && e.orig[0] instanceof Bn;
                })) return;
                var n = c.find_parent(kn);
                var i = false;
                var a = ve(c, n);
                var o;
                var s = [];
                var f = false;
                var u = new Gn(function(e, n) {
                    if (i) return true;
                    if (e instanceof jn && He[e.operator] || e instanceof Nn) {
                        s = null;
                        return;
                    }
                    if (e instanceof kn) return i = true;
                    if (a && e instanceof $r && a[e.name]) return i = true;
                    if (e instanceof Ln) {
                        var t = e.definition();
                        if (w.variables.get(e.name) !== t) {
                            s = null;
                            return;
                        }
                        if (t.init instanceof jt) return i = true;
                        if (di(e, u.parent())) return i = true;
                        var r = Q(t);
                        if (!(o < r)) o = r;
                        if (!s) return;
                        if (f) {
                            s = null;
                        } else {
                            s.push(w.argnames[r]);
                        }
                        return;
                    }
                    if (f) return;
                    if (e instanceof In && e.left instanceof $n) {
                        e.left.expression.walk(u);
                        if (e.left instanceof Cn) e.left.property.walk(u);
                        e.right.walk(u);
                        f = true;
                        return true;
                    }
                    if (e.has_side_effects(c)) {
                        n();
                        f = true;
                        return true;
                    }
                });
                d.walk(u);
                if (i) return;
                var e = p.args.length;
                if (s && w.argnames.length >= e) {
                    e = w.argnames.length;
                    while (e-- > o && w.argnames[e] === s.pop());
                    e++;
                }
                return e <= o || _n(p.args.slice(o, e), f && !s ? function(e) {
                    return e.is_constant_expression(n);
                } : function(e) {
                    return !e.has_side_effects(c);
                });
            }
            function ee(e, n) {
                return e.has(n) || me[n] || C.var_names().has(n);
            }
            function ne(n, t) {
                var r = false;
                w.each_argname(function(e) {
                    if (r) return;
                    if (e.unused) return;
                    if (!t || ee(n, e.name)) return r = true;
                    $.set(e.name, true);
                    if (z) z.push(e.definition());
                });
                return !r;
            }
            function te(n, e) {
                for (var t = 0; t < w.body.length; t++) {
                    var r = w.body[t];
                    if (r instanceof jt) {
                        var i = r.name;
                        if (!e) return false;
                        if ($.has(i.name)) return false;
                        if (ee(n, i.name)) return false;
                        if (!_n(r.enclosed, function(e) {
                            return e.scope === C || e.scope === r || !n.has(e.name);
                        })) return false;
                        if (z) z.push(i.definition());
                        continue;
                    }
                    if (!(r instanceof dr)) continue;
                    if (!e) return false;
                    for (var a = r.definitions.length; --a >= 0; ) {
                        var i = r.definitions[a].name;
                        if (ee(n, i.name)) return false;
                        if (z) z.push(i.definition());
                    }
                }
                return true;
            }
            function re() {
                var n = new gn();
                var e = 0, t;
                C = k;
                do {
                    if (C.variables) C.variables.each(function(e) {
                        n.set(e.name, true);
                    });
                    t = C;
                    C = c.parent(e++);
                    if (C instanceof Vt) {
                        if (!C.static) return false;
                    } else if (C instanceof vt) {
                        z = [];
                    } else if (C instanceof gt) {
                        if (C.init === t) continue;
                        z = [];
                    } else if (C instanceof bt) {
                        if (C.init === t) continue;
                        if (C.object === t) continue;
                        z = [];
                    }
                } while (!(C instanceof kn));
                V = C.body.indexOf(t) + 1;
                if (!V) return false;
                if (!Ee(w, ve(c, C))) return false;
                var r = (a !== w || w.parent_scope.resolve() === C) && !C.pinned();
                if (C instanceof kt) {
                    if (c.toplevel.vars) {
                        n.set("arguments", true);
                    } else {
                        r = false;
                    }
                }
                $ = new gn();
                var i = c.option("inline");
                if (!ne(n, i >= 2 && r)) return false;
                if (!te(n, i >= 3 && r)) return false;
                return !z || z.length == 0 || !an(w, z);
            }
            function F(e, n, t, r) {
                var i = t.definition();
                if (!C.var_names().has(t.name)) {
                    C.var_names().set(t.name, true);
                    e.push(Fe(An, t, {
                        name: t,
                        value: null
                    }));
                }
                C.variables.set(t.name, i);
                C.enclosed.push(i);
                if (!r) return;
                var a = Fe(Ln, t);
                i.assignments++;
                i.references.push(a);
                n.push(Fe(In, p, {
                    operator: "=",
                    left: a,
                    right: r
                }));
            }
            function ie(e, n) {
                var t = w.argnames.length;
                for (var r = p.args.length; --r >= t; ) {
                    n.push(p.args[r]);
                }
                var i = [];
                for (r = t; --r >= 0; ) {
                    var a = w.argnames[r];
                    var o;
                    if (a instanceof Dn) {
                        i.push(a);
                        o = a.name;
                    } else {
                        o = a;
                    }
                    var s = p.args[r];
                    if (o.unused || C.var_names().has(o.name)) {
                        if (s) n.push(s);
                    } else {
                        var f = Fe(Pr, o);
                        var u = o.definition();
                        u.orig.push(f);
                        u.eliminated++;
                        if (o.unused !== undefined) {
                            F(e, n, f);
                            if (s) n.push(s);
                        } else {
                            if (!s && a === o && (z || o.name == "arguments" && !At(w) && At(C))) {
                                s = Fe(Qr, p);
                            }
                            F(e, n, f, s);
                        }
                    }
                }
                e.reverse();
                n.reverse();
                for (r = i.length; --r >= 0; ) {
                    var c = i[r];
                    if (c.name.unused !== undefined) {
                        n.push(c.value);
                    } else {
                        var l = Fe(Ln, c.name);
                        c.name.definition().references.push(l);
                        n.push(Fe(In, c, {
                            operator: "=",
                            left: l,
                            right: c.value
                        }));
                    }
                }
            }
            function ae(i, a) {
                a.push(Fe(In, p, {
                    operator: "=",
                    left: Fe(kr, p, {
                        elements: w.argnames.map(function(e) {
                            if (e.unused) return Fe(Zr, e);
                            return e.convert_symbol(Ln, n);
                        }),
                        rest: w.rest && w.rest.convert_symbol(Ln, n)
                    }),
                    right: Fe(Hn, p, {
                        elements: p.args.slice()
                    })
                }));
                function n(e, n) {
                    if (n.unused) return W(n);
                    var t = n.definition();
                    t.assignments++;
                    t.references.push(e);
                    var r = Fe(Pr, n);
                    t.orig.push(r);
                    t.eliminated++;
                    F(i, a, r);
                }
            }
            function oe(r, e) {
                var t = [ V, 0 ];
                var a = [], i = [], o = [], s = [], f = [];
                w.body.filter(z ? function(e) {
                    if (!(e instanceof jt)) return true;
                    var n = Fe(Pr, cn(e.name));
                    var t = n.definition();
                    t.fixed = false;
                    t.orig.push(n);
                    t.eliminated++;
                    F(r, i, n, ye(e, true));
                    return false;
                } : function(e) {
                    if (!(e instanceof jt)) return true;
                    var n = e.name.definition();
                    C.functions.set(n.name, n);
                    C.variables.set(n.name, n);
                    C.enclosed.push(n);
                    C.var_names().set(n.name, true);
                    t.push(e);
                    return false;
                }).forEach(function(e) {
                    if (!(e instanceof dr)) {
                        if (e instanceof wn) f.push(e.body);
                        return;
                    }
                    for (var n = 0; n < e.definitions.length; n++) {
                        var t = e.definitions[n];
                        var r = cn(t.name);
                        var i = t.value;
                        if (i && f.length > 0) {
                            f.push(i);
                            i = Pe(t, f);
                            f = [];
                        }
                        F(a, o, r, i);
                        if (!z) continue;
                        if ($.has(r.name)) continue;
                        if (r.definition().orig.length == 1 && w.functions.has(r.name)) continue;
                        s.push(dn(c, r));
                    }
                });
                [].push.apply(r, a);
                [].push.apply(e, s);
                [].push.apply(e, i);
                [].push.apply(e, o);
                return t;
            }
            function se() {
                var e = [];
                var n = [];
                if (T > 1 || A || D || w.rest) {
                    ae(e, n);
                } else {
                    ie(e, n);
                }
                var t = oe(e, n);
                n.push(d);
                if (e.length) t.push(Fe(dr, w, {
                    definitions: e
                }));
                [].splice.apply(C.body, t);
                w.enclosed.forEach(function(e) {
                    if (C.var_names().has(e.name)) return;
                    C.enclosed.push(e);
                    C.var_names().set(e.name, true);
                });
                return n;
            }
        });
        e(gr, function(e, n) {
            if (n.option("unsafe")) {
                var t = e.expression;
                if (Ne(t)) switch (t.name) {
                  case "Array":
                  case "Error":
                  case "Function":
                  case "Object":
                  case "RegExp":
                    return Fe(qn, e).transform(n);
                }
            }
            if (n.option("sequences")) {
                var r = he(e, n);
                if (r !== e) return r.optimize(n);
            }
            if (n.option("unused")) ke(e, n);
            return e;
        });
        function se(t, r, e, n) {
            if (!(n instanceof jn)) return;
            if (!(n.operator == "&&" || n.operator == "||")) return;
            if (!(n.right instanceof In)) return;
            if (n.right.operator != "=") return;
            if (!(n.right.left instanceof Ln)) return;
            if (n.right.left.definition() !== r) return;
            if (e.has_side_effects(t)) return;
            if (!i(n.left)) return;
            if (!i(n.right.right)) return;
            r.replaced++;
            return n.operator == "&&" ? Fe(Nn, n, {
                condition: n.left,
                consequent: n.right.right,
                alternative: e
            }) : Fe(Nn, n, {
                condition: n.left,
                consequent: e,
                alternative: n.right.right
            });
            function i(e) {
                if (e.has_side_effects(t)) return;
                var n = false;
                e.walk(new Gn(function(e) {
                    if (n) return true;
                    if (e instanceof Ln && e.definition() === r) return n = true;
                }));
                return !n;
            }
        }
        e(On, function(e, a) {
            var o = n();
            var s = o.length - 1;
            r();
            t();
            if (s == 0) {
                e = je(a.parent(), a.self(), o[0]);
                if (!(e instanceof On)) e = e.optimize(a);
                return e;
            }
            e.expressions = o;
            return e;
            function n() {
                if (!a.option("side_effects")) return e.expressions;
                var t = [];
                var r = at(a);
                var i = e.expressions.length - 1;
                e.expressions.forEach(function(e, n) {
                    if (n < i) e = e.drop_side_effect_free(a, r);
                    if (e) {
                        k(t, e);
                        r = false;
                    }
                });
                return t;
            }
            function t() {
                if (!a.option("side_effects")) return;
                while (s > 0 && Ie(o[s], a)) s--;
                if (s < o.length - 1) {
                    o[s] = Fe(Pn, e, {
                        operator: "void",
                        expression: o[s]
                    });
                    o.length = s + 1;
                }
            }
            function f(e) {
                return e instanceof In && e.operator == "=" && e.left instanceof Ln && e.left.definition();
            }
            function r() {
                for (var e = 1; e < s; e++) {
                    var n = o[e - 1];
                    var t = f(n);
                    if (!t) continue;
                    var r = o[e];
                    if (a.option("conditionals")) {
                        var i = se(a, t, n.right, r);
                        if (i) {
                            n.right = i;
                            o.splice(e--, 1);
                            s--;
                            continue;
                        }
                    }
                    if (a.option("dead_code") && f(r) === t && r.right.is_constant_expression(t.scope.resolve())) {
                        o[--e] = n.right;
                    }
                }
            }
        });
        e(yr, function(e, n) {
            if (n.option("sequences")) {
                var t = he(e, n);
                if (t !== e) return t.optimize(n);
            }
            return de(n, e);
        });
        var Te = mn("+ -");
        var Ae = mn("* / %");
        e(Pn, function(e, n) {
            var t = e.operator;
            var r = e.expression;
            if (n.option("sequences") && u()) {
                var i = he(e, n);
                if (i !== e) return i.optimize(n);
            }
            switch (t) {
              case "+":
                if (!n.option("evaluate")) break;
                if (!r.is_number(n, true)) break;
                var a = n.parent();
                if (a instanceof Pn && a.operator == "delete") break;
                return r;

              case "-":
                if (r instanceof ei) r = r.transform(n);
                if (r instanceof Wn || r instanceof ei) return e;
                break;

              case "!":
                if (!n.option("booleans")) break;
                if (r.is_truthy()) return Pe(e, [ r, Fe(ti, e) ]).optimize(n);
                if (n.in_boolean_context()) {
                    if (r instanceof Pn && r.operator == "!") return r.expression;
                    if (r instanceof jn) {
                        var o = at(n);
                        e = (o ? A : le)(e, r.negate(n, o));
                    }
                }
                break;

              case "delete":
                if (!n.option("evaluate")) break;
                if (f(r)) break;
                return Pe(e, [ r, Fe(ri, e) ]).optimize(n);

              case "typeof":
                if (!n.option("booleans")) break;
                if (!n.in_boolean_context()) break;
                bn.warn("Boolean expression always true [{start}]", e);
                var s = [ Fe(ri, e) ];
                if (!(r instanceof Ln && Ce(r, n))) s.unshift(r);
                return Pe(e, s).optimize(n);

              case "void":
                if (!n.option("side_effects")) break;
                r = r.drop_side_effect_free(n);
                if (!r) return Fe(Qr, e).optimize(n);
                e.expression = r;
                return e;
            }
            if (n.option("evaluate") && r instanceof jn && Te[t] && Ae[r.operator] && (r.left.is_constant() || !r.right.has_side_effects(n))) {
                return Fe(jn, e, {
                    operator: r.operator,
                    left: Fe(Pn, r.left, {
                        operator: t,
                        expression: r.left
                    }),
                    right: r.right
                });
            }
            return de(n, e);
            function f(e) {
                return e instanceof ei || e instanceof Kr || e instanceof Ur || e instanceof $n || e instanceof Ln || e instanceof Qr;
            }
            function u() {
                switch (t) {
                  case "delete":
                    return !f(r.tail_node());

                  case "typeof":
                    return !Ne(r.tail_node());

                  default:
                    return true;
                }
            }
        });
        e(wr, function(e, n) {
            if (!n.option("awaits")) return e;
            if (n.option("sequences")) {
                var t = he(e, n);
                if (t !== e) return t.optimize(n);
            }
            if (n.option("side_effects")) {
                var r = e.expression;
                if (r instanceof wr) return r.optimize(n);
                if (r instanceof Pn && r.expression instanceof wr) return r.optimize(n);
                for (var i = 0, a = e, o; o = n.parent(i++); a = o) {
                    if (At(o)) {
                        if (o.value === a) return r.optimize(n);
                    } else if (o instanceof Sn) {
                        var s = true;
                        do {
                            a = o;
                            o = n.parent(i++);
                            if (o instanceof sr && (o.bfinally || o.bcatch) !== a) {
                                s = false;
                                break;
                            }
                        } while (o && !(o instanceof kn));
                        if (s) return r.optimize(n);
                    } else if (o instanceof On) {
                        if (o.tail_node() === a) continue;
                    }
                    break;
                }
            }
            return e;
        });
        e(xr, function(e, n) {
            if (!n.option("yields")) return e;
            if (n.option("sequences")) {
                var t = he(e, n);
                if (t !== e) return t.optimize(n);
            }
            var r = e.expression;
            if (e.nested && r.TYPE == "Call") {
                var i = r.clone().optimize(n);
                if (i.TYPE != "Call") return i;
            }
            return e;
        });
        jn.DEFMETHOD("lift_sequences", function(e) {
            if (this.left instanceof $n) {
                if (!(this.left.expression instanceof On)) return this;
                var n = this.left.expression.expressions.slice();
                var t = this.clone();
                t.left = t.left.clone();
                t.left.expression = n.pop();
                n.push(t);
                return Pe(this, n);
            }
            if (this.left instanceof On) {
                var n = this.left.expressions.slice();
                var t = this.clone();
                t.left = n.pop();
                n.push(t);
                return Pe(this, n);
            }
            if (this.right instanceof On) {
                if (this.left.has_side_effects(e)) return this;
                var r = this.operator == "=" && this.left instanceof Ln;
                var n = this.right.expressions;
                var i = n.length - 1;
                for (var a = 0; a < i; a++) {
                    if (!r && n[a].has_side_effects(e)) break;
                }
                if (a == i) {
                    n = n.slice();
                    var t = this.clone();
                    t.right = n.pop();
                    n.push(t);
                    return Pe(this, n);
                }
                if (a > 0) {
                    var t = this.clone();
                    t.right = Pe(this.right, n.slice(a));
                    n = n.slice(0, a);
                    n.push(t);
                    return Pe(this, n);
                }
            }
            return this;
        });
        var De = mn("indexOf lastIndexOf");
        var qe = mn("== === != !== * & | ^");
        function F(e, n) {
            if (e instanceof In) return !n && e.operator == "=" && F(e.right);
            if (e instanceof gr) return !n;
            if (e instanceof On) return F(e.tail_node(), n);
            if (e instanceof Ln) return !n && F(e.fixed_value());
            return e instanceof Hn || e instanceof Rt || e instanceof En || e instanceof Rn;
        }
        function Xe(e, n, t) {
            switch (e) {
              case "in":
                return F(n) || t && t.option("unsafe_comps");

              case "instanceof":
                if (n instanceof Ln) n = n.fixed_value();
                return M(n) || t && t.option("unsafe_comps");

              default:
                return true;
            }
        }
        function x(e, n) {
            if (n.is_constant()) return true;
            if (n instanceof In) return n.operator != "=" || x(e, n.right);
            if (n instanceof jn) {
                return !He[n.operator] || x(e, n.left) && x(e, n.right);
            }
            if (n instanceof qn) return Dt(n.expression);
            if (n instanceof Nn) {
                return x(e, n.consequent) && x(e, n.alternative);
            }
            if (n instanceof On) return x(e, n.tail_node());
            if (n instanceof Ln) {
                var t = n.fixed_value();
                return t && x(e, t);
            }
            if (n instanceof Vr) return !n.tag || nn(e, n.tag);
            if (n instanceof Fn) return true;
        }
        function Oe(e, n) {
            if (e instanceof In) return Ue(e.left, n) ? e : e.left;
            if (e instanceof On) return Oe(e.tail_node(), n);
            if (e instanceof Pn && fi[e.operator]) {
                return Ue(e.expression, n) ? e : e.expression;
            }
            return e;
        }
        function Ke(e, n) {
            if (n instanceof zn) return Ke(e, n.expression);
            if (n instanceof Cn) {
                return Ke(e, n.expression) && Ke(e, n.property);
            }
            if (n instanceof $r) return true;
            return !n.has_side_effects(e);
        }
        function Qe(e, n) {
            var t = e.right.tail_node();
            if (t !== e.right) {
                var r = e.right.expressions.slice(0, -1);
                r.push(t.left);
                t = t.clone();
                t.left = Pe(e.right, r);
                e.right = t;
            }
            e.left = Fe(jn, e, {
                operator: e.operator,
                left: e.left,
                right: t.left,
                start: e.left.start,
                end: t.left.end
            });
            e.right = t.right;
            if (n) {
                e.left = e.left.transform(n);
            } else if (e.operator == t.left.operator) {
                Qe(e.left);
            }
        }
        e(jn, function(r, i) {
            if (qe[r.operator] && r.right.is_constant() && !r.left.is_constant() && !(r.left instanceof jn && ui[r.left.operator] >= ui[r.operator])) {
                C();
            }
            if (i.option("sequences")) {
                var e = r.lift_sequences(i);
                if (e !== r) return e.optimize(i);
            }
            if (i.option("assignments") && He[r.operator]) {
                var n = Oe(r.left, i);
                var t = r.right;
                if (n instanceof Ln && t instanceof In && t.operator == "=" && n.equals(t.left)) {
                    n = n.clone();
                    var a = Fe(In, r, {
                        operator: "=",
                        left: n,
                        right: Fe(jn, r, {
                            operator: r.operator,
                            left: r.left,
                            right: t.right
                        })
                    });
                    if (n.fixed) {
                        n.fixed = function() {
                            return a.right;
                        };
                        n.fixed.assigns = [ a ];
                    }
                    var o = n.definition();
                    o.references.push(n);
                    o.replaced++;
                    return a.optimize(i);
                }
            }
            if (i.option("comparisons")) switch (r.operator) {
              case "===":
              case "!==":
                if (Ie(r.left, i) && r.right.is_defined(i)) {
                    bn.warn("Expression always defined [{start}]", r);
                    return Pe(r, [ r.right, Fe(r.operator == "===" ? ti : ri, r) ]).optimize(i);
                }
                var s = true;
                if (r.left.is_string(i) && r.right.is_string(i) || r.left.is_number(i) && r.right.is_number(i) || r.left.is_boolean(i) && r.right.is_boolean(i) || Ke(i, r.left) && r.left.equals(r.right)) {
                    r.operator = r.operator.slice(0, 2);
                }

              case "==":
              case "!=":
                if (!s && Ie(r.left, i)) {
                    r.left = Fe(Xr, r.left);
                } else if (i.option("typeofs") && r.left instanceof Vn && r.left.value == "undefined" && r.right instanceof Pn && r.right.operator == "typeof") {
                    var f = r.right.expression;
                    if (f instanceof Ln ? f.is_declared(i) : !(f instanceof $n && i.option("ie"))) {
                        r.right = f;
                        r.left = Fe(Qr, r.left).optimize(i);
                        if (r.operator.length == 2) r.operator += "=";
                    }
                } else if (r.left instanceof Ln && r.right instanceof Ln && r.left.definition() === r.right.definition() && F(r.left)) {
                    return Fe(r.operator[0] == "=" ? ri : ti, r).optimize(i);
                }
                break;

              case "&&":
              case "||":
                var u = r.left;
                if (!(u instanceof jn)) break;
                if (u.operator != (r.operator == "&&" ? "!==" : "===")) break;
                if (!(r.right instanceof jn)) break;
                if (u.operator != r.right.operator) break;
                if (Ie(u.left, i) && r.right.left instanceof Xr || u.left instanceof Xr && Ie(r.right.left, i)) {
                    var f = u.right;
                    if (f instanceof In && f.operator == "=") f = f.left;
                    if (f.has_side_effects(i)) break;
                    if (!f.equals(r.right.right)) break;
                    u.operator = u.operator.slice(0, -1);
                    u.left = Fe(Xr, r);
                    return u;
                }
                break;
            }
            var c = false;
            var l = i.parent();
            if (i.option("booleans")) {
                var n = Oe(r.left, i);
                if (He[r.operator] && !n.has_side_effects(i)) {
                    if (n.equals(r.right)) {
                        return je(l, i.self(), r.left).optimize(i);
                    }
                    Q(i, n);
                }
                c = i.in_boolean_context();
            }
            if (c) switch (r.operator) {
              case "+":
                var p = r.left.evaluate(i, true);
                if (p && typeof p == "string" || (p = r.right.evaluate(i, true)) && typeof p == "string") {
                    bn.warn("+ in boolean context always true [{start}]", r);
                    var d = [];
                    if (r.left.evaluate(i) instanceof bn) d.push(r.left);
                    if (r.right.evaluate(i) instanceof bn) d.push(r.right);
                    if (d.length < 2) {
                        d.push(Fe(ri, r));
                        return Pe(r, d).optimize(i);
                    }
                    r.truthy = true;
                }
                break;

              case "==":
                if (r.left instanceof Vn && r.left.value == "" && r.right.is_string(i)) {
                    return Fe(Pn, r, {
                        operator: "!",
                        expression: r.right
                    }).optimize(i);
                }
                break;

              case "!=":
                if (r.left instanceof Vn && r.left.value == "" && r.right.is_string(i)) {
                    return r.right.optimize(i);
                }
                break;
            }
            if (i.option("comparisons") && r.is_boolean(i)) {
                if (l.TYPE != "Binary") {
                    var h = Fe(Pn, r, {
                        operator: "!",
                        expression: r.negate(i)
                    });
                    if (pe(i, r, h) === h) return h;
                }
                switch (r.operator) {
                  case ">":
                    C("<");
                    break;

                  case ">=":
                    C("<=");
                    break;
                }
            }
            if (i.option("conditionals") && He[r.operator]) {
                if (r.left instanceof jn && r.operator == r.left.operator) {
                    var v = Fe(jn, r, {
                        operator: r.operator,
                        left: r.left.right,
                        right: r.right
                    });
                    var m = v.transform(i);
                    if (v !== m) {
                        r.left = r.left.left;
                        r.right = m;
                    }
                }
                var _ = r.right.tail_node();
                if (_ instanceof jn && r.operator == _.operator) Qe(r, i);
            }
            if (i.option("strings") && r.operator == "+") {
                if (r.right instanceof Vn && r.right.value == "" && r.left.is_string(i)) {
                    return r.left.optimize(i);
                }
                if (r.left instanceof Vn && r.left.value == "" && r.right.is_string(i)) {
                    return r.right.optimize(i);
                }
                if (r.left instanceof jn && r.left.operator == "+" && r.left.left instanceof Vn && r.left.left.value == "" && r.right.is_string(i) && (r.left.right.is_constant() || !r.right.has_side_effects(i))) {
                    r.left = r.left.right;
                    return r.optimize(i);
                }
                var _ = r.right.tail_node();
                if (_ instanceof jn && r.operator == _.operator && (r.left.is_string(i) && _.is_string(i) || _.left.is_string(i) && (r.left.is_constant() || !_.right.has_side_effects(i)))) {
                    Qe(r, i);
                }
            }
            if (i.option("evaluate")) {
                var g = true;
                switch (r.operator) {
                  case "&&":
                    var b = j(i, r.left);
                    if (!b) {
                        bn.warn("Condition left of && always false [{start}]", r);
                        return je(l, i.self(), r.left).optimize(i);
                    } else if (!(b instanceof bn)) {
                        bn.warn("Condition left of && always true [{start}]", r);
                        return Pe(r, [ r.left, r.right ]).optimize(i);
                    }
                    if (!r.right.evaluate(i, true)) {
                        if (c && !(r.right.evaluate(i) instanceof bn)) {
                            bn.warn("Boolean && always false [{start}]", r);
                            return Pe(r, [ r.left, Fe(ti, r) ]).optimize(i);
                        } else r.falsy = true;
                    } else if ((c || l.operator == "&&" && l.left === i.self()) && !(r.right.evaluate(i) instanceof bn)) {
                        bn.warn("Dropping side-effect-free && [{start}]", r);
                        return r.left.optimize(i);
                    }
                    if (r.left.operator == "||") {
                        var y = j(i, r.left.right);
                        if (!y) return Fe(Nn, r, {
                            condition: r.left.left,
                            consequent: r.right,
                            alternative: r.left.right
                        }).optimize(i);
                    }
                    break;

                  case "??":
                    var w = true;

                  case "||":
                    var b = j(i, r.left, w);
                    if (w ? b == null : !b) {
                        bn.warn("Condition left of {operator} always {value} [{start}]", {
                            operator: r.operator,
                            value: w ? "nullish" : "false",
                            start: r.start
                        });
                        return Pe(r, [ r.left, r.right ]).optimize(i);
                    } else if (!(b instanceof bn)) {
                        bn.warn("Condition left of {operator} always {value} [{start}]", {
                            operator: r.operator,
                            value: w ? "defined" : "true",
                            start: r.start
                        });
                        return je(l, i.self(), r.left).optimize(i);
                    }
                    var x;
                    if (!w && (x = r.right.evaluate(i, true)) && !(x instanceof bn)) {
                        if (c && !(r.right.evaluate(i) instanceof bn)) {
                            bn.warn("Boolean || always true [{start}]", r);
                            return Pe(r, [ r.left, Fe(ri, r) ]).optimize(i);
                        } else r.truthy = true;
                    } else if ((c || l.operator == "||" && l.left === i.self()) && !r.right.evaluate(i)) {
                        bn.warn("Dropping side-effect-free {operator} [{start}]", r);
                        return r.left.optimize(i);
                    }
                    if (!w && r.left.operator == "&&") {
                        var y = j(i, r.left.right);
                        if (y && !(y instanceof bn)) return Fe(Nn, r, {
                            condition: r.left.left,
                            consequent: r.left.right,
                            alternative: r.right
                        }).optimize(i);
                    }
                    break;

                  case "+":
                    if (r.left instanceof Un && r.right instanceof jn && r.right.operator == "+" && r.right.left instanceof Un && r.right.is_string(i)) {
                        r = Fe(jn, r, {
                            operator: "+",
                            left: Fe(Vn, r.left, {
                                value: "" + r.left.value + r.right.left.value,
                                start: r.left.start,
                                end: r.right.left.end
                            }),
                            right: r.right.right
                        });
                    }
                    if (r.right instanceof Un && r.left instanceof jn && r.left.operator == "+" && r.left.right instanceof Un && r.left.is_string(i)) {
                        r = Fe(jn, r, {
                            operator: "+",
                            left: r.left.left,
                            right: Fe(Vn, r.right, {
                                value: "" + r.left.right.value + r.right.value,
                                start: r.left.right.start,
                                end: r.right.end
                            })
                        });
                    }
                    if (r.right instanceof Pn && r.right.operator == "-" && r.left.is_number(i)) {
                        r = Fe(jn, r, {
                            operator: "-",
                            left: r.left,
                            right: r.right.expression
                        });
                        break;
                    }
                    if (r.left instanceof Pn && r.left.operator == "-" && z() && r.right.is_number(i)) {
                        r = Fe(jn, r, {
                            operator: "-",
                            left: r.right,
                            right: r.left.expression
                        });
                        break;
                    }
                    if (i.option("unsafe_math") && r.left instanceof jn && ui[r.left.operator] == ui[r.operator] && r.right.is_constant() && (r.right.is_boolean(i) || r.right.is_number(i)) && r.left.is_number(i) && !r.left.right.is_constant() && (r.left.left.is_boolean(i) || r.left.left.is_number(i))) {
                        r = Fe(jn, r, {
                            operator: r.left.operator,
                            left: Fe(jn, r, {
                                operator: r.operator,
                                left: r.right,
                                right: r.left.left
                            }),
                            right: r.left.right
                        });
                        break;
                    }

                  case "-":
                    if (r.right instanceof Pn && r.right.operator == "-" && r.left.is_number(i) && r.right.expression.is_number(i)) {
                        r = Fe(jn, r, {
                            operator: "+",
                            left: r.left,
                            right: r.right.expression
                        });
                        break;
                    }

                  case "*":
                  case "/":
                    g = i.option("unsafe_math");
                    if (r.operator != "+") [ "left", "right" ].forEach(function(e) {
                        var n = r[e];
                        if (n instanceof Pn && n.operator == "+") {
                            var t = n.expression;
                            if (t.is_boolean(i) || t.is_number(i) || t.is_string(i)) {
                                r[e] = t;
                            }
                        }
                    });

                  case "&":
                  case "|":
                  case "^":
                    if (r.operator != "-" && r.operator != "/" && (r.left.is_boolean(i) || r.left.is_number(i)) && (r.right.is_boolean(i) || r.right.is_number(i)) && z() && !(r.left instanceof jn && r.left.operator != r.operator && ui[r.left.operator] >= ui[r.operator])) {
                        r = pe(i, r, Fe(jn, r, {
                            operator: r.operator,
                            left: r.right,
                            right: r.left
                        }), r.right instanceof Un && !(r.left instanceof Un));
                    }
                    if (!g || !r.is_number(i)) break;
                    if (r.right instanceof jn && r.right.operator != "%" && ui[r.right.operator] == ui[r.operator] && r.right.is_number(i) && (r.operator != "+" || r.right.left.is_boolean(i) || r.right.left.is_number(i)) && (r.operator != "-" || !r.left.is_negative_zero()) && (r.right.left.is_constant_expression() || !r.right.right.has_side_effects(i)) && !A(r.right.right)) {
                        r = Fe(jn, r, {
                            operator: D(r.operator, r.right.operator),
                            left: Fe(jn, r.left, {
                                operator: r.operator,
                                left: r.left,
                                right: r.right.left,
                                start: r.left.start,
                                end: r.right.left.end
                            }),
                            right: r.right.right
                        });
                        if (r.operator == "+" && !r.right.is_boolean(i) && !r.right.is_number(i)) {
                            r.right = Fe(Pn, r.right, {
                                operator: "+",
                                expression: r.right
                            });
                        }
                    }
                    if (r.right instanceof Un && r.left instanceof jn && r.left.operator != "%" && ui[r.left.operator] == ui[r.operator] && r.left.is_number(i)) {
                        if (r.left.left instanceof Un) {
                            var n = q(r.operator, r.left.left, r.right, {
                                start: r.left.left.start,
                                end: r.right.end
                            });
                            r = q(r.left.operator, de(i, n), r.left.right, r);
                        } else if (r.left.right instanceof Un) {
                            var k = D(r.left.operator, r.operator);
                            var _ = de(i, q(k, r.left.right, r.right, r.left));
                            if (_.is_constant() && !(r.left.operator == "-" && r.right.value != 0 && +_.value == 0 && r.left.left.is_negative_zero())) {
                                r = q(r.left.operator, r.left.left, _, r);
                            }
                        }
                    }
                    break;

                  case "instanceof":
                    if (M(r.right)) return Pe(r, [ r, Fe(ti, r) ]).optimize(i);
                    break;
                }
                if (!(l instanceof Pn && l.operator == "delete")) {
                    if (r.left instanceof Wn && !r.right.is_constant()) switch (r.operator) {
                      case "+":
                        if (r.left.value == 0) {
                            if (r.right.is_boolean(i)) return Fe(Pn, r, {
                                operator: "+",
                                expression: r.right
                            }).optimize(i);
                            if (r.right.is_number(i) && !r.right.is_negative_zero()) return r.right;
                        }
                        break;

                      case "*":
                        if (r.left.value == 1) return Fe(Pn, r, {
                            operator: "+",
                            expression: r.right
                        }).optimize(i);
                        break;
                    }
                    if (r.right instanceof Wn && !r.left.is_constant()) switch (r.operator) {
                      case "+":
                        if (r.right.value == 0) {
                            if (r.left.is_boolean(i)) return Fe(Pn, r, {
                                operator: "+",
                                expression: r.left
                            }).optimize(i);
                            if (r.left.is_number(i) && !r.left.is_negative_zero()) return r.left;
                        }
                        break;

                      case "-":
                        if (r.right.value == 0) return Fe(Pn, r, {
                            operator: "+",
                            expression: r.left
                        }).optimize(i);
                        break;

                      case "/":
                        if (r.right.value == 1) return Fe(Pn, r, {
                            operator: "+",
                            expression: r.left
                        }).optimize(i);
                        break;
                    }
                }
            }
            if (i.option("typeofs")) switch (r.operator) {
              case "&&":
                V(r.left, r.right, null);
                break;

              case "||":
                V(r.left, null, r.right);
                break;
            }
            if (i.option("unsafe")) {
                var E = O(r.right);
                if (c && E && (r.operator == "==" || r.operator == "!=") && r.left instanceof Wn && r.left.value == 0) {
                    return (r.operator == "==" ? Fe(Pn, r, {
                        operator: "!",
                        expression: r.right
                    }) : r.right).optimize(i);
                }
                var S = O(r.left);
                if (i.option("comparisons") && $()) {
                    var T = Fe(Pn, r, {
                        operator: "!",
                        expression: Fe(Pn, r, {
                            operator: "~",
                            expression: S ? r.left : r.right
                        })
                    });
                    switch (r.operator) {
                      case "<":
                        if (S) break;

                      case "<=":
                      case "!=":
                        T = Fe(Pn, r, {
                            operator: "!",
                            expression: T
                        });
                        break;
                    }
                    return T.optimize(i);
                }
            }
            return de(i, r);
            function A(e) {
                var n = false;
                e.walk(new Gn(function(e) {
                    if (n) return true;
                    if (e instanceof In) {
                        if (e.left instanceof $n) return n = true;
                    } else if (e instanceof Fn) {
                        if (pi[e.operator] && e.expression instanceof $n) {
                            return n = true;
                        }
                    }
                }));
                return n;
            }
            function D(e, n) {
                switch (e) {
                  case "-":
                    return n == "+" ? "-" : "+";

                  case "/":
                    return n == "*" ? "/" : "*";

                  default:
                    return n;
                }
            }
            function q(e, n, t, r) {
                if (e == "+") {
                    if (!n.is_boolean(i) && !n.is_number(i)) {
                        n = Fe(Pn, n, {
                            operator: "+",
                            expression: n
                        });
                    }
                    if (!t.is_boolean(i) && !t.is_number(i)) {
                        t = Fe(Pn, t, {
                            operator: "+",
                            expression: t
                        });
                    }
                }
                return Fe(jn, r, {
                    operator: e,
                    left: n,
                    right: t
                });
            }
            function O(e) {
                return e.TYPE == "Call" && e.expression instanceof zn && De[e.expression.property];
            }
            function $() {
                switch (r.operator) {
                  case "<=":
                    return E && r.left instanceof Wn && r.left.value == 0;

                  case "<":
                    if (S && r.right instanceof Wn && r.right.value == 0) return true;

                  case "==":
                  case "!=":
                    if (!E) return false;
                    return r.left instanceof Wn && r.left.value == -1 || r.left instanceof Pn && r.left.operator == "-" && r.left.expression instanceof Wn && r.left.expression.value == 1;
                }
            }
            function z() {
                return r.left.is_constant() || r.right.is_constant() || !r.left.has_side_effects(i) && !r.right.has_side_effects(i);
            }
            function C(e) {
                if (z()) {
                    if (e) r.operator = e;
                    var n = r.left;
                    r.left = r.right;
                    r.right = n;
                }
            }
        });
        e(Yr, function(e) {
            return e;
        });
        function Ze(e, n, t) {
            var r = 0, i = e.self();
            do {
                if (i === t) return i;
                if (M(i) && i.name && i.name.definition() === n) return i;
            } while (i = e.parent(r++));
        }
        function en(e) {
            var n = e.scope.resolve();
            return _n(e.references, function(e) {
                return n === e.scope.resolve();
            });
        }
        e(Ln, function(t, e) {
            if (!e.option("ie") && Ne(t) && !(t.scope.resolve().uses_with && e.find_parent(xt))) {
                switch (t.name) {
                  case "undefined":
                    return Fe(Qr, t).optimize(e);

                  case "NaN":
                    return Fe(Kr, t).optimize(e);

                  case "Infinity":
                    return Fe(ei, t).optimize(e);
                }
            }
            var n = e.parent();
            if (e.option("reduce_vars") && di(e.self(), n) !== e.self()) {
                var r = t.definition();
                var i = t.fixed_value();
                var a = r.single_use && !(n instanceof qn && n.is_expr_pure(e));
                if (a) {
                    if (M(i)) {
                        if ((r.scope !== t.scope.resolve(true) || r.in_loop) && (!e.option("reduce_funcs") || r.escaped.depth == 1 || i.inlined)) {
                            a = false;
                        } else if (r.redefined()) {
                            a = false;
                        } else if (Ze(e, r, i)) {
                            a = false;
                        } else if (i.name && i.name.definition() !== r) {
                            a = false;
                        } else if (i.parent_scope !== t.scope || li(r)) {
                            if (!Se(i, e)) {
                                a = false;
                            } else if ((a = i.is_constant_expression(t.scope)) == "f") {
                                var o = t.scope;
                                do {
                                    if (o instanceof jt || o instanceof Tt) {
                                        o.inlined = true;
                                    }
                                } while (o = o.parent_scope);
                            }
                        } else if (i.name && (i.name.name == "await" && Dt(i) || i.name.name == "yield" && qt(i))) {
                            a = false;
                        } else if (i.has_side_effects(e)) {
                            a = false;
                        } else if (e.option("ie") && i instanceof Rt) {
                            a = false;
                        }
                        if (a) i.parent_scope = t.scope;
                    } else if (!i || r.recursive_refs > 0 || !i.is_constant_expression() || i.drop_side_effect_free(e)) {
                        a = false;
                    }
                }
                if (a) {
                    r.single_use = false;
                    i._squeezed = true;
                    i.single_use = true;
                    if (i instanceof Bt) i = re(i);
                    if (i instanceof jt) i = ye(i);
                    if (M(i)) {
                        var s = [];
                        var o = t.scope;
                        do {
                            s.push(o);
                            if (o === r.scope) break;
                        } while (o = o.parent_scope);
                        i.enclosed.forEach(function(e) {
                            if (i.variables.has(e.name)) return;
                            for (var n = 0; n < s.length; n++) {
                                var t = s[n];
                                if (!nt(t.enclosed, e)) return;
                                t.var_names().set(e.name, true);
                            }
                        });
                    }
                    var f;
                    if (r.recursive_refs > 0) {
                        f = i.clone(true);
                        var u = f.name.definition();
                        var c = f.variables.get(f.name.name);
                        var l = c && c.orig[0];
                        var p, d;
                        if (f instanceof Rt) {
                            p = "def_function";
                            d = Ir;
                        } else {
                            p = "def_variable";
                            d = Nr;
                        }
                        if (!(l instanceof d)) {
                            l = Fe(d, f.name);
                            l.scope = f;
                            f.name = l;
                            c = f[p](l);
                            c.recursive_refs = r.recursive_refs;
                        }
                        f.walk(new Gn(function(e) {
                            if (e instanceof zr) {
                                if (e !== l) {
                                    var n = e.definition();
                                    n.orig.push(e);
                                    n.eliminated++;
                                }
                                return;
                            }
                            if (!(e instanceof Ln)) return;
                            var n = e.definition();
                            if (n === u) {
                                e.thedef = n = c;
                            } else {
                                n.single_use = false;
                                var t = e.fixed_value();
                                if (M(t) && t.name && t.name.definition() === n && n.scope === t.name.scope && i.variables.get(t.name.name) === n) {
                                    t.name = t.name.clone();
                                    e.thedef = n = f.variables.get(t.name.name) || f[p](t.name);
                                }
                            }
                            n.references.push(e);
                        }));
                    } else {
                        if (i instanceof kn) {
                            e.push(i);
                            f = i.optimize(e);
                            e.pop();
                        } else {
                            f = i.optimize(e);
                        }
                        f = f.transform(new ii(function(e, n) {
                            if (e instanceof kn) return e;
                            e = e.clone();
                            n(e, this);
                            return e;
                        }));
                    }
                    r.replaced++;
                    return f;
                }
                var h;
                if (i && (h = t.fixed || r.fixed).should_replace !== false) {
                    var v, m;
                    if (i instanceof Lr) {
                        if (!li(r) && en(r) && !y(r)) m = i;
                    } else if ((v = i.evaluate(e, true)) !== i && typeof v != "function" && (v === null || typeof v != "object" || e.option("unsafe_regexp") && v instanceof RegExp && !r.cross_loop && en(r))) {
                        m = fe(v, i);
                    }
                    if (m) {
                        if (h.should_replace === undefined) {
                            var _ = m.optimize(e).print_to_string().length;
                            if (!w(i)) {
                                _ = Math.min(_, i.print_to_string().length);
                            }
                            var g = r.name.length;
                            if (e.option("unused") && !e.exposed(r)) {
                                var b = r.references.length - r.replaced - r.assignments;
                                b = Math.min(b, r.references.filter(function(e) {
                                    return e.fixed === h;
                                }).length);
                                g += (g + 2 + _) / Math.max(1, b);
                            }
                            h.should_replace = _ - Math.floor(g) < e.eval_threshold;
                        }
                        if (h.should_replace) {
                            var f;
                            if (w(i)) {
                                f = m.optimize(e);
                                if (f === m) f = f.clone(true);
                            } else {
                                f = le(m.optimize(e), i);
                                if (f === m || f === i) f = f.clone(true);
                            }
                            r.replaced++;
                            return f;
                        }
                    }
                }
            }
            return t;
            function y(e) {
                var n = t.scope;
                while (n !== e.scope) {
                    if (n instanceof Rt) return true;
                    n = n.parent_scope;
                }
            }
            function w(e) {
                var n;
                e.walk(new Gn(function(e) {
                    if (e instanceof Ln) n = true;
                    if (n) return true;
                }));
                return n;
            }
        });
        function nn(e, n) {
            return e.option("unsafe") && n instanceof zn && n.property == "raw" && Ne(n.expression) && n.expression.name == "String";
        }
        function tn(e) {
            var r = false;
            e = e.replace(/\\(u\{[^{}]*\}?|u[\s\S]{0,4}|x[\s\S]{0,2}|[0-9]+|[\s\S])/g, function(e, n) {
                var t = oi(n);
                if (typeof t == "string") return t;
                r = true;
            });
            if (!r) return e;
        }
        e(Vr, function(e, t) {
            if (!t.option("templates")) return e;
            var r = e.tag;
            if (!r || nn(t, r)) {
                var n = [];
                var i = [];
                for (var a = 0, o; a < e.strings.length; a++) {
                    var s = e.strings[a];
                    if (!r) {
                        var f = tn(s);
                        if (f) s = v(f);
                    }
                    if (a > 0) {
                        var u = e.expressions[a - 1];
                        var c = m(u);
                        if (c) {
                            var l = i[i.length - 1];
                            var p = l + c + s;
                            var d;
                            if (r || typeof (d = tn(p)) == o) {
                                i[i.length - 1] = d ? v(d) : p;
                                continue;
                            }
                        }
                        n.push(u);
                    }
                    i.push(s);
                    if (!r) o = typeof f;
                }
                if (!r && i.length > 1) {
                    if (i[i.length - 1] == "") return Fe(jn, e, {
                        operator: "+",
                        left: Fe(Vr, e, {
                            expressions: n.slice(0, -1),
                            strings: i.slice(0, -1)
                        }).transform(t),
                        right: n[n.length - 1]
                    }).optimize(t);
                    if (i[0] == "") {
                        var h = Fe(jn, e, {
                            operator: "+",
                            left: Fe(Vn, e, {
                                value: ""
                            }),
                            right: n[0]
                        });
                        for (var a = 1; i[a] == "" && a < n.length; a++) {
                            h = Fe(jn, e, {
                                operator: "+",
                                left: h,
                                right: n[a]
                            });
                        }
                        return pe(t, e, Fe(jn, e, {
                            operator: "+",
                            left: h.transform(t),
                            right: Fe(Vr, e, {
                                expressions: n.slice(a),
                                strings: i.slice(a)
                            }).transform(t)
                        }).optimize(t));
                    }
                }
                e.expressions = n;
                e.strings = i;
            }
            return de(t, e);
            function v(e) {
                return e.replace(/\r|\\|`|\${/g, function(e) {
                    return "\\" + (e == "\r" ? "r" : e);
                });
            }
            function m(e) {
                var n = e.evaluate(t);
                if (n === e) return;
                if (r && /\r|\\|`/.test(n)) return;
                n = v("" + n);
                if (n.length > e.print_to_string().length + "${}".length) return;
                return n;
            }
        });
        function rn(e, n) {
            return e instanceof Ln || e.TYPE === n.TYPE;
        }
        e(Qr, function(e, n) {
            if (n.option("unsafe_undefined")) {
                var t = Me(n).find_variable("undefined");
                if (t) {
                    var r = Fe(Ln, e, {
                        name: "undefined",
                        scope: t.scope,
                        thedef: t
                    });
                    r.is_undefined = true;
                    return r;
                }
            }
            var i = di(n.self(), n.parent());
            if (i && rn(i, e)) return e;
            return Fe(Pn, e, {
                operator: "void",
                expression: Fe(Wn, e, {
                    value: 0
                })
            });
        });
        e(ei, function(e, n) {
            var t = di(n.self(), n.parent());
            if (t && rn(t, e)) return e;
            if (n.option("keep_infinity") && !t && !Me(n).find_variable("Infinity")) {
                return e;
            }
            return Fe(jn, e, {
                operator: "/",
                left: Fe(Wn, e, {
                    value: 1
                }),
                right: Fe(Wn, e, {
                    value: 0
                })
            });
        });
        e(Kr, function(e, n) {
            var t = di(n.self(), n.parent());
            if (t && rn(t, e)) return e;
            if (!t && !Me(n).find_variable("NaN")) return e;
            return Fe(jn, e, {
                operator: "/",
                left: Fe(Wn, e, {
                    value: 0
                }),
                right: Fe(Wn, e, {
                    value: 0
                })
            });
        });
        function an(t, n) {
            var r = false;
            var i = new Gn(function(e) {
                if (r) return true;
                if (e instanceof Ln && Jn(e.definition(), n)) return r = true;
            });
            var a = new Gn(function(e) {
                if (r) return true;
                if (e instanceof En && e !== t) {
                    if (!(e.name || Dt(e) || qt(e))) {
                        var n = a.parent();
                        if (n instanceof qn && n.expression === e) return;
                    }
                    e.walk(i);
                    return true;
                }
            });
            t.walk(a);
            return r;
        }
        var on = mn("+ - * / % >> << >>> | ^ &");
        var sn = mn("* | ^ &");
        e(In, function(a, o) {
            if (o.option("dead_code")) {
                if (a.left instanceof $n) {
                    if (a.operator == "=") {
                        if (a.redundant) {
                            var e = [ a.left.expression ];
                            if (a.left instanceof Cn) e.push(a.left.property);
                            e.push(a.right);
                            return Pe(a, e).optimize(o);
                        }
                        if (a.left.equals(a.right) && !a.left.has_side_effects(o)) {
                            return a.right;
                        }
                        var n = a.left.expression;
                        if (n instanceof En || !o.has_directive("use strict") && n instanceof Un && !n.may_throw_on_access(o)) {
                            return a.left instanceof zn ? a.right : Pe(a, [ a.left.property, a.right ]).optimize(o);
                        }
                    }
                } else if (a.left instanceof Ln && Ce(a.left, o)) {
                    var t;
                    if (a.operator == "=" && a.left.equals(a.right) && !((t = o.parent()) instanceof Pn && t.operator == "delete")) {
                        return a.right;
                    }
                    if (a.left.is_immutable()) return _();
                    var r = a.left.definition();
                    var s = r.scope.resolve();
                    var i = s === o.find_parent(En);
                    var f = 0, u;
                    t = o.self();
                    if (!(s.uses_arguments && li(r)) || o.has_directive("use strict")) do {
                        u = t;
                        t = o.parent(f++);
                        if (t instanceof In) {
                            if (t.left instanceof Ln && t.left.definition() === r) {
                                if (v(f, t, !i)) break;
                                return _(r);
                            }
                            if (t.left.match_symbol(function(e) {
                                if (e instanceof $n) return true;
                            })) break;
                            continue;
                        }
                        if (t instanceof Qt) {
                            if (!i) break;
                            if (v(f, t)) break;
                            if (an(s, [ r ])) break;
                            return _(r);
                        }
                        if (t instanceof wn) {
                            if (!i) break;
                            if (an(s, [ r ])) break;
                            var c;
                            do {
                                c = t;
                                t = o.parent(f++);
                                if (t === s && T(t.body, c)) return _(r);
                            } while (h(c, t));
                            break;
                        }
                        if (t instanceof An) {
                            if (!(t.name instanceof zr)) continue;
                            if (t.name.definition() !== r) continue;
                            if (v(f, t)) break;
                            return _(r);
                        }
                    } while (d(u, t));
                }
            }
            if (o.option("sequences")) {
                var l = a.lift_sequences(o);
                if (l !== a) return l.optimize(o);
            }
            if (o.option("assignments")) {
                if (a.operator == "=" && a.left instanceof Ln && a.right instanceof jn) {
                    if (a.right.left instanceof Ln && a.right.left.name == a.left.name && on[a.right.operator]) {
                        return m(a.right.right);
                    }
                    if (a.right.right instanceof Ln && a.right.right.name == a.left.name && sn[a.right.operator] && !a.right.left.has_side_effects(o)) {
                        return m(a.right.left);
                    }
                }
                if ((a.operator == "-=" || a.operator == "+=" && (a.left.is_boolean(o) || a.left.is_number(o))) && a.right instanceof Wn && a.right.value == 1) {
                    var p = a.operator.slice(0, -1);
                    return Fe(Pn, a, {
                        operator: p + p,
                        expression: a.left
                    });
                }
            }
            return de(o, a);
            function d(e, n) {
                if (n instanceof jn) switch (e) {
                  case n.left:
                    return n.right.is_constant_expression(s);

                  case n.right:
                    return true;

                  default:
                    return false;
                }
                if (n instanceof Nn) switch (e) {
                  case n.condition:
                    return n.consequent.is_constant_expression(s) && n.alternative.is_constant_expression(s);

                  case n.consequent:
                  case n.alternative:
                    return true;

                  default:
                    return false;
                }
                if (n instanceof On) {
                    var t = n.expressions;
                    var r = t.indexOf(e);
                    if (r < 0) return false;
                    for (var i = t.length; --i > r; ) {
                        if (!t[i].is_constant_expression(s)) return false;
                    }
                    return true;
                }
                return n instanceof Pn;
            }
            function h(e, n) {
                if (n instanceof xn) return T(n.body, e);
                if (n instanceof fr) return T(n.body, e);
                if (n instanceof ur) return T(n.body, e);
                if (n instanceof Tn) return n.body === e || n.alternative === e;
                if (n instanceof sr) return n.bfinally ? n.bfinally === e : n.bcatch === e;
            }
            function v(e, n, t) {
                var r = a.right;
                a.right = Fe(Xr, r);
                var i = n.may_throw(o);
                a.right = r;
                return Le(o, e, n, s, i, t);
            }
            function m(e) {
                var n = a.left.fixed;
                if (n) n.to_binary = z(function(e) {
                    return e.left;
                }, n);
                return Fe(In, a, {
                    operator: a.right.operator + "=",
                    left: a.left,
                    right: e
                });
            }
            function _(e) {
                if (e) e.fixed = false;
                return (a.operator != "=" ? Fe(jn, a, {
                    operator: a.operator.slice(0, -1),
                    left: a.left,
                    right: a.right
                }) : je(o.parent(), a, a.right)).optimize(o);
            }
        });
        e(Nn, function(u, n) {
            if (n.option("sequences") && u.condition instanceof On) {
                var e = u.condition.expressions.slice();
                var t = u.clone();
                t.condition = e.pop();
                e.push(t);
                return Pe(u, e).optimize(n);
            }
            if (!n.option("conditionals")) return u;
            var c = u.condition;
            if (n.option("booleans") && !c.has_side_effects(n)) {
                Q(n, c);
            }
            c = j(n, c);
            if (!c) {
                bn.warn("Condition always false [{start}]", u);
                return Pe(u, [ u.condition, u.alternative ]).optimize(n);
            } else if (!(c instanceof bn)) {
                bn.warn("Condition always true [{start}]", u);
                return Pe(u, [ u.condition, u.consequent ]).optimize(n);
            }
            var r = at(n);
            var i = c.negate(n, r);
            if ((r ? A : le)(c, i) === i) {
                u = Fe(Nn, u, {
                    condition: i,
                    consequent: u.alternative,
                    alternative: u.consequent
                });
                i = c;
                c = u.condition;
            }
            var a = u.consequent;
            var o = u.alternative;
            var s = Oe(c, n);
            if (Ke(n, s)) {
                if (s.equals(a)) return Fe(jn, u, {
                    operator: "||",
                    left: c,
                    right: o
                }).optimize(n);
                if (s.equals(o)) return Fe(jn, u, {
                    operator: "&&",
                    left: c,
                    right: a
                }).optimize(n);
            }
            var f = a.tail_node();
            if (f instanceof In) {
                var l = f.operator == "=";
                var p = l ? o.tail_node() : o;
                if ((l || a === f) && p instanceof In && f.operator == p.operator && f.left.equals(p.left) && (l && f.left instanceof Ln || !c.has_side_effects(n) && E(a) && E(o))) {
                    return Fe(In, u, {
                        operator: f.operator,
                        left: f.left,
                        right: Fe(Nn, u, {
                            condition: c,
                            consequent: S(a),
                            alternative: S(o)
                        })
                    });
                }
            }
            var p = o.tail_node();
            if (f.equals(p)) return Pe(u, a.equals(o) ? [ c, a ] : [ Fe(Nn, u, {
                condition: c,
                consequent: T(a),
                alternative: T(o)
            }), p ]).optimize(n);
            var d = k(a, o, true);
            if (d) return d;
            var h;
            if (a instanceof qn && o.TYPE == a.TYPE && (h = y(a, o)) >= 0 && a.expression.equals(o.expression) && !c.has_side_effects(n) && !a.expression.has_side_effects(n)) {
                var t = a.clone();
                var v = a.args[h];
                t.args[h] = v instanceof Mn ? Fe(Mn, u, {
                    expression: Fe(Nn, u, {
                        condition: c,
                        consequent: v.expression,
                        alternative: o.args[h].expression
                    })
                }) : Fe(Nn, u, {
                    condition: c,
                    consequent: v,
                    alternative: o.args[h]
                });
                return t;
            }
            if (f instanceof Nn && f.alternative.equals(o)) {
                return Fe(Nn, u, {
                    condition: Fe(jn, u, {
                        left: c,
                        operator: "&&",
                        right: w(a, f, "condition")
                    }),
                    consequent: f.consequent,
                    alternative: B(f.alternative, o)
                });
            }
            if (f instanceof Nn && f.consequent.equals(o)) {
                return Fe(Nn, u, {
                    condition: Fe(jn, u, {
                        left: i,
                        operator: "||",
                        right: w(a, f, "condition")
                    }),
                    consequent: B(f.consequent, o),
                    alternative: f.alternative
                });
            }
            if (p instanceof Nn && a.equals(p.consequent)) {
                return Fe(Nn, u, {
                    condition: Fe(jn, u, {
                        left: c,
                        operator: "||",
                        right: w(o, p, "condition")
                    }),
                    consequent: B(a, p.consequent),
                    alternative: p.alternative
                });
            }
            if (p instanceof Nn && a.equals(p.alternative)) {
                return Fe(Nn, u, {
                    condition: Fe(jn, u, {
                        left: i,
                        operator: "&&",
                        right: w(o, p, "condition")
                    }),
                    consequent: p.consequent,
                    alternative: B(a, p.alternative)
                });
            }
            if (f instanceof jn && f.operator == "&&" && f.right.equals(o)) {
                return Fe(jn, u, {
                    operator: "&&",
                    left: Fe(jn, u, {
                        operator: "||",
                        left: i,
                        right: w(a, f, "left")
                    }),
                    right: B(f.right, o)
                }).optimize(n);
            }
            if (f instanceof jn && f.operator == "||" && f.right.equals(o)) {
                return Fe(jn, u, {
                    operator: "||",
                    left: Fe(jn, u, {
                        operator: "&&",
                        left: c,
                        right: w(a, f, "left")
                    }),
                    right: B(f.right, o)
                }).optimize(n);
            }
            if (p instanceof jn && p.operator == "&&" && p.right.equals(a)) {
                return Fe(jn, u, {
                    operator: "&&",
                    left: Fe(jn, u, {
                        operator: "||",
                        left: c,
                        right: w(o, p, "left")
                    }),
                    right: B(a, p.right)
                }).optimize(n);
            }
            if (p instanceof jn && p.operator == "||" && p.right.equals(a)) {
                return Fe(jn, u, {
                    operator: "||",
                    left: Fe(jn, u, {
                        operator: "&&",
                        left: i,
                        right: w(o, p, "left")
                    }),
                    right: B(a, p.right)
                }).optimize(n);
            }
            var m = n.option("booleans") && n.in_boolean_context();
            if (g(a)) {
                if (b(o)) return _(c);
                return Fe(jn, u, {
                    operator: "||",
                    left: _(c),
                    right: o
                }).optimize(n);
            }
            if (b(a)) {
                if (g(o)) return _(c.negate(n));
                return Fe(jn, u, {
                    operator: "&&",
                    left: _(c.negate(n)),
                    right: o
                }).optimize(n);
            }
            if (g(o)) return Fe(jn, u, {
                operator: "||",
                left: _(c.negate(n)),
                right: a
            }).optimize(n);
            if (b(o)) return Fe(jn, u, {
                operator: "&&",
                left: _(c),
                right: a
            }).optimize(n);
            if (n.option("typeofs")) V(c, a, o);
            return u;
            function _(e) {
                if (e.is_boolean(n)) return e;
                return Fe(Pn, e, {
                    operator: "!",
                    expression: e.negate(n)
                });
            }
            function g(e) {
                return e instanceof ri || m && e instanceof Un && e.value || e instanceof Pn && e.operator == "!" && e.expression instanceof Un && !e.expression.value;
            }
            function b(e) {
                return e instanceof ti || m && (e instanceof Un && !e.value || e instanceof Pn && e.operator == "void" && !e.expression.has_side_effects(n)) || e instanceof Pn && e.operator == "!" && e.expression instanceof Un && e.expression.value;
            }
            function y(e, n) {
                var t = e.args;
                var r = n.args;
                var i = t.length;
                if (i != r.length) return -2;
                for (var a = 0; a < i; a++) {
                    if (!t[a].equals(r[a])) {
                        if (t[a] instanceof Mn !== r[a] instanceof Mn) return -3;
                        for (var o = a + 1; o < i; o++) {
                            if (!t[o].equals(r[o])) return -2;
                        }
                        return a;
                    }
                }
                return -1;
            }
            function w(e, n, t) {
                if (e === n) return n[t];
                var r = e.expressions.slice(0, -1);
                r.push(n[t]);
                return Pe(e, r);
            }
            function x(e, n) {
                if (e.TYPE != n.TYPE) return;
                if (e.optional != n.optional) return;
                if (e instanceof qn) {
                    if (y(e, n) != -1) return;
                    return e.TYPE != "Call" || !(e.expression instanceof $n || n.expression instanceof $n) || x(e.expression, n.expression);
                }
                if (!(e instanceof $n)) return;
                var t = e.property;
                var r = n.property;
                return (t instanceof bn ? t.equals(r) : t == r) && !(e.expression instanceof Br || n.expression instanceof Br);
            }
            function k(e, n, t) {
                var r = e.tail_node();
                var i = n.tail_node();
                if (!x(r, i)) return !t && Fe(Nn, u, {
                    condition: c,
                    consequent: e,
                    alternative: n
                });
                var a = r.clone();
                var o = w(e, r, "expression");
                var s = w(n, i, "expression");
                var f = k(o, s);
                if (r.expression instanceof On) {
                    f = je(r, r.expression, f);
                }
                a.expression = f;
                return a;
            }
            function E(e) {
                return e === e.tail_node() || _n(e.expressions.slice(0, -1), function(e) {
                    return !e.has_side_effects(n);
                });
            }
            function S(e) {
                if (!(e instanceof On)) return e.right;
                var n = e.expressions.slice();
                n.push(n.pop().right);
                return Pe(e, n);
            }
            function T(e) {
                if (!(e instanceof On)) return Fe(Wn, e, {
                    value: 0
                });
                return Pe(e, e.expressions.slice(0, -1));
            }
        });
        e(ni, function(e, n) {
            if (!n.option("booleans")) return e;
            if (n.in_boolean_context()) return Fe(Wn, e, {
                value: +e.value
            });
            var t = n.parent();
            if (t instanceof jn && (t.operator == "==" || t.operator == "!=")) {
                bn.warn("Non-strict equality against boolean: {operator} {value} [{start}]", {
                    operator: t.operator,
                    value: e.value,
                    start: t.start
                });
                return Fe(Wn, e, {
                    value: +e.value
                });
            }
            return Fe(Pn, e, {
                operator: "!",
                expression: Fe(Wn, e, {
                    value: 1 - e.value
                })
            });
        });
        e(Mn, function(e, n) {
            var t = e.expression;
            if (n.option("spreads") && t instanceof Hn && !(n.parent() instanceof Rn)) {
                return et.splice(t.elements.map(function(e) {
                    return e instanceof Zr ? Fe(Qr, e).optimize(n) : e;
                }));
            }
            return e;
        });
        function fn(e, n) {
            if (!e) return false;
            var t = n.parent();
            if (t.TYPE != "Call") return true;
            if (t.expression !== n.self()) return true;
            if (e instanceof Ln) {
                e = e.fixed_value();
                if (!e) return false;
            }
            return e instanceof En && !e.contains_this();
        }
        e(Cn, function(e, t) {
            var n = e.expression;
            var r = e.property;
            var i = xe(e, t);
            if (i) return i;
            if (t.option("properties")) {
                var a = r.evaluate(t);
                if (a !== r) {
                    if (typeof a == "string") {
                        if (a == "undefined") {
                            a = undefined;
                        } else {
                            var o = parseFloat(a);
                            if (o.toString() == a) {
                                a = o;
                            }
                        }
                    }
                    r = e.property = le(r, fe(a, r).transform(t));
                    var s = "" + a;
                    if (ai(s) && s.length <= r.print_to_string().length + 1) {
                        return Fe(zn, e, {
                            optional: e.optional,
                            expression: n,
                            property: s,
                            quoted: true
                        }).optimize(t);
                    }
                }
            }
            var f = t.parent();
            var u = di(t.self(), f);
            var c, l, p, d;
            if (t.option("arguments") && n instanceof Ln && ze(c = n.definition()) && !n.in_arg && r instanceof Wn && Math.floor(d = r.value) == d && (l = c.scope) === S() && l.uses_arguments < (u ? 2 : 3)) {
                if (f instanceof Pn && f.operator == "delete") {
                    if (!c.deleted) c.deleted = [];
                    c.deleted[d] = true;
                }
                var h = l.argnames[d];
                if (c.deleted && c.deleted[d]) {
                    h = null;
                } else if (h) {
                    var v;
                    if (!(h instanceof Bn) || h.name == "await" || n.scope.find_variable(h.name) !== (v = h.definition())) {
                        h = null;
                    } else if (t.has_directive("use strict") || l.name || l.rest || !(p instanceof qn && d < p.args.length && _n(p.args.slice(0, d + 1), function(e) {
                        return !(e instanceof Mn);
                    })) || !_n(l.argnames, function(e) {
                        return e instanceof Bn;
                    })) {
                        if (T() || v.assignments || v.orig.length > 1) h = null;
                    }
                } else if ((u || !T()) && d < l.argnames.length + 5 && t.drop_fargs(l, p) && !l.rest) {
                    while (d >= l.argnames.length) {
                        h = l.make_var(Bn, l, "argument_" + l.argnames.length);
                        l.argnames.push(h);
                    }
                }
                if (h && Xn(function(e) {
                    return e.name === h.name;
                }, l.argnames) === h) {
                    if (u) c.reassigned--;
                    var m = Fe(Ln, h);
                    m.reference();
                    h.unused = undefined;
                    return m;
                }
            }
            if (u) return e;
            if (t.option("sequences") && f.TYPE != "Call" && !(f instanceof bt && f.init === e)) {
                var _ = he(e, t);
                if (_ !== e) return _.optimize(t);
            }
            if (a !== r) {
                var g = e.flatten_object(s, t);
                if (g) {
                    n = e.expression = g.expression;
                    r = e.property = g.property;
                }
            }
            var b;
            if (t.option("properties") && t.option("side_effects") && r instanceof Wn && n instanceof Hn && _n(b = n.elements, function(e) {
                return !(e instanceof Mn);
            })) {
                var d = r.value;
                var y = b[d];
                if (fn(y, t)) {
                    var w = y instanceof Zr;
                    var x = !w;
                    var k = [];
                    for (var E = b.length; --E > d; ) {
                        var o = b[E].drop_side_effect_free(t);
                        if (o) {
                            k.unshift(o);
                            if (x && o.has_side_effects(t)) x = false;
                        }
                    }
                    if (!x) k.unshift(y);
                    while (--E >= 0) {
                        var o = b[E].drop_side_effect_free(t);
                        if (o) {
                            k.unshift(o);
                        } else if (w) {
                            k.unshift(Fe(Zr, b[E]));
                        } else {
                            d--;
                        }
                    }
                    if (x) {
                        k.push(y);
                        return Pe(e, k).optimize(t);
                    }
                    return Fe(Cn, e, {
                        expression: Fe(Hn, n, {
                            elements: k
                        }),
                        property: Fe(Wn, r, {
                            value: d
                        })
                    });
                }
            }
            return de(t, e);
            function S() {
                var e = 0, n;
                while (n = t.parent(e++)) {
                    if (n instanceof En) {
                        if (n instanceof St) return;
                        if (At(n)) continue;
                        p = t.parent(e);
                        return n;
                    }
                }
            }
            function T() {
                return !t.option("reduce_vars") || c.reassigned;
            }
        });
        Tt.DEFMETHOD("contains_super", function() {
            var n = false;
            var t = this;
            t.walk(new Gn(function(e) {
                if (n) return true;
                if (e instanceof Br) return n = true;
                if (e !== t && e instanceof kn && !At(e)) return true;
            }));
            return n;
        });
        (function(e) {
            e($t, hn);
            e(zt, hn);
            e(bn, function() {
                var n = false;
                var t = this;
                t.walk(new Gn(function(e) {
                    if (n) return true;
                    if (e instanceof Lr) return n = true;
                    if (e !== t && e instanceof kn && !At(e)) return true;
                }));
                return n;
            });
        })(function(e, n) {
            e.DEFMETHOD("contains_this", n);
        });
        function un(e) {
            return e instanceof Ar && typeof e.key == "string" && !(e instanceof Dr && e.value.contains_super());
        }
        $n.DEFMETHOD("flatten_object", function(e, n) {
            if (!n.option("properties")) return;
            if (e === "__proto__") return;
            var t = this;
            var r = t.expression;
            if (!(r instanceof Rn)) return;
            var i = r.properties;
            for (var a = i.length; --a >= 0; ) {
                var o = i[a];
                if (o.key !== e) continue;
                if (!_n(i, un)) return;
                if (!fn(o.value, n)) return;
                var s, f, u = [];
                for (var c = 0; c < i.length; c++) {
                    var l = i[c].value;
                    if (i[c] instanceof Dr) {
                        var p = !(l.uses_arguments || qt(l) || l.contains_this());
                        if (p) {
                            if (!f) f = n.find_parent(kn);
                            var d = ve(n, f);
                            l.each_argname(function(e) {
                                if (d[e.name]) p = false;
                            });
                        }
                        var h;
                        if (p) {
                            h = Dt(l) ? zt : $t;
                        } else if (a != c || (s = n.parent()) instanceof qn && s.expression === t) {
                            h = l.CTOR;
                        } else {
                            return;
                        }
                        l = Fe(h, l);
                    }
                    u.push(l);
                }
                return Fe(Cn, t, {
                    expression: Fe(Hn, r, {
                        elements: u
                    }),
                    property: Fe(Wn, t, {
                        value: a
                    })
                });
            }
        });
        e(zn, function(e, n) {
            if (e.property == "arguments" || e.property == "caller") {
                bn.warn("Function.prototype.{property} not supported [{start}]", e);
            }
            var t = n.parent();
            if (di(n.self(), t)) return e;
            var r = xe(e, n);
            if (r) return r;
            if (n.option("sequences") && t.TYPE != "Call" && !(t instanceof bt && t.init === e)) {
                var i = he(e, n);
                if (i !== e) return i.optimize(n);
            }
            if (n.option("unsafe_proto") && e.expression instanceof zn && e.expression.property == "prototype") {
                var a = e.expression.expression;
                if (Ne(a)) switch (a.name) {
                  case "Array":
                    e.expression = Fe(Hn, e.expression, {
                        elements: []
                    });
                    break;

                  case "Function":
                    e.expression = Fe(Ft, e.expression, {
                        argnames: [],
                        body: []
                    }).init_vars(a.scope);
                    break;

                  case "Number":
                    e.expression = Fe(Wn, e.expression, {
                        value: 0
                    });
                    break;

                  case "Object":
                    e.expression = Fe(Rn, e.expression, {
                        properties: []
                    });
                    break;

                  case "RegExp":
                    e.expression = Fe(Gr, e.expression, {
                        value: /t/
                    });
                    break;

                  case "String":
                    e.expression = Fe(Vn, e.expression, {
                        value: ""
                    });
                    break;
                }
            }
            var o = e.flatten_object(e.property, n);
            if (o) return o.optimize(n);
            return de(n, e);
        });
        e(kr, function(e, n) {
            if (n.option("rests") && e.rest instanceof kr) {
                return Fe(kr, e, {
                    elements: e.elements.concat(e.rest.elements),
                    rest: e.rest.rest
                });
            }
            return e;
        });
        e(Er, function(e, n) {
            if (n.option("objects")) {
                var t = e.key;
                if (t instanceof bn) {
                    t = t.evaluate(n);
                    if (t !== e.key) e.key = "" + t;
                }
            }
            return e;
        });
        e(Rn, function(r, i) {
            if (!i.option("objects")) return r;
            var a = false;
            var t = false;
            var o = false;
            var s = i.has_directive("use strict");
            var f = [];
            var u = new gn();
            var c = [];
            r.properties.forEach(function(e) {
                if (!(e instanceof Mn)) return p(e);
                t = true;
                var n = e.expression;
                if (i.option("spreads") && n instanceof Rn && _n(n.properties, function(e) {
                    if (e instanceof Or) return false;
                    if (e instanceof Mn) return false;
                    if (e.key !== "__proto__") return true;
                    if (e instanceof qr) return true;
                    return !e.value.has_side_effects(i);
                })) {
                    a = true;
                    n.properties.forEach(function(e) {
                        var n = e.key;
                        var t = e instanceof qr;
                        if (n === "__proto__") {
                            if (!t) return;
                            n = fe(n, e);
                        }
                        p(t ? Fe(Ar, e, {
                            key: n,
                            value: Fe(Qr, e).optimize(i)
                        }) : e);
                    });
                } else {
                    o = true;
                    l();
                    c.push(e);
                }
            });
            l();
            if (!a) return r;
            if (t && o && c.length == 1) {
                var e = c[0];
                if (e instanceof Tr && e.key instanceof Wn) {
                    e.key = "" + e.key.value;
                }
            }
            return Fe(Rn, r, {
                properties: c
            });
            function l() {
                f.forEach(function(e) {
                    var n = u.get(e);
                    switch (n.length) {
                      case 0:
                        return;

                      case 1:
                        return c.push(n[0]);
                    }
                    a = true;
                    var t = s && !o && n.pop();
                    c.push(n.length == 1 ? n[0] : Fe(Ar, r, {
                        key: n[0].key,
                        value: Pe(r, n.map(function(e) {
                            return e.value;
                        }))
                    }));
                    if (t) c.push(t);
                    n.length = 0;
                });
                f = [];
                u = new gn();
            }
            function p(e) {
                var n = e.key;
                if (n instanceof bn) {
                    t = true;
                    n = n.evaluate(i);
                    if (n === e.key || n === "__proto__") {
                        o = true;
                    } else {
                        n = e.key = "" + n;
                    }
                }
                if (un(e)) {
                    if (e.value.has_side_effects(i)) l();
                    f.push(n);
                    u.add(n, e);
                } else {
                    l();
                    c.push(e);
                }
                if (t && !o && typeof n == "string" && C.test(n)) {
                    o = true;
                    if (u.has(n)) e = u.get(n)[0];
                    e.key = Fe(Wn, e, {
                        value: +n
                    });
                }
            }
        });
        function cn(e) {
            var n = e.definition().redefined();
            if (n) {
                e = e.clone();
                e.thedef = n;
            }
            return e;
        }
        function ln(n, e) {
            var t = false;
            e.walk(new Gn(function(e) {
                if (t) return true;
                if (e instanceof Ln && n.variables.get(e.name) === e.definition()) {
                    return t = true;
                }
            }));
            return t;
        }
        function pn(e, t) {
            var r = [];
            e.references.forEach(function(e) {
                var n = e.fixed;
                if (!n || !nt(r, n)) return;
                if (n.assigns) {
                    n.assigns.unshift(t);
                } else {
                    n.assigns = [ t ];
                }
            });
        }
        function dn(e, n) {
            var t = Fe(Ln, n);
            var r = Fe(In, n, {
                operator: "=",
                left: t,
                right: Fe(Qr, n).transform(e)
            });
            var i = n.definition();
            if (i.fixed) {
                t.fixed = function() {
                    return r.right;
                };
                t.fixed.assigns = [ r ];
                pn(i, r);
            }
            i.assignments++;
            i.references.push(t);
            return r;
        }
        (function(e) {
            e(bn, Kn);
            e(In, Kn);
            e(wr, function(t, e, n, r) {
                if (!t.option("awaits")) return;
                var i = this;
                var a = i.expression.try_inline(t, e, n, r, true);
                if (!a) return;
                if (!n) y(a, function(e) {
                    e.in_bool = false;
                    var n = e.value;
                    if (n instanceof wr) return;
                    e.value = Fe(wr, i, {
                        expression: n || Fe(Qr, e).transform(t)
                    });
                });
                return U(a) ? a : Fe(xn, i, {
                    body: [ a, Fe(wn, i, {
                        body: Fe(wr, i, {
                            expression: Fe(Wn, i, {
                                value: 0
                            })
                        })
                    }) ]
                });
            });
            e(jn, function(n, e, t, r, i) {
                if (t === undefined) return;
                var a = this;
                var o = a.operator;
                if (!He[o]) return;
                var s = a.right.try_inline(n, e, t, r, i);
                if (!s) return;
                return Fe(Tn, a, {
                    condition: f(a.left),
                    body: s,
                    alternative: t ? null : Fe(Sn, a, {
                        value: Fe(Qr, a).transform(n)
                    })
                });
                function f(e) {
                    switch (o) {
                      case "&&":
                        return e;

                      case "||":
                        return e.negate(n);

                      case "??":
                        return Fe(jn, a, {
                            operator: "==",
                            left: Fe(Xr, a),
                            right: e
                        });
                    }
                }
            });
            e(xn, function(e, n, t, r) {
                if (t) return;
                if (!this.variables) return;
                var i = this.body;
                var a = i.length - 1;
                if (a < 0) return;
                var o = i[a].try_inline(e, this, t, r);
                if (!o) return;
                i[a] = o;
                return this;
            });
            e(qn, function(r, i, e, a, n) {
                if (r.option("inline") < 4) return;
                var o = this;
                if (o.is_expr_pure(r)) return;
                var s = o.expression;
                if (!(s instanceof Tt)) return;
                if (s.name) return;
                if (s.uses_arguments) return;
                if (s.pinned()) return;
                if (qt(s)) return;
                var f = At(s);
                if (f && s.value) return;
                if (s.body[0] instanceof ft) return;
                if (s.contains_this()) return;
                if (!i) i = Me(r);
                var t = new gn();
                t.set("NaN", true);
                while (!(i instanceof kn)) {
                    i.variables.each(function(e) {
                        t.set(e.name, true);
                    });
                    i = i.parent_scope;
                }
                if (!Jn(i, r.stack)) return;
                if (i.pinned() && s.variables.size() > (f ? 0 : 1)) return;
                if (i instanceof kt) {
                    if (s.variables.size() > (f ? 0 : 1)) {
                        if (!r.toplevel.vars) return;
                        if (s.functions.size() > 0 && !r.toplevel.funcs) return;
                    }
                    t.set("arguments", true);
                }
                var u = !n && Dt(s);
                if (u) {
                    if (!r.option("awaits")) return;
                    if (!Dt(i)) return;
                    if (o.may_throw(r)) return;
                }
                var c = i.var_names();
                if (a) a = [];
                if (!s.variables.all(function(e, n) {
                    if (a) a.push(e);
                    if (!t.has(n) && !c.has(n)) return true;
                    return !f && n == "arguments" && e.orig.length == 1;
                })) return;
                if (a && a.length > 0 && an(s, a)) return;
                var l = true;
                if (!_n(s.argnames, function(e) {
                    var n = false;
                    var t = new Gn(function(e) {
                        if (n) return true;
                        if (e instanceof Dn) {
                            if (ln(s, e.value)) return n = true;
                            e.name.walk(t);
                            return true;
                        }
                        if (e instanceof Er) {
                            if (e.key instanceof bn && ln(s, e.key)) return n = true;
                            e.value.walk(t);
                            return true;
                        }
                        if (e instanceof Bn && !_n(e.definition().orig, function(e) {
                            return !(e instanceof jr);
                        })) return n = true;
                    });
                    e.walk(t);
                    if (n) return false;
                    if (!(e instanceof Bn)) l = false;
                    return true;
                })) return;
                if (s.rest) {
                    if (ln(s, s.rest)) return;
                    l = false;
                }
                var p;
                if (e) {
                    p = function(e) {
                        var n = false;
                        e.walk(new Gn(function(e) {
                            if (n) return true;
                            if (u && (e instanceof wr || e instanceof wt) || e instanceof Sn) {
                                return n = true;
                            }
                            if (e instanceof kn) return true;
                        }));
                        return !n;
                    };
                } else if (n || Dt(s) || R(i)) {
                    p = function(e) {
                        var n = false;
                        var t = new Gn(function(e) {
                            if (n) return true;
                            if (e instanceof Sn) return n = true;
                            if (e instanceof kn) return true;
                        });
                        e.walk(new Gn(function(e) {
                            if (n) return true;
                            if (e instanceof sr) {
                                if (e.bfinally && _n(e.body, function(e) {
                                    e.walk(t);
                                    return !n;
                                }) && e.bcatch) e.bcatch.walk(t);
                                return true;
                            }
                            if (e instanceof kn) return true;
                        }));
                        return !n;
                    };
                }
                if (p && !_n(s.body, p)) return;
                if (!Ee(s, ve(r, i))) return;
                s.functions.each(function(e, n) {
                    i.functions.set(n, e);
                });
                var d = [];
                s.variables.each(function(n, e) {
                    if (!f && e == "arguments" && n.orig.length == 1) return;
                    c.set(e, true);
                    i.enclosed.push(n);
                    i.variables.set(e, n);
                    n.single_use = false;
                    if (!a) return;
                    if (n.references.length == n.replaced) return;
                    if (n.orig.length == n.eliminated) return;
                    if (n.orig.length == 1 && s.functions.has(e)) return;
                    if (!_n(n.orig, function(e) {
                        if (e instanceof Cr) return false;
                        if (e instanceof Bn) return !e.unused && n.scope.resolve() !== s;
                        if (e instanceof Fr) return false;
                        return true;
                    })) return;
                    var t = n.orig[0];
                    if (t instanceof Hr) return;
                    d.push(Fe(wn, t, {
                        body: dn(r, cn(t))
                    }));
                });
                var h = Object.create(null), v = new gn();
                if (l && _n(o.args, function(e) {
                    return !(e instanceof Mn);
                })) {
                    var m = o.args.slice();
                    s.argnames.forEach(function(e) {
                        var n = m.shift();
                        if (e.unused) {
                            if (n) d.push(Fe(wn, o, {
                                body: n
                            }));
                            return;
                        }
                        var t = Fe(An, o, {
                            name: e.convert_symbol(Pr, g),
                            value: n || Fe(Qr, o).transform(r)
                        });
                        if (e instanceof Bn) pn(e.definition(), t);
                        d.push(Fe(dr, o, {
                            definitions: [ t ]
                        }));
                    });
                    if (m.length) d.push(Fe(wn, o, {
                        body: Pe(o, m)
                    }));
                } else {
                    d.push(Fe(dr, o, {
                        definitions: [ Fe(An, o, {
                            name: Fe(kr, o, {
                                elements: s.argnames.map(function(e) {
                                    if (e.unused) return Fe(Zr, e);
                                    return e.convert_symbol(Pr, g);
                                }),
                                rest: s.rest && s.rest.convert_symbol(Pr, g)
                            }),
                            value: Fe(Hn, o, {
                                elements: o.args.slice()
                            })
                        }) ]
                    }));
                }
                v.each(function(e, n) {
                    var t = h[n];
                    [].unshift.apply(t.orig, e);
                    t.eliminated += e.length;
                });
                [].push.apply(d, a ? s.body.filter(function(e) {
                    if (!(e instanceof jt)) return true;
                    var n = Fe(Pr, cn(e.name));
                    var t = n.definition();
                    t.fixed = false;
                    t.orig.push(n);
                    t.eliminated++;
                    d.push(Fe(dr, e, {
                        definitions: [ Fe(An, e, {
                            name: n,
                            value: ye(e, true)
                        }) ]
                    }));
                    return false;
                }) : s.body);
                var _ = Fe(xn, o, {
                    body: d
                });
                if (!e) {
                    if (u) y(_, function(e) {
                        var n = e.value;
                        if (Ie(n)) return;
                        e.value = Fe(wr, o, {
                            expression: n
                        });
                    });
                    d.push(Fe(Sn, o, {
                        value: R(i) ? Fe(Qr, o).transform(r) : null
                    }));
                }
                return _;
                function g(e, n) {
                    var t = n.definition();
                    h[t.id] = t;
                    v.add(t.id, e);
                }
            });
            e(Nn, function(e, n, t, r, i) {
                var a = this;
                var o = a.consequent.try_inline(e, n, t, r, i);
                var s = a.alternative.try_inline(e, n, t, r, i);
                if (!o && !s) return;
                return Fe(Tn, a, {
                    condition: a.condition,
                    body: o || f(a.consequent),
                    alternative: s || f(a.alternative)
                });
                function f(e) {
                    if (t) return Fe(wn, e, {
                        body: e
                    });
                    return Fe(Sn, e, {
                        value: e
                    });
                }
            });
            e(gt, function(e, n, t, r) {
                var i = this.body.try_inline(e, n, true, true);
                if (i) this.body = i;
                var a = this.init;
                if (a) {
                    a = a.try_inline(e, n, true, r);
                    if (a) {
                        this.init = null;
                        if (a instanceof xn) {
                            a.body.push(this);
                            return a;
                        }
                        return Fe(xn, a, {
                            body: [ a, this ]
                        });
                    }
                }
                return i && this;
            });
            e(bt, function(e, n, t, r) {
                var i = this.body.try_inline(e, n, true, true);
                if (i) this.body = i;
                var a = this.object;
                if (a instanceof On) {
                    var o = f(e, n, true, r, false, a, 1);
                    if (o) {
                        this.object = a.tail_node();
                        o.body.push(this);
                        return o;
                    }
                }
                return i && this;
            });
            e(Tn, function(e, n, t, r) {
                var i = this.body.try_inline(e, n, t, r);
                if (i) this.body = i;
                var a = this.alternative;
                if (a) {
                    a = a.try_inline(e, n, t, r);
                    if (a) this.alternative = a;
                }
                var o = this.condition;
                if (o instanceof On) {
                    var s = f(e, n, true, r, false, o, 1);
                    if (s) {
                        this.condition = o.tail_node();
                        s.body.push(this);
                        return s;
                    }
                }
                return (i || a) && this;
            });
            e(ht, function(e, n, t, r) {
                var i = this.body.try_inline(e, n, true, true);
                if (!i) return;
                this.body = i;
                return this;
            });
            e(dt, function(e, n, t, r) {
                var i = this.body.try_inline(e, n, t, r);
                if (!i) return;
                if (this.body instanceof ht && i instanceof xn) {
                    var a = i.body.pop();
                    this.body = a;
                    i.body.push(this);
                    return i;
                }
                this.body = i;
                return this;
            });
            e(gr, Kn);
            e(Sn, function(e, n, t, r) {
                var i = this.value;
                return i && i.try_inline(e, n, undefined, r === "try");
            });
            function f(e, n, t, r, i, a, o) {
                var s = [], f = a.expressions, u = t;
                for (var c = f.length - (o || 0), l = c; --c >= 0; u = true, i = false) {
                    var p = f[c].try_inline(e, n, u, r, i);
                    if (!p) continue;
                    d();
                    s.push(p);
                }
                if (s.length == 0) return;
                d();
                if (!t && s[0] instanceof wn) {
                    s[0] = Fe(Sn, a, {
                        value: s[0].body
                    });
                }
                return Fe(xn, a, {
                    body: s.reverse()
                });
                function d() {
                    if (l > c + 1) s.push(Fe(wn, a, {
                        body: Pe(a, f.slice(c + 1, l))
                    }));
                    l = c;
                }
            }
            e(On, function(e, n, t, r, i) {
                return f(e, n, t, r, i, this);
            });
            e(wn, function(e, n, t, r) {
                var i = this.body;
                while (i instanceof Pn) {
                    var a = i.operator;
                    if (pi[a]) break;
                    if (a == "void") break;
                    i = i.expression;
                }
                if (!t && !Ie(i)) i = Fe(Pn, this, {
                    operator: "void",
                    expression: i
                });
                return i.try_inline(e, n, t || false, r);
            });
            e(Pn, function(t, e, n, r, i) {
                var a = this;
                var o = a.operator;
                if (pi[o]) return;
                if (!n && o == "void") n = false;
                var s = a.expression.try_inline(t, e, n, r, i);
                if (!s) return;
                if (!n) y(s, function(e) {
                    e.in_bool = false;
                    var n = e.value;
                    if (o == "void" && Ie(n)) return;
                    e.value = Fe(Pn, a, {
                        operator: o,
                        expression: n || Fe(Qr, e).transform(t)
                    });
                });
                return s;
            });
            e(xt, function(e, n, t, r) {
                var i = this.body.try_inline(e, n, t, r);
                if (i) this.body = i;
                var a = this.expression;
                if (a instanceof On) {
                    var o = f(e, n, true, r, false, a, 1);
                    if (o) {
                        this.expression = a.tail_node();
                        o.body.push(this);
                        return o;
                    }
                }
                return i && this;
            });
            e(xr, function(e, n, t, r) {
                if (!e.option("yields")) return;
                if (!this.nested) return;
                var i = this.expression;
                if (i.TYPE != "Call") return;
                var a = i.expression;
                switch (a.CTOR) {
                  case Mt:
                    a = Fe(Ct, a);
                    break;

                  case Pt:
                    a = Fe(Ft, a);
                    break;

                  default:
                    return;
                }
                i = i.clone();
                i.expression = a;
                return i.try_inline(e, n, t, r);
            });
        })(function(e, n) {
            e.DEFMETHOD("try_inline", n);
        });
        e(Sn, function(e, n) {
            var t = e.value;
            if (t && n.option("side_effects") && Ie(t, n) && !R(n.find_parent(kn))) {
                e.value = null;
            }
            return e;
        });
    })(function(e, r) {
        e.DEFMETHOD("optimize", function(e) {
            var n = this;
            if (n._optimized) return n;
            if (e.has_directive("use asm")) return n;
            var t = r(n, e);
            t._optimized = true;
            return t;
        });
    });
    /***********************************************************************

  A JavaScript tokenizer / parser / beautifier / compressor.
  https://github.com/mishoo/UglifyJS

  -------------------------------- (C) ---------------------------------

                           Author: Mihai Bazon
                         <mihai.bazon@gmail.com>
                       http://mihai.bazon.net/blog

  Distributed under the BSD license:

    Copyright 2012 (c) Mihai Bazon <mihai.bazon@gmail.com>

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

        * Redistributions of source code must retain the above
          copyright notice, this list of conditions and the following
          disclaimer.

        * Redistributions in binary form must reproduce the above
          copyright notice, this list of conditions and the following
          disclaimer in the documentation and/or other materials
          provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER “AS IS” AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE
    LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
    OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
    TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
    THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
    SUCH DAMAGE.

 ***********************************************************************/
    "use strict";
    function oe(e) {
        return e.type == "comment2" && /@preserve|@license|@cc_on/i.test(e.value);
    }
    function vi(f) {
        f = we(f, {
            annotations: false,
            ascii_only: false,
            beautify: false,
            braces: false,
            comments: false,
            extendscript: false,
            galio: false,
            ie: false,
            indent_level: 4,
            indent_start: 0,
            inline_script: true,
            keep_quoted_props: false,
            max_line_len: false,
            preamble: null,
            preserve_line: false,
            quote_keys: false,
            quote_style: 0,
            semicolons: true,
            shebang: true,
            source_map: null,
            v8: false,
            webkit: false,
            width: 80,
            wrap_iife: false
        }, true);
        var u = hn;
        if (f.comments) {
            var n = f.comments;
            if (typeof f.comments === "string" && /^\/.*\/[a-zA-Z]*$/.test(f.comments)) {
                var e = f.comments.lastIndexOf("/");
                n = new RegExp(f.comments.substr(1, e - 1), f.comments.substr(e + 1));
            }
            if (n instanceof RegExp) {
                u = function(e) {
                    return e.type != "comment5" && n.test(e.value);
                };
            } else if (typeof n === "function") {
                u = function(e) {
                    return e.type != "comment5" && n(this, e);
                };
            } else if (n === "some") {
                u = oe;
            } else {
                u = vn;
            }
        }
        function t(e) {
            if (typeof e == "number") return new Array(e + 1).join(" ");
            if (!e) return "";
            if (!/^\s*$/.test(e)) throw new Error("unsupported indentation: " + JSON.stringify("" + e));
            return e;
        }
        var c = 0;
        var l = 1;
        var r = t(f.indent_start);
        var i = t(f.indent_level);
        var P = i.length + 1 >> 1;
        var o;
        var s = 0;
        var p = true;
        var d = f.source_map && [];
        var h;
        var v;
        var m;
        var _;
        var g = false;
        var b = false;
        var y;
        var a;
        var w = "";
        function x() {
            o = "";
            m = false;
            _ = false;
            a = [];
            var e = y;
            y = "";
            return e;
        }
        x();
        var k = f.ascii_only ? function(e, t) {
            if (t) e = e.replace(/[\ud800-\udbff][\udc00-\udfff]/g, function(e) {
                return "\\u{" + (e.charCodeAt(0) - 55232 << 10 | e.charCodeAt(1) - 56320).toString(16) + "}";
            });
            return e.replace(/[\u0000-\u001f\u007f-\uffff]/g, function(e) {
                var n = e.charCodeAt(0).toString(16);
                if (n.length <= 2 && !t) {
                    while (n.length < 2) n = "0" + n;
                    return "\\x" + n;
                } else {
                    while (n.length < 4) n = "0" + n;
                    return "\\u" + n;
                }
            });
        } : function(e) {
            var n = "";
            for (var t = 0, r = 0; t < e.length; t++) {
                var i = e.charCodeAt(t);
                if (re(i)) {
                    if (ie(e.charCodeAt(t + 1))) {
                        t++;
                        continue;
                    }
                } else if (!ie(i)) {
                    continue;
                }
                n += e.slice(r, t) + "\\u" + i.toString(16);
                r = t + 1;
            }
            return r == 0 ? e : n + e.slice(r);
        };
        function E(e) {
            return "'" + e.replace(/\x27/g, "\\'") + "'";
        }
        function S(e) {
            return '"' + e.replace(/\x22/g, '\\"') + '"';
        }
        var j = [ null, E, S, function(e, n) {
            return n == "'" ? E(e) : S(e);
        } ][f.quote_style] || function(e, n, t, r) {
            return t > r ? E(e) : S(e);
        };
        function T(t, e) {
            var r = 0, i = 0;
            t = t.replace(/[\\\b\f\n\r\v\t\x22\x27\u2028\u2029\0\ufeff]/g, function(e, n) {
                switch (e) {
                  case '"':
                    ++r;
                    return '"';

                  case "'":
                    ++i;
                    return "'";

                  case "\\":
                    return "\\\\";

                  case "\n":
                    return "\\n";

                  case "\r":
                    return "\\r";

                  case "\t":
                    return "\\t";

                  case "\b":
                    return "\\b";

                  case "\f":
                    return "\\f";

                  case "\v":
                    return f.ie ? "\\x0B" : "\\v";

                  case "\u2028":
                    return "\\u2028";

                  case "\u2029":
                    return "\\u2029";

                  case "\ufeff":
                    return "\\ufeff";

                  case "\0":
                    return /[0-9]/.test(t.charAt(n + 1)) ? "\\x00" : "\\0";
                }
                return e;
            });
            return j(k(t), e, r, i);
        }
        var N = d ? function(n, t) {
            d.forEach(function(e) {
                e.line += n;
                e.col += t;
            });
        } : Kn;
        var A = d ? function() {
            d.forEach(function(e) {
                f.source_map.add(e.token.file, e.line, e.col, e.token.line, e.token.col, !e.name && e.token.type == "name" ? e.token.value : e.name);
            });
            d = [];
        } : Kn;
        function D(e) {
            w += y.slice(0, s);
            y = y.slice(s);
            var n = y.length;
            N(e, n - c);
            l += e;
            c = n;
            while (e--) w += "\n";
        }
        var q = f.max_line_len ? function(e) {
            if (p) {
                if (c > f.max_line_len) {
                    bn.warn("Output exceeds {max_line_len} characters", f);
                }
                return;
            }
            if (c > f.max_line_len) {
                D(1);
                p = true;
            }
            if (p || e) A();
        } : Kn;
        var I = mn("( [ + * / - , .");
        function O(e, n, t) {
            return ae(e) && (ae(n) || n == "\\") || n == "/" && n == e || (n == "+" || n == "-") && n == o || o == "--" && n == ">" || o == "!" && t == "--" || e == "/" && (t == "in" || t == "instanceof");
        }
        var $ = f.beautify || f.comments || f.max_line_len || f.preserve_line || f.shebang || !f.semicolons || f.source_map || f.width ? function(e) {
            var n = e.charAt(0);
            if (g && n) {
                g = false;
                if (n != "\n") {
                    $("\n");
                    C();
                }
            }
            if (b && n) {
                b = false;
                if (!/[\s;})]/.test(n)) {
                    z();
                }
            }
            var t = o.slice(-1);
            if (_) {
                _ = false;
                if (t == ":" && n == "}" || t != ";" && (!n || ";}".indexOf(n) < 0)) {
                    var r = I[n];
                    if (r || f.semicolons) {
                        y += ";";
                        c++;
                        if (!p) {
                            q();
                            if (p && !r && y == ";") {
                                y = "";
                                c = 0;
                            }
                        }
                        if (s == y.length - 1) s++;
                    } else {
                        q();
                        y += "\n";
                        l++;
                        c = 0;
                        if (/^\s+$/.test(e)) _ = true;
                    }
                    if (!f.beautify) m = false;
                }
            }
            if (m) {
                if (O(t, n, e)) {
                    y += " ";
                    c++;
                }
                if (t != "<" || e != "!") m = false;
            }
            if (v) {
                d.push({
                    token: v,
                    name: h,
                    line: l,
                    col: c
                });
                v = false;
                if (p) A();
            }
            y += e;
            var i = e.split(/\r?\n/), a = i.length - 1;
            l += a;
            c += i[0].length;
            if (a > 0) {
                q();
                c = i[a].length;
            }
            o = e;
        } : function(e) {
            var n = e.charAt(0);
            var t = o.slice(-1);
            if (_) {
                _ = false;
                if (t == ":" && n == "}" || (!n || ";}".indexOf(n) < 0) && t != ";") {
                    y += ";";
                    m = false;
                }
            }
            if (m) {
                if (O(t, n, e)) y += " ";
                if (t != "<" || e != "!") m = false;
            }
            y += e;
            o = e;
        };
        var z = f.beautify ? function() {
            $(" ");
        } : function() {
            m = true;
        };
        var C = f.beautify ? function(e) {
            if (g) $("\n");
            $(e ? r.slice(0, -P) : r);
        } : Kn;
        var H = f.beautify ? function(e) {
            var n = r;
            r += i;
            e();
            r = n;
        } : function(e) {
            e();
        };
        var M = f.max_line_len || f.preserve_line ? function() {
            q();
            s = y.length;
            p = false;
        } : Kn;
        var Y = f.beautify ? function() {
            $("\n");
            s = y.length;
        } : M;
        var R = f.beautify ? function() {
            $(";");
        } : function() {
            _ = true;
        };
        function B() {
            if (_) $(";");
            $(";");
        }
        function L(e, n) {
            $("{");
            Y();
            H(e);
            J(n);
            C();
            $("}");
        }
        function U(e) {
            $("(");
            M();
            e();
            M();
            $(")");
        }
        function V(e) {
            $("[");
            M();
            e();
            M();
            $("]");
        }
        function W() {
            M();
            $(",");
            M();
            z();
        }
        function G() {
            $(":");
            z();
        }
        var J = d ? function(e, n) {
            v = e;
            h = n;
        } : Kn;
        function X() {
            if (!p) q(true);
            return w + y;
        }
        function K() {
            return /(^|\n) *$/.test(y);
        }
        function F(e, n) {
            if (g) return;
            if (e.nlb && (n || !K())) {
                g = true;
            } else if (n) {
                b = true;
            }
        }
        function Q(e) {
            var n = e.value.replace(/[@#]__PURE__/g, " ");
            if (/^\s*$/.test(n) && !/^\s*$/.test(e.value)) return false;
            if (/comment[134]/.test(e.type)) {
                $("//" + n);
                g = true;
            } else if (e.type == "comment2") {
                $("/*" + n + "*/");
            }
            return true;
        }
        function Z(e, n) {
            if (n instanceof jn) return n.left === e;
            if (n.TYPE == "Call") return n.expression === e;
            if (n instanceof Nn) return n.condition === e;
            if (n instanceof zn) return n.expression === e;
            if (n instanceof Qt) return true;
            if (n instanceof On) return n.expressions[0] === e;
            if (n instanceof Cn) return n.expression === e;
            if (n instanceof yr) return true;
            if (n instanceof xr) return true;
        }
        function ee(e) {
            var r = this;
            var i;
            if (e instanceof Qt) {
                i = e.value;
            } else if (e instanceof xr) {
                i = e.expression;
            }
            var t = s(e);
            if (!t) t = [];
            if (i) {
                var a = new Gn(function(e) {
                    if (!Z(e, a.parent())) return true;
                    var n = s(e);
                    if (n) t = t.concat(n);
                });
                a.push(e);
                i.walk(a);
            }
            if (l == 1 && c == 0) {
                if (t.length > 0 && f.shebang && t[0].type == "comment5") {
                    $("#!" + t.shift().value + "\n");
                    C();
                }
                var n = f.preamble;
                if (n) $(n.replace(/\r\n?|\u2028|\u2029|(^|\S)\s*$/g, "$1\n"));
            }
            t = t.filter(u, e);
            var o = false;
            t.forEach(function(e, n) {
                F(e, n);
                if (Q(e)) o = true;
            });
            if (o) F(e.start, true);
            function s(e) {
                var n = e.start;
                if (!n) {
                    if (!i) return;
                    e.start = n = new te();
                }
                var t = n.comments_before;
                if (!t) {
                    if (!i) return;
                    n.comments_before = t = [];
                }
                if (t._dumped === r) return;
                t._dumped = r;
                return t;
            }
        }
        function ne(e, t) {
            var n = this;
            var r = e.end;
            if (!r) return;
            var i = r[t ? "comments_before" : "comments_after"];
            if (!i || i._dumped === n) return;
            if (!(e instanceof ot || _n(i, function(e) {
                return !/comment[134]/.test(e.type);
            }))) return;
            i._dumped = n;
            i.filter(u, e).forEach(function(e, n) {
                F(e, n || !t);
                Q(e);
            });
        }
        return {
            get: X,
            reset: x,
            indent: C,
            should_break: f.beautify && f.width ? function() {
                return c >= f.width;
            } : hn,
            has_parens: function() {
                return o.slice(-1) == "(";
            },
            newline: Y,
            print: $,
            space: z,
            comma: W,
            colon: G,
            last: function() {
                return o;
            },
            semicolon: R,
            force_semicolon: B,
            to_utf8: k,
            print_name: function(e) {
                $(k(e.toString(), true));
            },
            print_string: f.inline_script ? function(e, n) {
                e = T(e, n).replace(/<\x2f(script)([>\/\t\n\f\r ])/gi, "<\\/$1$2");
                $(e.replace(/\x3c!--/g, "\\x3c!--").replace(/--\x3e/g, "--\\x3e"));
            } : function(e, n) {
                $(T(e, n));
            },
            with_indent: H,
            with_block: L,
            with_parens: U,
            with_square: V,
            add_mapping: J,
            option: function(e) {
                return f[e];
            },
            prepend_comments: f.comments || f.shebang ? ee : Kn,
            append_comments: f.comments ? ne : Kn,
            push_node: function(e) {
                a.push(e);
            },
            pop_node: f.preserve_line ? function() {
                var e = a.pop();
                if (e.start && e.start.line > l) {
                    D(e.start.line - l);
                }
            } : function() {
                a.pop();
            },
            parent: function(e) {
                return a[a.length - 2 - (e || 0)];
            }
        };
    }
    (function() {
        function e(e, n) {
            e.DEFMETHOD("_codegen", n);
        }
        var s = false;
        bn.DEFMETHOD("print", function(e, n) {
            var t = this;
            e.push_node(t);
            if (n || t.needs_parens(e)) {
                e.with_parens(r);
            } else {
                r();
            }
            e.pop_node();
            function r() {
                e.prepend_comments(t);
                t.add_source_map(e);
                t._codegen(e);
                e.append_comments(t);
            }
        });
        var t = vi({
            inline_script: false,
            shebang: false,
            width: false
        });
        bn.DEFMETHOD("print_to_string", function(e) {
            if (e) {
                var n = vi(e);
                this.print(n);
                return n.get();
            }
            this.print(t);
            return t.reset();
        });
        function n(e, n) {
            e.DEFMETHOD("needs_parens", n);
        }
        n(bn, hn);
        function r(e) {
            var n = e.parent();
            if (!e.has_parens() && at(e, false, true)) {
                return this.name || !(n instanceof vr);
            }
            if (e.option("webkit") && n instanceof $n && n.expression === this) return true;
            if (e.option("wrap_iife") && n instanceof qn && n.expression === this) return true;
        }
        n(Ct, r);
        n(Mt, r);
        n(Lt, r);
        n(Ft, r);
        n(Pt, r);
        function i(e) {
            return !e.has_parens() && at(e, true);
        }
        n(Rn, i);
        function a(e) {
            var n = e.parent();
            if (n instanceof jn) return n.operator == "**" && n.left === this;
            if (n instanceof qn) return n.expression === this;
            if (n instanceof Rt) return true;
            if (n instanceof $n) return n.expression === this;
            if (n instanceof Vr) return n.tag === this;
        }
        n(wr, a);
        n(Fn, a);
        n(On, function(e) {
            var n = e.parent();
            return n instanceof Hn || At(n) && n.value === this || n instanceof wr || n instanceof jn || n instanceof qn || n instanceof Rt || n instanceof Ut || n instanceof Nn || n instanceof Dn || n instanceof Er || n instanceof vr || n instanceof xe || n instanceof Tr || n instanceof $n && n.expression === this || n instanceof Mn || n instanceof Vr && n.tag === this || n instanceof Fn || n instanceof An || n instanceof xr;
        });
        n(jn, function(e) {
            var n = e.parent();
            if (n instanceof wr) return true;
            if (n instanceof jn) {
                var t = n.operator, r = ui[t];
                var i = this.operator, a = ui[i];
                return r > a || t == "??" && (i == "&&" || i == "||") || r == a && this === n[t == "**" ? "left" : "right"];
            }
            if (n instanceof qn) return n.expression === this;
            if (n instanceof Rt) return true;
            if (n instanceof $n) return n.expression === this;
            if (n instanceof Vr) return n.tag === this;
            if (n instanceof Fn) return true;
        });
        function o(e, n) {
            if (!e.terminal) return false;
            if (!(n instanceof qn || n instanceof $n)) return false;
            return n.expression === e;
        }
        n($n, function(e) {
            var n = this;
            var t = e.parent();
            if (t instanceof gr && t.expression === n && br(n).TYPE == "Call") return true;
            return o(n, t);
        });
        n(qn, function(e) {
            var n = this;
            var t = e.parent();
            if (t instanceof gr) return t.expression === n;
            if (e.option("webkit") && n.expression instanceof Ft && t instanceof $n && t.expression === n) {
                var r = e.parent(1);
                if (r instanceof In && r.left === t) return true;
            }
            return o(n, t);
        });
        n(gr, function(e) {
            if (z(this, e)) return false;
            var n = e.parent();
            if (n instanceof qn) return n.expression === this;
            if (n instanceof $n) return true;
            if (n instanceof Vr) return n.tag === this;
        });
        n(Wn, function(e) {
            if (!e.option("galio")) return false;
            var n = e.parent();
            return n instanceof $n && n.expression === this && /^0/.test(C(this.value));
        });
        function f(e, n) {
            var t = n.parent();
            if (t instanceof wr) return true;
            if (t instanceof jn) return !(t instanceof In);
            if (t instanceof qn) return t.expression === e;
            if (t instanceof Rt) return true;
            if (t instanceof Nn) return t.condition === e;
            if (t instanceof $n) return t.expression === e;
            if (t instanceof Vr) return t.tag === e;
            if (t instanceof Fn) return true;
        }
        n($t, function(e) {
            return f(this, e);
        });
        n(In, function(e) {
            if (f(this, e)) return true;
            if (e.option("v8")) return this.left instanceof Yn;
            if (this.left instanceof Sr) return i(e);
        });
        n(zt, function(e) {
            return f(this, e);
        });
        n(Nn, function(e) {
            return f(this, e) || e.option("extendscript") && e.parent() instanceof Nn;
        });
        n(xr, function(e) {
            return f(this, e);
        });
        e(ft, function(e) {
            var n = this.quote;
            var t = this.value;
            switch (e.option("quote_style")) {
              case 0:
              case 2:
                if (t.indexOf('"') == -1) n = '"';
                break;

              case 1:
                if (t.indexOf("'") == -1) n = "'";
                break;
            }
            e.print(n + t + n);
            e.semicolon();
        });
        e(st, function(e) {
            e.print("debugger");
            e.semicolon();
        });
        function u(e, t, r, n) {
            var i = e.length - 1;
            var a = n;
            var o = s;
            e.forEach(function(e, n) {
                if (a) {
                    if (e instanceof ft) {
                        if (e.value == "use asm") s = true;
                    } else if (!(e instanceof yn)) {
                        if (e instanceof wn && e.body instanceof Vn) {
                            r.force_semicolon();
                        }
                        a = false;
                    }
                }
                if (e instanceof yn) return;
                r.indent();
                e.print(r);
                if (n == i && t) return;
                r.newline();
                if (t) r.newline();
            });
            s = o;
        }
        e(kt, function(e) {
            u(this.body, true, e, true);
            e.print("");
        });
        e(dt, function(e) {
            this.label.print(e);
            e.colon();
            this.body.print(e);
        });
        e(wn, function(e) {
            this.body.print(e);
            e.semicolon();
        });
        function c(e, n) {
            n.print("{");
            n.with_indent(function() {
                n.append_comments(e, true);
            });
            n.print("}");
        }
        function l(e, n, t) {
            if (e.body.length > 0) {
                n.with_block(function() {
                    u(e.body, false, n, t);
                }, e.end);
            } else c(e, n);
        }
        e(xn, function(e) {
            l(this, e);
        });
        e(yn, function(e) {
            e.semicolon();
        });
        e(mt, function(e) {
            var n = this;
            e.print("do");
            M(n.body, e);
            e.space();
            e.print("while");
            e.space();
            e.with_parens(function() {
                n.condition.print(e);
            });
            e.semicolon();
        });
        e(_t, function(e) {
            var n = this;
            e.print("while");
            e.space();
            e.with_parens(function() {
                n.condition.print(e);
            });
            $(n.body, e);
        });
        e(gt, function(e) {
            var n = this;
            e.print("for");
            e.space();
            e.with_parens(function() {
                if (n.init) {
                    if (n.init instanceof cr) {
                        n.init.print(e);
                    } else {
                        E(n.init, e, true);
                    }
                    e.print(";");
                    e.space();
                } else {
                    e.print(";");
                }
                if (n.condition) {
                    n.condition.print(e);
                    e.print(";");
                    e.space();
                } else {
                    e.print(";");
                }
                if (n.step) {
                    n.step.print(e);
                }
            });
            $(n.body, e);
        });
        function p(t, r) {
            return function(e) {
                var n = this;
                e.print(t);
                e.space();
                e.with_parens(function() {
                    n.init.print(e);
                    e.space();
                    e.print(r);
                    e.space();
                    n.object.print(e);
                });
                $(n.body, e);
            };
        }
        e(wt, p("for await", "of"));
        e(yt, p("for", "in"));
        e(xe, p("for", "of"));
        e(xt, function(e) {
            var n = this;
            e.print("with");
            e.space();
            e.with_parens(function() {
                n.expression.print(e);
            });
            $(n.body, e);
        });
        e(hr, function(e) {
            e.print("export");
            e.space();
            this.body.print(e);
        });
        e(vr, function(e) {
            e.print("export");
            e.space();
            e.print("default");
            e.space();
            var n = this.body;
            n.print(e);
            if (n instanceof Lt) {
                if (!n.name) return;
            }
            if (n instanceof Bt) return;
            if (n instanceof jt) return;
            if (n instanceof Tt) {
                if (!n.name && !At(n)) return;
            }
            e.semicolon();
        });
        function d(e, n) {
            var t = e.value;
            if (t == "*" || ai(t)) {
                n.print_name(t);
            } else {
                n.print_string(t, e.quote);
            }
        }
        e(ke, function(r) {
            var i = this;
            r.print("export");
            r.space();
            var n = i.keys.length;
            if (n == 0) {
                c(i, r);
            } else if (i.keys[0].value == "*") {
                t(0);
            } else r.with_block(function() {
                r.indent();
                t(0);
                for (var e = 1; e < n; e++) {
                    r.print(",");
                    r.newline();
                    r.indent();
                    t(e);
                }
                r.newline();
            }, i.end);
            r.space();
            r.print("from");
            r.space();
            i.path.print(r);
            r.semicolon();
            function t(e) {
                var n = i.aliases[e];
                var t = i.keys[e];
                d(t, r);
                if (n.value != t.value) {
                    r.space();
                    r.print("as");
                    r.space();
                    d(n, r);
                }
            }
        });
        e(mr, function(e) {
            var n = this;
            e.print("export");
            e.space();
            A(n, e);
            e.semicolon();
        });
        e(_r, function(e) {
            var n = this;
            e.print("import");
            e.space();
            if (n.default) n.default.print(e);
            if (n.all) {
                if (n.default) e.comma();
                n.all.print(e);
            }
            if (n.properties) {
                if (n.default) e.comma();
                A(n, e);
            }
            if (n.all || n.default || n.properties) {
                e.space();
                e.print("from");
                e.space();
            }
            n.path.print(e);
            e.semicolon();
        });
        function h(e, t) {
            t.with_parens(function() {
                e.argnames.forEach(function(e, n) {
                    if (n) t.comma();
                    e.print(t);
                });
                if (e.rest) {
                    if (e.argnames.length) t.comma();
                    t.print("...");
                    e.rest.print(t);
                }
            });
        }
        function v(e, n) {
            var t = e.argnames.length == 1 && !e.rest && e.argnames[0];
            if (t instanceof Bn && t.name != "yield") {
                t.print(n);
            } else {
                h(e, n);
            }
            n.space();
            n.print("=>");
            n.space();
            if (e.value) {
                e.value.print(n);
            } else {
                l(e, n, true);
            }
        }
        e($t, function(e) {
            v(this, e);
        });
        e(zt, function(e) {
            e.print("async");
            e.space();
            v(this, e);
        });
        function m(e, n) {
            if (e.name) {
                n.space();
                e.name.print(n);
            }
            h(e, n);
            n.space();
            l(e, n, true);
        }
        e(En, function(e) {
            e.print("function");
            m(this, e);
        });
        function _(e) {
            e.print("async");
            e.space();
            e.print("function");
            m(this, e);
        }
        e(Nt, _);
        e(Ct, _);
        function g(e) {
            e.print("async");
            e.space();
            e.print("function*");
            m(this, e);
        }
        e(It, g);
        e(Mt, g);
        function b(e) {
            e.print("function*");
            m(this, e);
        }
        e(Yt, b);
        e(Pt, b);
        e(Rt, function(e) {
            var n = this;
            e.print("class");
            if (n.name) {
                e.space();
                n.name.print(e);
            }
            if (n.extends) {
                e.space();
                e.print("extends");
                e.space();
                n.extends.print(e);
            }
            e.space();
            A(n, e, true);
        });
        e(Vt, function(e) {
            var n = this;
            if (n.static) {
                e.print("static");
                e.space();
            }
            D(n, e);
            if (n.value) {
                e.space();
                e.print("=");
                e.space();
                n.value.print(e);
            }
            e.semicolon();
        });
        e(Wt, q("get"));
        e(Gt, q("set"));
        function y(e, n) {
            var t = e.value;
            if (Dt(t)) {
                n.print("async");
                n.space();
            }
            if (qt(t)) n.print("*");
            D(e, n);
            m(e.value, n);
        }
        e(Jt, function(e) {
            var n = this;
            if (n.static) {
                e.print("static");
                e.space();
            }
            y(n, e);
        });
        e(Xt, function(e) {
            e.print("static");
            e.space();
            l(this.value, e);
        });
        function w(t, r) {
            return function(e) {
                e.print(t);
                var n = this[r];
                if (n) {
                    e.space();
                    n.print(e);
                }
                e.semicolon();
            };
        }
        e(Sn, w("return", "value"));
        e(Zt, w("throw", "value"));
        e(nr, w("break", "label"));
        e(tr, w("continue", "label"));
        function P(e, n) {
            var t = e.body;
            if (n.option("braces") && !(t instanceof lr || t instanceof pr) || n.option("ie") && t instanceof mt) return M(t, n);
            if (!t) return n.force_semicolon();
            while (true) {
                if (t instanceof Tn) {
                    if (!t.alternative) {
                        M(e.body, n);
                        return;
                    }
                    t = t.alternative;
                } else if (t instanceof N) {
                    t = t.body;
                } else break;
            }
            $(e.body, n);
        }
        e(Tn, function(e) {
            var n = this;
            e.print("if");
            e.space();
            e.with_parens(function() {
                n.condition.print(e);
            });
            if (n.alternative) {
                P(n, e);
                e.space();
                e.print("else");
                if (n.alternative instanceof Tn) {
                    e.space();
                    n.alternative.print(e);
                } else {
                    $(n.alternative, e);
                }
            } else {
                $(n.body, e);
            }
        });
        e(rr, function(t) {
            var e = this;
            t.print("switch");
            t.space();
            t.with_parens(function() {
                e.expression.print(t);
            });
            t.space();
            var r = e.body.length - 1;
            if (r < 0) c(e, t); else t.with_block(function() {
                e.body.forEach(function(e, n) {
                    t.indent(true);
                    e.print(t);
                    if (n < r && e.body.length > 0) t.newline();
                });
            }, e.end);
        });
        function x(e, n) {
            n.newline();
            e.body.forEach(function(e) {
                n.indent();
                e.print(n);
                n.newline();
            });
        }
        e(ar, function(e) {
            e.print("default:");
            x(this, e);
        });
        e(or, function(e) {
            var n = this;
            e.print("case");
            e.space();
            n.expression.print(e);
            e.print(":");
            x(n, e);
        });
        e(sr, function(e) {
            var n = this;
            e.print("try");
            e.space();
            l(n, e);
            if (n.bcatch) {
                e.space();
                n.bcatch.print(e);
            }
            if (n.bfinally) {
                e.space();
                n.bfinally.print(e);
            }
        });
        e(fr, function(e) {
            var n = this;
            e.print("catch");
            if (n.argname) {
                e.space();
                e.with_parens(function() {
                    n.argname.print(e);
                });
            }
            e.space();
            l(n, e);
        });
        e(ur, function(e) {
            e.print("finally");
            e.space();
            l(this, e);
        });
        function k(r) {
            return function(t) {
                var e = this;
                t.print(r);
                t.space();
                e.definitions.forEach(function(e, n) {
                    if (n) t.comma();
                    e.print(t);
                });
                var n = t.parent();
                if (!(n instanceof ht && n.init === e)) t.semicolon();
            };
        }
        e(lr, k("const"));
        e(pr, k("let"));
        e(dr, k("var"));
        function E(e, n, t) {
            var r = false;
            if (t) e.walk(new Gn(function(e) {
                if (r) return true;
                if (e instanceof jn && e.operator == "in") return r = true;
                if (e instanceof kn && !(At(e) && e.value)) return true;
            }));
            e.print(n, r);
        }
        e(An, function(e) {
            var n = this;
            n.name.print(e);
            if (n.value) {
                e.space();
                e.print("=");
                e.space();
                var t = e.parent(1);
                var r = t instanceof gt || t instanceof bt;
                E(n.value, e, r);
            }
        });
        e(Dn, function(e) {
            var n = this;
            n.name.print(e);
            e.space();
            e.print("=");
            e.space();
            n.value.print(e);
        });
        function S(e, n) {
            if (!n.option("annotations")) return;
            if (!e.pure) return;
            var t = 0, r = e, i;
            do {
                i = r;
                r = n.parent(t++);
                if (r instanceof qn && r.expression === i) return;
            } while (r instanceof $n && r.expression === i);
            n.print("/*@__PURE__*/");
        }
        function T(e, t) {
            t.with_parens(function() {
                e.args.forEach(function(e, n) {
                    if (n) t.comma();
                    e.print(t);
                });
                t.add_mapping(e.end);
            });
        }
        e(qn, function(e) {
            var n = this;
            S(n, e);
            n.expression.print(e);
            if (n.optional) e.print("?.");
            T(n, e);
        });
        e(gr, function(e) {
            var n = this;
            S(n, e);
            e.print("new");
            e.space();
            n.expression.print(e);
            if (z(n, e)) T(n, e);
        });
        e(On, function(t) {
            this.expressions.forEach(function(e, n) {
                if (n > 0) {
                    t.comma();
                    if (t.should_break()) {
                        t.newline();
                        t.indent();
                    }
                }
                e.print(t);
            });
        });
        e(zn, function(e) {
            var n = this;
            var t = n.expression;
            t.print(e);
            var r = n.property;
            if (e.option("ie") && I[r] || n.quoted && e.option("keep_quoted_props")) {
                if (n.optional) e.print("?.");
                e.with_square(function() {
                    e.add_mapping(n.end);
                    e.print_string(r);
                });
            } else {
                if (t instanceof Wn && !/[ex.)]/i.test(e.last())) e.print(".");
                e.print(n.optional ? "?." : ".");
                e.add_mapping(n.end);
                e.print_name(r);
            }
        });
        e(Cn, function(e) {
            var n = this;
            n.expression.print(e);
            if (n.optional) e.print("?.");
            e.with_square(function() {
                n.property.print(e);
            });
        });
        e(Mn, function(e) {
            e.print("...");
            this.expression.print(e);
        });
        e(Pn, function(e) {
            var n = this.operator;
            var t = this.expression;
            e.print(n);
            if (/^[a-z]/i.test(n) || /[+-]$/.test(n) && t instanceof Pn && /^[+-]/.test(t.operator)) {
                e.space();
            }
            t.print(e);
        });
        e(yr, function(e) {
            var n = this;
            n.expression.print(e);
            e.add_mapping(n.end);
            e.print(n.operator);
        });
        e(jn, function(e) {
            var n = this;
            n.left.print(e);
            e.space();
            e.print(n.operator);
            e.space();
            n.right.print(e);
        });
        e(Nn, function(e) {
            var n = this;
            n.condition.print(e);
            e.space();
            e.print("?");
            e.space();
            n.consequent.print(e);
            e.space();
            e.colon();
            n.alternative.print(e);
        });
        e(wr, function(e) {
            e.print("await");
            e.space();
            this.expression.print(e);
        });
        e(xr, function(e) {
            e.print(this.nested ? "yield*" : "yield");
            if (this.expression) {
                e.space();
                this.expression.print(e);
            }
        });
        e(Hn, function(t) {
            var e = this.elements, r = e.length;
            t.with_square(r > 0 ? function() {
                t.space();
                e.forEach(function(e, n) {
                    if (n) t.comma();
                    e.print(t);
                    if (n === r - 1 && e instanceof Zr) t.comma();
                });
                t.space();
            } : Kn);
        });
        e(kr, function(t) {
            var e = this.elements, n = e.length, r = this.rest;
            t.with_square(n || r ? function() {
                t.space();
                e.forEach(function(e, n) {
                    if (n) t.comma();
                    e.print(t);
                });
                if (r) {
                    if (n) t.comma();
                    t.print("...");
                    r.print(t);
                } else if (e[n - 1] instanceof Zr) {
                    t.comma();
                }
                t.space();
            } : Kn);
        });
        e(Er, function(e) {
            var n = this;
            var t = D(n, e);
            var r = n.value;
            if (t) {
                if (r instanceof Dn) {
                    if (r.name instanceof $r && t == O(r.name)) {
                        e.space();
                        e.print("=");
                        e.space();
                        r.value.print(e);
                        return;
                    }
                } else if (r instanceof $r) {
                    if (t == O(r)) return;
                }
            }
            e.colon();
            r.print(e);
        });
        e(Sr, function(t) {
            var e = this;
            var n = e.properties, r = n.length, i = e.rest;
            if (r || i) t.with_block(function() {
                n.forEach(function(e, n) {
                    if (n) {
                        t.print(",");
                        t.newline();
                    }
                    t.indent();
                    e.print(t);
                });
                if (i) {
                    if (r) {
                        t.print(",");
                        t.newline();
                    }
                    t.indent();
                    t.print("...");
                    i.print(t);
                }
                t.newline();
            }, e.end); else c(e, t);
        });
        function A(e, t, r) {
            var n = e.properties;
            if (n.length > 0) t.with_block(function() {
                n.forEach(function(e, n) {
                    if (n) {
                        if (!r) t.print(",");
                        t.newline();
                    }
                    t.indent();
                    e.print(t);
                });
                t.newline();
            }, e.end); else c(e, t);
        }
        e(Rn, function(e) {
            A(this, e);
        });
        function D(e, n) {
            var t = e.key;
            if (t instanceof bn) return n.with_square(function() {
                t.print(n);
            });
            var r = e.start && e.start.quote;
            if (n.option("quote_keys") || r && n.option("keep_quoted_props")) {
                n.print_string(t, r);
            } else if ("" + +t == t && t >= 0) {
                n.print(C(t));
            } else if (e.private) {
                n.print_name(t);
            } else if (I[t] ? !n.option("ie") : ai(t)) {
                n.print_name(t);
                return t;
            } else {
                n.print_string(t, r);
            }
        }
        e(Ar, function(e) {
            var n = this;
            D(n, e);
            e.colon();
            n.value.print(e);
        });
        e(Dr, function(e) {
            y(this, e);
        });
        function q(t) {
            return function(e) {
                var n = this;
                if (n.static) {
                    e.print("static");
                    e.space();
                }
                e.print(t);
                e.space();
                D(n, e);
                m(n.value, e);
            };
        }
        e(Or, q("get"));
        e(qr, q("set"));
        function O(e) {
            var n = e.definition();
            return n && n.mangled_name || e.name;
        }
        e($r, function(e) {
            e.print_name(O(this));
        });
        e(Yr, function(e) {
            var n = this;
            var t = O(n);
            e.print_name(t);
            var r = n.alias;
            if (r.value != t) {
                e.space();
                e.print("as");
                e.space();
                d(r, e);
            }
        });
        e(Mr, function(e) {
            var n = this;
            var t = O(n);
            var r = n.key;
            if (r.value && r.value != t) {
                d(r, e);
                e.space();
                e.print("as");
                e.space();
            }
            e.print_name(t);
        });
        e(Zr, Kn);
        e(Vr, function(e) {
            var n = this;
            if (n.tag) n.tag.print(e);
            e.print("`");
            for (var t = 0; t < n.expressions.length; t++) {
                e.print(n.strings[t]);
                e.print("${");
                n.expressions[t].print(e);
                e.print("}");
            }
            e.print(n.strings[t]);
            e.print("`");
        });
        e(Un, function(e) {
            e.print("" + this.value);
        });
        e(Vn, function(e) {
            e.print_string(this.value, this.quote);
        });
        e(Wn, function(e) {
            var n = this.start;
            if (s && n && n.raw != null) {
                e.print(n.raw);
            } else {
                e.print(C(this.value));
            }
        });
        e(Gr, function(e) {
            var n = this.value;
            var t = n.toString();
            var r = t.lastIndexOf("/");
            if (n.raw_source) {
                t = "/" + n.raw_source + t.slice(r);
            } else if (r == 1) {
                t = "/(?:)" + t.slice(r);
            } else if (t.indexOf("/", 1) < r) {
                t = "/" + t.slice(1, r).replace(/\\\\|[^/]?\//g, function(e) {
                    return e[0] == "\\" ? e : e.slice(0, -1) + "\\/";
                }) + t.slice(r);
            }
            e.print(e.to_utf8(t).replace(/\\(?:\0(?![0-9])|[^\0])/g, function(e) {
                switch (e[1]) {
                  case "\n":
                    return "\\n";

                  case "\r":
                    return "\\r";

                  case "\t":
                    return "\t";

                  case "\b":
                    return "\b";

                  case "\f":
                    return "\f";

                  case "\0":
                    return "\0";

                  case "\v":
                    return "\v";

                  case "\u2028":
                    return "\\u2028";

                  case "\u2029":
                    return "\\u2029";

                  default:
                    return e;
                }
            }).replace(/[\n\r\u2028\u2029]/g, function(e) {
                switch (e) {
                  case "\n":
                    return "\\n";

                  case "\r":
                    return "\\r";

                  case "\u2028":
                    return "\\u2028";

                  case "\u2029":
                    return "\\u2029";
                }
            }));
        });
        function $(e, n) {
            if (n.option("braces") && !(e instanceof lr || e instanceof pr)) {
                M(e, n);
            } else if (e instanceof yn) {
                n.force_semicolon();
            } else {
                n.space();
                e.print(n);
            }
        }
        function z(e, n) {
            if (e.args.length > 0) return true;
            return n.option("beautify");
        }
        function j(e) {
            var n = e[0], t = n.length;
            for (var r = 1; r < e.length; ++r) {
                if (e[r].length < t) {
                    n = e[r];
                    t = n.length;
                }
            }
            return n;
        }
        function C(e) {
            var n = e.toString(10).replace(/^0\./, ".").replace("e+", "e");
            var t = [ n ];
            if (Math.floor(e) === e) {
                if (e < 0) {
                    t.push("-0x" + (-e).toString(16).toLowerCase());
                } else {
                    t.push("0x" + e.toString(16).toLowerCase());
                }
            }
            var r, i, a;
            if (r = /^\.0+/.exec(n)) {
                i = r[0].length;
                a = n.slice(i);
                t.push(a + "e-" + (a.length + i - 1));
            } else if (r = /[^0]0+$/.exec(n)) {
                i = r[0].length - 1;
                t.push(n.slice(0, -i) + "e" + i);
            } else if (r = /^(\d)\.(\d+)e(-?\d+)$/.exec(n)) {
                t.push(r[1] + r[2] + "e" + (r[3] - r[2].length));
            }
            return j(t);
        }
        function M(e, n) {
            n.space();
            if (e instanceof yn) {
                c(e, n);
            } else if (e instanceof xn) {
                e.print(n);
            } else n.with_block(function() {
                n.indent();
                e.print(n);
                n.newline();
            }, e.end);
        }
        function F(e, n) {
            e.forEach(function(e) {
                e.DEFMETHOD("add_source_map", n);
            });
        }
        F([ bn, dt ], Kn);
        F([ Hn, wr, xn, fr, Un, st, cr, Yn, ft, ur, Kt, En, gr, Rn, Mn, N, $r, rr, ir, sr, Pn, xr ], function(e) {
            e.add_mapping(this.start);
        });
        F([ Ut, Er, Tr ], function(e) {
            if (typeof this.key == "string") e.add_mapping(this.start, this.key);
        });
    })();
    /***********************************************************************

  A JavaScript tokenizer / parser / beautifier / compressor.
  https://github.com/mishoo/UglifyJS

  -------------------------------- (C) ---------------------------------

                           Author: Mihai Bazon
                         <mihai.bazon@gmail.com>
                       http://mihai.bazon.net/blog

  Distributed under the BSD license:

    Copyright 2012 (c) Mihai Bazon <mihai.bazon@gmail.com>

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

        * Redistributions of source code must retain the above
          copyright notice, this list of conditions and the following
          disclaimer.

        * Redistributions in binary form must reproduce the above
          copyright notice, this list of conditions and the following
          disclaimer in the documentation and/or other materials
          provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER “AS IS” AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE
    LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
    OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
    TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
    THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
    SUCH DAMAGE.

 ***********************************************************************/
    "use strict";
    var A = n("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/");
    var D = A.reduce(function(e, n, t) {
        e[n] = t;
        return e;
    }, Object.create(null));
    function q(e, n) {
        var t = 0;
        var r = 0;
        for (var i = 0, a = 0; i < n.length; i++) {
            var o = D[n[i]];
            t += (o & 31) << r;
            if (o & 32) {
                r += 5;
            } else {
                e[a++] += t & 1 ? 2147483648 | -(t >> 1) : t >> 1;
                t = r = 0;
            }
        }
        return a;
    }
    function O(e) {
        var n = "";
        e = Math.abs(e) << 1 | e >>> 31;
        do {
            var t = e & 31;
            if (e >>>= 5) t |= 32;
            n += A[t];
        } while (e);
        return n;
    }
    function $() {
        var t = new gn();
        var r = [];
        r.index = function(e) {
            var n = t.get(e);
            if (!(n >= 0)) {
                n = r.length;
                r.push(e);
                t.set(e, n);
            }
            return n;
        };
        return r;
    }
    function z(l) {
        var f = $();
        var a = l.includeSources && new gn();
        var u = $();
        var c = "";
        if (l.orig) Object.keys(l.orig).forEach(function(e) {
            var n = l.orig[e];
            var t = [ 0, 0, 1, 0, 0 ];
            l.orig[e] = {
                names: n.names,
                mappings: n.mappings.split(/;/).map(function(e) {
                    t[0] = 0;
                    return e.split(/,/).map(function(e) {
                        return t.slice(0, q(t, e));
                    });
                }),
                sources: n.sources
            };
            if (!a || !n.sourcesContent) return;
            for (var r = 0; r < n.sources.length; r++) {
                var i = n.sourcesContent[r];
                if (i) a.set(n.sources[r], i);
            }
        });
        var p;
        var d = 1;
        var h = 0;
        var v = 0;
        var m = 1;
        var _ = 0;
        var g = 0;
        return {
            add: l.orig ? function(e, n, t, r, i, a) {
                var o = l.orig[e];
                if (o) {
                    var s = o.mappings[r - 1];
                    if (!s) return;
                    var f;
                    for (var u = 0; u < s.length; u++) {
                        var c = s[u][0];
                        if (i >= c) f = s[u];
                        if (i <= c) break;
                    }
                    if (!f || f.length < 4) {
                        e = null;
                    } else {
                        e = o.sources[f[1]];
                        r = f[2];
                        i = f[3];
                        if (f.length > 4) a = o.names[f[4]];
                    }
                }
                b(e, n, t, r, i, a);
            } : b,
            setSourceContent: a ? function(e, n) {
                if (!a.has(e)) {
                    a.set(e, n);
                }
            } : Kn,
            toString: function() {
                return JSON.stringify({
                    version: 3,
                    file: l.filename || undefined,
                    sourceRoot: l.root || undefined,
                    sources: f,
                    sourcesContent: a ? f.map(function(e) {
                        return a.get(e) || null;
                    }) : undefined,
                    names: u,
                    mappings: c
                });
            }
        };
        function b(e, n, t, r, i, a) {
            if (p == null && e == null) return;
            p = e;
            if (d < n) {
                h = 0;
                do {
                    c += ";";
                } while (++d < n);
            } else if (c) {
                c += ",";
            }
            c += O(t - h);
            h = t;
            if (e == null) return;
            var o = f.index(e);
            c += O(o - v);
            v = o;
            c += O(r - m);
            m = r;
            c += O(i - _);
            _ = i;
            if (l.names && a != null) {
                var s = u.index(a);
                c += O(s - g);
                g = s;
            }
        }
    }
    /***********************************************************************

  A JavaScript tokenizer / parser / beautifier / compressor.
  https://github.com/mishoo/UglifyJS

  -------------------------------- (C) ---------------------------------

                           Author: Mihai Bazon
                         <mihai.bazon@gmail.com>
                       http://mihai.bazon.net/blog

  Distributed under the BSD license:

    Copyright 2012 (c) Mihai Bazon <mihai.bazon@gmail.com>

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

        * Redistributions of source code must retain the above
          copyright notice, this list of conditions and the following
          disclaimer.

        * Redistributions in binary form must reproduce the above
          copyright notice, this list of conditions and the following
          disclaimer in the documentation and/or other materials
          provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER “AS IS” AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE
    LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
    OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
    TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
    THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
    SUCH DAMAGE.

 ***********************************************************************/
    "use strict";
    (function() {
        var r = {
            Program: function(e) {
                return new kt({
                    start: s(e),
                    end: f(e),
                    body: a(e.body.map(l))
                });
            },
            ArrowFunctionExpression: function(e) {
                var n = [], t = null;
                e.params.forEach(function(e) {
                    if (e.type == "RestElement") {
                        t = l(e.argument);
                    } else {
                        n.push(l(e));
                    }
                });
                var r = new (e.async ? zt : $t)({
                    start: s(e),
                    end: f(e),
                    argnames: n,
                    rest: t
                });
                var i = l(e.body);
                if (i instanceof xn) {
                    r.body = a(i.body);
                    r.value = null;
                } else {
                    r.body = [];
                    r.value = i;
                }
                return r;
            },
            FunctionDeclaration: function(e) {
                var n;
                if (e.async) {
                    n = e.generator ? It : Nt;
                } else {
                    n = e.generator ? Yt : Ht;
                }
                var t = [], r = null;
                e.params.forEach(function(e) {
                    if (e.type == "RestElement") {
                        r = l(e.argument);
                    } else {
                        t.push(l(e));
                    }
                });
                return new n({
                    start: s(e),
                    end: f(e),
                    name: l(e.id),
                    argnames: t,
                    rest: r,
                    body: a(l(e.body).body)
                });
            },
            FunctionExpression: function(e) {
                var n;
                if (e.async) {
                    n = e.generator ? Mt : Ct;
                } else {
                    n = e.generator ? Pt : Ft;
                }
                var t = [], r = null;
                e.params.forEach(function(e) {
                    if (e.type == "RestElement") {
                        r = l(e.argument);
                    } else {
                        t.push(l(e));
                    }
                });
                return new n({
                    start: s(e),
                    end: f(e),
                    name: l(e.id),
                    argnames: t,
                    rest: r,
                    body: a(l(e.body).body)
                });
            },
            ClassDeclaration: function(e) {
                return new Bt({
                    start: s(e),
                    end: f(e),
                    name: l(e.id),
                    extends: l(e.superClass),
                    properties: e.body.body.map(l)
                });
            },
            ClassExpression: function(e) {
                return new Lt({
                    start: s(e),
                    end: f(e),
                    name: l(e.id),
                    extends: l(e.superClass),
                    properties: e.body.body.map(l)
                });
            },
            MethodDefinition: function(e) {
                var n = e.key, t = false;
                if (e.computed) {
                    n = l(n);
                } else if (n.type == "PrivateIdentifier") {
                    t = true;
                    n = "#" + n.name;
                } else {
                    n = o(n);
                }
                var r = Jt, i = l(e.value);
                switch (e.kind) {
                  case "get":
                    r = Wt;
                    i = new St(i);
                    break;

                  case "set":
                    r = Gt;
                    i = new St(i);
                    break;
                }
                return new r({
                    start: s(e),
                    end: f(e),
                    key: n,
                    private: t,
                    static: e.static,
                    value: i
                });
            },
            PropertyDefinition: function(e) {
                var n = e.key, t = false;
                if (e.computed) {
                    n = l(n);
                } else if (n.type == "PrivateIdentifier") {
                    t = true;
                    n = "#" + n.name;
                } else {
                    n = o(n);
                }
                return new Vt({
                    start: s(e),
                    end: f(e),
                    key: n,
                    private: t,
                    static: e.static,
                    value: l(e.value)
                });
            },
            StaticBlock: function(e) {
                var n = s(e);
                var t = f(e);
                return new Xt({
                    start: n,
                    end: t,
                    value: new Et({
                        start: n,
                        end: t,
                        body: a(e.body.map(l))
                    })
                });
            },
            ForOfStatement: function(e) {
                return new (e.await ? wt : xe)({
                    start: s(e),
                    end: f(e),
                    init: l(e.left),
                    object: l(e.right),
                    body: l(e.body)
                });
            },
            TryStatement: function(e) {
                var n = e.handlers || [ e.handler ];
                if (n.length > 1 || e.guardedHandlers && e.guardedHandlers.length) {
                    throw new Error("Multiple catch clauses are not supported.");
                }
                return new sr({
                    start: s(e),
                    end: f(e),
                    body: l(e.block).body,
                    bcatch: l(n[0]),
                    bfinally: e.finalizer ? new ur(l(e.finalizer)) : null
                });
            },
            Property: function(e) {
                var n = e.computed ? l(e.key) : o(e.key);
                var t = {
                    start: s(e),
                    end: f(e),
                    key: n,
                    value: l(e.value)
                };
                if (e.kind == "init") return new (e.method ? Dr : Ar)(t);
                t.value = new St(t.value);
                if (e.kind == "get") return new Or(t);
                if (e.kind == "set") return new qr(t);
            },
            ArrayExpression: function(e) {
                return new Hn({
                    start: s(e),
                    end: f(e),
                    elements: e.elements.map(function(e) {
                        return e === null ? new Zr() : l(e);
                    })
                });
            },
            ArrayPattern: function(e) {
                var n = [], t = null;
                e.elements.forEach(function(e) {
                    if (e === null) {
                        n.push(new Zr());
                    } else if (e.type == "RestElement") {
                        t = l(e.argument);
                    } else {
                        n.push(l(e));
                    }
                });
                return new kr({
                    start: s(e),
                    end: f(e),
                    elements: n,
                    rest: t
                });
            },
            ObjectPattern: function(e) {
                var n = [], t = null;
                e.properties.forEach(function(e) {
                    if (e.type == "RestElement") {
                        t = l(e.argument);
                    } else {
                        n.push(new Er(l(e)));
                    }
                });
                return new Sr({
                    start: s(e),
                    end: f(e),
                    properties: n,
                    rest: t
                });
            },
            MemberExpression: function(e) {
                return new (e.computed ? Cn : zn)({
                    start: s(e),
                    end: f(e),
                    optional: e.optional,
                    expression: l(e.object),
                    property: e.computed ? l(e.property) : e.property.name
                });
            },
            MetaProperty: function(e) {
                var n = l(e.meta);
                var t = o(e.property);
                if (n.name == "new" && t == "target") return new Ur({
                    start: s(e),
                    end: f(e),
                    name: "new.target"
                });
                return new zn({
                    start: s(e),
                    end: f(e),
                    expression: n,
                    property: t
                });
            },
            SwitchCase: function(e) {
                return new (e.test ? or : ar)({
                    start: s(e),
                    end: f(e),
                    expression: l(e.test),
                    body: e.consequent.map(l)
                });
            },
            ExportAllDeclaration: function(e) {
                var n = s(e);
                var t = f(e);
                return new ke({
                    start: n,
                    end: t,
                    aliases: [ e.exported ? p(e.exported) : new Vn({
                        start: n,
                        value: "*",
                        end: t
                    }) ],
                    keys: [ new Vn({
                        start: n,
                        value: "*",
                        end: t
                    }) ],
                    path: l(e.source)
                });
            },
            ExportDefaultDeclaration: function(e) {
                var n = l(e.declaration);
                if (!n.name) switch (n.CTOR) {
                  case Nt:
                    n = new Ct(n);
                    break;

                  case It:
                    n = new Mt(n);
                    break;

                  case Bt:
                    n = new Lt(n);
                    break;

                  case Ht:
                    n = new Ft(n);
                    break;

                  case Yt:
                    n = new Pt(n);
                    break;
                }
                return new vr({
                    start: s(e),
                    end: f(e),
                    body: n
                });
            },
            ExportNamedDeclaration: function(e) {
                if (e.declaration) return new hr({
                    start: s(e),
                    end: f(e),
                    body: l(e.declaration)
                });
                if (e.source) {
                    var n = [], t = [];
                    e.specifiers.forEach(function(e) {
                        n.push(p(e.exported));
                        t.push(p(e.local));
                    });
                    return new ke({
                        start: s(e),
                        end: f(e),
                        aliases: n,
                        keys: t,
                        path: l(e.source)
                    });
                }
                return new mr({
                    start: s(e),
                    end: f(e),
                    properties: e.specifiers.map(function(e) {
                        var n = new Yr(l(e.local));
                        n.alias = p(e.exported);
                        return n;
                    })
                });
            },
            ImportDeclaration: function(e) {
                var t = s(e);
                var r = f(e);
                var i = null, a = null, o = null;
                e.specifiers.forEach(function(e) {
                    var n = new Mr(l(e.local));
                    switch (e.type) {
                      case "ImportDefaultSpecifier":
                        a = n;
                        a.key = new Vn({
                            start: t,
                            value: "",
                            end: r
                        });
                        break;

                      case "ImportNamespaceSpecifier":
                        i = n;
                        i.key = new Vn({
                            start: t,
                            value: "*",
                            end: r
                        });
                        break;

                      default:
                        n.key = p(e.imported);
                        if (!o) o = [];
                        o.push(n);
                        break;
                    }
                });
                return new _r({
                    start: t,
                    end: r,
                    all: i,
                    default: a,
                    properties: o,
                    path: l(e.source)
                });
            },
            ImportExpression: function(e) {
                var n = s(e);
                var t = l(e.source);
                return new qn({
                    start: n,
                    end: f(e),
                    expression: new Ln({
                        start: n,
                        end: t.start,
                        name: "import"
                    }),
                    args: [ t ]
                });
            },
            VariableDeclaration: function(e) {
                return new ({
                    const: lr,
                    let: pr
                }[e.kind] || dr)({
                    start: s(e),
                    end: f(e),
                    definitions: e.declarations.map(l)
                });
            },
            Literal: function(e) {
                var n = {
                    start: s(e),
                    end: f(e)
                };
                if (e.bigint) {
                    n.value = e.bigint.toLowerCase() + "n";
                    return new Wr(n);
                }
                var t = e.value;
                if (t === null) return new Xr(n);
                var r = e.regex;
                if (r && r.pattern) {
                    n.value = new RegExp(r.pattern, r.flags);
                    n.value.raw_source = r.pattern;
                    return new Gr(n);
                } else if (r) {
                    n.value = e.regex && e.raw ? e.raw : t;
                    return new Gr(n);
                }
                switch (typeof t) {
                  case "string":
                    n.value = t;
                    return new Vn(n);

                  case "number":
                    if (isNaN(t)) return new Kr(n);
                    var i, a;
                    if (isFinite(t)) {
                        i = 1 / t < 0;
                        n.value = i ? -t : t;
                        a = new Wn(n);
                    } else {
                        i = t < 0;
                        a = new ei(n);
                    }
                    return i ? new Pn({
                        start: n.start,
                        end: n.end,
                        operator: "-",
                        expression: a
                    }) : a;

                  case "boolean":
                    return new (t ? ri : ti)(n);
                }
            },
            TemplateLiteral: function(e) {
                return new Vr({
                    start: s(e),
                    end: f(e),
                    expressions: e.expressions.map(l),
                    strings: e.quasis.map(function(e) {
                        return e.value.raw;
                    })
                });
            },
            TaggedTemplateExpression: function(e) {
                var n = l(e.quasi);
                n.start = s(e);
                n.end = f(e);
                n.tag = l(e.tag);
                return n;
            },
            Identifier: function(e) {
                var n, t = c.length - 1;
                do {
                    n = c[--t];
                } while (n.type == "ArrayPattern" || n.type == "AssignmentPattern" && n.left === c[t + 1] || n.type == "ObjectPattern" || n.type == "Property" && n.value === c[t + 1] || n.type == "VariableDeclarator" && n.id === c[t + 1]);
                var r = Ln;
                switch (n.type) {
                  case "ArrowFunctionExpression":
                    if (n.body !== c[t + 1]) r = Bn;
                    break;

                  case "BreakStatement":
                  case "ContinueStatement":
                    r = Te;
                    break;

                  case "CatchClause":
                    r = Hr;
                    break;

                  case "ClassDeclaration":
                    if (n.id === c[t + 1]) r = Ee;
                    break;

                  case "ClassExpression":
                    if (n.id === c[t + 1]) r = Ir;
                    break;

                  case "FunctionDeclaration":
                    r = n.id === c[t + 1] ? jr : Bn;
                    break;

                  case "FunctionExpression":
                    r = n.id === c[t + 1] ? Nr : Bn;
                    break;

                  case "LabeledStatement":
                    r = Se;
                    break;

                  case "VariableDeclaration":
                    r = {
                        const: Cr,
                        let: Fr
                    }[n.kind] || Pr;
                    break;
                }
                return new r({
                    start: s(e),
                    end: f(e),
                    name: e.name
                });
            },
            Super: function(e) {
                return new Br({
                    start: s(e),
                    end: f(e),
                    name: "super"
                });
            },
            ThisExpression: function(e) {
                return new Lr({
                    start: s(e),
                    end: f(e),
                    name: "this"
                });
            },
            ParenthesizedExpression: function(e) {
                var n = l(e.expression);
                if (!n.start.parens) n.start.parens = [];
                n.start.parens.push(s(e));
                if (!n.end.parens) n.end.parens = [];
                n.end.parens.push(f(e));
                return n;
            },
            ChainExpression: function(e) {
                var n = l(e.expression);
                n.terminal = true;
                return n;
            }
        };
        r.UpdateExpression = r.UnaryExpression = function e(n) {
            var t = "prefix" in n ? n.prefix : n.type == "UnaryExpression" ? true : false;
            return new (t ? Pn : yr)({
                start: s(n),
                end: f(n),
                operator: n.operator,
                expression: l(n.argument)
            });
        };
        u("EmptyStatement", yn);
        u("ExpressionStatement", wn, "expression>body");
        u("BlockStatement", xn, "body@body");
        u("IfStatement", Tn, "test>condition, consequent>body, alternate>alternative");
        u("LabeledStatement", dt, "label>label, body>body");
        u("BreakStatement", nr, "label>label");
        u("ContinueStatement", tr, "label>label");
        u("WithStatement", xt, "object>expression, body>body");
        u("SwitchStatement", rr, "discriminant>expression, cases@body");
        u("ReturnStatement", Sn, "argument>value");
        u("ThrowStatement", Zt, "argument>value");
        u("WhileStatement", _t, "test>condition, body>body");
        u("DoWhileStatement", mt, "test>condition, body>body");
        u("ForStatement", gt, "init>init, test>condition, update>step, body>body");
        u("ForInStatement", yt, "left>init, right>object, body>body");
        u("DebuggerStatement", st);
        u("VariableDeclarator", An, "id>name, init>value");
        u("CatchClause", fr, "param>argname, body%body");
        u("BinaryExpression", jn, "operator=operator, left>left, right>right");
        u("LogicalExpression", jn, "operator=operator, left>left, right>right");
        u("AssignmentExpression", In, "operator=operator, left>left, right>right");
        u("AssignmentPattern", Dn, "left>name, right>value");
        u("ConditionalExpression", Nn, "test>condition, consequent>consequent, alternate>alternative");
        u("NewExpression", gr, "callee>expression, arguments@args, pure=pure");
        u("CallExpression", qn, "callee>expression, arguments@args, optional=optional, pure=pure");
        u("SequenceExpression", On, "expressions@expressions");
        u("SpreadElement", Mn, "argument>expression");
        u("ObjectExpression", Rn, "properties@properties");
        u("AwaitExpression", wr, "argument>expression");
        u("YieldExpression", xr, "argument>expression, delegate=nested");
        h(kt, function e(n) {
            return g("Program", n);
        });
        h(jt, function e(n) {
            var t = n.argnames.map(v);
            if (n.rest) t.push({
                type: "RestElement",
                argument: v(n.rest)
            });
            return {
                type: "FunctionDeclaration",
                id: v(n.name),
                async: Dt(n),
                generator: qt(n),
                params: t,
                body: g("BlockStatement", n)
            };
        });
        h(En, function e(n) {
            var t = n.argnames.map(v);
            if (n.rest) t.push({
                type: "RestElement",
                argument: v(n.rest)
            });
            if (At(n)) return {
                type: "ArrowFunctionExpression",
                async: Dt(n),
                params: t,
                body: n.value ? v(n.value) : g("BlockStatement", n)
            };
            return {
                type: "FunctionExpression",
                id: v(n.name),
                async: Dt(n),
                generator: qt(n),
                params: t,
                body: g("BlockStatement", n)
            };
        });
        h(Bt, function e(n) {
            return {
                type: "ClassDeclaration",
                id: v(n.name),
                superClass: v(n.extends),
                body: {
                    type: "ClassBody",
                    body: n.properties.map(v)
                }
            };
        });
        h(Lt, function e(n) {
            return {
                type: "ClassExpression",
                id: v(n.name),
                superClass: v(n.extends),
                body: {
                    type: "ClassBody",
                    body: n.properties.map(v)
                }
            };
        });
        function e(r) {
            return function(e) {
                var n = e.key instanceof bn;
                var t = n ? v(e.key) : e.private ? {
                    type: "PrivateIdentifier",
                    name: e.key.slice(1)
                } : {
                    type: "Literal",
                    value: e.key
                };
                return {
                    type: "MethodDefinition",
                    kind: r,
                    computed: n,
                    key: t,
                    static: e.static,
                    value: v(e.value)
                };
            };
        }
        h(Wt, e("get"));
        h(Gt, e("set"));
        h(Jt, e("method"));
        h(Vt, function e(n) {
            var t = n.key instanceof bn;
            var r = t ? v(n.key) : n.private ? {
                type: "PrivateIdentifier",
                name: n.key.slice(1)
            } : {
                type: "Literal",
                value: n.key
            };
            return {
                type: "PropertyDefinition",
                computed: t,
                key: r,
                static: n.static,
                value: v(n.value)
            };
        });
        h(Xt, function e(n) {
            return g("StaticBlock", n.value);
        });
        function n(n) {
            return function(e) {
                return {
                    type: "ForOfStatement",
                    await: n,
                    left: v(e.init),
                    right: v(e.object),
                    body: v(e.body)
                };
            };
        }
        h(wt, n(true));
        h(xe, n(false));
        h(ft, function e(n) {
            return {
                type: "ExpressionStatement",
                expression: d(n, {
                    type: "Literal",
                    value: n.value
                })
            };
        });
        h(ir, function e(n) {
            return {
                type: "SwitchCase",
                test: v(n.expression),
                consequent: n.body.map(v)
            };
        });
        h(sr, function e(n) {
            return {
                type: "TryStatement",
                block: _(n),
                handler: v(n.bcatch),
                guardedHandlers: [],
                finalizer: v(n.bfinally)
            };
        });
        h(fr, function e(n) {
            return {
                type: "CatchClause",
                param: v(n.argname),
                guard: null,
                body: _(n)
            };
        });
        h(hr, function e(n) {
            return {
                type: "ExportNamedDeclaration",
                declaration: v(n.body)
            };
        });
        h(vr, function e(n) {
            return {
                type: "ExportDefaultDeclaration",
                declaration: v(n.body)
            };
        });
        h(ke, function e(n) {
            if (n.keys[0].value == "*") return {
                type: "ExportAllDeclaration",
                exported: n.aliases[0].value == "*" ? null : m(n.aliases[0]),
                source: v(n.path)
            };
            var t = [];
            for (var r = 0; r < n.aliases.length; r++) {
                t.push(d({
                    start: n.keys[r].start,
                    end: n.aliases[r].end
                }, {
                    type: "ExportSpecifier",
                    local: m(n.keys[r]),
                    exported: m(n.aliases[r])
                }));
            }
            return {
                type: "ExportNamedDeclaration",
                specifiers: t,
                source: v(n.path)
            };
        });
        h(mr, function e(n) {
            return {
                type: "ExportNamedDeclaration",
                specifiers: n.properties.map(function(e) {
                    return d({
                        start: e.start,
                        end: e.alias.end
                    }, {
                        type: "ExportSpecifier",
                        local: v(e),
                        exported: m(e.alias)
                    });
                })
            };
        });
        h(_r, function e(n) {
            var t = n.properties ? n.properties.map(function(e) {
                return d({
                    start: e.key.start,
                    end: e.end
                }, {
                    type: "ImportSpecifier",
                    local: v(e),
                    imported: m(e.key)
                });
            }) : [];
            if (n.all) t.unshift(d(n.all, {
                type: "ImportNamespaceSpecifier",
                local: v(n.all)
            }));
            if (n.default) t.unshift(d(n.default, {
                type: "ImportDefaultSpecifier",
                local: v(n.default)
            }));
            return {
                type: "ImportDeclaration",
                specifiers: t,
                source: v(n.path)
            };
        });
        h(cr, function e(n) {
            return {
                type: "VariableDeclaration",
                kind: n.TYPE.toLowerCase(),
                declarations: n.definitions.map(v)
            };
        });
        h($n, function e(n) {
            var t = n instanceof Cn;
            var r = {
                type: "MemberExpression",
                object: v(n.expression),
                computed: t,
                optional: n.optional,
                property: t ? v(n.property) : {
                    type: "Identifier",
                    name: n.property
                }
            };
            return n.terminal ? {
                type: "ChainExpression",
                expression: r
            } : r;
        });
        h(Fn, function e(n) {
            return {
                type: n.operator == "++" || n.operator == "--" ? "UpdateExpression" : "UnaryExpression",
                operator: n.operator,
                prefix: n instanceof Pn,
                argument: v(n.expression)
            };
        });
        h(jn, function e(n) {
            return {
                type: n.operator == "&&" || n.operator == "||" ? "LogicalExpression" : "BinaryExpression",
                left: v(n.left),
                operator: n.operator,
                right: v(n.right)
            };
        });
        h(Hn, function e(n) {
            return {
                type: "ArrayExpression",
                elements: n.elements.map(v)
            };
        });
        h(kr, function e(n) {
            var t = n.elements.map(v);
            if (n.rest) t.push({
                type: "RestElement",
                argument: v(n.rest)
            });
            return {
                type: "ArrayPattern",
                elements: t
            };
        });
        h(Er, function e(n) {
            var t = n.key instanceof bn;
            var r = t ? v(n.key) : {
                type: "Literal",
                value: n.key
            };
            return {
                type: "Property",
                kind: "init",
                computed: t,
                key: r,
                value: v(n.value)
            };
        });
        h(Sr, function e(n) {
            var t = n.properties.map(v);
            if (n.rest) t.push({
                type: "RestElement",
                argument: v(n.rest)
            });
            return {
                type: "ObjectPattern",
                properties: t
            };
        });
        h(Tr, function e(n) {
            var t = n.key instanceof bn;
            var r = t ? v(n.key) : {
                type: "Literal",
                value: n.key
            };
            var i;
            if (n instanceof Ar) {
                i = "init";
            } else if (n instanceof Or) {
                i = "get";
            } else if (n instanceof qr) {
                i = "set";
            }
            return {
                type: "Property",
                kind: i,
                computed: t,
                method: n instanceof Dr,
                key: r,
                value: v(n.value)
            };
        });
        h($r, function e(n) {
            var t = n.definition();
            return {
                type: "Identifier",
                name: t && t.mangled_name || n.name
            };
        });
        h(Br, function e() {
            return {
                type: "Super"
            };
        });
        h(Lr, function e() {
            return {
                type: "ThisExpression"
            };
        });
        h(Ur, function e() {
            return {
                type: "MetaProperty",
                meta: {
                    type: "Identifier",
                    name: "new"
                },
                property: {
                    type: "Identifier",
                    name: "target"
                }
            };
        });
        h(Gr, function e(n) {
            var t = n.value.toString().match(/\/([gimuy]*)$/)[1];
            var r = "/" + n.value.raw_source + "/" + t;
            return {
                type: "Literal",
                value: r,
                raw: r,
                regex: {
                    pattern: n.value.raw_source,
                    flags: t
                }
            };
        });
        h(Wr, function e(n) {
            var t = n.value;
            return {
                type: "Literal",
                bigint: t.slice(0, -1),
                raw: t
            };
        });
        function t(e) {
            var n = e.value;
            if (typeof n === "number" && (n < 0 || n === 0 && 1 / n < 0)) {
                return {
                    type: "UnaryExpression",
                    operator: "-",
                    prefix: true,
                    argument: {
                        type: "Literal",
                        value: -n,
                        raw: e.start.raw
                    }
                };
            }
            return {
                type: "Literal",
                value: n,
                raw: e.start.raw
            };
        }
        h(ni, t);
        h(Un, t);
        h(Xr, t);
        h(Jr, function e(n) {
            return {
                type: "Identifier",
                name: String(n.value)
            };
        });
        h(Vr, function e(n) {
            var t = n.strings.length - 1;
            var r = {
                type: "TemplateLiteral",
                expressions: n.expressions.map(v),
                quasis: n.strings.map(function(e, n) {
                    return {
                        type: "TemplateElement",
                        tail: n == t,
                        value: {
                            raw: e
                        }
                    };
                })
            };
            if (!n.tag) return r;
            return {
                type: "TaggedTemplateExpression",
                tag: v(n.tag),
                quasi: r
            };
        });
        pt.DEFMETHOD("to_mozilla_ast", xn.prototype.to_mozilla_ast);
        Zr.DEFMETHOD("to_mozilla_ast", Zn);
        bn.DEFMETHOD("to_mozilla_ast", function() {
            throw new Error("Cannot convert AST_" + this.TYPE);
        });
        function a(e) {
            for (var n = 0; n < e.length; n++) {
                var t = e[n];
                if (!(t instanceof wn)) break;
                var r = t.body;
                if (!(r instanceof Vn)) break;
                if (t.start.pos !== r.start.pos) break;
                e[n] = new ft(r);
            }
            return e;
        }
        function i(e) {
            if (e.type == "Literal") {
                return e.raw != null ? e.raw : e.value + "";
            }
        }
        function s(e) {
            var n = e.loc, t = n && n.start;
            var r = e.range;
            return new te({
                file: n && n.source,
                line: t && t.line,
                col: t && t.column,
                pos: r ? r[0] : e.start,
                endline: t && t.line,
                endcol: t && t.column,
                endpos: r ? r[0] : e.start,
                raw: i(e)
            });
        }
        function f(e) {
            var n = e.loc, t = n && n.end;
            var r = e.range;
            return new te({
                file: n && n.source,
                line: t && t.line,
                col: t && t.column,
                pos: r ? r[1] : e.end,
                endline: t && t.line,
                endcol: t && t.column,
                endpos: r ? r[1] : e.end,
                raw: i(e)
            });
        }
        function o(e) {
            return "" + e[e.type == "Identifier" ? "name" : "value"];
        }
        function u(e, n, t) {
            var a = [ "start: my_start_token(M)", "end: my_end_token(M)" ];
            var o = [ "type: " + JSON.stringify(e) ];
            if (t) t.split(/\s*,\s*/).forEach(function(e) {
                var n = /([a-z0-9$_]+)(=|@|>|%)([a-z0-9$_]+)/i.exec(e);
                if (!n) throw new Error("Can't understand property map: " + e);
                var t = n[1], r = n[2], i = n[3];
                switch (r) {
                  case "@":
                    a.push(i + ": M." + t + ".map(from_moz)");
                    o.push(t + ": M." + i + ".map(to_moz)");
                    break;

                  case ">":
                    a.push(i + ": from_moz(M." + t + ")");
                    o.push(t + ": to_moz(M." + i + ")");
                    break;

                  case "=":
                    a.push(i + ": M." + t);
                    o.push(t + ": M." + i);
                    break;

                  case "%":
                    a.push(i + ": from_moz(M." + t + ").body");
                    o.push(t + ": to_moz_block(M)");
                    break;

                  default:
                    throw new Error("Can't understand operator in propmap: " + e);
                }
            });
            r[e] = new Function("U2", "my_start_token", "my_end_token", "from_moz", [ "return function From_Moz_" + e + "(M) {", "    return new U2.AST_" + n.TYPE + "({", a.join(",\n"), "    });", "};" ].join("\n"))(b, s, f, l);
            h(n, new Function("to_moz", "to_moz_block", "to_moz_scope", [ "return function To_Moz_" + e + "(M) {", "    return {", o.join(",\n"), "    };", "};" ].join("\n"))(v, _, g));
        }
        var c = null;
        function l(e) {
            c.push(e);
            var n = null;
            if (e) {
                if (!it(r, e.type)) throw new Error("Unsupported type: " + e.type);
                n = r[e.type](e);
            }
            c.pop();
            return n;
        }
        function p(e) {
            return new Vn({
                start: s(e),
                value: o(e),
                end: f(e)
            });
        }
        bn.from_mozilla_ast = function(e) {
            var n = c;
            c = [];
            var t = l(e);
            c = n;
            t.walk(new Gn(function(e) {
                if (e instanceof Te) {
                    for (var n = 0, t; t = this.parent(n); n++) {
                        if (t instanceof kn) break;
                        if (t instanceof dt && t.label.name == e.name) {
                            e.thedef = t.label;
                            break;
                        }
                    }
                    if (!e.thedef) {
                        var r = e.start;
                        qe("Undefined label " + e.name, r.file, r.line, r.col, r.pos);
                    }
                }
            }));
            return t;
        };
        function d(e, n) {
            var t = e.start;
            var r = e.end;
            if (t.pos != null && r.endpos != null) {
                n.range = [ t.pos, r.endpos ];
            }
            if (t.line) {
                n.loc = {
                    start: {
                        line: t.line,
                        column: t.col
                    },
                    end: r.endline ? {
                        line: r.endline,
                        column: r.endcol
                    } : null
                };
                if (t.file) {
                    n.loc.source = t.file;
                }
            }
            return n;
        }
        function h(e, n) {
            e.DEFMETHOD("to_mozilla_ast", function() {
                return d(this, n(this));
            });
        }
        function v(e) {
            return e != null ? e.to_mozilla_ast() : null;
        }
        function m(e) {
            return ai(e.value) ? d(e, {
                type: "Identifier",
                name: e.value
            }) : v(e);
        }
        function _(e) {
            return {
                type: "BlockStatement",
                body: e.body.map(v)
            };
        }
        function g(e, n) {
            var t = n.body.map(v);
            if (n.body[0] instanceof wn && n.body[0].body instanceof Vn) {
                t.unshift(v(new yn(n.body[0])));
            }
            return {
                type: e,
                body: t
            };
        }
    })();
    /***********************************************************************

  A JavaScript tokenizer / parser / beautifier / compressor.
  https://github.com/mishoo/UglifyJS

  -------------------------------- (C) ---------------------------------

                           Author: Mihai Bazon
                         <mihai.bazon@gmail.com>
                       http://mihai.bazon.net/blog

  Distributed under the BSD license:

    Copyright 2012 (c) Mihai Bazon <mihai.bazon@gmail.com>

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

        * Redistributions of source code must retain the above
          copyright notice, this list of conditions and the following
          disclaimer.

        * Redistributions in binary form must reproduce the above
          copyright notice, this list of conditions and the following
          disclaimer in the documentation and/or other materials
          provided with the distribution.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER “AS IS” AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE
    LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
    OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
    TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
    THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
    SUCH DAMAGE.

 ***********************************************************************/
    "use strict";
    function W() {
        var n = new gn();
        [ "NaN", "null", "true", "false", "Infinity", "-Infinity", "undefined" ].forEach(r);
        [ "encodeURI", "encodeURIComponent", "escape", "eval", "decodeURI", "decodeURIComponent", "isFinite", "isNaN", "parseFloat", "parseInt", "unescape" ].forEach(r);
        var t = Function("return this")();
        [ "Array", "ArrayBuffer", "Atomics", "BigInt", "Boolean", "console", "DataView", "Date", "Error", "Function", "Int8Array", "Intl", "JSON", "Map", "Math", "Number", "Object", "Promise", "Proxy", "Reflect", "RegExp", "Set", "String", "Symbol", "WebAssembly" ].forEach(function(e) {
            r(e);
            var n = t[e];
            if (!n) return;
            Object.getOwnPropertyNames(n).map(r);
            if (typeof n != "function") return;
            if (n.__proto__) Object.getOwnPropertyNames(n.__proto__).map(r);
            if (n.prototype) Object.getOwnPropertyNames(n.prototype).map(r);
            try {
                Object.getOwnPropertyNames(new n()).map(r);
            } catch (e) {
                try {
                    Object.getOwnPropertyNames(n()).map(r);
                } catch (e) {}
            }
        });
        return (W = function() {
            return n.clone();
        })();
        function r(e) {
            n.set(e, true);
        }
    }
    function G(e, n) {
        e.walk(new Gn(function(e) {
            if (e instanceof Ut || e instanceof Er || e instanceof Tr) {
                if (e.key instanceof bn) {
                    J(e.key, t);
                } else if (e.start && e.start.quote) {
                    t(e.key);
                }
            } else if (e instanceof zn) {
                if (e.quoted) t(e.property);
            } else if (e instanceof Cn) {
                J(e.property, t);
            }
        }));
        function t(e) {
            nt(n, e);
        }
    }
    function J(e, n) {
        if (e instanceof Nn) {
            J(e.consequent, n);
            J(e.alternative, n);
        } else if (e instanceof On) {
            J(e.tail_node(), n);
        } else if (e instanceof Vn) {
            n(e.value);
        }
    }
    function X(e, t) {
        t = we(t, {
            builtins: false,
            cache: null,
            debug: false,
            domprops: false,
            keep_quoted: false,
            regex: null,
            reserved: null
        }, true);
        var n = t.builtins ? new gn() : W();
        if (!t.domprops && typeof domprops !== "undefined") domprops.forEach(function(e) {
            n.set(e, true);
        });
        if (Array.isArray(t.reserved)) t.reserved.forEach(function(e) {
            n.set(e, true);
        });
        var r = -1;
        var i;
        if (t.cache) {
            i = t.cache.props;
            i.each(function(e) {
                n.set(e, true);
            });
        } else {
            i = new gn();
        }
        var a = t.regex;
        var o = t.debug !== false;
        var s;
        if (o) s = t.debug === true ? "" : t.debug;
        var f = new gn();
        var u = n.clone();
        e.walk(new Gn(function(e) {
            if (e.TYPE == "Call") {
                var n = e.expression;
                if (n instanceof zn) switch (n.property) {
                  case "defineProperty":
                  case "getOwnPropertyDescriptor":
                    if (e.args.length < 2) break;
                    n = n.expression;
                    if (!(n instanceof Ln)) break;
                    if (n.name != "Object") break;
                    if (!n.definition().undeclared) break;
                    J(e.args[1], p);
                    break;

                  case "hasOwnProperty":
                    if (e.args.length < 1) break;
                    J(e.args[0], p);
                    break;
                }
            } else if (e instanceof Ut || e instanceof Er || e instanceof Tr) {
                if (e.key instanceof bn) {
                    J(e.key, p);
                } else {
                    p(e.key);
                }
            } else if (e instanceof zn) {
                if (di(e, this.parent())) p(e.property);
            } else if (e instanceof Cn) {
                if (di(e, this.parent())) J(e.property, p);
            }
        }));
        e.walk(new Gn(function(e) {
            if (e instanceof jn) {
                if (e.operator == "in") h(e.left);
            } else if (e.TYPE == "Call") {
                var n = e.expression;
                if (n instanceof zn) switch (n.property) {
                  case "defineProperty":
                  case "getOwnPropertyDescriptor":
                    if (e.args.length < 2) break;
                    n = n.expression;
                    if (!(n instanceof Ln)) break;
                    if (n.name != "Object") break;
                    if (!n.definition().undeclared) break;
                    h(e.args[1]);
                    break;

                  case "hasOwnProperty":
                    if (e.args.length < 1) break;
                    h(e.args[0]);
                    break;
                }
            } else if (e instanceof Ut || e instanceof Er || e instanceof Tr) {
                if (e.key instanceof bn) {
                    h(e.key);
                } else {
                    e.key = d(e.key);
                }
            } else if (e instanceof zn) {
                e.property = d(e.property);
            } else if (e instanceof Cn) {
                if (!t.keep_quoted) h(e.property);
            }
        }));
        function c(e) {
            if (u.has(e)) return false;
            if (/^-?[0-9]+(\.[0-9]+)?(e[+-][0-9]+)?$/.test(e)) return false;
            return true;
        }
        function l(e) {
            if (n.has(e)) {
                bn.info("Preserving reserved property {this}", e);
                return false;
            }
            if (a && !a.test(e)) {
                bn.info("Preserving excluded property {this}", e);
                return false;
            }
            return i.has(e) || f.has(e);
        }
        function p(e) {
            if (c(e)) f.set(e, true);
            if (!l(e)) u.set(e, true);
        }
        function d(e) {
            if (!l(e)) return e;
            var n = i.get(e);
            if (!n) {
                if (o) {
                    var t = "_$" + e + "$" + s + "_";
                    if (c(t)) n = t;
                }
                if (!n) do {
                    n = T(++r);
                } while (!c(n));
                if (/^#/.test(e)) n = "#" + n;
                i.set(e, n);
            }
            bn.info("Mapping property {name} to {mangled}", {
                mangled: n,
                name: e
            });
            return n;
        }
        function h(e) {
            if (e instanceof On) {
                h(e.tail_node());
            } else if (e instanceof Vn) {
                e.value = d(e.value);
            } else if (e instanceof Nn) {
                h(e.consequent);
                h(e.alternative);
            }
        }
    }
    "use strict";
    var K, Q;
    if (typeof Buffer == "undefined") {
        K = atob;
        Q = btoa;
    } else if (typeof Buffer.alloc == "undefined") {
        K = function(e) {
            return new Buffer(e, "base64").toString();
        };
        Q = function(e) {
            return new Buffer(e).toString("base64");
        };
    } else {
        K = function(e) {
            return Buffer.from(e, "base64").toString();
        };
        Q = function(e) {
            return Buffer.from(e).toString("base64");
        };
    }
    function Z(e, n) {
        var t = n.end.comments_after;
        for (var r = t.length; --r >= 0; ) {
            var i = t[r];
            if (i.type != "comment1") break;
            var a = /^# ([^\s=]+)=(\S+)\s*$/.exec(i.value);
            if (!a) break;
            if (a[1] == "sourceMappingURL") {
                a = /^data:application\/json(;.*?)?;base64,([^,]+)$/.exec(a[2]);
                if (!a) break;
                return K(a[2]);
            }
        }
        bn.warn("inline source map not found: {name}", {
            name: e
        });
    }
    function ee(n) {
        try {
            return JSON.parse(n);
        } catch (e) {
            throw new Error("invalid input source map: " + n);
        }
    }
    function ne(n, t, e) {
        e.forEach(function(e) {
            if (t[e]) {
                if (typeof t[e] != "object") t[e] = {};
                if (!(n in t[e])) t[e][n] = t[n];
            }
        });
    }
    function se(e) {
        if (!e) return;
        if (!("props" in e)) {
            e.props = new gn();
        } else if (!(e.props instanceof gn)) {
            e.props = gn.fromObject(e.props);
        }
    }
    function fe(e) {
        return {
            props: e.props.toObject()
        };
    }
    function ue(r, i) {
        try {
            i = we(i, {
                annotations: undefined,
                compress: {},
                enclose: false,
                expression: false,
                ie: false,
                ie8: false,
                keep_fargs: false,
                keep_fnames: false,
                mangle: {},
                module: false,
                nameCache: null,
                output: {},
                parse: {},
                rename: undefined,
                sourceMap: false,
                timings: false,
                toplevel: !!(i && i["module"]),
                v8: false,
                validate: false,
                warnings: false,
                webkit: false,
                wrap: false
            }, true);
            if (i.validate) bn.enable_validation();
            var e = i.timings && {
                start: Date.now()
            };
            if (i.annotations !== undefined) ne("annotations", i, [ "compress", "output" ]);
            if (i.expression) ne("expression", i, [ "compress", "parse" ]);
            if (i.ie8) i.ie = i.ie || i.ie8;
            if (i.ie) ne("ie", i, [ "compress", "mangle", "output", "rename" ]);
            if (i.keep_fargs) ne("keep_fargs", i, [ "compress", "mangle", "rename" ]);
            if (i.keep_fnames) ne("keep_fnames", i, [ "compress", "mangle", "rename" ]);
            if (i.module) ne("module", i, [ "compress", "parse" ]);
            if (i.toplevel) ne("toplevel", i, [ "compress", "mangle", "rename" ]);
            if (i.v8) ne("v8", i, [ "mangle", "output", "rename" ]);
            if (i.webkit) ne("webkit", i, [ "compress", "mangle", "output", "rename" ]);
            var n;
            if (i.mangle) {
                i.mangle = we(i.mangle, {
                    cache: i.nameCache && (i.nameCache.vars || {}),
                    eval: false,
                    ie: false,
                    keep_fargs: false,
                    keep_fnames: false,
                    properties: false,
                    reserved: [],
                    toplevel: false,
                    v8: false,
                    webkit: false
                }, true);
                if (i.mangle.properties) {
                    if (typeof i.mangle.properties != "object") {
                        i.mangle.properties = {};
                    }
                    if (i.mangle.properties.keep_quoted) {
                        n = i.mangle.properties.reserved;
                        if (!Array.isArray(n)) n = [];
                        i.mangle.properties.reserved = n;
                    }
                    if (i.nameCache && !("cache" in i.mangle.properties)) {
                        i.mangle.properties.cache = i.nameCache.props || {};
                    }
                }
                se(i.mangle.cache);
                se(i.mangle.properties.cache);
            }
            if (i.rename === undefined) i.rename = i.compress && i.mangle;
            if (i.sourceMap) {
                i.sourceMap = we(i.sourceMap, {
                    content: null,
                    filename: null,
                    includeSources: false,
                    names: true,
                    root: null,
                    url: null
                }, true);
            }
            var t = [];
            if (i.warnings) bn.log_function(function(e) {
                t.push(e);
            }, i.warnings == "verbose");
            if (e) e.parse = Date.now();
            var a;
            i.parse = i.parse || {};
            if (r instanceof bn) {
                a = r;
            } else {
                if (typeof r == "string") r = [ r ];
                i.parse.toplevel = null;
                var o = i.sourceMap && i.sourceMap.content;
                if (typeof o == "string" && o != "inline") {
                    o = ee(o);
                }
                if (o) i.sourceMap.orig = Object.create(null);
                for (var s in r) if (it(r, s)) {
                    i.parse.filename = s;
                    i.parse.toplevel = a = ci(r[s], i.parse);
                    if (o == "inline") {
                        var f = Z(s, a);
                        if (f) i.sourceMap.orig[s] = ee(f);
                    } else if (o) {
                        i.sourceMap.orig[s] = o;
                    }
                }
            }
            if (i.parse.expression) a = a.wrap_expression();
            if (n) G(a, n);
            [ "enclose", "wrap" ].forEach(function(e) {
                var n = i[e];
                if (!n) return;
                var t = a.print_to_string().slice(0, -1);
                a = a[e](n);
                r[a.start.file] = a.print_to_string().replace(t, "");
            });
            if (i.validate) a.validate_ast();
            if (e) e.rename = Date.now();
            if (i.rename) {
                a.figure_out_scope(i.rename);
                a.expand_names(i.rename);
            }
            if (e) e.compress = Date.now();
            if (i.compress) {
                a = new hi(i.compress).compress(a);
                if (i.validate) a.validate_ast();
            }
            if (e) e.scope = Date.now();
            if (i.mangle) a.figure_out_scope(i.mangle);
            if (e) e.mangle = Date.now();
            if (i.mangle) {
                a.compute_char_frequency(i.mangle);
                a.mangle_names(i.mangle);
            }
            if (e) e.properties = Date.now();
            if (n) G(a, n);
            if (i.mangle && i.mangle.properties) X(a, i.mangle.properties);
            if (i.parse.expression) a = a.unwrap_expression();
            if (e) e.output = Date.now();
            var u = {};
            var c = we(i.output, {
                ast: false,
                code: true
            });
            if (c.ast) u.ast = a;
            if (c.code) {
                if (i.sourceMap) {
                    c.source_map = z(i.sourceMap);
                    if (i.sourceMap.includeSources) {
                        if (r instanceof kt) {
                            throw new Error("original source content unavailable");
                        } else for (var s in r) if (it(r, s)) {
                            c.source_map.setSourceContent(s, r[s]);
                        }
                    }
                }
                delete c.ast;
                delete c.code;
                var l = vi(c);
                a.print(l);
                u.code = l.get();
                if (i.sourceMap) {
                    u.map = c.source_map.toString();
                    var p = i.sourceMap.url;
                    if (p) {
                        u.code = u.code.replace(/\n\/\/# sourceMappingURL=\S+\s*$/, "");
                        if (p == "inline") {
                            u.code += "\n//# sourceMappingURL=data:application/json;charset=utf-8;base64," + Q(u.map);
                        } else {
                            u.code += "\n//# sourceMappingURL=" + p;
                        }
                    }
                }
            }
            if (i.nameCache && i.mangle) {
                if (i.mangle.cache) i.nameCache.vars = fe(i.mangle.cache);
                if (i.mangle.properties && i.mangle.properties.cache) {
                    i.nameCache.props = fe(i.mangle.properties.cache);
                }
            }
            if (e) {
                e.end = Date.now();
                u.timings = {
                    parse: .001 * (e.rename - e.parse),
                    rename: .001 * (e.compress - e.rename),
                    compress: .001 * (e.scope - e.compress),
                    scope: .001 * (e.mangle - e.scope),
                    mangle: .001 * (e.properties - e.mangle),
                    properties: .001 * (e.output - e.properties),
                    output: .001 * (e.end - e.output),
                    total: .001 * (e.end - e.start)
                };
            }
            if (t.length) {
                u.warnings = t;
            }
            return u;
        } catch (e) {
            return {
                error: e
            };
        } finally {
            bn.log_function();
            bn.disable_validation();
        }
    }
    b["Dictionary"] = gn;
    b["is_statement"] = ut;
    b["List"] = et;
    b["minify"] = ue;
    b["parse"] = ci;
    b["push_uniq"] = nt;
    b["TreeTransformer"] = ii;
    b["TreeWalker"] = Gn;
})(typeof UglifyJS == "undefined" ? UglifyJS = {} : UglifyJS);
// @license-end
