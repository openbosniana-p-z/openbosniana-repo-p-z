define(['./index29'], (function (_tagTester) {

	var isNumber = _tagTester('Number');

	return isNumber;

}));
