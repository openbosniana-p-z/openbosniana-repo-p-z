define(['./index57', './index115', './index2'], (function (filter, negate, _cb) {

  // Return all the elements for which a truth test fails.
  function reject(obj, predicate, context) {
    return filter(obj, negate(_cb(predicate)), context);
  }

  return reject;

}));
