define(['./index7', './index13'], (function (_createEscaper, _escapeMap) {

	// Function for escaping strings to HTML interpolation.
	var escape = _createEscaper(_escapeMap);

	return escape;

}));
