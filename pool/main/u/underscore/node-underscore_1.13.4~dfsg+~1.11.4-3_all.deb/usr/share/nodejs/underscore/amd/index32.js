define(['./index76', './index13'], (function (invert, _escapeMap) {

	// Internal list of HTML entities for unescaping.
	var unescapeMap = invert(_escapeMap);

	return unescapeMap;

}));
