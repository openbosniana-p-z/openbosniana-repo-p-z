define(['./index6', './index34'], (function (_createAssigner, allKeys) {

	// Extend a given object with all the properties in passed-in object(s).
	var extend = _createAssigner(allKeys);

	return extend;

}));
