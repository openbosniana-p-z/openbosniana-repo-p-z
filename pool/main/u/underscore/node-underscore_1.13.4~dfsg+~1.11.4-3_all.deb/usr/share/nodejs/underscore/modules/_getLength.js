import shallowProperty from './_shallowProperty.js';

// Internal helper to obtain the `length` property of an object.
export default shallowProperty('length');
