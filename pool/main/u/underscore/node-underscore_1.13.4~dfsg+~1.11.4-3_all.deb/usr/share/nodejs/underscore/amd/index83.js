define(['./index29'], (function (_tagTester) {

	var isDate = _tagTester('Date');

	return isDate;

}));
