define(['./index122', './index50', './index150'], (function (partial, delay, underscore) {

	// Defers a function, scheduling it to run after the current call stack has
	// cleared.
	var defer = partial(delay, underscore, 1);

	return defer;

}));
