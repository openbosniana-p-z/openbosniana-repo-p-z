define((function () {

  // Keep the identity function around for default iteratees.
  function identity(value) {
    return value;
  }

  return identity;

}));
