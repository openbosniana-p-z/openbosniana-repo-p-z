//     Underscore.js 1.13.4
//     https://underscorejs.org
//     (c) 2009-2022 Jeremy Ashkenas, Julian Gonggrijp, and DocumentCloud and Investigative Reporters & Editors
//     Underscore may be freely distributed under the MIT license.

var underscoreNodeF = require('./underscore-node-f.cjs');



module.exports = underscoreNodeF._;
//# sourceMappingURL=underscore-node.cjs.map
