define(['./index29'], (function (_tagTester) {

	var isRegExp = _tagTester('RegExp');

	return isRegExp;

}));
