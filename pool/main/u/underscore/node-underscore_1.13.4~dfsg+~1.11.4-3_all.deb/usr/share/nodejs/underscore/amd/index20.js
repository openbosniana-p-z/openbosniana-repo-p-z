define(['./index29'], (function (_tagTester) {

	var hasObjectTag = _tagTester('Object');

	return hasObjectTag;

}));
