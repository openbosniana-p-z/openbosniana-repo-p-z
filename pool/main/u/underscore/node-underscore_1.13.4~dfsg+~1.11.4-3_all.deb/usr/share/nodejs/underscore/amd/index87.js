define(['./index29'], (function (_tagTester) {

	var isError = _tagTester('Error');

	return isError;

}));
