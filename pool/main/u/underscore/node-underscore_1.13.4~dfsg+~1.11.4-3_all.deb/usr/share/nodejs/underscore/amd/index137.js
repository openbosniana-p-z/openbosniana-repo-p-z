define(['./index135'], (function (sample) {

  // Shuffle a collection.
  function shuffle(obj) {
    return sample(obj, Infinity);
  }

  return shuffle;

}));
