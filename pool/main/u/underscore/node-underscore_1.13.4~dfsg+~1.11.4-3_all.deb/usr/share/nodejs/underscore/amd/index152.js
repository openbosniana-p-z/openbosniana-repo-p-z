define(['./index7', './index32'], (function (_createEscaper, _unescapeMap) {

	// Function for unescaping strings from HTML interpolation.
	var unescape = _createEscaper(_unescapeMap);

	return unescape;

}));
