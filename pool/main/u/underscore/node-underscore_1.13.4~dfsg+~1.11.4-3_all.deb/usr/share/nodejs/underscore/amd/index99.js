define(['./index29'], (function (_tagTester) {

	var isSymbol = _tagTester('Symbol');

	return isSymbol;

}));
