define(['./index29'], (function (_tagTester) {

	var isString = _tagTester('String');

	return isString;

}));
