/* include/lttng/ust-config.h.  Generated from ust-config.h.in by configure.  */
/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _LTTNG_UST_CONFIG_H
#define _LTTNG_UST_CONFIG_H

/* lttng/ust-config.h.in. Manually generated for control over the contained defs. */

/* DTrace/GDB/SystemTap integration via sdt.h */
/* #undef LTTNG_UST_HAVE_SDT_INTEGRATION */

#endif
