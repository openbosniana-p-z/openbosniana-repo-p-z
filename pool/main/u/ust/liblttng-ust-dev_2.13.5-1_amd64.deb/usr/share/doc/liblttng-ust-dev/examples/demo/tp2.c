/*
 * SPDX-License-Identifier: MIT
 *
 * Copyright (C) 2011 Mathieu Desnoyers <mathieu.desnoyers@efficios.com>
 */

#define LTTNG_UST_TRACEPOINT_CREATE_PROBES
#include "ust_tests_demo2.h"
