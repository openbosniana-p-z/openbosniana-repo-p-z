/*
 * SPDX-License-Identifier: MIT
 *
 * Copyright (C) 2016 Sebastien Boisvert <sboisvert@gydle.com>
 */

#include "aligner-lib.h"

int main(void)
{
	align_query("molecule-foo");

	return 0;
}
