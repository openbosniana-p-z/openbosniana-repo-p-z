/*
 * SPDX-License-Identifier: MIT
 *
 * Copyright (C) 2016 Sebastien Boisvert <sboisvert@gydle.com>
 */

#ifndef TEST_LIB_H
#define TEST_LIB_H

#include <string>

void test_alignment(const std::string &alignment);

#endif
