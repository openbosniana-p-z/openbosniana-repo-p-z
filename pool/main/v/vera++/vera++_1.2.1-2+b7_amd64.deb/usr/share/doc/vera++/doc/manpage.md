% VERA++(1) Vera++ User Manuals
% Maciej Sobczak; Vincent Hobeïka; Gaëtan Lehmann
% April 10, 2013

NAME
====

vera++ - Programmable verification and analysis tool for C++

SYNOPSIS
========

vera++ *[options]  [file ...]*

