var vamp_sdk_2PluginBase_8h =
[
    [ "Vamp::PluginBase", "classVamp_1_1PluginBase.html", "classVamp_1_1PluginBase" ],
    [ "Vamp::PluginBase::ParameterDescriptor", "structVamp_1_1PluginBase_1_1ParameterDescriptor.html", "structVamp_1_1PluginBase_1_1ParameterDescriptor" ]
];