var annotated_dup =
[
    [ "Vamp", "namespaceVamp.html", [
      [ "HostExt", "namespaceVamp_1_1HostExt.html", [
        [ "PluginBufferingAdapter", "classVamp_1_1HostExt_1_1PluginBufferingAdapter.html", "classVamp_1_1HostExt_1_1PluginBufferingAdapter" ],
        [ "PluginChannelAdapter", "classVamp_1_1HostExt_1_1PluginChannelAdapter.html", "classVamp_1_1HostExt_1_1PluginChannelAdapter" ],
        [ "PluginInputDomainAdapter", "classVamp_1_1HostExt_1_1PluginInputDomainAdapter.html", "classVamp_1_1HostExt_1_1PluginInputDomainAdapter" ],
        [ "PluginLoader", "classVamp_1_1HostExt_1_1PluginLoader.html", "classVamp_1_1HostExt_1_1PluginLoader" ],
        [ "PluginSummarisingAdapter", "classVamp_1_1HostExt_1_1PluginSummarisingAdapter.html", "classVamp_1_1HostExt_1_1PluginSummarisingAdapter" ],
        [ "PluginWrapper", "classVamp_1_1HostExt_1_1PluginWrapper.html", "classVamp_1_1HostExt_1_1PluginWrapper" ]
      ] ],
      [ "FFT", "classVamp_1_1FFT.html", "classVamp_1_1FFT" ],
      [ "FFTComplex", "classVamp_1_1FFTComplex.html", "classVamp_1_1FFTComplex" ],
      [ "FFTReal", "classVamp_1_1FFTReal.html", "classVamp_1_1FFTReal" ],
      [ "Plugin", "classVamp_1_1Plugin.html", "classVamp_1_1Plugin" ],
      [ "PluginAdapter", "classVamp_1_1PluginAdapter.html", "classVamp_1_1PluginAdapter" ],
      [ "PluginAdapterBase", "classVamp_1_1PluginAdapterBase.html", "classVamp_1_1PluginAdapterBase" ],
      [ "PluginBase", "classVamp_1_1PluginBase.html", "classVamp_1_1PluginBase" ],
      [ "PluginHostAdapter", "classVamp_1_1PluginHostAdapter.html", "classVamp_1_1PluginHostAdapter" ],
      [ "RealTime", "structVamp_1_1RealTime.html", "structVamp_1_1RealTime" ]
    ] ],
    [ "_VampFeature", "struct__VampFeature.html", "struct__VampFeature" ],
    [ "_VampFeatureList", "struct__VampFeatureList.html", "struct__VampFeatureList" ],
    [ "_VampFeatureUnion", "union__VampFeatureUnion.html", "union__VampFeatureUnion" ],
    [ "_VampFeatureV2", "struct__VampFeatureV2.html", "struct__VampFeatureV2" ],
    [ "_VampOutputDescriptor", "struct__VampOutputDescriptor.html", "struct__VampOutputDescriptor" ],
    [ "_VampParameterDescriptor", "struct__VampParameterDescriptor.html", "struct__VampParameterDescriptor" ],
    [ "_VampPluginDescriptor", "struct__VampPluginDescriptor.html", "struct__VampPluginDescriptor" ],
    [ "AmplitudeFollower", "classAmplitudeFollower.html", "classAmplitudeFollower" ],
    [ "FixedTempoEstimator", "classFixedTempoEstimator.html", "classFixedTempoEstimator" ],
    [ "PercussionOnsetDetector", "classPercussionOnsetDetector.html", "classPercussionOnsetDetector" ],
    [ "PowerSpectrum", "classPowerSpectrum.html", "classPowerSpectrum" ],
    [ "SpectralCentroid", "classSpectralCentroid.html", "classSpectralCentroid" ],
    [ "ZeroCrossing", "classZeroCrossing.html", "classZeroCrossing" ]
];