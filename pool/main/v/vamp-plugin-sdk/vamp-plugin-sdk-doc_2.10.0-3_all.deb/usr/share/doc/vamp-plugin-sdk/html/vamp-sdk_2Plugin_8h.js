var vamp_sdk_2Plugin_8h =
[
    [ "Vamp::Plugin", "classVamp_1_1Plugin.html", "classVamp_1_1Plugin" ],
    [ "Vamp::Plugin::OutputDescriptor", "structVamp_1_1Plugin_1_1OutputDescriptor.html", "structVamp_1_1Plugin_1_1OutputDescriptor" ],
    [ "Vamp::Plugin::Feature", "structVamp_1_1Plugin_1_1Feature.html", "structVamp_1_1Plugin_1_1Feature" ]
];