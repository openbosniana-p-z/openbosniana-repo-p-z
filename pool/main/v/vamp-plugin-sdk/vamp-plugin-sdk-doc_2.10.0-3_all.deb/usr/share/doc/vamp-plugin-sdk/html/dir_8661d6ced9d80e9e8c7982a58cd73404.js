var dir_8661d6ced9d80e9e8c7982a58cd73404 =
[
    [ "FFT.h", "FFT_8h.html", "FFT_8h" ],
    [ "plugguard.h", "plugguard_8h.html", "plugguard_8h" ],
    [ "vamp-sdk/Plugin.h", "vamp-sdk_2Plugin_8h.html", "vamp-sdk_2Plugin_8h" ],
    [ "PluginAdapter.h", "PluginAdapter_8h.html", "PluginAdapter_8h" ],
    [ "vamp-sdk/PluginBase.h", "vamp-sdk_2PluginBase_8h.html", "vamp-sdk_2PluginBase_8h" ],
    [ "vamp-sdk/RealTime.h", "vamp-sdk_2RealTime_8h.html", "vamp-sdk_2RealTime_8h" ],
    [ "vamp-sdk.h", "vamp-sdk_8h.html", null ]
];