var struct__VampOutputDescriptor =
[
    [ "identifier", "struct__VampOutputDescriptor.html#a461161b2010370176115967e4f58a5f5", null ],
    [ "name", "struct__VampOutputDescriptor.html#af4fca576bd47167fd2bf9b43d588815f", null ],
    [ "description", "struct__VampOutputDescriptor.html#abfa911b138cfb80cf63e8f2e0fa0fb89", null ],
    [ "unit", "struct__VampOutputDescriptor.html#ad038caa8e596dfd037035637202f1d63", null ],
    [ "hasFixedBinCount", "struct__VampOutputDescriptor.html#ae8571f5a2bc740738af0cb7dda0c4749", null ],
    [ "binCount", "struct__VampOutputDescriptor.html#a652ee422092720e44d23d98bdb68f978", null ],
    [ "binNames", "struct__VampOutputDescriptor.html#a10fffaa32bd894843ff7592240dfe447", null ],
    [ "hasKnownExtents", "struct__VampOutputDescriptor.html#af6b512d772023b4e852216689c1c4465", null ],
    [ "minValue", "struct__VampOutputDescriptor.html#a9a28180989e3d028c12a98517479dc46", null ],
    [ "maxValue", "struct__VampOutputDescriptor.html#a4cbe540a247df60f85b00b2aa16461ee", null ],
    [ "isQuantized", "struct__VampOutputDescriptor.html#ab56cf0bbb17136819024574d5cc65e30", null ],
    [ "quantizeStep", "struct__VampOutputDescriptor.html#a71aa40222dda4321030cccd0bb655fe3", null ],
    [ "sampleType", "struct__VampOutputDescriptor.html#a5da1d27cc99badc214640e859b882072", null ],
    [ "sampleRate", "struct__VampOutputDescriptor.html#a1ccf193317b2b9c2eb0dbd8dcf61d26e", null ],
    [ "hasDuration", "struct__VampOutputDescriptor.html#af792a96dbf292ec966b9b68250febd99", null ]
];