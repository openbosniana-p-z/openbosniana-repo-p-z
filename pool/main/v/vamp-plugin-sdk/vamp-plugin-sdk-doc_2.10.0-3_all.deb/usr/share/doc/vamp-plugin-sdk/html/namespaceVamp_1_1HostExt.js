var namespaceVamp_1_1HostExt =
[
    [ "PluginBufferingAdapter", "classVamp_1_1HostExt_1_1PluginBufferingAdapter.html", "classVamp_1_1HostExt_1_1PluginBufferingAdapter" ],
    [ "PluginChannelAdapter", "classVamp_1_1HostExt_1_1PluginChannelAdapter.html", "classVamp_1_1HostExt_1_1PluginChannelAdapter" ],
    [ "PluginInputDomainAdapter", "classVamp_1_1HostExt_1_1PluginInputDomainAdapter.html", "classVamp_1_1HostExt_1_1PluginInputDomainAdapter" ],
    [ "PluginLoader", "classVamp_1_1HostExt_1_1PluginLoader.html", "classVamp_1_1HostExt_1_1PluginLoader" ],
    [ "PluginSummarisingAdapter", "classVamp_1_1HostExt_1_1PluginSummarisingAdapter.html", "classVamp_1_1HostExt_1_1PluginSummarisingAdapter" ],
    [ "PluginWrapper", "classVamp_1_1HostExt_1_1PluginWrapper.html", "classVamp_1_1HostExt_1_1PluginWrapper" ]
];