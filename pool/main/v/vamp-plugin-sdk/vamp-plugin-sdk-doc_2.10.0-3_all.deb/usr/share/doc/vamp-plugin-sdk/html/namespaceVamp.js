var namespaceVamp =
[
    [ "HostExt", "namespaceVamp_1_1HostExt.html", "namespaceVamp_1_1HostExt" ],
    [ "FFT", "classVamp_1_1FFT.html", "classVamp_1_1FFT" ],
    [ "FFTComplex", "classVamp_1_1FFTComplex.html", "classVamp_1_1FFTComplex" ],
    [ "FFTReal", "classVamp_1_1FFTReal.html", "classVamp_1_1FFTReal" ],
    [ "Plugin", "classVamp_1_1Plugin.html", "classVamp_1_1Plugin" ],
    [ "PluginAdapter", "classVamp_1_1PluginAdapter.html", "classVamp_1_1PluginAdapter" ],
    [ "PluginAdapterBase", "classVamp_1_1PluginAdapterBase.html", "classVamp_1_1PluginAdapterBase" ],
    [ "PluginBase", "classVamp_1_1PluginBase.html", "classVamp_1_1PluginBase" ],
    [ "PluginHostAdapter", "classVamp_1_1PluginHostAdapter.html", "classVamp_1_1PluginHostAdapter" ],
    [ "RealTime", "structVamp_1_1RealTime.html", "structVamp_1_1RealTime" ],
    [ "operator<<", "namespaceVamp.html#a84f347b339c111e035f4f0d6ed37f4e0", null ]
];