var namespaces_dup =
[
    [ "Vamp", "namespaceVamp.html", "namespaceVamp" ]
];