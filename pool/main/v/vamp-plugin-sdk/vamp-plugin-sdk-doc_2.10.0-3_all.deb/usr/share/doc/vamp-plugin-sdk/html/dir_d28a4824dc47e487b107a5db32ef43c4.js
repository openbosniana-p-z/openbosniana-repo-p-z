var dir_d28a4824dc47e487b107a5db32ef43c4 =
[
    [ "AmplitudeFollower.cpp", "AmplitudeFollower_8cpp.html", null ],
    [ "AmplitudeFollower.h", "AmplitudeFollower_8h.html", "AmplitudeFollower_8h" ],
    [ "FixedTempoEstimator.cpp", "FixedTempoEstimator_8cpp.html", "FixedTempoEstimator_8cpp" ],
    [ "FixedTempoEstimator.h", "FixedTempoEstimator_8h.html", "FixedTempoEstimator_8h" ],
    [ "PercussionOnsetDetector.cpp", "PercussionOnsetDetector_8cpp.html", null ],
    [ "PercussionOnsetDetector.h", "PercussionOnsetDetector_8h.html", "PercussionOnsetDetector_8h" ],
    [ "plugins.cpp", "plugins_8cpp.html", "plugins_8cpp" ],
    [ "PowerSpectrum.cpp", "PowerSpectrum_8cpp.html", null ],
    [ "PowerSpectrum.h", "PowerSpectrum_8h.html", "PowerSpectrum_8h" ],
    [ "SpectralCentroid.cpp", "SpectralCentroid_8cpp.html", null ],
    [ "SpectralCentroid.h", "SpectralCentroid_8h.html", "SpectralCentroid_8h" ],
    [ "ZeroCrossing.cpp", "ZeroCrossing_8cpp.html", null ],
    [ "ZeroCrossing.h", "ZeroCrossing_8h.html", "ZeroCrossing_8h" ]
];