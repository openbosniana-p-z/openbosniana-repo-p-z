var structVamp_1_1Plugin_1_1Feature =
[
    [ "Feature", "structVamp_1_1Plugin_1_1Feature.html#acd4b4cd0d2c31512f4a5df50f8f7a7b8", null ],
    [ "hasTimestamp", "structVamp_1_1Plugin_1_1Feature.html#a98907091d0b6a589720ae35ae588a82b", null ],
    [ "timestamp", "structVamp_1_1Plugin_1_1Feature.html#acaa605f36839c07e76f4882f5e22d8d7", null ],
    [ "hasDuration", "structVamp_1_1Plugin_1_1Feature.html#a33686757bd4481c72494122e9bfb9fba", null ],
    [ "duration", "structVamp_1_1Plugin_1_1Feature.html#af687c0a7fe041757e922ec296862b115", null ],
    [ "values", "structVamp_1_1Plugin_1_1Feature.html#a60b9f3057386820dbcaec0eb1189ce71", null ],
    [ "label", "structVamp_1_1Plugin_1_1Feature.html#a8eb1fb35f73b247ed13de9527c18f036", null ]
];