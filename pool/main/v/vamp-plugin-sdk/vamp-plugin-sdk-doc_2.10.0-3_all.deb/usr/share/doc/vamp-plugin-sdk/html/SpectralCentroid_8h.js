var SpectralCentroid_8h =
[
    [ "SpectralCentroid", "classSpectralCentroid.html", "classSpectralCentroid" ]
];