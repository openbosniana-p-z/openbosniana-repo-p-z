var PluginHostAdapter_8h =
[
    [ "Vamp::PluginHostAdapter", "classVamp_1_1PluginHostAdapter.html", "classVamp_1_1PluginHostAdapter" ]
];