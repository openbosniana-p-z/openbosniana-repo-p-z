var struct__VampFeatureV2 =
[
    [ "hasDuration", "struct__VampFeatureV2.html#a44d9c57f1ae197d3fec1a48c650cce81", null ],
    [ "durationSec", "struct__VampFeatureV2.html#abc95aac3a2efdef6ef0b17e7b6bd3daf", null ],
    [ "durationNsec", "struct__VampFeatureV2.html#af71693d907f69048d602d28edbce679e", null ]
];