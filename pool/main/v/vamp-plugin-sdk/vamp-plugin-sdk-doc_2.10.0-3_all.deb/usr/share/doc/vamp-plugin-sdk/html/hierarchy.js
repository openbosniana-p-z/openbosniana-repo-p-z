var hierarchy =
[
    [ "_VampFeature", "struct__VampFeature.html", null ],
    [ "_VampFeatureList", "struct__VampFeatureList.html", null ],
    [ "_VampFeatureUnion", "union__VampFeatureUnion.html", null ],
    [ "_VampFeatureV2", "struct__VampFeatureV2.html", null ],
    [ "_VampOutputDescriptor", "struct__VampOutputDescriptor.html", null ],
    [ "_VampParameterDescriptor", "struct__VampParameterDescriptor.html", null ],
    [ "_VampPluginDescriptor", "struct__VampPluginDescriptor.html", null ],
    [ "FixedTempoEstimator::D", "classFixedTempoEstimator_1_1D.html", null ],
    [ "Vamp::Plugin::Feature", "structVamp_1_1Plugin_1_1Feature.html", null ],
    [ "Vamp::FFT", "classVamp_1_1FFT.html", null ],
    [ "Vamp::FFTComplex", "classVamp_1_1FFTComplex.html", null ],
    [ "Vamp::FFTReal", "classVamp_1_1FFTReal.html", null ],
    [ "Vamp::Plugin::OutputDescriptor", "structVamp_1_1Plugin_1_1OutputDescriptor.html", null ],
    [ "Vamp::PluginBase::ParameterDescriptor", "structVamp_1_1PluginBase_1_1ParameterDescriptor.html", null ],
    [ "Vamp::PluginAdapterBase", "classVamp_1_1PluginAdapterBase.html", [
      [ "Vamp::PluginAdapter< P >", "classVamp_1_1PluginAdapter.html", null ]
    ] ],
    [ "Vamp::PluginBase", "classVamp_1_1PluginBase.html", [
      [ "Vamp::Plugin", "classVamp_1_1Plugin.html", [
        [ "AmplitudeFollower", "classAmplitudeFollower.html", null ],
        [ "FixedTempoEstimator", "classFixedTempoEstimator.html", null ],
        [ "PercussionOnsetDetector", "classPercussionOnsetDetector.html", null ],
        [ "PowerSpectrum", "classPowerSpectrum.html", null ],
        [ "SpectralCentroid", "classSpectralCentroid.html", null ],
        [ "Vamp::HostExt::PluginWrapper", "classVamp_1_1HostExt_1_1PluginWrapper.html", [
          [ "Vamp::HostExt::PluginBufferingAdapter", "classVamp_1_1HostExt_1_1PluginBufferingAdapter.html", null ],
          [ "Vamp::HostExt::PluginChannelAdapter", "classVamp_1_1HostExt_1_1PluginChannelAdapter.html", null ],
          [ "Vamp::HostExt::PluginInputDomainAdapter", "classVamp_1_1HostExt_1_1PluginInputDomainAdapter.html", null ],
          [ "Vamp::HostExt::PluginSummarisingAdapter", "classVamp_1_1HostExt_1_1PluginSummarisingAdapter.html", null ]
        ] ],
        [ "Vamp::PluginHostAdapter", "classVamp_1_1PluginHostAdapter.html", null ],
        [ "ZeroCrossing", "classZeroCrossing.html", null ]
      ] ]
    ] ],
    [ "Vamp::HostExt::PluginLoader", "classVamp_1_1HostExt_1_1PluginLoader.html", null ],
    [ "Vamp::RealTime", "structVamp_1_1RealTime.html", null ]
];