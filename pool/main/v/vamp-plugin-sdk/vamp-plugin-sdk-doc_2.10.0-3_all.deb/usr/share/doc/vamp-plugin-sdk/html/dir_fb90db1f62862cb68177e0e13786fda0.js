var dir_fb90db1f62862cb68177e0e13786fda0 =
[
    [ "host-c.h", "host-c_8h.html", "host-c_8h" ],
    [ "hostguard.h", "hostguard_8h.html", "hostguard_8h" ],
    [ "vamp-hostsdk/Plugin.h", "vamp-hostsdk_2Plugin_8h.html", null ],
    [ "vamp-hostsdk/PluginBase.h", "vamp-hostsdk_2PluginBase_8h.html", null ],
    [ "PluginBufferingAdapter.h", "PluginBufferingAdapter_8h.html", "PluginBufferingAdapter_8h" ],
    [ "PluginChannelAdapter.h", "PluginChannelAdapter_8h.html", "PluginChannelAdapter_8h" ],
    [ "PluginHostAdapter.h", "PluginHostAdapter_8h.html", "PluginHostAdapter_8h" ],
    [ "PluginInputDomainAdapter.h", "PluginInputDomainAdapter_8h.html", "PluginInputDomainAdapter_8h" ],
    [ "PluginLoader.h", "PluginLoader_8h.html", "PluginLoader_8h" ],
    [ "PluginSummarisingAdapter.h", "PluginSummarisingAdapter_8h.html", "PluginSummarisingAdapter_8h" ],
    [ "PluginWrapper.h", "PluginWrapper_8h.html", "PluginWrapper_8h" ],
    [ "vamp-hostsdk/RealTime.h", "vamp-hostsdk_2RealTime_8h.html", null ],
    [ "vamp-hostsdk.h", "vamp-hostsdk_8h.html", null ]
];