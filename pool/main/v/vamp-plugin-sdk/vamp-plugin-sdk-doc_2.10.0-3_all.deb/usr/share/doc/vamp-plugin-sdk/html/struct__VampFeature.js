var struct__VampFeature =
[
    [ "hasTimestamp", "struct__VampFeature.html#abe6aa7a08185beeb9deca2d08d99859f", null ],
    [ "sec", "struct__VampFeature.html#a31f0b57050e33d082692536097953d9c", null ],
    [ "nsec", "struct__VampFeature.html#a8874cb23600c6b10ca6e8a40920d999e", null ],
    [ "valueCount", "struct__VampFeature.html#ab1ce7c8a2b489e9b0694a967497a29fd", null ],
    [ "values", "struct__VampFeature.html#ae4030f941ddb2bab8bc147b88e1f1c15", null ],
    [ "label", "struct__VampFeature.html#a6662b7489a7890cae713bf4e8f6d52cd", null ]
];