var files_dup =
[
    [ "examples", "dir_d28a4824dc47e487b107a5db32ef43c4.html", "dir_d28a4824dc47e487b107a5db32ef43c4" ],
    [ "host", "dir_4f7e4242e27b8c8b476722507617a881.html", "dir_4f7e4242e27b8c8b476722507617a881" ],
    [ "src", "dir_68267d1309a1af8e8297ef4c3efbcdba.html", "dir_68267d1309a1af8e8297ef4c3efbcdba" ],
    [ "vamp", "dir_9c751ccb9387a8f0ae6ae8f777da02a0.html", "dir_9c751ccb9387a8f0ae6ae8f777da02a0" ],
    [ "vamp-hostsdk", "dir_fb90db1f62862cb68177e0e13786fda0.html", "dir_fb90db1f62862cb68177e0e13786fda0" ],
    [ "vamp-sdk", "dir_8661d6ced9d80e9e8c7982a58cd73404.html", "dir_8661d6ced9d80e9e8c7982a58cd73404" ]
];