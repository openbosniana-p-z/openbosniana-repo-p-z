var structVamp_1_1PluginBase_1_1ParameterDescriptor =
[
    [ "ParameterDescriptor", "structVamp_1_1PluginBase_1_1ParameterDescriptor.html#a5b793130e9746b2302317b3c9a9c1395", null ],
    [ "identifier", "structVamp_1_1PluginBase_1_1ParameterDescriptor.html#a116fd9f0dc94c2bc4bbc60b5443c598c", null ],
    [ "name", "structVamp_1_1PluginBase_1_1ParameterDescriptor.html#a0ecebb94fb4ada4aad2640e20aa57084", null ],
    [ "description", "structVamp_1_1PluginBase_1_1ParameterDescriptor.html#a780ddad41e433d85c82f9ea4d959cbaf", null ],
    [ "unit", "structVamp_1_1PluginBase_1_1ParameterDescriptor.html#a3bc3df322e4c02e17e96bc6d44982d7b", null ],
    [ "minValue", "structVamp_1_1PluginBase_1_1ParameterDescriptor.html#ab3e4d84f5bc199eea8b642b27e425ec8", null ],
    [ "maxValue", "structVamp_1_1PluginBase_1_1ParameterDescriptor.html#ab934b20dd708228a0e3c2811a3e2cec4", null ],
    [ "defaultValue", "structVamp_1_1PluginBase_1_1ParameterDescriptor.html#aec4ef77451ec02193ecc4a0856673fbc", null ],
    [ "isQuantized", "structVamp_1_1PluginBase_1_1ParameterDescriptor.html#a7c556d58d552f737ee5a34efdf7f9425", null ],
    [ "quantizeStep", "structVamp_1_1PluginBase_1_1ParameterDescriptor.html#a01f8387e7c853d5e4e35d4e9a37353d7", null ],
    [ "valueNames", "structVamp_1_1PluginBase_1_1ParameterDescriptor.html#a94df96f53835980b4739965007ff222b", null ]
];