var classVamp_1_1PluginAdapterBase =
[
    [ "~PluginAdapterBase", "classVamp_1_1PluginAdapterBase.html#aaa8afd318b6c3da108e1cbcc7e46603d", null ],
    [ "PluginAdapterBase", "classVamp_1_1PluginAdapterBase.html#a5dad6a9b4b170c0f284962e125ac988e", null ],
    [ "getDescriptor", "classVamp_1_1PluginAdapterBase.html#a7ff5c9374a8dc43f977c3707d1da45b5", null ],
    [ "createPlugin", "classVamp_1_1PluginAdapterBase.html#a297abd48ed0924ec5f3618529816c093", null ],
    [ "m_impl", "classVamp_1_1PluginAdapterBase.html#a0e3594c54884efd5a7ef38030645745b", null ]
];