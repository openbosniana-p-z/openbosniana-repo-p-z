var AmplitudeFollower_8h =
[
    [ "AmplitudeFollower", "classAmplitudeFollower.html", "classAmplitudeFollower" ]
];