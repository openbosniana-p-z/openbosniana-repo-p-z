var vamp_simple_host_8cpp =
[
    [ "HOST_VERSION", "vamp-simple-host_8cpp.html#aa8bc193818940a8954ef0e0e5a8e16d6", null ],
    [ "Verbosity", "vamp-simple-host_8cpp.html#abf3be10d03894afb391f3a2935e3b313", [
      [ "PluginIds", "vamp-simple-host_8cpp.html#abf3be10d03894afb391f3a2935e3b313a4cf6a0dfdb6864356feab9d9ca230d16", null ],
      [ "PluginOutputIds", "vamp-simple-host_8cpp.html#abf3be10d03894afb391f3a2935e3b313a30eab122efa9537df4ecb2fc27fc354e", null ],
      [ "PluginInformation", "vamp-simple-host_8cpp.html#abf3be10d03894afb391f3a2935e3b313a8acba147ed4716f3baa8546f6dc055a1", null ],
      [ "PluginInformationDetailed", "vamp-simple-host_8cpp.html#abf3be10d03894afb391f3a2935e3b313a2624ce417628b6d40ce0973ba381c1e6", null ]
    ] ],
    [ "printFeatures", "vamp-simple-host_8cpp.html#ac0aeb001c8eebe86d5e16cddd5db30e5", null ],
    [ "transformInput", "vamp-simple-host_8cpp.html#ae610372882497afdeaf180a7e53eb00b", null ],
    [ "fft", "vamp-simple-host_8cpp.html#ab40a86a032d0cf473d15fed3616ccc57", null ],
    [ "printPluginPath", "vamp-simple-host_8cpp.html#a4767f8c142ee0b61ba414df1b0376a01", null ],
    [ "printPluginCategoryList", "vamp-simple-host_8cpp.html#af771864c41f23e5755ed99e8ac6609a5", null ],
    [ "enumeratePlugins", "vamp-simple-host_8cpp.html#a80dad9e80d85fdf86b7714bf1b3c1017", null ],
    [ "listPluginsInLibrary", "vamp-simple-host_8cpp.html#a4d02c3d9ebe7bedb3a4c3a116479e334", null ],
    [ "runPlugin", "vamp-simple-host_8cpp.html#a54e0185f4b6ff507cb42c29a04f76397", null ],
    [ "usage", "vamp-simple-host_8cpp.html#a7cac13da282785878351e0a820104851", null ],
    [ "main", "vamp-simple-host_8cpp.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "toSeconds", "vamp-simple-host_8cpp.html#ac1aad33dbc00144cc38f20787179ec13", null ],
    [ "header", "vamp-simple-host_8cpp.html#a713775f2037987c0851ff3672339a82c", null ]
];