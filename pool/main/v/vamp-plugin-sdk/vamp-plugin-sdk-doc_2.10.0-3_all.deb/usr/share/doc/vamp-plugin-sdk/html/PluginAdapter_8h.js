var PluginAdapter_8h =
[
    [ "Vamp::PluginAdapterBase", "classVamp_1_1PluginAdapterBase.html", "classVamp_1_1PluginAdapterBase" ],
    [ "Vamp::PluginAdapter< P >", "classVamp_1_1PluginAdapter.html", "classVamp_1_1PluginAdapter" ]
];