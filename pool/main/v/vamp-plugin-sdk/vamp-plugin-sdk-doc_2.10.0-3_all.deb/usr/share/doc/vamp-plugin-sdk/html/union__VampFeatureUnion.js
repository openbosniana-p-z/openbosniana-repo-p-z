var union__VampFeatureUnion =
[
    [ "v1", "union__VampFeatureUnion.html#a4a32a2ce141ec3cd36b8be54cd9c3369", null ],
    [ "v2", "union__VampFeatureUnion.html#a87e508e37e02cce11c3c4ddf087a627a", null ]
];