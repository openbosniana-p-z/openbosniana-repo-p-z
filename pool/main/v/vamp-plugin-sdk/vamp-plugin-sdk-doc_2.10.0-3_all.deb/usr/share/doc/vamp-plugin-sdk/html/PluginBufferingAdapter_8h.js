var PluginBufferingAdapter_8h =
[
    [ "Vamp::HostExt::PluginBufferingAdapter", "classVamp_1_1HostExt_1_1PluginBufferingAdapter.html", "classVamp_1_1HostExt_1_1PluginBufferingAdapter" ]
];