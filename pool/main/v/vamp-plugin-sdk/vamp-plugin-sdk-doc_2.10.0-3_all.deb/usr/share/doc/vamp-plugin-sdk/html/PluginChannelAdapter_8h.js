var PluginChannelAdapter_8h =
[
    [ "Vamp::HostExt::PluginChannelAdapter", "classVamp_1_1HostExt_1_1PluginChannelAdapter.html", "classVamp_1_1HostExt_1_1PluginChannelAdapter" ]
];