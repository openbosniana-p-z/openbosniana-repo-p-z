var plugguard_8h =
[
    [ "_VAMP_IN_PLUGINSDK", "plugguard_8h.html#a3bf4e97f131677e5e1505a7a9582d68a", null ],
    [ "VAMP_SDK_VERSION", "plugguard_8h.html#a9b7a8e1ac1c91366bec5f2f33c137a2f", null ],
    [ "VAMP_SDK_MAJOR_VERSION", "plugguard_8h.html#ab5f7da6acf45065a6c7b7cd38a0bf588", null ],
    [ "VAMP_SDK_MINOR_VERSION", "plugguard_8h.html#ad5eef1e2154b42769cd642d2a1d42257", null ],
    [ "_VAMP_SDK_PLUGSPACE_BEGIN", "plugguard_8h.html#a1a2724ea453971288d3218e4eab3072c", null ],
    [ "_VAMP_SDK_PLUGSPACE_END", "plugguard_8h.html#ac879bb1077ecc6132ea3581ef9033753", null ]
];