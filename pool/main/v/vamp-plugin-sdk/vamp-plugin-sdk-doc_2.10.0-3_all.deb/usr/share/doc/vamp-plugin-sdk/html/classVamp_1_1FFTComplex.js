var classVamp_1_1FFTComplex =
[
    [ "FFTComplex", "classVamp_1_1FFTComplex.html#ab73b793c7d1bf5ed175ff4aa0cec5190", null ],
    [ "~FFTComplex", "classVamp_1_1FFTComplex.html#a5b108c655e5c73ee3ba6881ddd7c40a6", null ],
    [ "forward", "classVamp_1_1FFTComplex.html#ab09f93ce626fe41513f33dd9ab54518d", null ],
    [ "inverse", "classVamp_1_1FFTComplex.html#aa392c6a7dbcc2cc6a1edeac6da4c435b", null ],
    [ "m_d", "classVamp_1_1FFTComplex.html#aa521eef4194d91d2c48d07ed5f6d7f5f", null ]
];