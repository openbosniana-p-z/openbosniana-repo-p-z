var PluginWrapper_8h =
[
    [ "Vamp::HostExt::PluginWrapper", "classVamp_1_1HostExt_1_1PluginWrapper.html", "classVamp_1_1HostExt_1_1PluginWrapper" ]
];