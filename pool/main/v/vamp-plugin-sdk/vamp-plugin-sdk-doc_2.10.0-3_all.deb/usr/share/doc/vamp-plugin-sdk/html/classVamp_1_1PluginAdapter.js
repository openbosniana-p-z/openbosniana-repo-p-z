var classVamp_1_1PluginAdapter =
[
    [ "PluginAdapter", "classVamp_1_1PluginAdapter.html#a16312efd629b7063d7b6d67889a2c15a", null ],
    [ "~PluginAdapter", "classVamp_1_1PluginAdapter.html#a9612c9df7d4844959a36921d43d4bd50", null ],
    [ "createPlugin", "classVamp_1_1PluginAdapter.html#a6286e32ebdeb050fb5b1f517034a6787", null ],
    [ "getDescriptor", "classVamp_1_1PluginAdapter.html#a7ff5c9374a8dc43f977c3707d1da45b5", null ],
    [ "m_impl", "classVamp_1_1PluginAdapter.html#a0e3594c54884efd5a7ef38030645745b", null ]
];