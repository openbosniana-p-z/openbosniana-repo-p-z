var PowerSpectrum_8h =
[
    [ "PowerSpectrum", "classPowerSpectrum.html", "classPowerSpectrum" ]
];