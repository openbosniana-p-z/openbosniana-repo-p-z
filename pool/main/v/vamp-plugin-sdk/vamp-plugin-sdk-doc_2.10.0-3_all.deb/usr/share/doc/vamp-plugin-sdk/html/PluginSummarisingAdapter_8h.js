var PluginSummarisingAdapter_8h =
[
    [ "Vamp::HostExt::PluginSummarisingAdapter", "classVamp_1_1HostExt_1_1PluginSummarisingAdapter.html", "classVamp_1_1HostExt_1_1PluginSummarisingAdapter" ]
];