var plugins_8cpp =
[
    [ "vampGetPluginDescriptor", "plugins_8cpp.html#ab46466285f79cd30a020d53ae4ef3474", null ],
    [ "zeroCrossingAdapter", "plugins_8cpp.html#a01871ad1ab2bb64e2c53fe5cce19b780", null ],
    [ "spectralCentroidAdapter", "plugins_8cpp.html#ac96bdfb6356a153341b29b43c4961cd5", null ],
    [ "percussionOnsetAdapter", "plugins_8cpp.html#acee3823cb6a43281a2ecf923b69613dd", null ],
    [ "fixedTempoAdapter", "plugins_8cpp.html#a937de36d22633261716032570064a4be", null ],
    [ "amplitudeAdapter", "plugins_8cpp.html#a4e60bb6a99451da5deb18b969e6b16cd", null ],
    [ "powerSpectrum", "plugins_8cpp.html#a77810f485caaae4a8b2303496046d3d7", null ]
];