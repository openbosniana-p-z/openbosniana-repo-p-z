var vamp_8h =
[
    [ "_VampParameterDescriptor", "struct__VampParameterDescriptor.html", "struct__VampParameterDescriptor" ],
    [ "_VampOutputDescriptor", "struct__VampOutputDescriptor.html", "struct__VampOutputDescriptor" ],
    [ "_VampFeature", "struct__VampFeature.html", "struct__VampFeature" ],
    [ "_VampFeatureV2", "struct__VampFeatureV2.html", "struct__VampFeatureV2" ],
    [ "_VampFeatureUnion", "union__VampFeatureUnion.html", "union__VampFeatureUnion" ],
    [ "_VampFeatureList", "struct__VampFeatureList.html", "struct__VampFeatureList" ],
    [ "_VampPluginDescriptor", "struct__VampPluginDescriptor.html", "struct__VampPluginDescriptor" ],
    [ "VAMP_API_VERSION", "vamp_8h.html#a6d6c8c755dbabf161f72712e0e2143c7", null ],
    [ "VampParameterDescriptor", "vamp_8h.html#a82b252318dee74fe7bfbcfbf394dca5b", null ],
    [ "VampOutputDescriptor", "vamp_8h.html#aa856ef601fb564e46ea2ccba1699b848", null ],
    [ "VampFeature", "vamp_8h.html#a1fe719932f8606c20e626dd3ed342d03", null ],
    [ "VampFeatureV2", "vamp_8h.html#ad293f75fbd66a284333b8d61124dd8e9", null ],
    [ "VampFeatureUnion", "vamp_8h.html#af5427f38fc26f5bb3ce2060fd114ce0e", null ],
    [ "VampFeatureList", "vamp_8h.html#a83320ceddf7fd5d51b134de4c18c2958", null ],
    [ "VampPluginHandle", "vamp_8h.html#ad3be2952b1f4ad7d775940a6db75c79b", null ],
    [ "VampPluginDescriptor", "vamp_8h.html#aaa081d0c32afb7005da47031285daf5d", null ],
    [ "VampGetPluginDescriptorFunction", "vamp_8h.html#a20f63c7e20d6fab0ecec8ef32ddc1d50", null ],
    [ "VampSampleType", "vamp_8h.html#aa24a8cee023d8b7659d25cbe0584b821", [
      [ "vampOneSamplePerStep", "vamp_8h.html#aa24a8cee023d8b7659d25cbe0584b821ab546deafd57f175fb1e7f9cbea1c5113", null ],
      [ "vampFixedSampleRate", "vamp_8h.html#aa24a8cee023d8b7659d25cbe0584b821aafc8a05f722bc83ecce227e12e838cf8", null ],
      [ "vampVariableSampleRate", "vamp_8h.html#aa24a8cee023d8b7659d25cbe0584b821abae8a21a9e30eb73e16d6abc6c7415e8", null ]
    ] ],
    [ "VampInputDomain", "vamp_8h.html#ab107386a5f042feddf6446bea23bb765", [
      [ "vampTimeDomain", "vamp_8h.html#ab107386a5f042feddf6446bea23bb765ae3dbb77ff3e8f292966fd3748888e1a1", null ],
      [ "vampFrequencyDomain", "vamp_8h.html#ab107386a5f042feddf6446bea23bb765aee0c1c0d429276f071b8c0730b7bd87d", null ]
    ] ],
    [ "vampGetPluginDescriptor", "vamp_8h.html#a0bde41362c77414c2e8630e90321ab94", null ]
];