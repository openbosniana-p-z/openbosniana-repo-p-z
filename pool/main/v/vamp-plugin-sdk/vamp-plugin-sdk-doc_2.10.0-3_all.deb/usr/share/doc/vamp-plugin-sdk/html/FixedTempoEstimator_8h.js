var FixedTempoEstimator_8h =
[
    [ "FixedTempoEstimator", "classFixedTempoEstimator.html", "classFixedTempoEstimator" ]
];