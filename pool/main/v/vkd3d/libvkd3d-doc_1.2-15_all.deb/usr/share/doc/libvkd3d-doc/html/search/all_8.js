var searchData=
[
  ['offset_0',['offset',['../structvkd3d__shader__push__constant__buffer.html#ab581633f353215820e62386cad3b18ff',1,'vkd3d_shader_push_constant_buffer']]],
  ['option_5fcount_1',['option_count',['../structvkd3d__shader__compile__info.html#a8d6e5f4798cd4b0182830dac31ab71e0',1,'vkd3d_shader_compile_info']]],
  ['options_2',['options',['../structvkd3d__shader__compile__info.html#a1bb67bf682da261ef8c923b00a3e3ec2',1,'vkd3d_shader_compile_info']]]
];
