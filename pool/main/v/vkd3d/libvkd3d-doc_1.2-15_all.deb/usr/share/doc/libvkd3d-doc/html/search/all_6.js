var searchData=
[
  ['mask_0',['mask',['../structvkd3d__shader__signature__element.html#ad09399cc894b1f7079effe1311a21e64',1,'vkd3d_shader_signature_element']]],
  ['min_5fprecision_1',['min_precision',['../structvkd3d__shader__signature__element.html#aa3701639b5770dbd05c10cbe5c621ea5',1,'vkd3d_shader_signature_element']]]
];
