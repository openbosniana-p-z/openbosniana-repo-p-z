var indexSectionsWithContent =
{
  0: "bcdeflmnoprstuv",
  1: "v",
  2: "v",
  3: "v",
  4: "bcdeflmnoprstuv",
  5: "p",
  6: "v",
  7: "v",
  8: "v"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

