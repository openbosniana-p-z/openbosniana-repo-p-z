var searchData=
[
  ['descriptor_5fcount_0',['descriptor_count',['../structvkd3d__shader__scan__descriptor__info.html#a3de8e9233d5259c44e6d77ceb40c5a87',1,'vkd3d_shader_scan_descriptor_info']]],
  ['descriptors_1',['descriptors',['../structvkd3d__shader__scan__descriptor__info.html#a9cf9b077e6506f42b63f0fe9d3bf9515',1,'vkd3d_shader_scan_descriptor_info']]]
];
