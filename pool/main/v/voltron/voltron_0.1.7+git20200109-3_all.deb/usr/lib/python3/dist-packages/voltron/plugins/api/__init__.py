if not hasattr(__builtins__, "xrange"):
    xrange = range
