module VagrantPlugins
  module LibrarianPuppet
    VERSION = "0.9.2"
  end
end
