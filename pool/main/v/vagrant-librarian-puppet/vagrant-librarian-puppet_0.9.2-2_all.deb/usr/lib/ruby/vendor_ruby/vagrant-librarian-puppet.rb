require "vagrant-librarian-puppet/version"
require "vagrant-librarian-puppet/plugin"
