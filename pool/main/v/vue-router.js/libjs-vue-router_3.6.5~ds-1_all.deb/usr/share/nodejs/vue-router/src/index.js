import VueRouter from './entries/cjs'

export default VueRouter
