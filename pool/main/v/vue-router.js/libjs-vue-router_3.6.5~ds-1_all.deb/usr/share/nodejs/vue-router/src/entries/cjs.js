import VueRouter from '../router'

export default VueRouter
