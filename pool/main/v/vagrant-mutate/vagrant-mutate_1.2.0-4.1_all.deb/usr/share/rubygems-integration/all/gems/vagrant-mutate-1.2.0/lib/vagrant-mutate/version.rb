module VagrantMutate
  VERSION = '1.2.0'
end
