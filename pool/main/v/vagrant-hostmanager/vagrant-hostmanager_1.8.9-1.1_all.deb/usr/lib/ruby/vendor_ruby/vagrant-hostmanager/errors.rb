module VagrantPlugins
  module HostManager
    module Errors
    end
  end
end
