usr/share/#PACKAGE#/#PLUGIN#    var/lib/vdr/plugins/#PLUGIN#
