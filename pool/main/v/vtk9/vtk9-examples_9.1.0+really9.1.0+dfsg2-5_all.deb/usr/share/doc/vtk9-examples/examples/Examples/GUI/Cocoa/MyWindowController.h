#import <Cocoa/Cocoa.h>

@interface MyWindowController : NSWindowController

// Designated initializer
- (instancetype)init /*NS_DESIGNATED_INITIALIZER*/;

@end
