#import <Cocoa/Cocoa.h>

@interface MyDocument : NSDocument

@end
