# Wrapping example

This example shows how VTK modules built outside of VTK can be wrapped.
