# Using VTK example

This example shows how using VTK doesn't require the use of the module system.
