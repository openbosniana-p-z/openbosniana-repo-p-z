
#ifndef VTKCOMMONMATH_EXPORT_H
#define VTKCOMMONMATH_EXPORT_H

#ifdef VTKCOMMONMATH_STATIC_DEFINE
#  define VTKCOMMONMATH_EXPORT
#  define VTKCOMMONMATH_NO_EXPORT
#else
#  ifndef VTKCOMMONMATH_EXPORT
#    ifdef CommonMath_EXPORTS
        /* We are building this library */
#      define VTKCOMMONMATH_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define VTKCOMMONMATH_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef VTKCOMMONMATH_NO_EXPORT
#    define VTKCOMMONMATH_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef VTKCOMMONMATH_DEPRECATED
#  define VTKCOMMONMATH_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef VTKCOMMONMATH_DEPRECATED_EXPORT
#  define VTKCOMMONMATH_DEPRECATED_EXPORT VTKCOMMONMATH_EXPORT VTKCOMMONMATH_DEPRECATED
#endif

#ifndef VTKCOMMONMATH_DEPRECATED_NO_EXPORT
#  define VTKCOMMONMATH_DEPRECATED_NO_EXPORT VTKCOMMONMATH_NO_EXPORT VTKCOMMONMATH_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef VTKCOMMONMATH_NO_DEPRECATED
#    define VTKCOMMONMATH_NO_DEPRECATED
#  endif
#endif

#endif /* VTKCOMMONMATH_EXPORT_H */
