
#ifndef __gtk_databox_marshal_MARSHAL_H__
#define __gtk_databox_marshal_MARSHAL_H__

#include	<glib-object.h>

G_BEGIN_DECLS

/* VOID:VOID (/dev/stdin:1) */
#define gtk_databox_marshal_VOID__VOID	g_cclosure_marshal_VOID__VOID

/* VOID:POINTER (/dev/stdin:2) */
#define gtk_databox_marshal_VOID__POINTER	g_cclosure_marshal_VOID__POINTER

/* VOID:POINTER,POINTER (/dev/stdin:3) */
extern void gtk_databox_marshal_VOID__POINTER_POINTER (GClosure     *closure,
                                                       GValue       *return_value,
                                                       guint         n_param_values,
                                                       const GValue *param_values,
                                                       gpointer      invocation_hint,
                                                       gpointer      marshal_data);

G_END_DECLS

#endif /* __gtk_databox_marshal_MARSHAL_H__ */

