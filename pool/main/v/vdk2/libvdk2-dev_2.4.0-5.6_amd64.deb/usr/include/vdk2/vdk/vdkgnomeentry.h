/*
 * ===========================
 * VDK Visual Develeopment Kit
 * Version 1.0.4
 * December 1999
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 */

#ifndef VDK_GNOME_ENTRY_H
#define VDK_GNOME_ENTRY_H

#if HAVE_GNOME
#include <vdk/combo.h>
#include <gnome.h>
class VDKForm;
/*!
  \class VDKGnomeEntry
  \brief Provides a gnome entry

  VDKGnomeEntry acts like a VDKCombo with an "history" list
  filled with user entries.
 */
class VDKGnomeEntry: public VDKCombo
{
 protected:
 public:
  /*!
    Sets history id, setting history to NULL clears any previous
    history data
  */
  VDKReadWriteValueProp<VDKGnomeEntry,char*> History;
  /*!
    Sets max number of history items. (defaults to 10)
   */
  VDKReadWriteValueProp<VDKGnomeEntry,unsigned int> MaxSaved;
  /*!
    Constructor
    \param owner
    \param def default value
    \param history setting history to NULL clear any previous data
   */
  VDKGnomeEntry(VDKForm* owner,
		char* def = (char*) NULL,
		char* history = (char*) NULL
		);
  /*!
    Destructor
   */
  virtual ~VDKGnomeEntry();

  void SetHistory(char* history)
    {
      gnome_entry_set_history_id(GNOME_ENTRY(widget),history);
    }
  
  void SetMaxSaved(unsigned int max)
    {
      gnome_entry_set_max_saved(GNOME_ENTRY(widget),max);
    }

};
#endif

#endif
