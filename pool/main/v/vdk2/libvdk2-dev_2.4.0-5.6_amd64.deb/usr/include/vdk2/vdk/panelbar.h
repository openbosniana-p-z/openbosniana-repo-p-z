/*
 * ===========================
 * VDK Visual Development Kit
 * Version 0.4
 * October 1998
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 */


#ifndef PANELBAR_H
#define PANELBAR_H
#include <vdk/frame.h>
#include <vdk/label.h>
#include <vdk/separator.h>
#include <vdk/dlist.h>

typedef VDKList<VDKLabel> PanelList;
/*!
  \class VDKPanelbar
  \brief Provides a status bar with one or more panel, each panel
  is a VDKLabel
 */
class VDKPanelbar: public VDKFrame
{
  PanelList panels;
public:
  /*!
    Constructor
    \param owner
    \param panels_num
    \param shadow
   */
  VDKPanelbar(VDKForm* owner, int panels_num = 1,
	   int shadow = shadow_in);
  ~VDKPanelbar() {}
  /*!
    Returns panels, since a panel is a VDKLabel you can access
    them to set panel contents or other properties.
    \code
    panelbar->Panels()[0] = "a text";
    \endcode
   */
  PanelList& Panels() { return panels; }
};

#endif
