/*
 * ===========================
 * VDK Visual Development Kit
 * Version 0.4
 * October 1998
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-130
 *
 * vdkfeatures.h added by Salmaso Raffaele <r.salmaso@flashnet.it> 1999-01-20
 */ 

 
#ifndef _vdkfeatures_h
#define _vdkfeatures_h

#define VDK_VERSION_MAJOR 2
#define VDK_VERSION_MINOR 4
#define VDK_VERSION_MICRO 0
#define VDKCOMPO_VERSION_MAJOR @VDKCOMPO_VERSION_MAJOR@
#define VDKCOMPO_VERSION_MINOR @VDKCOMPO_VERSION_MINOR@
#define VDKCOMPO_VERSION_MICRO @VDKCOMPO_VERSION_MICRO@
#define VDK_MAJOR_VERSION 2
#define VDK_MINOR_VERSION 4
#define VDK_MICRO_VERSION 0
#define VDK_REVISION 0
#define VDK_VERSION 2.4.0
#define VDKCOMPO_VERSION @VDKCOMPO_VERSION@

#endif
