
#ifndef __gtksourceview_marshal_MARSHAL_H__
#define __gtksourceview_marshal_MARSHAL_H__

#include	<glib-object.h>

G_BEGIN_DECLS

/* VOID:BOOLEAN (./gtksourceview-marshal.list:1) */
#define gtksourceview_marshal_VOID__BOOLEAN	g_cclosure_marshal_VOID__BOOLEAN

G_END_DECLS

#endif /* __gtksourceview_marshal_MARSHAL_H__ */

