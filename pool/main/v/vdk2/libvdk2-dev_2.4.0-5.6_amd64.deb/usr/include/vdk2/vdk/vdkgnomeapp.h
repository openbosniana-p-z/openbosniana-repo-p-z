/*
 * ===========================
 * VDK Visual Develeopment Kit
 * Version 1.0.4
 * December 1999
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 */

#ifndef GNOME_APPLICATION_H
#define GNOME_APPLICATION_H
#if HAVE_GNOME
#include <vdk/application.h>
#include <gnome.h>
/*!
  \class VDKGnomeApplication
  \brief Provides a gnome-aware application.
  
  This class encapsulate most of behaviours of a gnome-aware
  application. Initialize gnome libs as well.
  \par TIP
  If your application uses one of the gnome widget you must
  use this class. Plain VDKApplication using a gnome widget
  doesn't work.
 */
class VDKGnomeApplication: public VDKApplication
{
 protected:
    char* _app_id,*_title;
 public:
    /*!
      Contsructor
      \param id application id
      \param title application title
      \param argc arguments counter
      \param argv arguments array
     */
    VDKGnomeApplication(char* app_id,
			char* title,
			int* argc,
			char** argv);
    /*!
      Destructor
     */
    ~VDKGnomeApplication();
    /*!
      Returns application id
     */
    char* AppId() { return _app_id; }
    /*!
      Returns application title
     */
    char* AppTitle() { return _title; }
};
#endif

#endif
