/*
 * ===========================
 * VDK Visual Development Kit
 * Version 0.7
 * March 1999
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 */
#ifndef _EVENT_BOX_H
#define _EVENT_BOX_H

#include <vdk/widcontain.h>
/*! \class VDKEventBox
 *
 *  VDKEventBox acts like a VDKBox except that reacts to all
 *  events.
 *  Tips: event handling must be performed using dynamics tables
 */
class VDKEventBox: public VDKObjectContainer
{
 protected:
  int mode;
  GtkWidget* box;
 public:
  VDKEventBox(VDKForm* owner = (VDKForm*) NULL, int mode = v_box);
  virtual ~VDKEventBox() {}
  virtual void Add(VDKObject* obj, int justify = l_justify,
		   int expand = TRUE, int fill = TRUE , int padding = 0);
  /*!
    Returns a VDKPoint containing VDKEventBox coordinates relative
    to parent form
   */
  VDKPoint FormPosition();
};
#endif
