/*
 * ===========================
 * VDK Visual Develeopment Kit
 * Version 2.0.0
 * november 2000
 * ===========================
 *
 * Copyright (C) 1998, Mario Motta
 * Developed by Mario Motta <mmotta@guest.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 */
#ifndef _sigctest_main_form_h_
#define _sigctest_main_form_h_
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
// compiled only with libsigc extension
#ifdef USE_SIGCPLUSPLUS
// vdk support
#include <vdk/vdk.h>

// Sigctest FORM  CLASS
class SigctestForm: public VDKForm
{
// gui object declarations
private:
// gui object declarations
	void GUISetup(void);

public:
  SigctestForm(VDKForm* owner, char* title = NULL);
  ~SigctestForm();
  void Setup(void);
  void OnButtonClicked(VDKObject* sender);
  void OnCustomListSelected(VDKObject* sender, int row, int col);
  void OnCheckButtonToggled(bool toggled);

  void OnToggledButtonCheckedPropertyChange(bool checked);
  void OnCustomListUnselectedPropertyChange(VDKCustomList* sender, VDKPoint p);
  void OnToolbarButtonPressedPropertyChange(int button);
  void OnNotebookActivePagePropertyChange(int page);

 protected: VDKBox* vbox3;
 protected: VDKFixed* fixed0;
 protected: VDKCustomButton* aButton;
 protected: VDKCustomButton* aToggledButton;
 protected: VDKCustomList* aCustomList;
 protected: VDKCheckButton* aCheckButton;
 protected: VDKFrame* frame0;
 protected: VDKToolbar* aToolbar;
 protected: VDKNotebook* aNotebook;
 protected: VDKBox* notebook0_page0;
 protected: VDKBox* notebook0_page2;
 protected: VDKBox* notebook0_page3;
 protected: VDKStatusbar* aStatusbar;
};
// compiled only with libsigc extension
#endif

#endif

