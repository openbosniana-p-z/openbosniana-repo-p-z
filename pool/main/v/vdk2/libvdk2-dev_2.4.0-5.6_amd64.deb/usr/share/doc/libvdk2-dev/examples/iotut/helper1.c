/*
 * Copyright (C) 1999 Jonathan R. Hudson
 * Developed by Jonathan R. Hudson <jonathan@daria.co.uk>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <signal.h>

int main(int ac, char **av)
{
    char foo[1024];
    int n;
    
    while((n = read(0, foo, sizeof(foo))) > 0)
    {
        char buff[1024];
        sprintf (buff, "%d: %.*s", n-1, n, foo);
        write(1, buff, strlen(buff));
        if(strncasecmp(foo, "quit\n", 5) == 0)
            break;
    }
    kill(getppid(), SIGUSR1);
    exit(0);
}
