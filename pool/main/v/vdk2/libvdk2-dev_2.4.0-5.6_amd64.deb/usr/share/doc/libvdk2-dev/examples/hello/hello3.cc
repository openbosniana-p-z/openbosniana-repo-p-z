               
#include <vdk/vdk.h>
#include "kill.xpm"

class MyForm: public VDKForm
{ 
  VDKPixmapToggleButton* helloButton;
  VDKLabelButton* closeButton;
  VDKLabel* label;
public:
  MyForm(VDKApplication* app, gchar* title):
    VDKForm(app,title) {}
  ~MyForm() {}
void Setup()
{
  VDKBox* box = new VDKBox(this);
  box->Add(helloButton = new VDKPixmapToggleButton(this, kill_xpm, "Test Me", "haloah", GTK_POS_LEFT, 10));
  box->Add(closeButton = new VDKLabelButton(this, "Closes hello application"));
  box->Add(label = new VDKLabel(this,"Test 3"));
  Add(box);
  SetSize(200,100);
}   
  
bool SayHello(VDKObject*)
{
  if (helloButton->Checked)
    label->Caption="Hello world !";
  else
    label->Caption="Not Hello world!"; 
  return true;
}  

bool Quit(VDKObject*) { Close(); return true; }
  
DECLARE_SIGNAL_MAP(MyForm);  
};  
   

DEFINE_SIGNAL_MAP(MyForm,VDKForm)
  ON_SIGNAL(helloButton,toggled_signal,SayHello),
  ON_SIGNAL(closeButton,clicked_signal,Quit) 
END_SIGNAL_MAP       

   
 
class MyApp: public VDKApplication
{
  
public:
  MyApp(int* argc, char** argv): VDKApplication(argc,argv) {}
  ~MyApp() {}
  void Setup()
  {
    MainForm = new MyForm(this,"Hello world 3");
    MainForm->Setup();
    MainForm->Show(); 
  }
}; 
 

int main (int argc, char *argv[])   
{
  MyApp app(&argc, argv); 
  app.Run();      
  return 0;  
}






