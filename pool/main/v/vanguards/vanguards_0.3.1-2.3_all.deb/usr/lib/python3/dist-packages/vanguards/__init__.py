# -*- coding: utf-8 -*-

__version__ = "0.3.1"
__author__ = "Mike Perry"
__license__ = "MIT/Expat"
__url__ = "https://github.com/mikeperry-tor/vanguards"
