#ifndef __VMML__VMMLIB_LAPACK__HPP__
#define __VMML__VMMLIB_LAPACK__HPP__

#include <vmmlib/lapack_svd.hpp>
#include <vmmlib/lapack_linear_least_squares.hpp>

#endif

