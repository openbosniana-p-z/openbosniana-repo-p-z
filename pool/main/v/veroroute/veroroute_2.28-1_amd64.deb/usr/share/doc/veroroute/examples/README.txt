This folder contains a circuit schematic and its corresponding netlist.
The vrt files are veroboard and PCB layouts using the imported netlist.

