module VagrantPlugins
  module CommandServe
    class Type
      class SSHInfo < Type
      end
    end
  end
end
