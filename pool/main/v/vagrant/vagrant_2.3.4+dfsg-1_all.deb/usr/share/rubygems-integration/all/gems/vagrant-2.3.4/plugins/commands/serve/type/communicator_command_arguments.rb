module VagrantPlugins
  module CommandServe
    class Type
      class CommunicatorCommandArguments < Type
      end
    end
  end
end
