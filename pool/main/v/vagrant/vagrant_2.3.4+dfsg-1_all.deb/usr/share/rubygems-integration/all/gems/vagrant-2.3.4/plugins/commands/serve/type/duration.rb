module VagrantPlugins
  module CommandServe
    class Type
      class Duration < Type
      end
    end
  end
end
