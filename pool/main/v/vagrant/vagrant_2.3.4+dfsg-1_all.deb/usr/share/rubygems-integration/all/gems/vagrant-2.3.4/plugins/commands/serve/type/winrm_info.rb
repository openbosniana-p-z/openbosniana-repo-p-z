module VagrantPlugins
  module CommandServe
    class Type
      class WinrmInfo < Type
      end
    end
  end
end
