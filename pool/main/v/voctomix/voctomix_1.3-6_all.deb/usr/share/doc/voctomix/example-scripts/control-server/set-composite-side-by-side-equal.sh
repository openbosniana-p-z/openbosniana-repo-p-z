#!/bin/sh
echo set_composite_mode side_by_side_equal | nc -q0 localhost 9999
