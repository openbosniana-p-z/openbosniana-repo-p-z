#!/bin/sh
echo set_audio cam2 | nc -q0 localhost 9999
