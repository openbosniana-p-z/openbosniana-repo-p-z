#!/bin/sh
ffplay tcp://localhost:11000
