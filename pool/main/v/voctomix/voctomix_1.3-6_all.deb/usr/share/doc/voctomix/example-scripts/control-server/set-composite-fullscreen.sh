#!/bin/sh
echo set_composite_mode fullscreen | nc -q0 localhost 9999
