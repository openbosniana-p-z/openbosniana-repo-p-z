#!/bin/sh
echo set_video_a cam2 | nc -q0 localhost 9999
