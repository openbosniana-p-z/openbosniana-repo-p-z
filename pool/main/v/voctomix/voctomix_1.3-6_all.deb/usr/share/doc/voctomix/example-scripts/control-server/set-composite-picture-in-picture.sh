#!/bin/sh
echo set_composite_mode picture_in_picture | nc -q0 localhost 9999
