#!/bin/sh
echo set_audio cam1 | nc -q0 localhost 9999
