#!/bin/sh
echo set_stream_live | nc -q0 localhost 9999
