#!/bin/sh
echo set_composite_mode side_by_side_preview | nc -q0 localhost 9999
