# Voctomix Example-Scripts

This folder is a collection of Scripts that show how different A/V Sources and sinks can interoperate with the voctocore. Some of them can be used in production as-is while some can serve as a template for whatever you need in your situation.

They are grouped into main categories, depending on their purpose an the external tool they are using. The c3voc only uses the ffmpeg tools so they are the *preferred method* of getting data in and out of voctomix, because they are tested and used in production.
