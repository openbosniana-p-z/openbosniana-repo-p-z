#!/bin/sh
echo set_video_a cam1 | nc -q0 localhost 9999
