#!/bin/sh
echo set_video_a grabber | nc -q0 localhost 9999
