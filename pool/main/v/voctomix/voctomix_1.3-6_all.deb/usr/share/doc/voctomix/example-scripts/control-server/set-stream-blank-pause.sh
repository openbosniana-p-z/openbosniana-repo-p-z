#!/bin/sh
echo set_stream_blank pause | nc -q0 localhost 9999
