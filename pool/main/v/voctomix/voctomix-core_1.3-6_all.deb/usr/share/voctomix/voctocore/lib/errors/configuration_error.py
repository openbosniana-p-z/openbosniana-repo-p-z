class ConfigurationError(RuntimeError):
    """Problem in the Configuration"""
