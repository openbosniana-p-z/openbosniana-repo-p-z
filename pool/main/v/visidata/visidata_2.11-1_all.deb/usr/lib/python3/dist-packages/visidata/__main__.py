from .main import vd_cli

vd_cli()
