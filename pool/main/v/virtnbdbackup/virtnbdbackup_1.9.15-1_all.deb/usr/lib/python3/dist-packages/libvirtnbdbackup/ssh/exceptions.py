"""
    Exceptions
"""


class sshError(Exception):
    """Exception thrown during ssh session"""
