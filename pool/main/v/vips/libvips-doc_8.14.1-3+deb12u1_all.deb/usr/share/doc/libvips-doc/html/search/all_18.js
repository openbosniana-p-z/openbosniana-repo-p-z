var searchData=
[
  ['zone_0',['zone',['../classVImage.html#a5c27b07c20446fa7805b85ff9984f2f5',1,'VImage']]],
  ['zoom_1',['zoom',['../classVImage.html#a587aaaf63bded6795ff61520279e5b0d',1,'VImage']]]
];
