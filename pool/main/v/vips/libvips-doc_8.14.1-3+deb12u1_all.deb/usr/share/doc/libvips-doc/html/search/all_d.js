var searchData=
[
  ['openexrload_0',['openexrload',['../classVImage.html#ab60e87e42fd224d0ea00b18cc976cbb7',1,'VImage']]],
  ['openslideload_1',['openslideload',['../classVImage.html#ae0163af86ee85d3db9e0cf0a26a2dd1b',1,'VImage']]],
  ['openslideload_5fsource_2',['openslideload_source',['../classVImage.html#aa065386fa516d56c809a26edc17e177a',1,'VImage']]],
  ['operator_28_29_3',['operator()',['../classVRegion.html#a70113876aea0deec50a8edbed4b266a5',1,'VRegion']]],
  ['operator_5b_5d_4',['operator[]',['../classVRegion.html#ab0fd17162b84a27d114b177b56c895a6',1,'VRegion']]],
  ['option_5',['option',['../classVImage.html#af432280245e5c33bd800aa4a9983ea22',1,'VImage']]],
  ['ostream_5fprint_6',['ostream_print',['../classVError.html#a8b2824da270e4d493b24fa48097165b5',1,'VError']]]
];
