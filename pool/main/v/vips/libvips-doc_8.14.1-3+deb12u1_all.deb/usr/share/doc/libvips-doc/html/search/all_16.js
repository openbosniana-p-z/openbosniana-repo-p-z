var searchData=
[
  ['xoffset_0',['xoffset',['../classVImage.html#aea0e82d0cebe430a2b56d87899029355',1,'VImage']]],
  ['xres_1',['xres',['../classVImage.html#a043b127b6d2425dd73330b16b9519e92',1,'VImage']]],
  ['xyz_2',['xyz',['../classVImage.html#a421c167f6e23e27606d5cac97ef3f198',1,'VImage']]],
  ['xyz2cmyk_3',['XYZ2CMYK',['../classVImage.html#a31377d2fa029001cead07c9c9f3b8b3b',1,'VImage']]],
  ['xyz2lab_4',['XYZ2Lab',['../classVImage.html#a06eaf2dd482427255b58acd7a9b2194e',1,'VImage']]],
  ['xyz2scrgb_5',['XYZ2scRGB',['../classVImage.html#af8a8533b9d92553d5b36ecc08ecef2a0',1,'VImage']]],
  ['xyz2yxy_6',['XYZ2Yxy',['../classVImage.html#a5067ae1df47017010da13e8e3b273a92',1,'VImage']]]
];
