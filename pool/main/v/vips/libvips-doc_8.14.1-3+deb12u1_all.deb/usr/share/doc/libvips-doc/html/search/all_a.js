var searchData=
[
  ['lab2labq_0',['Lab2LabQ',['../classVImage.html#a0dbf2c75196d85ba43aaaa645264660b',1,'VImage']]],
  ['lab2labs_1',['Lab2LabS',['../classVImage.html#a41588fed5a7b490c1596f822fa84fc28',1,'VImage']]],
  ['lab2lch_2',['Lab2LCh',['../classVImage.html#acac321c0952ca54f111c1d0f2da9a86a',1,'VImage']]],
  ['lab2xyz_3',['Lab2XYZ',['../classVImage.html#a38de14dd0ad7ba062612b75999f3f998',1,'VImage']]],
  ['labelregions_4',['labelregions',['../classVImage.html#a5f3261496635c1c62580a6e1ee36d4d3',1,'VImage']]],
  ['labq2lab_5',['LabQ2Lab',['../classVImage.html#a836bf8120446d25ee00c1156fb4f1eab',1,'VImage']]],
  ['labq2labs_6',['LabQ2LabS',['../classVImage.html#aef4fe1264558a5373292612b3f0f717c',1,'VImage']]],
  ['labq2srgb_7',['LabQ2sRGB',['../classVImage.html#a0e8104e47b4d23a4534f2bbdfe46fd3c',1,'VImage']]],
  ['labs2lab_8',['LabS2Lab',['../classVImage.html#a6b1a0f5d91b6c6f90f251c22553b528b',1,'VImage']]],
  ['labs2labq_9',['LabS2LabQ',['../classVImage.html#aba3cbcadccd2faedc36d1feb12a08c51',1,'VImage']]],
  ['lch2cmc_10',['LCh2CMC',['../classVImage.html#a12194c03ab7125598628dc1af11be1aa',1,'VImage']]],
  ['lch2lab_11',['LCh2Lab',['../classVImage.html#aefef9a1f5589c8e0324465f7df11d2e9',1,'VImage']]],
  ['linear_12',['linear',['../classVImage.html#ac269ca48e1acfc391897fc8840182057',1,'VImage::linear(double a, double b, VOption *options=0) const'],['../classVImage.html#aecf9077f4ac36f710f3b30033bcaf25e',1,'VImage::linear(std::vector&lt; double &gt; a, double b, VOption *options=0) const'],['../classVImage.html#a93e0634ff4a8abb04478af015ac34c60',1,'VImage::linear(double a, std::vector&lt; double &gt; b, VOption *options=0) const'],['../classVImage.html#a57011b223f99706208b86fb14bb2b1d0',1,'VImage::linear(std::vector&lt; double &gt; a, std::vector&lt; double &gt; b, VOption *options=0) const']]],
  ['linecache_13',['linecache',['../classVImage.html#aaca3bcb30f43fdb3b498cbdb1b9c86f4',1,'VImage']]],
  ['log_14',['log',['../classVImage.html#a7d29be1fb8d009685a9a30103a998294',1,'VImage']]],
  ['log10_15',['log10',['../classVImage.html#a3c47be9f0bfb17fab1fafb535a5fcce1',1,'VImage']]],
  ['logmat_16',['logmat',['../classVImage.html#a596ae72453d787f35c627c1fa3f5b316',1,'VImage']]]
];
