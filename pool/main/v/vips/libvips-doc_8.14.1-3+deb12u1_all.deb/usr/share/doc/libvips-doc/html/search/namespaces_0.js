var searchData=
[
  ['vips_0',['vips',['../namespacevips.html',1,'']]]
];
