var searchData=
[
  ['unpremultiply_0',['unpremultiply',['../classVImage.html#ab9a4f70f9d490e95299b8122553c7cff',1,'VImage']]]
];
