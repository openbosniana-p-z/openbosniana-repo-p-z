var searchData=
[
  ['yoffset_0',['yoffset',['../classVImage.html#aa0d09e7bef5744f4716640ec0485db48',1,'VImage']]],
  ['yres_1',['yres',['../classVImage.html#a98c8be7ff8e48c0029de4b6a5004e1a6',1,'VImage']]],
  ['yxy2xyz_2',['Yxy2XYZ',['../classVImage.html#ac3ed770e42f73a2a0c3dbeb53c983ffb',1,'VImage']]]
];
