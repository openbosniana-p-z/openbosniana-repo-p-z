var searchData=
[
  ['bandand_0',['bandand',['../classVImage.html#a3bc5efed2cb5a5cbfdf292c5d0f39b06',1,'VImage']]],
  ['bandbool_1',['bandbool',['../classVImage.html#ae106db4728c2c93cb12c3c70fc815737',1,'VImage']]],
  ['bandeor_2',['bandeor',['../classVImage.html#af4bb6750ffe85c2d58deac836155aff4',1,'VImage']]],
  ['bandfold_3',['bandfold',['../classVImage.html#ac55869ef9c0e9f96aa24c23b6cb82f97',1,'VImage']]],
  ['bandjoin_4',['bandjoin',['../classVImage.html#afc0b18bd4cd93dc9e0042cb09546ea16',1,'VImage::bandjoin(VImage other, VOption *options=0) const'],['../classVImage.html#a116939e473825def63a6e864e56b6d7c',1,'VImage::bandjoin(double other, VOption *options=0) const'],['../classVImage.html#a3c966c030691f5c2b13331c6392842ec',1,'VImage::bandjoin(std::vector&lt; double &gt; other, VOption *options=0) const'],['../classVImage.html#a462460898d24d974ac1504969fde8397',1,'VImage::bandjoin(std::vector&lt; VImage &gt; in, VOption *options=0)']]],
  ['bandjoin_5fconst_5',['bandjoin_const',['../classVImage.html#abe0d5d51603e6ec83ec755bdd8a7e742',1,'VImage']]],
  ['bandmean_6',['bandmean',['../classVImage.html#a0d378a6f211f2d8d896af13d41fb836d',1,'VImage']]],
  ['bandor_7',['bandor',['../classVImage.html#a87ce165336c0760d6738b189bde6ecd5',1,'VImage']]],
  ['bandrank_8',['bandrank',['../classVImage.html#ae63a5540a07f0b51d514d041ad762d6d',1,'VImage']]],
  ['bands_9',['bands',['../classVImage.html#ab5a5514aac679c1d977c24ddf57ea8a7',1,'VImage']]],
  ['bandsplit_10',['bandsplit',['../classVImage.html#acf79387f18eb8359d1af8f9c76fb0fb7',1,'VImage']]],
  ['bandunfold_11',['bandunfold',['../classVImage.html#ae782ac6b3bc805b6225da36989c4a430',1,'VImage']]],
  ['black_12',['black',['../classVImage.html#a23f86e380a8ac7518f251d7f0f0ee75b',1,'VImage']]],
  ['boolean_13',['boolean',['../classVImage.html#a9ebfe1abd04780e15bf18bc2bbfe8652',1,'VImage']]],
  ['boolean_5fconst_14',['boolean_const',['../classVImage.html#a9ab40a2a8dc87a06584810589432865a',1,'VImage']]],
  ['buildlut_15',['buildlut',['../classVImage.html#a7c2bb95788130733832edda5e8eb4c0e',1,'VImage']]],
  ['byteswap_16',['byteswap',['../classVImage.html#ab20bd94812e4f0427f94d35e4f352a50',1,'VImage']]]
];
