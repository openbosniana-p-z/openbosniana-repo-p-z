var searchData=
[
  ['embed_0',['embed',['../classVImage.html#adf824d6bd39159b8f67ab47b710181c1',1,'VImage']]],
  ['erode_1',['erode',['../classVImage.html#a03b5b6c815b27f453c809263fae66f56',1,'VImage']]],
  ['exp_2',['exp',['../classVImage.html#a9b6eb91c3a6fde8a1d8a1053f9753ee3',1,'VImage']]],
  ['exp10_3',['exp10',['../classVImage.html#a5ad97291f68151f45a1eb267df614045',1,'VImage']]],
  ['extract_5farea_4',['extract_area',['../classVImage.html#acae0a58b8b3590725b5b2d11694f3dde',1,'VImage']]],
  ['extract_5fband_5',['extract_band',['../classVImage.html#ab927d18b83aa4ee135a2e4cc290047bc',1,'VImage']]],
  ['eye_6',['eye',['../classVImage.html#a74317bcb66d7bbc3fb9c6d61b977b751',1,'VImage']]]
];
