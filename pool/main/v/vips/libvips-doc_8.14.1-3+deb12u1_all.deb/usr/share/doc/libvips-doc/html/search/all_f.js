var searchData=
[
  ['quadratic_0',['quadratic',['../classVImage.html#a079bfa64692315aa8146753e027403ca',1,'VImage']]]
];
