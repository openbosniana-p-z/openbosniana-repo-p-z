Contributors
============

In alphabetical order:

- Ben Boeckel
- Christian Geier
- Clément Mondon
- Corey Hinshaw
- Hugo Osvaldo Barrera
- Julian Mehne
- Malte Kiefer
- Marek Marczykowski-Górecki
- Markus Unterwaditzer
- Michael Adler
- rEnr3n
- Thomas Weißschuh
- Witcher01

Special thanks goes to:

* `FastMail <https://github.com/pimutils/vdirsyncer/issues/571>`_ sponsors a
  paid account for testing their servers.
* `Packagecloud <https://packagecloud.io/>`_ provide repositories for
  vdirsyncer's Debian packages.
