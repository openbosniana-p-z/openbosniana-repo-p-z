import {arc} from '../path/shapes';
import markItemPath from './markItemPath';

export default markItemPath('arc', arc);
