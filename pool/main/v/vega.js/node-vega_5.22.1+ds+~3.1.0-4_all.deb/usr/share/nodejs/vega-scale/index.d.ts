// TODO: add missing types

export function scheme(name: string, scheme?: any): any;
