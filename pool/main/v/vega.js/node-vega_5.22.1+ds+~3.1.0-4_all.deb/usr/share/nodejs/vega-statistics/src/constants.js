export const SQRT2PI = Math.sqrt(2 * Math.PI);
export const SQRT2 = Math.SQRT2;