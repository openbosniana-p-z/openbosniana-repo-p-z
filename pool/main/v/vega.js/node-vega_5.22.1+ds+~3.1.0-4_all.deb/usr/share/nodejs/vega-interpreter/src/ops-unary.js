export default {
  '+': a => +a,
  '-': a => -a,
  '~': a => ~a,
  '!': a => !a
};
