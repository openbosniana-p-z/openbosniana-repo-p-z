import {shape} from '../path/shapes';
import markItemPath from './markItemPath';

export default markItemPath('shape', shape);
