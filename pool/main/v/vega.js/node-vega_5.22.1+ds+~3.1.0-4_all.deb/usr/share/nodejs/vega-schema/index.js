export {default as schema} from './src/schema';
