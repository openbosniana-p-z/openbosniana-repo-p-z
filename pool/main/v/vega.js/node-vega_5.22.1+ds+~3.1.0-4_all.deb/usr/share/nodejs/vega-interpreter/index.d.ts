export namespace expressionInterpreter {
  export function operator(ctx: any, expr: any): any;
  export function parameter(ctx: any, expr: any): any;
  export function event(ctx: any, expr: any): any;
  export function handler(ctx: any, expr: any): any;
  export function encode(ctx: any, encode: any): any;
}
