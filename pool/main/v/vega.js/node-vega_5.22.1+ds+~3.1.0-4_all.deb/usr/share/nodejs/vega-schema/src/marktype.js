import { stringType } from './util';

export default {
  marktype: stringType
};
