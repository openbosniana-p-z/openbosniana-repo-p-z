export const array8 = n => new Uint8Array(n);

export const array16 = n => new Uint16Array(n);

export const array32 = n => new Uint32Array(n);
