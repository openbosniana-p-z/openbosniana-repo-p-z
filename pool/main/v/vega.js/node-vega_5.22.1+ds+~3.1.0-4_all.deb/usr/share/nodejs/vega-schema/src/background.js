import { stringOrSignal } from './util';

const background = stringOrSignal;

export default {
  background
};
