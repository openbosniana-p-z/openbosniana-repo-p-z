import { stringType } from './util';

const selector = stringType;

export default {
  selector
};
