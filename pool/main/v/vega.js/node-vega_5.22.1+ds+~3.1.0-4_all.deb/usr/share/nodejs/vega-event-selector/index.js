export { default as parseSelector } from './src/event-selector';
