# vega-force

Force simulation transform for Vega dataflows.

This package provides the following Vega data transform:

- [**Force**](https://vega.github.io/vega/docs/transforms/force/) [&lt;&gt;](https://github.com/vega/vega/blob/master/packages/vega-force/src/Force.js "Source")
