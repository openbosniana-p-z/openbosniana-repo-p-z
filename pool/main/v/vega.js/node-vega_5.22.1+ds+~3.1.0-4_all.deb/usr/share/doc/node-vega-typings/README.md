# Vega-Typings

[![npm version](https://img.shields.io/npm/v/vega-typings.svg)](https://www.npmjs.com/package/vega-typings)

Typings for [Vega](https://github.com/vega/vega).
