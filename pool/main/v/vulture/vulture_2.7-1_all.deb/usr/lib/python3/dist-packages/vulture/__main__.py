from vulture.core import main

main()
