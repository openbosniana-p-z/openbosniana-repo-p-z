import collections

# To free memory, the "default_factory" attribute can be set to None.
collections.defaultdict().default_factory
