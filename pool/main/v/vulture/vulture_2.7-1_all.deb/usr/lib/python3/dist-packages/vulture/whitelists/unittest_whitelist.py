from unittest import mock, TestCase

TestCase.setUp
TestCase.tearDown
TestCase.setUpClass
TestCase.tearDownClass
TestCase.run
TestCase.skipTest
TestCase.debug
TestCase.failureException
TestCase.longMessage
TestCase.maxDiff
TestCase.subTest

mock.Mock.return_value
mock.Mock.side_effect
