import logging

logging.Filter.filter
logging.getLogger().propagate
logging.StreamHandler.emit
