from vitables.start import gui

gui()

