var searchData=
[
  ['role_0',['role',['../structdata.html#adf2176e7975673fbfd305fca6a45cd1d',1,'data']]]
];
