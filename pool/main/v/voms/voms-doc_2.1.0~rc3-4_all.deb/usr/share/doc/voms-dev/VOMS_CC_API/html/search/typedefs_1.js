var searchData=
[
  ['gss_5fcred_5fid_5ft_0',['gss_cred_id_t',['../voms__api_8h.html#a76bb3f76530747d9832792991031a960',1,'voms_api.h']]],
  ['gss_5fctx_5fid_5ft_1',['gss_ctx_id_t',['../voms__api_8h.html#ab4d4ee81ca188b5cc17b3667e4ea3a8a',1,'voms_api.h']]]
];
