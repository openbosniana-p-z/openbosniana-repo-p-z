var searchData=
[
  ['recurse_5ftype_0',['recurse_type',['../voms__api_8h.html#a104918adf5603cfd54085f981fff6e2d',1,'voms_api.h']]]
];
