var searchData=
[
  ['error_0',['error',['../structvomsdata.html#a9c39fddec66f7d7ca38d7f5a68caf6a3',1,'vomsdata']]],
  ['extra_5fdata_1',['extra_data',['../structvomsdata.html#ad00bc0b9ba1be4e6cf914527b15887a2',1,'vomsdata']]]
];
