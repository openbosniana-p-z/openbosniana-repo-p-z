var searchData=
[
  ['_7evoms_0',['~voms',['../structvoms.html#a92fff524dca812fe6259464390a6807a',1,'voms']]],
  ['_7evomsdata_1',['~vomsdata',['../structvomsdata.html#acb8452277ec3476ea96c578acd9d3a01',1,'vomsdata']]]
];
