var searchData=
[
  ['verify_5ftype_0',['verify_type',['../voms__api_8h.html#acdaa6cbefca8282d51dae3531f4e7dcf',1,'voms_api.h']]],
  ['verror_5ftype_1',['verror_type',['../voms__api_8h.html#ae20b6773aacbfdcc4e784ec602ba4d96',1,'voms_api.h']]]
];
