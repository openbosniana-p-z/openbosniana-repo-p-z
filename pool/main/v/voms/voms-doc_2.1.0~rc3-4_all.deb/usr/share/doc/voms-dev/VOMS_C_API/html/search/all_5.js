var searchData=
[
  ['getmajorversionnumber_0',['getMajorVersionNumber',['../voms__apic_8h.html#a2d23e12c7a98839e17fb81b8df3af828',1,'voms_apic.h']]],
  ['getminorversionnumber_1',['getMinorVersionNumber',['../voms__apic_8h.html#a3e128023cc23deabcabd931ba1587556',1,'voms_apic.h']]],
  ['getpatchversionnumber_2',['getPatchVersionNumber',['../voms__apic_8h.html#a639f84d8917572e4984d6a622415bcb9',1,'voms_apic.h']]],
  ['group_3',['group',['../structdata.html#aeea26875d4c0335d39f2e6de1e1d27fb',1,'data']]],
  ['gss_5fcred_5fid_5ft_4',['gss_cred_id_t',['../voms__apic_8h.html#a76bb3f76530747d9832792991031a960',1,'voms_apic.h']]],
  ['gss_5fctx_5fid_5ft_5',['gss_ctx_id_t',['../voms__apic_8h.html#ab4d4ee81ca188b5cc17b3667e4ea3a8a',1,'voms_apic.h']]]
];
