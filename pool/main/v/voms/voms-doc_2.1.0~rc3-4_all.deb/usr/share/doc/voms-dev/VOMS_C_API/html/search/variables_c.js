var searchData=
[
  ['type_0',['type',['../structvoms.html#a464f29320ee58675a0d44fd6a5fdfdc4',1,'voms']]]
];
