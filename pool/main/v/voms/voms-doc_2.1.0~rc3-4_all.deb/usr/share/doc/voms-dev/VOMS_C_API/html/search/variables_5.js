var searchData=
[
  ['group_0',['group',['../structdata.html#aeea26875d4c0335d39f2e6de1e1d27fb',1,'data']]]
];
