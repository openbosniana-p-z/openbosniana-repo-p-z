var searchData=
[
  ['recurse_5fchain_0',['RECURSE_CHAIN',['../voms__api_8h.html#a104918adf5603cfd54085f981fff6e2dac0f875c2113832879a8c52876f47da72',1,'voms_api.h']]],
  ['recurse_5fdeep_1',['RECURSE_DEEP',['../voms__api_8h.html#a104918adf5603cfd54085f981fff6e2da1c16f44d59a1c9e4e56c1bfc98c4ee77',1,'voms_api.h']]],
  ['recurse_5fnone_2',['RECURSE_NONE',['../voms__api_8h.html#a104918adf5603cfd54085f981fff6e2da0b328808b66912dd6d75a19280f6b722',1,'voms_api.h']]],
  ['recurse_5ftype_3',['recurse_type',['../voms__api_8h.html#a104918adf5603cfd54085f981fff6e2d',1,'voms_api.h']]],
  ['resetorder_4',['ResetOrder',['../structvomsdata.html#a1a679b45341bb026658cf4af2c0be868',1,'vomsdata']]],
  ['resettargets_5',['ResetTargets',['../structvomsdata.html#a5cc720a7a197f8ef0f6c1859f4e3591a',1,'vomsdata']]],
  ['retrieve_6',['Retrieve',['../structvomsdata.html#ae02ce31a158bf5187fb28da196d207db',1,'vomsdata::Retrieve(X509 *cert, STACK_OF(X509) *chain, recurse_type how=RECURSE_CHAIN)'],['../structvomsdata.html#a6751bd1cf1ef2df32359a026330c20da',1,'vomsdata::Retrieve(X509_EXTENSION *ext)'],['../structvomsdata.html#a4925305f29368eee22c49b4732b7233d',1,'vomsdata::Retrieve(FILE *file, recurse_type how)'],['../structvomsdata.html#ab760bcb45f34a8cf514255cad4d4d343',1,'vomsdata::Retrieve(AC *ac)']]],
  ['retrievefromcred_7',['RetrieveFromCred',['../structvomsdata.html#a330e14ecfe1dad254e77045024fc350e',1,'vomsdata']]],
  ['retrievefromctx_8',['RetrieveFromCtx',['../structvomsdata.html#a7d3acaec4b376a81ab978490c0fafd11',1,'vomsdata']]],
  ['retrievefromproxy_9',['RetrieveFromProxy',['../structvomsdata.html#a8877883bdae232261d2b73b7c5ace949',1,'vomsdata']]],
  ['role_10',['role',['../structdata.html#adf2176e7975673fbfd305fca6a45cd1d',1,'data']]]
];
