var searchData=
[
  ['data_0',['data',['../structdata.html',1,'']]]
];
