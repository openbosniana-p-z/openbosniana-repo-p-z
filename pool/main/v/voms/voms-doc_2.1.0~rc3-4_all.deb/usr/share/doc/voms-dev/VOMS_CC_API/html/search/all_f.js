var searchData=
[
  ['translatevoms_0',['TranslateVOMS',['../structvoms.html#aad7e3631086c5bd81f7ed644ffecc1ab',1,'voms']]],
  ['type_1',['type',['../structvoms.html#ab39d4ec2f52ab43de6281fa67bf0a9d5',1,'voms']]],
  ['type_5fcustom_2',['TYPE_CUSTOM',['../voms__api_8h.html#ac2ad7f431e3446fddcd9b6b9f93c4c14a0bdd417ed00e2349e72a6e1ae9c53e7c',1,'voms_api.h']]],
  ['type_5fnodata_3',['TYPE_NODATA',['../voms__api_8h.html#ac2ad7f431e3446fddcd9b6b9f93c4c14a931518cef7c196fc8d74fcbff9f1346a',1,'voms_api.h']]],
  ['type_5fstd_4',['TYPE_STD',['../voms__api_8h.html#ac2ad7f431e3446fddcd9b6b9f93c4c14ab186b7c86d2c72a266b02aa8d885a356',1,'voms_api.h']]]
];
