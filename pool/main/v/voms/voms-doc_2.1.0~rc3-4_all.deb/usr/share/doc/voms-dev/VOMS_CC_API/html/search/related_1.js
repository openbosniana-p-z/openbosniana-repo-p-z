var searchData=
[
  ['vomsdata_0',['vomsdata',['../structvoms.html#a20eaa8103b5b8625a648873f83380dfb',1,'voms']]]
];
