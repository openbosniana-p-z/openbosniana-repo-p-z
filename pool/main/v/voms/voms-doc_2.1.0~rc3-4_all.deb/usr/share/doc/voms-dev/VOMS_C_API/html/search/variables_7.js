var searchData=
[
  ['name_0',['name',['../structattribute.html#a46dbec84d6b8f7e772973adc03cef037',1,'attribute']]],
  ['nick_1',['nick',['../structcontactdata.html#a51c00ad8e8123940e4c703b630c25cf7',1,'contactdata']]]
];
