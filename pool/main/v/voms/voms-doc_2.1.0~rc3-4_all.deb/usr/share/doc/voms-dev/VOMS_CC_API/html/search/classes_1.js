var searchData=
[
  ['contactdata_0',['contactdata',['../structcontactdata.html',1,'']]]
];
