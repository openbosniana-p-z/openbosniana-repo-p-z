var searchData=
[
  ['check_5fsig_0',['check_sig',['../voms__api_8h.html#aa5180d7bf9b83453a34099fe79f9fe75',1,'voms_api.h']]]
];
