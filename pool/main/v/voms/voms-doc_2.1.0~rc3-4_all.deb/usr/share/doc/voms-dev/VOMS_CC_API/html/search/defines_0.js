var searchData=
[
  ['noglobus_0',['NOGLOBUS',['../voms__api_8h.html#aff48d14af012253e2d8dfe57ddb57068',1,'voms_api.h']]]
];
