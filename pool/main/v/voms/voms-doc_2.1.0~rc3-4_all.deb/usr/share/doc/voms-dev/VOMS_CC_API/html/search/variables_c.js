var searchData=
[
  ['type_0',['type',['../structvoms.html#ab39d4ec2f52ab43de6281fa67bf0a9d5',1,'voms']]]
];
