var searchData=
[
  ['data_0',['data',['../structvomsdata.html#aa43ea2e333c05f8882f1c92b0acc4fb1',1,'vomsdata']]],
  ['date1_1',['date1',['../structvoms.html#abb1893a17964503d44966ce4d557027c',1,'voms']]],
  ['date2_2',['date2',['../structvoms.html#a0499cee6f19b37556c58e1e826ed8ab8',1,'voms']]]
];
