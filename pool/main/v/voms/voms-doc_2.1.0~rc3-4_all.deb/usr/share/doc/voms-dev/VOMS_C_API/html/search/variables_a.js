var searchData=
[
  ['real_0',['real',['../structvomsdata.html#a24ef685dd3c7ad89f3cd7be5be520bd6',1,'vomsdata']]],
  ['reserved_1',['reserved',['../structcontactdata.html#adf84c4666f0247b0811591ed5a1a3ba3',1,'contactdata']]],
  ['role_2',['role',['../structdata.html#af7f723ab0993c2c236d7c29fa82e8a0f',1,'data']]]
];
