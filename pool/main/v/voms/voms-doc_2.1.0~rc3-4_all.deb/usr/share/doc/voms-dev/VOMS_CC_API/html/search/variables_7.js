var searchData=
[
  ['name_0',['name',['../structattribute.html#ad38537b15af5f1b035ec66480a557f3a',1,'attribute']]],
  ['nick_1',['nick',['../structcontactdata.html#a28dbdda0a2abf13fddbebcf3850d0feb',1,'contactdata']]]
];
