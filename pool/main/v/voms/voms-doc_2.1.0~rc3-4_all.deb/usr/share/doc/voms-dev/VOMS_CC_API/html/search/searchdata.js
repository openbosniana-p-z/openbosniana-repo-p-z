var indexSectionsWithContent =
{
  0: "acdefghilnopqrstuvw~",
  1: "acdv",
  2: "v",
  3: "acdefgilorsv~",
  4: "acdefghnpqrstuvw",
  5: "cg",
  6: "drv",
  7: "rtv",
  8: "tv",
  9: "n"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Macros"
};

