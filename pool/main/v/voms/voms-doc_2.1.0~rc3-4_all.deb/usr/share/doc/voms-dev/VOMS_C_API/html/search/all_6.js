var searchData=
[
  ['holder_0',['holder',['../structvoms.html#adc7bb548306637528d5470881df0d975',1,'voms']]],
  ['host_1',['host',['../structcontactdata.html#a6797e7ae8d65eed4694ff69c4a228204',1,'contactdata']]]
];
