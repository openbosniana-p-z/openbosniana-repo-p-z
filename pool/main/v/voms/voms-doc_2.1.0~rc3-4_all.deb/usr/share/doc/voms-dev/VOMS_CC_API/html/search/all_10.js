var searchData=
[
  ['uri_0',['uri',['../structvoms.html#a75bafa51b729a2f5aeab7e546c1922b1',1,'voms']]],
  ['user_1',['user',['../structvoms.html#a2e9a272b0a15b14fc0c7c6270a9cf2ad',1,'voms']]],
  ['userca_2',['userca',['../structvoms.html#a95fe12d576e603d3eee04de04dfecc52',1,'voms']]]
];
