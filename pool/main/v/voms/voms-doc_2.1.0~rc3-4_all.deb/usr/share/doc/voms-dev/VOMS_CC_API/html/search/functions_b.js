var searchData=
[
  ['voms_0',['voms',['../structvoms.html#ab0e2cb8d36dfa4bee07b6247942e10ae',1,'voms::voms(const voms &amp;)'],['../structvoms.html#ad76e20404d1ca57bb3ea456acd4611cf',1,'voms::voms()']]],
  ['vomsdata_1',['vomsdata',['../structvomsdata.html#a8e4d765f10cf98ae552034df81b8fe6e',1,'vomsdata::vomsdata(std::string voms_dir=&quot;&quot;, std::string cert_dir=&quot;&quot;)'],['../structvomsdata.html#af0e72dff783ba1b530d40aae37fcff06',1,'vomsdata::vomsdata(const vomsdata &amp;)']]]
];
