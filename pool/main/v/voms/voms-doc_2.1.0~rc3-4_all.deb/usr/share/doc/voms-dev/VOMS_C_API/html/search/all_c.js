var searchData=
[
  ['type_0',['type',['../structvoms.html#a464f29320ee58675a0d44fd6a5fdfdc4',1,'voms']]],
  ['type_5fcustom_1',['TYPE_CUSTOM',['../voms__apic_8h.html#a80b368359bfb50b3b5337f27089a2114',1,'voms_apic.h']]],
  ['type_5fnodata_2',['TYPE_NODATA',['../voms__apic_8h.html#ac7883b9a604caff05fbdfdf09e4079f2',1,'voms_apic.h']]],
  ['type_5fstd_3',['TYPE_STD',['../voms__apic_8h.html#ac10a5d4fef12e501169015f3bf2950a6',1,'voms_apic.h']]]
];
