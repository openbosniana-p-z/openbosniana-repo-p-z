var searchData=
[
  ['resetorder_0',['ResetOrder',['../structvomsdata.html#a1a679b45341bb026658cf4af2c0be868',1,'vomsdata']]],
  ['resettargets_1',['ResetTargets',['../structvomsdata.html#a5cc720a7a197f8ef0f6c1859f4e3591a',1,'vomsdata']]],
  ['retrieve_2',['Retrieve',['../structvomsdata.html#ae02ce31a158bf5187fb28da196d207db',1,'vomsdata::Retrieve(X509 *cert, STACK_OF(X509) *chain, recurse_type how=RECURSE_CHAIN)'],['../structvomsdata.html#a6751bd1cf1ef2df32359a026330c20da',1,'vomsdata::Retrieve(X509_EXTENSION *ext)'],['../structvomsdata.html#a4925305f29368eee22c49b4732b7233d',1,'vomsdata::Retrieve(FILE *file, recurse_type how)'],['../structvomsdata.html#ab760bcb45f34a8cf514255cad4d4d343',1,'vomsdata::Retrieve(AC *ac)']]],
  ['retrievefromcred_3',['RetrieveFromCred',['../structvomsdata.html#a330e14ecfe1dad254e77045024fc350e',1,'vomsdata']]],
  ['retrievefromctx_4',['RetrieveFromCtx',['../structvomsdata.html#a7d3acaec4b376a81ab978490c0fafd11',1,'vomsdata']]],
  ['retrievefromproxy_5',['RetrieveFromProxy',['../structvomsdata.html#a8877883bdae232261d2b73b7c5ace949',1,'vomsdata']]]
];
