var searchData=
[
  ['getac_0',['GetAC',['../structvoms.html#a32f4ba5847ca157df7b0b7a8f1e19e1d',1,'voms']]],
  ['getattributes_1',['GetAttributes',['../structvoms.html#a7324323f13e68077a84cdf1957560b6f',1,'voms']]],
  ['gettargets_2',['GetTargets',['../structvoms.html#abf6587d17f158fc403bd95cd000ed6b6',1,'voms']]],
  ['getvomsmajorversionnumber_3',['getVOMSMajorVersionNumber',['../voms__api_8h.html#affcaff3414ae0bd042de6d3579da0953',1,'voms_api.h']]],
  ['getvomsminorversionnumber_4',['getVOMSMinorVersionNumber',['../voms__api_8h.html#a18810dee05fcfbe070efd10b86704130',1,'voms_api.h']]],
  ['getvomspatchversionnumber_5',['getVOMSPatchVersionNumber',['../voms__api_8h.html#a5b70db7b13ae75ec1359e578aca4877e',1,'voms_api.h']]],
  ['grantor_6',['grantor',['../structattributelist.html#a9cb5e7b0d5a9337a47cc2f32eb7beacb',1,'attributelist']]],
  ['group_7',['group',['../structdata.html#a172a289b535aadc708fc189b462aaa8c',1,'data']]],
  ['gss_5fcred_5fid_5ft_8',['gss_cred_id_t',['../voms__api_8h.html#a76bb3f76530747d9832792991031a960',1,'voms_api.h']]],
  ['gss_5fctx_5fid_5ft_9',['gss_ctx_id_t',['../voms__api_8h.html#ab4d4ee81ca188b5cc17b3667e4ea3a8a',1,'voms_api.h']]]
];
