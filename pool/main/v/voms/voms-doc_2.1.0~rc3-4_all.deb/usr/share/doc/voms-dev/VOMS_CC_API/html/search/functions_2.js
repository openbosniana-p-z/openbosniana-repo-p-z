var searchData=
[
  ['defaultdata_0',['DefaultData',['../structvomsdata.html#ad2446653ae03a423a16a25e3968b401e',1,'vomsdata']]]
];
