var searchData=
[
  ['extra_5fdata_0',['extra_data',['../structvomsdata.html#a4263055454d075483f2b818beef2599f',1,'vomsdata']]],
  ['extralen_1',['extralen',['../structvomsdata.html#ab6580e4c2a50491267c25b8a69e4dd35',1,'vomsdata']]]
];
