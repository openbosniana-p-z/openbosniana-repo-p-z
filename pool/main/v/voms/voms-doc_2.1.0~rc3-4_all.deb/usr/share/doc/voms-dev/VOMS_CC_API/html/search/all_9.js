var searchData=
[
  ['name_0',['name',['../structattribute.html#ad38537b15af5f1b035ec66480a557f3a',1,'attribute']]],
  ['nick_1',['nick',['../structcontactdata.html#a28dbdda0a2abf13fddbebcf3850d0feb',1,'contactdata']]],
  ['noglobus_2',['NOGLOBUS',['../voms__api_8h.html#aff48d14af012253e2d8dfe57ddb57068',1,'voms_api.h']]]
];
