var searchData=
[
  ['real_0',['real',['../structvomsdata.html#a24ef685dd3c7ad89f3cd7be5be520bd6',1,'vomsdata']]],
  ['recurse_5fchain_1',['RECURSE_CHAIN',['../voms__apic_8h.html#a45bb47400aef88e966454ca690494b5d',1,'voms_apic.h']]],
  ['recurse_5fnone_2',['RECURSE_NONE',['../voms__apic_8h.html#a3d93709befed17d61791a0663098b4be',1,'voms_apic.h']]],
  ['reserved_3',['reserved',['../structcontactdata.html#adf84c4666f0247b0811591ed5a1a3ba3',1,'contactdata']]],
  ['role_4',['role',['../structdata.html#af7f723ab0993c2c236d7c29fa82e8a0f',1,'data']]]
];
