var searchData=
[
  ['grantor_0',['grantor',['../structattributelist.html#a9cb5e7b0d5a9337a47cc2f32eb7beacb',1,'attributelist']]],
  ['group_1',['group',['../structdata.html#a172a289b535aadc708fc189b462aaa8c',1,'data']]]
];
