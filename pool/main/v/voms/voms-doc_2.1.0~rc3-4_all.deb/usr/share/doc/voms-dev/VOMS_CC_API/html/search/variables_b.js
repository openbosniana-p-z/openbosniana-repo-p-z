var searchData=
[
  ['serial_0',['serial',['../structvoms.html#a8142b9e45efa4317850b335c1692edb3',1,'voms']]],
  ['server_1',['server',['../structvoms.html#aea16312943bf1b13dc1d6e7ef607ee7e',1,'voms']]],
  ['serverca_2',['serverca',['../structvoms.html#ab43c1de955f291477910f1d56729cca5',1,'voms']]],
  ['siglen_3',['siglen',['../structvoms.html#a3b971a57e9e397a17253c6e5acd0d15a',1,'voms']]],
  ['signature_4',['signature',['../structvoms.html#a662ece77491bb03761e7e518e9914723',1,'voms']]],
  ['std_5',['std',['../structvoms.html#ac33e04a35e25e06bac43026edabba5be',1,'voms']]]
];
