var searchData=
[
  ['translatevoms_0',['TranslateVOMS',['../structvoms.html#aad7e3631086c5bd81f7ed644ffecc1ab',1,'voms']]]
];
