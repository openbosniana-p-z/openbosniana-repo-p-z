var searchData=
[
  ['uri_0',['uri',['../structvoms.html#aa4ee2b1ba87c538faf9f84f2cf681574',1,'voms']]],
  ['user_1',['user',['../structvoms.html#a1a362931e41a80c01a310cced93419c1',1,'voms']]],
  ['userca_2',['userca',['../structvoms.html#afcba6ec9917f52b889372e3ef1a3ed27',1,'voms']]]
];
