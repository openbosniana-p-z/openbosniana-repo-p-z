var searchData=
[
  ['getmajorversionnumber_0',['getMajorVersionNumber',['../voms__apic_8h.html#a2d23e12c7a98839e17fb81b8df3af828',1,'voms_apic.h']]],
  ['getminorversionnumber_1',['getMinorVersionNumber',['../voms__apic_8h.html#a3e128023cc23deabcabd931ba1587556',1,'voms_apic.h']]],
  ['getpatchversionnumber_2',['getPatchVersionNumber',['../voms__apic_8h.html#a639f84d8917572e4984d6a622415bcb9',1,'voms_apic.h']]]
];
