var searchData=
[
  ['type_5fcustom_0',['TYPE_CUSTOM',['../voms__api_8h.html#ac2ad7f431e3446fddcd9b6b9f93c4c14a0bdd417ed00e2349e72a6e1ae9c53e7c',1,'voms_api.h']]],
  ['type_5fnodata_1',['TYPE_NODATA',['../voms__api_8h.html#ac2ad7f431e3446fddcd9b6b9f93c4c14a931518cef7c196fc8d74fcbff9f1346a',1,'voms_api.h']]],
  ['type_5fstd_2',['TYPE_STD',['../voms__api_8h.html#ac2ad7f431e3446fddcd9b6b9f93c4c14ab186b7c86d2c72a266b02aa8d885a356',1,'voms_api.h']]]
];
