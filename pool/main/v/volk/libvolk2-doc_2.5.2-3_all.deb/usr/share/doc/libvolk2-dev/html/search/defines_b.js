var searchData=
[
  ['rotator_5freload_0',['ROTATOR_RELOAD',['../volk__32fc__s32fc__x2__rotator__32fc_8h.html#ab2976971764b8014e2d82eb2bc74aecf',1,'volk_32fc_s32fc_x2_rotator_32fc.h']]],
  ['rotator_5freload_5f2_1',['ROTATOR_RELOAD_2',['../volk__32fc__s32fc__x2__rotator__32fc_8h.html#aa82de71ed3c19ddc35f6cc84ad97b50e',1,'volk_32fc_s32fc_x2_rotator_32fc.h']]],
  ['rotator_5freload_5f4_2',['ROTATOR_RELOAD_4',['../volk__32fc__s32fc__x2__rotator__32fc_8h.html#aa0e358e4e58756b1807317c9a54f568a',1,'volk_32fc_s32fc_x2_rotator_32fc.h']]]
];
