var unionbit128 =
[
    [ "d", "unionbit128.html#aaa05f29f2ea72932452b2aa7e29cdea6", null ],
    [ "double_vec", "unionbit128.html#a332ed77d3ca646e23af92f01d0b1fec7", null ],
    [ "f", "unionbit128.html#a1468059a8bd56945348b61f89a938f69", null ],
    [ "float_vec", "unionbit128.html#ac5e44fa66bbb137f04aeb58695593627", null ],
    [ "i", "unionbit128.html#aa041f436e8c47ce199f2e61a54c000bf", null ],
    [ "i16", "unionbit128.html#aaf4e694dd656b8a695f2b3a7d48a3b8a", null ],
    [ "i8", "unionbit128.html#a5f39cf527f76819e2deada1123dd482e", null ],
    [ "int_vec", "unionbit128.html#a2986c2342d07680e3d1cb854310ed96f", null ]
];