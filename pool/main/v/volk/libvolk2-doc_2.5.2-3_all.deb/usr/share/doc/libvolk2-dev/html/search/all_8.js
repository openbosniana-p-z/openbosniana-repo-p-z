var searchData=
[
  ['has_5fdispatcher_0',['has_dispatcher',['../classvolk__kernel__defs_1_1kernel__class.html#a14b69da65d590563c0bfce9e15565603',1,'volk_kernel_defs::kernel_class']]],
  ['how_20to_20create_20custom_20kernel_20dispatchers_1',['How to create custom kernel dispatchers',['../md_kernels__r_e_a_d_m_e.html',1,'']]]
];
