var searchData=
[
  ['a_0',['A',['../volk__32f__expfast__32f_8h.html#a955f504eccf76b4eb2489c0adab03121',1,'volk_32f_expfast_32f.h']]],
  ['acos_5fterms_1',['ACOS_TERMS',['../volk__32f__acos__32f_8h.html#aabe7b71a034c9d1ec71ef0c2338fdf7c',1,'volk_32f_acos_32f.h']]],
  ['align_5fstruct_2',['ALIGN_STRUCT',['../sse2neon_8h.html#a7dd90da22d0dfa048ae19f0e6883ec17',1,'sse2neon.h']]],
  ['asin_5fterms_3',['ASIN_TERMS',['../volk__32f__asin__32f_8h.html#a44a09a8486ec85c6db4fd06396594ab1',1,'volk_32f_asin_32f.h']]]
];
