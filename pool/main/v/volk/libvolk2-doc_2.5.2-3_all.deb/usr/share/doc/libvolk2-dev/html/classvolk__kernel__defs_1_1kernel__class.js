var classvolk__kernel__defs_1_1kernel__class =
[
    [ "__init__", "classvolk__kernel__defs_1_1kernel__class.html#aa6af44b718a197fd05f2a8321ea09a7d", null ],
    [ "__repr__", "classvolk__kernel__defs_1_1kernel__class.html#a57e8441e89a8fab23c315d759d6ca620", null ],
    [ "get_impls", "classvolk__kernel__defs_1_1kernel__class.html#afd8ce0de5c22781943b69c0e9ae1ba30", null ],
    [ "arglist_full", "classvolk__kernel__defs_1_1kernel__class.html#aef95071301be7b4c722fa06861b6b690", null ],
    [ "arglist_names", "classvolk__kernel__defs_1_1kernel__class.html#a1ee4f121058a039ad626a58eb9681f15", null ],
    [ "arglist_types", "classvolk__kernel__defs_1_1kernel__class.html#ada57adbc18c8f967796346f004d3cda0", null ],
    [ "args", "classvolk__kernel__defs_1_1kernel__class.html#aec838a2bf9d02d335bb440638aca8ae9", null ],
    [ "has_dispatcher", "classvolk__kernel__defs_1_1kernel__class.html#a14b69da65d590563c0bfce9e15565603", null ],
    [ "name", "classvolk__kernel__defs_1_1kernel__class.html#a58f60be439577d6f4a07799c65b2f7f0", null ],
    [ "pname", "classvolk__kernel__defs_1_1kernel__class.html#acadd6809f2fbd5e36acaac4cdc93537b", null ]
];