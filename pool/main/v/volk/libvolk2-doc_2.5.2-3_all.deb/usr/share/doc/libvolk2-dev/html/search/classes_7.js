var searchData=
[
  ['machine_5fclass_0',['machine_class',['../classvolk__machine__defs_1_1machine__class.html',1,'volk_machine_defs']]]
];
