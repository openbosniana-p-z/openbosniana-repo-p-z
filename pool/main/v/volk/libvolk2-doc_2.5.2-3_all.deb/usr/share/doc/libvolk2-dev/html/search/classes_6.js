var searchData=
[
  ['kernel_5fclass_0',['kernel_class',['../classvolk__kernel__defs_1_1kernel__class.html',1,'volk_kernel_defs']]]
];
