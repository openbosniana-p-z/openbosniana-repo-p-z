var searchData=
[
  ['benchmark_5fmode_0',['benchmark_mode',['../classvolk__test__params__t.html#afe15f57daa86b3306adebf92620157b2',1,'volk_test_params_t']]],
  ['bfly_1',['BFLY',['../volk__8u__x4__conv__k7__r2__8u_8h.html#a02ec559746280778b5fa8c5a60e9b393',1,'volk_8u_x4_conv_k7_r2_8u.h']]]
];
