var structfpcr__bitfield =
[
    [ "bit22", "structfpcr__bitfield.html#a3acdbf56a3e02d0b0e7bfd32693a6518", null ],
    [ "bit23", "structfpcr__bitfield.html#a07a04ba4f4a06ff7a253a77ea4017bec", null ],
    [ "bit24", "structfpcr__bitfield.html#a2cb5a2841c0304ddc652240161dad2eb", null ],
    [ "res0", "structfpcr__bitfield.html#a07262cc6de7f02a3a565a982d7766fc3", null ],
    [ "res1", "structfpcr__bitfield.html#a2323458ee71138313092f66c11a6e8fb", null ],
    [ "res2", "structfpcr__bitfield.html#a9e3af44de655e048929dfaa78be4b22e", null ]
];