var searchData=
[
  ['odd_5fxor_5feven_5fvalues_0',['odd_xor_even_values',['../volk__32f__8u__polarbutterfly__32f_8h.html#a4e096860dbeaac8a706b3f37249f1d96',1,'volk_32f_8u_polarbutterfly_32f.h']]],
  ['operator_21_3d_1',['operator!=',['../namespacevolk.html#ab6439ba32d50e7d79e75b2e5e6600027',1,'volk']]],
  ['operator_3d_3d_2',['operator==',['../namespacevolk.html#a8f96095f7316b516c5d4ec3dd3c09b8a',1,'volk']]]
];
