var searchData=
[
  ['readme_2emd_0',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['run_5fcitations_5fupdate_2epy_1',['run_citations_update.py',['../run__citations__update_8py.html',1,'']]]
];
