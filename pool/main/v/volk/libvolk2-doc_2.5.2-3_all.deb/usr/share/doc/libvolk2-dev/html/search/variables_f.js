var searchData=
[
  ['t_0',['t',['../unionp__decision__t.html#a7d87c644ef89ce7977e3a6a7754e0fba',1,'p_decision_t::t()'],['../uniondecision__t.html#a977bde73bcb56b538a5248e46e62eda1',1,'decision_t::t()']]],
  ['time_1',['time',['../classvolk__test__time__t.html#a2542710f1ff7b4b0349886a026c8bf6c',1,'volk_test_time_t']]]
];
