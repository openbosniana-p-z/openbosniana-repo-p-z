var searchData=
[
  ['deallocate_0',['deallocate',['../structvolk_1_1alloc.html#a2d6ad719a74bf67b338a8606c067d6ac',1,'volk::alloc']]],
  ['desc_1',['desc',['../classvolk__test__case__t.html#a19afd701f36b6f41c9277779beb5c42a',1,'volk_test_case_t']]],
  ['do_5farch_5fflags_5flist_2',['do_arch_flags_list',['../namespacevolk__compile__utils.html#a21184c44b64e6eea77d5dbaa9ffb93b8',1,'volk_compile_utils']]],
  ['do_5fmachine_5fflags_5flist_3',['do_machine_flags_list',['../namespacevolk__compile__utils.html#a5b4ff9bd459700ff993e9831ac84eda6',1,'volk_compile_utils']]],
  ['do_5fmachines_5flist_4',['do_machines_list',['../namespacevolk__compile__utils.html#a1f30798b4d4f81dd4faefc8654528496',1,'volk_compile_utils']]]
];
