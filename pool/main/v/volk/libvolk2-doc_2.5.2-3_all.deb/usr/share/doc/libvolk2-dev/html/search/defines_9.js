var searchData=
[
  ['pow_5fpoly_5fdegree_0',['POW_POLY_DEGREE',['../volk__32f__x2__pow__32f_8h.html#a2261611ce3603ae6f9d167b49f12ed9a',1,'POW_POLY_DEGREE():&#160;volk_32f_x2_pow_32f.h'],['../volk__32f__x2__pow__32f_8h.html#a2261611ce3603ae6f9d167b49f12ed9a',1,'POW_POLY_DEGREE():&#160;volk_32f_x2_pow_32f.h']]]
];
