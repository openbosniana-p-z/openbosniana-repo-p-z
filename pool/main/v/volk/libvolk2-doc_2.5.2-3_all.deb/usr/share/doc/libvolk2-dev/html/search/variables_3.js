var searchData=
[
  ['d_0',['d',['../unionbit128.html#aaa05f29f2ea72932452b2aa7e29cdea6',1,'bit128::d()'],['../unionbit256.html#a54f6deb0e3f51c7f0d888330adf2bbcc',1,'bit256::d()']]],
  ['deps_1',['deps',['../classvolk__kernel__defs_1_1impl__class.html#aaeeb012993ce93acc22f323d1e08bb96',1,'volk_kernel_defs::impl_class']]],
  ['double_5fvec_2',['double_vec',['../unionbit128.html#a332ed77d3ca646e23af92f01d0b1fec7',1,'bit128::double_vec()'],['../unionbit256.html#a1b035eff78246f6a328418ff290d5275',1,'bit256::double_vec()']]]
];
