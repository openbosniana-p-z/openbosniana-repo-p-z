var searchData=
[
  ['alignment_0',['alignment',['../classvolk__machine__defs_1_1machine__class.html#a61b0189c5b58cc5899794ca137fd44d0',1,'volk_machine_defs::machine_class']]],
  ['arch_5fdict_1',['arch_dict',['../namespacevolk__arch__defs.html#affe074a247af5258087c2c207992a732',1,'volk_arch_defs']]],
  ['arch_5fnames_2',['arch_names',['../classvolk__machine__defs_1_1machine__class.html#aac3809099880ffe678dbbe70a0752e30',1,'volk_machine_defs::machine_class']]],
  ['archs_3',['archs',['../classvolk__machine__defs_1_1machine__class.html#a83be842d912cfb8f69aa7b8f5d0bea7e',1,'volk_machine_defs.machine_class.archs()'],['../namespacevolk__arch__defs.html#ab2759fcf4828f3156d5391481fbc8061',1,'volk_arch_defs.archs()']]],
  ['archs_5fxml_4',['archs_xml',['../namespacevolk__arch__defs.html#ae305d23c32bfb8a59cfdaaff9b9d4e9c',1,'volk_arch_defs']]],
  ['arglist_5ffull_5',['arglist_full',['../classvolk__kernel__defs_1_1kernel__class.html#aef95071301be7b4c722fa06861b6b690',1,'volk_kernel_defs::kernel_class']]],
  ['arglist_5fnames_6',['arglist_names',['../classvolk__kernel__defs_1_1kernel__class.html#a1ee4f121058a039ad626a58eb9681f15',1,'volk_kernel_defs::kernel_class']]],
  ['arglist_5ftypes_7',['arglist_types',['../classvolk__kernel__defs_1_1kernel__class.html#ada57adbc18c8f967796346f004d3cda0',1,'volk_kernel_defs::kernel_class']]],
  ['args_8',['args',['../classvolk__kernel__defs_1_1impl__class.html#ac4ab12c5a4fc427622b47a33dc96a9ca',1,'volk_kernel_defs.impl_class.args()'],['../classvolk__kernel__defs_1_1kernel__class.html#aec838a2bf9d02d335bb440638aca8ae9',1,'volk_kernel_defs.kernel_class.args()']]]
];
