var searchData=
[
  ['calculate_5fmax_5fstage_5fdepth_5ffor_5frow_0',['calculate_max_stage_depth_for_row',['../volk__32f__8u__polarbutterfly__32f_8h.html#a9d0285a2bcefb4ab13b6b6e53aec770e',1,'volk_32f_8u_polarbutterfly_32f.h']]],
  ['calculate_5fscaled_5fdistances_1',['calculate_scaled_distances',['../volk__32fc__x2__s32f__square__dist__scalar__mult__32f_8h.html#aafc5731b8b06574459d8a938d7fb5c58',1,'volk_32fc_x2_s32f_square_dist_scalar_mult_32f.h']]],
  ['ccompare_2',['ccompare',['../qa__utils_8cc.html#aa4e7c56898578f3b3c7beffcb4a12ec5',1,'qa_utils.cc']]],
  ['chainback_5fviterbi_3',['chainback_viterbi',['../volk__8u__conv__k7__r2puppet__8u_8h.html#a97a255a4f4a7f86df20c8bc0a3cd22ac',1,'volk_8u_conv_k7_r2puppet_8u.h']]],
  ['clean_5fup_5fintermediate_5fvalues_4',['clean_up_intermediate_values',['../volk__32f__8u__polarbutterflypuppet__32f_8h.html#a307108bfae9d23c5627632a1440a4dae',1,'volk_32f_8u_polarbutterflypuppet_32f.h']]],
  ['comment_5fremover_5',['comment_remover',['../namespacevolk__kernel__defs.html#a387b4882bd430dd9c511b0f61889abf9',1,'volk_kernel_defs']]],
  ['convert_5fkernel_6',['convert_kernel',['../classvolk__modtool_1_1volk__modtool__generate_1_1volk__modtool.html#a8f293ec0d94f0bdf6a20dace31d9db4f',1,'volk_modtool::volk_modtool_generate::volk_modtool']]]
];
