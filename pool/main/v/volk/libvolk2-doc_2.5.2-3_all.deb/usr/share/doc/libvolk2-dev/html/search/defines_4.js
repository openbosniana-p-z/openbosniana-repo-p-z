var searchData=
[
  ['do_5frbit_0',['DO_RBIT',['../volk__32u__reverse__32u_8h.html#a7c6c50ff9bbab4a55cb98d37f9b4b666',1,'volk_32u_reverse_32u.h']]]
];
