var searchData=
[
  ['q_5frsqrt_0',['Q_rsqrt',['../volk__32f__invsqrt__32f_8h.html#aeb64e1ec1eeb71734b28c1799502557c',1,'volk_32f_invsqrt_32f.h']]]
];
