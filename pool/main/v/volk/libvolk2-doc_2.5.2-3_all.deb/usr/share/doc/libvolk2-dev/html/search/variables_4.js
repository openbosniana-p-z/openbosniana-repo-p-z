var searchData=
[
  ['f_0',['f',['../unionbit128.html#a1468059a8bd56945348b61f89a938f69',1,'bit128::f()'],['../unionbit256.html#a108257d1f41befb5bf3118a2255f6c19',1,'bit256::f()']]],
  ['flags_1',['flags',['../namespacevolk__arch__defs.html#a496daf51a50daca544bcecdc1b57d87c',1,'volk_arch_defs']]],
  ['float_5fvec_2',['float_vec',['../unionbit128.html#ac5e44fa66bbb137f04aeb58695593627',1,'bit128::float_vec()'],['../unionbit256.html#ad1e802e8bb4b540df7032aac7190af1d',1,'bit256::float_vec()']]]
];
