var searchData=
[
  ['encodepolar_5fsingle_5fstage_0',['encodepolar_single_stage',['../volk__8u__x2__encodeframepolar__8u_8h.html#a14bfe77f647e27ea03b3834d67b22171',1,'volk_8u_x2_encodeframepolar_8u.h']]],
  ['even_5fu_5fvalues_1',['even_u_values',['../volk__32f__8u__polarbutterfly__32f_8h.html#a8399b65a8f4b34f36497bf5ca5e4b4ac',1,'volk_32f_8u_polarbutterfly_32f.h']]],
  ['extending_20volk_2',['Extending VOLK',['../extending_volk.html',1,'']]],
  ['extending_5fvolk_2edox_3',['extending_volk.dox',['../extending__volk_8dox.html',1,'']]],
  ['extract_5flv_5fhaves_4',['extract_lv_haves',['../namespacevolk__kernel__defs.html#a0bafdc283b81b11a0e8ffee54062753a',1,'volk_kernel_defs']]]
];
