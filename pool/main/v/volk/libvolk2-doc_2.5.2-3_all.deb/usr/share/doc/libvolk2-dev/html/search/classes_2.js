var searchData=
[
  ['char_5fsplit_0',['char_split',['../structchar__split.html',1,'']]]
];
