var searchData=
[
  ['_5f_5fm128_0',['__m128',['../sse2neon_8h.html#a1185a477a51f888c7ba5562a1f1db592',1,'sse2neon.h']]],
  ['_5f_5fm128d_1',['__m128d',['../sse2neon_8h.html#a4cb585ca17fac7e19a3c191459ab05f3',1,'sse2neon.h']]],
  ['_5f_5fm128i_2',['__m128i',['../sse2neon_8h.html#ae568b00e462205af997f7d5d84814f70',1,'sse2neon.h']]],
  ['_5f_5fm64_3',['__m64',['../sse2neon_8h.html#a9a1e8f07efa0113ecce3c32d1fde155a',1,'sse2neon.h']]]
];
