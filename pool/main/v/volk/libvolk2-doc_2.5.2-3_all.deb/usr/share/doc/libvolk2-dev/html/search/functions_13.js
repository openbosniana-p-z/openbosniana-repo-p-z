var searchData=
[
  ['uniform_0',['uniform',['../qa__utils_8h.html#aa6795d41afd69c1bb67ce644cf8a3dc6',1,'qa_utils.h']]],
  ['update_5fcitation_5ffile_1',['update_citation_file',['../namespacerun__citations__update.html#a989f130bfad4ca055a6f271408ee3ad7',1,'run_citations_update']]],
  ['update_5fsquare_5fsum_5f1_5fval_2',['update_square_sum_1_val',['../volk__32f__stddev__and__mean__32f__x2_8h.html#af118bfea807642e95b88667b1cb55fa4',1,'volk_32f_stddev_and_mean_32f_x2.h']]]
];
