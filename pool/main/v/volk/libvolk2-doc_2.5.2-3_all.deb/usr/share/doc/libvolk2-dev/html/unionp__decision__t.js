var unionp__decision__t =
[
    [ "t", "unionp__decision__t.html#a7d87c644ef89ce7977e3a6a7754e0fba", null ],
    [ "w", "unionp__decision__t.html#a5b8ec8ea6b07d929d999d5b5cc7de828", null ]
];