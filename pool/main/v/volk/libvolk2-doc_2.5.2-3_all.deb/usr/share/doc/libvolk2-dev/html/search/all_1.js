var searchData=
[
  ['a_0',['A',['../volk__32f__expfast__32f_8h.html#a955f504eccf76b4eb2489c0adab03121',1,'volk_32f_expfast_32f.h']]],
  ['absolute_5fmode_1',['absolute_mode',['../classvolk__test__params__t.html#a4880be540ea243cd2668a9d8cad049b3',1,'volk_test_params_t']]],
  ['accrue_5fresult_2',['accrue_result',['../volk__32f__stddev__and__mean__32f__x2_8h.html#a4eb1301adbc52c97349d703b4a7a368c',1,'volk_32f_stddev_and_mean_32f_x2.h']]],
  ['acos_5fterms_3',['ACOS_TERMS',['../volk__32f__acos__32f_8h.html#aabe7b71a034c9d1ec71ef0c2338fdf7c',1,'volk_32f_acos_32f.h']]],
  ['add_5fsquare_5fsums_4',['add_square_sums',['../volk__32f__stddev__and__mean__32f__x2_8h.html#a421dfba75bf21154fcbf10fef2607d3c',1,'volk_32f_stddev_and_mean_32f_x2.h']]],
  ['adjust_5ffrozen_5fmask_5',['adjust_frozen_mask',['../volk__8u__x3__encodepolarpuppet__8u_8h.html#a2efcbbe45527407d5ddf5724861e91b5',1,'volk_8u_x3_encodepolarpuppet_8u.h']]],
  ['align_5fstruct_6',['ALIGN_STRUCT',['../sse2neon_8h.html#af50c4382585bd76da21cf701a333e30f',1,'ALIGN_STRUCT(16) SIMDVec:&#160;sse2neon.h'],['../sse2neon_8h.html#a7dd90da22d0dfa048ae19f0e6883ec17',1,'ALIGN_STRUCT():&#160;sse2neon.h']]],
  ['alignment_7',['alignment',['../classvolk__machine__defs_1_1machine__class.html#a61b0189c5b58cc5899794ca137fd44d0',1,'volk_machine_defs::machine_class']]],
  ['alloc_8',['alloc',['../structvolk_1_1alloc.html#a92128b2c407822062294b2ccb614e392',1,'volk::alloc::alloc()=default'],['../structvolk_1_1alloc.html#ad7558a21bfa9a67e0b0feeaa04ca3bb4',1,'volk::alloc::alloc(alloc&lt; U &gt; const &amp;) noexcept'],['../structvolk_1_1alloc.html',1,'volk::alloc&lt; T &gt;']]],
  ['allocate_9',['allocate',['../structvolk_1_1alloc.html#adcbfaa9f2edae51034f91d17157686e7',1,'volk::alloc']]],
  ['arch_5fclass_10',['arch_class',['../classvolk__arch__defs_1_1arch__class.html',1,'volk_arch_defs']]],
  ['arch_5fdict_11',['arch_dict',['../namespacevolk__arch__defs.html#affe074a247af5258087c2c207992a732',1,'volk_arch_defs']]],
  ['arch_5fnames_12',['arch_names',['../classvolk__machine__defs_1_1machine__class.html#aac3809099880ffe678dbbe70a0752e30',1,'volk_machine_defs::machine_class']]],
  ['archs_13',['archs',['../namespacevolk__arch__defs.html#ab2759fcf4828f3156d5391481fbc8061',1,'volk_arch_defs.archs()'],['../classvolk__machine__defs_1_1machine__class.html#a83be842d912cfb8f69aa7b8f5d0bea7e',1,'volk_machine_defs.machine_class.archs()']]],
  ['archs_5fxml_14',['archs_xml',['../namespacevolk__arch__defs.html#ae305d23c32bfb8a59cfdaaff9b9d4e9c',1,'volk_arch_defs']]],
  ['arglist_5ffull_15',['arglist_full',['../classvolk__kernel__defs_1_1kernel__class.html#aef95071301be7b4c722fa06861b6b690',1,'volk_kernel_defs::kernel_class']]],
  ['arglist_5fnames_16',['arglist_names',['../classvolk__kernel__defs_1_1kernel__class.html#a1ee4f121058a039ad626a58eb9681f15',1,'volk_kernel_defs::kernel_class']]],
  ['arglist_5ftypes_17',['arglist_types',['../classvolk__kernel__defs_1_1kernel__class.html#ada57adbc18c8f967796346f004d3cda0',1,'volk_kernel_defs::kernel_class']]],
  ['args_18',['args',['../classvolk__kernel__defs_1_1impl__class.html#ac4ab12c5a4fc427622b47a33dc96a9ca',1,'volk_kernel_defs.impl_class.args()'],['../classvolk__kernel__defs_1_1kernel__class.html#aec838a2bf9d02d335bb440638aca8ae9',1,'volk_kernel_defs.kernel_class.args()']]],
  ['asin_5fterms_19',['ASIN_TERMS',['../volk__32f__asin__32f_8h.html#a44a09a8486ec85c6db4fd06396594ab1',1,'volk_32f_asin_32f.h']]]
];
