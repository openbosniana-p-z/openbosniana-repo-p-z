var classvolk__test__time__t =
[
    [ "name", "classvolk__test__time__t.html#ab711fb1565a251d7a021e08fe38094c5", null ],
    [ "pass", "classvolk__test__time__t.html#af18c523789978f3a53be7c5b69da147d", null ],
    [ "time", "classvolk__test__time__t.html#a2542710f1ff7b4b0349886a026c8bf6c", null ],
    [ "units", "classvolk__test__time__t.html#abfd64f48acc1790df4b3c6f8915ed25f", null ]
];