/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Vector Optimized Library of Kernels", "index.html", [
    [ "VOLK", "index.html", null ],
    [ "Changelog", "md_docs__c_h_a_n_g_e_l_o_g.html", [
      [ "[2.0.0] - 2019-08-06", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md1", null ],
      [ "[2.1.0] - 2019-12-22", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md2", [
        [ "Highlights", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md3", null ],
        [ "Contributors", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md4", null ],
        [ "Changes", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md5", null ]
      ] ],
      [ "[2.2.0] - 2020-02-16", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md6", [
        [ "Highlights", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md7", null ],
        [ "Contributors", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md8", null ],
        [ "Changes", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md9", null ]
      ] ],
      [ "[2.2.1] - 2020-02-24", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md10", [
        [ "Contributors", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md11", null ],
        [ "Changes", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md12", null ]
      ] ],
      [ "[2.3.0] - 2020-05-09", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md13", [
        [ "Highlights", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md14", null ],
        [ "Contributors", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md15", null ],
        [ "Changes", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md16", null ]
      ] ],
      [ "[2.4.0] - 2020-11-22", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md17", [
        [ "Highlights", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md18", null ],
        [ "Contributors", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md19", null ],
        [ "Changes", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md20", null ]
      ] ],
      [ "[2.4.1] - 2020-12-17", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md21", [
        [ "Contributors", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md22", null ],
        [ "Changes", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md23", null ]
      ] ],
      [ "[2.5.0] - 2021-06-05", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md24", [
        [ "Announcements", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md25", null ],
        [ "Contributors", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md26", null ],
        [ "Changes", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md27", null ]
      ] ],
      [ "[2.5.1] - 2022-02-12", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md28", [
        [ "Contributors", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md29", null ],
        [ "Changes", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md30", null ]
      ] ],
      [ "[2.5.2] - 2022-09-04", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md31", [
        [ "Contributors", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md32", null ],
        [ "Changes", "md_docs__c_h_a_n_g_e_l_o_g.html#autotoc_md33", null ]
      ] ]
    ] ],
    [ "VOLK Code of Conduct", "md_docs__c_o_d_e__o_f__c_o_n_d_u_c_t.html", [
      [ "Our Pledge", "md_docs__c_o_d_e__o_f__c_o_n_d_u_c_t.html#autotoc_md35", null ],
      [ "Our Standards", "md_docs__c_o_d_e__o_f__c_o_n_d_u_c_t.html#autotoc_md36", null ],
      [ "Enforcement Responsibilities", "md_docs__c_o_d_e__o_f__c_o_n_d_u_c_t.html#autotoc_md37", null ],
      [ "Scope", "md_docs__c_o_d_e__o_f__c_o_n_d_u_c_t.html#autotoc_md38", null ],
      [ "Enforcement", "md_docs__c_o_d_e__o_f__c_o_n_d_u_c_t.html#autotoc_md39", null ],
      [ "Enforcement Guidelines", "md_docs__c_o_d_e__o_f__c_o_n_d_u_c_t.html#autotoc_md40", [
        [ "1. Correction", "md_docs__c_o_d_e__o_f__c_o_n_d_u_c_t.html#autotoc_md41", null ],
        [ "2. Warning", "md_docs__c_o_d_e__o_f__c_o_n_d_u_c_t.html#autotoc_md42", null ],
        [ "3. Temporary Ban", "md_docs__c_o_d_e__o_f__c_o_n_d_u_c_t.html#autotoc_md43", null ],
        [ "4. Permanent Ban", "md_docs__c_o_d_e__o_f__c_o_n_d_u_c_t.html#autotoc_md44", null ]
      ] ]
    ] ],
    [ "Contributing to VOLK", "md_docs__c_o_n_t_r_i_b_u_t_i_n_g.html", [
      [ "What about non-code contributions?", "md_docs__c_o_n_t_r_i_b_u_t_i_n_g.html#autotoc_md46", null ],
      [ "DCO Signed?", "md_docs__c_o_n_t_r_i_b_u_t_i_n_g.html#autotoc_md47", null ],
      [ "Coding Guidelines", "md_docs__c_o_n_t_r_i_b_u_t_i_n_g.html#autotoc_md48", null ],
      [ "Git commit messages are very important", "md_docs__c_o_n_t_r_i_b_u_t_i_n_g.html#autotoc_md49", null ],
      [ "Unit Tests", "md_docs__c_o_n_t_r_i_b_u_t_i_n_g.html#autotoc_md50", null ],
      [ "The Buddy Principle: Submit One, Review One", "md_docs__c_o_n_t_r_i_b_u_t_i_n_g.html#autotoc_md51", null ],
      [ "Standard command line options", "md_docs__c_o_n_t_r_i_b_u_t_i_n_g.html#autotoc_md52", null ]
    ] ],
    [ "Extending VOLK", "extending_volk.html", null ],
    [ "Kernels", "kernels.html", "kernels" ],
    [ "Concepts, Terms, and Techniques", "concepts_terms_and_techniques.html", null ],
    [ "Using VOLK", "using_volk.html", null ],
    [ "Versioning", "md_docs_versioning.html", [
      [ "Begin of Creative Commons - CC BY 3.0 document from https://semver.org", "md_docs_versioning.html#autotoc_md71", null ],
      [ "Semantic Versioning 2.0.0", "md_docs_versioning.html#autotoc_md72", [
        [ "Summary", "md_docs_versioning.html#autotoc_md73", null ],
        [ "Introduction", "md_docs_versioning.html#autotoc_md74", null ],
        [ "Semantic Versioning Specification (SemVer)", "md_docs_versioning.html#autotoc_md75", null ],
        [ "Why Use Semantic Versioning?", "md_docs_versioning.html#autotoc_md76", null ],
        [ "FAQ", "md_docs_versioning.html#autotoc_md77", [
          [ "How should I deal with revisions in the 0.y.z initial development phase?", "md_docs_versioning.html#autotoc_md78", null ],
          [ "How do I know when to release 1.0.0?", "md_docs_versioning.html#autotoc_md79", null ],
          [ "Doesn't this discourage rapid development and fast iteration?", "md_docs_versioning.html#autotoc_md80", null ],
          [ "If even the tiniest backwards incompatible changes to the public API require a major version bump, won't I end up at version 42.0.0 very rapidly?", "md_docs_versioning.html#autotoc_md81", null ],
          [ "Documenting the entire public API is too much work!", "md_docs_versioning.html#autotoc_md82", null ],
          [ "What do I do if I accidentally release a backwards incompatible change as a minor version?", "md_docs_versioning.html#autotoc_md83", null ],
          [ "What should I do if I update my own dependencies without changing the public API?", "md_docs_versioning.html#autotoc_md84", null ],
          [ "What if I inadvertently alter the public API in a way that is not compliant with the version number change (i.e. the code incorrectly introduces a major breaking change in a patch release)", "md_docs_versioning.html#autotoc_md85", null ],
          [ "How should I handle deprecating functionality?", "md_docs_versioning.html#autotoc_md86", null ],
          [ "Does semver have a size limit on the version string?", "md_docs_versioning.html#autotoc_md87", null ]
        ] ],
        [ "About", "md_docs_versioning.html#autotoc_md88", null ],
        [ "License", "md_docs_versioning.html#autotoc_md89", null ]
      ] ]
    ] ],
    [ "How to create custom kernel dispatchers", "md_kernels__r_e_a_d_m_e.html", [
      [ "Code for an example dispatcher w/ tail case", "md_kernels__r_e_a_d_m_e.html#autotoc_md91", null ],
      [ "Code for an example dispatcher w/ tail case and accumulator", "md_kernels__r_e_a_d_m_e.html#autotoc_md92", null ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"____init_____8py.html",
"sse2neon_8h.html#a07288154ecbae3a0d347d9e10d6845f0",
"sse2neon_8h.html#a6386e00ea0f96250ac5b9d43a0d3ae28",
"sse2neon_8h.html#acb718dd43522a3c525b6576a5abaa3ab",
"volk_32fc_s32fc_x2_rotator_32fc.html",
"volk__32f__exp__32f_8h.html",
"volk__32f__x2__fm__detectpuppet__32f_8h.html#aa48478b843d4a30e06cf82355120baf7",
"volk__32fc__s32fc__x2__rotator__32fc_8h.html#a32ddd9de337f2e3e335c577231b071c7",
"volk__8ic__x2__multiply__conjugate__16ic_8h.html#a104a122f9f35a588aaa3b642b590fc3c"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';