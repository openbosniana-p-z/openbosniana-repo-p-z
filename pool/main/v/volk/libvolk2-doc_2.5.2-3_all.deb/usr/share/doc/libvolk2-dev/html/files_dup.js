var files_dup =
[
    [ "docs", "dir_49e56c817e5e54854c35e136979f97ca.html", null ],
    [ "gen", "dir_76d06afa57792f775bcb80774dbca277.html", "dir_76d06afa57792f775bcb80774dbca277" ],
    [ "include", "dir_d44c64559bbebec7f509842c48db8b23.html", "dir_d44c64559bbebec7f509842c48db8b23" ],
    [ "kernels", "dir_d3fd84b2e4114076d2551689812cf799.html", "dir_d3fd84b2e4114076d2551689812cf799" ],
    [ "lib", "dir_97aefd0d527b934f1d99a682da8fe6a9.html", "dir_97aefd0d527b934f1d99a682da8fe6a9" ],
    [ "python", "dir_7837fde3ab9c1fb2fc5be7b717af8d79.html", "dir_7837fde3ab9c1fb2fc5be7b717af8d79" ],
    [ "scripts", "dir_53e6fa9553ac22a5646d2a2b2d7b97a1.html", "dir_53e6fa9553ac22a5646d2a2b2d7b97a1" ]
];