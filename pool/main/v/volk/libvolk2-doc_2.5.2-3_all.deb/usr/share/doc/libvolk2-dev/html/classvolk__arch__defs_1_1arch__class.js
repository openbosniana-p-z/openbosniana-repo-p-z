var classvolk__arch__defs_1_1arch__class =
[
    [ "__init__", "classvolk__arch__defs_1_1arch__class.html#a1b43c9760d281743e7b70b5dcdf4615c", null ],
    [ "__repr__", "classvolk__arch__defs_1_1arch__class.html#ad6b4b555c14cbcf0a1019cb62145620d", null ],
    [ "get_flags", "classvolk__arch__defs_1_1arch__class.html#abf6af012548d66289e47a67b6b908af0", null ],
    [ "is_supported", "classvolk__arch__defs_1_1arch__class.html#a6cfd963839d58a2a71a27226c1720467", null ],
    [ "checks", "classvolk__arch__defs_1_1arch__class.html#a6482eff2dc628ec80aa859ce924b5f5b", null ]
];