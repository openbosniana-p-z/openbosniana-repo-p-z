var searchData=
[
  ['_7evolk_5fqa_5faligned_5fmem_5fpool_0',['~volk_qa_aligned_mem_pool',['../classvolk__qa__aligned__mem__pool.html#a225982c7d64d25252da5602b3abfb8d8',1,'volk_qa_aligned_mem_pool']]]
];
