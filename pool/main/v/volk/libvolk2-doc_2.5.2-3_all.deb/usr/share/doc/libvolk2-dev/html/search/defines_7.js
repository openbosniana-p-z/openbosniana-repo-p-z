var searchData=
[
  ['log_5fpoly_5fdegree_0',['LOG_POLY_DEGREE',['../volk__32f__log2__32f_8h.html#ad85ee20f6eee837e0c0dfbdef33836d4',1,'volk_32f_log2_32f.h']]],
  ['lv_5fcimag_1',['lv_cimag',['../volk__complex_8h.html#a1f58129a88c382411b2e8997c8dd89e4',1,'volk_complex.h']]],
  ['lv_5fcmake_2',['lv_cmake',['../volk__complex_8h.html#a241cf3f7a97e885e45ff971a6a82c12d',1,'volk_complex.h']]],
  ['lv_5fconj_3',['lv_conj',['../volk__complex_8h.html#a2330460b9995c46312beb01447edb76f',1,'volk_complex.h']]],
  ['lv_5fcreal_4',['lv_creal',['../volk__complex_8h.html#a9e9cedc79eafa6db42f03878b5a5ba47',1,'volk_complex.h']]]
];
