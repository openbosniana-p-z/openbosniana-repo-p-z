var searchData=
[
  ['main_0',['main',['../namespacevolk__compile__utils.html#a5837a8e811ccd74b7ef68d2e57b4ffd9',1,'volk_compile_utils.main()'],['../namespacevolk__tmpl__utils.html#a507f46837ee4bb3d97edc90543be82e5',1,'volk_tmpl_utils.main()'],['../testqa_8cc.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main():&#160;testqa.cc'],['../namespacerun__citations__update.html#ad0623f54ae6e2f250168f46aeb6c6fa1',1,'run_citations_update.main()']]],
  ['make_5fabsolute_1',['make_absolute',['../classvolk__test__params__t.html#a308aa40ec22eda97a0eb30d611a7dab8',1,'volk_test_params_t']]],
  ['make_5fmodule_5fskeleton_2',['make_module_skeleton',['../classvolk__modtool_1_1volk__modtool__generate_1_1volk__modtool.html#a55769df350790d3a58ed53aad24ba33f',1,'volk_modtool::volk_modtool_generate::volk_modtool']]],
  ['make_5ftol_3',['make_tol',['../classvolk__test__params__t.html#a3161490650dc67e8e5f5b33cabef0a62',1,'volk_test_params_t']]],
  ['maximum_5fframe_5fsize_4',['maximum_frame_size',['../volk__32f__8u__polarbutterflypuppet__32f_8h.html#a71f43e3050db9dd88996577c8b6c1c00',1,'volk_32f_8u_polarbutterflypuppet_32f.h']]],
  ['merge_5fnames_5',['merge_names',['../namespacerun__citations__update.html#a083f258ecf2212f3472f9815a583ab34',1,'run_citations_update']]]
];
