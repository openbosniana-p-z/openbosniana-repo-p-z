var searchData=
[
  ['sanitize_5fbytes_0',['sanitize_bytes',['../volk__32f__8u__polarbutterflypuppet__32f_8h.html#ab1ddf4017e01f8c8aa0e009b1d25fa87',1,'volk_32f_8u_polarbutterflypuppet_32f.h']]],
  ['sat_5fadds16i_1',['sat_adds16i',['../saturation__arithmetic_8h.html#aa5f5bb510b4ff50f0409d3db0265daeb',1,'saturation_arithmetic.h']]],
  ['sat_5fmuls16i_2',['sat_muls16i',['../saturation__arithmetic_8h.html#a6ef288dd3cc6182922e15e23c5f71322',1,'saturation_arithmetic.h']]],
  ['scalar_3',['scalar',['../classvolk__test__params__t.html#a1e5d4c8aec386206c70788e7f9c3e2bb',1,'volk_test_params_t']]],
  ['set_5fbenchmark_4',['set_benchmark',['../classvolk__test__params__t.html#a4f6e4d1791d28f169250998c03b6bfb9',1,'volk_test_params_t']]],
  ['set_5fiter_5',['set_iter',['../classvolk__test__params__t.html#a4962f77ec3b73a8b2bc818327cac5ca6',1,'volk_test_params_t']]],
  ['set_5fregex_6',['set_regex',['../classvolk__test__params__t.html#ae8dad6e29a19f8a158ee8cba2d3facdb',1,'volk_test_params_t']]],
  ['set_5fscalar_7',['set_scalar',['../classvolk__test__params__t.html#a5a3929985108250bca84f31a7a7de9aa',1,'volk_test_params_t']]],
  ['set_5ftol_8',['set_tol',['../classvolk__test__params__t.html#a482a05aa751d8e3c207dbd94d6e2122c',1,'volk_test_params_t']]],
  ['set_5fvlen_9',['set_vlen',['../classvolk__test__params__t.html#a5a42996f14493e9ebdbdb6c741b75669',1,'volk_test_params_t']]],
  ['split_5finto_5fnested_5fifdef_5fsections_10',['split_into_nested_ifdef_sections',['../namespacevolk__kernel__defs.html#a099fb07491ea02388fcc54d71459a943',1,'volk_kernel_defs']]],
  ['split_5fsignature_11',['split_signature',['../qa__utils_8cc.html#a68fab71ef950c73a3d7c65f9117e883d',1,'qa_utils.cc']]]
];
