var searchData=
[
  ['params_0',['params',['../namespacevolk__arch__defs.html#a5279621f8418f0306cf615fc09f72cae',1,'volk_arch_defs']]],
  ['pass_1',['pass',['../classvolk__test__time__t.html#af18c523789978f3a53be7c5b69da147d',1,'volk_test_time_t']]],
  ['pname_2',['pname',['../classvolk__kernel__defs_1_1kernel__class.html#acadd6809f2fbd5e36acaac4cdc93537b',1,'volk_kernel_defs::kernel_class']]]
];
