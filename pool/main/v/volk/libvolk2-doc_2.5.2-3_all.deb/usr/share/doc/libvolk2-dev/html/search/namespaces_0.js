var searchData=
[
  ['run_5fcitations_5fupdate_0',['run_citations_update',['../namespacerun__citations__update.html',1,'']]]
];
