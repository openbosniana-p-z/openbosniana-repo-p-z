var uniondecision__t =
[
    [ "c", "uniondecision__t.html#adeb3944334c0efe91a4c94aa029efab5", null ],
    [ "s", "uniondecision__t.html#a83d1f04e7c1661e9ce544784af0dbcca", null ],
    [ "t", "uniondecision__t.html#a977bde73bcb56b538a5248e46e62eda1", null ],
    [ "w", "uniondecision__t.html#aaecec4cd8583811fe2e9b668aa72beda", null ]
];