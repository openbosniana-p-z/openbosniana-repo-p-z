var searchData=
[
  ['value_5ftype_0',['value_type',['../structvolk_1_1alloc.html#a3a14d9024f3d306775dae2d32bfd5808',1,'volk::alloc']]],
  ['vector_1',['vector',['../namespacevolk.html#ab38dbd2ab7657eb25ac216e984da1a49',1,'volk']]],
  ['volk_5farch_5fpref_5ft_2',['volk_arch_pref_t',['../volk__prefs_8h.html#af19f586342b4e5fb55304905c0b12ff3',1,'volk_prefs.h']]],
  ['volk_5ffn_5f1arg_3',['volk_fn_1arg',['../qa__utils_8h.html#a2f89aadd759aad1337fe38dddd225601',1,'qa_utils.h']]],
  ['volk_5ffn_5f1arg_5fs32f_4',['volk_fn_1arg_s32f',['../qa__utils_8h.html#acb2329fa551d5ff437b1dd7b9078ec99',1,'qa_utils.h']]],
  ['volk_5ffn_5f1arg_5fs32fc_5',['volk_fn_1arg_s32fc',['../qa__utils_8h.html#adced3f85a96eb0b1aab2d4a7556747d9',1,'qa_utils.h']]],
  ['volk_5ffn_5f2arg_6',['volk_fn_2arg',['../qa__utils_8h.html#abd2110a743efad95703f275a34ed9f82',1,'qa_utils.h']]],
  ['volk_5ffn_5f2arg_5fs32f_7',['volk_fn_2arg_s32f',['../qa__utils_8h.html#a8308a610bc4afb0fa0b54bc983955ed5',1,'qa_utils.h']]],
  ['volk_5ffn_5f2arg_5fs32fc_8',['volk_fn_2arg_s32fc',['../qa__utils_8h.html#af9bd1a879111281b6ab581b8a1234440',1,'qa_utils.h']]],
  ['volk_5ffn_5f3arg_9',['volk_fn_3arg',['../qa__utils_8h.html#a68dbe492201b82b95423d522bfbfaec8',1,'qa_utils.h']]],
  ['volk_5ffn_5f3arg_5fs32f_10',['volk_fn_3arg_s32f',['../qa__utils_8h.html#ae71d3830fdfa0bb41cebdc0688977fb4',1,'qa_utils.h']]],
  ['volk_5ffn_5f3arg_5fs32fc_11',['volk_fn_3arg_s32fc',['../qa__utils_8h.html#a76ddfb360fabdf22539a3da618c7fdd1',1,'qa_utils.h']]],
  ['volk_5ffn_5f4arg_12',['volk_fn_4arg',['../qa__utils_8h.html#ab94b105770d8b6431c18e9ff19edabae',1,'qa_utils.h']]]
];
