var searchData=
[
  ['c_0',['C',['../volk__32f__expfast__32f_8h.html#ac4cf4b2ab929bd23951a8676eeac086b',1,'volk_32f_expfast_32f.h']]]
];
