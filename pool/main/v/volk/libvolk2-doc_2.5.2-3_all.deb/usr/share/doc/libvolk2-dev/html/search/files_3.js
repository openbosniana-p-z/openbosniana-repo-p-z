var searchData=
[
  ['kernel_5ftests_2eh_0',['kernel_tests.h',['../kernel__tests_8h.html',1,'']]],
  ['kernels_2edox_1',['kernels.dox',['../kernels_8dox.html',1,'']]]
];
