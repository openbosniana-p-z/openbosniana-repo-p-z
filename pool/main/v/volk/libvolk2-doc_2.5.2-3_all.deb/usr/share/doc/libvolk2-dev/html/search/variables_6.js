var searchData=
[
  ['has_5fdispatcher_0',['has_dispatcher',['../classvolk__kernel__defs_1_1kernel__class.html#a14b69da65d590563c0bfce9e15565603',1,'volk_kernel_defs::kernel_class']]]
];
