var dir_974b6411e0c0ff18898113d6f544eb7d =
[
    [ "run_citations_update.py", "run__citations__update_8py.html", "run__citations__update_8py" ]
];