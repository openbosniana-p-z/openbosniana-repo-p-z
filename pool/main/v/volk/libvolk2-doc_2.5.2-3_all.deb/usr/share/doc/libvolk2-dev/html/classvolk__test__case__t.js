var classvolk__test__case__t =
[
    [ "volk_test_case_t", "classvolk__test__case__t.html#ae488ae07a08dad936110ab1dcd4a6848", null ],
    [ "volk_test_case_t", "classvolk__test__case__t.html#a7580bf65609e579e0fb5deca4f995ed6", null ],
    [ "desc", "classvolk__test__case__t.html#a19afd701f36b6f41c9277779beb5c42a", null ],
    [ "name", "classvolk__test__case__t.html#add1e513735556a08dd252a5f89a84a49", null ],
    [ "puppet_master_name", "classvolk__test__case__t.html#a1e208bee880c97612af28355438655b5", null ],
    [ "test_parameters", "classvolk__test__case__t.html#a50591a0450d6587d24011a5775e9c433", null ],
    [ "kernel_ptr", "classvolk__test__case__t.html#a26f0f4cffebd0c84712e6a242b40ce0b", null ]
];