var searchData=
[
  ['changelog_0',['Changelog',['../md_docs__c_h_a_n_g_e_l_o_g.html',1,'']]],
  ['concepts_2c_20terms_2c_20and_20techniques_1',['Concepts, Terms, and Techniques',['../concepts_terms_and_techniques.html',1,'']]],
  ['contributing_20to_20volk_2',['Contributing to VOLK',['../md_docs__c_o_n_t_r_i_b_u_t_i_n_g.html',1,'']]]
];
