var searchData=
[
  ['q_5frsqrt_0',['Q_rsqrt',['../volk__32f__invsqrt__32f_8h.html#aeb64e1ec1eeb71734b28c1799502557c',1,'volk_32f_invsqrt_32f.h']]],
  ['qa_1',['QA',['../kernel__tests_8h.html#a6dc77be697ba265945fcda9c16701b39',1,'kernel_tests.h']]],
  ['qa_5futils_2ecc_2',['qa_utils.cc',['../qa__utils_8cc.html',1,'']]],
  ['qa_5futils_2eh_3',['qa_utils.h',['../qa__utils_8h.html',1,'']]]
];
