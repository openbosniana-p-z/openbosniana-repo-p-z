var searchData=
[
  ['how_20to_20create_20custom_20kernel_20dispatchers_0',['How to create custom kernel dispatchers',['../md_kernels__r_e_a_d_m_e.html',1,'']]]
];
