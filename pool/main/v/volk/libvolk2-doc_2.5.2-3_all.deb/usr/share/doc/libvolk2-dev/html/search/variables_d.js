var searchData=
[
  ['remapification_0',['remapification',['../classvolk__modtool_1_1cfg_1_1volk__modtool__config.html#a676ad294495153dd2449e7de8bf7fdb6',1,'volk_modtool::cfg::volk_modtool_config']]],
  ['remove_5fafter_5funderscore_1',['remove_after_underscore',['../classvolk__modtool_1_1volk__modtool__generate_1_1volk__modtool.html#a59ecd58edef5de298c799be324c55e9c',1,'volk_modtool::volk_modtool_generate::volk_modtool']]],
  ['res0_2',['res0',['../structfpcr__bitfield.html#a07262cc6de7f02a3a565a982d7766fc3',1,'fpcr_bitfield']]],
  ['res1_3',['res1',['../structfpcr__bitfield.html#a2323458ee71138313092f66c11a6e8fb',1,'fpcr_bitfield']]],
  ['res2_4',['res2',['../structfpcr__bitfield.html#a9e3af44de655e048929dfaa78be4b22e',1,'fpcr_bitfield']]],
  ['results_5',['results',['../classvolk__test__results__t.html#a34aef184cee76a03da922ec6a9620d0e',1,'volk_test_results_t']]]
];
