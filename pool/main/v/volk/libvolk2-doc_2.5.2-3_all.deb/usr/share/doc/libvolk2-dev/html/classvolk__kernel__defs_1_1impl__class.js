var classvolk__kernel__defs_1_1impl__class =
[
    [ "__init__", "classvolk__kernel__defs_1_1impl__class.html#a42b15404fc03732e0c0a68a6374f9ceb", null ],
    [ "__repr__", "classvolk__kernel__defs_1_1impl__class.html#af8905302c33897d8c330728be05bd90a", null ],
    [ "args", "classvolk__kernel__defs_1_1impl__class.html#ac4ab12c5a4fc427622b47a33dc96a9ca", null ],
    [ "deps", "classvolk__kernel__defs_1_1impl__class.html#aaeeb012993ce93acc22f323d1e08bb96", null ],
    [ "is_aligned", "classvolk__kernel__defs_1_1impl__class.html#acc69d9b147395944adf080f4a654218e", null ],
    [ "name", "classvolk__kernel__defs_1_1impl__class.html#af3a6621bc9e5827671762d0f1ca0bb9f", null ]
];