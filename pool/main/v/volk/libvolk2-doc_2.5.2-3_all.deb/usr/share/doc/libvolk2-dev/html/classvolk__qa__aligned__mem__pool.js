var classvolk__qa__aligned__mem__pool =
[
    [ "~volk_qa_aligned_mem_pool", "classvolk__qa__aligned__mem__pool.html#a225982c7d64d25252da5602b3abfb8d8", null ],
    [ "get_new", "classvolk__qa__aligned__mem__pool.html#a8c8df462482d00c22abfa6d6254f44ef", null ]
];