var searchData=
[
  ['t_0',['t',['../unionp__decision__t.html#a7d87c644ef89ce7977e3a6a7754e0fba',1,'p_decision_t::t()'],['../uniondecision__t.html#a977bde73bcb56b538a5248e46e62eda1',1,'decision_t::t()']]],
  ['terms_1',['TERMS',['../volk__32f__atan__32f_8h.html#a51bb25ad979da93f37683b2bee04d1bb',1,'volk_32f_atan_32f.h']]],
  ['terms_5fand_5ftechniques_2edox_2',['terms_and_techniques.dox',['../terms__and__techniques_8dox.html',1,'']]],
  ['test_5fparameters_3',['test_parameters',['../classvolk__test__case__t.html#a50591a0450d6587d24011a5775e9c433',1,'volk_test_case_t']]],
  ['testqa_2ecc_4',['testqa.cc',['../testqa_8cc.html',1,'']]],
  ['time_5',['time',['../classvolk__test__time__t.html#a2542710f1ff7b4b0349886a026c8bf6c',1,'volk_test_time_t']]],
  ['tol_6',['tol',['../classvolk__test__params__t.html#afc4e19cb81830acbb818c32a462f1aa9',1,'volk_test_params_t']]]
];
