var searchData=
[
  ['fcompare_0',['fcompare',['../qa__utils_8cc.html#a779a84ccc7570de879149dc0ffc5186b',1,'qa_utils.cc']]],
  ['find_5fcitation_5ffile_1',['find_citation_file',['../namespacerun__citations__update.html#a5c4b0843086fcc5b0f6be7288b35d961',1,'run_citations_update']]],
  ['fix_5fknown_5fnames_2',['fix_known_names',['../namespacerun__citations__update.html#a95251b98c5e38878503719ba1d997e56',1,'run_citations_update']]],
  ['flatten_5fsection_5ftext_3',['flatten_section_text',['../namespacevolk__kernel__defs.html#a29461610fe96acb868dcc54e3a9905b5',1,'volk_kernel_defs']]]
];
