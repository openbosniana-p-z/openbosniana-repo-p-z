var searchData=
[
  ['s_0',['s',['../uniondecision__t.html#a83d1f04e7c1661e9ce544784af0dbcca',1,'decision_t']]],
  ['simdvec_1',['SIMDVec',['../sse2neon_8h.html#afef688070e82aab885b5d8b1204bae84',1,'sse2neon.h']]],
  ['size_2',['size',['../structvolk__type__t.html#ac60d025d4db560a8d42522fa216285df',1,'volk_type_t']]],
  ['srcdir_3',['srcdir',['../namespacevolk__kernel__defs.html#ade702fb3f5e329f36005af43c47399c5',1,'volk_kernel_defs']]],
  ['sse2neon_5fsbox_4',['SSE2NEON_sbox',['../sse2neon_8h.html#ad2780622735d56636223ed31497aeca2',1,'sse2neon.h']]],
  ['str_5',['str',['../structvolk__type__t.html#a9dbe606f1017bbcd47f6e5d32b3c2345',1,'volk_type_t']]]
];
