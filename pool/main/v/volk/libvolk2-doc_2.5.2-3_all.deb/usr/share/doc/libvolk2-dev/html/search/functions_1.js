var searchData=
[
  ['absolute_5fmode_0',['absolute_mode',['../classvolk__test__params__t.html#a4880be540ea243cd2668a9d8cad049b3',1,'volk_test_params_t']]],
  ['accrue_5fresult_1',['accrue_result',['../volk__32f__stddev__and__mean__32f__x2_8h.html#a4eb1301adbc52c97349d703b4a7a368c',1,'volk_32f_stddev_and_mean_32f_x2.h']]],
  ['add_5fsquare_5fsums_2',['add_square_sums',['../volk__32f__stddev__and__mean__32f__x2_8h.html#a421dfba75bf21154fcbf10fef2607d3c',1,'volk_32f_stddev_and_mean_32f_x2.h']]],
  ['adjust_5ffrozen_5fmask_3',['adjust_frozen_mask',['../volk__8u__x3__encodepolarpuppet__8u_8h.html#a2efcbbe45527407d5ddf5724861e91b5',1,'volk_8u_x3_encodepolarpuppet_8u.h']]],
  ['align_5fstruct_4',['ALIGN_STRUCT',['../sse2neon_8h.html#af50c4382585bd76da21cf701a333e30f',1,'sse2neon.h']]],
  ['alloc_5',['alloc',['../structvolk_1_1alloc.html#a92128b2c407822062294b2ccb614e392',1,'volk::alloc::alloc()=default'],['../structvolk_1_1alloc.html#ad7558a21bfa9a67e0b0feeaa04ca3bb4',1,'volk::alloc::alloc(alloc&lt; U &gt; const &amp;) noexcept']]],
  ['allocate_6',['allocate',['../structvolk_1_1alloc.html#adcbfaa9f2edae51034f91d17157686e7',1,'volk::alloc']]]
];
