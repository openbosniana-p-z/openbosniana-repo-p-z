var searchData=
[
  ['name_0',['name',['../classvolk__test__case__t.html#add1e513735556a08dd252a5f89a84a49',1,'volk_test_case_t']]],
  ['next_5flower_5fpower_5fof_5ftwo_1',['next_lower_power_of_two',['../volk__8u__x3__encodepolarpuppet__8u_8h.html#a6324e29044c350c7a062a4711d17087a',1,'volk_8u_x3_encodepolarpuppet_8u.h']]],
  ['normalize_5fnames_2',['normalize_names',['../namespacerun__citations__update.html#aea3cfd9b1a9546be9452e1af628165bd',1,'run_citations_update']]]
];
