var dir_dcf56790c413bee594765e8faf46e4bb =
[
    [ "constants.h", "constants_8h.html", "constants_8h" ],
    [ "saturation_arithmetic.h", "saturation__arithmetic_8h.html", "saturation__arithmetic_8h" ],
    [ "sse2neon.h", "sse2neon_8h.html", "sse2neon_8h" ],
    [ "volk_alloc.hh", "volk__alloc_8hh.html", "volk__alloc_8hh" ],
    [ "volk_avx2_intrinsics.h", "volk__avx2__intrinsics_8h.html", "volk__avx2__intrinsics_8h" ],
    [ "volk_avx_intrinsics.h", "volk__avx__intrinsics_8h.html", "volk__avx__intrinsics_8h" ],
    [ "volk_common.h", "volk__common_8h.html", "volk__common_8h" ],
    [ "volk_complex.h", "volk__complex_8h.html", "volk__complex_8h" ],
    [ "volk_malloc.h", "volk__malloc_8h.html", "volk__malloc_8h" ],
    [ "volk_neon_intrinsics.h", "volk__neon__intrinsics_8h.html", "volk__neon__intrinsics_8h" ],
    [ "volk_prefs.h", "volk__prefs_8h.html", "volk__prefs_8h" ],
    [ "volk_sse3_intrinsics.h", "volk__sse3__intrinsics_8h.html", "volk__sse3__intrinsics_8h" ],
    [ "volk_sse_intrinsics.h", "volk__sse__intrinsics_8h.html", "volk__sse__intrinsics_8h" ]
];