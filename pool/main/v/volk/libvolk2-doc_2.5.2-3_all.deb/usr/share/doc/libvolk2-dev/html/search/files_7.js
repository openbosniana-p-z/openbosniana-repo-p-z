var searchData=
[
  ['saturation_5farithmetic_2eh_0',['saturation_arithmetic.h',['../saturation__arithmetic_8h.html',1,'']]],
  ['sse2neon_2eh_1',['sse2neon.h',['../sse2neon_8h.html',1,'']]]
];
