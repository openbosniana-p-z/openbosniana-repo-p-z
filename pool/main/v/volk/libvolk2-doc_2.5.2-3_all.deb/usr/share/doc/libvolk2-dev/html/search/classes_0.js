var searchData=
[
  ['alloc_0',['alloc',['../structvolk_1_1alloc.html',1,'volk']]],
  ['arch_5fclass_1',['arch_class',['../classvolk__arch__defs_1_1arch__class.html',1,'volk_arch_defs']]]
];
