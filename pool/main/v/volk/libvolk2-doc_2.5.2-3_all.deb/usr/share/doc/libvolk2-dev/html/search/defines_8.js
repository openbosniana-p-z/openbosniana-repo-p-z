var searchData=
[
  ['max_0',['MAX',['../volk__32f__x3__sum__of__poly__32f_8h.html#aff9931d7524c88e07743af6535b20761',1,'volk_32f_x3_sum_of_poly_32f.h']]],
  ['mln2_1',['Mln2',['../volk__32f__expfast__32f_8h.html#a0f790f260a1dbc13e6fe3c36c29978bf',1,'volk_32f_expfast_32f.h']]]
];
