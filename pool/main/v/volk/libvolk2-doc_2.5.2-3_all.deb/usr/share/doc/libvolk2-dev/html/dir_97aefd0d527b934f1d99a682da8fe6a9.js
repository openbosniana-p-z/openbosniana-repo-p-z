var dir_97aefd0d527b934f1d99a682da8fe6a9 =
[
    [ "kernel_tests.h", "kernel__tests_8h.html", "kernel__tests_8h" ],
    [ "qa_utils.cc", "qa__utils_8cc.html", "qa__utils_8cc" ],
    [ "qa_utils.h", "qa__utils_8h.html", "qa__utils_8h" ],
    [ "testqa.cc", "testqa_8cc.html", "testqa_8cc" ],
    [ "volk_malloc.c", "volk__malloc_8c.html", "volk__malloc_8c" ],
    [ "volk_prefs.c", "volk__prefs_8c.html", "volk__prefs_8c" ],
    [ "volk_rank_archs.c", "volk__rank__archs_8c.html", "volk__rank__archs_8c" ],
    [ "volk_rank_archs.h", "volk__rank__archs_8h.html", "volk__rank__archs_8h" ]
];