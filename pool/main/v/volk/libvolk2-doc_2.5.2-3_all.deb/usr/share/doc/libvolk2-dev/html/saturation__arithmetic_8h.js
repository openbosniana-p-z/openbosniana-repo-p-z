var saturation__arithmetic_8h =
[
    [ "sat_adds16i", "saturation__arithmetic_8h.html#aa5f5bb510b4ff50f0409d3db0265daeb", null ],
    [ "sat_muls16i", "saturation__arithmetic_8h.html#a6ef288dd3cc6182922e15e23c5f71322", null ]
];