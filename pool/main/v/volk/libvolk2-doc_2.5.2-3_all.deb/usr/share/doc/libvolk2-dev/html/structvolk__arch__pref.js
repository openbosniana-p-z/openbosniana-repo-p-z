var structvolk__arch__pref =
[
    [ "impl_a", "structvolk__arch__pref.html#a5def79909224275149a12a980ce121a4", null ],
    [ "impl_u", "structvolk__arch__pref.html#a453e0513c4a1cfc2e595c472103f4eec", null ],
    [ "name", "structvolk__arch__pref.html#a84fe69582db66b693dfd75272d53252f", null ]
];