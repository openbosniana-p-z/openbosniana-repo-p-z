var searchData=
[
  ['llr_5feven_0',['llr_even',['../volk__32f__8u__polarbutterfly__32f_8h.html#a2a9319c60b9c8dc75ac13280382415ae',1,'volk_32f_8u_polarbutterfly_32f.h']]],
  ['llr_5fodd_1',['llr_odd',['../volk__32f__8u__polarbutterfly__32f_8h.html#abe4729b16368046808e3a2c4ba7a5c8f',1,'volk_32f_8u_polarbutterfly_32f.h']]],
  ['llr_5fodd_5fstages_2',['llr_odd_stages',['../volk__32f__8u__polarbutterfly__32f_8h.html#a34b9042d563dea6304401bbc3bbee0ed',1,'volk_32f_8u_polarbutterfly_32f.h']]],
  ['load_5fcitation_5ffile_3',['load_citation_file',['../namespacerun__citations__update.html#af35b306ea0ace8a683121038c72f2ee3',1,'run_citations_update']]],
  ['load_5frandom_5fdata_4',['load_random_data',['../qa__utils_8cc.html#aedffb52f08e14c5f41dd7d2601c30e57',1,'qa_utils.cc']]],
  ['log2_5fof_5fpower_5fof_5f2_5',['log2_of_power_of_2',['../volk__8u__x2__encodeframepolar__8u_8h.html#a7e3e6c4249d1e162299f6dbc073889be',1,'volk_8u_x2_encodeframepolar_8u.h']]],
  ['log2f_5fnon_5fieee_6',['log2f_non_ieee',['../volk__common_8h.html#aad3e8cad9bde3c6bcaad473db951ea7f',1,'volk_common.h']]]
];
