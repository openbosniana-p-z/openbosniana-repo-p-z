var structvolk__type__t =
[
    [ "is_complex", "structvolk__type__t.html#a1f9983b662a63db2b5c76d24779a1aba", null ],
    [ "is_float", "structvolk__type__t.html#ab9c934f8d5d8240031bd85e6d677c07b", null ],
    [ "is_scalar", "structvolk__type__t.html#a75ca9c026a0d0a329be09c4fd31ad180", null ],
    [ "is_signed", "structvolk__type__t.html#a1655c5b7a23423a7733f8807b7cada8b", null ],
    [ "size", "structvolk__type__t.html#ac60d025d4db560a8d42522fa216285df", null ],
    [ "str", "structvolk__type__t.html#a9dbe606f1017bbcd47f6e5d32b3c2345", null ]
];