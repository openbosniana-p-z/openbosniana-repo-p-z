var searchData=
[
  ['sse2neon_5faes_5fb2w_0',['SSE2NEON_AES_B2W',['../sse2neon_8h.html#a070b136af9a783703dca15147e069681',1,'sse2neon.h']]],
  ['sse2neon_5faes_5fdata_1',['SSE2NEON_AES_DATA',['../sse2neon_8h.html#a3e19573f88b560880afc5158cf2a3aa6',1,'sse2neon.h']]],
  ['sse2neon_5faes_5ff2_2',['SSE2NEON_AES_F2',['../sse2neon_8h.html#a8d2da334f61cd2d8350d188daea4c0b2',1,'sse2neon.h']]],
  ['sse2neon_5faes_5ff3_3',['SSE2NEON_AES_F3',['../sse2neon_8h.html#ac92721fe90a0403ce06242a2f44984d1',1,'sse2neon.h']]],
  ['sse2neon_5faes_5fh0_4',['SSE2NEON_AES_H0',['../sse2neon_8h.html#afac8af0d3b0ea43fea78c52906e92db2',1,'sse2neon.h']]],
  ['sse2neon_5faes_5fu0_5',['SSE2NEON_AES_U0',['../sse2neon_8h.html#a4308c45591a26fe6641ab803b633ce86',1,'sse2neon.h']]],
  ['sse2neon_5faes_5fu1_6',['SSE2NEON_AES_U1',['../sse2neon_8h.html#ac6a84766118d23ea950edc76e4c48ed3',1,'sse2neon.h']]],
  ['sse2neon_5faes_5fu2_7',['SSE2NEON_AES_U2',['../sse2neon_8h.html#a103fff5364558e5e63428c2ebb7d20a0',1,'sse2neon.h']]],
  ['sse2neon_5faes_5fu3_8',['SSE2NEON_AES_U3',['../sse2neon_8h.html#abfe4cbe2de2f4d23c68fd76745e50319',1,'sse2neon.h']]],
  ['sse2neon_5fprecise_5fdiv_9',['SSE2NEON_PRECISE_DIV',['../sse2neon_8h.html#aa3c48012020b2657fd315f7d7a3d9a30',1,'sse2neon.h']]],
  ['sse2neon_5fprecise_5fdp_10',['SSE2NEON_PRECISE_DP',['../sse2neon_8h.html#a5ecab727c00b91686f9389d6ccf0195a',1,'sse2neon.h']]],
  ['sse2neon_5fprecise_5fminmax_11',['SSE2NEON_PRECISE_MINMAX',['../sse2neon_8h.html#a1d9963fb6c9d4d3ec7c9a460b848498b',1,'sse2neon.h']]],
  ['sse2neon_5fprecise_5fsqrt_12',['SSE2NEON_PRECISE_SQRT',['../sse2neon_8h.html#a3997ba865051f6c010544604ab877874',1,'sse2neon.h']]]
];
