var searchData=
[
  ['i_0',['i',['../unionbit128.html#aa041f436e8c47ce199f2e61a54c000bf',1,'bit128::i()'],['../unionbit256.html#a7215b9dbc605284ce9913a79e18b1463',1,'bit256::i()']]],
  ['i16_1',['i16',['../unionbit128.html#aaf4e694dd656b8a695f2b3a7d48a3b8a',1,'bit128::i16()'],['../unionbit256.html#a2f1ffeb37652f3f95b79ed37020c7248',1,'bit256::i16()']]],
  ['i8_2',['i8',['../unionbit128.html#a5f39cf527f76819e2deada1123dd482e',1,'bit128::i8()'],['../unionbit256.html#a244da0efe9d74b2a9e9e7eeda637d848',1,'bit256::i8()']]],
  ['impl_5fa_3',['impl_a',['../structvolk__arch__pref.html#a5def79909224275149a12a980ce121a4',1,'volk_arch_pref']]],
  ['impl_5fu_4',['impl_u',['../structvolk__arch__pref.html#a453e0513c4a1cfc2e595c472103f4eec',1,'volk_arch_pref']]],
  ['int_5fvec_5',['int_vec',['../unionbit128.html#a2986c2342d07680e3d1cb854310ed96f',1,'bit128::int_vec()'],['../unionbit256.html#aeece0501ca82ab495b18d3a5baafcb09',1,'bit256::int_vec()']]],
  ['is_5faligned_6',['is_aligned',['../classvolk__kernel__defs_1_1impl__class.html#acc69d9b147395944adf080f4a654218e',1,'volk_kernel_defs::impl_class']]],
  ['is_5fcomplex_7',['is_complex',['../structvolk__type__t.html#a1f9983b662a63db2b5c76d24779a1aba',1,'volk_type_t']]],
  ['is_5ffloat_8',['is_float',['../structvolk__type__t.html#ab9c934f8d5d8240031bd85e6d677c07b',1,'volk_type_t']]],
  ['is_5fscalar_9',['is_scalar',['../structvolk__type__t.html#a75ca9c026a0d0a329be09c4fd31ad180',1,'volk_type_t']]],
  ['is_5fsigned_10',['is_signed',['../structvolk__type__t.html#a1655c5b7a23423a7733f8807b7cada8b',1,'volk_type_t']]],
  ['iter_11',['iter',['../classvolk__test__results__t.html#a15cf2084d51541021c7be7915780265f',1,'volk_test_results_t']]]
];
