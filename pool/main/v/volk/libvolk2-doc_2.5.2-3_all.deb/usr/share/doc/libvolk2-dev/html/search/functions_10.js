var searchData=
[
  ['random_5ffloats_0',['random_floats',['../qa__utils_8cc.html#a117e1cfbdbae5c5a68ac58da9bf50066',1,'random_floats(void *buf, unsigned int n, std::default_random_engine &amp;rnd_engine):&#160;qa_utils.cc'],['../qa__utils_8h.html#afe36104681ff6d7cfaba4fbd21a02c78',1,'random_floats(float *buf, unsigned n):&#160;qa_utils.h']]],
  ['read_5fmap_1',['read_map',['../classvolk__modtool_1_1cfg_1_1volk__modtool__config.html#a3da6c380cd9a5b7d53b6df4c2f395eab',1,'volk_modtool::cfg::volk_modtool_config']]],
  ['register_5farch_2',['register_arch',['../namespacevolk__arch__defs.html#a4d9a6fe0ae9cc6d0a7eb3b51b138b8fe',1,'volk_arch_defs']]],
  ['register_5fmachine_3',['register_machine',['../namespacevolk__machine__defs.html#af254f5f34d20b9ccf671585926a57bd4',1,'volk_machine_defs']]],
  ['remap_4',['remap',['../classvolk__modtool_1_1cfg_1_1volk__modtool__config.html#a6fc7260c787839b821e04c69c31c4269',1,'volk_modtool::cfg::volk_modtool_config']]],
  ['remove_5fkernel_5',['remove_kernel',['../classvolk__modtool_1_1volk__modtool__generate_1_1volk__modtool.html#ad5c540716c7594c566ec305bc786ab79',1,'volk_modtool::volk_modtool_generate::volk_modtool']]],
  ['renormalize_6',['renormalize',['../volk__8u__x4__conv__k7__r2__8u_8h.html#aea94685f1958f5d3d5b7543f3f768d55',1,'volk_8u_x4_conv_k7_r2_8u.h']]],
  ['run_5fcast_5ftest1_7',['run_cast_test1',['../qa__utils_8cc.html#a32fb341f6d28745845d933969a96b355',1,'qa_utils.cc']]],
  ['run_5fcast_5ftest1_5fs32f_8',['run_cast_test1_s32f',['../qa__utils_8cc.html#a5cce9a706b86e6d8030bc4454a84d742',1,'qa_utils.cc']]],
  ['run_5fcast_5ftest1_5fs32fc_9',['run_cast_test1_s32fc',['../qa__utils_8cc.html#a865c9727bbe1ab7522eb5ea2b211081a',1,'qa_utils.cc']]],
  ['run_5fcast_5ftest2_10',['run_cast_test2',['../qa__utils_8cc.html#a7b592491e062892c19012c53f4428a0d',1,'qa_utils.cc']]],
  ['run_5fcast_5ftest2_5fs32f_11',['run_cast_test2_s32f',['../qa__utils_8cc.html#a4846e4f59d40acd020a3e8e8f447a4aa',1,'qa_utils.cc']]],
  ['run_5fcast_5ftest2_5fs32fc_12',['run_cast_test2_s32fc',['../qa__utils_8cc.html#a66c3f228af95080dc15d735239ec2e8c',1,'qa_utils.cc']]],
  ['run_5fcast_5ftest3_13',['run_cast_test3',['../qa__utils_8cc.html#a18b16a04b7301beeab4832072bdbda76',1,'qa_utils.cc']]],
  ['run_5fcast_5ftest3_5fs32f_14',['run_cast_test3_s32f',['../qa__utils_8cc.html#ac2fcddaeabfccdb401e5b4d984395bf0',1,'qa_utils.cc']]],
  ['run_5fcast_5ftest3_5fs32fc_15',['run_cast_test3_s32fc',['../qa__utils_8cc.html#a6133c3dfe5a95bc45bc714595bbd22d2',1,'qa_utils.cc']]],
  ['run_5fcast_5ftest4_16',['run_cast_test4',['../qa__utils_8cc.html#af6d7a16eb531c74a402fb1ed86c66db2',1,'qa_utils.cc']]],
  ['run_5fvolk_5ftests_17',['run_volk_tests',['../qa__utils_8cc.html#ae032ab624254976ef28115db689b2133',1,'run_volk_tests(volk_func_desc_t desc, void(*manual_func)(), std::string name, volk_test_params_t test_params, std::vector&lt; volk_test_results_t &gt; *results, std::string puppet_master_name):&#160;qa_utils.cc'],['../qa__utils_8cc.html#a4d88fe8e5bd526c684defa997ff8b5c0',1,'run_volk_tests(volk_func_desc_t desc, void(*manual_func)(), std::string name, float tol, lv_32fc_t scalar, unsigned int vlen, unsigned int iter, std::vector&lt; volk_test_results_t &gt; *results, std::string puppet_master_name, bool absolute_mode, bool benchmark_mode):&#160;qa_utils.cc'],['../qa__utils_8h.html#ae56d0c0a42cfd407aaebe5c01ac626eb',1,'run_volk_tests(volk_func_desc_t, void(*)(), std::string, volk_test_params_t, std::vector&lt; volk_test_results_t &gt; *results=NULL, std::string puppet_master_name=&quot;NULL&quot;):&#160;qa_utils.cc'],['../qa__utils_8h.html#af0db2de611b04024577fc767145fa291',1,'run_volk_tests(volk_func_desc_t, void(*)(), std::string, float, lv_32fc_t, unsigned int, unsigned int, std::vector&lt; volk_test_results_t &gt; *results=NULL, std::string puppet_master_name=&quot;NULL&quot;, bool absolute_mode=false, bool benchmark_mode=false):&#160;qa_utils.cc']]]
];
