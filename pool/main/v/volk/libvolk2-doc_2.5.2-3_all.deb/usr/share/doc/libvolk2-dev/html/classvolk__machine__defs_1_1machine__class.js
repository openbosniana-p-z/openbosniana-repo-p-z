var classvolk__machine__defs_1_1machine__class =
[
    [ "__init__", "classvolk__machine__defs_1_1machine__class.html#aabaf0f929bdff1c8f108a6e53583d0b7", null ],
    [ "__repr__", "classvolk__machine__defs_1_1machine__class.html#a0db9aa569cf4fab98890b29863db6aee", null ],
    [ "alignment", "classvolk__machine__defs_1_1machine__class.html#a61b0189c5b58cc5899794ca137fd44d0", null ],
    [ "arch_names", "classvolk__machine__defs_1_1machine__class.html#aac3809099880ffe678dbbe70a0752e30", null ],
    [ "archs", "classvolk__machine__defs_1_1machine__class.html#a83be842d912cfb8f69aa7b8f5d0bea7e", null ],
    [ "name", "classvolk__machine__defs_1_1machine__class.html#aaec507a55242272e7eb738e955cb975d", null ]
];