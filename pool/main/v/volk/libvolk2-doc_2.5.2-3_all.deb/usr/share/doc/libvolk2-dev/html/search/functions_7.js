var searchData=
[
  ['generate_5ferror_5ffree_5finput_5fvector_0',['generate_error_free_input_vector',['../volk__32f__8u__polarbutterflypuppet__32f_8h.html#a9ae791afa2c03b4cf9df45d4a114ed03',1,'volk_32f_8u_polarbutterflypuppet_32f.h']]],
  ['get_5farch_5flist_1',['get_arch_list',['../qa__utils_8cc.html#a7ffc025b950bd5b1ee7637dd26910be4',1,'qa_utils.cc']]],
  ['get_5fbasename_2',['get_basename',['../classvolk__modtool_1_1volk__modtool__generate_1_1volk__modtool.html#a8edefbb0e69db30242c7bdb9016ca780',1,'volk_modtool::volk_modtool_generate::volk_modtool']]],
  ['get_5fcurrent_5fkernels_3',['get_current_kernels',['../classvolk__modtool_1_1volk__modtool__generate_1_1volk__modtool.html#a454650acd1cd381d93f57ce81d85c142',1,'volk_modtool::volk_modtool_generate::volk_modtool']]],
  ['get_5fflags_4',['get_flags',['../classvolk__arch__defs_1_1arch__class.html#abf6af012548d66289e47a67b6b908af0',1,'volk_arch_defs::arch_class']]],
  ['get_5fimpls_5',['get_impls',['../classvolk__kernel__defs_1_1kernel__class.html#afd8ce0de5c22781943b69c0e9ae1ba30',1,'volk_kernel_defs::kernel_class']]],
  ['get_5fmap_6',['get_map',['../classvolk__modtool_1_1cfg_1_1volk__modtool__config.html#a2e20cbb56a875efe42107bb69c41c851',1,'volk_modtool::cfg::volk_modtool_config']]],
  ['get_5fnew_7',['get_new',['../classvolk__qa__aligned__mem__pool.html#a8c8df462482d00c22abfa6d6254f44ef',1,'volk_qa_aligned_mem_pool']]],
  ['get_5fsignatures_5ffrom_5fname_8',['get_signatures_from_name',['../qa__utils_8cc.html#afeb455eb595378ecb3954e6f493e1ec6',1,'qa_utils.cc']]]
];
