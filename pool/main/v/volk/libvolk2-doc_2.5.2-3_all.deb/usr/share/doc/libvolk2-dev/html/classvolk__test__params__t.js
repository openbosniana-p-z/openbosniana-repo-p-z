var classvolk__test__params__t =
[
    [ "volk_test_params_t", "classvolk__test__params__t.html#a84c3f80faf20c22a47316c59f7a2cc87", null ],
    [ "absolute_mode", "classvolk__test__params__t.html#a4880be540ea243cd2668a9d8cad049b3", null ],
    [ "benchmark_mode", "classvolk__test__params__t.html#afe15f57daa86b3306adebf92620157b2", null ],
    [ "iter", "classvolk__test__params__t.html#a2c4f7340653c154881f911c6d78939f0", null ],
    [ "kernel_regex", "classvolk__test__params__t.html#a5f3cbf11b30fe959f139745bdfdb3934", null ],
    [ "make_absolute", "classvolk__test__params__t.html#a308aa40ec22eda97a0eb30d611a7dab8", null ],
    [ "make_tol", "classvolk__test__params__t.html#a3161490650dc67e8e5f5b33cabef0a62", null ],
    [ "scalar", "classvolk__test__params__t.html#a1e5d4c8aec386206c70788e7f9c3e2bb", null ],
    [ "set_benchmark", "classvolk__test__params__t.html#a4f6e4d1791d28f169250998c03b6bfb9", null ],
    [ "set_iter", "classvolk__test__params__t.html#a4962f77ec3b73a8b2bc818327cac5ca6", null ],
    [ "set_regex", "classvolk__test__params__t.html#ae8dad6e29a19f8a158ee8cba2d3facdb", null ],
    [ "set_scalar", "classvolk__test__params__t.html#a5a3929985108250bca84f31a7a7de9aa", null ],
    [ "set_tol", "classvolk__test__params__t.html#a482a05aa751d8e3c207dbd94d6e2122c", null ],
    [ "set_vlen", "classvolk__test__params__t.html#a5a42996f14493e9ebdbdb6c741b75669", null ],
    [ "tol", "classvolk__test__params__t.html#afc4e19cb81830acbb818c32a462f1aa9", null ],
    [ "vlen", "classvolk__test__params__t.html#a33f7e1fb21bab1bdbbc66a2352f81d0a", null ]
];