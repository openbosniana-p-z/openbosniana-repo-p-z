var searchData=
[
  ['d_0',['d',['../unionbit128.html#aaa05f29f2ea72932452b2aa7e29cdea6',1,'bit128::d()'],['../unionbit256.html#a54f6deb0e3f51c7f0d888330adf2bbcc',1,'bit256::d()']]],
  ['deallocate_1',['deallocate',['../structvolk_1_1alloc.html#a2d6ad719a74bf67b338a8606c067d6ac',1,'volk::alloc']]],
  ['decision_5ft_2',['decision_t',['../uniondecision__t.html',1,'']]],
  ['deps_3',['deps',['../classvolk__kernel__defs_1_1impl__class.html#aaeeb012993ce93acc22f323d1e08bb96',1,'volk_kernel_defs::impl_class']]],
  ['desc_4',['desc',['../classvolk__test__case__t.html#a19afd701f36b6f41c9277779beb5c42a',1,'volk_test_case_t']]],
  ['do_5farch_5fflags_5flist_5',['do_arch_flags_list',['../namespacevolk__compile__utils.html#a21184c44b64e6eea77d5dbaa9ffb93b8',1,'volk_compile_utils']]],
  ['do_5fmachine_5fflags_5flist_6',['do_machine_flags_list',['../namespacevolk__compile__utils.html#a5b4ff9bd459700ff993e9831ac84eda6',1,'volk_compile_utils']]],
  ['do_5fmachines_5flist_7',['do_machines_list',['../namespacevolk__compile__utils.html#a1f30798b4d4f81dd4faefc8654528496',1,'volk_compile_utils']]],
  ['do_5frbit_8',['DO_RBIT',['../volk__32u__reverse__32u_8h.html#a7c6c50ff9bbab4a55cb98d37f9b4b666',1,'volk_32u_reverse_32u.h']]],
  ['double_5fvec_9',['double_vec',['../unionbit128.html#a332ed77d3ca646e23af92f01d0b1fec7',1,'bit128::double_vec()'],['../unionbit256.html#a1b035eff78246f6a328418ff290d5275',1,'bit256::double_vec()']]],
  ['dword_5fsplit_10',['dword_split',['../structdword__split.html',1,'']]]
];
