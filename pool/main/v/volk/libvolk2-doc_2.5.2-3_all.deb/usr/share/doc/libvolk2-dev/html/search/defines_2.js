var searchData=
[
  ['b_0',['B',['../volk__32f__expfast__32f_8h.html#a111da81ae5883147168bbb8366377b10',1,'volk_32f_expfast_32f.h']]],
  ['bit128_5fp_1',['bit128_p',['../volk__common_8h.html#a05c2a3d4b16c94986318506664101312',1,'volk_common.h']]],
  ['bit256_5fp_2',['bit256_p',['../volk__common_8h.html#a7cdc0e3f19d458685a019855ef475508',1,'volk_common.h']]]
];
