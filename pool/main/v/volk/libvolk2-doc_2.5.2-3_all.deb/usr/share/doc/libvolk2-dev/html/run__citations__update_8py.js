var run__citations__update_8py =
[
    [ "find_citation_file", "run__citations__update_8py.html#a5c4b0843086fcc5b0f6be7288b35d961", null ],
    [ "fix_known_names", "run__citations__update_8py.html#a95251b98c5e38878503719ba1d997e56", null ],
    [ "load_citation_file", "run__citations__update_8py.html#af35b306ea0ace8a683121038c72f2ee3", null ],
    [ "main", "run__citations__update_8py.html#ad0623f54ae6e2f250168f46aeb6c6fa1", null ],
    [ "merge_names", "run__citations__update_8py.html#a083f258ecf2212f3472f9815a583ab34", null ],
    [ "normalize_names", "run__citations__update_8py.html#aea3cfd9b1a9546be9452e1af628165bd", null ],
    [ "parse_contributors", "run__citations__update_8py.html#a876658a59e89f3c789e7ec45fc80f0a2", null ],
    [ "parse_name", "run__citations__update_8py.html#adb4286caf8df5681a15d2020cde6daeb", null ],
    [ "update_citation_file", "run__citations__update_8py.html#a989f130bfad4ca055a6f271408ee3ad7", null ],
    [ "name_aliases", "run__citations__update_8py.html#a5952aa35761b3c453e7f736f8d9a8358", null ]
];