var searchData=
[
  ['terms_0',['TERMS',['../volk__32f__atan__32f_8h.html#a51bb25ad979da93f37683b2bee04d1bb',1,'volk_32f_atan_32f.h']]]
];
