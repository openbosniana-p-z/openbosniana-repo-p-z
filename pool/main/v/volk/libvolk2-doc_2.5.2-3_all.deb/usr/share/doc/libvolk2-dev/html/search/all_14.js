var searchData=
[
  ['uniform_0',['uniform',['../qa__utils_8h.html#aa6795d41afd69c1bb67ce644cf8a3dc6',1,'qa_utils.h']]],
  ['units_1',['units',['../classvolk__test__time__t.html#abfd64f48acc1790df4b3c6f8915ed25f',1,'volk_test_time_t']]],
  ['update_5fcitation_5ffile_2',['update_citation_file',['../namespacerun__citations__update.html#a989f130bfad4ca055a6f271408ee3ad7',1,'run_citations_update']]],
  ['update_5fsquare_5fsum_5f1_5fval_3',['update_square_sum_1_val',['../volk__32f__stddev__and__mean__32f__x2_8h.html#af118bfea807642e95b88667b1cb55fa4',1,'volk_32f_stddev_and_mean_32f_x2.h']]],
  ['using_20volk_4',['Using VOLK',['../using_volk.html',1,'']]],
  ['using_5fvolk_2edox_5',['using_volk.dox',['../using__volk_8dox.html',1,'']]]
];
