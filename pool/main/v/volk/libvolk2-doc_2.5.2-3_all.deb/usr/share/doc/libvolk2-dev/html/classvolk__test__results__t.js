var classvolk__test__results__t =
[
    [ "best_arch_a", "classvolk__test__results__t.html#a56a4db2090be7b25e8ee972e4a29c560", null ],
    [ "best_arch_u", "classvolk__test__results__t.html#ac0e1308a8db59bf4efb3ef51aef5e15d", null ],
    [ "config_name", "classvolk__test__results__t.html#a10c46a09b4474541b9a968f43a16f435", null ],
    [ "iter", "classvolk__test__results__t.html#a15cf2084d51541021c7be7915780265f", null ],
    [ "name", "classvolk__test__results__t.html#a02707d489f87b90baa0d01db16172da1", null ],
    [ "results", "classvolk__test__results__t.html#a34aef184cee76a03da922ec6a9620d0e", null ],
    [ "vlen", "classvolk__test__results__t.html#ae60746ce3e88000183a80d1ecbe13cf3", null ]
];