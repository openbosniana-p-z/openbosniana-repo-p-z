var constants_8h =
[
    [ "volk_available_machines", "constants_8h.html#aee7bc5d81b1a2c1b9a8af9add9fc3d5f", null ],
    [ "volk_c_compiler", "constants_8h.html#aeace7cd681cdfe56dab15a8ac94682bb", null ],
    [ "volk_compiler_flags", "constants_8h.html#a864c4ea927548f901a5745cd2d4b4c28", null ],
    [ "volk_prefix", "constants_8h.html#a3a145062a0183d725becd5fee554a389", null ],
    [ "volk_version", "constants_8h.html#ab3c4b8c415ed1c26369a1d318552467c", null ]
];