var searchData=
[
  ['_5fmm_5fhint_5fenta_0',['_MM_HINT_ENTA',['../sse2neon_8h.html#ae37750a247f50b9b627909311b8af6b0acb8fef15a7aa8d11163d609f526c6b4a',1,'sse2neon.h']]],
  ['_5fmm_5fhint_5fet0_1',['_MM_HINT_ET0',['../sse2neon_8h.html#ae37750a247f50b9b627909311b8af6b0a7cdbb8a6b11f1b50fa99803895a767ab',1,'sse2neon.h']]],
  ['_5fmm_5fhint_5fet1_2',['_MM_HINT_ET1',['../sse2neon_8h.html#ae37750a247f50b9b627909311b8af6b0a9e5b1be0c221ff1dccc6fb2a100ed1ba',1,'sse2neon.h']]],
  ['_5fmm_5fhint_5fet2_3',['_MM_HINT_ET2',['../sse2neon_8h.html#ae37750a247f50b9b627909311b8af6b0aa1518a0980c3a7d5b381cd91e2634fea',1,'sse2neon.h']]],
  ['_5fmm_5fhint_5fnta_4',['_MM_HINT_NTA',['../sse2neon_8h.html#ae37750a247f50b9b627909311b8af6b0afea64c5623a3777a2fde83f7e3c7f488',1,'sse2neon.h']]],
  ['_5fmm_5fhint_5ft0_5',['_MM_HINT_T0',['../sse2neon_8h.html#ae37750a247f50b9b627909311b8af6b0a678f28344cbd365be7acb16f0656ec8b',1,'sse2neon.h']]],
  ['_5fmm_5fhint_5ft1_6',['_MM_HINT_T1',['../sse2neon_8h.html#ae37750a247f50b9b627909311b8af6b0a2fb7e60f1696f6cc6200e9b6540ccb88',1,'sse2neon.h']]],
  ['_5fmm_5fhint_5ft2_7',['_MM_HINT_T2',['../sse2neon_8h.html#ae37750a247f50b9b627909311b8af6b0adbaef209e1d680737f0162c3ad64fd7e',1,'sse2neon.h']]]
];
