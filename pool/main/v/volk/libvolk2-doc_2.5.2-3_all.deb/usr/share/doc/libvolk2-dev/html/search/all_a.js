var searchData=
[
  ['kernel_5fclass_0',['kernel_class',['../classvolk__kernel__defs_1_1kernel__class.html',1,'volk_kernel_defs']]],
  ['kernel_5ffiles_1',['kernel_files',['../namespacevolk__kernel__defs.html#a8908c9febdbc1485c801a75b2bbf36b6',1,'volk_kernel_defs']]],
  ['kernel_5fptr_2',['kernel_ptr',['../classvolk__test__case__t.html#a26f0f4cffebd0c84712e6a242b40ce0b',1,'volk_test_case_t']]],
  ['kernel_5fregex_3',['kernel_regex',['../classvolk__test__params__t.html#a5f3cbf11b30fe959f139745bdfdb3934',1,'volk_test_params_t']]],
  ['kernel_5ftests_2eh_4',['kernel_tests.h',['../kernel__tests_8h.html',1,'']]],
  ['kernels_5',['kernels',['../namespacevolk__kernel__defs.html#a889a1a72cd5bb4e403a67dfed3913928',1,'volk_kernel_defs']]],
  ['kernels_6',['Kernels',['../kernels.html',1,'']]],
  ['kernels_2edox_7',['kernels.dox',['../kernels_8dox.html',1,'']]],
  ['key_5fval_5fsub_8',['key_val_sub',['../classvolk__modtool_1_1cfg_1_1volk__modtool__config.html#aa725981496084fd240c53ff1d44f9186',1,'volk_modtool::cfg::volk_modtool_config']]],
  ['kwargs_9',['kwargs',['../namespacevolk__arch__defs.html#ad0d6254acf898f485b7b6f79b99c727b',1,'volk_arch_defs.kwargs()'],['../namespacevolk__machine__defs.html#adfac546264145eaca21c953a84d586ac',1,'volk_machine_defs.kwargs()']]]
];
