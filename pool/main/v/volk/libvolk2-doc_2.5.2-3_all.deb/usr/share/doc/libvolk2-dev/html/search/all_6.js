var searchData=
[
  ['f_0',['f',['../unionbit128.html#a1468059a8bd56945348b61f89a938f69',1,'bit128::f()'],['../unionbit256.html#a108257d1f41befb5bf3118a2255f6c19',1,'bit256::f()']]],
  ['fcompare_1',['fcompare',['../qa__utils_8cc.html#a779a84ccc7570de879149dc0ffc5186b',1,'qa_utils.cc']]],
  ['find_5fcitation_5ffile_2',['find_citation_file',['../namespacerun__citations__update.html#a5c4b0843086fcc5b0f6be7288b35d961',1,'run_citations_update']]],
  ['fix_5fknown_5fnames_3',['fix_known_names',['../namespacerun__citations__update.html#a95251b98c5e38878503719ba1d997e56',1,'run_citations_update']]],
  ['flags_4',['flags',['../namespacevolk__arch__defs.html#a496daf51a50daca544bcecdc1b57d87c',1,'volk_arch_defs']]],
  ['flatten_5fsection_5ftext_5',['flatten_section_text',['../namespacevolk__kernel__defs.html#a29461610fe96acb868dcc54e3a9905b5',1,'volk_kernel_defs']]],
  ['float_5fvec_6',['float_vec',['../unionbit128.html#ac5e44fa66bbb137f04aeb58695593627',1,'bit128::float_vec()'],['../unionbit256.html#ad1e802e8bb4b540df7032aac7190af1d',1,'bit256::float_vec()']]],
  ['force_5finline_7',['FORCE_INLINE',['../sse2neon_8h.html#ac032d233a8ebfcd82fd49d0824eefb18',1,'sse2neon.h']]],
  ['fpcr_5fbitfield_8',['fpcr_bitfield',['../structfpcr__bitfield.html',1,'']]]
];
