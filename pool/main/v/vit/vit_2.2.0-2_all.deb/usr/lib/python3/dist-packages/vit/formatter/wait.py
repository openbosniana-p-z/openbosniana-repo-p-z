from vit.formatter import DateTime

class Wait(DateTime):
    pass
