from vit.formatter.description import Description

class DescriptionCombined(Description):
    pass
