from vit.formatter.tags import Tags

class TagsList(Tags):
    pass
