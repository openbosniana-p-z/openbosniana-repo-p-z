from vit.formatter.until import Until

class UntilFormatted(Until):
    pass
