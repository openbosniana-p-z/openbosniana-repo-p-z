from vit.formatter import DateTime

class Modified(DateTime):
    pass
