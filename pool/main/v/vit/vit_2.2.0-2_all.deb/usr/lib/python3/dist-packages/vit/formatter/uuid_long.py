from vit.formatter.uuid import Uuid

class UuidLong(Uuid):
    pass
