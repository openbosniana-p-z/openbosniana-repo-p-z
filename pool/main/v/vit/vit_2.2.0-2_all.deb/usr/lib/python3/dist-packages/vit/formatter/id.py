from vit.formatter import Number

class Id(Number):
    pass
