from vit.formatter.status import Status

class StatusLong(Status):
    pass
