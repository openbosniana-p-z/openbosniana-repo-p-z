from vit.formatter.id import Id

class IdNumber(Id):
    pass
