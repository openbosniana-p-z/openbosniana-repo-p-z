from vit.formatter.parent import Parent

class ParentLong(Parent):
    pass
