from vit.formatter.entry import Entry

class EntryFormatted(Entry):
    pass
