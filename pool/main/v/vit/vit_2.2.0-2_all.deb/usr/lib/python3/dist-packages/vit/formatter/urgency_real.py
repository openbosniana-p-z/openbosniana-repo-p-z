from vit.formatter.urgency import Urgency

class UrgencyReal(Urgency):
    pass
