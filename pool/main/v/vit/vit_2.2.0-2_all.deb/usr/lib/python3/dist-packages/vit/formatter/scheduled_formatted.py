from vit.formatter.scheduled import Scheduled

class ScheduledFormatted(Scheduled):
    pass
