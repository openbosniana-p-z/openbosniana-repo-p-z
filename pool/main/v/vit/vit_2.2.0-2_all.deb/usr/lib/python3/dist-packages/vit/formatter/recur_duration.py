from vit.formatter.recur import Recur

class RecurDuration(Recur):
    pass
