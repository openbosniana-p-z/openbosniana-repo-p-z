import os

user = os.environ.copy()
