from vit.formatter import DateTime

class Entry(DateTime):
    pass
