from vit.formatter.project import Project

class ProjectFull(Project):
    pass
