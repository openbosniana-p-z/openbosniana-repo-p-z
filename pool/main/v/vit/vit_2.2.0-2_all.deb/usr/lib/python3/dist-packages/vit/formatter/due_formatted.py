from vit.formatter.due import Due

class DueFormatted(Due):
    pass
