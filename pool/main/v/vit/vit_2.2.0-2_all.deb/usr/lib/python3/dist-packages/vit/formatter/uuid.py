from vit.formatter import String

class Uuid(String):
    pass
