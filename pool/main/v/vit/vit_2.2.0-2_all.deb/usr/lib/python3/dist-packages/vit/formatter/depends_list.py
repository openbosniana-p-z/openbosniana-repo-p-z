from vit.formatter.depends import Depends

class DependsList(Depends):
    pass
