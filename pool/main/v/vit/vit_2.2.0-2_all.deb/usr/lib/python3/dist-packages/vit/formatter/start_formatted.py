from vit.formatter.start import Start

class StartFormatted(Start):
    pass
