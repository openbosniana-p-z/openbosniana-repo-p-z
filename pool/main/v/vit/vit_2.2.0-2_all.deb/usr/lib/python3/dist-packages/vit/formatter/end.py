from vit.formatter import DateTime

class End(DateTime):
    pass
