#ifndef QSORTDEF_H
#define QSORTDEF_H

void qsortUint(Uint *l, Uint *r);
void qsortThreeUintwrtuint2(ThreeUint *l, ThreeUint *r);
void qsortPairUintwrtuint0(PairUint *l, PairUint *r);

#endif
