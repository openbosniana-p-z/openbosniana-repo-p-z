#ifndef GENERICQUEUEDEF_H
#define GENERICQUEUEDEF_H

#include "types.h"

typedef Sint (*GenericQueueprocessor)(void *elem,void *info);

#endif
