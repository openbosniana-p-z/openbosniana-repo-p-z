#ifndef PATH_MAX
# define PATH_MAX 8192
#endif
