#ifndef PROGRAMVERSION_H
#define PROGRAMVERSION_H
#include <stdio.h>

void showprogramversion(FILE *fp,char *program);

#endif
