#ifndef GENERICQUEUE_IF_H
#define GENERICQUEUE_IF_H

typedef struct _Genericqueue Genericqueue;

#endif
