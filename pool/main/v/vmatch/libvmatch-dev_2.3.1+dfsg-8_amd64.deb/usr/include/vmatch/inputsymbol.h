#ifndef INPUTSYMBOL_H
#define INPUTSYMBOL_H

/*
  The following defines the separator symbol for fasta files.
*/

#define FASTASEPARATOR '>'

/*
  The following defines the newline symbol. 
*/

#define NEWLINESYMBOL  '\n'

#endif
