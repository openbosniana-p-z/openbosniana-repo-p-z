#ifndef SEARCHDEF_H
#define SEARCHDEF_H

typedef enum
{
  preorder,
  postorder,
  endorder,
  leaf
} VISIT;

#endif
