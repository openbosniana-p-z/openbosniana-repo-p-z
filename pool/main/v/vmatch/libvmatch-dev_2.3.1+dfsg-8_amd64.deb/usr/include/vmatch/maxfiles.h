//\IgnoreLatex{

#ifndef MAXFILES_H
#define MAXFILES_H

//}

/*
  The maximal number of files allowed when constructing or
  using virtual suffix trees.
*/

#define MAXNUMBEROFFILES     256

//\IgnoreLatex{

#endif

//}
