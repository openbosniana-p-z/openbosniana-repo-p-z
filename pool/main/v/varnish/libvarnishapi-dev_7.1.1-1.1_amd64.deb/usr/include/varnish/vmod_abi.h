/*
 * NB:  This file is machine generated, DO NOT EDIT!
 *
 * Edit and run include/generate.py instead.
 */

#define VMOD_ABI_Version "Varnish 7.1.1 7cee1c581bead20e88d101ab3d72afb29f14d87a"
