/*
 * NB:  This file is machine generated, DO NOT EDIT!
 *
 * Edit and run lib/libvcc/generate.py instead.
 */

/*lint -save -e525 -e539 */

VRTSTVVAR(free_space,	BYTES,	int64_t,	0.)
VRTSTVVAR(used_space,	BYTES,	int64_t,	0.)
VRTSTVVAR(happy,	BOOL,	unsigned,	0)
#undef VRTSTVVAR

/*lint -restore */
