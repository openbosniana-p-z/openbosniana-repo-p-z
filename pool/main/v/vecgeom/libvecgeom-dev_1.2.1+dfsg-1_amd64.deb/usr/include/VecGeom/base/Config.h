/// \file Config.h
/// \author Ben Morgan (Ben.Morgan@warwick.ac.uk)

#ifndef VECGEOM_BASE_CONFIG_H_
#define VECGEOM_BASE_CONFIG_H_

// Scalar/Vector Backend (only one can be defined)
/* #undef VECGEOM_SCALAR */
#define VECGEOM_VC
/* #undef VECGEOM_SINGLE_PRECISION */
#ifdef VECGEOM_SINGLE_PRECISION
#define VECGEOM_FLOAT_PRECISION
#endif

// Other symbols that are added to VECGEOM_DEFINITIONS, and their activation rule

// CUDA Settings
// When CUDA is ON
/* #undef VECGEOM_ENABLE_CUDA */
// When CUDA_VOLUME_SPECIALIZATION) is ON (NB: the _NO_ version must be defined otherwise)
/* #undef VECGEOM_CUDA_VOLUME_SPECIALIZATION */
#ifndef VECGEOM_CUDA_VOLUME_SPECIALIZATION
#define VECGEOM_CUDA_NO_VOLUME_SPECIALIZATION
#endif

// When QUADRILATERAL_ACCELERATION is ON (Maybe a VC dependence as well?)
// Also, *seems* to only affect template functions in headers, so maybe choice is deferred?
#define VECGEOM_QUADRILATERAL_ACCELERATION
#ifdef VECGEOM_QUADRILATERAL_ACCELERATION
#define VECGEOM_QUADRILATERALS_VC
#endif

// When NO_SPECIALIZATION is ON
// Pretty clear this affects API and ABI
#define VECGEOM_NO_SPECIALIZATION

// Both of the following are API and ABI
// Nb: for volume conversion part, *might* be possible to isolate in separate library?
// When ROOT is ON
/* #undef VECGEOM_ROOT */

// When Geant4 is ON
/* #undef VECGEOM_GEANT4 */

// When EMBREE is ON
// API/ABI, though relatively localized to VecGeom/volumes/TessellatedStruct.h
#define VECGEOM_EMBREE

// Volume related...
// When INPLACE_TRANSFORMATIONS is ON
#define VECGEOM_INPLACE_TRANSFORMATIONS

// Defined when PLANESHELL is OFF
#define VECGEOM_PLANESHELL
#ifndef VECGEOM_PLANESHELL
#define VECGEOM_PLANESHELL_DISABLE
#endif

// Navigation related...
// When USE_CACHED_TRANSFORMATIONS is ON
/* #undef VECGEOM_USE_CACHED_TRANSFORMATIONS */
#ifdef VECGEOM_USE_CACHED_TRANSFORMATIONS 
#define VECGEOM_CACHED_TRANS
#endif

// When USE_INDEXEDNAVSTATES is ON
#define VECGEOM_USE_INDEXEDNAVSTATES

// When USE_NAVINDEX is ON
/* #undef VECGEOM_USE_NAVINDEX */

// Testing, debugging, profiling...
// When DISTANCE_DEBUG is ON
/* #undef VECGEOM_DISTANCE_DEBUG */

// When BENCHMARK is ON (NB: Not clear it's used at all in code)
/* #undef VECGEOM_TEST_BENCHMARK */

// When VTUNE is ON
/* #undef VECGEOM_TEST_VTUNE */

// When GDML id ON
#define VECGEOM_GDML

#endif
