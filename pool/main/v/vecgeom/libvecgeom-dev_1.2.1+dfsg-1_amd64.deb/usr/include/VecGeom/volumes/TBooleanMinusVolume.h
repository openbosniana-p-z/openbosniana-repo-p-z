/*
 * TBooleanMinusVolume.h
 *
 *  Created on: Aug 20, 2014
 *      Author: swenzel
 */

#ifndef TBOOLEANMINUSVOLUME_H_
#define TBOOLEANMINUSVOLUME_H_

#include "VecGeom/base/Global.h"
#include "VecGeom/volumes/TPlacedBooleanMinusVolume.h"
#include "VecGeom/volumes/TSpecializedBooleanMinusVolume.h"
#include "VecGeom/volumes/TUnplacedBooleanMinusVolume.h"

#endif /* TBOOLEANMINUSVOLUME_H_ */
