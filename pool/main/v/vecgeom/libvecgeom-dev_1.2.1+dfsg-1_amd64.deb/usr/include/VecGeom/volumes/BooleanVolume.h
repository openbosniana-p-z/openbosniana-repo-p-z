#ifndef BOOLEANVOLUME_H_
#define BOOLEANVOLUME_H_

#include "VecGeom/base/Global.h"
#include "VecGeom/volumes/PlacedBooleanVolume.h"
#include "VecGeom/volumes/SpecializedBooleanVolume.h"
#include "VecGeom/volumes/UnplacedBooleanVolume.h"

#endif /* BOOLEANVOLUME_H_ */
