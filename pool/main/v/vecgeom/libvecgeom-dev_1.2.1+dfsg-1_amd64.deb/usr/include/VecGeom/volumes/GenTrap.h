/*
 * GenTrap.h
 *
 *  Created on: Aug 3, 2014
 *      Author: swenzel
 */

#ifndef VECGEOM_VOLUMES_GENTRAP_H_
#define VECGEOM_VOLUMES_GENTRAP_H_

#include "VecGeom/base/Global.h"
#include "VecGeom/volumes/PlacedGenTrap.h"
#include "VecGeom/volumes/SpecializedGenTrap.h"
#include "VecGeom/volumes/UnplacedGenTrap.h"

#endif /* GENTRAP_H_ */
