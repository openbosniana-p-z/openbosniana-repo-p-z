module Vagrant
  module LXC
    VERSION = "1.4.3"
  end
end
