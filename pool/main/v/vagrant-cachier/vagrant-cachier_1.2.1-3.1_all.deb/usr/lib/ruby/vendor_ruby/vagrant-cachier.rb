require 'vagrant'

require "vagrant-cachier/version"
require "vagrant-cachier/plugin"
