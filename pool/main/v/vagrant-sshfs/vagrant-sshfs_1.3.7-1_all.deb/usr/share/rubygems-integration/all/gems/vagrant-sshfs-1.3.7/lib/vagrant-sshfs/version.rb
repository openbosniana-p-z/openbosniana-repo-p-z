module VagrantPlugins
  module SyncedFolderSSHFS
    VERSION = "1.3.7"
  end
end
