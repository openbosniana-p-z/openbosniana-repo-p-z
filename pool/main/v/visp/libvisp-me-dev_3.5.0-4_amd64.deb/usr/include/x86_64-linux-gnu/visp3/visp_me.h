/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __visp_me_h_
#define __visp_me_h_

#include <visp3/visp_core.h>
#include <visp3/me/vpMe.h>
#include <visp3/me/vpMeEllipse.h>
#include <visp3/me/vpMeLine.h>
#include <visp3/me/vpMeNurbs.h>
#include <visp3/me/vpMeSite.h>
#include <visp3/me/vpMeTracker.h>
#include <visp3/me/vpNurbs.h>

#endif

