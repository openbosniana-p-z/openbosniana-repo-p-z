/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __visp_gui_h_
#define __visp_gui_h_

#include <visp3/visp_core.h>
#include <visp3/gui/vpD3DRenderer.h>
#include <visp3/gui/vpDisplayD3D.h>
#include <visp3/gui/vpDisplayGDI.h>
#include <visp3/gui/vpDisplayGTK.h>
#include <visp3/gui/vpDisplayOpenCV.h>
#include <visp3/gui/vpDisplayWin32.h>
#include <visp3/gui/vpDisplayX.h>
#include <visp3/gui/vpGDIRenderer.h>
#include <visp3/gui/vpPlot.h>
#include <visp3/gui/vpPlotCurve.h>
#include <visp3/gui/vpPlotGraph.h>
#include <visp3/gui/vpProjectionDisplay.h>
#include <visp3/gui/vpWin32API.h>
#include <visp3/gui/vpWin32Renderer.h>
#include <visp3/gui/vpWin32Window.h>

#endif

