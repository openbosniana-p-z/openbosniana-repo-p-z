/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __visp_io_h_
#define __visp_io_h_

#include <visp3/visp_core.h>
#include <visp3/io/vpDiskGrabber.h>
#include <visp3/io/vpImageIo.h>
#include <visp3/io/vpImageQueue.h>
#include <visp3/io/vpImageStorageWorker.h>
#include <visp3/io/vpKeyboard.h>
#include <visp3/io/vpParallelPort.h>
#include <visp3/io/vpParallelPortException.h>
#include <visp3/io/vpParseArgv.h>
#include <visp3/io/vpVideoReader.h>
#include <visp3/io/vpVideoWriter.h>

#endif

