/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __visp_imgproc_h_
#define __visp_imgproc_h_

#include <visp3/visp_core.h>
#include <visp3/imgproc/vpContours.h>
#include <visp3/imgproc/vpImgproc.h>

#endif

