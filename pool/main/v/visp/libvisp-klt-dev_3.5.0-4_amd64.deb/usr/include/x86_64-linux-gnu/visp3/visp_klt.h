/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __visp_klt_h_
#define __visp_klt_h_

#include <visp3/visp_core.h>
#include <visp3/klt/vpKltOpencv.h>

#endif

