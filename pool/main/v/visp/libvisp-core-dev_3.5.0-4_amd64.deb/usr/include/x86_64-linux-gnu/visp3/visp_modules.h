/*
 *      ** File generated automatically, do not modify **
 *
 * This file defines the list of modules available in current build configuration
 *
 */

#ifndef _visp_modules_h_
#define _visp_modules_h_

#define VISP_HAVE_MODULE_AR
#define VISP_HAVE_MODULE_BLOB
#define VISP_HAVE_MODULE_CORE
#define VISP_HAVE_MODULE_DETECTION
#define VISP_HAVE_MODULE_GUI
#define VISP_HAVE_MODULE_IMGPROC
#define VISP_HAVE_MODULE_IO
#define VISP_HAVE_MODULE_KLT
#define VISP_HAVE_MODULE_MBT
#define VISP_HAVE_MODULE_ME
#define VISP_HAVE_MODULE_ROBOT
#define VISP_HAVE_MODULE_SENSOR
#define VISP_HAVE_MODULE_TT
#define VISP_HAVE_MODULE_TT_MI
#define VISP_HAVE_MODULE_VISION
#define VISP_HAVE_MODULE_VISUAL_FEATURES
#define VISP_HAVE_MODULE_VS

#endif

