/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __visp_detection_h_
#define __visp_detection_h_

#include <visp3/visp_core.h>
#include <visp3/visp_vision.h>
#include <visp3/detection/vpDetectorAprilTag.h>
#include <visp3/detection/vpDetectorBase.h>
#include <visp3/detection/vpDetectorDNN.h>
#include <visp3/detection/vpDetectorDataMatrixCode.h>
#include <visp3/detection/vpDetectorFace.h>
#include <visp3/detection/vpDetectorQRCode.h>

#endif

