/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMeEllipse_gen_h_
#define __vpMeEllipse_gen_h_

#include <visp3/me/vpMeEllipse.h>

#endif

