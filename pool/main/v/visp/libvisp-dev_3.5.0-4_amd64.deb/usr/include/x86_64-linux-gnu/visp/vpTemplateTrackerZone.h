/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTemplateTrackerZone_gen_h_
#define __vpTemplateTrackerZone_gen_h_

#include <visp3/tt/vpTemplateTrackerZone.h>

#endif

