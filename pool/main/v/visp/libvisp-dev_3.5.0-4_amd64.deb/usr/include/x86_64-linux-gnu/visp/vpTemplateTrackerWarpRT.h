/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTemplateTrackerWarpRT_gen_h_
#define __vpTemplateTrackerWarpRT_gen_h_

#include <visp3/tt/vpTemplateTrackerWarpRT.h>

#endif

