/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpFeaturePoint3D_gen_h_
#define __vpFeaturePoint3D_gen_h_

#include <visp3/visual_features/vpFeaturePoint3D.h>

#endif

