/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMbtFaceDepthNormal_gen_h_
#define __vpMbtFaceDepthNormal_gen_h_

#include <visp3/mbt/vpMbtFaceDepthNormal.h>

#endif

