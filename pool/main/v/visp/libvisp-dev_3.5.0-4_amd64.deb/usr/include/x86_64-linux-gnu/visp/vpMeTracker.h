/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMeTracker_gen_h_
#define __vpMeTracker_gen_h_

#include <visp3/me/vpMeTracker.h>

#endif

