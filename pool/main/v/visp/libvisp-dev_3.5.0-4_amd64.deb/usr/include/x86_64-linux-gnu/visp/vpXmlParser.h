/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpXmlParser_gen_h_
#define __vpXmlParser_gen_h_

#include <visp3/core/vpXmlParser.h>

#endif

