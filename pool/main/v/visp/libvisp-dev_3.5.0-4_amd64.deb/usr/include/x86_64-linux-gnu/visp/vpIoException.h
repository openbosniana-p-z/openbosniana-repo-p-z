/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpIoException_gen_h_
#define __vpIoException_gen_h_

#include <visp3/core/vpIoException.h>

#endif

