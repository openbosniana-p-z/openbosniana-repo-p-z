/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpReflexTakktile2_gen_h_
#define __vpReflexTakktile2_gen_h_

#include <visp3/robot/vpReflexTakktile2.h>

#endif

