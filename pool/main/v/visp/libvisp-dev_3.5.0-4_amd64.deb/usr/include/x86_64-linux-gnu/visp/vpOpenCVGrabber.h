/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpOpenCVGrabber_gen_h_
#define __vpOpenCVGrabber_gen_h_

#include <visp3/sensor/vpOpenCVGrabber.h>

#endif

