/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpImageSimulator_gen_h_
#define __vpImageSimulator_gen_h_

#include <visp3/robot/vpImageSimulator.h>

#endif

