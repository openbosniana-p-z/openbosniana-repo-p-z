/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpLevenbergMarquartd_gen_h_
#define __vpLevenbergMarquartd_gen_h_

#include <visp3/vision/vpLevenbergMarquartd.h>

#endif

