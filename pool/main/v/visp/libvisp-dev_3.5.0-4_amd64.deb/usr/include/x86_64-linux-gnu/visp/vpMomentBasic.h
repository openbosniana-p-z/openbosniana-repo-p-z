/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMomentBasic_gen_h_
#define __vpMomentBasic_gen_h_

#include <visp3/core/vpMomentBasic.h>

#endif

