/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRobotKinova_gen_h_
#define __vpRobotKinova_gen_h_

#include <visp3/robot/vpRobotKinova.h>

#endif

