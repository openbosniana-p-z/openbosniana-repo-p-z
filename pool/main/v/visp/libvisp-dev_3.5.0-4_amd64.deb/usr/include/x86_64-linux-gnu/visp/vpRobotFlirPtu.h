/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRobotFlirPtu_gen_h_
#define __vpRobotFlirPtu_gen_h_

#include <visp3/robot/vpRobotFlirPtu.h>

#endif

