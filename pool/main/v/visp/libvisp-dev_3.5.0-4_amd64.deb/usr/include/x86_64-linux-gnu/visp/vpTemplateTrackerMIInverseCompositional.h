/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTemplateTrackerMIInverseCompositional_gen_h_
#define __vpTemplateTrackerMIInverseCompositional_gen_h_

#include <visp3/tt_mi/vpTemplateTrackerMIInverseCompositional.h>

#endif

