/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpGenericFeature_gen_h_
#define __vpGenericFeature_gen_h_

#include <visp3/visual_features/vpGenericFeature.h>

#endif

