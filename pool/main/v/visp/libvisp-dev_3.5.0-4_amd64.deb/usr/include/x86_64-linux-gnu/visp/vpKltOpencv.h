/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpKltOpencv_gen_h_
#define __vpKltOpencv_gen_h_

#include <visp3/klt/vpKltOpencv.h>

#endif

