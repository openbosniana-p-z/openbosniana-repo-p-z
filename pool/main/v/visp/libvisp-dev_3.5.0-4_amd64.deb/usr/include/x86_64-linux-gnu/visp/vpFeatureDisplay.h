/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpFeatureDisplay_gen_h_
#define __vpFeatureDisplay_gen_h_

#include <visp3/core/vpFeatureDisplay.h>

#endif

