/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpKeyPoint_gen_h_
#define __vpKeyPoint_gen_h_

#include <visp3/vision/vpKeyPoint.h>

#endif

