/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpExponentialMap_gen_h_
#define __vpExponentialMap_gen_h_

#include <visp3/core/vpExponentialMap.h>

#endif

