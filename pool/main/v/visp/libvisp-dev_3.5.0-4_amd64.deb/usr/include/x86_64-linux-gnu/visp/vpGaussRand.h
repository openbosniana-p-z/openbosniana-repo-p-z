/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpGaussRand_gen_h_
#define __vpGaussRand_gen_h_

#include <visp3/core/vpGaussRand.h>

#endif

