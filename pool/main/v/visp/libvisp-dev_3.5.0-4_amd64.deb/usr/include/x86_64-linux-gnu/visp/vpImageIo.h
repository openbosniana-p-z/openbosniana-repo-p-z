/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpImageIo_gen_h_
#define __vpImageIo_gen_h_

#include <visp3/io/vpImageIo.h>

#endif

