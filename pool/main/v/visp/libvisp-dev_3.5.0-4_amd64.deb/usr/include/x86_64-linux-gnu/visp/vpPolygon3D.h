/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpPolygon3D_gen_h_
#define __vpPolygon3D_gen_h_

#include <visp3/core/vpPolygon3D.h>

#endif

