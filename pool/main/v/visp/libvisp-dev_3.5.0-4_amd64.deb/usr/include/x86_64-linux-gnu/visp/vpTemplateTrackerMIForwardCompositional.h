/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTemplateTrackerMIForwardCompositional_gen_h_
#define __vpTemplateTrackerMIForwardCompositional_gen_h_

#include <visp3/tt_mi/vpTemplateTrackerMIForwardCompositional.h>

#endif

