/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpFeatureDepth_gen_h_
#define __vpFeatureDepth_gen_h_

#include <visp3/visual_features/vpFeatureDepth.h>

#endif

