/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRobotBiclops_gen_h_
#define __vpRobotBiclops_gen_h_

#include <visp3/robot/vpRobotBiclops.h>

#endif

