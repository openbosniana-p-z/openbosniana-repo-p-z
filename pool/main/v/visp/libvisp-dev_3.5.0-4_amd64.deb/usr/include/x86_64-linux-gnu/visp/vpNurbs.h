/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpNurbs_gen_h_
#define __vpNurbs_gen_h_

#include <visp3/me/vpNurbs.h>

#endif

