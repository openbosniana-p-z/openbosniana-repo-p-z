/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpKeyboard_gen_h_
#define __vpKeyboard_gen_h_

#include <visp3/io/vpKeyboard.h>

#endif

