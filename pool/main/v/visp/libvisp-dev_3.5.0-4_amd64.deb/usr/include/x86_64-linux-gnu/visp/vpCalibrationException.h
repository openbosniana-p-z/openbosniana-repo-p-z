/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpCalibrationException_gen_h_
#define __vpCalibrationException_gen_h_

#include <visp3/vision/vpCalibrationException.h>

#endif

