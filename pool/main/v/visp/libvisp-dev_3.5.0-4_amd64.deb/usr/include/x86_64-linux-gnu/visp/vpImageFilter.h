/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpImageFilter_gen_h_
#define __vpImageFilter_gen_h_

#include <visp3/core/vpImageFilter.h>

#endif

