/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpDetectorFace_gen_h_
#define __vpDetectorFace_gen_h_

#include <visp3/detection/vpDetectorFace.h>

#endif

