/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTranslationVector_gen_h_
#define __vpTranslationVector_gen_h_

#include <visp3/core/vpTranslationVector.h>

#endif

