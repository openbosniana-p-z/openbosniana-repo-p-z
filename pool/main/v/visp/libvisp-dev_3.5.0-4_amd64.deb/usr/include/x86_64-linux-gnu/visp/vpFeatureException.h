/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpFeatureException_gen_h_
#define __vpFeatureException_gen_h_

#include <visp3/visual_features/vpFeatureException.h>

#endif

