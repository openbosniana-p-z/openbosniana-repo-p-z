/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMeterPixelConversion_gen_h_
#define __vpMeterPixelConversion_gen_h_

#include <visp3/core/vpMeterPixelConversion.h>

#endif

