/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpDetectorDataMatrixCode_gen_h_
#define __vpDetectorDataMatrixCode_gen_h_

#include <visp3/detection/vpDetectorDataMatrixCode.h>

#endif

