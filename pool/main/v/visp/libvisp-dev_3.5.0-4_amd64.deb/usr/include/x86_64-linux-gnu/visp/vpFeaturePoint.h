/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpFeaturePoint_gen_h_
#define __vpFeaturePoint_gen_h_

#include <visp3/visual_features/vpFeaturePoint.h>

#endif

