/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpSubColVector_gen_h_
#define __vpSubColVector_gen_h_

#include <visp3/core/vpSubColVector.h>

#endif

