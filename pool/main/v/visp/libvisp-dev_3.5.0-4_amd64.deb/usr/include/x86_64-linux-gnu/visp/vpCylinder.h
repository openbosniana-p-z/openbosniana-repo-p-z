/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpCylinder_gen_h_
#define __vpCylinder_gen_h_

#include <visp3/core/vpCylinder.h>

#endif

