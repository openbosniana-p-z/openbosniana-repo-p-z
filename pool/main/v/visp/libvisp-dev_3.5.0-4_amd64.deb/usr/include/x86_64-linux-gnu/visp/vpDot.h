/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpDot_gen_h_
#define __vpDot_gen_h_

#include <visp3/blob/vpDot.h>

#endif

