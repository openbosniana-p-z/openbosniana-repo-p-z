/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpD3DRenderer_gen_h_
#define __vpD3DRenderer_gen_h_

#include <visp3/gui/vpD3DRenderer.h>

#endif

