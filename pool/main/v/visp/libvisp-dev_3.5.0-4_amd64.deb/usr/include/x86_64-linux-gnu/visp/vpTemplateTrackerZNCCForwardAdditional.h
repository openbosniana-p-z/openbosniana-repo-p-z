/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTemplateTrackerZNCCForwardAdditional_gen_h_
#define __vpTemplateTrackerZNCCForwardAdditional_gen_h_

#include <visp3/tt/vpTemplateTrackerZNCCForwardAdditional.h>

#endif

