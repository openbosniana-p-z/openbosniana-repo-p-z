/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMeNurbs_gen_h_
#define __vpMeNurbs_gen_h_

#include <visp3/me/vpMeNurbs.h>

#endif

