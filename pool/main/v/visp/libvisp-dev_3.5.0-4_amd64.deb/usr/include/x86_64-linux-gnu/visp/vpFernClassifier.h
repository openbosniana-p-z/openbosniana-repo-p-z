/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpFernClassifier_gen_h_
#define __vpFernClassifier_gen_h_

#include <visp3/vision/vpFernClassifier.h>

#endif

