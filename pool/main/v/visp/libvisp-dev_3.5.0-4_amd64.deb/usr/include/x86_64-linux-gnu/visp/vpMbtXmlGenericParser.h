/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMbtXmlGenericParser_gen_h_
#define __vpMbtXmlGenericParser_gen_h_

#include <visp3/mbt/vpMbtXmlGenericParser.h>

#endif

