/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMomentCommon_gen_h_
#define __vpMomentCommon_gen_h_

#include <visp3/core/vpMomentCommon.h>

#endif

