/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpPioneerPan_gen_h_
#define __vpPioneerPan_gen_h_

#include <visp3/robot/vpPioneerPan.h>

#endif

