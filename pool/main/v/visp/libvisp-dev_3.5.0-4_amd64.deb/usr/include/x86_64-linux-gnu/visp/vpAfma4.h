/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpAfma4_gen_h_
#define __vpAfma4_gen_h_

#include <visp3/robot/vpAfma4.h>

#endif

