/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpFeatureSegment_gen_h_
#define __vpFeatureSegment_gen_h_

#include <visp3/visual_features/vpFeatureSegment.h>

#endif

