/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpColVector_gen_h_
#define __vpColVector_gen_h_

#include <visp3/core/vpColVector.h>

#endif

