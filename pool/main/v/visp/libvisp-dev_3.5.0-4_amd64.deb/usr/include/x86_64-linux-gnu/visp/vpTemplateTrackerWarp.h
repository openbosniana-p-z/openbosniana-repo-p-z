/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTemplateTrackerWarp_gen_h_
#define __vpTemplateTrackerWarp_gen_h_

#include <visp3/tt/vpTemplateTrackerWarp.h>

#endif

