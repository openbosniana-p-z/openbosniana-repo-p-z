/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpHistogramPeak_gen_h_
#define __vpHistogramPeak_gen_h_

#include <visp3/core/vpHistogramPeak.h>

#endif

