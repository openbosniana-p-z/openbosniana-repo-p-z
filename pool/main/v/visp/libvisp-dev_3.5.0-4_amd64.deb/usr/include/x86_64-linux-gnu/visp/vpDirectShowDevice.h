/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpDirectShowDevice_gen_h_
#define __vpDirectShowDevice_gen_h_

#include <visp3/sensor/vpDirectShowDevice.h>

#endif

