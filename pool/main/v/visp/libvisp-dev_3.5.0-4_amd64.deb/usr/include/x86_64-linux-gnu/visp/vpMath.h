/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMath_gen_h_
#define __vpMath_gen_h_

#include <visp3/core/vpMath.h>

#endif

