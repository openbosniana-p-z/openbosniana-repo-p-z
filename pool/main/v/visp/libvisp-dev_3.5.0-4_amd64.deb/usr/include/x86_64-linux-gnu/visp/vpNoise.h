/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpNoise_gen_h_
#define __vpNoise_gen_h_

#include <visp3/core/vpNoise.h>

#endif

