/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTriangle_gen_h_
#define __vpTriangle_gen_h_

#include <visp3/core/vpTriangle.h>

#endif

