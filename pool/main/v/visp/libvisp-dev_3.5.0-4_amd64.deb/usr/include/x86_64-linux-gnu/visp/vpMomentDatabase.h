/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMomentDatabase_gen_h_
#define __vpMomentDatabase_gen_h_

#include <visp3/core/vpMomentDatabase.h>

#endif

