/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpFeatureMomentCentered_gen_h_
#define __vpFeatureMomentCentered_gen_h_

#include <visp3/visual_features/vpFeatureMomentCentered.h>

#endif

