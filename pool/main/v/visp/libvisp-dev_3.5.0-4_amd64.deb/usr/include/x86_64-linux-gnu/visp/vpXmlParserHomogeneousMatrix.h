/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpXmlParserHomogeneousMatrix_gen_h_
#define __vpXmlParserHomogeneousMatrix_gen_h_

#include <visp3/core/vpXmlParserHomogeneousMatrix.h>

#endif

