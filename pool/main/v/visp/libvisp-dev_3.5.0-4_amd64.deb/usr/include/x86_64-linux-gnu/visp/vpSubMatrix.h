/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpSubMatrix_gen_h_
#define __vpSubMatrix_gen_h_

#include <visp3/core/vpSubMatrix.h>

#endif

