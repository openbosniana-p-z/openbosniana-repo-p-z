/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpViper_gen_h_
#define __vpViper_gen_h_

#include <visp3/robot/vpViper.h>

#endif

