/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpDirectShowSampleGrabberI_gen_h_
#define __vpDirectShowSampleGrabberI_gen_h_

#include <visp3/sensor/vpDirectShowSampleGrabberI.h>

#endif

