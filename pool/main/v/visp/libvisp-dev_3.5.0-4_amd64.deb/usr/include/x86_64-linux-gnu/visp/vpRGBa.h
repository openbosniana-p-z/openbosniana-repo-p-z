/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRGBa_gen_h_
#define __vpRGBa_gen_h_

#include <visp3/core/vpRGBa.h>

#endif

