/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpPlot_gen_h_
#define __vpPlot_gen_h_

#include <visp3/gui/vpPlot.h>

#endif

