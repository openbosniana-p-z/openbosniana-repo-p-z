/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMomentGravityCenter_gen_h_
#define __vpMomentGravityCenter_gen_h_

#include <visp3/core/vpMomentGravityCenter.h>

#endif

