/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpFeatureThetaU_gen_h_
#define __vpFeatureThetaU_gen_h_

#include <visp3/visual_features/vpFeatureThetaU.h>

#endif

