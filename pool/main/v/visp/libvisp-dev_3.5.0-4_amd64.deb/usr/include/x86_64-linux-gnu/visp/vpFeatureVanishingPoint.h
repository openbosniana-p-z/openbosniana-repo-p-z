/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpFeatureVanishingPoint_gen_h_
#define __vpFeatureVanishingPoint_gen_h_

#include <visp3/visual_features/vpFeatureVanishingPoint.h>

#endif

