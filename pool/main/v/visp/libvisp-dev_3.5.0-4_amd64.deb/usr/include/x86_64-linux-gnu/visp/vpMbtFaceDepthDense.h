/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMbtFaceDepthDense_gen_h_
#define __vpMbtFaceDepthDense_gen_h_

#include <visp3/mbt/vpMbtFaceDepthDense.h>

#endif

