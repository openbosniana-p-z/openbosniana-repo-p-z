/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpBSpline_gen_h_
#define __vpBSpline_gen_h_

#include <visp3/core/vpBSpline.h>

#endif

