/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTemplateTrackerWarpHomography_gen_h_
#define __vpTemplateTrackerWarpHomography_gen_h_

#include <visp3/tt/vpTemplateTrackerWarpHomography.h>

#endif

