/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpServolens_gen_h_
#define __vpServolens_gen_h_

#include <visp3/robot/vpServolens.h>

#endif

