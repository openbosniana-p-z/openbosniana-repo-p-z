/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpAdaptiveGain_gen_h_
#define __vpAdaptiveGain_gen_h_

#include <visp3/vs/vpAdaptiveGain.h>

#endif

