/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpParallelPortException_gen_h_
#define __vpParallelPortException_gen_h_

#include <visp3/io/vpParallelPortException.h>

#endif

