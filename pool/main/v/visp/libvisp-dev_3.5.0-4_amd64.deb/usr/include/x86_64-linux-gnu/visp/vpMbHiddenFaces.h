/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMbHiddenFaces_gen_h_
#define __vpMbHiddenFaces_gen_h_

#include <visp3/mbt/vpMbHiddenFaces.h>

#endif

