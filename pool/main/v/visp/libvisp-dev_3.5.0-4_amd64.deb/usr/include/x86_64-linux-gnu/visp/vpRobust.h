/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRobust_gen_h_
#define __vpRobust_gen_h_

#include <visp3/core/vpRobust.h>

#endif

