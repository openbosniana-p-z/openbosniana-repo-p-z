/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMbtDistanceCircle_gen_h_
#define __vpMbtDistanceCircle_gen_h_

#include <visp3/mbt/vpMbtDistanceCircle.h>

#endif

