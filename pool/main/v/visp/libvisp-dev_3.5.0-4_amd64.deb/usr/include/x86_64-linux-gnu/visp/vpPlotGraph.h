/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpPlotGraph_gen_h_
#define __vpPlotGraph_gen_h_

#include <visp3/gui/vpPlotGraph.h>

#endif

