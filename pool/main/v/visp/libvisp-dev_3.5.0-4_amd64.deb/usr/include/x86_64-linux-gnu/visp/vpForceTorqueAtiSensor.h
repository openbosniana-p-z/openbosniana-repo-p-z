/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpForceTorqueAtiSensor_gen_h_
#define __vpForceTorqueAtiSensor_gen_h_

#include <visp3/sensor/vpForceTorqueAtiSensor.h>

#endif

