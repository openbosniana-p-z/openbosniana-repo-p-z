/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRobotTemplate_gen_h_
#define __vpRobotTemplate_gen_h_

#include <visp3/robot/vpRobotTemplate.h>

#endif

