/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRobotAfma6_gen_h_
#define __vpRobotAfma6_gen_h_

#include <visp3/robot/vpRobotAfma6.h>

#endif

