/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTemplateTrackerWarpTranslation_gen_h_
#define __vpTemplateTrackerWarpTranslation_gen_h_

#include <visp3/tt/vpTemplateTrackerWarpTranslation.h>

#endif

