/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vp1394CMUGrabber_gen_h_
#define __vp1394CMUGrabber_gen_h_

#include <visp3/sensor/vp1394CMUGrabber.h>

#endif

