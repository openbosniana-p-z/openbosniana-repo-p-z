/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpKinect_gen_h_
#define __vpKinect_gen_h_

#include <visp3/sensor/vpKinect.h>

#endif

