/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMatrix_gen_h_
#define __vpMatrix_gen_h_

#include <visp3/core/vpMatrix.h>

#endif

