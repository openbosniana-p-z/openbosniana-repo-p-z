/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpHistogramValey_gen_h_
#define __vpHistogramValey_gen_h_

#include <visp3/core/vpHistogramValey.h>

#endif

