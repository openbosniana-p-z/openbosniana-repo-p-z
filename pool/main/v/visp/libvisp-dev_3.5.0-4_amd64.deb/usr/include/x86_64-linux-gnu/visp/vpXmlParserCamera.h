/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpXmlParserCamera_gen_h_
#define __vpXmlParserCamera_gen_h_

#include <visp3/core/vpXmlParserCamera.h>

#endif

