/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRzyxVector_gen_h_
#define __vpRzyxVector_gen_h_

#include <visp3/core/vpRzyxVector.h>

#endif

