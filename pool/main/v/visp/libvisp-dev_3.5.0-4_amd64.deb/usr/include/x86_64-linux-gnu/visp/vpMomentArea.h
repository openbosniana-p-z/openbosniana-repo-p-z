/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMomentArea_gen_h_
#define __vpMomentArea_gen_h_

#include <visp3/core/vpMomentArea.h>

#endif

