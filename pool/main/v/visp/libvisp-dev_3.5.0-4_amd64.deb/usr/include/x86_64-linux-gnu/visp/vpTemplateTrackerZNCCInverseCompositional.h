/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTemplateTrackerZNCCInverseCompositional_gen_h_
#define __vpTemplateTrackerZNCCInverseCompositional_gen_h_

#include <visp3/tt/vpTemplateTrackerZNCCInverseCompositional.h>

#endif

