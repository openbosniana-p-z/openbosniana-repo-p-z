/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpImageException_gen_h_
#define __vpImageException_gen_h_

#include <visp3/core/vpImageException.h>

#endif

