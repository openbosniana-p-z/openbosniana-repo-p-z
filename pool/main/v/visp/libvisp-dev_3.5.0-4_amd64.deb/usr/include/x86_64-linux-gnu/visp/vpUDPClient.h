/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpUDPClient_gen_h_
#define __vpUDPClient_gen_h_

#include <visp3/core/vpUDPClient.h>

#endif

