/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTemplateTrackerWarpAffine_gen_h_
#define __vpTemplateTrackerWarpAffine_gen_h_

#include <visp3/tt/vpTemplateTrackerWarpAffine.h>

#endif

