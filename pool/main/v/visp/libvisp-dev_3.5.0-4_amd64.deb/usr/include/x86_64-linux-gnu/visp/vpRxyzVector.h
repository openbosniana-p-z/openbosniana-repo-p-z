/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRxyzVector_gen_h_
#define __vpRxyzVector_gen_h_

#include <visp3/core/vpRxyzVector.h>

#endif

