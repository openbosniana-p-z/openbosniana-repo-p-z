/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpServoData_gen_h_
#define __vpServoData_gen_h_

#include <visp3/vs/vpServoData.h>

#endif

