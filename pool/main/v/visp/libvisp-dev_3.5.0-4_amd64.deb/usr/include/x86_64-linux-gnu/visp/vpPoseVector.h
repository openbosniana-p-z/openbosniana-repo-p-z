/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpPoseVector_gen_h_
#define __vpPoseVector_gen_h_

#include <visp3/core/vpPoseVector.h>

#endif

