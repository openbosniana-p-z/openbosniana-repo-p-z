/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpWin32API_gen_h_
#define __vpWin32API_gen_h_

#include <visp3/gui/vpWin32API.h>

#endif

