/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpDisplayException_gen_h_
#define __vpDisplayException_gen_h_

#include <visp3/core/vpDisplayException.h>

#endif

