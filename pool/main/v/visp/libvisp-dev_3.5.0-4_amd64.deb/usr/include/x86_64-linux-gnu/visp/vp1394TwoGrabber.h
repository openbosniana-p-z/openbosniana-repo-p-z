/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vp1394TwoGrabber_gen_h_
#define __vp1394TwoGrabber_gen_h_

#include <visp3/sensor/vp1394TwoGrabber.h>

#endif

