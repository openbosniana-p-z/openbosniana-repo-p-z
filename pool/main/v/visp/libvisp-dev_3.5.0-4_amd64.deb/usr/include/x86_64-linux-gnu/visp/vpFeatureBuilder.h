/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpFeatureBuilder_gen_h_
#define __vpFeatureBuilder_gen_h_

#include <visp3/visual_features/vpFeatureBuilder.h>

#endif

