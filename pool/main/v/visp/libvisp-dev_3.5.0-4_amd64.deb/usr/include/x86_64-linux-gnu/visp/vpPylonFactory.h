/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpPylonFactory_gen_h_
#define __vpPylonFactory_gen_h_

#include <visp3/sensor/vpPylonFactory.h>

#endif

