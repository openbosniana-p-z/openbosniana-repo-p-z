/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpSimulatorPioneer_gen_h_
#define __vpSimulatorPioneer_gen_h_

#include <visp3/robot/vpSimulatorPioneer.h>

#endif

