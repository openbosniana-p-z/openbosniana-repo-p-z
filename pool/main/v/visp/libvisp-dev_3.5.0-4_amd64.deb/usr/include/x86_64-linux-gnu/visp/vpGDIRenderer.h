/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpGDIRenderer_gen_h_
#define __vpGDIRenderer_gen_h_

#include <visp3/gui/vpGDIRenderer.h>

#endif

