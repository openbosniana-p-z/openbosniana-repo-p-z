/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpPixelMeterConversion_gen_h_
#define __vpPixelMeterConversion_gen_h_

#include <visp3/core/vpPixelMeterConversion.h>

#endif

