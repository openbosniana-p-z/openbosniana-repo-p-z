/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRobotBebop2_gen_h_
#define __vpRobotBebop2_gen_h_

#include <visp3/robot/vpRobotBebop2.h>

#endif

