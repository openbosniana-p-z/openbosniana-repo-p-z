/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTemplateTrackerSSD_gen_h_
#define __vpTemplateTrackerSSD_gen_h_

#include <visp3/tt/vpTemplateTrackerSSD.h>

#endif

