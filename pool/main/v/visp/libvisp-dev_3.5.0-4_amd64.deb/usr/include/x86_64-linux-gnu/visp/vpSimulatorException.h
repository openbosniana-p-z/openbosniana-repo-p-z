/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpSimulatorException_gen_h_
#define __vpSimulatorException_gen_h_

#include <visp3/ar/vpSimulatorException.h>

#endif

