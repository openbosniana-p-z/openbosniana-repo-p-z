/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpFeatureMomentGravityCenterNormalized_gen_h_
#define __vpFeatureMomentGravityCenterNormalized_gen_h_

#include <visp3/visual_features/vpFeatureMomentGravityCenterNormalized.h>

#endif

