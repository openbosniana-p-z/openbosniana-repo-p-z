/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpImage_gen_h_
#define __vpImage_gen_h_

#include <visp3/core/vpImage.h>

#endif

