/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpXmlConfigParserKeyPoint_gen_h_
#define __vpXmlConfigParserKeyPoint_gen_h_

#include <visp3/vision/vpXmlConfigParserKeyPoint.h>

#endif

