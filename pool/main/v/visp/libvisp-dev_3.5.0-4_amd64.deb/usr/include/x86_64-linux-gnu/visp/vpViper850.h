/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpViper850_gen_h_
#define __vpViper850_gen_h_

#include <visp3/robot/vpViper850.h>

#endif

