/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTime_gen_h_
#define __vpTime_gen_h_

#include <visp3/core/vpTime.h>

#endif

