/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpImageTools_gen_h_
#define __vpImageTools_gen_h_

#include <visp3/core/vpImageTools.h>

#endif

