/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpClient_gen_h_
#define __vpClient_gen_h_

#include <visp3/core/vpClient.h>

#endif

