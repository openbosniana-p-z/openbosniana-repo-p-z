/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTemplateTrackerSSDESM_gen_h_
#define __vpTemplateTrackerSSDESM_gen_h_

#include <visp3/tt/vpTemplateTrackerSSDESM.h>

#endif

