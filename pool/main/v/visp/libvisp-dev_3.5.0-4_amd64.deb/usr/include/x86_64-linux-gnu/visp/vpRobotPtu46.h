/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRobotPtu46_gen_h_
#define __vpRobotPtu46_gen_h_

#include <visp3/robot/vpRobotPtu46.h>

#endif

