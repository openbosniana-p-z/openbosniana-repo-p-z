/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpArray2D_gen_h_
#define __vpArray2D_gen_h_

#include <visp3/core/vpArray2D.h>

#endif

