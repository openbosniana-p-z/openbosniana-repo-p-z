/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRobotException_gen_h_
#define __vpRobotException_gen_h_

#include <visp3/robot/vpRobotException.h>

#endif

