/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpKalmanFilter_gen_h_
#define __vpKalmanFilter_gen_h_

#include <visp3/core/vpKalmanFilter.h>

#endif

