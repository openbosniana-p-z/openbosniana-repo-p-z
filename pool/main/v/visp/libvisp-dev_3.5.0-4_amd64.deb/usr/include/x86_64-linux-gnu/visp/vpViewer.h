/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpViewer_gen_h_
#define __vpViewer_gen_h_

#include <visp3/ar/vpViewer.h>

#endif

