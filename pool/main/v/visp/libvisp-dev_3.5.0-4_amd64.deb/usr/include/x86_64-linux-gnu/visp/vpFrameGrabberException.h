/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpFrameGrabberException_gen_h_
#define __vpFrameGrabberException_gen_h_

#include <visp3/core/vpFrameGrabberException.h>

#endif

