/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpServo_gen_h_
#define __vpServo_gen_h_

#include <visp3/vs/vpServo.h>

#endif

