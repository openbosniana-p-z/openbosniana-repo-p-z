/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpCircle_gen_h_
#define __vpCircle_gen_h_

#include <visp3/core/vpCircle.h>

#endif

