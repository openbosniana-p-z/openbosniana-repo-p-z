/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpGEMM_gen_h_
#define __vpGEMM_gen_h_

#include <visp3/core/vpGEMM.h>

#endif

