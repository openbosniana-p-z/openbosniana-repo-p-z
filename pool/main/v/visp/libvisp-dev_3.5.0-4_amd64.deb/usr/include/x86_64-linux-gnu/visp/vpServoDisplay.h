/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpServoDisplay_gen_h_
#define __vpServoDisplay_gen_h_

#include <visp3/vs/vpServoDisplay.h>

#endif

