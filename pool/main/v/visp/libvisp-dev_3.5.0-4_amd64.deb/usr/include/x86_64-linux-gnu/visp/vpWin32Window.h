/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpWin32Window_gen_h_
#define __vpWin32Window_gen_h_

#include <visp3/gui/vpWin32Window.h>

#endif

