/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTemplateTrackerWarpSRT_gen_h_
#define __vpTemplateTrackerWarpSRT_gen_h_

#include <visp3/tt/vpTemplateTrackerWarpSRT.h>

#endif

