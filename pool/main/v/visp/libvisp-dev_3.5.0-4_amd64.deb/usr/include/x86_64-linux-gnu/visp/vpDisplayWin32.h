/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpDisplayWin32_gen_h_
#define __vpDisplayWin32_gen_h_

#include <visp3/gui/vpDisplayWin32.h>

#endif

