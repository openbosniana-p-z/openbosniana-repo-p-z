/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpQbDevice_gen_h_
#define __vpQbDevice_gen_h_

#include <visp3/robot/vpQbDevice.h>

#endif

