/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpPioneer_gen_h_
#define __vpPioneer_gen_h_

#include <visp3/robot/vpPioneer.h>

#endif

