/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTemplateTrackerMI_gen_h_
#define __vpTemplateTrackerMI_gen_h_

#include <visp3/tt_mi/vpTemplateTrackerMI.h>

#endif

