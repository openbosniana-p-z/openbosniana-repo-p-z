/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpFeatureEllipse_gen_h_
#define __vpFeatureEllipse_gen_h_

#include <visp3/visual_features/vpFeatureEllipse.h>

#endif

