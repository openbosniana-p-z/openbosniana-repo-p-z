/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTemplateTrackerSSDForwardAdditional_gen_h_
#define __vpTemplateTrackerSSDForwardAdditional_gen_h_

#include <visp3/tt/vpTemplateTrackerSSDForwardAdditional.h>

#endif

