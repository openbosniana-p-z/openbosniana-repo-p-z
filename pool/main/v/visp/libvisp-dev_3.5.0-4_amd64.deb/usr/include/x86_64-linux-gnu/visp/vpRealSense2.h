/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRealSense2_gen_h_
#define __vpRealSense2_gen_h_

#include <visp3/sensor/vpRealSense2.h>

#endif

