/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpWin32Renderer_gen_h_
#define __vpWin32Renderer_gen_h_

#include <visp3/gui/vpWin32Renderer.h>

#endif

