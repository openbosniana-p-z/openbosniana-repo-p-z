/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMbtPolygon_gen_h_
#define __vpMbtPolygon_gen_h_

#include <visp3/mbt/vpMbtPolygon.h>

#endif

