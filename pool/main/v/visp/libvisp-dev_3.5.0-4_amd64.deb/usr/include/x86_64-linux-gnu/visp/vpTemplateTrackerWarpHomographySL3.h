/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTemplateTrackerWarpHomographySL3_gen_h_
#define __vpTemplateTrackerWarpHomographySL3_gen_h_

#include <visp3/tt/vpTemplateTrackerWarpHomographySL3.h>

#endif

