/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpQuaternionVector_gen_h_
#define __vpQuaternionVector_gen_h_

#include <visp3/core/vpQuaternionVector.h>

#endif

