/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMomentAlpha_gen_h_
#define __vpMomentAlpha_gen_h_

#include <visp3/core/vpMomentAlpha.h>

#endif

