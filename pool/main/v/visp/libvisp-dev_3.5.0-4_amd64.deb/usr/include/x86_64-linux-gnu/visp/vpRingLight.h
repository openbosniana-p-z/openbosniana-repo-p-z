/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRingLight_gen_h_
#define __vpRingLight_gen_h_

#include <visp3/robot/vpRingLight.h>

#endif

