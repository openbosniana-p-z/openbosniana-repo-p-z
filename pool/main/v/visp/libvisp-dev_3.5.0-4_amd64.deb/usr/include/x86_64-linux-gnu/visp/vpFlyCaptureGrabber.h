/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpFlyCaptureGrabber_gen_h_
#define __vpFlyCaptureGrabber_gen_h_

#include <visp3/sensor/vpFlyCaptureGrabber.h>

#endif

