/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpUnicycle_gen_h_
#define __vpUnicycle_gen_h_

#include <visp3/robot/vpUnicycle.h>

#endif

