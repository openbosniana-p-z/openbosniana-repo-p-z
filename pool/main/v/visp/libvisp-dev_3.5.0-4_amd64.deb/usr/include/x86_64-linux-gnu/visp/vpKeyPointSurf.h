/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpKeyPointSurf_gen_h_
#define __vpKeyPointSurf_gen_h_

#include <visp3/vision/vpKeyPointSurf.h>

#endif

