/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMouseButton_gen_h_
#define __vpMouseButton_gen_h_

#include <visp3/core/vpMouseButton.h>

#endif

