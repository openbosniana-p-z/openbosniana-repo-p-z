/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRect_gen_h_
#define __vpRect_gen_h_

#include <visp3/core/vpRect.h>

#endif

