/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpDot2_gen_h_
#define __vpDot2_gen_h_

#include <visp3/blob/vpDot2.h>

#endif

