/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRotationVector_gen_h_
#define __vpRotationVector_gen_h_

#include <visp3/core/vpRotationVector.h>

#endif

