/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpConvert_gen_h_
#define __vpConvert_gen_h_

#include <visp3/core/vpConvert.h>

#endif

