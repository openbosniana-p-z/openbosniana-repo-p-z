/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpPylonGrabber_gen_h_
#define __vpPylonGrabber_gen_h_

#include <visp3/sensor/vpPylonGrabber.h>

#endif

