/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMatrixException_gen_h_
#define __vpMatrixException_gen_h_

#include <visp3/core/vpMatrixException.h>

#endif

