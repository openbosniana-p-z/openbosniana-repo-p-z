/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpImageDraw_gen_h_
#define __vpImageDraw_gen_h_

#include <visp3/core/vpImageDraw.h>

#endif

