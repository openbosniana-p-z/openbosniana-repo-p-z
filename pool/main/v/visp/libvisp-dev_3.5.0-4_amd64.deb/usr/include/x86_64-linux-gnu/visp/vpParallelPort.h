/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpParallelPort_gen_h_
#define __vpParallelPort_gen_h_

#include <visp3/io/vpParallelPort.h>

#endif

