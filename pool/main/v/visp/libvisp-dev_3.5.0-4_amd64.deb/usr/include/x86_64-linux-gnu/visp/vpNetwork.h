/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpNetwork_gen_h_
#define __vpNetwork_gen_h_

#include <visp3/core/vpNetwork.h>

#endif

