/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpDetectorBase_gen_h_
#define __vpDetectorBase_gen_h_

#include <visp3/detection/vpDetectorBase.h>

#endif

