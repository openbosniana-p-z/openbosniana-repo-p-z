/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpDisplay_gen_h_
#define __vpDisplay_gen_h_

#include <visp3/core/vpDisplay.h>

#endif

