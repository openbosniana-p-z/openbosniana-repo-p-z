/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpFont_gen_h_
#define __vpFont_gen_h_

#include <visp3/core/vpFont.h>

#endif

