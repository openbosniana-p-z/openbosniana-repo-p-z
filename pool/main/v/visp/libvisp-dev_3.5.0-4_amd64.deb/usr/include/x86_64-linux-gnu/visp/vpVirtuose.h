/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpVirtuose_gen_h_
#define __vpVirtuose_gen_h_

#include <visp3/robot/vpVirtuose.h>

#endif

