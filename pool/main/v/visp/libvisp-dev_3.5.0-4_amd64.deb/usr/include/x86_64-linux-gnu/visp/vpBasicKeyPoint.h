/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpBasicKeyPoint_gen_h_
#define __vpBasicKeyPoint_gen_h_

#include <visp3/vision/vpBasicKeyPoint.h>

#endif

