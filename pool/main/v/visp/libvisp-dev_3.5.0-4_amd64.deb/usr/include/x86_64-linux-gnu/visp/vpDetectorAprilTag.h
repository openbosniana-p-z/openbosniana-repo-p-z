/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpDetectorAprilTag_gen_h_
#define __vpDetectorAprilTag_gen_h_

#include <visp3/detection/vpDetectorAprilTag.h>

#endif

