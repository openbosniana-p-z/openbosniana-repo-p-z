/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpServer_gen_h_
#define __vpServer_gen_h_

#include <visp3/core/vpServer.h>

#endif

