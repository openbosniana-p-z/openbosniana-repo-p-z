/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpFeatureMoment_gen_h_
#define __vpFeatureMoment_gen_h_

#include <visp3/visual_features/vpFeatureMoment.h>

#endif

