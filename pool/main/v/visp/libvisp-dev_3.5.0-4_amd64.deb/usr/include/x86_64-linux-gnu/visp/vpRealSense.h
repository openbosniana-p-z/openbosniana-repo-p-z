/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRealSense_gen_h_
#define __vpRealSense_gen_h_

#include <visp3/sensor/vpRealSense.h>

#endif

