/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpWireFrameSimulator_gen_h_
#define __vpWireFrameSimulator_gen_h_

#include <visp3/robot/vpWireFrameSimulator.h>

#endif

