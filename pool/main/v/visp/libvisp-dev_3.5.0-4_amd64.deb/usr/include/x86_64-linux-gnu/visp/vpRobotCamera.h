/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRobotCamera_gen_h_
#define __vpRobotCamera_gen_h_

#include <visp3/robot/vpRobotCamera.h>

#endif

