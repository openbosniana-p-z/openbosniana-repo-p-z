/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpDisplayOpenCV_gen_h_
#define __vpDisplayOpenCV_gen_h_

#include <visp3/gui/vpDisplayOpenCV.h>

#endif

