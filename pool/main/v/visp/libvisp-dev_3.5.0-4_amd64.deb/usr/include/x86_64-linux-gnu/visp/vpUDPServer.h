/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpUDPServer_gen_h_
#define __vpUDPServer_gen_h_

#include <visp3/core/vpUDPServer.h>

#endif

