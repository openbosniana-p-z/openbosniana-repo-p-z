/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpDisplayX_gen_h_
#define __vpDisplayX_gen_h_

#include <visp3/gui/vpDisplayX.h>

#endif

