/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMomentAreaNormalized_gen_h_
#define __vpMomentAreaNormalized_gen_h_

#include <visp3/core/vpMomentAreaNormalized.h>

#endif

