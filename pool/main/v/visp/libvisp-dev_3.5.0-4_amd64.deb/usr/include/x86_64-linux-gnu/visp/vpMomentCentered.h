/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMomentCentered_gen_h_
#define __vpMomentCentered_gen_h_

#include <visp3/core/vpMomentCentered.h>

#endif

