/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpUeyeGrabber_gen_h_
#define __vpUeyeGrabber_gen_h_

#include <visp3/sensor/vpUeyeGrabber.h>

#endif

