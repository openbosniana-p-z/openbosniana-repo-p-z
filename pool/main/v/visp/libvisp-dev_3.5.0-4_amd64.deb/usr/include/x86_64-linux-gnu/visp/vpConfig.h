/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpConfig_gen_h_
#define __vpConfig_gen_h_

#include <visp3/core/vpConfig.h>

#endif

