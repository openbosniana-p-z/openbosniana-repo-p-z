/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpFeatureMomentGravityCenter_gen_h_
#define __vpFeatureMomentGravityCenter_gen_h_

#include <visp3/visual_features/vpFeatureMomentGravityCenter.h>

#endif

