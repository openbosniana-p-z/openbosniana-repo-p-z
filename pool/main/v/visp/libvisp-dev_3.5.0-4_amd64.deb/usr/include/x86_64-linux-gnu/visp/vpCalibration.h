/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpCalibration_gen_h_
#define __vpCalibration_gen_h_

#include <visp3/vision/vpCalibration.h>

#endif

