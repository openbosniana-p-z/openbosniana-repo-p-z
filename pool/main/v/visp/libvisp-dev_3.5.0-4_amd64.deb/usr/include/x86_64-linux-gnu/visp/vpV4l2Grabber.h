/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpV4l2Grabber_gen_h_
#define __vpV4l2Grabber_gen_h_

#include <visp3/sensor/vpV4l2Grabber.h>

#endif

