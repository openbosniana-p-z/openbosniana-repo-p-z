/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRzyzVector_gen_h_
#define __vpRzyzVector_gen_h_

#include <visp3/core/vpRzyzVector.h>

#endif

