/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpImageQueue_gen_h_
#define __vpImageQueue_gen_h_

#include <visp3/io/vpImageQueue.h>

#endif

