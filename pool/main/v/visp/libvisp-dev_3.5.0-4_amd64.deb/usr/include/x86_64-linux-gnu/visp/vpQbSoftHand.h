/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpQbSoftHand_gen_h_
#define __vpQbSoftHand_gen_h_

#include <visp3/robot/vpQbSoftHand.h>

#endif

