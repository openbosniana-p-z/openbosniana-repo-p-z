/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpBiclops_gen_h_
#define __vpBiclops_gen_h_

#include <visp3/robot/vpBiclops.h>

#endif

