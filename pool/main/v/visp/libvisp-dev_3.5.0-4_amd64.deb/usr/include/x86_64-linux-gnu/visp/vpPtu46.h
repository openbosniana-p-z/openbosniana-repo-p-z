/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpPtu46_gen_h_
#define __vpPtu46_gen_h_

#include <visp3/robot/vpPtu46.h>

#endif

