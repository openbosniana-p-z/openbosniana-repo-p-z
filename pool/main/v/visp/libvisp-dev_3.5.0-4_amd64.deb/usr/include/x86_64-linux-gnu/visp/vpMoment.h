/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMoment_gen_h_
#define __vpMoment_gen_h_

#include <visp3/core/vpMoment.h>

#endif

