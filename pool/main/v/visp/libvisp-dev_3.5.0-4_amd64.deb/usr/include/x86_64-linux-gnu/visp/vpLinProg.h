/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpLinProg_gen_h_
#define __vpLinProg_gen_h_

#include <visp3/core/vpLinProg.h>

#endif

