/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpParseArgv_gen_h_
#define __vpParseArgv_gen_h_

#include <visp3/io/vpParseArgv.h>

#endif

