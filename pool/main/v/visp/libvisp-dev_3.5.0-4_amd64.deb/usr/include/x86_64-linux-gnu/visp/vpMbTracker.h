/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMbTracker_gen_h_
#define __vpMbTracker_gen_h_

#include <visp3/mbt/vpMbTracker.h>

#endif

