/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMbEdgeTracker_gen_h_
#define __vpMbEdgeTracker_gen_h_

#include <visp3/mbt/vpMbEdgeTracker.h>

#endif

