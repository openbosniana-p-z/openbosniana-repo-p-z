/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpImageMorphology_gen_h_
#define __vpImageMorphology_gen_h_

#include <visp3/core/vpImageMorphology.h>

#endif

