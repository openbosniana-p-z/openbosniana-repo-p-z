/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __visp_modules_gen_h_
#define __visp_modules_gen_h_

#include <visp3/visp_modules.h>

#endif

