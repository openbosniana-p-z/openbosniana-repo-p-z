/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRansac_gen_h_
#define __vpRansac_gen_h_

#include <visp3/core/vpRansac.h>

#endif

