/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpScale_gen_h_
#define __vpScale_gen_h_

#include <visp3/core/vpScale.h>

#endif

