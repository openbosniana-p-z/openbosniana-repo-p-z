/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMomentCInvariant_gen_h_
#define __vpMomentCInvariant_gen_h_

#include <visp3/core/vpMomentCInvariant.h>

#endif

