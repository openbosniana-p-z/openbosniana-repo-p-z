/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTemplateTracker_gen_h_
#define __vpTemplateTracker_gen_h_

#include <visp3/tt/vpTemplateTracker.h>

#endif

