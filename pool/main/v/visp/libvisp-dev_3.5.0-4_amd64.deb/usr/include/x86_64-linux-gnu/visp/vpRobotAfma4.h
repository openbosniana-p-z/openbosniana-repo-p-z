/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRobotAfma4_gen_h_
#define __vpRobotAfma4_gen_h_

#include <visp3/robot/vpRobotAfma4.h>

#endif

