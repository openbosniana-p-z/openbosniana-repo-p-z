/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpDetectorDNN_gen_h_
#define __vpDetectorDNN_gen_h_

#include <visp3/detection/vpDetectorDNN.h>

#endif

