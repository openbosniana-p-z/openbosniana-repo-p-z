/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpPose_gen_h_
#define __vpPose_gen_h_

#include <visp3/vision/vpPose.h>

#endif

