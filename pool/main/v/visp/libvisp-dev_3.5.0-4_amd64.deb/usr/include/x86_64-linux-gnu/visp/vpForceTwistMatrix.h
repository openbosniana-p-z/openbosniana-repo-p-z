/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpForceTwistMatrix_gen_h_
#define __vpForceTwistMatrix_gen_h_

#include <visp3/core/vpForceTwistMatrix.h>

#endif

