/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpSphere_gen_h_
#define __vpSphere_gen_h_

#include <visp3/core/vpSphere.h>

#endif

