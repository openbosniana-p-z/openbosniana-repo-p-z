/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpImageStorageWorker_gen_h_
#define __vpImageStorageWorker_gen_h_

#include <visp3/io/vpImageStorageWorker.h>

#endif

