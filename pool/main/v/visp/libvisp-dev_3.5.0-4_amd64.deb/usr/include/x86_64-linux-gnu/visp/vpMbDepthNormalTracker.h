/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMbDepthNormalTracker_gen_h_
#define __vpMbDepthNormalTracker_gen_h_

#include <visp3/mbt/vpMbDepthNormalTracker.h>

#endif

