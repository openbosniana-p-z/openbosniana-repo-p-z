/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMbGenericTracker_gen_h_
#define __vpMbGenericTracker_gen_h_

#include <visp3/mbt/vpMbGenericTracker.h>

#endif

