/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTracker_gen_h_
#define __vpTracker_gen_h_

#include <visp3/core/vpTracker.h>

#endif

