/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpProjectionDisplay_gen_h_
#define __vpProjectionDisplay_gen_h_

#include <visp3/gui/vpProjectionDisplay.h>

#endif

