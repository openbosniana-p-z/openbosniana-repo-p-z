/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpSimulatorCamera_gen_h_
#define __vpSimulatorCamera_gen_h_

#include <visp3/robot/vpSimulatorCamera.h>

#endif

