/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpAROgre_gen_h_
#define __vpAROgre_gen_h_

#include <visp3/ar/vpAROgre.h>

#endif

