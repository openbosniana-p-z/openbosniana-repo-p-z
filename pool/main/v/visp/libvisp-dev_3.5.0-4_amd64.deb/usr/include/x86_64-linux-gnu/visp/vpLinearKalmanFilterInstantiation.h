/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpLinearKalmanFilterInstantiation_gen_h_
#define __vpLinearKalmanFilterInstantiation_gen_h_

#include <visp3/core/vpLinearKalmanFilterInstantiation.h>

#endif

