/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpOccipitalStructure_gen_h_
#define __vpOccipitalStructure_gen_h_

#include <visp3/sensor/vpOccipitalStructure.h>

#endif

