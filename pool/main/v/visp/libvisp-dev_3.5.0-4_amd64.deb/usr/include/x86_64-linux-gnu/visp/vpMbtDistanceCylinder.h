/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMbtDistanceCylinder_gen_h_
#define __vpMbtDistanceCylinder_gen_h_

#include <visp3/mbt/vpMbtDistanceCylinder.h>

#endif

