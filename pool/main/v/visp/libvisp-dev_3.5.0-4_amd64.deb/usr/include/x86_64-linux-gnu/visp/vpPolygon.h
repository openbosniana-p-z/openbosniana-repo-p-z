/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpPolygon_gen_h_
#define __vpPolygon_gen_h_

#include <visp3/core/vpPolygon.h>

#endif

