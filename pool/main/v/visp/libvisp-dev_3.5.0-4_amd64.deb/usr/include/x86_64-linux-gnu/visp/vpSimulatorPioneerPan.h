/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpSimulatorPioneerPan_gen_h_
#define __vpSimulatorPioneerPan_gen_h_

#include <visp3/robot/vpSimulatorPioneerPan.h>

#endif

