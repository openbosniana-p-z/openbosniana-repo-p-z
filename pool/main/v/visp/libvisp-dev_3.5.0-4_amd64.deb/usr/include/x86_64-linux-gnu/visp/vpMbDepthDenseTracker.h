/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMbDepthDenseTracker_gen_h_
#define __vpMbDepthDenseTracker_gen_h_

#include <visp3/mbt/vpMbDepthDenseTracker.h>

#endif

