/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRobotWireFrameSimulator_gen_h_
#define __vpRobotWireFrameSimulator_gen_h_

#include <visp3/robot/vpRobotWireFrameSimulator.h>

#endif

