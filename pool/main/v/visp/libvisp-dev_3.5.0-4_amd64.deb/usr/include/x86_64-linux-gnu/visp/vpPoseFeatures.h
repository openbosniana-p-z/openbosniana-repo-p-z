/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpPoseFeatures_gen_h_
#define __vpPoseFeatures_gen_h_

#include <visp3/vision/vpPoseFeatures.h>

#endif

