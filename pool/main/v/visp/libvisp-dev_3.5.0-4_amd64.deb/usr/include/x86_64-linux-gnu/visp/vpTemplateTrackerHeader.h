/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTemplateTrackerHeader_gen_h_
#define __vpTemplateTrackerHeader_gen_h_

#include <visp3/tt/vpTemplateTrackerHeader.h>

#endif

