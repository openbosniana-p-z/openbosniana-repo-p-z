/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRotationMatrix_gen_h_
#define __vpRotationMatrix_gen_h_

#include <visp3/core/vpRotationMatrix.h>

#endif

