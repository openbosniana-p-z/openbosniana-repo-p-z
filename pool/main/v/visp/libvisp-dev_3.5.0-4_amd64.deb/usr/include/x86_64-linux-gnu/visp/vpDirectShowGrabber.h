/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpDirectShowGrabber_gen_h_
#define __vpDirectShowGrabber_gen_h_

#include <visp3/sensor/vpDirectShowGrabber.h>

#endif

