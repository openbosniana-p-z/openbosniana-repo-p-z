/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTemplateTrackerSSDForwardCompositional_gen_h_
#define __vpTemplateTrackerSSDForwardCompositional_gen_h_

#include <visp3/tt/vpTemplateTrackerSSDForwardCompositional.h>

#endif

