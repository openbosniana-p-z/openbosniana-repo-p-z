/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpSimulatorAfma6_gen_h_
#define __vpSimulatorAfma6_gen_h_

#include <visp3/robot/vpSimulatorAfma6.h>

#endif

