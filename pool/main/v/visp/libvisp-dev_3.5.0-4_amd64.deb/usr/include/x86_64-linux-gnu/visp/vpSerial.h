/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpSerial_gen_h_
#define __vpSerial_gen_h_

#include <visp3/core/vpSerial.h>

#endif

