/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRobotBiclopsController_gen_h_
#define __vpRobotBiclopsController_gen_h_

#include <visp3/robot/vpRobotBiclopsController.h>

#endif

