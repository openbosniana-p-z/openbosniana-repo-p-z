/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpViper650_gen_h_
#define __vpViper650_gen_h_

#include <visp3/robot/vpViper650.h>

#endif

