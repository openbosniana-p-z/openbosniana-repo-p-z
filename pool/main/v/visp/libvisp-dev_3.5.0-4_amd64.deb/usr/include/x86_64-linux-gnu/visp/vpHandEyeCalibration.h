/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpHandEyeCalibration_gen_h_
#define __vpHandEyeCalibration_gen_h_

#include <visp3/vision/vpHandEyeCalibration.h>

#endif

