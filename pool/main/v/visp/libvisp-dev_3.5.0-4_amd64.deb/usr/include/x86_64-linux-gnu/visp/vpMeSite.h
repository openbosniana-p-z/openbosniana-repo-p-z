/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMeSite_gen_h_
#define __vpMeSite_gen_h_

#include <visp3/me/vpMeSite.h>

#endif

