/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMbtMeEllipse_gen_h_
#define __vpMbtMeEllipse_gen_h_

#include <visp3/mbt/vpMbtMeEllipse.h>

#endif

