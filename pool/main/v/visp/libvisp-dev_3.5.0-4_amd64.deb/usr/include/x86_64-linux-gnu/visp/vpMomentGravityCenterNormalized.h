/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMomentGravityCenterNormalized_gen_h_
#define __vpMomentGravityCenterNormalized_gen_h_

#include <visp3/core/vpMomentGravityCenterNormalized.h>

#endif

