/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpImageConvert_gen_h_
#define __vpImageConvert_gen_h_

#include <visp3/core/vpImageConvert.h>

#endif

