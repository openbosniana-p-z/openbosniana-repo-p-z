/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTemplateTrackerBSpline_gen_h_
#define __vpTemplateTrackerBSpline_gen_h_

#include <visp3/tt/vpTemplateTrackerBSpline.h>

#endif

