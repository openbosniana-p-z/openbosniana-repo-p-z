/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpMbtDistanceKltPoints_gen_h_
#define __vpMbtDistanceKltPoints_gen_h_

#include <visp3/mbt/vpMbtDistanceKltPoints.h>

#endif

