/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpDetectorQRCode_gen_h_
#define __vpDetectorQRCode_gen_h_

#include <visp3/detection/vpDetectorQRCode.h>

#endif

