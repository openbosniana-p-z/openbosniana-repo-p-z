/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpVideoReader_gen_h_
#define __vpVideoReader_gen_h_

#include <visp3/io/vpVideoReader.h>

#endif

