/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpServoException_gen_h_
#define __vpServoException_gen_h_

#include <visp3/vs/vpServoException.h>

#endif

