/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpTrackingException_gen_h_
#define __vpTrackingException_gen_h_

#include <visp3/core/vpTrackingException.h>

#endif

