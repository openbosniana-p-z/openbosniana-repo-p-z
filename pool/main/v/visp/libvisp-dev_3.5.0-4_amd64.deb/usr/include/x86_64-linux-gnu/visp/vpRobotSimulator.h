/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRobotSimulator_gen_h_
#define __vpRobotSimulator_gen_h_

#include <visp3/robot/vpRobotSimulator.h>

#endif

