/*
 *      ** File generated automatically, do not modify **
 *
*/

#ifndef __vpRobotFranka_gen_h_
#define __vpRobotFranka_gen_h_

#include <visp3/robot/vpRobotFranka.h>

#endif

