Example: Building a Trapperkeeper service that wraps java code
--------------------------------------------------------------
To run the example:

    lein trampoline run --config ./examples/java_service/config.conf \
                    --bootstrap-config ./examples/java_service/bootstrap.cfg
