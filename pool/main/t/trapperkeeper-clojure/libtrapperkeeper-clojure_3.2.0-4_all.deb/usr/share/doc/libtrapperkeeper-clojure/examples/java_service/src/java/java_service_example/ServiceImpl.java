package java_service_example;

public class ServiceImpl {
    public static String getMessage() { return "This came from java."; }
    public static int getMeaningOfLife() { return 42; }
}