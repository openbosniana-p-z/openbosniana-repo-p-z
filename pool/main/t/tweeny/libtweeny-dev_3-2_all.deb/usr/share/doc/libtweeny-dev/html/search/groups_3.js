var searchData=
[
  ['linear_124',['Linear',['../group__linear.html',1,'']]]
];
