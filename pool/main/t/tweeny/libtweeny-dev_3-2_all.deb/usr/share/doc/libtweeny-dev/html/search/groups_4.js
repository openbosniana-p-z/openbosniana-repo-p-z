var searchData=
[
  ['quadratic_125',['Quadratic',['../group__quadratic.html',1,'']]],
  ['quartic_126',['Quartic',['../group__quartic.html',1,'']]],
  ['quintic_127',['Quintic',['../group__quintic.html',1,'']]]
];
