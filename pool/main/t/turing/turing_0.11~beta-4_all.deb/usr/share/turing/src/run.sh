#!/bin/bash

source tools/compile-gui.sh
python3 main.py

