# -*- coding: utf-8 -*-

from .AssignStmt import *
from .BaseStmt import *
from .BlockStmt import *
from .BreakStmt import *
from .CallStmt import *
from .CommentStmt import *
from .ContinueStmt import *
from .DisplayStmt import *
from .ElseStmt import *
from .ForStmt import *
from .FuncStmt import *
from .GClearStmt import *
from .GFuncStmt import *
from .GLineStmt import *
from .GPointStmt import *
from .GWindowStmt import *
from .IfStmt import *
from .InputStmt import *
from .ReturnStmt import *
from .SleepStmt import *
from .StopStmt import *
from .WhileStmt import *
