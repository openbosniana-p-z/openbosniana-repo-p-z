"""
This document contains the tree widget used to display the editor document
outline.

"""
from pyqode.core.widgets import OutlineTreeWidget


class PyOutlineTreeWidget(OutlineTreeWidget):
    """
    Deprecated, use pyqode.core.widgets.OutlineTreeWidget instead.
    """
    pass
