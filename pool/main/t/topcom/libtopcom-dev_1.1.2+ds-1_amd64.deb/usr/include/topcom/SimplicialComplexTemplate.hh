////////////////////////////////////////////////////////////////////////////////
// 
// SimplicialComplexTemplate.hh 
//
//    produced: 29/05/98 jr
// last change: 02/06/98 jr
//
////////////////////////////////////////////////////////////////////////////////
#ifndef SIMPLICIALCOMPLEXTEMPLATE_HH
#define SIMPLICIALCOMPLEXTEMPLATE_HH

#include "SimplicialComplexTemplate_Declarations.hh"
#include "SimplicialComplexTemplate_Definitions.hh"

namespace topcom {
};

#endif

// eof SimplicialComplexTemplate.hh
