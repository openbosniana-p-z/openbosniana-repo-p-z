#!/usr/bin/python3

import configparser
import sys
from pathlib import Path
from subprocess import run

def task_path():
    cfg_locations = [
        "/etc/topydo.conf",
        str(Path("~/.config/topydo/config").expanduser()),
        str(Path("~/.topydo").expanduser()),
        ".topydo",
        "topydo.conf",
        "topydo.ini",
    ]

    config = configparser.ConfigParser()
    config.read(cfg_locations)
    task_path = config.get("topydo", "filename", fallback="todo.txt")
    task_path = str(Path(task_path).expanduser().resolve())
    return task_path


def printinfo(task_path):

    print("executable =", "/usr/bin/topydo")
    print("task_path =", task_path)


def run_hooks(hooktype, task_path):
    try:
        run(["todo.txt-base", hooktype, task_path])
    except FileNotFoundError:
        pass


def main():
    tsk_path = task_path()

    if len(sys.argv) >= 2 and sys.argv[1] == "--info":
        printinfo(tsk_path)
        sys.exit(0)

    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


    from topydo.ui.UILoader import main as tpdmain

    tpdmain()


if __name__ == "__main__":
    main()
