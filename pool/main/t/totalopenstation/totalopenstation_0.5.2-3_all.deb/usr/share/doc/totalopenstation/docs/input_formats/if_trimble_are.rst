.. _if_trimble_are:

=========================================
:mod:`trimble_are` -- Trimble AREA format
=========================================

.. moduleauthor:: Stefano Costa, Luca Bianconi, Alessandro Bezzi

