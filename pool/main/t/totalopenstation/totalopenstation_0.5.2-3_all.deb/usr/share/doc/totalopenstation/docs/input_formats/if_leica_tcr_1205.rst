.. _if_leica_tcr_1205:

=======================================
:mod:`leica_tcr_1205` -- Leica TCR 1205
=======================================

.. moduleauthor:: Stefano Costa, Stefano Costa


This format is used by the Leica TCR 1205 (and other similar devices),
and contains both polar and cartesian coordinates. At the moment, only
cartesian coordinates are used to obtain exported data.

Acknowledgements
================

Support for this format was added thanks to Joseph Reeves, OA Digital.
