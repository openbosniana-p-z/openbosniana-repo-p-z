.. |br| raw:: html

    <br />

.. _`Github`: https://github.com/steko/totalopenstation/
.. _`bug tracker`: https://github.com/steko/totalopenstation/issues
.. _`pull request`: https://github.com/steko/totalopenstation/pulls
.. _`support channel`: https://github.com/steko/totalopenstation/issues
