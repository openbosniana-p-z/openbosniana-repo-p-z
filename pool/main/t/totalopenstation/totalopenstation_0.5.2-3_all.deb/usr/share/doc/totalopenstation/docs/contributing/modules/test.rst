==========
Test suits
==========

This module is used for test purpose.

Each new format or new function should have a test suits.

Classes
=======

.. automodule:: tests
   :members:
   :member-order: bysource
   :undoc-members:
   :show-inheritance: