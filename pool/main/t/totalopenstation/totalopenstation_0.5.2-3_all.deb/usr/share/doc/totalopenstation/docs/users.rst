.. _users:

=============================
 Users of Total Open Station
=============================

So far, Total Open Station has been successfully used by:

    * Università di Siena, Italy `Dipartimento di Archeologia e Storia delle
      Arti`_, for the excavations at Gortyna and Vignale
    * `Oxford Archaeology`_, UK, for fieldwork, using the OpenMoko_ mobile
      platform
    * `Arke_Geomática`_, Spain has blogged about TOPS
    * Arc-Team_, Italy, we have added support for the Trimble “area” format
      after Arc-Team sent us some sample data
    * Università di Padova, Italy (excavation in Montegrotto)
    * `Gurob Harem Palace Project`_, Egypt

.. _`Dipartimento di Archeologia e Storia delle Arti`: http://www.archeoarti.unisi.it
.. _`Oxford Archaeology`: http://thehumanjourney.net/
.. _OpenMoko: http://blogs.thehumanjourney.net/finds/entry/2
.. _Arke_Geomática: http://arkeox.blogspot.com/2008/10/sistemas-electrnicosdigitales-de.html
.. _Arc-Team: http://www.arc-team.com/
.. _`Gurob Harem Palace Project`: http://www.gurob.org.uk/

If you're in the number of happy users, let us know.
