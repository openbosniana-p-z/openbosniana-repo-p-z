# Trapperkeeper Authorization Documentation Index

* [Configuration](./authorization-config.md)
* [Working with x.509 Extensions](./extensions.md)
