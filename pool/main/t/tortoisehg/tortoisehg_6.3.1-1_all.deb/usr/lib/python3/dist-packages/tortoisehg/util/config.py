bin_path = '/usr/bin'
icon_path = '/usr/share/pixmaps/tortoisehg'
license_path = '/usr/share/doc/tortoisehg/COPYING.txt'
locale_path = '/usr/share/locale'
nofork = True
qt_api = 'PyQt5'
