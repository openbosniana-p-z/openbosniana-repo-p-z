#!/bin/sh

for prog in *.go ; do
    echo $prog ;
    run-theme-d-program $prog ;
done
