Unzip or untar the distribution. It should make its own directory.
For Wind@ws run the install.bat file by the command "install".
Read the file tthgold_manual.html or tthgold_manual.tex for further instructions.

