Introduction:
------------

Run "ticker text" to just display text on the screen. See the man page for
more info.

The programming interface:
-------------------------

Setting up a program to communicate with ticker and make it change the text
it displays periodically isn't too hard if you understand shared memory.
Take a look at the sysinfo-ticker for a simple example that you can modify
for your own purposes. Basically, you open a non-private shared memory
segment of a given size, and then you pass its id number to ticker via -s



Please report any problems to Joey Hess <joey@kitenet.net>. However, I
haven't used this program in a long time myself, am doing no new
development on it, and will happily pass it on to anyone who wants to take
over the reins and develop it.
