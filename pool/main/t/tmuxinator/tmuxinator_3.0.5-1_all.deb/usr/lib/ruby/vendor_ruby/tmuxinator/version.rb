module Tmuxinator
  VERSION = "3.0.5".freeze
end
