# API Docs for Older Versions

- [0.9.0](https://clojure.github.io/test.check/0.9.0)
- [0.8.2](https://clojure.github.io/test.check/0.8.2)
- [0.6.2](https://clojure.github.io/test.check/0.6.2)
