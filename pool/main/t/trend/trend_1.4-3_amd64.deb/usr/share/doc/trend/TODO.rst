Planned features

	* More optimisations can be done for: different shading modes,
	  different input types.

	* Faster oscilloscope controls like: graph offsetting,
	  zooming and panning.

	* Remote control via stdin.

	* Internal refactoring.

	* Infinity support is lacking (lines, fill and integration
	  could be correctly implemented by using signbit() instead
	  of ignoring the value completely).
