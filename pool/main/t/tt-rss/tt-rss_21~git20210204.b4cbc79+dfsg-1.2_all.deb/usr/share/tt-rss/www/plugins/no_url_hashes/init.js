require(['dojo/_base/kernel', 'dojo/ready'], function (dojo, ready) {
	ready(function () {
		hash_set = function () {
		};
		hash_get = function () {
		};
	});
});

