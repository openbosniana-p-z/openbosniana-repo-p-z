#ifndef airExistsConf_h
#define airExistsConf_h
/* #undef AIR_EXISTS_MACRO_FAILS */
#endif // airExistsConf_h

