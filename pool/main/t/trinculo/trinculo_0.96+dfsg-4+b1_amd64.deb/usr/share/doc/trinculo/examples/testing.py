import hashlib
import subprocess
import os
import tempfile

devnull = open(os.devnull, 'w')

examplepath="/usr/share/doc/trinculo/examples"
trinculo="/usr/bin/trinculo"

tmpdir=tempfile.mkdtemp()

print("Testing trinculo (v0.95)")
print("Test files are written to: " + tmpdir)
print("1. Testing frequentist association (plink)...", end=' ')

test1 = subprocess.call([trinculo,"multinom","--bfile", examplepath + "/genotypes","--pheno", examplepath + "/phenos.txt","--phenoname","Pheno","--basepheno","Control","--out", tmpdir + "/1"],stdout=devnull, stderr=devnull)

stoptest=False
if test1 != 0:
    print("FAILED (trinculo returned non-zero code " + str(test1) + ")")
    stoptest=True 

if not stoptest:
    test2 = os.path.isfile(tmpdir + "/1" + ".log") and os.path.isfile(tmpdir + "/1" + ".assoc.multinom")
    if not test2:
        print("FAILED (trinuculo failed to produce expected files)")
        stoptest=True
if not stoptest:
    test3 = hashlib.md5(open(tmpdir + '/1.assoc.multinom').read().encode('utf-8')).hexdigest()
    res3 = "1d672864decc4dcd484d11ddeefa02c6"
    if test3 != res3:
        print("FAILED (trinculo produced file with incorrect MD5 sum: " + tmpdir + '/1.assoc.multinom)')
        stoptest=True

if not stoptest:
    print("PASSED")


print("2. Testing frequentist association (dosage)...", end=' ')

test1 = subprocess.call([trinculo,"multinom","--dosage", examplepath + "/genotypes.dose","--pheno", examplepath + "/phenos.txt","--phenoname","Pheno","--basepheno","Control","--out", tmpdir + "/2"],stdout=devnull, stderr=devnull)

stoptest=False
if test1 != 0:
    print("FAILED (trinculo returned non-zero code " + str(test1) + ")")
    stoptest=True 

if not stoptest:
    test2 = os.path.isfile(tmpdir + "/2" + ".log") and os.path.isfile(tmpdir + "/2" + ".assoc.multinom")
    if not test2:
        print("FAILED (trinuculo failed to produce expected files)")
        stoptest=True

if not stoptest: 
    test3 = hashlib.md5(open(tmpdir + '/2.assoc.multinom').read().encode('utf-8')).hexdigest()
    res3 = "3d36d0b3d81553578ff98613999053ba"
    if test3 != res3:
        print("FAILED (trinculo produced file with incorrect MD5 sum: " + tmpdir + '/2.assoc.multinom)')
        stoptest=True

if not stoptest:
    print("PASSED")
  
print("3. Testing frequentist association (covariates)...", end=' ')

test1 = subprocess.call([trinculo,"multinom","--bfile", examplepath + "/genotypes","--pheno", examplepath + "/phenos.txt","--phenoname","Pheno","--basepheno","Control","--covar", examplepath + "/pcs.txt","--out", tmpdir + "/3"],stdout=devnull, stderr=devnull)

stoptest=False
if test1 != 0:
    print("FAILED (trinculo returned non-zero code " + str(test1) + ")")
    stoptest=True

if not stoptest:
    test2 = os.path.isfile(tmpdir + "/3" + ".log") and os.path.isfile(tmpdir + "/3" + ".assoc.multinom")
    if not test2:
        print("FAILED (trinuculo failed to produce expected files)")
        stoptest=True

if not stoptest:
    test3 = hashlib.md5(open(tmpdir + '/3.assoc.multinom').read().encode('utf-8')).hexdigest()
    res3 = "1603b7aa447e4d04baffc5effd7b7237"
    if test3 != res3:
        print("FAILED (trinculo produced file with incorrect MD5 sum: " + tmpdir + '/3.assoc.multinom)')
        stoptest=True

if not stoptest:
    print("PASSED")


print("4. Testing frequentist association (conditioning)...", end=' ')

condfile=tempfile.mkstemp()
open(condfile[1],"w").write("SNP1")

test1 = subprocess.call([trinculo,"multinom","--bfile", examplepath + "/genotypes","--pheno", examplepath + "/phenos.txt","--phenoname","Pheno","--basepheno","Control","--covar", examplepath + "/pcs.txt","--condition",condfile[1],"--out", tmpdir + "/4"],stdout=devnull, stderr=devnull)

stoptest=False
if test1 != 0:
    print("FAILED (trinculo returned non-zero code " + str(test1) + ")")
    stoptest=True

if not stoptest:
    test2 = os.path.isfile(tmpdir + "/4" + ".log") and os.path.isfile(tmpdir + "/4" + ".assoc.multinom")
    if not test2:
        print("FAILED (trinuculo failed to produce expected files)")
        stoptest=True

if not stoptest:
    test3 = hashlib.md5(open(tmpdir + '/4.assoc.multinom').read().encode('utf-8')).hexdigest()
    res3 = "3a03279b653d08ba73eac7f25f4ee302"
    if test3 != res3:
        print("FAILED (trinculo produced file with incorrect MD5 sum: " + tmpdir + '/4.assoc.multinom)')
        stoptest=True

if not stoptest:
    print("PASSED")


print("5. Testing Bayesian association...", end=' ')

test1 = subprocess.call([trinculo,"multinom","--bfile", examplepath + "/genotypes","--pheno", examplepath + "/phenos.txt","--phenoname","Pheno","--basepheno","Control","--covar", examplepath + "/pcs.txt","--normalize","--defaultprior","--out", tmpdir + "/5"],stdout=devnull, stderr=devnull)

stoptest=False
if test1 != 0:
    print("FAILED (trinculo returned non-zero code " + str(test1) + ")")
    stoptest=True

if not stoptest:
    test2 = os.path.isfile(tmpdir + "/5" + ".log") and os.path.isfile(tmpdir + "/5" + ".assoc.multinom")
    if not test2:
        print("FAILED (trinuculo failed to produce expected files)")
        stoptest=True

if not stoptest:
    test3 = hashlib.md5(open(tmpdir + '/5.assoc.multinom').read().encode('utf-8')).hexdigest()
    res3 = "417e85005a795e4f73475fa9a7c50de3"
    if test3 != res3:
        print("FAILED (trinculo produced file with incorrect MD5 sum: " + tmpdir + '/5.assoc.multinom)')
        stoptest=True

if not stoptest:
    print("PASSED")


print("6. Testing Bayesian association (prior file)...", end=' ')

test1 = subprocess.call([trinculo,"multinom","--bfile", examplepath + "/genotypes","--pheno", examplepath + "/phenos.txt","--phenoname","Pheno","--basepheno","Control","--covar", examplepath + "/pcs.txt","--normalize","--priors",examplepath + "/priors.txt","--out", tmpdir + "/6"],stdout=devnull, stderr=devnull)

stoptest=False
if test1 != 0:
    print("FAILED (trinculo returned non-zero code " + str(test1) + ")")
    stoptest=True

if not stoptest:
    test2 = os.path.isfile(tmpdir + "/6" + ".log") and os.path.isfile(tmpdir + "/6" + ".assoc.multinom")
    if not test2:
        print("FAILED (trinuculo failed to produce expected files)")
        stoptest=True

if not stoptest:
    test3 = hashlib.md5(open(tmpdir + '/6.assoc.multinom').read().encode('utf-8')).hexdigest()
    res3 = "417e85005a795e4f73475fa9a7c50de3"
    if test3 != res3:
        print("FAILED (trinculo produced file with incorrect MD5 sum: " + tmpdir + '/6.assoc.multinom)')
        stoptest=True

if not stoptest:
    print("PASSED")



print("7. Testing Bayesian model selection...", end=' ')

test1 = subprocess.call([trinculo,"multinom","--bfile", examplepath + "/genotypes","--pheno", examplepath + "/phenos.txt","--phenoname","Pheno","--basepheno","Control","--covar", examplepath + "/pcs.txt","--normalize","--defaultprior","--select","--out", tmpdir + "/7"],stdout=devnull, stderr=devnull)

stoptest=False
if test1 != 0:
    print("FAILED (trinculo returned non-zero code " + str(test1) + ")")
    stoptest=True

if not stoptest:
    test2 = os.path.isfile(tmpdir + "/7" + ".log") and os.path.isfile(tmpdir + "/7" + ".assoc.multinom") and os.path.isfile(tmpdir + "/7" + ".select.multinom")
    if not test2:
        print("FAILED (trinuculo failed to produce expected files)")
        stoptest=True

if not stoptest:
    test3 = hashlib.md5(open(tmpdir + '/7.select.multinom').read().encode('utf-8')).hexdigest()
    res3 = "39b9fadf0227dc788255cecfec780621"
    if test3 != res3:
        print("FAILED (trinculo produced file with incorrect MD5 sum: " + tmpdir + '/7.select.multinom)')
        stoptest=True

if not stoptest:
    print("PASSED")

print("8. Testing Bayesian model selection (empirical prior)...", end=' ')

test1 = subprocess.call([trinculo,"multinom","--bfile", examplepath + "/genotypes","--pheno", examplepath + "/phenos.txt","--phenoname","Pheno","--basepheno","Control","--covar", examplepath + "/pcs.txt","--normalize","--empiricalprior","--select","--out", tmpdir + "/8"],stdout=devnull, stderr=devnull)

stoptest=False
if test1 != 0:
    print("FAILED (trinculo returned non-zero code " + str(test1) + ")")
    stoptest=True

if not stoptest:
    test2 = os.path.isfile(tmpdir + "/8" + ".log") and os.path.isfile(tmpdir + "/8" + ".assoc.multinom") and os.path.isfile(tmpdir + "/8" + ".select.multinom") and os.path.isfile(tmpdir + "/8" + ".prior")
    if not test2:
        print("FAILED (trinuculo failed to produce expected files)")
        stoptest=True

if not stoptest:
    test3 = hashlib.md5(open(tmpdir + '/8.select.multinom').read().encode('utf-8')).hexdigest()
    res3 = "895f33f2ef961eac8d79c8bf141ffa25"
    if test3 != res3:
        print("FAILED (trinculo produced file with incorrect MD5 sum: " + tmpdir + '/8.select.multinom)')
        stoptest=True

if not stoptest:
    print("PASSED")

print("9. Testing ordinal regression...", end=' ')



test1 = subprocess.call([trinculo,"ordinal","--bfile", examplepath + "/genotypes","--pheno", examplepath + "/phenos.txt","--phenoname","Order","--covar", examplepath + "/pcs.txt","--out", tmpdir + "/9"],stdout=devnull, stderr=devnull)

stoptest=False
if test1 != 0:
    print("FAILED (trinculo returned non-zero code " + str(test1) + ")")
    stoptest=True

if not stoptest:
    test2 = os.path.isfile(tmpdir + "/9" + ".log") and os.path.isfile(tmpdir + "/9" + ".assoc.ordinal")
    if not test2:
        print("FAILED (trinuculo failed to produce expected files)")
        stoptest=True

if not stoptest:
    print("PASSED")
