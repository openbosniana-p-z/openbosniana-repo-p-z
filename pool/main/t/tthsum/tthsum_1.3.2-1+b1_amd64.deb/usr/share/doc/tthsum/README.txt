========================================================================
  README (tthsum tiger tree hash creator/verifier)       wjd, 2004-2009
========================================================================

  tthsum is an md5sum-alike program that works with Tiger/THEX hashes.
Use it to calculate TTH checksums and to compare those with previously
calculated sums (digests).

  For more information, see the man page or tthsum.html.

Copyright: Walter Doekes, 2004,2005,2009
Licensing: GPLv3, see COPYING.txt for details.


------------------------------------------------------------------------
  Building and installing
------------------------------------------------------------------------
  On a standad Linux distro you run `make' from the command line; on a
standard BSD run `gmake' to get GNU make; on Windows run
`nmake /f NMakefile' from a shell that has cl.exe and link.exe in its
path and has the appropriate environment variables set.

  Run `(g)make install' or `nmake /f NMakefile install' (on anyOS or
Windows respectively) to install the files in the locations specified
in the makefiles.

------------------------------------------------------------------------
  Getting tthsum
------------------------------------------------------------------------
  The latest version of tthsum can be found on: http://tthsum.devs.nu/


========================================================================
