from __future__ import annotations

from towncrier._shell import cli


cli()
