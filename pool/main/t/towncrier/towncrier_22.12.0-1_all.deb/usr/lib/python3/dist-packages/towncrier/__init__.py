# Copyright (c) Amber Brown, 2015
# See LICENSE for details.

"""
towncrier, a builder for your news files.
"""

from __future__ import annotations

from ._version import __version__


__all__ = ["__version__"]
