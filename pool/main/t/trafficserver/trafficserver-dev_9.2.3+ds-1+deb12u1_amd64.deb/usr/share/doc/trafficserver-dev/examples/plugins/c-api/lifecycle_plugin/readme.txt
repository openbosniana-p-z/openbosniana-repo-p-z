This prints debug messages about the lifecycle hooks.
