#include "Sacado_mpl_vector.hpp"
#include "Sacado_mpl_integral_c.hpp"

/* Ensemble Sizes Stokhos is configured to support */
#define HAVE_STOKHOS_ENSEMBLE_SIZES "16"

/* Default ensemble size to use in examples/tests */
#define STOKHOS_DEFAULT_ENSEMBLE_SIZE 16

namespace Stokhos {

  /* MPL list of ensemble sizes */
  typedef Sacado::mpl::vector< Sacado::mpl::integral_c<unsigned,16> > ETI_Ensemble_Sizes;

}
