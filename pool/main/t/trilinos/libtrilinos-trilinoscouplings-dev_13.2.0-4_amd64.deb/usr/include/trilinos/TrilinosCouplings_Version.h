#ifndef TRILINOSCOUPLINGS_VERSION_H
#define TRILINOSCOUPLINGS_VERSION_H

#include "TrilinosCouplings_ConfigDefs.h"
#ifndef TRILINOS_VERSION_H
# define TRILINOS_VERSION_H
# define TRILINOS_MAJOR_VERSION 13
# define TRILINOS_MAJOR_MINOR_VERSION 130200
# define TRILINOS_VERSION_STRING "130200"
#elif ( TRILINOS_MAJOR_VERSION != 13 ) \
   || ( TRILINOS_MAJOR_MINOR_VERSION != 130200 )
// don't know what to do. should not happen
# warning "trilinos version mismatch."
#endif /* TRILINOS_VERSION_H */

string TrilinosCouplings_Version() { 
  return("TrilinosCouplings in Trilinos " TRILINOS_VERSION_STRING); 
}

#endif /* TRILINOSCOUPLINGS_VERSION_H */
