#include "Ifpack2_OverlappingRowMatrix_decl.hpp"
