#include "Ifpack2_BorderedOperator_decl.hpp"
