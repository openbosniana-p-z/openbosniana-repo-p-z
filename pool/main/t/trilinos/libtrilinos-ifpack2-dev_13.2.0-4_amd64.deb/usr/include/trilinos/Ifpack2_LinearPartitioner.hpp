#include "Ifpack2_LinearPartitioner_decl.hpp"
