#include "Ifpack2_SingletonFilter_decl.hpp"
