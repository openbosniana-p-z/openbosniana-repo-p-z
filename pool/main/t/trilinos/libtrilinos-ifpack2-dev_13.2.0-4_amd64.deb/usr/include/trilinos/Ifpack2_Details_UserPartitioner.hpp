#include "Ifpack2_Details_UserPartitioner_decl.hpp"
