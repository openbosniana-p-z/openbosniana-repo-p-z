#include "Thyra_Ifpack2PreconditionerFactory_decl.hpp"
