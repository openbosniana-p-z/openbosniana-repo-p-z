#include "Ifpack2_Details_ScaledDampedResidual_decl.hpp"
