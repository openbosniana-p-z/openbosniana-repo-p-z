#include "Ifpack2_LocalFilter_decl.hpp"
