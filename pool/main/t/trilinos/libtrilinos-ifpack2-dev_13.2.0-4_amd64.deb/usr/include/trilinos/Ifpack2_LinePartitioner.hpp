#include "Ifpack2_LinePartitioner_decl.hpp"
