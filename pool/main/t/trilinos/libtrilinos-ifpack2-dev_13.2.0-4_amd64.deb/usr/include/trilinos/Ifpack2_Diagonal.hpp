#include "Ifpack2_Diagonal_decl.hpp"
