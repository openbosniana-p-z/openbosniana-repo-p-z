#include "Ifpack2_Details_Amesos2Wrapper_decl.hpp"
