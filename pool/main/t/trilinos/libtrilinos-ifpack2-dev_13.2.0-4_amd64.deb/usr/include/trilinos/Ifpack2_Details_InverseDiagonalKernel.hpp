#include "Ifpack2_Details_InverseDiagonalKernel_decl.hpp"
