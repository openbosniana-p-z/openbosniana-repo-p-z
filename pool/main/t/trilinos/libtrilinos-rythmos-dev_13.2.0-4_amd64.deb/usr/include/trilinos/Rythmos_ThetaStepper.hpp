#include "Rythmos_ThetaStepper_decl.hpp"
#ifndef HAVE_RYTHMOS_EXPLICIT_INSTANTIATION
#include "Rythmos_ThetaStepper_def.hpp"
#endif
