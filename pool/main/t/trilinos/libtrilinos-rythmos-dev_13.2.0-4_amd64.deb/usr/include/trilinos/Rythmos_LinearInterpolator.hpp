#include "Rythmos_LinearInterpolator_decl.hpp"
#ifndef HAVE_RYTHMOS_EXPLICIT_INSTANTIATION
#include "Rythmos_LinearInterpolator_def.hpp"
#endif



