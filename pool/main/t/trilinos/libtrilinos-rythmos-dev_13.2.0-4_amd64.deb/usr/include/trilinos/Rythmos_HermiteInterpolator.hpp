#include "Rythmos_HermiteInterpolator_decl.hpp"
#ifndef HAVE_RYTHMOS_EXPLICIT_INSTANTIATION
#include "Rythmos_HermiteInterpolator_def.hpp"
#endif




