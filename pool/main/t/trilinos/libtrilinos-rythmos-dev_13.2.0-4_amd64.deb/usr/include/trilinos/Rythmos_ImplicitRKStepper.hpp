#include "Rythmos_ImplicitRKStepper_decl.hpp"
#ifndef HAVE_RYTHMOS_EXPLICIT_INSTANTIATION
#include "Rythmos_ImplicitRKStepper_def.hpp"
#endif // HAVE_RYTHMOS_EXPLICIT_INSTANTIATION

