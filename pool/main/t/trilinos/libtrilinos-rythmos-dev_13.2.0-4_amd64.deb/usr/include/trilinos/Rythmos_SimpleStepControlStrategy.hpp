#include "Rythmos_SimpleStepControlStrategy_decl.hpp"
#ifndef HAVE_RYTHMOS_EXPLICIT_INSTANTIATION
#include "Rythmos_SimpleStepControlStrategy_def.hpp"
#endif
