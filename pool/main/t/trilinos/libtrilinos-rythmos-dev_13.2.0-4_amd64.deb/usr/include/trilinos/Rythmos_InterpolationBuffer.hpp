#include "Rythmos_InterpolationBuffer_decl.hpp"
#ifndef HAVE_RYTHMOS_EXPLICIT_INSTANTIATION
#include "Rythmos_InterpolationBuffer_def.hpp"
#endif // HAVE_RYTHMOS_EXPLICIT_INSTANTIATION


