#include "Rythmos_DataStore_decl.hpp"
#ifndef HAVE_RYTHMOS_EXPLICIT_INSTANTIATION
#include "Rythmos_DataStore_def.hpp"
#endif


