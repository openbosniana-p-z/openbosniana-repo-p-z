#include "Rythmos_RampingIntegrationControlStrategy_decl.hpp"
#ifndef HAVE_RYTHMOS_EXPLICIT_INSTANTIATION
#include "Rythmos_RampingIntegrationControlStrategy_def.hpp"
#endif


