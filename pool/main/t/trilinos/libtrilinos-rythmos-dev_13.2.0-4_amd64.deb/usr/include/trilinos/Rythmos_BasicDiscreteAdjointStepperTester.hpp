#include "Rythmos_BasicDiscreteAdjointStepperTester_decl.hpp"
#ifndef HAVE_RYTHMOS_EXPLICIT_INSTANTIATION
#include "Rythmos_BasicDiscreteAdjointStepperTester_def.hpp"
#endif


