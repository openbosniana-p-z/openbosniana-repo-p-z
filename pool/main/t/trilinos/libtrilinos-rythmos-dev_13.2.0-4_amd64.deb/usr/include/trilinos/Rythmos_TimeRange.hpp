#include "Rythmos_TimeRange_decl.hpp"
#ifndef HAVE_RYTHMOS_EXPLICIT_INSTANTIATION
#include "Rythmos_TimeRange_def.hpp"
#endif



