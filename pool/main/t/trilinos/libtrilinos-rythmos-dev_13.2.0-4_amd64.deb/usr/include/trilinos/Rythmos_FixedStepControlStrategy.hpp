#include "Rythmos_FixedStepControlStrategy_decl.hpp"
#ifndef HAVE_RYTHMOS_EXPLICIT_INSTANTIATION
#include "Rythmos_FixedStepControlStrategy_def.hpp"
#endif
