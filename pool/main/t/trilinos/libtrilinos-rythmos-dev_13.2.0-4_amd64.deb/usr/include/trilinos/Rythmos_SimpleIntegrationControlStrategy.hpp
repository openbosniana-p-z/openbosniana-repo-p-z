#include "Rythmos_SimpleIntegrationControlStrategy_decl.hpp"
#ifndef HAVE_RYTHMOS_EXPLICIT_INSTANTIATION
#include "Rythmos_SimpleIntegrationControlStrategy_def.hpp"
#endif


