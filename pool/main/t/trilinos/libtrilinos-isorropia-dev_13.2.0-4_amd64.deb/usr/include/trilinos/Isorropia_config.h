/* src/Isorropia_config.h.in.  Generated from configure.ac by autoheader.  */

/* define unconditionally since Isorropia depends on Epetra */
#define HAVE_EPETRA

/* Define if want to build with isorropia enabled */
#define HAVE_EPETRAEXT

/* define unconditionally since Isorropia depends on Zoltan */
#define HAVE_ISORROPIA_ZOLTAN

/* define if we want to use MPI */
#define HAVE_MPI

/* define if we want to use MPI */
/* #undef ISORROPIA_HAVE_OMP */
