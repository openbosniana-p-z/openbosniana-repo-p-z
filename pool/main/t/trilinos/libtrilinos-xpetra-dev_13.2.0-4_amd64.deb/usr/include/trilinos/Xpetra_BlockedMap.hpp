#include "Xpetra_BlockedMap_decl.hpp"
