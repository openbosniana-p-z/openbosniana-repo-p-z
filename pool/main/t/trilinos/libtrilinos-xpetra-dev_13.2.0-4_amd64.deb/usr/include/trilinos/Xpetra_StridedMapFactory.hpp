#include "Xpetra_StridedMapFactory_decl.hpp"
