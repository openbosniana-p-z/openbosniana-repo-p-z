#include "Xpetra_BlockedMultiVector_decl.hpp"
