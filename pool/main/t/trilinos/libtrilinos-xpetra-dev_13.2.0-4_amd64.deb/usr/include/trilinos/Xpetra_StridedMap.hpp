#include "Xpetra_StridedMap_decl.hpp"
