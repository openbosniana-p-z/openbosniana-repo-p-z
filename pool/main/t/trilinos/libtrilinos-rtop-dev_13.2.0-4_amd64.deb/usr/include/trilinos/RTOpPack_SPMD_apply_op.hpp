#include "RTOpPack_SPMD_apply_op_decl.hpp"
