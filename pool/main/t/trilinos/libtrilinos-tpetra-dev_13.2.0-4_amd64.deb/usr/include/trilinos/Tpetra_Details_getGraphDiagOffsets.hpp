#include "Tpetra_Details_getGraphDiagOffsets_decl.hpp"
