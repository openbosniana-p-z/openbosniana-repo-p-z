#include "Tpetra_LocalCrsMatrixOperator_decl.hpp"
