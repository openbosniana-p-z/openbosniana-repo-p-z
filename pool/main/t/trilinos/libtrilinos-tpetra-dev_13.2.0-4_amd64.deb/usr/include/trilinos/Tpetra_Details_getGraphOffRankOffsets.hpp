#include "Tpetra_Details_getGraphOffRankOffsets_decl.hpp"
