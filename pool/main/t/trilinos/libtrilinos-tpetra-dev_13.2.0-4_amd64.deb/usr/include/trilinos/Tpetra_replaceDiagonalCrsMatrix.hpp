#include "Tpetra_replaceDiagonalCrsMatrix_decl.hpp"
