#include "Tpetra_Details_localRowOffsets_decl.hpp"
