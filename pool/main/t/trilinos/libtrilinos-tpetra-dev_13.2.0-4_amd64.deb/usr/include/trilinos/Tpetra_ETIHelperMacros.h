// Header file for backwards compatibility.
#ifndef TPETRA_ETIHELPERMACROS_H
#define TPETRA_ETIHELPERMACROS_H

#include <TpetraCore_ETIHelperMacros.h>

#endif // TPETRA_ETIHELPERMACROS_H
