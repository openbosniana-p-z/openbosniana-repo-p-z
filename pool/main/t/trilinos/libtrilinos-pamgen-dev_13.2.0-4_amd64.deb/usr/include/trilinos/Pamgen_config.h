/* src/Pamgen_config.h.in.  Generated from configure.ac by autoheader.  */

/* Define if want to build examples */
/* #undef HAVE_EXAMPLES */

/* define if we want to use MPI */
#define HAVE_MPI

/* Define if want to build pamgen-examples */
/* #undef HAVE_PAMGEN_EXAMPLES */

/* Define if want to build pamgen-tests */
/* #undef HAVE_PAMGEN_TESTS */

/* Define if want to build tests */
/* #undef HAVE_TESTS */

/* Define if want to use nemesis */
/* #undef HAVE_PAMGEN_NEMESIS */

/* Define if we want to use boost */
#define HAVE_PAMGEN_BOOST
