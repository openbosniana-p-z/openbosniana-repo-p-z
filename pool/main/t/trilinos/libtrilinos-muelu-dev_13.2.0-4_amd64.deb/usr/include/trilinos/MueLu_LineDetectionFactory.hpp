#include "MueLu_LineDetectionFactory_decl.hpp"
