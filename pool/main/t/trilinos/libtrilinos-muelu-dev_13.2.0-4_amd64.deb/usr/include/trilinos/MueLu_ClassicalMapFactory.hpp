#include "MueLu_ClassicalMapFactory_decl.hpp"
