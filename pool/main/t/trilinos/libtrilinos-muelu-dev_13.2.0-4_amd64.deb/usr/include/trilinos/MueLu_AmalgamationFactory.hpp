#include "MueLu_AmalgamationFactory_decl.hpp"
