#include "MueLu_AmalgamationInfo_kokkos_decl.hpp"
