#include "MueLu_AggregationStructuredAlgorithm_decl.hpp"
