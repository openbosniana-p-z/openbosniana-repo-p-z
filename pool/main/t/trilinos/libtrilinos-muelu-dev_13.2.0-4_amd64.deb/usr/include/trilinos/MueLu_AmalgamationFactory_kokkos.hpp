#include "MueLu_AmalgamationFactory_kokkos_decl.hpp"
