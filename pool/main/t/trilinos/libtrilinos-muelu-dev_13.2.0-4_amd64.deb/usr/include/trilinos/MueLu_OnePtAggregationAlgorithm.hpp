#include "MueLu_OnePtAggregationAlgorithm_decl.hpp"
