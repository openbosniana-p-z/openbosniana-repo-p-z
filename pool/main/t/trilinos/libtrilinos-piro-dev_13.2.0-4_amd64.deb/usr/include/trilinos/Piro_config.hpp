#ifndef PIRO_CONFIG_HPP
#define PIRO_CONFIG_HPP

/* Define if want to build examples */
/* #undef HAVE_EXAMPLES */

/* Define if you want to build export makefiles. */
/* #undef HAVE_EXPORT_MAKEFILES */

/* Define if you are using gnumake - this will shorten your link lines. */
/* #undef HAVE_GNUMAKE */

/* define if we want to use MPI */
#define HAVE_MPI

/* Define if want to build piro-tests */
/* #undef HAVE_PIRO_TESTS */


/* Defines for optional package dependencies */
#define HAVE_PIRO_NOX
/* DEPRECATED */
#define Piro_ENABLE_NOX
#define HAVE_PIRO_RYTHMOS
/* DEPRECATED */
#define Piro_ENABLE_Rythmos
/* #undef HAVE_PIRO_TEMPUS */
/* DEPRECATED */
/* #undef Piro_ENABLE_Tempus */
#define HAVE_PIRO_STOKHOS
/* DEPRECATED */
#define Piro_ENABLE_Stokhos
/* #undef HAVE_PIRO_TRIKOTA */
/* DEPRECATED */
/* #undef Piro_ENABLE_TriKota */
#define HAVE_PIRO_ROL
/* DEPRECATED */
#define Piro_ENABLE_ROL
#define HAVE_PIRO_IFPACK2
/* DEPRECATED */
#define Piro_ENABLE_Ifpack2
#define HAVE_PIRO_MUELU
/* DEPRECATED */
#define Piro_ENABLE_MueLu
#define HAVE_PIRO_THYRAEPETRAADAPTERS
#define HAVE_PIRO_THYRAEPETRAEXTADAPTERS
#define HAVE_PIRO_EPETRA
#define HAVE_PIRO_EPETRAEXT
#define HAVE_PIRO_TPETRA
#define HAVE_PIRO_TEKO

/* Define to the address where bug reports for this package should be sent. */
/* #undef PACKAGE_BUGREPORT */

/* Define to the full name of this package. */
#define PACKAGE_NAME Piro

/* Define to the full name and version of this package. */
/* #undef PACKAGE_STRING */

/* Define to the one symbol short name of this package. */
/* #undef PACKAGE_TARNAME */

/* Define to the version of this package. */
/* #undef PACKAGE_VERSION */

#endif
