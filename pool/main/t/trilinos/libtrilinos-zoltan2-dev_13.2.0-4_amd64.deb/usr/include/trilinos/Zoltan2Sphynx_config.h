/* define if we have MueLu */
#define HAVE_ZOLTAN2SPHYNX_MUELU
