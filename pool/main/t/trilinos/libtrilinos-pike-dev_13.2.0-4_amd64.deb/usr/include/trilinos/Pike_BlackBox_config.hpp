#ifndef PIKE_BLACKBOX_CONFIG_HPP
#define PIKE_BLACKBOX_CONFIG_HPP

/* #undef HAVE_PIKE_DEBUG */

#define HAVE_PIKE_EXPLICIT_INSTANTIATION

/* #undef HAVE_PIKE_EXPERIMENTAL */

#ifndef PIKE_FUNC_TIME_MONITOR
#  define PIKE_TEUCHOS_TIME_MONITOR
#  define PIKE_FUNC_TIME_MONITOR(FUNCNAME) \
     TEUCHOS_FUNC_TIME_MONITOR_DIFF(FUNCNAME, PIKE)
#  define PIKE_FUNC_TIME_MONITOR_DIFF(FUNCNAME, DIFF) \
     TEUCHOS_FUNC_TIME_MONITOR_DIFF(FUNCNAME, DIFF)
#endif


#ifndef PIKE_DEPRECATED
#  if (__GNUC__ > 3 || (__GNUC__ == 3 && __GNUC_MINOR__ >= 1))
#    define PIKE_DEPRECATED  __attribute__((__deprecated__))
#  else
#    define PIKE_DEPRECATED
#  endif
#endif

#ifndef PIKE_DEPRECATED_MSG
#  if (__GNUC__ > 4 || (__GNUC__ == 4 && __GNUC_MINOR__ >= 5))
#    define PIKE_DEPRECATED_MSG(MSG)  __attribute__((__deprecated__ (#MSG) ))
#  elif (__GNUC__ > 3 || (__GNUC__ == 3 && __GNUC_MINOR__ >= 1))
#    define PIKE_DEPRECATED_MSG(MSG)  __attribute__((__deprecated__))
#  else
#    define PIKE_DEPRECATED_MSG(MSG)
#  endif
#endif


#endif
