#include "Thyra_DefaultSpmdVector_decl.hpp"
