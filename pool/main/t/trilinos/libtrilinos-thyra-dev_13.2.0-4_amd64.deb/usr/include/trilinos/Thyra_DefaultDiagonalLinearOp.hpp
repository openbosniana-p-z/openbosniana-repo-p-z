#include "Thyra_DefaultDiagonalLinearOp_decl.hpp"
