#include "Thyra_LinearOpDefaultBase_decl.hpp"
