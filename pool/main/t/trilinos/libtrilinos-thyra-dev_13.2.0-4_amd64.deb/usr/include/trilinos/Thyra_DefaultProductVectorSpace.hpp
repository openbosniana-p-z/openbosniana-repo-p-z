#include "Thyra_DefaultProductVectorSpace_decl.hpp"
