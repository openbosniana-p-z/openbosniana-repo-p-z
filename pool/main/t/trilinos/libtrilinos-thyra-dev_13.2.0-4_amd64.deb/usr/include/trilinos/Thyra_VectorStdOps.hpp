#include "Thyra_VectorStdOps_decl.hpp"
