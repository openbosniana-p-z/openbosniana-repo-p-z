#include "Thyra_apply_op_helper_decl.hpp"
