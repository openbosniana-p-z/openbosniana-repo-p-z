#include "Thyra_ScaledAdjointLinearOpBase_decl.hpp"
