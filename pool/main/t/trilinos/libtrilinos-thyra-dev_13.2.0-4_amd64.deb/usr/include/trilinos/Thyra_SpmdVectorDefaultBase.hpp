#include "Thyra_SpmdVectorDefaultBase_decl.hpp"
