#include "Thyra_EuclideanScalarProd_decl.hpp"
