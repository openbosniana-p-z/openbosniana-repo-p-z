#include "Thyra_DefaultAdjointLinearOpWithSolve_decl.hpp"
