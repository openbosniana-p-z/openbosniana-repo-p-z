#include "Thyra_DefaultSpmdVectorSpace_decl.hpp"
