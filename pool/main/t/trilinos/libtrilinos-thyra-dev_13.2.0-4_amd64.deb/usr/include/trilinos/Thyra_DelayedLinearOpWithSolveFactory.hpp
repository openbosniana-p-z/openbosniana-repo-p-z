#include "Thyra_DelayedLinearOpWithSolveFactory_decl.hpp"
