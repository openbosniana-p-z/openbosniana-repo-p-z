#include "Thyra_DelayedLinearOpWithSolve_decl.hpp"
