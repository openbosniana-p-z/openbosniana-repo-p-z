#include "Thyra_DefaultAddedLinearOp_decl.hpp"
