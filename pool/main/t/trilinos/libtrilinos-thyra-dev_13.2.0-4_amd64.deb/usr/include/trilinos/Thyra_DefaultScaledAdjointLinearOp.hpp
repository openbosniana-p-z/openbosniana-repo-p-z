#include "Thyra_DefaultScaledAdjointLinearOp_decl.hpp"
