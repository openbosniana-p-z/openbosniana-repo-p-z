#include "Thyra_VectorSpaceDefaultBase_decl.hpp"
