#include "Thyra_SpmdVectorSpaceBase_decl.hpp"
