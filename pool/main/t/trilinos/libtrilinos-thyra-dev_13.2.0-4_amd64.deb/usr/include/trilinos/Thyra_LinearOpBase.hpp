#include "Thyra_LinearOpBase_decl.hpp"
