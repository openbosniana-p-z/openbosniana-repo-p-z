#include "Thyra_VectorStdOpsTester_decl.hpp"
