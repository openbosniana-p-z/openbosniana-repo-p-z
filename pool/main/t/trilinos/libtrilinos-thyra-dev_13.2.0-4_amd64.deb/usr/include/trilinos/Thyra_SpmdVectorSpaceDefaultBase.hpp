#include "Thyra_SpmdVectorSpaceDefaultBase_decl.hpp"
