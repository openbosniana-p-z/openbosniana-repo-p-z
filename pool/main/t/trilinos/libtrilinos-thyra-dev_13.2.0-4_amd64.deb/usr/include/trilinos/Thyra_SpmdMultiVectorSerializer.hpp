#include "Thyra_SpmdMultiVectorSerializer_decl.hpp"
