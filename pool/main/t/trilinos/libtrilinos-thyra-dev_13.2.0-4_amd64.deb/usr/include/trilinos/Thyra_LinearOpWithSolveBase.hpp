#include "Thyra_LinearOpWithSolveBase_decl.hpp"
