#include "Thyra_SpmdLocalDataAccess_decl.hpp"
