#include "Thyra_ScalarProdVectorSpaceBase_decl.hpp"
