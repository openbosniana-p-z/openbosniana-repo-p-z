#include "Thyra_DefaultSpmdVectorSpaceFactory_decl.hpp"
