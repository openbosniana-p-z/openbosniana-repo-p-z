#include "Thyra_DefaultMultipliedLinearOp_decl.hpp"
