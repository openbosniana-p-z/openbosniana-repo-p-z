#include "Thyra_LinearOpScalarProd_decl.hpp"
