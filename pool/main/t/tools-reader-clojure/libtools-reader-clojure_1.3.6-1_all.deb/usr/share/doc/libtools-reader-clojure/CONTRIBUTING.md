This is a [Clojure contrib] project.

Under the Clojure contrib [guidelines], this project cannot accept
pull requests. All patches must be submitted via [JIRA].

See [Contributing] on the Clojure website for
more information on how to contribute.

[Clojure contrib]: https://clojure.org/community/contrib_libs
[Contributing]: https://clojure.org/community/contributing
[JIRA]: https://clojure.atlassian.net/browse/TRDR
[guidelines]: https://clojure.org/community/contrib_howto
