/* TooN/internal/config.hh.  Generated from config.hh.in by configure.  */
/* TooN/internal/config.hh.in.  Generated from configure.ac by autoheader.  */

/* define if the compiler supports basic C++14 syntax */
/* #undef HAVE_CXX14 */

/* Define to 1 if you have the `lapack' library (-llapack). */
#define HAVE_LIBLAPACK 1

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define PACKAGE_NAME "TooN"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "TooN version-3.0.0-beta1"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "toon"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "version-3.0.0-beta1"

/* Use LAPACK */
#define TOON_USE_LAPACK /**/
