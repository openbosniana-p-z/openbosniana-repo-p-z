class Trocla::Formats::Plain < Trocla::Formats::Base
  def format(plain_password, options = {})
    plain_password
  end
end
