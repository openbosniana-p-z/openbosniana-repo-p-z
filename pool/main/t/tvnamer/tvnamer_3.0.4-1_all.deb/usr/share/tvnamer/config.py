#!/usr/bin/env python

"""Holds Config singleton
"""

from tvnamer.config_defaults import defaults

Config = dict(defaults)
