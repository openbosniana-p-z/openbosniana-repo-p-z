/*
 * Author Jerry Lundström <jerry@dns-oarc.net>
 * Copyright (c) 2020, OARC, Inc.
 * All rights reserved.
 *
 * This file is part of the tinyframe library.
 *
 * tinyframe library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * tinyframe library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with tinyframe library.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __tinyframe_h_version
#define __tinyframe_h_version 1

#define TINYFRAME_VERSION 000000010001
#define TINYFRAME_VERSION_MAJOR 0000
#define TINYFRAME_VERSION_MINOR 0001
#define TINYFRAME_VERSION_PATCH 0001
#define TINYFRAME_VERSION_STRING "0.1.1"

#endif
