==============
Country Import
==============

Imports::

    >>> from proteus import Model
    >>> from trytond.tests.tools import activate_modules
    >>> from trytond.modules.country.scripts import import_countries, import_postal_codes

Activate modules::

    >>> config = activate_modules('country')

Import countries::

    >>> Country = Model.get('country.country')
    >>> belgium = Country(name="Belgium", code='BE')
    >>> belgium.save()

    >>> import_countries.do_import()

Import postal codes::

    >>> # The following test requires internet access, thus not for Debian
    >>> # import_postal_codes.do_import(['us'])
