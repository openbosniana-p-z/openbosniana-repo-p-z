# -mm-specific stuff.

# Remap .P so it does something.

req P parse-macro-args eol push-string ".sp .5v\n"
