
#ifndef TELEPATHY_LOGGER_QT_EXPORT_H
#define TELEPATHY_LOGGER_QT_EXPORT_H

#ifdef TELEPATHY_LOGGER_QT_STATIC_DEFINE
#  define TELEPATHY_LOGGER_QT_EXPORT
#  define TELEPATHY_LOGGER_QT_NO_EXPORT
#else
#  ifndef TELEPATHY_LOGGER_QT_EXPORT
#    ifdef telepathy_logger_qt_EXPORTS
        /* We are building this library */
#      define TELEPATHY_LOGGER_QT_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define TELEPATHY_LOGGER_QT_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef TELEPATHY_LOGGER_QT_NO_EXPORT
#    define TELEPATHY_LOGGER_QT_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef TELEPATHY_LOGGER_QT_DEPRECATED
#  define TELEPATHY_LOGGER_QT_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef TELEPATHY_LOGGER_QT_DEPRECATED_EXPORT
#  define TELEPATHY_LOGGER_QT_DEPRECATED_EXPORT TELEPATHY_LOGGER_QT_EXPORT TELEPATHY_LOGGER_QT_DEPRECATED
#endif

#ifndef TELEPATHY_LOGGER_QT_DEPRECATED_NO_EXPORT
#  define TELEPATHY_LOGGER_QT_DEPRECATED_NO_EXPORT TELEPATHY_LOGGER_QT_NO_EXPORT TELEPATHY_LOGGER_QT_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef TELEPATHY_LOGGER_QT_NO_DEPRECATED
#    define TELEPATHY_LOGGER_QT_NO_DEPRECATED
#  endif
#endif

#endif /* TELEPATHY_LOGGER_QT_EXPORT_H */
