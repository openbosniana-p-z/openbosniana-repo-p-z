This is a very simple website in pure tyxml using the jsx syntax extension.
To generate the website, compile `site_html.re` and then execute. This can be done with `make`.

Content of this directory:
- `site_html.re`: Generates the Html.
- `main.js` and `home.css` : auxiliary files for the website.
- `.merlin`: An appropriate merlin file.
- Readme.md : You are reading it

This website is distributed under the [unlicense][], feel free to use it!

[unlicense]: http://unlicense.org/
