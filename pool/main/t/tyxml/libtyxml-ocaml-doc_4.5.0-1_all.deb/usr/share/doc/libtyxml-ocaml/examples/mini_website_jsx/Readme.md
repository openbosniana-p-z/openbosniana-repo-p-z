This is the minimal website in pure tyxml using the jsx syntax extension.
To generate the website, compile `minihtml.re` and then execute. This can be done with `make`.

Content of this directory:
- `minihtml.re`: Generates the Html.
- `.merlin`: An appropriate merlin file.
- Readme.md : You are reading it

This website is distributed under the [unlicense][], feel free to use it!

[unlicense]: http://unlicense.org/
