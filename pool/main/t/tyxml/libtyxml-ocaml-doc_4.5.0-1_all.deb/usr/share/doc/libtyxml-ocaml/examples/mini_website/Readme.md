This is the minimal website in pure tyxml. To generate the website, compile `minihtml.ml` and then execute. This can be done with `make`.

Content of this directory:
- `minihtml.ml`: Generates the Html.
- `Makefile`: Simple rules to create the website.
- `.merlin`: An appropriate merlin file.
- Readme.md : You are reading it

This website is distributed under the [unlicense][], feel free to use it!

[unlicense]: http://unlicense.org/
