var searchData=
[
  ['random_5fgenerator_156',['random_generator',['../classtiny__dnn_1_1random__generator.html',1,'tiny_dnn']]],
  ['rebind_157',['rebind',['../structtiny__dnn_1_1aligned__allocator_1_1rebind.html',1,'tiny_dnn::aligned_allocator']]],
  ['relu_158',['relu',['../classtiny__dnn_1_1activation_1_1relu.html',1,'tiny_dnn::activation']]],
  ['result_159',['result',['../structtiny__dnn_1_1result.html',1,'tiny_dnn']]],
  ['rmsprop_160',['RMSprop',['../structtiny__dnn_1_1RMSprop.html',1,'tiny_dnn']]]
];
