var searchData=
[
  ['he_241',['he',['../classtiny__dnn_1_1weight__init_1_1he.html',1,'tiny_dnn::weight_init']]]
];
