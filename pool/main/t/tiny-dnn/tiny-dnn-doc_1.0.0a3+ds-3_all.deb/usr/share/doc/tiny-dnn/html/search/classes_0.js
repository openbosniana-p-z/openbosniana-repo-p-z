var searchData=
[
  ['absolute_190',['absolute',['../classtiny__dnn_1_1absolute.html',1,'tiny_dnn']]],
  ['absolute_5feps_191',['absolute_eps',['../classtiny__dnn_1_1absolute__eps.html',1,'tiny_dnn']]],
  ['adagrad_192',['adagrad',['../structtiny__dnn_1_1adagrad.html',1,'tiny_dnn']]],
  ['adam_193',['adam',['../structtiny__dnn_1_1adam.html',1,'tiny_dnn']]],
  ['alexnet_194',['alexnet',['../classmodels_1_1alexnet.html',1,'models']]],
  ['aligned_5fallocator_195',['aligned_allocator',['../classtiny__dnn_1_1aligned__allocator.html',1,'tiny_dnn']]],
  ['average_5fpooling_5flayer_196',['average_pooling_layer',['../classtiny__dnn_1_1average__pooling__layer.html',1,'tiny_dnn']]],
  ['average_5funpooling_5flayer_197',['average_unpooling_layer',['../classtiny__dnn_1_1average__unpooling__layer.html',1,'tiny_dnn']]],
  ['avx_5fbackend_198',['avx_backend',['../classtiny__dnn_1_1core_1_1avx__backend.html',1,'tiny_dnn::core']]]
];
