var searchData=
[
  ['tan_5fh_302',['tan_h',['../classtiny__dnn_1_1activation_1_1tan__h.html',1,'tiny_dnn::activation']]],
  ['tan_5fhp1m2_303',['tan_hp1m2',['../classtiny__dnn_1_1activation_1_1tan__hp1m2.html',1,'tiny_dnn::activation']]],
  ['tensor_304',['Tensor',['../classtiny__dnn_1_1Tensor.html',1,'tiny_dnn']]],
  ['timer_305',['timer',['../classtiny__dnn_1_1timer.html',1,'tiny_dnn']]],
  ['tiny_5fbackend_306',['tiny_backend',['../classtiny__dnn_1_1core_1_1tiny__backend.html',1,'tiny_dnn::core']]]
];
