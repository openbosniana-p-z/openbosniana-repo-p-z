var searchData=
[
  ['_7ebatch_5fnormalization_5flayer_375',['~batch_normalization_layer',['../classtiny__dnn_1_1batch__normalization__layer.html#ab811d22a603e321ab44ebed32d39ca61',1,'tiny_dnn::batch_normalization_layer']]]
];
