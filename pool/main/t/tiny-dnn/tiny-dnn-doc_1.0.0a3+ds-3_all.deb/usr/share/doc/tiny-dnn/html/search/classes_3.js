var searchData=
[
  ['deconv_5flayer_5fworker_5fspecific_5fstorage_218',['deconv_layer_worker_specific_storage',['../structtiny__dnn_1_1core_1_1deconv__layer__worker__specific__storage.html',1,'tiny_dnn::core']]],
  ['deconv_5fparams_219',['deconv_params',['../structtiny__dnn_1_1core_1_1deconv__params.html',1,'tiny_dnn::core']]],
  ['deconvolutional_5flayer_220',['deconvolutional_layer',['../classtiny__dnn_1_1deconvolutional__layer.html',1,'tiny_dnn']]],
  ['deserialization_5fhelper_221',['deserialization_helper',['../classtiny__dnn_1_1deserialization__helper.html',1,'tiny_dnn']]],
  ['device_222',['Device',['../classtiny__dnn_1_1Device.html',1,'tiny_dnn']]],
  ['dnn_5fbackend_223',['dnn_backend',['../classtiny__dnn_1_1core_1_1dnn__backend.html',1,'tiny_dnn::core']]],
  ['dropout_5flayer_224',['dropout_layer',['../classtiny__dnn_1_1dropout__layer.html',1,'tiny_dnn']]]
];
