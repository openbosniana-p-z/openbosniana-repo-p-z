var searchData=
[
  ['save_161',['save',['../classtiny__dnn_1_1network.html#a4efa3fe083b8d1e66ece6373c53efaaf',1,'tiny_dnn::network']]],
  ['scalable_162',['scalable',['../classtiny__dnn_1_1weight__init_1_1scalable.html',1,'tiny_dnn::weight_init']]],
  ['sequential_163',['sequential',['../classtiny__dnn_1_1sequential.html',1,'tiny_dnn']]],
  ['serialization_5fhelper_164',['serialization_helper',['../classtiny__dnn_1_1serialization__helper.html',1,'tiny_dnn']]],
  ['session_165',['session',['../classtiny__dnn_1_1core_1_1session.html',1,'tiny_dnn::core']]],
  ['set_5fcontext_166',['set_context',['../classtiny__dnn_1_1layer.html#ab8b8a68041ed53d265326444f619e0ba',1,'tiny_dnn::layer::set_context()'],['../classtiny__dnn_1_1dropout__layer.html#af95c02e1804c06a04002b9d189dc7211',1,'tiny_dnn::dropout_layer::set_context()'],['../classtiny__dnn_1_1batch__normalization__layer.html#a1ac945fdedef100360ada63e9ad6e670',1,'tiny_dnn::batch_normalization_layer::set_context()']]],
  ['set_5fnetphase_167',['set_netphase',['../classtiny__dnn_1_1network.html#a0228cad8a5c55cdd8809c4c9ad7f989a',1,'tiny_dnn::network']]],
  ['setup_168',['setup',['../classtiny__dnn_1_1nodes.html#af9a543b10b5fb154737d609f2b2c70c8',1,'tiny_dnn::nodes']]],
  ['sigmoid_169',['sigmoid',['../classtiny__dnn_1_1activation_1_1sigmoid.html',1,'tiny_dnn::activation']]],
  ['slice_5flayer_170',['slice_layer',['../classtiny__dnn_1_1slice__layer.html#a2d539b088d838b03204fa2b0ee02ad0c',1,'tiny_dnn::slice_layer::slice_layer()'],['../classtiny__dnn_1_1slice__layer.html',1,'tiny_dnn::slice_layer']]],
  ['softmax_171',['softmax',['../classtiny__dnn_1_1activation_1_1softmax.html',1,'tiny_dnn::activation']]],
  ['stateful_5foptimizer_172',['stateful_optimizer',['../structtiny__dnn_1_1stateful__optimizer.html',1,'tiny_dnn']]],
  ['stateful_5foptimizer_3c_201_20_3e_173',['stateful_optimizer&lt; 1 &gt;',['../structtiny__dnn_1_1stateful__optimizer.html',1,'tiny_dnn']]],
  ['stateful_5foptimizer_3c_202_20_3e_174',['stateful_optimizer&lt; 2 &gt;',['../structtiny__dnn_1_1stateful__optimizer.html',1,'tiny_dnn']]]
];
