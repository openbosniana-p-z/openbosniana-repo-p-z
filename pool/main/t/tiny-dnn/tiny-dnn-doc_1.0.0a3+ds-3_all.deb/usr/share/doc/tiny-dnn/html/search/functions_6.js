var searchData=
[
  ['generate_331',['generate',['../classtiny__dnn_1_1graph__visualizer.html#a7ce08269cc26f9443eeca7b6b6ae87ef',1,'tiny_dnn::graph_visualizer']]],
  ['get_5floss_332',['get_loss',['../classtiny__dnn_1_1network.html#a642d34bfae83cf4bcae862d56bcff14c',1,'tiny_dnn::network::get_loss(const std::vector&lt; vec_t &gt; &amp;in, const std::vector&lt; vec_t &gt; &amp;t)'],['../classtiny__dnn_1_1network.html#a5025b0b4cacdded64013b2e26006e615',1,'tiny_dnn::network::get_loss(const std::vector&lt; T &gt; &amp;in, const std::vector&lt; tensor_t &gt; &amp;t)']]],
  ['gradient_5fcheck_333',['gradient_check',['../classtiny__dnn_1_1network.html#a92290b927a139ffc2f37320d90e42f62',1,'tiny_dnn::network']]]
];
