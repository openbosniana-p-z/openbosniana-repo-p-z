var searchData=
[
  ['update_5fweights_186',['update_weights',['../classtiny__dnn_1_1nodes.html#a68786f8b147c2ec04f6cae260fe2338e',1,'tiny_dnn::nodes']]]
];
