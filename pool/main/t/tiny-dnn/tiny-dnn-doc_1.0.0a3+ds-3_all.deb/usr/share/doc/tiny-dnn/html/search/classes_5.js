var searchData=
[
  ['feedforward_5flayer_228',['feedforward_layer',['../classtiny__dnn_1_1feedforward__layer.html',1,'tiny_dnn']]],
  ['feedforward_5flayer_3c_20activation_3a_3aidentity_20_3e_229',['feedforward_layer&lt; activation::identity &gt;',['../classtiny__dnn_1_1feedforward__layer.html',1,'tiny_dnn']]],
  ['foobar_230',['foobar',['../structfoobar.html',1,'']]],
  ['fully_5fconnected_5flayer_231',['fully_connected_layer',['../classtiny__dnn_1_1fully__connected__layer.html',1,'tiny_dnn']]],
  ['fully_5fparams_232',['fully_params',['../classtiny__dnn_1_1core_1_1fully__params.html',1,'tiny_dnn::core']]],
  ['fullyconnectedgradop_233',['FullyConnectedGradOp',['../classtiny__dnn_1_1FullyConnectedGradOp.html',1,'tiny_dnn']]],
  ['fullyconnectedop_234',['FullyConnectedOp',['../classtiny__dnn_1_1FullyConnectedOp.html',1,'tiny_dnn']]],
  ['function_235',['function',['../classtiny__dnn_1_1activation_1_1function.html',1,'tiny_dnn::activation::function'],['../classtiny__dnn_1_1weight__init_1_1function.html',1,'tiny_dnn::weight_init::function']]]
];
