var searchData=
[
  ['changing_20from_20v0_2e0_2e1_387',['Changing from v0.0.1',['../md_docs_update_log_v0_0_1_to_v0_1_0.html',1,'']]],
  ['cifar_2d10_20classification_20example_388',['Cifar-10 Classification Example',['../md_examples_cifar10_readme.html',1,'']]]
];
