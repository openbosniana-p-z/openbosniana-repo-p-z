var searchData=
[
  ['backend_199',['backend',['../classtiny__dnn_1_1core_1_1backend.html',1,'tiny_dnn::core']]],
  ['batch_5fnormalization_5flayer_200',['batch_normalization_layer',['../classtiny__dnn_1_1batch__normalization__layer.html',1,'tiny_dnn']]],
  ['blocked_5frange_201',['blocked_range',['../structtiny__dnn_1_1blocked__range.html',1,'tiny_dnn']]]
];
