var searchData=
[
  ['weight_5finit_187',['weight_init',['../classtiny__dnn_1_1network.html#a4573d77b3734f80bb227dfe34e5858b9',1,'tiny_dnn::network']]]
];
