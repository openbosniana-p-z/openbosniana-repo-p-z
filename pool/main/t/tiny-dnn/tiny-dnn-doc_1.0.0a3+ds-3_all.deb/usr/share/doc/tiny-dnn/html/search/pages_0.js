var searchData=
[
  ['a_20quick_20introduction_20to_20tiny_2ddnn_385',['A quick introduction to tiny-dnn',['../md_docs_getting_started_Getting_started.html',1,'']]],
  ['adding_20a_20new_20layer_386',['Adding a new layer',['../md_docs_developer_guides_Adding_a_new_layer.html',1,'']]]
];
