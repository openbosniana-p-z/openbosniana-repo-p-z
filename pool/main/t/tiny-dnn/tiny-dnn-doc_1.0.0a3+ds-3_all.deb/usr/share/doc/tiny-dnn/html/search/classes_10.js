var searchData=
[
  ['scalable_292',['scalable',['../classtiny__dnn_1_1weight__init_1_1scalable.html',1,'tiny_dnn::weight_init']]],
  ['sequential_293',['sequential',['../classtiny__dnn_1_1sequential.html',1,'tiny_dnn']]],
  ['serialization_5fhelper_294',['serialization_helper',['../classtiny__dnn_1_1serialization__helper.html',1,'tiny_dnn']]],
  ['session_295',['session',['../classtiny__dnn_1_1core_1_1session.html',1,'tiny_dnn::core']]],
  ['sigmoid_296',['sigmoid',['../classtiny__dnn_1_1activation_1_1sigmoid.html',1,'tiny_dnn::activation']]],
  ['slice_5flayer_297',['slice_layer',['../classtiny__dnn_1_1slice__layer.html',1,'tiny_dnn']]],
  ['softmax_298',['softmax',['../classtiny__dnn_1_1activation_1_1softmax.html',1,'tiny_dnn::activation']]],
  ['stateful_5foptimizer_299',['stateful_optimizer',['../structtiny__dnn_1_1stateful__optimizer.html',1,'tiny_dnn']]],
  ['stateful_5foptimizer_3c_201_20_3e_300',['stateful_optimizer&lt; 1 &gt;',['../structtiny__dnn_1_1stateful__optimizer.html',1,'tiny_dnn']]],
  ['stateful_5foptimizer_3c_202_20_3e_301',['stateful_optimizer&lt; 2 &gt;',['../structtiny__dnn_1_1stateful__optimizer.html',1,'tiny_dnn']]]
];
