var searchData=
[
  ['tan_5fh_175',['tan_h',['../classtiny__dnn_1_1activation_1_1tan__h.html',1,'tiny_dnn::activation']]],
  ['tan_5fhp1m2_176',['tan_hp1m2',['../classtiny__dnn_1_1activation_1_1tan__hp1m2.html',1,'tiny_dnn::activation']]],
  ['tensor_177',['Tensor',['../classtiny__dnn_1_1Tensor.html',1,'tiny_dnn']]],
  ['test_178',['test',['../classtiny__dnn_1_1network.html#a4fc8276135415b9b0c80195e729d05b9',1,'tiny_dnn::network::test(const std::vector&lt; vec_t &gt; &amp;in, const std::vector&lt; label_t &gt; &amp;t)'],['../classtiny__dnn_1_1network.html#a734a27404a26433a7c413241dc32e167',1,'tiny_dnn::network::test(const std::vector&lt; vec_t &gt; &amp;in)']]],
  ['timer_179',['timer',['../classtiny__dnn_1_1timer.html',1,'tiny_dnn']]],
  ['tiny_2ddnn_20documentations_180',['tiny-dnn documentations',['../index.html',1,'']]],
  ['tiny_5fbackend_181',['tiny_backend',['../classtiny__dnn_1_1core_1_1tiny__backend.html',1,'tiny_dnn::core']]],
  ['to_5fjson_182',['to_json',['../classtiny__dnn_1_1network.html#a3eedf63b5aaa72a8330075fac33488c7',1,'tiny_dnn::network']]],
  ['todo_20list_183',['Todo List',['../todo.html',1,'']]],
  ['train_184',['train',['../classtiny__dnn_1_1network.html#a39b6025371ff3271136f869911716d03',1,'tiny_dnn::network::train(Optimizer &amp;optimizer, const std::vector&lt; vec_t &gt; &amp;inputs, const std::vector&lt; label_t &gt; &amp;class_labels, size_t batch_size, int epoch, OnBatchEnumerate on_batch_enumerate, OnEpochEnumerate on_epoch_enumerate, const bool reset_weights=false, const int n_threads=CNN_TASK_SIZE, const std::vector&lt; vec_t &gt; &amp;t_cost=std::vector&lt; vec_t &gt;())'],['../classtiny__dnn_1_1network.html#ab5a3a3663ede1929382ad4cb62346ce2',1,'tiny_dnn::network::train(Optimizer &amp;optimizer, const std::vector&lt; vec_t &gt; &amp;inputs, const std::vector&lt; label_t &gt; &amp;class_labels, size_t batch_size=1, int epoch=1)'],['../classtiny__dnn_1_1network.html#a731e141331998cf0203edb86a7b80209',1,'tiny_dnn::network::train(Optimizer &amp;optimizer, const std::vector&lt; vec_t &gt; &amp;in, const std::vector&lt; vec_t &gt; &amp;t, size_t batch_size=1, int epoch=1)']]],
  ['train_20network_20with_20your_20original_20dataset_185',['Train network with your original dataset',['../md_docs_how_tos_Train_network_with_your_dataset.html',1,'']]]
];
