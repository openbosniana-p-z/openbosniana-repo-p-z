var searchData=
[
  ['edge_225',['edge',['../classtiny__dnn_1_1edge.html',1,'tiny_dnn']]],
  ['elementwise_5fadd_5flayer_226',['elementwise_add_layer',['../classtiny__dnn_1_1elementwise__add__layer.html',1,'tiny_dnn']]],
  ['elu_227',['elu',['../classtiny__dnn_1_1activation_1_1elu.html',1,'tiny_dnn::activation']]]
];
