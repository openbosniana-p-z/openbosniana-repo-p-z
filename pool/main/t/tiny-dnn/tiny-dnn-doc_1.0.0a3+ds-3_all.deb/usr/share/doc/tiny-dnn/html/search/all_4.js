var searchData=
[
  ['edge_49',['edge',['../classtiny__dnn_1_1edge.html',1,'tiny_dnn']]],
  ['elementwise_5fadd_5flayer_50',['elementwise_add_layer',['../classtiny__dnn_1_1elementwise__add__layer.html#ad2577f818c7f4d7c14525ae2d6b07c7e',1,'tiny_dnn::elementwise_add_layer::elementwise_add_layer()'],['../classtiny__dnn_1_1elementwise__add__layer.html',1,'tiny_dnn::elementwise_add_layer']]],
  ['elu_51',['elu',['../classtiny__dnn_1_1activation_1_1elu.html',1,'tiny_dnn::activation']]]
];
