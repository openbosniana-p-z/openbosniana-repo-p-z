var searchData=
[
  ['parallelize_5f_140',['parallelize_',['../classtiny__dnn_1_1layer.html#aca5ad5db186cab5d9cf083d7633de1eb',1,'tiny_dnn::layer']]],
  ['params_141',['Params',['../classtiny__dnn_1_1core_1_1Params.html',1,'tiny_dnn::core']]],
  ['partial_5fconnected_5flayer_142',['partial_connected_layer',['../classtiny__dnn_1_1partial__connected__layer.html',1,'tiny_dnn']]],
  ['partial_5fconnected_5flayer_3c_20activation_3a_3aidentity_20_3e_143',['partial_connected_layer&lt; activation::identity &gt;',['../classtiny__dnn_1_1partial__connected__layer.html',1,'tiny_dnn']]],
  ['post_5fupdate_144',['post_update',['../classtiny__dnn_1_1batch__normalization__layer.html#a3631947a5eb1611362ae1f8bd39b72a6',1,'tiny_dnn::batch_normalization_layer::post_update()'],['../classtiny__dnn_1_1layer.html#a7379f2de1a0af419a67365d9b5e1fe70',1,'tiny_dnn::layer::post_update()']]],
  ['power_5flayer_145',['power_layer',['../classtiny__dnn_1_1power__layer.html#acdaa31cf0925912162f61d602b636fdf',1,'tiny_dnn::power_layer::power_layer(const shape3d &amp;in_shape, float_t factor, float_t scale=1.0f)'],['../classtiny__dnn_1_1power__layer.html#a3bda18eacc09dbc7b40e4d3b8036b984',1,'tiny_dnn::power_layer::power_layer(const layer &amp;prev_layer, float_t factor, float_t scale=1.0f)'],['../classtiny__dnn_1_1power__layer.html',1,'tiny_dnn::power_layer']]],
  ['predict_146',['predict',['../classtiny__dnn_1_1network.html#a168d244499e0739c4c2ff28fcc79d002',1,'tiny_dnn::network::predict(const vec_t &amp;in)'],['../classtiny__dnn_1_1network.html#aa7db7c62365d64c9206f05408bae7c73',1,'tiny_dnn::network::predict(const tensor_t &amp;in)'],['../classtiny__dnn_1_1network.html#a4936db088730f1dd9c3417525efe26c9',1,'tiny_dnn::network::predict(const std::vector&lt; tensor_t &gt; &amp;in)'],['../classtiny__dnn_1_1network.html#a44dddb4178c4cfd5bd669024db7a0290',1,'tiny_dnn::network::predict(const Range &amp;in)']]],
  ['predict_5flabel_147',['predict_label',['../classtiny__dnn_1_1network.html#a7fa20eb925a1e2d43a864d21b2f44fcd',1,'tiny_dnn::network']]],
  ['predict_5fmax_5fvalue_148',['predict_max_value',['../classtiny__dnn_1_1network.html#adfea9492a91a938fba388b316603dbea',1,'tiny_dnn::network']]],
  ['program_149',['Program',['../classtiny__dnn_1_1Program.html',1,'tiny_dnn']]],
  ['programhash_150',['ProgramHash',['../classtiny__dnn_1_1ProgramHash.html',1,'tiny_dnn']]],
  ['programmanager_151',['ProgramManager',['../classtiny__dnn_1_1ProgramManager.html',1,'tiny_dnn']]],
  ['progress_5fdisplay_152',['progress_display',['../classtiny__dnn_1_1progress__display.html',1,'tiny_dnn']]]
];
