var searchData=
[
  ['name_350',['name',['../classtiny__dnn_1_1network.html#af52387758157f60063f7be20c4814a1d',1,'tiny_dnn::network']]]
];
