var searchData=
[
  ['quantized_5fconvolutional_5flayer_284',['quantized_convolutional_layer',['../classtiny__dnn_1_1quantized__convolutional__layer.html',1,'tiny_dnn']]],
  ['quantized_5fdeconvolutional_5flayer_285',['quantized_deconvolutional_layer',['../classtiny__dnn_1_1quantized__deconvolutional__layer.html',1,'tiny_dnn']]],
  ['quantized_5ffully_5fconnected_5flayer_286',['quantized_fully_connected_layer',['../classtiny__dnn_1_1quantized__fully__connected__layer.html',1,'tiny_dnn']]]
];
