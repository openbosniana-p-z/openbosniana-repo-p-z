var searchData=
[
  ['gaussian_236',['gaussian',['../classtiny__dnn_1_1weight__init_1_1gaussian.html',1,'tiny_dnn::weight_init']]],
  ['generic_5fvec_5ftype_237',['generic_vec_type',['../structvectorize_1_1detail_1_1generic__vec__type.html',1,'vectorize::detail']]],
  ['gradient_5fdescent_238',['gradient_descent',['../structtiny__dnn_1_1gradient__descent.html',1,'tiny_dnn']]],
  ['graph_239',['graph',['../classtiny__dnn_1_1graph.html',1,'tiny_dnn']]],
  ['graph_5fvisualizer_240',['graph_visualizer',['../classtiny__dnn_1_1graph__visualizer.html',1,'tiny_dnn']]]
];
