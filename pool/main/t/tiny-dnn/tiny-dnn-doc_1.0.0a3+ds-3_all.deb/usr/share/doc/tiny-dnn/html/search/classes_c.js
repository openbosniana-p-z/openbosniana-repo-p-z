var searchData=
[
  ['opkernel_271',['OpKernel',['../classtiny__dnn_1_1core_1_1OpKernel.html',1,'tiny_dnn::core']]],
  ['opkernelconstruction_272',['OpKernelConstruction',['../classtiny__dnn_1_1core_1_1OpKernelConstruction.html',1,'tiny_dnn::core']]],
  ['opkernelcontext_273',['OpKernelContext',['../classtiny__dnn_1_1core_1_1OpKernelContext.html',1,'tiny_dnn::core']]],
  ['opparams_274',['OpParams',['../structtiny__dnn_1_1core_1_1OpKernelContext_1_1OpParams.html',1,'tiny_dnn::core::OpKernelContext']]],
  ['optimizer_275',['optimizer',['../structtiny__dnn_1_1optimizer.html',1,'tiny_dnn']]]
];
