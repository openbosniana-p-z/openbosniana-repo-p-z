var searchData=
[
  ['layer_247',['layer',['../classtiny__dnn_1_1layer.html',1,'tiny_dnn']]],
  ['layer_5fnode_248',['layer_node',['../structtiny__dnn_1_1detail_1_1layer__node.html',1,'tiny_dnn::detail']]],
  ['leaky_5frelu_249',['leaky_relu',['../classtiny__dnn_1_1activation_1_1leaky__relu.html',1,'tiny_dnn::activation']]],
  ['lecun_250',['lecun',['../classtiny__dnn_1_1weight__init_1_1lecun.html',1,'tiny_dnn::weight_init']]],
  ['linear_5flayer_251',['linear_layer',['../classtiny__dnn_1_1linear__layer.html',1,'tiny_dnn']]],
  ['lrn_5flayer_252',['lrn_layer',['../classtiny__dnn_1_1lrn__layer.html',1,'tiny_dnn']]]
];
