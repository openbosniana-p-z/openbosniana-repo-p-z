var searchData=
[
  ['max_5fpooling_5flayer_105',['max_pooling_layer',['../classtiny__dnn_1_1max__pooling__layer.html#a1de3a14b9a8d53f354cb85f69c8bb4e6',1,'tiny_dnn::max_pooling_layer::max_pooling_layer(serial_size_t in_width, serial_size_t in_height, serial_size_t in_channels, serial_size_t pooling_size, backend_t backend_type=core::default_engine())'],['../classtiny__dnn_1_1max__pooling__layer.html#a651e9ef889db06b21a78e041f386d2e7',1,'tiny_dnn::max_pooling_layer::max_pooling_layer(serial_size_t in_width, serial_size_t in_height, serial_size_t in_channels, serial_size_t pooling_size_x, serial_size_t pooling_size_y, serial_size_t stride_x, serial_size_t stride_y, padding pad_type=padding::valid, backend_t backend_type=core::default_engine())'],['../classtiny__dnn_1_1max__pooling__layer.html',1,'tiny_dnn::max_pooling_layer&lt; Activation &gt;']]],
  ['max_5fpooling_5flayer_5fworker_5fspecific_5fstorage_106',['max_pooling_layer_worker_specific_storage',['../structtiny__dnn_1_1core_1_1max__pooling__layer__worker__specific__storage.html',1,'tiny_dnn::core']]],
  ['max_5funpooling_5flayer_107',['max_unpooling_layer',['../classtiny__dnn_1_1max__unpooling__layer.html#a4b47bf2cb08c915676736a935eb6ed7d',1,'tiny_dnn::max_unpooling_layer::max_unpooling_layer(serial_size_t in_width, serial_size_t in_height, serial_size_t in_channels, serial_size_t unpooling_size)'],['../classtiny__dnn_1_1max__unpooling__layer.html#a45c6faee61148057f2246ad9695f5479',1,'tiny_dnn::max_unpooling_layer::max_unpooling_layer(serial_size_t in_width, serial_size_t in_height, serial_size_t in_channels, serial_size_t unpooling_size, serial_size_t stride)'],['../classtiny__dnn_1_1max__unpooling__layer.html',1,'tiny_dnn::max_unpooling_layer&lt; Activation &gt;']]],
  ['maxpool_108',['maxpool',['../classtiny__dnn_1_1core_1_1nnp__backend.html#ae8a99619c86898d5e268e7bec336d95b',1,'tiny_dnn::core::nnp_backend']]],
  ['maxpool_5fparams_109',['maxpool_params',['../classtiny__dnn_1_1core_1_1maxpool__params.html',1,'tiny_dnn::core']]],
  ['maxpoolgradop_110',['MaxPoolGradOp',['../classtiny__dnn_1_1MaxPoolGradOp.html',1,'tiny_dnn']]],
  ['maxpoolop_111',['MaxPoolOp',['../classtiny__dnn_1_1MaxPoolOp.html',1,'tiny_dnn']]],
  ['mnist_20digit_20classification_112',['MNIST Digit Classification',['../md_examples_mnist_readme.html',1,'']]],
  ['mnist_20reconstruction_20and_20classification_20with_20deconvolutional_20auto_2dencoder_113',['MNIST Reconstruction and Classification with Deconvolutional Auto-encoder',['../md_examples_deconv_readme.html',1,'']]],
  ['mnist_5fheader_114',['mnist_header',['../structtiny__dnn_1_1detail_1_1mnist__header.html',1,'tiny_dnn::detail']]],
  ['momentum_115',['momentum',['../structtiny__dnn_1_1momentum.html',1,'tiny_dnn']]],
  ['mse_116',['mse',['../classtiny__dnn_1_1mse.html',1,'tiny_dnn']]]
];
