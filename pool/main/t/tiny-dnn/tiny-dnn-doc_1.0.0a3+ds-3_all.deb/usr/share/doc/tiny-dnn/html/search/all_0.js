var searchData=
[
  ['a_20quick_20introduction_20to_20tiny_2ddnn_0',['A quick introduction to tiny-dnn',['../md_docs_getting_started_Getting_started.html',1,'']]],
  ['absolute_1',['absolute',['../classtiny__dnn_1_1absolute.html',1,'tiny_dnn']]],
  ['absolute_5feps_2',['absolute_eps',['../classtiny__dnn_1_1absolute__eps.html',1,'tiny_dnn']]],
  ['adagrad_3',['adagrad',['../structtiny__dnn_1_1adagrad.html',1,'tiny_dnn']]],
  ['adam_4',['adam',['../structtiny__dnn_1_1adam.html',1,'tiny_dnn']]],
  ['adding_20a_20new_20layer_5',['Adding a new layer',['../md_docs_developer_guides_Adding_a_new_layer.html',1,'']]],
  ['alexnet_6',['alexnet',['../classmodels_1_1alexnet.html',1,'models']]],
  ['aligned_5fallocator_7',['aligned_allocator',['../classtiny__dnn_1_1aligned__allocator.html',1,'tiny_dnn']]],
  ['at_8',['at',['../classtiny__dnn_1_1network.html#af4807f9a6896f952666d0f37c84fae0b',1,'tiny_dnn::network']]],
  ['average_5fpooling_5flayer_9',['average_pooling_layer',['../classtiny__dnn_1_1average__pooling__layer.html#a925675e44432d081de1e48977e77b23d',1,'tiny_dnn::average_pooling_layer::average_pooling_layer(serial_size_t in_width, serial_size_t in_height, serial_size_t in_channels, serial_size_t pool_size)'],['../classtiny__dnn_1_1average__pooling__layer.html#a636724956e279195c93d87af88a96763',1,'tiny_dnn::average_pooling_layer::average_pooling_layer(serial_size_t in_width, serial_size_t in_height, serial_size_t in_channels, serial_size_t pool_size, serial_size_t stride)'],['../classtiny__dnn_1_1average__pooling__layer.html#a88cb6a5d1bdf95a5d265da711facadc5',1,'tiny_dnn::average_pooling_layer::average_pooling_layer(serial_size_t in_width, serial_size_t in_height, serial_size_t in_channels, serial_size_t pool_size_x, serial_size_t pool_size_y, serial_size_t stride_x, serial_size_t stride_y, padding pad_type=padding::valid)'],['../classtiny__dnn_1_1average__pooling__layer.html',1,'tiny_dnn::average_pooling_layer&lt; Activation &gt;']]],
  ['average_5funpooling_5flayer_10',['average_unpooling_layer',['../classtiny__dnn_1_1average__unpooling__layer.html#ac1eff0391c3b676f6d9bdd59b307b884',1,'tiny_dnn::average_unpooling_layer::average_unpooling_layer(serial_size_t in_width, serial_size_t in_height, serial_size_t in_channels, serial_size_t pooling_size)'],['../classtiny__dnn_1_1average__unpooling__layer.html#a97403f58a6325c74aa84b8f25c19da82',1,'tiny_dnn::average_unpooling_layer::average_unpooling_layer(serial_size_t in_width, serial_size_t in_height, serial_size_t in_channels, serial_size_t pooling_size, serial_size_t stride)'],['../classtiny__dnn_1_1average__unpooling__layer.html',1,'tiny_dnn::average_unpooling_layer&lt; Activation &gt;']]],
  ['avx_5fbackend_11',['avx_backend',['../classtiny__dnn_1_1core_1_1avx__backend.html',1,'tiny_dnn::core']]]
];
