var searchData=
[
  ['xavier_188',['xavier',['../classtiny__dnn_1_1weight__init_1_1xavier.html',1,'tiny_dnn::weight_init']]]
];
