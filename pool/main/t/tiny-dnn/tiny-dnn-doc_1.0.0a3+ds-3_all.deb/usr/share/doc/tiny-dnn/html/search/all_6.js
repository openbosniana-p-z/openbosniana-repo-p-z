var searchData=
[
  ['gaussian_67',['gaussian',['../classtiny__dnn_1_1weight__init_1_1gaussian.html',1,'tiny_dnn::weight_init']]],
  ['generate_68',['generate',['../classtiny__dnn_1_1graph__visualizer.html#a7ce08269cc26f9443eeca7b6b6ae87ef',1,'tiny_dnn::graph_visualizer']]],
  ['generic_5fvec_5ftype_69',['generic_vec_type',['../structvectorize_1_1detail_1_1generic__vec__type.html',1,'vectorize::detail']]],
  ['get_5floss_70',['get_loss',['../classtiny__dnn_1_1network.html#a642d34bfae83cf4bcae862d56bcff14c',1,'tiny_dnn::network::get_loss(const std::vector&lt; vec_t &gt; &amp;in, const std::vector&lt; vec_t &gt; &amp;t)'],['../classtiny__dnn_1_1network.html#a5025b0b4cacdded64013b2e26006e615',1,'tiny_dnn::network::get_loss(const std::vector&lt; T &gt; &amp;in, const std::vector&lt; tensor_t &gt; &amp;t)']]],
  ['gradient_5fcheck_71',['gradient_check',['../classtiny__dnn_1_1network.html#a92290b927a139ffc2f37320d90e42f62',1,'tiny_dnn::network']]],
  ['gradient_5fdescent_72',['gradient_descent',['../structtiny__dnn_1_1gradient__descent.html',1,'tiny_dnn']]],
  ['graph_73',['graph',['../classtiny__dnn_1_1graph.html',1,'tiny_dnn']]],
  ['graph_5fvisualizer_74',['graph_visualizer',['../classtiny__dnn_1_1graph__visualizer.html',1,'tiny_dnn']]],
  ['guild_20for_20ios_20demo_75',['Guild for iOS demo',['../md_examples_ios_readme.html',1,'']]]
];
