from todoman import version  # type: ignore

__version__ = version.version
__documentation__ = "/usr/share/doc/todoman/html/"
