from todoman.cli import cli

if __name__ == "__main__":
    cli(auto_envvar_prefix="TODOMAN")
