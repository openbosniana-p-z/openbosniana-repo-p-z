from __future__ import unicode_literals

TOMBO_VERSION = '1.5.1'
