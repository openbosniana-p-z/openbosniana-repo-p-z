"""This module handles collecting and persisting in json format a tox session"""
from .result import ResultLog

__all__ = ("ResultLog",)
