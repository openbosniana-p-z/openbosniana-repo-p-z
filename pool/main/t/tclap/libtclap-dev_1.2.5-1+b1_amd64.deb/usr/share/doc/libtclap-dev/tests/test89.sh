#!/bin/bash

./test_wrapper $srcdir/test89.out ../examples/test28
