#!/bin/sh
# failure
./test_wrapper $srcdir/test51.out ../examples/test8 '-s=one homer -B'
