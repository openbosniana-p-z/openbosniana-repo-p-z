#!/bin/sh
# failure
./test_wrapper $srcdir/test18.out ../examples/test4 '-Bs --Bs asdf'
