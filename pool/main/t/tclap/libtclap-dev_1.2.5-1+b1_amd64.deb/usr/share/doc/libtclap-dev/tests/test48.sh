#!/bin/sh
# success
./test_wrapper $srcdir/test48.out ../examples/test8 '-s=aaa homer marge bart -- one two'
