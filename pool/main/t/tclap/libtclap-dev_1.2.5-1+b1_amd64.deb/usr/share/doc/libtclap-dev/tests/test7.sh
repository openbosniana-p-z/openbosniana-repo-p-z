#!/bin/sh
# success
./test_wrapper $srcdir/test7.out ../examples/test2 '-i 10 -s hello goodbye -hABC'
