#!/bin/sh
# success
./test_wrapper $srcdir/test13.out ../examples/test3 '--stringTest=bill -i=9 -i=8 -B homer marge bart'
