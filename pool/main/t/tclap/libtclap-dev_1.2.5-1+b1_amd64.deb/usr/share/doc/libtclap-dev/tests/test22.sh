#!/bin/sh
# failure
./test_wrapper $srcdir/test22.out ../examples/test5 '-a fdsa -b asdf -c fdas'
