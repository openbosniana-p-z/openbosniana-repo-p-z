#!/bin/sh
# success
./test_wrapper $srcdir/test37.out ../examples/test7 '-n homer 2 -n marge 1 3'
