#!/bin/sh
# success
./test_wrapper $srcdir/test34.out ../examples/test6 '-n homer 2'
