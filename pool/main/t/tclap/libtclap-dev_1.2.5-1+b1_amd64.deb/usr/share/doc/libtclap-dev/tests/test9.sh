#!/bin/sh
# success
./test_wrapper $srcdir/test9.out ../examples/test2 '-i 10 -s hello goodbye -- -hv one two'
