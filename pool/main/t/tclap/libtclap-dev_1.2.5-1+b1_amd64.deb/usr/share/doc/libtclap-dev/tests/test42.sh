#!/bin/sh
# success
./test_wrapper $srcdir/test42.out ../examples/test3 '--help' 
