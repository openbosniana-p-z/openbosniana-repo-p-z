#!/bin/sh
# success
./test_wrapper $srcdir/test6.out ../examples/test2 '-i 10 -s hello goodbye -ABC'
