#!/bin/sh
# failure
./test_wrapper $srcdir/test52.out ../examples/test8 '-i=9a -i=1 -s=asdf asdf asdf'
