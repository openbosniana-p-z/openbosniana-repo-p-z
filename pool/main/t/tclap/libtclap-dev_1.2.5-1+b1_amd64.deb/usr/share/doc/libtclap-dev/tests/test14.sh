#!/bin/sh
# success
./test_wrapper $srcdir/test14.out ../examples/test3  '--stringTest=aaa homer marge bart -- one two'
