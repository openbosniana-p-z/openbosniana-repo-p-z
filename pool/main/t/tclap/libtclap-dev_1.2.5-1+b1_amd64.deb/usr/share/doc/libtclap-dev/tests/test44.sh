#!/bin/sh
# success
./test_wrapper $srcdir/test44.out ../examples/test5 '--help' 
