#!/bin/sh
# success  test octal
./test_wrapper $srcdir/test72.out ../examples/test19 '-i 012'
