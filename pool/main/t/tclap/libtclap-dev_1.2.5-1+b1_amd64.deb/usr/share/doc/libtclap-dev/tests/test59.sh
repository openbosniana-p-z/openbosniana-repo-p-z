#!/bin/sh
# success
./test_wrapper $srcdir/test59.out ../examples/test9 '-VVV -N --noise -r blah'
