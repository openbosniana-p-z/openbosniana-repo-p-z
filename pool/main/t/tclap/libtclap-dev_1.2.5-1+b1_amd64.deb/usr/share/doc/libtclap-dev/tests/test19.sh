#!/bin/sh
# success
./test_wrapper $srcdir/test19.out ../examples/test4 '-BA --Bs asdf'
