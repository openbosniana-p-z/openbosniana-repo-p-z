#!/bin/sh

# failure, still looking for -n 
./test_wrapper $srcdir/test81.out ../examples/test22 'asdf  asdf -r fds xxx'
