#!/bin/sh
# success
./test_wrapper $srcdir/test40.out ../examples/test1 '--help' 
