#!/bin/sh
# failure
./test_wrapper $srcdir/test50.out ../examples/test8 '-s one homer -B -Bh'
