#!/bin/sh
# failure
./test_wrapper $srcdir/test10.out ../examples/test2 '-i 10 -s hello'
