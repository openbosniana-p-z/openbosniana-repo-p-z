#!/bin/bash

./test_wrapper $srcdir/test91.out ../examples/test30 '-p "1 2.3"'
