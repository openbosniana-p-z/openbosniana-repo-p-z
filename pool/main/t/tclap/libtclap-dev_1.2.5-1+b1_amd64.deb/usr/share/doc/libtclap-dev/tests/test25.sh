#!/bin/sh
# success
./test_wrapper $srcdir/test25.out ../examples/test5 '--aaa asdf -c fdas --fff blah -i one -i two'
