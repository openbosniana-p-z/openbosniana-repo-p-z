#!/bin/sh
# failure
./test_wrapper $srcdir/test39.out ../examples/test7 '2 -n homer -n bart 6'
