#!/bin/sh
# success
./test_wrapper $srcdir/test43.out ../examples/test4 '--help' 
