#!/bin/sh
# failure
./test_wrapper $srcdir/test32.out ../examples/test3 '-f=9 -f=1.0.0 -s=asdf asdf asdf'
