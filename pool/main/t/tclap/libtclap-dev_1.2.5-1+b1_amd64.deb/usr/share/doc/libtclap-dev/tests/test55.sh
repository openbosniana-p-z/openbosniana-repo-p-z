#!/bin/sh
# success
./test_wrapper $srcdir/test55.out ../examples/test3 '--stringTest=asdf - asdf zero one'
