#!/bin/sh
# failure
./test_wrapper $srcdir/test38.out ../examples/test7 '-n mike 2 1' 
