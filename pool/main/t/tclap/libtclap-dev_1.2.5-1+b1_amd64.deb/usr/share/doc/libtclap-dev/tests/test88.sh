#!/bin/bash

./test_wrapper $srcdir/test88.out ../examples/test27
