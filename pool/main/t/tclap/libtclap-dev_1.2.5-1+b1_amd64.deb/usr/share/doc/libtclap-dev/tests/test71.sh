#!/bin/sh
# success test hex
./test_wrapper $srcdir/test71.out ../examples/test19 '-i 0xA'
