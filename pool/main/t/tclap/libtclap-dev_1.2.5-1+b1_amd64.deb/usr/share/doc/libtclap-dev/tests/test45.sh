#!/bin/sh
# success
./test_wrapper $srcdir/test45.out ../examples/test6 '--help'
