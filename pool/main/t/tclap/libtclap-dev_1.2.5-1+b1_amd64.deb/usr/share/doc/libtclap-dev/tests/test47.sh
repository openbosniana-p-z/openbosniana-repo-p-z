#!/bin/sh
# success
./test_wrapper $srcdir/test47.out ../examples/test8 '-s=bill -i=9 -i=8 -B homer marge bart'
