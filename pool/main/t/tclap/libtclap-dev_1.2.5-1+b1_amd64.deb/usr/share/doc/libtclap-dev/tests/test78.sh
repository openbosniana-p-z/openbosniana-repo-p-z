#!/bin/sh
# success
./test_wrapper $srcdir/test78.out ../examples/test21 '~~reverse /n mike'
