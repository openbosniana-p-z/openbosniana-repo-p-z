#!/bin/sh
# success
./test_wrapper $srcdir/test56.out ../examples/test2 '-i 1 - -s fdsa one two'
