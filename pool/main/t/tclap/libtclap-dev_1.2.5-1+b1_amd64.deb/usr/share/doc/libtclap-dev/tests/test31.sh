#!/bin/sh
# failure
./test_wrapper $srcdir/test31.out ../examples/test3 '-i=9a -i=1 -s=asdf asdf asdf'
