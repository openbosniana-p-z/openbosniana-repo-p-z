#!/bin/sh
# success
./test_wrapper $srcdir/test21.out ../examples/test5 '-b asdf -c fdas -g asdf -j homer'
