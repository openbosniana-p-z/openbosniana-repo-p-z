#!/bin/sh

./test_wrapper $srcdir/test86.out ../examples/test14 '-v "3.2 -47.11 0"'
