#!/bin/sh
# failure
./test_wrapper $srcdir/test17.out ../examples/test3  '--stringTest=one homer -B'
