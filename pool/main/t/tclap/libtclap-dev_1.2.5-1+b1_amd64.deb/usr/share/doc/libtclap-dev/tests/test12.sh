#!/bin/sh
# failure
./test_wrapper $srcdir/test12.out ../examples/test2 '-i 10 -s hello -f nine'
