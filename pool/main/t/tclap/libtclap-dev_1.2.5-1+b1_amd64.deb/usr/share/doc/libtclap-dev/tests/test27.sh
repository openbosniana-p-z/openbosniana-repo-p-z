#!/bin/sh
# failure
./test_wrapper $srcdir/test27.out ../examples/test2 '-i 2 -f 4.0.2 -s asdf asdf'
