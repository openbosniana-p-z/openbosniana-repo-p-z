#!/bin/sh
# failure
./test_wrapper $srcdir/test23.out ../examples/test5 '-d junk -c fdas'
