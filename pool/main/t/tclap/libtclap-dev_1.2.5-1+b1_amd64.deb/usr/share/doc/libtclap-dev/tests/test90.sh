#!/bin/bash

./test_wrapper $srcdir/test90.out ../examples/test29
