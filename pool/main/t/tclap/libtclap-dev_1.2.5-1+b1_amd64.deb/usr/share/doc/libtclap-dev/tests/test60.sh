#!/bin/sh
# failure
./test_wrapper $srcdir/test60.out ../examples/test9 '-VVV -N --noise -rr'
