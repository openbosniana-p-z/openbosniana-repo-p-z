#!/bin/sh
# failure
./test_wrapper $srcdir/test28.out ../examples/test2 '-i 2a -f 4.2 -s asdf asdf'
