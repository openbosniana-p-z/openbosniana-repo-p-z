#!/bin/sh
# failure
./test_wrapper $srcdir/test15.out ../examples/test3  '--stringTest bbb homer marge bart -- -hv two'
