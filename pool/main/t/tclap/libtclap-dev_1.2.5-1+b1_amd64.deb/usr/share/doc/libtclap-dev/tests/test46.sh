#!/bin/sh
# success
./test_wrapper $srcdir/test46.out ../examples/test7 '--help' 
