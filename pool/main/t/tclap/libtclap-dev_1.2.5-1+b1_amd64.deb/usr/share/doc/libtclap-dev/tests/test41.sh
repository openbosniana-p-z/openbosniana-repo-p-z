#!/bin/sh
# success
./test_wrapper $srcdir/test41.out ../examples/test2 '--help' 
