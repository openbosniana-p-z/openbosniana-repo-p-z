#!/bin/sh
# failure
./test_wrapper $srcdir/test4.out ../examples/test1
