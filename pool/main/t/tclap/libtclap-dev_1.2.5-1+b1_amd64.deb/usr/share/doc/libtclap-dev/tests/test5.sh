#!/bin/sh
# success
./test_wrapper $srcdir/test5.out ../examples/test2 '-i 10 -s homer marge bart lisa'
