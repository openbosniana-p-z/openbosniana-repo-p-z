#!/bin/sh
# success
./test_wrapper $srcdir/test3.out ../examples/test1 '-n mike -r'
