#!/bin/sh
# success
./test_wrapper $srcdir/test33.out ../examples/test5 '-a asdf -c fdas --eee blah --ddd -j o --jjj t'
