#!/bin/sh
# failure...  no hex here, but see test19.cpp for how to use hex 
./test_wrapper $srcdir/test29.out ../examples/test2 '-i 0xA -f 4.2 -s asdf asdf'
