#!/bin/sh

./test_wrapper $srcdir/test1.out ../examples/test1 '-r -n mike'
