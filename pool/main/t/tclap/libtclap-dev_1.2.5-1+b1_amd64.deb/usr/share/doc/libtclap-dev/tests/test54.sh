#!/bin/sh
# success
./test_wrapper $srcdir/test54.out ../examples/test8 '--help' 
