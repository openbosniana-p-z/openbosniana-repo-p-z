#!/bin/sh

# success
./test_wrapper $srcdir/test79.out ../examples/test21
