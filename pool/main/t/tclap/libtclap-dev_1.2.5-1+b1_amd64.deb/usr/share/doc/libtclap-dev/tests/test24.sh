#!/bin/sh
# failure
./test_wrapper $srcdir/test24.out ../examples/test5 '--aaa dilbert -b asdf -c fdas'
