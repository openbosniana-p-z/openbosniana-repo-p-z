#!/bin/sh
# failure
./test_wrapper $srcdir/test35.out ../examples/test6 '-n mike 2' 
