#!/bin/sh
# failure
./test_wrapper $srcdir/test49.out ../examples/test8 '-s bbb homer marge bart -- -hv two'
