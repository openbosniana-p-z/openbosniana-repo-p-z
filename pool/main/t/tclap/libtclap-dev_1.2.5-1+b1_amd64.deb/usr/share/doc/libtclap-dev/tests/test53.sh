#!/bin/sh
# failure
./test_wrapper $srcdir/test53.out ../examples/test8 '-f=9 -f=1.0.0 -s=asdf asdf asdf'
