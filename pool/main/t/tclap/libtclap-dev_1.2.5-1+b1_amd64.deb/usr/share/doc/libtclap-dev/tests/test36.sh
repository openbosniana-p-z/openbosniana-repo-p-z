#!/bin/sh
# failure
./test_wrapper $srcdir/test36.out ../examples/test6 '-n homer 6'
