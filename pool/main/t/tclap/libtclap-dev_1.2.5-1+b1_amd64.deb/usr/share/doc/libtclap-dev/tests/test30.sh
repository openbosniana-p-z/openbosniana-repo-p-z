#!/bin/sh
# failure
./test_wrapper $srcdir/test30.out ../examples/test2 '-i 2.1 -f 4.2 -s asdf asdf'
