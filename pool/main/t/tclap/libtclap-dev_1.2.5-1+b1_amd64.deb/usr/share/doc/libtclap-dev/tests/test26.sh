#!/bin/sh
# failure
./test_wrapper $srcdir/test26.out ../examples/test2 '-i 2 -f 4..2 -s asdf asdf'
