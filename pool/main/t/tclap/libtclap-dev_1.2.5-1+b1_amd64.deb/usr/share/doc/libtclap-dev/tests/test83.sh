#!/bin/sh

# success
./test_wrapper $srcdir/test83.out ../examples/test24
