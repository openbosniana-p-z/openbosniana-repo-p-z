#!/bin/sh
# success
./test_wrapper $srcdir/test8.out ../examples/test2 '--version'
