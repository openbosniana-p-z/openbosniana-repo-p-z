#!/bin/sh
# success
./test_wrapper $srcdir/test58.out ../examples/test9
