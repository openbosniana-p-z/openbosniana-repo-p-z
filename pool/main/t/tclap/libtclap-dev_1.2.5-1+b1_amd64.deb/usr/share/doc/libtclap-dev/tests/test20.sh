#!/bin/sh
# success
./test_wrapper $srcdir/test20.out ../examples/test5 '-a asdf -c fdas --eee blah -i sss -i fdsf'
