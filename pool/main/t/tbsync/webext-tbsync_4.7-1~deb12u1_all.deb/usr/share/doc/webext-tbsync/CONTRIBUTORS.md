## Creator
* John Bieling

## Contributors
* John Bieling
* Jan Dagefoerde
* Nam Ldmpub
* Fonic

## Translators
* John Bieling (de, en-US)
* Wanderlei Hüttel (pt-BR)
* Alessandro Menti (it)
* Óvári (hu)
* Alexey Sinitsyn (ru)
* Daniel Wróblewski (pl)
