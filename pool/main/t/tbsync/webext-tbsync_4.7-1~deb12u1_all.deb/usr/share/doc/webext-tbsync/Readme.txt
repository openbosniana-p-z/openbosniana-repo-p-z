Want to add or fix a localization?

To help translating this project, please visit 

	https://crowdin.com/profile/jobisoft

where the localizations are managed. If you want to add
a new language, just contact me and I will set it up.
