module Type_abstract = Type_abstract
module Type_equal = Type_equal
module Type_generic = Type_generic
module Typename = Typename
module Make_typename = Make_typename
module Type_named_intf = Named_intf
module Typerepable = Typerepable
module Typerep_obj = Typerep_obj
include Std_internal
