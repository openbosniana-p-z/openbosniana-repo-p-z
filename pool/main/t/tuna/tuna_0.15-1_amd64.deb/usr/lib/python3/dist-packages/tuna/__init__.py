"""
Copyright (c) 2008, 2009 Red Hat Inc.

Application Tuning GUI
"""
__author__ = "Arnaldo Carvalho de Melo <acme@redhat.com>"
__license__ = "GPLv2 License"
