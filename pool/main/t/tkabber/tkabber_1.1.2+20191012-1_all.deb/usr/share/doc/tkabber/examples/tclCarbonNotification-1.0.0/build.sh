#!/bin/sh

critcl -pkg tclCarbonNotification.tcl
