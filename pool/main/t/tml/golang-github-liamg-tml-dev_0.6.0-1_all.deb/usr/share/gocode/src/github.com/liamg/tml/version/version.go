package version

// Version of tml - set on build
var Version = "dev"