package tml

// NewLine prints a new line to the terminal with no content
func NewLine() {
    Println("")
}
