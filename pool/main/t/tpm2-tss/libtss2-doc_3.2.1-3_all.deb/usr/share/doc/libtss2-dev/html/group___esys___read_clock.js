var group___esys___read_clock =
[
    [ "Esys_ReadClock", "group___esys___read_clock.html#ga6004e33015685030d238a165ffaf8c4c", null ],
    [ "Esys_ReadClock_Async", "group___esys___read_clock.html#gad80793ae2afdd8b5b23dba0d8b0a252c", null ],
    [ "Esys_ReadClock_Finish", "group___esys___read_clock.html#ga971e3f42d473eacb6387353b9b119370", null ]
];