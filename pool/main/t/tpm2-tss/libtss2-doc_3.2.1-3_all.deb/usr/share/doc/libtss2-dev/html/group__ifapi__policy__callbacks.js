var group__ifapi__policy__callbacks =
[
    [ "ifapi_branch_selection", "group__ifapi__policy__callbacks.html#gac886bf2a0cd070979c90bc4423e3d343", null ],
    [ "ifapi_exec_auth_nv_policy", "group__ifapi__policy__callbacks.html#ga10715ee791f9a8a37c071cafa85dc7e1", null ],
    [ "ifapi_get_duplicate_name", "group__ifapi__policy__callbacks.html#gaf778195543972a79fc9ab0b6756e97ef", null ],
    [ "ifapi_get_key_public", "group__ifapi__policy__callbacks.html#ga297e58a7ce5c56556862ec819e2dafd4", null ],
    [ "ifapi_get_object_name", "group__ifapi__policy__callbacks.html#ga7b6fe64874f104dd78e2bf52daa552ab", null ],
    [ "ifapi_policy_action", "group__ifapi__policy__callbacks.html#gadd7eb66246e0cf577e7483d982327b8e", null ],
    [ "ifapi_policyeval_cbauth", "group__ifapi__policy__callbacks.html#ga0b46c66ee5f543af5eecca6373c2a6e4", null ],
    [ "ifapi_read_pcr", "group__ifapi__policy__callbacks.html#gaf73e9ba8195cf4e4a0133d66f18009da", null ]
];