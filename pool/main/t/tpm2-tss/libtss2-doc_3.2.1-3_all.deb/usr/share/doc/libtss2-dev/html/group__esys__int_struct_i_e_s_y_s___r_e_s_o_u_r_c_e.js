var group__esys__int_struct_i_e_s_y_s___r_e_s_o_u_r_c_e =
[
    [ "handle", "group__esys__int.html#a092e62b7e8fba38c269167a77a28f482", null ],
    [ "misc", "group__esys__int.html#aeb9e271b418591bece67ed825c3f943e", null ],
    [ "name", "group__esys__int.html#aa6ec8dddc97ebcafb145d444aa264a48", null ],
    [ "rsrcType", "group__esys__int.html#a498133ad172b9f9f437773e6fedf25cb", null ]
];