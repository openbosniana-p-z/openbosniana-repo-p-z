var group___fapi___nv_extend =
[
    [ "Fapi_NvExtend", "group___fapi___nv_extend.html#gab80509e6c7302081baf27e2de9b6ee7c", null ],
    [ "Fapi_NvExtend_Async", "group___fapi___nv_extend.html#gad46012aa6e6b5f88371ba5787e29cad0", null ],
    [ "Fapi_NvExtend_Finish", "group___fapi___nv_extend.html#gaab101560cdb5bf40119104f8b2d8a254", null ]
];