var group___esys___get_time =
[
    [ "Esys_GetTime", "group___esys___get_time.html#gaeac70392aafceb71ad539c0f4ecf6924", null ],
    [ "Esys_GetTime_Async", "group___esys___get_time.html#ga344041d2af9781b410dc178118ac5e31", null ],
    [ "Esys_GetTime_Finish", "group___esys___get_time.html#ga525cc634019b36b626bf993194e12d76", null ]
];