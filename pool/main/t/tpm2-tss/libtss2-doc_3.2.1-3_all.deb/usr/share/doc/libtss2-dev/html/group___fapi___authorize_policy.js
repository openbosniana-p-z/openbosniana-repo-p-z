var group___fapi___authorize_policy =
[
    [ "Fapi_AuthorizePolicy", "group___fapi___authorize_policy.html#ga91fa6daecab1fa84c45fd9dfacf12f21", null ],
    [ "Fapi_AuthorizePolicy_Async", "group___fapi___authorize_policy.html#ga7f69f41925a6eb9c88e7aa22e6e7d13d", null ],
    [ "Fapi_AuthorizePolicy_Finish", "group___fapi___authorize_policy.html#ga59a9d17f342ee247f09e31751481944c", null ]
];