var group___fapi___create_nv =
[
    [ "Fapi_CreateNv", "group___fapi___create_nv.html#gabdea8a4a9aa6c07589bd01f80c373117", null ],
    [ "Fapi_CreateNv_Async", "group___fapi___create_nv.html#gadd3eb9d5fd4a941d2d52c798eeef6c79", null ],
    [ "Fapi_CreateNv_Finish", "group___fapi___create_nv.html#ga9591e43cd9a21fa112c78e56d0b5b45a", null ]
];