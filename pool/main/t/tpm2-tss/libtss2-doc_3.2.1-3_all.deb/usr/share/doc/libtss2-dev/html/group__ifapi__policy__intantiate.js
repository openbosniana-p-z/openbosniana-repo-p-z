var group__ifapi__policy__intantiate =
[
    [ "ifapi_policyeval_instantiate_async", "group__ifapi__policy__intantiate.html#ga1b514a2d8abacd8ca4f12a379f7a9b9c", null ],
    [ "ifapi_policyeval_instantiate_finish", "group__ifapi__policy__intantiate.html#gaa21f707557f59a29100bbe57c7ee8221", null ]
];