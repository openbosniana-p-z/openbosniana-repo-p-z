var group__ifapi__policy__execution =
[
    [ "get_policy_digest_idx", "group__ifapi__policy__execution.html#ga01ff79224d4877642c99c7ff698d895f", null ],
    [ "ifapi_extend_authorization", "group__ifapi__policy__execution.html#ga22089e183c37d59da09c2c9d38d4d402", null ],
    [ "ifapi_policyeval_execute", "group__ifapi__policy__execution.html#ga7cda976fe18fa117e01436bf90475848", null ],
    [ "ifapi_policyeval_execute_prepare", "group__ifapi__policy__execution.html#ga6e68667e49ec0daf18277b770df3f446", null ]
];