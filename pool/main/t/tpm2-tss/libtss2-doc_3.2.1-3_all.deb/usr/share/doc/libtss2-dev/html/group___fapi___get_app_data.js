var group___fapi___get_app_data =
[
    [ "Fapi_GetAppData", "group___fapi___get_app_data.html#gaa351bb8e7bfc297e9db96f6dd69fa988", null ],
    [ "Fapi_GetAppData_Async", "group___fapi___get_app_data.html#ga950a96c8d1a33d3a3596cee14e74905d", null ],
    [ "Fapi_GetAppData_Finish", "group___fapi___get_app_data.html#gaa57df7367463a171ae3de3f63bd0d705", null ]
];