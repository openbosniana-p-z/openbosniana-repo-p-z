var group__ifapi__profile =
[
    [ "ifapi_profiles_finalize", "group__ifapi__profile.html#ga7f35ab0d369df53118addf132afc9c6e", null ],
    [ "ifapi_profiles_get", "group__ifapi__profile.html#ga1d1f66781412b41c312359da5808e743", null ],
    [ "ifapi_profiles_initialize_async", "group__ifapi__profile.html#ga726700f428528de3917ffaa1e7bbf429", null ],
    [ "ifapi_profiles_initialize_finish", "group__ifapi__profile.html#ga48f2955d99163ee98cb37fbe423c5c3d", null ]
];