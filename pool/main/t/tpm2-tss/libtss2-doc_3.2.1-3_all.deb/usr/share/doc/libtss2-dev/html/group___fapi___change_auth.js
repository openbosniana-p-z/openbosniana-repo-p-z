var group___fapi___change_auth =
[
    [ "Fapi_ChangeAuth", "group___fapi___change_auth.html#ga5b22cf88c1ba51d0a0a5f5cc9012a6bd", null ],
    [ "Fapi_ChangeAuth_Async", "group___fapi___change_auth.html#ga45ec348aa4fc55e101143239fa88f4c1", null ],
    [ "Fapi_ChangeAuth_Finish", "group___fapi___change_auth.html#ga5109402a98c08e42baba3833854851f2", null ]
];