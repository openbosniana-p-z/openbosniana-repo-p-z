var group___fapi___write_authorize_nv =
[
    [ "Fapi_WriteAuthorizeNv", "group___fapi___write_authorize_nv.html#gab5ec6688c23889aaff1c14b9fcab573f", null ],
    [ "Fapi_WriteAuthorizeNv_Async", "group___fapi___write_authorize_nv.html#gaeefd019c2cc8f2ebe74fbc8ae510f6d9", null ],
    [ "Fapi_WriteAuthorizeNv_Finish", "group___fapi___write_authorize_nv.html#ga23171eeb2d8828e2c3a3a23e6889c9aa", null ]
];