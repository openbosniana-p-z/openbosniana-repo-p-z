var group___fapi___set_certificate =
[
    [ "Fapi_SetCertificate", "group___fapi___set_certificate.html#gabbfc6bd0560365c3b5d749d3124282c2", null ],
    [ "Fapi_SetCertificate_Async", "group___fapi___set_certificate.html#ga429f499528660b8d875b4a15cd3f3887", null ],
    [ "Fapi_SetCertificate_Finish", "group___fapi___set_certificate.html#ga1ccb25c9a54517b2f82f9f7d52a811a2", null ]
];