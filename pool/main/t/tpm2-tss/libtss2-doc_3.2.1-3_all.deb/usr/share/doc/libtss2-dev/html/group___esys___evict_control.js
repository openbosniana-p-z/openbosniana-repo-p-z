var group___esys___evict_control =
[
    [ "Esys_EvictControl", "group___esys___evict_control.html#gaf858a9e957df138376cad4e2f88d33b5", null ],
    [ "Esys_EvictControl_Async", "group___esys___evict_control.html#gacffb5d841a32f8e8e99ececc6cc19ebb", null ],
    [ "Esys_EvictControl_Finish", "group___esys___evict_control.html#ga45c69688b5e590d2f4fe6d1715117d0e", null ]
];