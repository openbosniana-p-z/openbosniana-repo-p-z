var group__esys__int_struct_i_e_s_y_s___c_o_n_t_e_x_t___d_a_t_a =
[
    [ "esysMetadata", "group__esys__int.html#ac64ac382d0a3c2218ff3012b5fa74941", null ],
    [ "reserved", "group__esys__int.html#a341b309519da31020dfc9a91cc114e0e", null ],
    [ "tpmContext", "group__esys__int.html#ab0e4207556ed7e185346c8ca7bf128c7", null ]
];