var group___fapi___verify_quote =
[
    [ "Fapi_VerifyQuote", "group___fapi___verify_quote.html#ga79e88a0020161cd67a28a8d7ae7e6d92", null ],
    [ "Fapi_VerifyQuote_Async", "group___fapi___verify_quote.html#ga155d58ada33013a213f2b69da00f8b31", null ],
    [ "Fapi_VerifyQuote_Finish", "group___fapi___verify_quote.html#gab22d19cb301ad1b6615797e73ea71d06", null ]
];