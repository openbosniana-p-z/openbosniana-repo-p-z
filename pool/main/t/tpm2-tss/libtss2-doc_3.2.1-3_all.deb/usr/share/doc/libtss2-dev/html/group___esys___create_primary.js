var group___esys___create_primary =
[
    [ "Esys_CreatePrimary", "group___esys___create_primary.html#ga62260c675571e016e175e9ba29597755", null ],
    [ "Esys_CreatePrimary_Async", "group___esys___create_primary.html#gaba439e987705b7fb7f76d72d0ae5a27b", null ],
    [ "Esys_CreatePrimary_Finish", "group___esys___create_primary.html#ga4eb13926cdb5ba180f5a683f28751ffb", null ]
];