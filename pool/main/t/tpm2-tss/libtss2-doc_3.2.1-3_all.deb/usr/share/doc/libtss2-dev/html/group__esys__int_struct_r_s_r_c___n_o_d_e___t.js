var group__esys__int_struct_r_s_r_c___n_o_d_e___t =
[
    [ "auth", "group__esys__int.html#a95ba3fe2be33aa36fc4ba8dfb5a48c6b", null ],
    [ "esys_handle", "group__esys__int.html#a7d0713ca6b0be8c86f31dd7a9e8391e7", null ],
    [ "next", "group__esys__int.html#a6f73db0a7a27e033afec9216cc8d2f03", null ],
    [ "rsrc", "group__esys__int.html#a2c2aa9e7bdc064896589bf9d00f53456", null ]
];