var group___fapi___get_certificate =
[
    [ "Fapi_GetCertificate", "group___fapi___get_certificate.html#gae64c6a59414207696ddd44c84e31a9da", null ],
    [ "Fapi_GetCertificate_Async", "group___fapi___get_certificate.html#ga0ae332a320fbcbda52ad322a684e62b8", null ],
    [ "Fapi_GetCertificate_Finish", "group___fapi___get_certificate.html#ga7e31193ed47fd63cd1a37730663f5e02", null ]
];