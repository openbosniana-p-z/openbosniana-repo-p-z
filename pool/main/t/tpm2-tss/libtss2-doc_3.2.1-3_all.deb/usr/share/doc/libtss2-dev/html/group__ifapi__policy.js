var group__ifapi__policy =
[
    [ "ifapi_calculate_policy", "group__ifapi__policy.html#ga959cdbfee441db40e08a25a6b5508312", null ],
    [ "ifapi_calculate_policy_authorize", "group__ifapi__policy.html#ga9fbf90c59843f0add73e9d9de69f33d1", null ],
    [ "ifapi_calculate_policy_authorize_nv", "group__ifapi__policy.html#ga44f6a328290d32b03bd92de0a94f24ed", null ],
    [ "ifapi_calculate_policy_command_code", "group__ifapi__policy.html#gaa7f669753404880d5b0135f4eac1a54e", null ],
    [ "ifapi_calculate_policy_counter_timer", "group__ifapi__policy.html#ga9ed3dd6c381b21fb63dcb67c7a81bf14", null ],
    [ "ifapi_calculate_policy_cp_hash", "group__ifapi__policy.html#gaa5dc445da32612ac83611cfad88318c4", null ],
    [ "ifapi_calculate_policy_digest_hash", "group__ifapi__policy.html#gaba6cdfe85baf4b0502d7d41d3a21ca8f", null ],
    [ "ifapi_calculate_policy_duplicate", "group__ifapi__policy.html#ga0e3b46d4597dea46f4c0b8d5c97029a9", null ],
    [ "ifapi_calculate_policy_locality", "group__ifapi__policy.html#ga0a040ee310af9b00e52889ee5f5d539a", null ],
    [ "ifapi_calculate_policy_name_hash", "group__ifapi__policy.html#ga770dcf38187e6356701ddfd6ece5f0eb", null ],
    [ "ifapi_calculate_policy_nv", "group__ifapi__policy.html#ga38c784847444e3b50e158f146d913d6a", null ],
    [ "ifapi_calculate_policy_nv_written", "group__ifapi__policy.html#ga424e5a67a951be415c090f0c68da3329", null ],
    [ "ifapi_calculate_policy_or", "group__ifapi__policy.html#gafb80869164b6798e92befa69192caaf6", null ],
    [ "ifapi_calculate_policy_secret", "group__ifapi__policy.html#ga431512c41eeeb7120ce8c9849e3a8a60", null ],
    [ "ifapi_calculate_policy_signed", "group__ifapi__policy.html#ga5471b7bf1a14125e033904d986629eb8", null ],
    [ "ifapi_calculate_simple_policy", "group__ifapi__policy.html#gaaf855bd0e68bacff034168df555d4412", null ],
    [ "ifapi_calculate_tree", "group__ifapi__policy.html#ga0dd62193830c4656f409ce6102cb3568", null ],
    [ "ifapi_compute_policy_pcr", "group__ifapi__policy.html#gab244e28f8bce51e7806ba4a0b310b5b8", null ]
];