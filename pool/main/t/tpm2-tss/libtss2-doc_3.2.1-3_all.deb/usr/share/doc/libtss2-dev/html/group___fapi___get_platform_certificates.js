var group___fapi___get_platform_certificates =
[
    [ "Fapi_GetPlatformCertificates", "group___fapi___get_platform_certificates.html#gabe36124d77d8271e9dd76b468dbcf250", null ],
    [ "Fapi_GetPlatformCertificates_Async", "group___fapi___get_platform_certificates.html#gaf3159895717bae1829e559500e72fbd0", null ],
    [ "Fapi_GetPlatformCertificates_Finish", "group___fapi___get_platform_certificates.html#ga90e719caa7692e3aa20046de47aab2b5", null ]
];