var group___fapi___quote =
[
    [ "Fapi_Quote", "group___fapi___quote.html#gaae9ed4c6ef7e097ae9b00ddc0a184f74", null ],
    [ "Fapi_Quote_Async", "group___fapi___quote.html#ga2a57d5a993a86e279de43fc21b452721", null ],
    [ "Fapi_Quote_Finish", "group___fapi___quote.html#ga6a9429c2b13d8ce7d6a4616326b5da54", null ]
];