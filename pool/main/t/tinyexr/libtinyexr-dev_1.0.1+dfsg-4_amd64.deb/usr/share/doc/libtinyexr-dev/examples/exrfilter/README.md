Simple EXR filtering program.

Currently implemented are

- Clip min/max intensity(RGB)
