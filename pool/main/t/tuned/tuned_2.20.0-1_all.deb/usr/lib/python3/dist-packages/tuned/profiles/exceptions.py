import tuned.exceptions

class InvalidProfileException(tuned.exceptions.TunedException):
	pass
