import tuned.exceptions

class TunedAdminDBusException(tuned.exceptions.TunedException):
	pass
