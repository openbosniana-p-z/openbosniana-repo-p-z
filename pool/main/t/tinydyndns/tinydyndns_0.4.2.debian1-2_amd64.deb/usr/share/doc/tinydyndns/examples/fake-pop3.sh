#!/bin/sh
USER=floyd
PASS=guest
tcpclient dyn.smarden.org 110 sh -c "exec 0<&6; exec 1>&7
  echo USER $USER
  read input
  echo PASS $PASS
  read input
  echo QUIT
  read input"
