/* Auto-generated, do not edit.
 *
 * This file may be distributed under the same terms
 * as the specification from which it was generated.
 */

#define TP_HASH_TYPE_PROTOCOL_PROPERTIES_MAP (tp_type_dbus_hash_sa_7bsv_7d ())

#define TP_HASH_TYPE_VCARD_FIELD_ADDRESS_MAP (tp_type_dbus_hash_ss ())

#define TP_HASH_TYPE_ADDRESSING_NORMALIZATION_MAP (tp_type_dbus_hash_su ())

#define TP_HASH_TYPE_ALIAS_MAP (tp_type_dbus_hash_us ())

#define TP_HASH_TYPE_AVATAR_TOKEN_MAP (tp_type_dbus_hash_us ())

#define TP_HASH_TYPE_CONTACT_CLIENT_TYPES (tp_type_dbus_hash_uas ())

#define TP_HASH_TYPE_CONTACT_CAPABILITIES_MAP (tp_type_dbus_hash_ua_28a_7bsv_7das_29 ())

#define TP_ARRAY_TYPE_CONTACT_CAPABILITIES_MAP_LIST (tp_type_dbus_array_of_a_7bua_28a_7bsv_7das_29_7d ())

#define TP_HASH_TYPE_CONTACT_INFO_MAP (tp_type_dbus_hash_ua_28sasas_29 ())

#define TP_HASH_TYPE_CONTACT_SUBSCRIPTION_MAP (tp_type_dbus_hash_u_28uus_29 ())

#define TP_HASH_TYPE_SIMPLE_CONTACT_PRESENCES (tp_type_dbus_hash_u_28uss_29 ())

#define TP_HASH_TYPE_SIMPLE_STATUS_SPEC_MAP (tp_type_dbus_hash_s_28ubb_29 ())

#define TP_HASH_TYPE_MULTIPLE_STATUS_MAP (tp_type_dbus_hash_sa_7bsv_7d ())

#define TP_HASH_TYPE_CONTACT_PRESENCES (tp_type_dbus_hash_u_28ua_7bsa_7bsv_7d_7d_29 ())

#define TP_HASH_TYPE_STATUS_SPEC_MAP (tp_type_dbus_hash_s_28ubba_7bss_7d_29 ())

#define TP_HASH_TYPE_SINGLE_CONTACT_ATTRIBUTES_MAP (tp_type_dbus_hash_sv ())

#define TP_HASH_TYPE_CONTACT_ATTRIBUTES_MAP (tp_type_dbus_hash_ua_7bsv_7d ())

#define TP_HASH_TYPE_CHANNEL_CLASS (tp_type_dbus_hash_sv ())

#define TP_ARRAY_TYPE_CHANNEL_CLASS_LIST (tp_type_dbus_array_of_a_7bsv_7d ())

#define TP_HASH_TYPE_LOCATION (tp_type_dbus_hash_sv ())

#define TP_HASH_TYPE_CONTACT_LOCATIONS (tp_type_dbus_hash_ua_7bsv_7d ())

#define TP_HASH_TYPE_MAIL (tp_type_dbus_hash_sv ())

#define TP_ARRAY_TYPE_MAIL_LIST (tp_type_dbus_array_of_a_7bsv_7d ())

#define TP_HASH_TYPE_CALL_MEMBER_MAP (tp_type_dbus_hash_uu ())

#define TP_ARRAY_TYPE_CALL_MEMBER_MAP_LIST (tp_type_dbus_array_of_a_7buu_7d ())

#define TP_HASH_TYPE_CONTACT_SEARCH_MAP (tp_type_dbus_hash_ss ())

#define TP_HASH_TYPE_CONTACT_SEARCH_RESULT_MAP (tp_type_dbus_hash_sa_28sasas_29 ())

#define TP_HASH_TYPE_SUPPORTED_SOCKET_MAP (tp_type_dbus_hash_uau ())

#define TP_HASH_TYPE_DBUS_TUBE_PARTICIPANTS (tp_type_dbus_hash_us ())

#define TP_HASH_TYPE_CHANNEL_CALL_STATE_MAP (tp_type_dbus_hash_uu ())

#define TP_HASH_TYPE_CAPTCHA_ANSWERS (tp_type_dbus_hash_us ())

#define TP_HASH_TYPE_CHAT_STATE_MAP (tp_type_dbus_hash_uu ())

#define TP_HASH_TYPE_CHANNEL_ORIGINATOR_MAP (tp_type_dbus_hash_uo ())

#define TP_HASH_TYPE_METADATA (tp_type_dbus_hash_sas ())

#define TP_HASH_TYPE_HANDLE_OWNER_MAP (tp_type_dbus_hash_uu ())

#define TP_HASH_TYPE_HANDLE_IDENTIFIER_MAP (tp_type_dbus_hash_us ())

#define TP_HASH_TYPE_MESSAGE_PART (tp_type_dbus_hash_sv ())

#define TP_ARRAY_TYPE_MESSAGE_PART_LIST (tp_type_dbus_array_of_a_7bsv_7d ())

#define TP_HASH_TYPE_MESSAGE_PART_CONTENT_MAP (tp_type_dbus_hash_uv ())

#define TP_HASH_TYPE_RTCP_FEEDBACK_MESSAGE_MAP (tp_type_dbus_hash_u_28ua_28sss_29_29 ())

#define TP_HASH_TYPE_NOT_DELEGATED_MAP (tp_type_dbus_hash_o_28ss_29 ())

#define TP_HASH_TYPE_CONTACT_CODEC_MAP (tp_type_dbus_hash_ua_28usuuba_7bss_7d_29 ())

#define TP_HASH_TYPE_CONTACT_MEDIA_DESCRIPTION_PROPERTIES_MAP (tp_type_dbus_hash_ua_7bsv_7d ())

#define TP_HASH_TYPE_CONTACT_SSRCS_MAP (tp_type_dbus_hash_uau ())

#define TP_HASH_TYPE_MEDIA_DESCRIPTION_PROPERTIES (tp_type_dbus_hash_sv ())

#define TP_HASH_TYPE_CANDIDATE_INFO (tp_type_dbus_hash_sv ())

#define TP_HASH_TYPE_CONTACT_SENDING_STATE_MAP (tp_type_dbus_hash_uu ())

#define TP_HASH_TYPE_COMPONENT_STATE_MAP (tp_type_dbus_hash_uu ())

#define TP_HASH_TYPE_QUALIFIED_PROPERTY_VALUE_MAP (tp_type_dbus_hash_sv ())

#define TP_ARRAY_TYPE_QUALIFIED_PROPERTY_VALUE_MAP_LIST (tp_type_dbus_array_of_a_7bsv_7d ())

#define TP_HASH_TYPE_STRING_VARIANT_MAP (tp_type_dbus_hash_sv ())

#define TP_ARRAY_TYPE_STRING_VARIANT_MAP_LIST (tp_type_dbus_array_of_a_7bsv_7d ())

#define TP_HASH_TYPE_STRING_STRING_MAP (tp_type_dbus_hash_ss ())

#define TP_ARRAY_TYPE_STRING_STRING_MAP_LIST (tp_type_dbus_array_of_a_7bss_7d ())

#define TP_HASH_TYPE_OBJECT_IMMUTABLE_PROPERTIES_MAP (tp_type_dbus_hash_oa_7bsv_7d ())

#define TP_ARRAY_TYPE_OBJECT_IMMUTABLE_PROPERTIES_MAP_LIST (tp_type_dbus_array_of_a_7boa_7bsv_7d_7d ())

GType tp_type_dbus_hash_o_28ss_29 (void);

GType tp_type_dbus_hash_oa_7bsv_7d (void);

GType tp_type_dbus_hash_s_28ubb_29 (void);

GType tp_type_dbus_hash_s_28ubba_7bss_7d_29 (void);

GType tp_type_dbus_hash_sa_28sasas_29 (void);

GType tp_type_dbus_hash_sas (void);

GType tp_type_dbus_hash_sa_7bsv_7d (void);

GType tp_type_dbus_hash_ss (void);

GType tp_type_dbus_hash_su (void);

GType tp_type_dbus_hash_sv (void);

GType tp_type_dbus_hash_u_28ua_28sss_29_29 (void);

GType tp_type_dbus_hash_u_28ua_7bsa_7bsv_7d_7d_29 (void);

GType tp_type_dbus_hash_u_28uss_29 (void);

GType tp_type_dbus_hash_u_28uus_29 (void);

GType tp_type_dbus_hash_ua_28a_7bsv_7das_29 (void);

GType tp_type_dbus_hash_ua_28sasas_29 (void);

GType tp_type_dbus_hash_ua_28usuuba_7bss_7d_29 (void);

GType tp_type_dbus_hash_uas (void);

GType tp_type_dbus_hash_uau (void);

GType tp_type_dbus_hash_ua_7bsv_7d (void);

GType tp_type_dbus_hash_uo (void);

GType tp_type_dbus_hash_us (void);

GType tp_type_dbus_hash_uu (void);

GType tp_type_dbus_hash_uv (void);

#define TP_STRUCT_TYPE_PARAM_SPEC (tp_type_dbus_struct_susv ())

#define TP_ARRAY_TYPE_PARAM_SPEC_LIST (tp_type_dbus_array_susv ())

#define TP_STRUCT_TYPE_CHANNEL_INFO (tp_type_dbus_struct_osuu ())

#define TP_ARRAY_TYPE_CHANNEL_INFO_LIST (tp_type_dbus_array_osuu ())

#define TP_STRUCT_TYPE_ALIAS_PAIR (tp_type_dbus_struct_us ())

#define TP_ARRAY_TYPE_ALIAS_PAIR_LIST (tp_type_dbus_array_us ())

#define TP_STRUCT_TYPE_CURRENCY_AMOUNT (tp_type_dbus_struct_ius ())

#define TP_STRUCT_TYPE_CAPABILITY_PAIR (tp_type_dbus_struct_su ())

#define TP_ARRAY_TYPE_CAPABILITY_PAIR_LIST (tp_type_dbus_array_su ())

#define TP_STRUCT_TYPE_CONTACT_CAPABILITY (tp_type_dbus_struct_usuu ())

#define TP_ARRAY_TYPE_CONTACT_CAPABILITY_LIST (tp_type_dbus_array_usuu ())

#define TP_STRUCT_TYPE_CAPABILITY_CHANGE (tp_type_dbus_struct_usuuuu ())

#define TP_ARRAY_TYPE_CAPABILITY_CHANGE_LIST (tp_type_dbus_array_usuuuu ())

#define TP_STRUCT_TYPE_HANDLER_CAPABILITIES (tp_type_dbus_struct_saa_7bsv_7das ())

#define TP_ARRAY_TYPE_HANDLER_CAPABILITIES_LIST (tp_type_dbus_array_saa_7bsv_7das ())

#define TP_STRUCT_TYPE_CONTACT_INFO_FIELD (tp_type_dbus_struct_sasas ())

#define TP_ARRAY_TYPE_CONTACT_INFO_FIELD_LIST (tp_type_dbus_array_sasas ())

#define TP_STRUCT_TYPE_FIELD_SPEC (tp_type_dbus_struct_sasuu ())

#define TP_ARRAY_TYPE_FIELD_SPECS (tp_type_dbus_array_sasuu ())

#define TP_STRUCT_TYPE_CONTACT_SUBSCRIPTIONS (tp_type_dbus_struct_uus ())

#define TP_STRUCT_TYPE_SIMPLE_PRESENCE (tp_type_dbus_struct_uss ())

#define TP_STRUCT_TYPE_SIMPLE_STATUS_SPEC (tp_type_dbus_struct_ubb ())

#define TP_STRUCT_TYPE_ACCESS_CONTROL (tp_type_dbus_struct_uv ())

#define TP_STRUCT_TYPE_RICH_PRESENCE_ACCESS_CONTROL (tp_type_dbus_struct_uv ())

#define TP_STRUCT_TYPE_LAST_ACTIVITY_AND_STATUSES (tp_type_dbus_struct_ua_7bsa_7bsv_7d_7d ())

#define TP_STRUCT_TYPE_STATUS_SPEC (tp_type_dbus_struct_ubba_7bss_7d ())

#define TP_STRUCT_TYPE_CHANNEL_DETAILS (tp_type_dbus_struct_oa_7bsv_7d ())

#define TP_ARRAY_TYPE_CHANNEL_DETAILS_LIST (tp_type_dbus_array_oa_7bsv_7d ())

#define TP_STRUCT_TYPE_REQUESTABLE_CHANNEL_CLASS (tp_type_dbus_struct_a_7bsv_7das ())

#define TP_ARRAY_TYPE_REQUESTABLE_CHANNEL_CLASS_LIST (tp_type_dbus_array_a_7bsv_7das ())

#define TP_STRUCT_TYPE_SERVICE_POINT_INFO (tp_type_dbus_struct__28us_29as ())

#define TP_ARRAY_TYPE_SERVICE_POINT_INFO_LIST (tp_type_dbus_array__28us_29as ())

#define TP_STRUCT_TYPE_SERVICE_POINT (tp_type_dbus_struct_us ())

#define TP_STRUCT_TYPE_HTTP_POST_DATA (tp_type_dbus_struct_ss ())

#define TP_ARRAY_TYPE_HTTP_POST_DATA_LIST (tp_type_dbus_array_ss ())

#define TP_STRUCT_TYPE_MAIL_ADDRESS (tp_type_dbus_struct_ss ())

#define TP_ARRAY_TYPE_MAIL_ADDRESS_LIST (tp_type_dbus_array_ss ())

#define TP_STRUCT_TYPE_MAIL_URL (tp_type_dbus_struct_sua_28ss_29 ())

#define TP_STRUCT_TYPE_CALL_STATE_REASON (tp_type_dbus_struct_uuss ())

#define TP_STRUCT_TYPE_MEDIA_STREAM_INFO (tp_type_dbus_struct_uuuuuu ())

#define TP_ARRAY_TYPE_MEDIA_STREAM_INFO_LIST (tp_type_dbus_array_uuuuuu ())

#define TP_STRUCT_TYPE_ROOM_INFO (tp_type_dbus_struct_usa_7bsv_7d ())

#define TP_ARRAY_TYPE_ROOM_INFO_LIST (tp_type_dbus_array_usa_7bsv_7d ())

#define TP_STRUCT_TYPE_PENDING_TEXT_MESSAGE (tp_type_dbus_struct_uuuuus ())

#define TP_ARRAY_TYPE_PENDING_TEXT_MESSAGE_LIST (tp_type_dbus_array_uuuuus ())

#define TP_STRUCT_TYPE_TUBE_INFO (tp_type_dbus_struct_uuusa_7bsv_7du ())

#define TP_ARRAY_TYPE_TUBE_INFO_LIST (tp_type_dbus_array_uuusa_7bsv_7du ())

#define TP_STRUCT_TYPE_DBUS_TUBE_MEMBER (tp_type_dbus_struct_us ())

#define TP_ARRAY_TYPE_DBUS_TUBE_MEMBER_LIST (tp_type_dbus_array_us ())

#define TP_STRUCT_TYPE_CAPTCHA_INFO (tp_type_dbus_struct_ussuas ())

#define TP_ARRAY_TYPE_CAPTCHA_INFO_LIST (tp_type_dbus_array_ussuas ())

#define TP_STRUCT_TYPE_LOCAL_PENDING_INFO (tp_type_dbus_struct_uuus ())

#define TP_ARRAY_TYPE_LOCAL_PENDING_INFO_LIST (tp_type_dbus_array_uuus ())

#define TP_STRUCT_TYPE_MEDIA_SESSION_HANDLER_INFO (tp_type_dbus_struct_os ())

#define TP_ARRAY_TYPE_MEDIA_SESSION_HANDLER_INFO_LIST (tp_type_dbus_array_os ())

#define TP_STRUCT_TYPE_MEDIA_STREAM_HANDLER_CANDIDATE (tp_type_dbus_struct_sa_28usuussduss_29 ())

#define TP_ARRAY_TYPE_MEDIA_STREAM_HANDLER_CANDIDATE_LIST (tp_type_dbus_array_sa_28usuussduss_29 ())

#define TP_STRUCT_TYPE_MEDIA_STREAM_HANDLER_TRANSPORT (tp_type_dbus_struct_usuussduss ())

#define TP_ARRAY_TYPE_MEDIA_STREAM_HANDLER_TRANSPORT_LIST (tp_type_dbus_array_usuussduss ())

#define TP_STRUCT_TYPE_MEDIA_STREAM_HANDLER_CODEC (tp_type_dbus_struct_usuuua_7bss_7d ())

#define TP_ARRAY_TYPE_MEDIA_STREAM_HANDLER_CODEC_LIST (tp_type_dbus_array_usuuua_7bss_7d ())

#define TP_STRUCT_TYPE_RTCP_FEEDBACK_MESSAGE_PROPERTIES (tp_type_dbus_struct_ua_28sss_29 ())

#define TP_STRUCT_TYPE_RTCP_FEEDBACK_MESSAGE (tp_type_dbus_struct_sss ())

#define TP_ARRAY_TYPE_RTCP_FEEDBACK_MESSAGE_LIST (tp_type_dbus_array_sss ())

#define TP_STRUCT_TYPE_RTP_HEADER_EXTENSION (tp_type_dbus_struct_uuss ())

#define TP_ARRAY_TYPE_RTP_HEADER_EXTENSIONS_LIST (tp_type_dbus_array_uuss ())

#define TP_STRUCT_TYPE_PROPERTY_SPEC (tp_type_dbus_struct_ussu ())

#define TP_ARRAY_TYPE_PROPERTY_SPEC_LIST (tp_type_dbus_array_ussu ())

#define TP_STRUCT_TYPE_PROPERTY_FLAGS_CHANGE (tp_type_dbus_struct_uu ())

#define TP_ARRAY_TYPE_PROPERTY_FLAGS_CHANGE_LIST (tp_type_dbus_array_uu ())

#define TP_STRUCT_TYPE_PROPERTY_VALUE (tp_type_dbus_struct_uv ())

#define TP_ARRAY_TYPE_PROPERTY_VALUE_LIST (tp_type_dbus_array_uv ())

#define TP_STRUCT_TYPE_AVATAR (tp_type_dbus_struct_ays ())

#define TP_STRUCT_TYPE_NOT_DELEGATED_ERROR (tp_type_dbus_struct_ss ())

#define TP_STRUCT_TYPE_DISPATCH_OPERATION_DETAILS (tp_type_dbus_struct_oa_7bsv_7d ())

#define TP_ARRAY_TYPE_DISPATCH_OPERATION_DETAILS_LIST (tp_type_dbus_array_oa_7bsv_7d ())

#define TP_STRUCT_TYPE_DEBUG_MESSAGE (tp_type_dbus_struct_dsus ())

#define TP_ARRAY_TYPE_DEBUG_MESSAGE_LIST (tp_type_dbus_array_dsus ())

#define TP_STRUCT_TYPE_TLS_CERTIFICATE_REJECTION (tp_type_dbus_struct_usa_7bsv_7d ())

#define TP_ARRAY_TYPE_TLS_CERTIFICATE_REJECTION_LIST (tp_type_dbus_array_usa_7bsv_7d ())

#define TP_STRUCT_TYPE_CODEC (tp_type_dbus_struct_usuuba_7bss_7d ())

#define TP_ARRAY_TYPE_CODEC_LIST (tp_type_dbus_array_usuuba_7bss_7d ())

#define TP_STRUCT_TYPE_MEDIA_DESCRIPTION_OFFER (tp_type_dbus_struct_oa_7bsv_7d ())

#define TP_STRUCT_TYPE_VIDEO_RESOLUTION (tp_type_dbus_struct_uu ())

#define TP_ARRAY_TYPE_VIDEO_RESOLUTION_STRUCT (tp_type_dbus_array_uu ())

#define TP_STRUCT_TYPE_RTP_HEADER_EXTENSION (tp_type_dbus_struct_uuss ())

#define TP_ARRAY_TYPE_RTP_HEADER_EXTENSIONS_LIST (tp_type_dbus_array_uuss ())

#define TP_STRUCT_TYPE_CANDIDATE (tp_type_dbus_struct_usua_7bsv_7d ())

#define TP_ARRAY_TYPE_CANDIDATE_LIST (tp_type_dbus_array_usua_7bsv_7d ())

#define TP_STRUCT_TYPE_STREAM_CREDENTIALS (tp_type_dbus_struct_ss ())

#define TP_STRUCT_TYPE_CANDIDATE_PAIR (tp_type_dbus_struct__28usua_7bsv_7d_29_28usua_7bsv_7d_29 ())

#define TP_ARRAY_TYPE_CANDIDATE_PAIR_LIST (tp_type_dbus_array__28usua_7bsv_7d_29_28usua_7bsv_7d_29 ())

#define TP_STRUCT_TYPE_SOCKET_ADDRESS_IP (tp_type_dbus_struct_sq ())

#define TP_ARRAY_TYPE_SOCKET_ADDRESS_IP_LIST (tp_type_dbus_array_sq ())

#define TP_STRUCT_TYPE_SOCKET_ADDRESS_IPV4 (tp_type_dbus_struct_sq ())

#define TP_STRUCT_TYPE_SOCKET_ADDRESS_IPV6 (tp_type_dbus_struct_sq ())

#define TP_STRUCT_TYPE_SOCKET_NETMASK_IPV4 (tp_type_dbus_struct_sy ())

#define TP_STRUCT_TYPE_SOCKET_NETMASK_IPV6 (tp_type_dbus_struct_sy ())

GType tp_type_dbus_struct__28us_29as (void);

GType tp_type_dbus_struct__28usua_7bsv_7d_29_28usua_7bsv_7d_29 (void);

GType tp_type_dbus_struct_ays (void);

GType tp_type_dbus_struct_a_7bsv_7das (void);

GType tp_type_dbus_struct_dsus (void);

GType tp_type_dbus_struct_ius (void);

GType tp_type_dbus_struct_oa_7bsv_7d (void);

GType tp_type_dbus_struct_os (void);

GType tp_type_dbus_struct_osuu (void);

GType tp_type_dbus_struct_sa_28usuussduss_29 (void);

GType tp_type_dbus_struct_saa_7bsv_7das (void);

GType tp_type_dbus_struct_sasas (void);

GType tp_type_dbus_struct_sasuu (void);

GType tp_type_dbus_struct_sq (void);

GType tp_type_dbus_struct_ss (void);

GType tp_type_dbus_struct_sss (void);

GType tp_type_dbus_struct_su (void);

GType tp_type_dbus_struct_sua_28ss_29 (void);

GType tp_type_dbus_struct_susv (void);

GType tp_type_dbus_struct_sy (void);

GType tp_type_dbus_struct_ua_28sss_29 (void);

GType tp_type_dbus_struct_ua_7bsa_7bsv_7d_7d (void);

GType tp_type_dbus_struct_ubb (void);

GType tp_type_dbus_struct_ubba_7bss_7d (void);

GType tp_type_dbus_struct_us (void);

GType tp_type_dbus_struct_usa_7bsv_7d (void);

GType tp_type_dbus_struct_uss (void);

GType tp_type_dbus_struct_ussu (void);

GType tp_type_dbus_struct_ussuas (void);

GType tp_type_dbus_struct_usua_7bsv_7d (void);

GType tp_type_dbus_struct_usuu (void);

GType tp_type_dbus_struct_usuuba_7bss_7d (void);

GType tp_type_dbus_struct_usuussduss (void);

GType tp_type_dbus_struct_usuuua_7bss_7d (void);

GType tp_type_dbus_struct_usuuuu (void);

GType tp_type_dbus_struct_uu (void);

GType tp_type_dbus_struct_uus (void);

GType tp_type_dbus_struct_uuss (void);

GType tp_type_dbus_struct_uuus (void);

GType tp_type_dbus_struct_uuusa_7bsv_7du (void);

GType tp_type_dbus_struct_uuuuus (void);

GType tp_type_dbus_struct_uuuuuu (void);

GType tp_type_dbus_struct_uv (void);

GType tp_type_dbus_array__28us_29as (void);

GType tp_type_dbus_array__28usua_7bsv_7d_29_28usua_7bsv_7d_29 (void);

GType tp_type_dbus_array_a_7bsv_7das (void);

GType tp_type_dbus_array_dsus (void);

GType tp_type_dbus_array_oa_7bsv_7d (void);

GType tp_type_dbus_array_os (void);

GType tp_type_dbus_array_osuu (void);

GType tp_type_dbus_array_sa_28usuussduss_29 (void);

GType tp_type_dbus_array_saa_7bsv_7das (void);

GType tp_type_dbus_array_sasas (void);

GType tp_type_dbus_array_sasuu (void);

GType tp_type_dbus_array_sq (void);

GType tp_type_dbus_array_ss (void);

GType tp_type_dbus_array_sss (void);

GType tp_type_dbus_array_su (void);

GType tp_type_dbus_array_susv (void);

GType tp_type_dbus_array_us (void);

GType tp_type_dbus_array_usa_7bsv_7d (void);

GType tp_type_dbus_array_ussu (void);

GType tp_type_dbus_array_ussuas (void);

GType tp_type_dbus_array_usua_7bsv_7d (void);

GType tp_type_dbus_array_usuu (void);

GType tp_type_dbus_array_usuuba_7bss_7d (void);

GType tp_type_dbus_array_usuussduss (void);

GType tp_type_dbus_array_usuuua_7bss_7d (void);

GType tp_type_dbus_array_usuuuu (void);

GType tp_type_dbus_array_uu (void);

GType tp_type_dbus_array_uuss (void);

GType tp_type_dbus_array_uuus (void);

GType tp_type_dbus_array_uuusa_7bsv_7du (void);

GType tp_type_dbus_array_uuuuus (void);

GType tp_type_dbus_array_uuuuuu (void);

GType tp_type_dbus_array_uv (void);

GType tp_type_dbus_array_of_a_7boa_7bsv_7d_7d (void);

GType tp_type_dbus_array_of_a_7bss_7d (void);

GType tp_type_dbus_array_of_a_7bsv_7d (void);

GType tp_type_dbus_array_of_a_7bua_28a_7bsv_7das_29_7d (void);

GType tp_type_dbus_array_of_a_7buu_7d (void);

