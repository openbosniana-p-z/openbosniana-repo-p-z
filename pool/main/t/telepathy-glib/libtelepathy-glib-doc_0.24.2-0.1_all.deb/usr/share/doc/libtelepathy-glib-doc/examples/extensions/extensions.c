#include "extensions.h"

/* include auto-generated stubs for things common to service and client */
#include "_gen/gtypes-body.h"
#include "_gen/interfaces-body.h"
