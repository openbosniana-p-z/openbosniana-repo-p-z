Sample Trapperkeeper Servlet Web App
---------------------------------

To run the app, use this command:

```sh
lein trampoline run --config examples/servlet_app/servlet-example.conf \
                    --bootstrap-config examples/servlet_app/bootstrap.cfg

```
