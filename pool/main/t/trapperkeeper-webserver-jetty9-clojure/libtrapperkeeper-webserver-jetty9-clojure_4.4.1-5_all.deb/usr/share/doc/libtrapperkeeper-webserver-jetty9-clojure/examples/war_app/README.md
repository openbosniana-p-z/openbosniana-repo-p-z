Sample Trapperkeeper WAR Web App
---------------------------------

To run the app, use this command:

```sh
lein trampoline run --config examples/war_app/war-example.conf \
                    --bootstrap-config examples/war_app/bootstrap.cfg

```

Open

```
http://localhost:8080/test/hello

```

in your browser to see the famous Hello World message.