#!/bin/bash

set -ev

rm -f ./atg.*
rm -f ./pipeliner.*
rm -f ./enhanced.*

rm -rf ./test__checkpoints
rm -f ./test.*

