##
## Copyright (C) 2011-2012 Andrew Atkinson
##
##-------------------------------------------------------------------
## This program is free software: you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see <http://www.gnu.org/licenses/>.
##-------------------------------------------------------------------


import setuptools
from setuptools import setup
from Defaults import ProgramInfo as info
import os
if os.name == 'nt': #sys.platform == 'win32':
    import py2exe

if os.name == 'nt':
    outputname = info().name + info().version.replace('.', '_')
    manualfolder = 'Manual' + info().manversion.replace('.', '_')
    copyfiles = [('Images', ['Images/topparser.ico']),
                ('', ['COPYING']),
                ('', ['ChangeLog.txt'])]
    for file in os.listdir('Manual'):
        if os.path.isfile('Manual/' + file):
            copyfiles.append([manualfolder, ['Manual/' + file]])
            print(copyfiles)
elif os.name == 'posix':
    manualfolder = ''
    copyfiles = ''
else:
    raise Exception("Sorry: no implementation for your platform ('%s') available" % os.name)


if os.name == 'nt':
    setup(
        name=info().name,
        version=info().version,
        url=info().website,
        author=info().developer,
        author_email=info().developer_email,
        description=info().description,
        license=info().licence,
        #python_requires='2.6,2.7,<3',
        windows=[{"script": 'TopParser.py',
                  "icon_resourses": [(1, 'Images/topparser.ico')],
                "copyright": info().copyright}],
        data_files= copyfiles,
        options={"py2exe": {"dist_dir": outputname}}
    )

if os.name == 'posix':
    setup(
        name=info().name,
        version=info().version,
        url=info().website,
        author=info().developer,
        author_email=info().developer_email,
        description=info().description,
        license=info().licence,
        #python_requires='2.6,2.7,<3',
        #scripts='TopParser',
        data_files='',
    )
