Support spécial pour les programmes Turtle
==========================================

Quand on développe des programmes avec le module ``turtle``, Thonny offre le support suivant :

* On peut faire sans les appels de ``mainloop``, ``done`` ou ``exitonclick`` dans le script (Thonny s'occupera de garder la fenêtre Turtle interactive). Cela permet de créer des parts de son dessin à l'aide d'un script et de continuer à ajouter des propriétés à l'aide du shell. On peut aussi faire tout le dessin à partir du shell.
* On peut `ancrer la fenêtre Turtle <dock.rst>`_, afin qu'elle reste bien visibles tant qu'on travaille sur le script.
