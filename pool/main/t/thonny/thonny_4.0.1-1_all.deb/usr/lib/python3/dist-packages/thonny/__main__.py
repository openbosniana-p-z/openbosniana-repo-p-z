from thonny import launch, report_time

report_time("Before launch")
launch()
