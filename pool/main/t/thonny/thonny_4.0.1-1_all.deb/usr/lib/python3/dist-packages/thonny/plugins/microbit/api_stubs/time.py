def sleep():
    pass


def sleep_ms():
    pass


def sleep_us():
    pass


def ticks_add():
    pass


def ticks_diff():
    pass


def ticks_ms():
    pass


def ticks_us():
    pass
