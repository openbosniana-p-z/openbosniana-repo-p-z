<?php

return [
    'Names' => [
        'PKR' => [
            0 => 'Rs',
            1 => 'Pakistani Rupee',
        ],
    ],
];
