<?php

return [
    'Names' => [
        'CNY' => [
            0 => '¥',
            1 => 'CNY',
        ],
    ],
];
