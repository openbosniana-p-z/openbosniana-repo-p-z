<?php

return [
    'Names' => [
        'KMF' => [
            0 => 'CF',
            1 => 'franc comorien',
        ],
    ],
];
