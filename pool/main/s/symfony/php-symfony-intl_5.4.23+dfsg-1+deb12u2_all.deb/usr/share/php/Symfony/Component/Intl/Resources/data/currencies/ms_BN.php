<?php

return [
    'Names' => [
        'BND' => [
            0 => '$',
            1 => 'Dolar Brunei',
        ],
    ],
];
