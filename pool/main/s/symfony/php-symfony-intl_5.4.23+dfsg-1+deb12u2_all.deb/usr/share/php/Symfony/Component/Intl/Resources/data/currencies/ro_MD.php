<?php

return [
    'Names' => [
        'MDL' => [
            0 => 'L',
            1 => 'leu moldovenesc',
        ],
    ],
];
