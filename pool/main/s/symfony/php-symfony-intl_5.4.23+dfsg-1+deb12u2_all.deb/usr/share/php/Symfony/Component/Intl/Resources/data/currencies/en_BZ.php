<?php

return [
    'Names' => [
        'BZD' => [
            0 => '$',
            1 => 'Belize Dollar',
        ],
    ],
];
