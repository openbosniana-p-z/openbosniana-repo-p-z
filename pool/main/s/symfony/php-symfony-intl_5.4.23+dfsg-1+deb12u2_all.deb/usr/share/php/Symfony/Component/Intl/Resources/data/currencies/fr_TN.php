<?php

return [
    'Names' => [
        'TND' => [
            0 => 'DT',
            1 => 'dinar tunisien',
        ],
    ],
];
