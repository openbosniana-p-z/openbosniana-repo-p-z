<?php

return [
    'Names' => [
        'CRC' => [
            0 => '₡',
            1 => 'colón costarricense',
        ],
    ],
];
