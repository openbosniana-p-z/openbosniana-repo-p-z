<?php

return [
    'Names' => [
        'SEK' => [
            0 => 'kr',
            1 => 'Swedish Krona',
        ],
    ],
];
