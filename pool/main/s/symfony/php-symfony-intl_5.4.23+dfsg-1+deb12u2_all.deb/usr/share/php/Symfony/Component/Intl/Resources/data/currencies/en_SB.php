<?php

return [
    'Names' => [
        'SBD' => [
            0 => '$',
            1 => 'Solomon Islands Dollar',
        ],
    ],
];
