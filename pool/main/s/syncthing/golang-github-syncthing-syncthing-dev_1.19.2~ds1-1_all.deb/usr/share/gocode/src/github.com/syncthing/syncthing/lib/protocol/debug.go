// Copyright (C) 2014 The Protocol Authors.

package protocol

import (
	"github.com/syncthing/syncthing/lib/logger"
)

var (
	l = logger.DefaultLogger.NewFacility("protocol", "The BEP protocol")
)
