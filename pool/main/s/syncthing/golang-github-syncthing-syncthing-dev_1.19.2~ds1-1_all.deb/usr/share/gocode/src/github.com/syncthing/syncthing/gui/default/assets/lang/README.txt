All files in this directory are auto generated. Do not change any of
them. To contribute translations, please head over to

 https://www.transifex.com/projects/p/syncthing/

Any updates made on Transifex will be automatically pulled into these
files.
