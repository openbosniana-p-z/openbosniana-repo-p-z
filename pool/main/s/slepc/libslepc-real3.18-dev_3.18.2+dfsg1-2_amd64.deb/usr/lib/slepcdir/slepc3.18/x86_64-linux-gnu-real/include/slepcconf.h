#if !defined(INCLUDED_SLEPCCONF_H)
#define INCLUDED_SLEPCCONF_H

#define SLEPC_PETSC_DIR "/usr/lib/petscdir/petsc3.18/x86_64-linux-gnu-real"
#define SLEPC_PETSC_ARCH ""
#define SLEPC_DIR "/usr/lib/slepcdir/slepc3.18/x86_64-linux-gnu-real"
#define SLEPC_LIB_DIR "/usr/lib/slepcdir/slepc3.18/x86_64-linux-gnu-real/lib"
#define SLEPC_HAVE_SCALAPACK 1
#define SLEPC_SCALAPACK_HAVE_UNDERSCORE 1
#define SLEPC_HAVE_ARPACK 1
#define SLEPC_ARPACK_HAVE_UNDERSCORE 1
#define SLEPC_HAVE_PACKAGES ":scalapack:arpack:"
#endif
