/* src/config.h.  Generated from config.h.in by configure.  */
/* src/config.h.in.  Generated from configure.ac by autoheader.  */

#ifndef __SIGSCHEME_CONFIG_H
#define __SIGSCHEME_CONFIG_H

/* Define if building universal (internal helper macro) */
/* #undef AC_APPLE_UNIVERSAL_BUILD */

/* The normal alignment of `char', in bytes. */
#define ALIGNOF_CHAR 1

/* The normal alignment of `double', in bytes. */
#define ALIGNOF_DOUBLE 8

/* The normal alignment of `float', in bytes. */
#define ALIGNOF_FLOAT 4

/* The normal alignment of `int', in bytes. */
#define ALIGNOF_INT 4

/* The normal alignment of `int16_t', in bytes. */
#define ALIGNOF_INT16_T 2

/* The normal alignment of `int32_t', in bytes. */
#define ALIGNOF_INT32_T 4

/* The normal alignment of `int64_t', in bytes. */
#define ALIGNOF_INT64_T 8

/* The normal alignment of `int8_t', in bytes. */
#define ALIGNOF_INT8_T 1

/* The normal alignment of `intmax_t', in bytes. */
#define ALIGNOF_INTMAX_T 8

/* The normal alignment of `intptr_t', in bytes. */
#define ALIGNOF_INTPTR_T 8

/* The normal alignment of `long', in bytes. */
#define ALIGNOF_LONG 8

/* The normal alignment of `long double', in bytes. */
#define ALIGNOF_LONG_DOUBLE 16

/* The normal alignment of `long long', in bytes. */
#define ALIGNOF_LONG_LONG 8

/* The normal alignment of `short', in bytes. */
#define ALIGNOF_SHORT 2

/* The normal alignment of `size_t', in bytes. */
#define ALIGNOF_SIZE_T 8

/* The normal alignment of `void *', in bytes. */
#define ALIGNOF_VOID_P 8

/* Define to 1 if the right shift operation is arithmetic. */
#define HAVE_ARITHMETIC_RSHIFT 1

/* Define to 1 if you have the <assert.h> header file. */
#define HAVE_ASSERT_H 1

/* Define to 1 if va_list is an array type. */
#define HAVE_AUTOREFERRED_PASSED_VA_LIST 1

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define to 1 if you have the `fileno' function. */
#define HAVE_FILENO 1

/* Define to 1 if you have the `getcontext' function. */
#define HAVE_GETCONTEXT 1

/* Define to 1 if you have the `getcwd' function. */
#define HAVE_GETCWD 1

/* Define to 1 if you have the `getpagesize' function. */
#define HAVE_GETPAGESIZE 1

/* Define to 1 if you have the GNU libc. */
#define HAVE_GLIBC 1

/* Define to 1 if the system has the type `intmax_t'. */
#define HAVE_INTMAX_T 1

/* Define to 1 if the system has the type `intptr_t'. */
#define HAVE_INTPTR_T 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the <limits.h> header file. */
#define HAVE_LIMITS_H 1

/* Define to 1 if the system has the type `long double'. */
#define HAVE_LONG_DOUBLE 1

/* Define to 1 if the type `long double' works and has more range or precision
   than `double'. */
#define HAVE_LONG_DOUBLE_WIDER 1

/* Define to 1 if the system has the type `long long int'. */
#define HAVE_LONG_LONG_INT 1

/* Define to 1 if you have the <malloc.h> header file. */
#define HAVE_MALLOC_H 1

/* Define to 1 if you have the `memalign' function. */
#define HAVE_MEMALIGN 1

/* Define if `malloc'ing more than one page always returns a page-aligned
   address. */
/* #undef HAVE_PAGE_ALIGNED_MALLOC */

/* Define to 1 if you have the `posix_memalign' function. */
#define HAVE_POSIX_MEMALIGN 1

/* Define to 1 if f(va_list va){ &va; } works as expected. */
/* #undef HAVE_REFERENCEABLE_PASSED_VA_LIST */

/* Define to 1 if you have the `sigsetjmp' (and 'siglongjmp') function or
   macro. */
#define HAVE_SIGSETJMP 1

/* Define to 1 if you have the <stddef.h> header file. */
#define HAVE_STDDEF_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the `strcasecmp' function. */
#define HAVE_STRCASECMP 1

/* Define to 1 if you have the `strdup' function. */
#define HAVE_STRDUP 1

/* Define to 1 if cpp supports the ANSI # stringizing operator. */
#define HAVE_STRINGIZE 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the `strtoimax' function. */
#define HAVE_STRTOIMAX 1

/* Define to 1 if you have the `strtoll' function. */
#define HAVE_STRTOLL 1

/* Define to 1 if you have the <sys/inttypes.h> header file. */
/* #undef HAVE_SYS_INTTYPES_H */

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if the system has the type `uintmax_t'. */
#define HAVE_UINTMAX_T 1

/* Define to 1 if the system has the type `uintptr_t'. */
#define HAVE_UINTPTR_T 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to 1 if the system has the type `unsigned long long int'. */
#define HAVE_UNSIGNED_LONG_LONG_INT 1

/* define if your compiler has __attribute__ */
#define HAVE___ATTRIBUTE__ 1

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#define LT_OBJDIR ".libs/"

/* Name of package */
#define PACKAGE "sigscheme"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "sigscheme-ja@googlegroups.com"

/* Define to the full name of this package. */
#define PACKAGE_NAME "SigScheme"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "SigScheme 0.9.1"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "sigscheme"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "0.9.1"

/* type assertion on Scheme object accessors */
/* #undef SCM_ACCESSOR_ASSERT */

/* some SIOD compatible features */
/* #undef SCM_COMPAT_SIOD */

/* emulating the buggy behaviors of SIOD */
/* #undef SCM_COMPAT_SIOD_BUGS */

/* immutable list literals */
/* #undef SCM_CONST_LIST_LITERAL */

/* immutable vector literals */
#define SCM_CONST_VECTOR_LITERAL 1

/* debug mode */
/* #undef SCM_DEBUG */

/* frame-separator on backtrace */
/* #undef SCM_DEBUG_BACKTRACE_SEP */

/* values printing on backtrace */
/* #undef SCM_DEBUG_BACKTRACE_VAL */

/* encoding-related functions debugging */
/* #undef SCM_DEBUG_ENCODING */

/* macro and pattern matching debugging */
/* #undef SCM_DEBUG_MACRO */

/* parser debugging */
/* #undef SCM_DEBUG_PARSER */

/* port debugging */
/* #undef SCM_DEBUG_PORT */

/* Define to 1 to adapt encoding.c to SigScheme. */
#define SCM_ENCODING_USE_WITH_SIGSCHEME 1

/* Define to 1 to adapt scmport*.[hc] to SigScheme. */
#define SCM_SCMPORT_USE_WITH_SIGSCHEME 1

/* recovery from failed SCM_ASSERT() */
/* #undef SCM_SOFT_ASSERT */

/* strict check for form arguments */
#define SCM_STRICT_ARGCHECK 1

/* all feasible encoding error checks */
#define SCM_STRICT_ENCODING_CHECK 1

/* rejecting quote-less () */
/* #undef SCM_STRICT_NULL_FORM */

/* strict R5RS conformance checks */
/* #undef SCM_STRICT_R5RS */

/* strict check for R5RS top-level definitions */
#define SCM_STRICT_TOPLEVEL_DEFINITIONS 1

/* rejecting quote-less vector literal */
#define SCM_STRICT_VECTOR_FORM 1

/* 32bit_fixnum */
/* #undef SCM_USE_32BIT_FIXNUM */

/* 32bit_scmref */
/* #undef SCM_USE_32BIT_SCMREF */

/* 64bit_fixnum */
/* #undef SCM_USE_64BIT_FIXNUM */

/* 64bit_scmref */
/* #undef SCM_USE_64BIT_SCMREF */

/* showing backtrace on error */
/* #undef SCM_USE_BACKTRACE */

/* R5RS characters */
#define SCM_USE_CHAR 1

/* R5RS complex numbers (not implemented yet) */
/* #undef SCM_USE_COMPLEX */

/* R5RS continuation */
#define SCM_USE_CONTINUATION 1

/* all c[ad]+r procedures defined in R5RS */
#define SCM_USE_DEEP_CADRS 1

/* storage dump (not implemented yet) */
/* #undef SCM_USE_DUMP */

/* EUC-CN character encoding */
/* #undef SCM_USE_EUCCN */

/* euccn_as_default */
/* #undef SCM_USE_EUCCN_AS_DEFAULT */

/* EUC-JP character encoding */
/* #undef SCM_USE_EUCJP */

/* eucjp_as_default */
/* #undef SCM_USE_EUCJP_AS_DEFAULT */

/* EUC-KR character encoding */
/* #undef SCM_USE_EUCKR */

/* euckr_as_default */
/* #undef SCM_USE_EUCKR_AS_DEFAULT */

/* eval_c_string() of libsscm */
#define SCM_USE_EVAL_C_STRING 1

/* intermediate format strings */
#define SCM_USE_FORMAT 1

/* R5RS hygienic macros (experimental) */
/* #undef SCM_USE_HYGIENIC_MACRO */

/* R5RS integer numbers */
#define SCM_USE_INT 1

/* R5RS internal definitions */
#define SCM_USE_INTERNAL_DEFINITIONS 1

/* intptr_scmref */
#define SCM_USE_INTPTR_SCMREF 1

/* int_fixnum */
/* #undef SCM_USE_INT_FIXNUM */

/* 'define-macro' syntactic closure */
#define SCM_USE_LEGACY_MACRO 1

/* building libsscm */
#define SCM_USE_LIBSSCM 1

/* R5RS 'load' */
#define SCM_USE_LOAD 1

/* long_fixnum */
#define SCM_USE_LONG_FIXNUM 1

/* multibyte_char */
#define SCM_USE_MULTIBYTE_CHAR 1

/* null character in a middle of a string (experimental) */
/* #undef SCM_USE_NULL_CAPABLE_STRING */

/* R5RS numbers */
#define SCM_USE_NUMBER 1

/* number_io */
#define SCM_USE_NUMBER_IO 1

/* R5RS ports */
#define SCM_USE_PORT 1

/* R5RS promises */
#define SCM_USE_PROMISE 1

/* R5RS quasiquotation */
#define SCM_USE_QUASIQUOTE 1

/* R6RS characters (preliminary) */
#define SCM_USE_R6RS_CHARS 1

/* named characters of R6RS (preliminary) */
#define SCM_USE_R6RS_NAMED_CHARS 1

/* R5RS rational numbers (not implemented yet) */
/* #undef SCM_USE_RATIONAL */

/* internal format which takes raw C values from va_list */
#define SCM_USE_RAW_C_FORMAT 1

/* R5RS 'read' */
#define SCM_USE_READER 1

/* R5RS real numbers (not implemented yet) */
/* #undef SCM_USE_REAL */

/* the 'sscm' interactive shell */
#define SCM_USE_SHELL 1

/* singlebyte_as_default */
/* #undef SCM_USE_SINGLEBYTE_AS_DEFAULT */

/* Shift_JIS character encoding */
/* #undef SCM_USE_SJIS */

/* sjis_as_default */
/* #undef SCM_USE_SJIS_AS_DEFAULT */

/* SRFI-0 'cond-expand' */
#define SCM_USE_SRFI0 1

/* SRFI-1 list library */
#define SCM_USE_SRFI1 1

/* SRFI-2 'and-let*' */
#define SCM_USE_SRFI2 1

/* SRFI-22 running scheme scripts on Unix (partial) */
#define SCM_USE_SRFI22 1

/* SRFI-23 'error' */
#define SCM_USE_SRFI23 1

/* SRFI-28 'format' */
#define SCM_USE_SRFI28 1

/* SRFI-34 exception handling for programs */
#define SCM_USE_SRFI34 1

/* SRFI-38 'write/ss' ('read/ss' is not provided) */
#define SCM_USE_SRFI38 1

/* SRFI-43 vector library */
#define SCM_USE_SRFI43 1

/* SRFI-48 'format' (superset of SRFI-28) */
#define SCM_USE_SRFI48 1

/* SRFI-55 'require-extension' */
#define SCM_USE_SRFI55 1

/* SRFI-6 basic string ports */
#define SCM_USE_SRFI6 1

/* SRFI-60 integers as bits (partial) */
#define SCM_USE_SRFI60 1

/* SRFI-69 basic hash tables */
#define SCM_USE_SRFI69 1

/* SRFI-8 'receive' */
#define SCM_USE_SRFI8 1

/* SRFI-9 defining record types */
#define SCM_USE_SRFI9 1

/* SRFI-95 sorting and merging */
#define SCM_USE_SRFI95 1

/* SigScheme-specific extensions */
#define SCM_USE_SSCM_EXTENSIONS 1

/* SigScheme-specific 'format+' */
#define SCM_USE_SSCM_FORMAT_EXTENSION 1

/* storage_compact */
#define SCM_USE_STORAGE_COMPACT 1

/* storage_fatty */
/* #undef SCM_USE_STORAGE_FATTY */

/* primary procedures of R5RS strings */
#define SCM_USE_STRING 1

/* string_procedure */
#define SCM_USE_STRING_PROCEDURE 1

/* 'syntax-case' (not implemented yet) */
/* #undef SCM_USE_SYNTAX_CASE */

/* syntactic closure (not implemented yet) */
/* #undef SCM_USE_UNHYGIENIC_MACRO */

/* UTF-8 character encoding */
#define SCM_USE_UTF8 1

/* utf8_as_default */
#define SCM_USE_UTF8_AS_DEFAULT 1

/* valuecons for efficient multiple values handling */
/* #undef SCM_USE_VALUECONS */

/* R5RS vectors */
#define SCM_USE_VECTOR 1

/* suppressing compiler warnings */
#define SCM_USE_WARNING_SUPPRESSOR 1

/* R5RS 'write' and 'display' */
#define SCM_USE_WRITER 1

/* The size of `char', as computed by sizeof. */
#define SIZEOF_CHAR 1

/* The size of `double', as computed by sizeof. */
#define SIZEOF_DOUBLE 8

/* The size of `float', as computed by sizeof. */
#define SIZEOF_FLOAT 4

/* The size of `int', as computed by sizeof. */
#define SIZEOF_INT 4

/* The size of `int16_t', as computed by sizeof. */
#define SIZEOF_INT16_T 2

/* The size of `int32_t', as computed by sizeof. */
#define SIZEOF_INT32_T 4

/* The size of `int64_t', as computed by sizeof. */
#define SIZEOF_INT64_T 8

/* The size of `int8_t', as computed by sizeof. */
#define SIZEOF_INT8_T 1

/* The size of `intmax_t', as computed by sizeof. */
#define SIZEOF_INTMAX_T 8

/* The size of `intptr_t', as computed by sizeof. */
#define SIZEOF_INTPTR_T 8

/* The size of `long', as computed by sizeof. */
#define SIZEOF_LONG 8

/* The size of `long double', as computed by sizeof. */
#define SIZEOF_LONG_DOUBLE 16

/* The size of `long long', as computed by sizeof. */
#define SIZEOF_LONG_LONG 8

/* The size of `short', as computed by sizeof. */
#define SIZEOF_SHORT 2

/* The size of `size_t', as computed by sizeof. */
#define SIZEOF_SIZE_T 8

/* The size of `void*', as computed by sizeof. */
#define SIZEOF_VOIDP 8

/* The size of `void *', as computed by sizeof. */
#define SIZEOF_VOID_P 8

/* Define to 1 if all of the C90 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define STDC_HEADERS 1

/* Version number of package */
#define VERSION "0.9.1"

/* Define WORDS_BIGENDIAN to 1 if your processor stores words with the most
   significant byte first (like Motorola and SPARC, unlike Intel). */
#if defined AC_APPLE_UNIVERSAL_BUILD
# if defined __BIG_ENDIAN__
#  define WORDS_BIGENDIAN 1
# endif
#else
# ifndef WORDS_BIGENDIAN
/* #  undef WORDS_BIGENDIAN */
# endif
#endif

/* Define to 1 if it is needed to enable strcasecmp(3). */
#if SCM_COMPILING_LIBSSCM
#define _BSD_SOURCE 1
#endif

/* Define to 200112L to enable posix_memalign(3). */
#if SCM_COMPILING_LIBSSCM
#define _POSIX_C_SOURCE 200112L
#endif

/* Define for Solaris 2.5.1 so the uint32_t typedef from <sys/synch.h>,
   <pthread.h>, or <semaphore.h> is not used. If the typedef were allowed, the
   #define below would cause a syntax error. */
/* #undef _UINT32_T */

/* Define for Solaris 2.5.1 so the uint64_t typedef from <sys/synch.h>,
   <pthread.h>, or <semaphore.h> is not used. If the typedef were allowed, the
   #define below would cause a syntax error. */
/* #undef _UINT64_T */

/* Define for Solaris 2.5.1 so the uint8_t typedef from <sys/synch.h>,
   <pthread.h>, or <semaphore.h> is not used. If the typedef were allowed, the
   #define below would cause a syntax error. */
/* #undef _UINT8_T */

/* Define to 500 to enable strdup(3). */
#if SCM_COMPILING_LIBSSCM
#define _XOPEN_SOURCE 500
#endif

/* Define to 1 if type `char' is unsigned and your compiler does not
   predefine this macro.  */
#ifndef __CHAR_UNSIGNED__
/* # undef __CHAR_UNSIGNED__ */
#endif

/* Define to empty if `const' does not conform to ANSI C. */
/* #undef const */

/* Define to `__inline__' or `__inline' if that's what the C compiler
   calls it, or to nothing if 'inline' is not supported under any name.  */
#ifndef __cplusplus
/* #undef inline */
#endif

/* Define to the type of a signed integer type of width exactly 16 bits if
   such a type exists and the standard includes do not define it. */
/* #undef int16_t */

/* Define to the type of a signed integer type of width exactly 32 bits if
   such a type exists and the standard includes do not define it. */
/* #undef int32_t */

/* Define to the type of a signed integer type of width exactly 64 bits if
   such a type exists and the standard includes do not define it. */
/* #undef int64_t */

/* Define to the type of a signed integer type of width exactly 8 bits if such
   a type exists and the standard includes do not define it. */
/* #undef int8_t */

/* Define to the widest signed integer type if <stdint.h> and <inttypes.h> do
   not define. */
/* #undef intmax_t */

/* Define to the type of a signed integer type wide enough to hold a pointer,
   if such a type exists, and if the system does not define it. */
/* #undef intptr_t */

/* Define to the equivalent of the C99 'restrict' keyword, or to
   nothing if this is not supported.  Do not define if restrict is
   supported only directly.  */
#define restrict __restrict__
/* Work around a bug in older versions of Sun C++, which did not
   #define __restrict__ or support _Restrict or __restrict__
   even though the corresponding Sun C compiler ended up with
   "#define restrict _Restrict" or "#define restrict __restrict__"
   in the previous line.  This workaround can be removed once
   we assume Oracle Developer Studio 12.5 (2016) or later.  */
#if defined __SUNPRO_CC && !defined __RESTRICT && !defined __restrict__
# define _Restrict
# define __restrict__
#endif

/* Define to `unsigned int' if <sys/types.h> does not define. */
/* #undef size_t */

/* Define to `int' if <sys/types.h> does not define. */
/* #undef ssize_t */

/* Define to the type of an unsigned integer type of width exactly 16 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint16_t */

/* Define to the type of an unsigned integer type of width exactly 32 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint32_t */

/* Define to the type of an unsigned integer type of width exactly 64 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint64_t */

/* Define to the type of an unsigned integer type of width exactly 8 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint8_t */

/* Define to the widest unsigned integer type if <stdint.h> and <inttypes.h>
   do not define. */
/* #undef uintmax_t */

/* Define to the type of an unsigned integer type wide enough to hold a
   pointer, if such a type exists, and if the system does not define it. */
/* #undef uintptr_t */

/* Define to empty if the keyword `volatile' does not work. Warning: valid
   code using `volatile' can become incorrect without. Disable with care. */
/* #undef volatile */


/* FIXME: temporary solution */
#include "config-old.h"

#endif /* __SIGSCHEME_CONFIG_H */
