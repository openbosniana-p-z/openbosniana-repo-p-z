These are the model files from which the UR10 example was built.
However, the example itself uses an explicit Simbody model rather than
reading in a .urdf model file directly.
