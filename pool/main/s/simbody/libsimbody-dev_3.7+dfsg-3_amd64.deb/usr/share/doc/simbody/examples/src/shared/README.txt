This subdirectory is for files that are shared by more than one Simbody
example. That may include header files, source code, geometry, drawings,
or anything else that makes sense.

These files will get installed along with the examples; make sure your
example program can find what it needs to run or to build from an 
installed copy of Simbody.
