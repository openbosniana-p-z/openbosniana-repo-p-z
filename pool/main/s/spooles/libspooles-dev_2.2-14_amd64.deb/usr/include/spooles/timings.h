#ifndef _TIMINGS_
#define _TIMINGS_
#include <sys/time.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
static struct timeval  TV ;
#define MARKTIME(t) \
   gettimeofday(&TV, NULL) ; \
   t = (TV.tv_sec + 0.000001*TV.tv_usec)
#endif

