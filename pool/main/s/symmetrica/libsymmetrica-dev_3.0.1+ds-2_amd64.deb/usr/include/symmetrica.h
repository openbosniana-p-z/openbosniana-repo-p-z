/* Public interface header for client programs. */
#include <symmetrica/def.h>
#include <symmetrica/macro.h>
