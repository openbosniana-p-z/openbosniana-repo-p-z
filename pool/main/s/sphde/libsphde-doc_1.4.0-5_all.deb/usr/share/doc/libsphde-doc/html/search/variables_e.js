var searchData=
[
  ['sasclearondealloc_0',['sasClearOnDealloc',['../sassim_8h.html#aea3f2fe03f4b74be814ce6bc59d54e4c',1,'sassim.h']]],
  ['saslockowner_1',['SasLockOwner',['../saslock_8h.html#afa2a9e0ef22fb20ccea8426a03d50c18',1,'saslock.h']]],
  ['sph_5fcpu_5ffrequency_2',['sph_cpu_frequency',['../sphtimer_8h.html#a364eaec71a1f6d77431ae36bcbd6a96d',1,'sphtimer.h']]],
  ['start_5flog_3',['start_log',['../structSPHLFLogIterator__t.html#a5ea4f0e86251f8890e7705870de41632',1,'SPHLFLogIterator_t']]],
  ['subcat_4',['subcat',['../structsphLogEntryLayout__t.html#a1d76978ffdf63cd07bb7044c48f1eaad',1,'sphLogEntryLayout_t::subcat()'],['../structsphLFEntryLayout__t.html#a09b9ff16c654e56232263edc17744bfe',1,'sphLFEntryLayout_t::subcat()']]]
];
