var searchData=
[
  ['_5f_5freserved_0',['__reserved',['../structsphLogEntryLayout__t.html#ac0f924e5a452c8a5bdc40116f271cedd',1,'sphLogEntryLayout_t::__reserved()'],['../structsphLFEntryLayout__t.html#a1f6fc44ba35978a12757ef3037c0c3cf',1,'sphLFEntryLayout_t::__reserved()']]]
];
