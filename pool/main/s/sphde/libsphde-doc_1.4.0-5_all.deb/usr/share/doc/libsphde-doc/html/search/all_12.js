var searchData=
[
  ['valid_0',['valid',['../structsphLogEntryLayout__t.html#abd2bb4e513f6efa231ca9b24f01ec6ac',1,'sphLogEntryLayout_t::valid()'],['../structsphLFEntryLayout__t.html#ae224bc1d3d13a71baaa326b76e82ffa2',1,'sphLFEntryLayout_t::valid()']]],
  ['vm_5faddress_5ft_1',['vm_address_t',['../saslock_8h.html#ac8ba6746799005639a7156774b7300c2',1,'saslock.h']]]
];
