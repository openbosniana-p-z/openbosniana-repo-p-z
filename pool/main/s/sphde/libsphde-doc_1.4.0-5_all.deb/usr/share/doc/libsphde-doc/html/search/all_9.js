var searchData=
[
  ['len_0',['len',['../structsphLogEntryLayout__t.html#aa99e366f4c32b3cd82b0fc0c419f93f4',1,'sphLogEntryLayout_t::len()'],['../structsphLFEntryLayout__t.html#a5caabfaef4f6c9e0d3ddc21024a3d6c0',1,'sphLFEntryLayout_t::len()']]],
  ['logger_1',['logger',['../structSPHLFLogIterator__t.html#a06d631636fab465dcf4c27233ea5e557',1,'SPHLFLogIterator_t']]],
  ['logiter_2',['logIter',['../structSPHLFPortalIterator__t.html#a26a8af8732cd7b4de9faed3e65cbd90c',1,'SPHLFPortalIterator_t']]],
  ['longptr_5ft_3',['longPtr_t',['../sphlflogger_8h.html#a9e89948a0b6d5380f0dd2a41b945dc26',1,'longPtr_t():&#160;sphlflogger.h'],['../sphlfentry_8h.html#a9e89948a0b6d5380f0dd2a41b945dc26',1,'longPtr_t():&#160;sphlfentry.h']]]
];
