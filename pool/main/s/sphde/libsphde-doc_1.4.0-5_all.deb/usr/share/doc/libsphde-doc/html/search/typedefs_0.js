var searchData=
[
  ['longptr_5ft_0',['longPtr_t',['../sphlflogger_8h.html#a9e89948a0b6d5380f0dd2a41b945dc26',1,'longPtr_t():&#160;sphlflogger.h'],['../sphlfentry_8h.html#a9e89948a0b6d5380f0dd2a41b945dc26',1,'longPtr_t():&#160;sphlfentry.h']]]
];
