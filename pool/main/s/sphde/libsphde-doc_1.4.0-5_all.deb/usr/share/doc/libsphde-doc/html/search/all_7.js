var searchData=
[
  ['idunit_0',['idUnit',['../unionsphLogEntry__t.html#a727500786e20a47cc9232458b6670e7c',1,'sphLogEntry_t::idUnit()'],['../unionsphLFEntry__t.html#adc0e377a664299f1d4d41a18fd42b451',1,'sphLFEntry_t::idUnit()']]],
  ['int64_5fkey_1',['int64_key',['../unionsasindexkeymap__t.html#a9b68a570f79ef8a68b01a89f359e7f82',1,'sasindexkeymap_t']]]
];
