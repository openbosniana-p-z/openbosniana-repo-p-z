var searchData=
[
  ['getcurrentprojectcontext_0',['getCurrentProjectContext',['../sphcontext_8h.html#ab3b26b7dbebb89f6578540f41cf03afc',1,'sphcontext.h']]],
  ['getmemhigh_1',['getMemHigh',['../sassim_8h.html#a6a2371a5b9bb2b4e7acf2fc7385359e4',1,'sassim.h']]],
  ['getmemlow_2',['getMemLow',['../sassim_8h.html#a9ee7be9d68e029d74d6c710c6693bdbb',1,'sassim.h']]],
  ['getprojectcontextbyname_3',['getProjectContextByName',['../sphcontext_8h.html#a3e68eeb2c11dcd6cbbf47f2a1143fefb',1,'sphcontext.h']]],
  ['getsasfinder_4',['getSASFinder',['../sassim_8h.html#a8d0fd79a0726df5994c6e6fd4533eb17',1,'sassim.h']]]
];
