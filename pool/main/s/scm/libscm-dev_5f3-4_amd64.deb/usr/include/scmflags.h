#define IMPLINIT "Init5f3.scm"
#define INITS init_sc2();init_ioext();
#define COMPILED_INITS init_ramap();init_record();init_gsubr();init_edline();init_rgx();init_socket();init_posix();init_unix();init_crs();init_x();init_differ();
#define CAUTIOUS
#define BIGNUMS
#define ARRAYS
#define FLOATS
#define CCLO
#define TICKS
#define CAN_DUMP
#define MACRO
