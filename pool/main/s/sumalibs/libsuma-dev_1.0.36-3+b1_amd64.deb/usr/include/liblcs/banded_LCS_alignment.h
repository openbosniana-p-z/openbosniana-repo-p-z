/*
 * banded_LCS_alignment.h
 *
 *  Created on: november 8, 2012
 *      Author: mercier
 */


double banded_lcs_align(int16_t* seq1, int16_t* seq2, int l1, int l2, double threshold, BOOL n, int ref, BOOL lcsmode, int16_t* address);
