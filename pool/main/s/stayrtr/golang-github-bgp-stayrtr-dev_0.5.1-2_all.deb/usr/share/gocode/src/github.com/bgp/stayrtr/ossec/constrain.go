// +build !openbsd

package ossec

func PledgePromises(promises string) error {
	return nil
}
