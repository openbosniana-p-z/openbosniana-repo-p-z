var fax_8c =
[
    [ "HDLC_FRAMING_OK_THRESHOLD", "fax_8c.html#a35630af13cdf4a5b011b86e2d0fa935e", null ],
    [ "fax_free", "fax_8c.html#a69d694c9287f4c0591a835b3e4071d2a", null ],
    [ "fax_get_logging_state", "fax_8c.html#aef12e004d3b78c5ce0d35c87fb11a4b1", null ],
    [ "fax_get_t30_state", "fax_8c.html#ae6cca297be2d48d9d0fe1118fb4259d1", null ],
    [ "fax_init", "fax_8c.html#a3be96fbb2115b6e99fea37431b0ec26c", null ],
    [ "fax_release", "fax_8c.html#aaf4f155f00d612301c03525a5623d305", null ],
    [ "fax_restart", "fax_8c.html#a55e66f521ca5e5b1693be6f3852ec06c", null ],
    [ "fax_rx", "fax_8c.html#a7583da8ebe555cfa3ed4c1469234ba42", null ],
    [ "fax_rx_fillin", "fax_8c.html#a007d11caa4f6b2082122251350e09310", null ],
    [ "fax_set_tep_mode", "fax_8c.html#ad60854cc71eaf4106efac0e0d56a2ede", null ],
    [ "fax_set_transmit_on_idle", "fax_8c.html#a37693f8bc74056939a7f844dc7b19ce3", null ],
    [ "fax_tx", "fax_8c.html#aeb7f78fc3396ab1a75a915c110053e29", null ]
];