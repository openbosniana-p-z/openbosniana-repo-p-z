var gsm0610__tests_8c =
[
    [ "BLOCK_LEN", "gsm0610__tests_8c.html#ad5df2c41c5104642db3277574068043f", null ],
    [ "HIST_LEN", "gsm0610__tests_8c.html#aded5babbee1b6f90b7cb4500bfb1f227", null ],
    [ "IN_FILE_NAME", "gsm0610__tests_8c.html#a8118656bb5a60090a1dbffa402168438", null ],
    [ "OUT_FILE_NAME", "gsm0610__tests_8c.html#a75506823f0db0ef3f4f022cf132dbbbb", null ],
    [ "SPANDSP_EXPOSE_INTERNAL_STRUCTURES", "gsm0610__tests_8c.html#a4dbcfe9986d8f3d4d39f3e395fc96c0c", null ],
    [ "TESTDATA_DIR", "gsm0610__tests_8c.html#ad23ee34c7deaaf0b349ab19b3b936c16", null ],
    [ "main", "gsm0610__tests_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "code_vector", "gsm0610__tests_8c.html#aa1811e36262db703cd5ef020fbcccf00", null ],
    [ "code_vector_buf", "gsm0610__tests_8c.html#a7482458e505da4f7077d10455e63b9b5", null ],
    [ "decoder_code_vector", "gsm0610__tests_8c.html#a697fb4bc98b496fe1dad2c10524b3bd8", null ],
    [ "in_vector", "gsm0610__tests_8c.html#a086871f9707822d1ad10a8ac2c49f0de", null ],
    [ "law_in_vector", "gsm0610__tests_8c.html#a9e2896e50c175dc278e461a23a679a9f", null ],
    [ "law_out_vector", "gsm0610__tests_8c.html#a5291e80a1d0bb3eb560d906e69dfb096", null ],
    [ "out_vector", "gsm0610__tests_8c.html#aa72a2e37cb11a719be2af02510f4578e", null ],
    [ "ref_code_vector", "gsm0610__tests_8c.html#a680b136c26091471c89fb67a915e1afe", null ],
    [ "ref_law_out_vector", "gsm0610__tests_8c.html#a86f7864021e1a7abf9ae249b50f5ca5f", null ],
    [ "ref_out_vector", "gsm0610__tests_8c.html#a075f54a7ad9f21baa57f09d26f261d05", null ],
    [ "vector_len", "gsm0610__tests_8c.html#a25fadd6c6efe6b0ec76577867e4e404d", null ]
];