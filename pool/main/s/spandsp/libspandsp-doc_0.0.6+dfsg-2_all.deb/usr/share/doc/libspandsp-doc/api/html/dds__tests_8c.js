var dds__tests_8c =
[
    [ "OUTPUT_FILE_NAME", "dds__tests_8c.html#ab0c4c9ae8d3b88ac57ad0e488c6507c2", null ],
    [ "OUTPUT_FILE_NAME_COMPLEX", "dds__tests_8c.html#ac3e5bebfc0619d98722bfe8e36705bf6", null ],
    [ "SAMPLES_PER_CHUNK", "dds__tests_8c.html#a22f19f7dca15ce7e9b2d2bf451cbab7f", null ],
    [ "main", "dds__tests_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ]
];