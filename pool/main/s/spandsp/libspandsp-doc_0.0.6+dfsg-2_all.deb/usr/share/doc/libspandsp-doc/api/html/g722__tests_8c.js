var g722__tests_8c =
[
    [ "BLOCK_LEN", "g722__tests_8c.html#ad5df2c41c5104642db3277574068043f", null ],
    [ "EIGHTK_IN_FILE_NAME", "g722__tests_8c.html#a986fb14a8e6a3e7628c740def1d148f0", null ],
    [ "ENCODED_FILE_NAME", "g722__tests_8c.html#a42f7ec054f20efb306a1bb7cf32a8588", null ],
    [ "G722_SAMPLE_RATE", "g722__tests_8c.html#a16d2b612a220a33c97a0292a172a2eab", null ],
    [ "IN_FILE_NAME", "g722__tests_8c.html#a8118656bb5a60090a1dbffa402168438", null ],
    [ "MAX_TEST_VECTOR_LEN", "g722__tests_8c.html#a56b39cb1ba4c528ab14f0e6b65ed9537", null ],
    [ "OUT_FILE_NAME", "g722__tests_8c.html#a75506823f0db0ef3f4f022cf132dbbbb", null ],
    [ "TESTDATA_DIR", "g722__tests_8c.html#ad23ee34c7deaaf0b349ab19b3b936c16", null ],
    [ "main", "g722__tests_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "compressed", "g722__tests_8c.html#a2cd097883f77bbf75eac9ad831fc0845", null ],
    [ "decompressed", "g722__tests_8c.html#a785ec9a10991a8d4ef7f9e22bd2f173c", null ],
    [ "itu_data", "g722__tests_8c.html#aebd14bda78885e305008f70b62b313a9", null ],
    [ "itu_ref", "g722__tests_8c.html#aa8e5fc74c1a3f45a936938c67d9e2e67", null ],
    [ "itu_ref_upper", "g722__tests_8c.html#a446b5cf283b8a2809d9506019af8685f", null ]
];