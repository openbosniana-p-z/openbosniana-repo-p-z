var math__fixed_8c =
[
    [ "fixed_atan2", "math__fixed_8c.html#aea1238a416fea6f15e08453248276c22", null ],
    [ "fixed_cos", "math__fixed_8c.html#a078e417a1fee2722d8965ee128d367f4", null ],
    [ "fixed_divide16", "math__fixed_8c.html#ac7a7e0849eebcd17f3a6f57b91c539b2", null ],
    [ "fixed_divide32", "math__fixed_8c.html#afae7bc33b6b7e9abf720a2c62a60bddb", null ],
    [ "fixed_log10_16", "math__fixed_8c.html#a283f1951b09fa33e7bddeb59855d9156", null ],
    [ "fixed_log10_32", "math__fixed_8c.html#ad7941423c8a42474bfb873b5e2e08b1c", null ],
    [ "fixed_reciprocal16", "math__fixed_8c.html#af09433989fd29781d7e088e29243974d", null ],
    [ "fixed_sin", "math__fixed_8c.html#a636879c0d155d3a4b24369a78ca104bf", null ],
    [ "fixed_sqrt16", "math__fixed_8c.html#a3677786dd56d8bc58ffe5d79a1c2a8a2", null ],
    [ "fixed_sqrt32", "math__fixed_8c.html#a96a2de65a6084ef80839b7fb4a814588", null ]
];