var g726__tests_8c =
[
    [ "test_set_t", "structtest__set__t.html", "structtest__set__t" ],
    [ "BLOCK_LEN", "g726__tests_8c.html#ad5df2c41c5104642db3277574068043f", null ],
    [ "G726_ENCODING_NONE", "g726__tests_8c.html#a78e4149cdb8d0776e7fd16665a725ef5", null ],
    [ "IN_FILE_NAME", "g726__tests_8c.html#a8118656bb5a60090a1dbffa402168438", null ],
    [ "MAX_TEST_VECTOR_LEN", "g726__tests_8c.html#a56b39cb1ba4c528ab14f0e6b65ed9537", null ],
    [ "OUT_FILE_NAME", "g726__tests_8c.html#a75506823f0db0ef3f4f022cf132dbbbb", null ],
    [ "SPANDSP_EXPOSE_INTERNAL_STRUCTURES", "g726__tests_8c.html#a4dbcfe9986d8f3d4d39f3e395fc96c0c", null ],
    [ "TESTDATA_DIR", "g726__tests_8c.html#ad23ee34c7deaaf0b349ab19b3b936c16", null ],
    [ "main", "g726__tests_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "adpcmdata", "g726__tests_8c.html#a2d224a0503ee494344338e78441e33d6", null ],
    [ "itu_ref", "g726__tests_8c.html#af758e93d5ba163e40edb24b97df7901a", null ],
    [ "itudata", "g726__tests_8c.html#a20165ba809ae1b8e2e2facbc645c52db", null ],
    [ "outdata", "g726__tests_8c.html#aec3db96e6e9c48f2c26dacc335838701", null ],
    [ "unpacked", "g726__tests_8c.html#a49a65d82923586b8a00f7007ca98d87b", null ],
    [ "xlaw", "g726__tests_8c.html#ab945e037f0082b64f0fb9dec3b16af64", null ]
];