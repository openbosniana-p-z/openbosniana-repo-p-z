var awgn_8h =
[
    [ "awgn_state_t", "awgn_8h.html#adeeeab36549c901bffb8347c583bf6a8", null ],
    [ "awgn", "awgn_8h.html#acffb6b9f3ddfce6bce0b10b52a73a348", null ],
    [ "awgn_free", "awgn_8h.html#ade4c5dd1743f9ea1f529a6b298375647", null ],
    [ "awgn_init_dbm0", "awgn_8h.html#a0b96435f480a8659f0905a7565c767bf", null ],
    [ "awgn_init_dbov", "awgn_8h.html#afbcc7444e435a61b4f88b09f2ff405cf", null ],
    [ "awgn_release", "awgn_8h.html#a897fe07ec4c2b3c40b37c88271be4dac", null ]
];