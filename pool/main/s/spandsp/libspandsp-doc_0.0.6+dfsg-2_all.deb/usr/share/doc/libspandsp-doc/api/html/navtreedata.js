var NAVTREE =
[
  [ "spandsp", "index.html", [
    [ "Telephony line model construction", "make_line_models_page.html", [
      [ "What does it do?", "make_line_models_page.html#make_line_models_page_sec_1", null ],
      [ "How does it work?", "make_line_models_page.html#make_line_models_page_sec_2", null ]
    ] ],
    [ "G.1050/TIA-921 IP network path model", "g1050_ip_network_model_page.html", [
      [ "What does it do?", "g1050_ip_network_model_page.html#g1050_ip_network_model_page_sec_1", null ]
    ] ],
    [ "Telephone line model", "line_model_page.html", [
      [ "What does it do?", "line_model_page.html#line_model_page_sec_1", null ]
    ] ],
    [ "RFC2198 simulation", "rfc2198_model_page.html", [
      [ "What does it do?", "rfc2198_model_page.html#rfc2198_model_page_sec_1", null ]
    ] ],
    [ "ADSI transmission and reception", "adsi_page.html", [
      [ "What does it do?", "adsi_page.html#adsi_page_sec_1", null ],
      [ "How does it work?", "adsi_page.html#adsi_page_sec_2", null ],
      [ "The Bellcore CLASS specification", "adsi_page.html#adsi_page_sec_2a", null ],
      [ "CHANNEL SEIZURE SIGNAL", "adsi_page.html#adsi_page_sec_2a1", null ],
      [ "CARRIER SIGNAL", "adsi_page.html#adsi_page_sec_2a2", null ],
      [ "MESSAGE TYPE WORD", "adsi_page.html#adsi_page_sec_2a3", null ],
      [ "MESSAGE LENGTH WORD", "adsi_page.html#adsi_page_sec_2a4", null ],
      [ "DATA WORDS", "adsi_page.html#adsi_page_sec_2a5", null ],
      [ "CHECKSUM WORD", "adsi_page.html#adsi_page_sec_2a6", null ],
      [ "The ETSI CLIP specification", "adsi_page.html#adsi_page_sec_2b", null ],
      [ "The ETSI caller ID by DTMF specification", "adsi_page.html#adsi_page_sec_2c", null ],
      [ "The Japanese specification from NTT", "adsi_page.html#adsi_page_sec_2d", null ]
    ] ],
    [ "Fast approximate four quadrant arc-tangent", "arctan2_page.html", [
      [ "What does it do?", "arctan2_page.html#arctan2_page_sec_1", null ],
      [ "How does it work?", "arctan2_page.html#arctan2_page_sec_2", null ]
    ] ],
    [ "Asynchronous bit stream processing", "async_page.html", [
      [ "What does it do?", "async_page.html#async_page_sec_1", null ],
      [ "The transmitter", "async_page.html#async_page_sec_2", null ],
      [ "The receiver", "async_page.html#async_page_sec_3", null ]
    ] ],
    [ "AT command interpreter", "at_page.html", [
      [ "What does it do?", "at_page.html#at_page_sec_1", null ],
      [ "How does it work?", "at_page.html#at_page_sec_2", null ]
    ] ],
    [ "Additive white gaussian noise (AWGN) generation", "awgn_page.html", [
      [ "What does it do?", "awgn_page.html#awgn_page_sec_1", null ],
      [ "How does it work?", "awgn_page.html#awgn_page_sec_2", null ]
    ] ],
    [ "MFC/R2 tone generation", "mfc_r2_tone_generation_page.html", [
      [ "What does it do?", "mfc_r2_tone_generation_page.html#mfc_r2_tone_generation_page_sec_1", null ],
      [ "How does it work?", "mfc_r2_tone_generation_page.html#mfc_r2_tone_generation_page_sec_2", null ]
    ] ],
    [ "Bell MF tone generation", "bell_mf_tone_generation_page.html", [
      [ "What does it do?", "bell_mf_tone_generation_page.html#bell_mf_tone_generation_page_sec_1", null ],
      [ "How does it work?", "bell_mf_tone_generation_page.html#bell_mf_tone_generation_page_sec_2", null ]
    ] ],
    [ "MFC/R2 tone receiver", "mfc_r2_tone_rx_page.html", [
      [ "What does it do?", "mfc_r2_tone_rx_page.html#mfc_r2_tone_rx_page_sec_1", null ],
      [ "How does it work?", "mfc_r2_tone_rx_page.html#mfc_r2_tone_rx_page_sec_2", null ]
    ] ],
    [ "Bell MF tone receiver", "bell_mf_tone_rx_page.html", [
      [ "What does it do?", "bell_mf_tone_rx_page.html#bell_mf_tone_rx_page_sec_1", null ],
      [ "How does it work?", "bell_mf_tone_rx_page.html#bell_mf_tone_rx_page_sec_2", null ]
    ] ],
    [ "The Bit Error Rate tester", "bert_page.html", [
      [ "What does it do?", "bert_page.html#bert_page_sec_1", null ],
      [ "How does it work?", "bert_page.html#bert_page_sec_2", null ]
    ] ],
    [ "Bi-quadratic filter sections", "biquad_page.html", [
      [ "What does it do?", "biquad_page.html#biquad_page_sec_1", null ],
      [ "How does it work?", "biquad_page.html#biquad_page_sec_2", null ]
    ] ],
    [ "Bitstream composition and decomposition", "bitstream_page.html", [
      [ "What does it do?", "bitstream_page.html#bitstream_page_sec_1", null ],
      [ "How does it work?", "bitstream_page.html#bitstream_page_sec_2", null ]
    ] ],
    [ "Complex number support", "complex_page.html", [
      [ "What does it do?", "complex_page.html#complex_page_sec_1", null ]
    ] ],
    [ "CRC", "crc_page.html", [
      [ "What does it do?", "crc_page.html#crc_page_sec_1", null ],
      [ "How does it work?", "crc_page.html#crc_page_sec_2", null ]
    ] ],
    [ "Removing DC bias from a signal", "dc_restore_page.html", [
      [ "What does it do?", "dc_restore_page.html#dc_restore_page_sec_1", null ],
      [ "How does it work?", "dc_restore_page.html#dc_restore_page_sec_2", null ]
    ] ],
    [ "DTMF receiver", "dtmf_rx_page.html", [
      [ "What does it do?", "dtmf_rx_page.html#dtmf_rx_page_sec_1", null ],
      [ "How does it work?", "dtmf_rx_page.html#dtmf_rx_page_sec_2", null ]
    ] ],
    [ "DTMF tone generation", "dtmf_tx_page.html", [
      [ "What does it do?", "dtmf_tx_page.html#dtmf_tx_page_sec_1", null ],
      [ "How does it work?", "dtmf_tx_page.html#dtmf_tx_page_sec_2", null ]
    ] ],
    [ "Line echo cancellation for voice", "echo_can_page.html", [
      [ "What does it do?", "echo_can_page.html#echo_can_page_sec_1", null ],
      [ "How does it work?", "echo_can_page.html#echo_can_page_sec_2", null ],
      [ "How do I use it?", "echo_can_page.html#echo_can_page_sec_3", null ]
    ] ],
    [ "FAX over analogue modem handling", "fax_page.html", [
      [ "What does it do?", "fax_page.html#fax_page_sec_1", null ],
      [ "How does it work?", "fax_page.html#fax_page_sec_2", null ]
    ] ],
    [ "FIR filtering", "fir_page.html", [
      [ "What does it do?", "fir_page.html#fir_page_sec_1", null ],
      [ "How does it work?", "fir_page.html#fir_page_sec_2", null ]
    ] ],
    [ "FSK modems", "fsk_page.html", [
      [ "What does it do?", "fsk_page.html#fsk_page_sec_1", null ],
      [ "The transmitter", "fsk_page.html#fsk_page_sec_2", null ],
      [ "The receiver", "fsk_page.html#fsk_page_sec_3", null ]
    ] ],
    [ "The test data from the G.168 specification", "g168_test_data_page.html", null ],
    [ "A-law and mu-law handling", "g711_page.html", null ],
    [ "G.722 encoding and decoding", "g722_page.html", [
      [ "What does it do?", "g722_page.html#g722_page_sec_1", null ],
      [ "How does it work?", "g722_page.html#g722_page_sec_2", null ]
    ] ],
    [ "G.726 encoding and decoding", "g726_page.html", [
      [ "What does it do?", "g726_page.html#g726_page_sec_1", null ],
      [ "How does it work?", "g726_page.html#g726_page_sec_2", null ]
    ] ],
    [ "GSM 06.10 encoding and decoding", "gsm0610_page.html", [
      [ "What does it do?", "gsm0610_page.html#gsm0610_page_sec_1", null ],
      [ "How does it work?", "gsm0610_page.html#gsm0610_page_sec_2", null ]
    ] ],
    [ "HDLC", "hdlc_page.html", [
      [ "What does it do?", "hdlc_page.html#hdlc_page_sec_1", null ],
      [ "How does it work?", "hdlc_page.html#hdlc_page_sec_2", null ]
    ] ],
    [ "IMA/DVI/Intel ADPCM encoding and decoding", "ima_adpcm_page.html", [
      [ "What does it do?", "ima_adpcm_page.html#ima_adpcm_page_sec_1", null ],
      [ "How does it work?", "ima_adpcm_page.html#ima_adpcm_page_sec_2", null ],
      [ "How do I use it?", "ima_adpcm_page.html#ima_adpcm_page_sec_3", null ]
    ] ],
    [ "Image translation", "image_translate_page.html", [
      [ "What does it do?", "image_translate_page.html#image_translate_page_sec_1", null ],
      [ "How does it work?", "image_translate_page.html#image_translate_page_sec_2", null ],
      [ "How do I use it?", "image_translate_page.html#image_translate_page_sec_3", null ]
    ] ],
    [ "Logging", "logging_page.html", [
      [ "What does it do?", "logging_page.html#logging_page_sec_1", null ]
    ] ],
    [ "LPC10 encoding and decoding", "lpc10_page.html", [
      [ "What does it do?", "lpc10_page.html#lpc10_page_sec_1", null ],
      [ "How does it work?", "lpc10_page.html#lpc10_page_sec_2", null ]
    ] ],
    [ "Fixed point math functions", "math_fixed_page.html", [
      [ "What does it do?", "math_fixed_page.html#math_fixed_page_sec_1", null ],
      [ "How does it work?", "math_fixed_page.html#math_fixed_page_sec_2", null ]
    ] ],
    [ "Modem connect tone detection", "modem_connect_tones_page.html", [
      [ "What does it do?", "modem_connect_tones_page.html#modem_connect_tones_page_sec_1", null ],
      [ "How does it work?", "modem_connect_tones_page.html#modem_connect_tones_page_sec_2", null ]
    ] ],
    [ "Line echo cancellation for modems", "modem_echo_can_page.html", [
      [ "What does it do?", "modem_echo_can_page.html#modem_echo_can_page_sec_1", null ],
      [ "How does it work?", "modem_echo_can_page.html#modem_echo_can_page_sec_2", null ],
      [ "How do I use it?", "modem_echo_can_page.html#modem_echo_can_page_sec_3", null ]
    ] ],
    [ "Noise generation", "noise_page.html", [
      [ "What does it do?", "noise_page.html#noise_page_sec_1", null ]
    ] ],
    [ "OKI (Dialogic) ADPCM encoding and decoding", "okiadpcm_page.html", [
      [ "What does it do?", "okiadpcm_page.html#okiadpcm_page_sec_1", null ]
    ] ],
    [ "Play-out (jitter buffering)", "playout_page.html", [
      [ "What does it do?", "playout_page.html#playout_page_sec_1", null ]
    ] ],
    [ "Packet loss concealment", "plc_page.html", [
      [ "What does it do?", "plc_page.html#plc_page_sec_1", null ],
      [ "How does it work?", "plc_page.html#plc_page_sec_2", null ],
      [ "How do I use it?", "plc_page.html#plc_page_sec_3", null ]
    ] ],
    [ "Power metering", "power_meter_page.html", [
      [ "What does it do?", "power_meter_page.html#power_meter_page_sec_1", null ],
      [ "How does it work?", "power_meter_page.html#power_meter_page_sec_2", null ]
    ] ],
    [ "Queuing", "queue_page.html", [
      [ "What does it do?", "queue_page.html#queue_page_sec_1", null ],
      [ "How does it work?", "queue_page.html#queue_page_sec_2", null ]
    ] ],
    [ "Saturated arithmetic", "saturated_page.html", [
      [ "What does it do?", "saturated_page.html#saturated_page_sec_1", null ],
      [ "How does it work?", "saturated_page.html#saturated_page_sec_2", null ]
    ] ],
    [ "Scheduling", "schedule_page.html", [
      [ "What does it do?", "schedule_page.html#schedule_page_sec_1", null ],
      [ "How does it work?", "schedule_page.html#schedule_page_sec_2", null ]
    ] ],
    [ "The 2280/2400/2600Hz signalling tone processor", "sig_tone_page.html", [
      [ "What does it do?", "sig_tone_page.html#sig_tone_sec_1", null ],
      [ "How does it work?", "sig_tone_page.html#sig_tone_sec_2", null ]
    ] ],
    [ "Supervisory tone detection", "super_tone_rx_page.html", [
      [ "What does it do?", "super_tone_rx_page.html#super_tone_rx_page_sec_1", null ],
      [ "How does it work?", "super_tone_rx_page.html#super_tone_rx_page_sec_2", null ]
    ] ],
    [ "Supervisory tone generation", "super_tone_tx_page.html", [
      [ "What does it do?", "super_tone_tx_page.html#super_tone_tx_page_sec_1", null ],
      [ "How does it work?", "super_tone_tx_page.html#super_tone_tx_page_sec_2", null ]
    ] ],
    [ "The swept tone generator", "swept_tone_page.html", [
      [ "What does it do?", "swept_tone_page.html#swept_tone_page_sec_1", null ]
    ] ],
    [ "T.30 FAX protocol handling", "t30_page.html", [
      [ "What does it do?", "t30_page.html#t30_page_sec_1", null ],
      [ "How does it work?", "t30_page.html#t30_page_sec_2", [
        [ "The answer (CED) tone", "t30_page.html#t30_page_sec_2a", null ],
        [ "Common Timing Deviations", "t30_page.html#t30_page_sec_2b", null ],
        [ "Variations in the inter-carrier gap", "t30_page.html#t30_page_sec_2c", null ],
        [ "Other timing variations", "t30_page.html#t30_page_sec_2d", null ],
        [ "Other deviations from the T.30 standard", "t30_page.html#t30_page_sec_2e", null ]
      ] ]
    ] ],
    [ "T.31 Class 1 FAX modem protocol handling", "t31_page.html", [
      [ "What does it do?", "t31_page.html#t31_page_sec_1", null ],
      [ "How does it work?", "t31_page.html#t31_page_sec_2", null ]
    ] ],
    [ "T.35 manufacturer specific processing for FAX machines", "t35_page.html", [
      [ "What does it do?", "t35_page.html#t35_page_sec_1", null ],
      [ "How does it work?", "t35_page.html#t35_page_sec_2", null ]
    ] ],
    [ "T.38 real time FAX over IP message handling", "t38_core_page.html", [
      [ "What does it do?", "t38_core_page.html#t38_core_page_sec_1", null ],
      [ "How does it work?", "t38_core_page.html#t38_core_page_sec_2", null ]
    ] ],
    [ "T.38 real time FAX over IP PSTN gateway", "t38_gateway_page.html", [
      [ "What does it do?", "t38_gateway_page.html#t38_gateway_page_sec_1", null ],
      [ "How does it work?", "t38_gateway_page.html#t38_gateway_page_sec_2", null ]
    ] ],
    [ "T.38 rate adapting non-ECM image data buffer", "t38_non_ecm_buffer_page.html", [
      [ "What does it do?", "t38_non_ecm_buffer_page.html#t38_non_ecm_buffer_page_sec_1", null ],
      [ "How does it work?", "t38_non_ecm_buffer_page.html#t38_non_ecm_buffer_page_sec_2", null ]
    ] ],
    [ "T.38 real time FAX over IP termination", "t38_terminal_page.html", [
      [ "What does it do?", "t38_terminal_page.html#t38_terminal_page_sec_1", null ],
      [ "How does it work?", "t38_terminal_page.html#t38_terminal_page_sec_2", null ]
    ] ],
    [ "T.4 image compression and decompression", "t4_page.html", [
      [ "What does it do?", "t4_page.html#t4_page_sec_1", null ]
    ] ],
    [ "T.4 and T.6 FAX image decompression", "t4_t6_decode_page.html", [
      [ "What does it do?", "t4_t6_decode_page.html#t4_t6_decode_page_sec_1", null ]
    ] ],
    [ "Time scaling speech", "time_scale_page.html", [
      [ "What does it do?", "time_scale_page.html#time_scale_page_sec_1", null ],
      [ "How does it work?", "time_scale_page.html#time_scale_page_sec_2", null ],
      [ "How do I used it?", "time_scale_page.html#time_scale_page_sec_3", null ]
    ] ],
    [ "Timezone handling", "timezone_page.html", [
      [ "What does it do?", "timezone_page.html#timezone_sec_1", null ],
      [ "How does it work?", "timezone_page.html#timezone_sec_2", null ]
    ] ],
    [ "Tone generation", "tone_generation_page.html", [
      [ "What does it do?", "tone_generation_page.html#tone_generation_page_sec_1", null ],
      [ "How does it work?", "tone_generation_page.html#tone_generation_page_sec_2", null ]
    ] ],
    [ "The V.17 receiver", "v17rx_page.html", [
      [ "What does it do?", "v17rx_page.html#v17rx_page_sec_1", null ],
      [ "How does it work?", "v17rx_page.html#v17rx_page_sec_2", null ]
    ] ],
    [ "The V.17 transmitter", "v17tx_page.html", [
      [ "What does it do?", "v17tx_page.html#v17tx_page_sec_1", null ],
      [ "How does it work?", "v17tx_page.html#v17tx_page_sec_2", null ]
    ] ],
    [ "The V.18 text telephony protocols", "v18_page.html", [
      [ "What does it do?", "v18_page.html#v18_page_sec_1", null ],
      [ "How does it work?", "v18_page.html#v18_page_sec_2", null ]
    ] ],
    [ "The V.22bis modem", "v22bis_page.html", [
      [ "What does it do?", "v22bis_page.html#v22bis_page_sec_1", null ],
      [ "How does it work?", "v22bis_page.html#v22bis__page_sec_2", null ]
    ] ],
    [ "The V.27ter receiver", "v27ter_rx_page.html", [
      [ "What does it do?", "v27ter_rx_page.html#v27ter_rx_page_sec_1", null ],
      [ "How does it work?", "v27ter_rx_page.html#v27ter_rx_page_sec_2", null ]
    ] ],
    [ "The V.27ter transmitter", "v27ter_tx_page.html", [
      [ "What does it do?", "v27ter_tx_page.html#v27ter_tx_page_sec_1", null ],
      [ "How does it work?", "v27ter_tx_page.html#v27ter_tx_page_sec_2", null ]
    ] ],
    [ "The V.29 receiver", "v29rx_page.html", [
      [ "What does it do?", "v29rx_page.html#v29rx_page_sec_1", null ],
      [ "How does it work?", "v29rx_page.html#v29rx_page_sec_2", null ]
    ] ],
    [ "The V.29 transmitter", "v29tx_page.html", [
      [ "What does it do?", "v29tx_page.html#v29tx_page_sec_1", null ],
      [ "How does it work?", "v29tx_page.html#v29tx_page_sec_2", null ]
    ] ],
    [ "V.42 modem error correction", "v42_page.html", [
      [ "What does it do?", "v42_page.html#v42_page_sec_1", null ],
      [ "How does it work?", "v42_page.html#v42_page_sec_2", null ]
    ] ],
    [ "V.42bis modem data compression", "v42bis_page.html", [
      [ "What does it do?", "v42bis_page.html#v42bis_page_sec_1", null ],
      [ "How does it work?", "v42bis_page.html#v42bis_page_sec_2", null ]
    ] ],
    [ "The V.8 modem negotiation protocol", "v8_page.html", [
      [ "What does it do?", "v8_page.html#v8_page_sec_1", null ],
      [ "How does it work?", "v8_page.html#v8_page_sec_2", null ]
    ] ],
    [ "Ademco ContactID tests", "ademco_contactid_tests_page.html", [
      [ "What does it do?", "ademco_contactid_tests_page.html#ademco_contactid_tests_page_sec_1", null ],
      [ "How does it work?", "ademco_contactid_tests_page.html#ademco_contactid_tests_page_sec_2", null ]
    ] ],
    [ "ADSI tests", "adsi_tests_page.html", [
      [ "What does it do?", "adsi_tests_page.html#adsi_tests_page_sec_1", null ],
      [ "How does it work?", "adsi_tests_page.html#adsi_tests_page_sec_2", null ]
    ] ],
    [ "Asynchronous bit stream tests", "async_tests_page.html", [
      [ "What does it do?", "async_tests_page.html#async_tests_page_sec_1", null ]
    ] ],
    [ "AT interpreter tests", "at_interpreter_tests_page.html", [
      [ "What does it do?", "at_interpreter_tests_page.html#at_interpreter_tests_page_sec_1", null ]
    ] ],
    [ "AWGN tests", "awgn_tests_page.html", [
      [ "What does it do?", "awgn_tests_page.html#awgn_tests_page_sec_1", null ]
    ] ],
    [ "Bell MF tone generation and detection tests", "bell_mf_tests_page.html", [
      [ "What does it do?", "bell_mf_tests_page.html#bell_mf_tests_page_sec_1", null ]
    ] ],
    [ "Bell MF generation tests", "bell_mf_tx_tests_page.html", [
      [ "What does it do?", "bell_mf_tx_tests_page.html#bell_mf_tx_tests_page_sec_1", null ],
      [ "How does it work?", "bell_mf_tx_tests_page.html#bell_mf_tx_tests_page_sec_2", null ]
    ] ],
    [ "BERT tests", "bert_tests_page.html", [
      [ "What does it do?", "bert_tests_page.html#bert_tests_page_sec_1", null ]
    ] ],
    [ "Bit operations tests", "bit_operations_tests_page.html", [
      [ "What does it do?", "bit_operations_tests_page.html#bit_operations_tests_page_sec_1", null ],
      [ "How is it used?", "bit_operations_tests_page.html#bit_operations_tests_page_sec_2", null ]
    ] ],
    [ "Bitstream tests", "bitstream_tests_page.html", [
      [ "What does it do?", "bitstream_tests_page.html#bitstream_tests_page_sec_1", null ],
      [ "How is it used?", "bitstream_tests_page.html#bitstream_tests_page_sec_2", null ]
    ] ],
    [ "Complex arithmetic tests", "complex_tests_page.html", [
      [ "What does it do?", "complex_tests_page.html#complex_tests_page_sec_1", null ],
      [ "How is it used?", "complex_tests_page.html#complex_tests_page_sec_2", null ]
    ] ],
    [ "CRC tests", "crc_tests_page.html", [
      [ "What does it do?", "crc_tests_page.html#crc_tests_page_sec_1", null ]
    ] ],
    [ "DC restoration tests", "dc_restore_tests_page.html", [
      [ "What does it do?", "dc_restore_tests_page.html#dc_restore_tests_page_sec_1", null ]
    ] ],
    [ "Direct digital synthesis tests", "dds_tests_page.html", [
      [ "What does it do?", "dds_tests_page.html#dds_tests_page_sec_1", null ],
      [ "How does it work?", "dds_tests_page.html#dds_tests_page_sec_2", null ]
    ] ],
    [ "DTMF receiver tests", "dtmf_rx_tests_page.html", [
      [ "What does it do?", "dtmf_rx_tests_page.html#dtmf_rx_tests_page_sec_1", null ]
    ] ],
    [ "DTMF generation tests", "dtmf_tx_tests_page.html", [
      [ "What does it do?", "dtmf_tx_tests_page.html#dtmf_tx_tests_page_sec_1", null ],
      [ "How does it work?", "dtmf_tx_tests_page.html#dtmf_tx_tests_page_sec_2", null ]
    ] ],
    [ "Echo canceller performance monitoring", "echo_monitor_page.html", [
      [ "What does it do?", "echo_monitor_page.html#echo_monitor_page_sec_1", null ],
      [ "How does it work?", "echo_monitor_page.html#echo_monitor_page_sec_2", null ]
    ] ],
    [ "Line echo cancellation for voice tests", "echo_can_tests_page.html", [
      [ "What does it do?", "echo_can_tests_page.html#echo_can_tests_page_sec_1", null ],
      [ "How does it work?", "echo_can_tests_page.html#echo_can_tests_page_sec_2", null ]
    ] ],
    [ "FAX decoder", "fax_decode_page.html", [
      [ "What does it do?", "fax_decode_page.html#fax_decode_page_sec_1", null ],
      [ "How does it work?", "fax_decode_page.html#fax_decode_tests_page_sec_2", null ]
    ] ],
    [ "FAX over analogue modem handling", "fax_tester_page.html", [
      [ "What does it do?", "fax_tester_page.html#fax_tester_page_sec_1", null ],
      [ "How does it work?", "fax_tester_page.html#fax_tester_page_sec_2", null ]
    ] ],
    [ "FAX tests", "fax_tests_page.html", [
      [ "What does it do?", "fax_tests_page.html#fax_tests_page_sec_1", null ],
      [ "How does it work?", "fax_tests_page.html#fax_tests_page_sec_2", null ]
    ] ],
    [ "FSK modem tests", "fsk_tests_page.html", [
      [ "What does it do?", "fsk_tests_page.html#fsk_tests_page_sec_1", null ],
      [ "How does it work?", "fsk_tests_page.html#fsk_tests_page_sec_2", null ]
    ] ],
    [ "A-law and u-law conversion tests", "g711_tests_page.html", [
      [ "What does it do?", "g711_tests_page.html#g711_tests_page_sec_1", null ],
      [ "How is it used?", "g711_tests_page.html#g711_tests_page_sec_2", null ]
    ] ],
    [ "G.722 tests", "g722_tests_page.html", [
      [ "What does it do?", "g722_tests_page.html#g722_tests_page_sec_1", null ],
      [ "How is it used?", "g722_tests_page.html#g722_tests_page_sec_2", null ]
    ] ],
    [ "G.726 tests", "g726_tests_page.html", [
      [ "What does it do?", "g726_tests_page.html#g726_tests_page_sec_1", null ],
      [ "How is it used?", "g726_tests_page.html#g726_tests_page_sec_2", null ]
    ] ],
    [ "GSM 06.10 full rate codec tests", "gsm0610_tests_page.html", [
      [ "What does it do?", "gsm0610_tests_page.html#gsm0610_tests_page_sec_1", null ],
      [ "How is it used?", "gsm0610_tests_page.html#gsm0610_tests_page_sec_2", null ]
    ] ],
    [ "HDLC tests", "hdlc_tests_page.html", [
      [ "What does it do?", "hdlc_tests_page.html#hdlc_tests_page_sec_1", null ]
    ] ],
    [ "IMA ADPCM tests", "ima_adpcm_tests_page.html", [
      [ "What does it do?", "ima_adpcm_tests_page.html#ima_adpcm_tests_page_sec_1", null ],
      [ "How is it used?", "ima_adpcm_tests_page.html#ima_adpcm_tests_page_sec_2", null ]
    ] ],
    [ "Telephone line model monitoring", "line_model_monitor_page.html", [
      [ "What does it do?", "line_model_monitor_page.html#line_model_monitor_page_sec_1", null ],
      [ "How does it work?", "line_model_monitor_page.html#line_model_monitor_page_sec_2", null ]
    ] ],
    [ "Telephony line model tests", "line_model_tests_page.html", [
      [ "What does it do?", "line_model_tests_page.html#line_model_tests_page_sec_1", null ],
      [ "How does it work?", "line_model_tests_page.html#line_model_tests_page_sec_2", null ]
    ] ],
    [ "Logging tests", "logging_tests_page.html", [
      [ "What does it do?", "logging_tests_page.html#logging_tests_page_sec_1", null ]
    ] ],
    [ "LPC10 codec tests", "lpc10_tests_page.html", [
      [ "What does it do?", "lpc10_tests_page.html#lpc10_tests_page_sec_1", null ],
      [ "How is it used?", "lpc10_tests_page.html#lpc10_tests_page_sec_2", null ]
    ] ],
    [ "CSS construction for G.168 testing", "makecss_page.html", [
      [ "What does it do?", "makecss_page.html#makecss_page_sec_1", null ],
      [ "How does it work?", "makecss_page.html#makecss_page_sec_2", null ]
    ] ],
    [ "Fixed point math function tests", "math_fixed_tests_page.html", [
      [ "What does it do?", "math_fixed_tests_page.html#math_fixed_tests_page_sec_1", null ]
    ] ],
    [ "IP streaming media performance monitoring", "media_monitor_page.html", [
      [ "What does it do?", "media_monitor_page.html#media_monitor_page_sec_1", null ],
      [ "How does it work?", "media_monitor_page.html#media_monitor_page_sec_2", null ]
    ] ],
    [ "Modem connect tones tests", "modem_connect_tones_tests_page.html", [
      [ "What does it do?", "modem_connect_tones_tests_page.html#modem_connect_tones_rx_tests_page_sec_1", null ]
    ] ],
    [ "Line echo cancellation for modems tests", "modem_echo_can_tests_page.html", [
      [ "What does it do?", "modem_echo_can_tests_page.html#modem_echo_can_tests_page_sec_1", null ],
      [ "How does it work?", "modem_echo_can_tests_page.html#modem_echo_can_tests_page_sec_2", null ]
    ] ],
    [ "Modem performance monitoring", "constel_page.html", [
      [ "What does it do?", "constel_page.html#constel_page_sec_1", null ],
      [ "How does it work?", "constel_page.html#constel_page_sec_2", null ]
    ] ],
    [ "Noise generator tests", "noise_tests_page.html", [
      [ "What does it do?", "noise_tests_page.html#noise_tests_page_sec_1", null ]
    ] ],
    [ "OKI (Dialogic) ADPCM tests", "oki_adpcm_tests_page.html", [
      [ "What does it do?", "oki_adpcm_tests_page.html#oki_adpcm_tests_page_sec_1", null ],
      [ "How is it used?", "oki_adpcm_tests_page.html#oki_adpcm_tests_page_sec_2", null ]
    ] ],
    [ "Playout (jitter buffering) tests", "playout_tests_page.html", [
      [ "What does it do?", "playout_tests_page.html#playout_tests_page_sec_1", null ]
    ] ],
    [ "Packet loss concealment tests", "plc_tests_page.html", [
      [ "What does it do?", "plc_tests_page.html#plc_tests_page_sec_1", null ],
      [ "How are the tests run?", "plc_tests_page.html#plc_tests_page_sec_2", null ]
    ] ],
    [ "Power meter tests", "power_meter_tests_page.html", [
      [ "What does it do?", "power_meter_tests_page.html#power_meter_tests_page_sec_1", null ],
      [ "How does it work?", "power_meter_tests_page.html#power_meter_tests_page_sec_2", null ]
    ] ],
    [ "Queue tests", "queue_tests_page.html", [
      [ "What does it do?", "queue_tests_page.html#queue_tests_page_sec_1", null ]
    ] ],
    [ "R2 MF tone generation and detection tests", "r2_mf_tests_page.html", [
      [ "What does it do?", "r2_mf_tests_page.html#r2_mf_tests_page_sec_1", null ]
    ] ],
    [ "R2 MF generation tests", "r2_mf_tx_tests_page.html", [
      [ "What does it do?", "r2_mf_tx_tests_page.html#r2_mf_tx_tests_page_sec_1", null ],
      [ "How does it work?", "r2_mf_tx_tests_page.html#r2_mf_tx_tests_page_sec_2", null ]
    ] ],
    [ "Saturated arithmetic function tests", "saturated_tests_page.html", [
      [ "What does it do?", "saturated_tests_page.html#saturated_tests_page_sec_1", null ],
      [ "How does it work?", "saturated_tests_page.html#saturated_tests_page_sec_2", null ]
    ] ],
    [ "Event scheduler tests", "schedule_tests_page.html", [
      [ "What does it do?", "schedule_tests_page.html#schedule_tests_page_sec_1", null ],
      [ "How does it work?", "schedule_tests_page.html#schedule_tests_page_sec_2", null ]
    ] ],
    [ "The 2280/2400/2600Hz signalling tone Rx/Tx tests", "sig_tone_tests_page.html", [
      [ "What does it do?", "sig_tone_tests_page.html#sig_tone_tests_sec_1", null ],
      [ "How does it work?", "sig_tone_tests_page.html#sig_tone_tests_sec_2", null ]
    ] ],
    [ "Supervisory tone detection tests", "super_tone_rx_tests_page.html", [
      [ "What does it do?", "super_tone_rx_tests_page.html#super_tone_rx_tests_page_sec_1", null ]
    ] ],
    [ "Supervisory tone generation tests", "super_tone_tx_tests_page.html", [
      [ "What does it do?", "super_tone_tx_tests_page.html#super_tone_tx_tests_page_sec_1", null ]
    ] ],
    [ "T.31 tests", "t31_tests_page.html", [
      [ "What does it do?", "t31_tests_page.html#t31_tests_page_sec_1", null ]
    ] ],
    [ "T.35 tests", "t35_tests_page.html", [
      [ "What does it do?", "t35_tests_page.html#t35_tests_page_sec_1", null ]
    ] ],
    [ "T.38 core tests", "t38_core_tests_page.html", [
      [ "What does it do?", "t38_core_tests_page.html#t38_core_tests_page_sec_1", null ]
    ] ],
    [ "T.38 gateway tests", "t38_gateway_tests_page.html", [
      [ "What does it do?", "t38_gateway_tests_page.html#t38_gateway_tests_page_sec_1", null ]
    ] ],
    [ "T.38 mixed gateway and termination tests", "t38_gateway_to_terminal_tests_page.html", [
      [ "What does it do?", "t38_gateway_to_terminal_tests_page.html#t38_gateway_to_terminal_tests_page_sec_1", null ]
    ] ],
    [ "T.38 non-ECM buffer tests", "t38_non_ecm_buffer_tests_page.html", [
      [ "What does it do?", "t38_non_ecm_buffer_tests_page.html#t38_non_ecm_buffer_tests_page_sec_1", null ]
    ] ],
    [ "T.38 termination tests", "t38_terminal_tests_page.html", [
      [ "What does it do?", "t38_terminal_tests_page.html#t38_terminal_tests_page_sec_1", null ]
    ] ],
    [ "T.38 mixed gateway and termination tests", "t38_terminal_to_gateway_tests_page.html", [
      [ "What does it do?", "t38_terminal_to_gateway_tests_page.html#t38_terminal_to_gateway_tests_page_sec_1", null ]
    ] ],
    [ "T.4 tests", "t4_tests_page.html", [
      [ "What does it do", "t4_tests_page.html#t4_tests_page_sec_1", null ]
    ] ],
    [ "Time scaling tests", "time_scale_tests_page.html", [
      [ "What does it do?", "time_scale_tests_page.html#time_scale_tests_page_sec_1", null ],
      [ "How are the tests run?", "time_scale_tests_page.html#time_scale_tests_page_sec_2", null ]
    ] ],
    [ "Timezone handling tests", "timezone_tests_page.html", [
      [ "What does it do?", "timezone_tests_page.html#timezone_tests_page_sec_1", null ]
    ] ],
    [ "Tone detection tests", "tone_detect_tests_page.html", [
      [ "What does it do?", "tone_detect_tests_page.html#tone_detect_tests_page_sec_1", null ]
    ] ],
    [ "Tone generation tests", "tone_generate_tests_page.html", [
      [ "What does it do?", "tone_generate_tests_page.html#tone_generate_tests_page_sec_1", null ]
    ] ],
    [ "V.17 modem tests", "v17_tests_page.html", [
      [ "What does it do?", "v17_tests_page.html#v17_tests_page_sec_1", null ],
      [ "How is it used?", "v17_tests_page.html#v17_tests_page_sec_2", null ]
    ] ],
    [ "V.18 tests", "v18_tests_page.html", [
      [ "What does it do?", "v18_tests_page.html#v18_tests_page_sec_1", null ]
    ] ],
    [ "V.22bis modem tests", "v22bis_tests_page.html", [
      [ "What does it do?", "v22bis_tests_page.html#v22bis_tests_page_sec_1", null ],
      [ "How is it used?", "v22bis_tests_page.html#v22bis_tests_page_sec_2", null ]
    ] ],
    [ "V.27ter modem tests", "v27ter_tests_page.html", [
      [ "What does it do?", "v27ter_tests_page.html#v27ter_tests_page_sec_1", null ],
      [ "How is it used?", "v27ter_tests_page.html#v27ter_tests_page_sec_2", null ]
    ] ],
    [ "V.29 modem tests", "v29_tests_page.html", [
      [ "What does it do?", "v29_tests_page.html#v29_tests_page_sec_1", null ],
      [ "How is it used?", "v29_tests_page.html#v29_tests_page_sec_2", null ]
    ] ],
    [ "V.42 tests", "v42_tests_page.html", [
      [ "What does it do?", "v42_tests_page.html#v42_tests_page_sec_1", null ]
    ] ],
    [ "V.42bis tests", "v42bis_tests_page.html", [
      [ "What does it do?", "v42bis_tests_page.html#v42bis_tests_page_sec_1", null ]
    ] ],
    [ "V.8 tests", "v8_tests_page.html", [
      [ "What does it do?", "v8_tests_page.html#v8_tests_page_sec_1", null ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"ademco__contactid_8c.html",
"ademco__contactid_8h.html#aaf8fd5f0e57d456151c951e0f3715fc4ae36be786bb0f0cd69aeb1c7365d9aeb9",
"at__interpreter_8c.html#a1b4d0b74b2414dd804299d3eb1c015b6",
"bit_operations_tests_page.html#bit_operations_tests_page_sec_1",
"echo_can_page.html#echo_can_page_sec_1",
"functions_u.html",
"globals_func_p.html",
"line__models_8h.html#a5e84791443285a818257c490c0eb5541",
"pcap__parse_8h.html",
"sig__tone_8h.html#a22923815759af26cc1d267464d8d4611",
"structbell__mf__rx__state__s.html#a25226ccd3d9586a3e6283ce6c6251ba8",
"structfaxtester__state__s.html#a8d1bdec70006e4edffa4cdec7138a955",
"structgsm0610__state__s.html",
"structmodem__connect__tones__rx__state__s.html#a726eb3586fdd09059ce91a036192d90d",
"structsuper__tone__rx__segment__s.html#acf962dce7b84da5e4326a1f9851467ba",
"structt31__t38__front__end__state__t.html#a79f9f2c8e9ad887fdaff14483393ed26",
"structtest__set__t.html#a1d0dc85a485d2e6361d7ca4fb6b548e3",
"structv22bis__state__s.html#ae29d5727317ccf3d383e4f932ec18450",
"super__tone__rx_8c.html#a5223fb286140f93907b46d1883313e63",
"t30_8h.html#a70ad55be767ca0a42c9150d24618e4caa52bd30715a118bf8ebcf3c4bbce83109",
"t30__api_8h.html#ad283c05887d2d166a3241b9dc0fcf42f",
"t31_8c.html#a26e1124d33b4acdb532c49f6498df549aae3e183792e2b04e21c261deb2dbc12c",
"t38__core_8h.html#aad5a3a458d9d30f446c2f00519a882eeaf3683ffe2cfc2a4dbd672a8e6f4daad7",
"t38__terminal__tests_8c.html#a8d7212524f53a388e6c32ab3f42b1b3b",
"t4__tx_8h.html#ac1586a4259b1fa716b3d71d9ca807655",
"v17rx_8c.html#adceece21e3dc01cf43c96c2607cc9dbe",
"v27ter__tx_8c.html#a626b78e8eceea3b7c07837ce00bdcdbd",
"v8_8c.html#a26c0312ac66c00f31cf886616c48afa2a5a7e286cb76d7e060eacdba69b12b647"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';