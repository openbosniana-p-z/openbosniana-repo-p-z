var gsm0610__long__term_8c =
[
    [ "gsm0610_long_term_predictor", "gsm0610__long__term_8c.html#ab44dba07314a4efe9a5614c623df763f", null ],
    [ "gsm0610_long_term_synthesis_filtering", "gsm0610__long__term_8c.html#af41b1b5e24d230f0c53b303e5e9678c0", null ]
];