var ima__adpcm_8c =
[
    [ "STEP_MAX", "ima__adpcm_8c.html#afb1629f78e781dc38b5ded85f69928eb", null ],
    [ "ima_adpcm_decode", "ima__adpcm_8c.html#a4a05b55e5fb0a288460d545192a4c915", null ],
    [ "ima_adpcm_encode", "ima__adpcm_8c.html#a373a16816c2f806d4a62b97730024e8f", null ],
    [ "ima_adpcm_free", "ima__adpcm_8c.html#a010d19d4deefd7b12f4c71d302512483", null ],
    [ "ima_adpcm_init", "ima__adpcm_8c.html#a5eae19c7895a2326e52c1f61b6f2acb6", null ],
    [ "ima_adpcm_release", "ima__adpcm_8c.html#a551c58909b85a213e5c0cb11cbff4d26", null ],
    [ "bits", "ima__adpcm_8c.html#a46a6da6b1936191571fd30b2a749f38c", null ],
    [ "code", "ima__adpcm_8c.html#a70008c0b7822b172472813e6730ea565", null ],
    [ "mask", "ima__adpcm_8c.html#a7fd850d4bb04f7410e8e2abf5f349348", null ]
];