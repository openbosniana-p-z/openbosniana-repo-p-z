var fax_8h =
[
    [ "fax_state_t", "fax_8h.html#ac91c836002ad09bf8b876858cfd35aeb", null ],
    [ "fax_free", "fax_8h.html#a69d694c9287f4c0591a835b3e4071d2a", null ],
    [ "fax_get_logging_state", "fax_8h.html#aef12e004d3b78c5ce0d35c87fb11a4b1", null ],
    [ "fax_get_t30_state", "fax_8h.html#ae6cca297be2d48d9d0fe1118fb4259d1", null ],
    [ "fax_init", "fax_8h.html#a3be96fbb2115b6e99fea37431b0ec26c", null ],
    [ "fax_release", "fax_8h.html#aaf4f155f00d612301c03525a5623d305", null ],
    [ "fax_restart", "fax_8h.html#a55e66f521ca5e5b1693be6f3852ec06c", null ],
    [ "fax_set_tep_mode", "fax_8h.html#ad60854cc71eaf4106efac0e0d56a2ede", null ],
    [ "fax_set_transmit_on_idle", "fax_8h.html#a37693f8bc74056939a7f844dc7b19ce3", null ],
    [ "SPAN_DECLARE_NONSTD", "fax_8h.html#aa149fd8aa2825146a33c40ce17d2ba17", null ],
    [ "amp", "fax_8h.html#aa77e792e6beeb7cbd63a2a5207441e6f", null ],
    [ "len", "fax_8h.html#afed088663f8704004425cdae2120b9b3", null ],
    [ "max_len", "fax_8h.html#ae6abc5c69c0538a61cfc0e5f8ca81db4", null ]
];