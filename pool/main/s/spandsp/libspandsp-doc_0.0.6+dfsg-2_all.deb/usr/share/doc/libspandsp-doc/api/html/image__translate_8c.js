var image__translate_8c =
[
    [ "image_translate_free", "image__translate_8c.html#add6ea5d13bb71d780bbff0601a0dedc2", null ],
    [ "image_translate_get_output_length", "image__translate_8c.html#a485ed4e25f6b982ed5fe83828d2f000a", null ],
    [ "image_translate_get_output_width", "image__translate_8c.html#aacbd77e2c5041a6b398fa90e4e07e0f5", null ],
    [ "image_translate_init", "image__translate_8c.html#a73235602b309f915c4a46793e534a54d", null ],
    [ "image_translate_release", "image__translate_8c.html#ac07690fb9be0243883fcae8aac18bd26", null ],
    [ "image_translate_row", "image__translate_8c.html#a7f607850346f1ecbb482a0c9bd0608ff", null ]
];