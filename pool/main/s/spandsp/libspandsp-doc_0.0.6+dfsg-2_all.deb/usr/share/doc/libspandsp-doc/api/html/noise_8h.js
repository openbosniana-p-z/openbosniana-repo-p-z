var noise_8h =
[
    [ "noise_state_t", "noise_8h.html#a15e4195571b71f8f86ce83cc5abf411d", null ],
    [ "NOISE_CLASS_AWGN", "noise_8h.html#afccd240f973cf154952fb917c9209719af631122e5927a28b86fff8a6f00e9ebe", null ],
    [ "NOISE_CLASS_HOTH", "noise_8h.html#afccd240f973cf154952fb917c9209719a823953829868c843836f9fb4f30c2462", null ],
    [ "noise", "noise_8h.html#aa72f27039efd3655026088063aa6dcd2", null ],
    [ "noise_free", "noise_8h.html#a10f0a7230882f2539a3382626a4e024b", null ],
    [ "noise_init_dbm0", "noise_8h.html#a02a4e7f2a4dd69c2cec83b7913c6ceaf", null ],
    [ "noise_init_dbov", "noise_8h.html#a1ab10908f897284596199780e77cf36c", null ],
    [ "noise_release", "noise_8h.html#ad196a1981ef047f17b8e4c5940aa19b3", null ]
];