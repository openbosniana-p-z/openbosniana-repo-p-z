var hdlc__tests_8c =
[
    [ "main", "hdlc__tests_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "abort_reported", "hdlc__tests_8c.html#a6d90306f84e21dd9013a805da077c8aa", null ],
    [ "buf", "hdlc__tests_8c.html#adecb27e6392c8b2d2de3e5a5cdc64ed8", null ],
    [ "bytes_sent", "hdlc__tests_8c.html#ab9e07f56cbc46818dce94414d79bff18", null ],
    [ "end", "hdlc__tests_8c.html#ae6f678325e5b403cc922e2bd4d908cf5", null ],
    [ "frame_data_errors", "hdlc__tests_8c.html#a5bf081aa654ec845878f1f05da7c937c", null ],
    [ "frame_failed", "hdlc__tests_8c.html#a411ed2d3672306bdd610f75fa2650b76", null ],
    [ "frame_handled", "hdlc__tests_8c.html#ad700db7a7a95ece32ae32dfcf2b59263", null ],
    [ "frame_len_errors", "hdlc__tests_8c.html#a3b009297a16f3feaa2b167aa8779dd16", null ],
    [ "frames_sent", "hdlc__tests_8c.html#a424e7dcd4360fc4da5b6ba1e0d90fbd4", null ],
    [ "framing_ok_reported", "hdlc__tests_8c.html#ad25b25a234e2964174952de696b523ad", null ],
    [ "framing_ok_reports", "hdlc__tests_8c.html#aef3d0588feed76edabab4075a522117d", null ],
    [ "ref_len", "hdlc__tests_8c.html#a8b3eedcfca8bb386cb28772a9a08d890", null ],
    [ "rx", "hdlc__tests_8c.html#a0bde42aed364620e28e97bd952d393cb", null ],
    [ "start", "hdlc__tests_8c.html#a6a51e9baeec9b06ae477cf6475efc71d", null ],
    [ "tx", "hdlc__tests_8c.html#a9c27ff1eb32426d4b59060a19dd3a48b", null ],
    [ "underflow_reported", "hdlc__tests_8c.html#adf2be6f62dbb742d6c7ec8ac41b530bc", null ]
];