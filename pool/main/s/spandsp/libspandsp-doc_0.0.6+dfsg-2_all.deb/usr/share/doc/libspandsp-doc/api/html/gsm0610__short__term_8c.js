var gsm0610__short__term_8c =
[
    [ "STEP", "gsm0610__short__term_8c.html#aa62f61a3a390334155652607147cb6fd", null ],
    [ "gsm0610_short_term_analysis_filter", "gsm0610__short__term_8c.html#a4bc9b5530cf8ccfd40af02e7cfe00c21", null ],
    [ "gsm0610_short_term_synthesis_filter", "gsm0610__short__term_8c.html#a23ab8cc24d33f7c40580651d2a55dd51", null ]
];