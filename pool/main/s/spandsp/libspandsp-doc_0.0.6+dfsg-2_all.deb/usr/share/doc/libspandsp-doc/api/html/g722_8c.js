var g722_8c =
[
    [ "g722_decode", "g722_8c.html#a9960072356db239a2861d132af06ebc5", null ],
    [ "g722_decode_free", "g722_8c.html#a8b2a4d094e437c00b4936e988e93fe28", null ],
    [ "g722_decode_init", "g722_8c.html#ad79183471278366b4e87321bb810fad7", null ],
    [ "g722_decode_release", "g722_8c.html#a9dbbe9430de1ee7aa6d22f3523a578c1", null ],
    [ "g722_encode", "g722_8c.html#a5fddb432e48aa916ba855cae0ee00743", null ],
    [ "g722_encode_free", "g722_8c.html#aa8c59c5fe90fd9f5de695fdfb5a6c867", null ],
    [ "g722_encode_init", "g722_8c.html#aa07fd4b4d86a97335bcde872e25eb288", null ],
    [ "g722_encode_release", "g722_8c.html#a11ea21bf5a03f25c3e2e225e4a5bfc56", null ]
];