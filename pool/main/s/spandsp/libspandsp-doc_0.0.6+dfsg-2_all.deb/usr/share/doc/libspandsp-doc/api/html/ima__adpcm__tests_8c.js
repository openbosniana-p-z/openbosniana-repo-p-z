var ima__adpcm__tests_8c =
[
    [ "HIST_LEN", "ima__adpcm__tests_8c.html#aded5babbee1b6f90b7cb4500bfb1f227", null ],
    [ "IN_FILE_NAME", "ima__adpcm__tests_8c.html#a8118656bb5a60090a1dbffa402168438", null ],
    [ "OUT_FILE_NAME", "ima__adpcm__tests_8c.html#a75506823f0db0ef3f4f022cf132dbbbb", null ],
    [ "SPANDSP_EXPOSE_INTERNAL_STRUCTURES", "ima__adpcm__tests_8c.html#a4dbcfe9986d8f3d4d39f3e395fc96c0c", null ],
    [ "main", "ima__adpcm__tests_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ]
];