var lpc10__tests_8c =
[
    [ "BLOCK_LEN", "lpc10__tests_8c.html#ad5df2c41c5104642db3277574068043f", null ],
    [ "BLOCKS_PER_READ", "lpc10__tests_8c.html#a0b57a3232bff811fc6b8daaa03ffe5e0", null ],
    [ "COMPRESS_FILE_NAME", "lpc10__tests_8c.html#ac268f050725c5b9ca47ab04d419b27c5", null ],
    [ "DECOMPRESS_FILE_NAME", "lpc10__tests_8c.html#a5dba242a31ffaedd21c2926ca56ed4e7", null ],
    [ "IN_FILE_NAME", "lpc10__tests_8c.html#a8118656bb5a60090a1dbffa402168438", null ],
    [ "OUT_FILE_NAME", "lpc10__tests_8c.html#a75506823f0db0ef3f4f022cf132dbbbb", null ],
    [ "REF_FILE_NAME", "lpc10__tests_8c.html#a8db25466edf272d9ec855b692f9a98b2", null ],
    [ "SPANDSP_EXPOSE_INTERNAL_STRUCTURES", "lpc10__tests_8c.html#a4dbcfe9986d8f3d4d39f3e395fc96c0c", null ],
    [ "main", "lpc10__tests_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ]
];