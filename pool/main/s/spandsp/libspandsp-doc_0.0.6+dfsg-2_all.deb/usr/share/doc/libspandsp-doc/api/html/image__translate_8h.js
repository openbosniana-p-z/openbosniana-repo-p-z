var image__translate_8h =
[
    [ "image_translate_state_t", "image__translate_8h.html#aea8e6d582352a1a9017cfabd0fd004ea", null ],
    [ "IMAGE_TRANSLATE_FROM_MONO", "image__translate_8h.html#af3520ff6d43011872bab77edd27d4de3a8cf33b11f16fbe60c7eba667506ac17a", null ],
    [ "IMAGE_TRANSLATE_FROM_GRAY_8", "image__translate_8h.html#af3520ff6d43011872bab77edd27d4de3a736892cc842784047145c30f9054e55d", null ],
    [ "IMAGE_TRANSLATE_FROM_GRAY_16", "image__translate_8h.html#af3520ff6d43011872bab77edd27d4de3a38c50b73291284e75d8e2e692d92c1fe", null ],
    [ "IMAGE_TRANSLATE_FROM_COLOUR_8", "image__translate_8h.html#af3520ff6d43011872bab77edd27d4de3a33757f5617199522fff9fa09d2d91c00", null ],
    [ "IMAGE_TRANSLATE_FROM_COLOUR_16", "image__translate_8h.html#af3520ff6d43011872bab77edd27d4de3a0e45a4bccc5fb047486903dd4978cecf", null ],
    [ "image_translate_free", "image__translate_8h.html#add6ea5d13bb71d780bbff0601a0dedc2", null ],
    [ "image_translate_get_output_length", "image__translate_8h.html#a485ed4e25f6b982ed5fe83828d2f000a", null ],
    [ "image_translate_get_output_width", "image__translate_8h.html#aacbd77e2c5041a6b398fa90e4e07e0f5", null ],
    [ "image_translate_init", "image__translate_8h.html#a73235602b309f915c4a46793e534a54d", null ],
    [ "image_translate_release", "image__translate_8h.html#ac07690fb9be0243883fcae8aac18bd26", null ],
    [ "image_translate_row", "image__translate_8h.html#a7f607850346f1ecbb482a0c9bd0608ff", null ]
];