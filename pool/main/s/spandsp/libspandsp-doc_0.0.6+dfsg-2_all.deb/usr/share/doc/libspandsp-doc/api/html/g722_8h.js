var g722_8h =
[
    [ "g722_decode_state_t", "g722_8h.html#ad714bbad056fc9d871b1aab1e9fba5bf", null ],
    [ "g722_encode_state_t", "g722_8h.html#a180475a40eea37607c9e5fe20e8b9969", null ],
    [ "G722_SAMPLE_RATE_8000", "g722_8h.html#a394b3903fbf00ba2b6243f60689a5a5fadf4959c5af7ec14092f02cf409098183", null ],
    [ "G722_PACKED", "g722_8h.html#a394b3903fbf00ba2b6243f60689a5a5fad5e6ab7e4a0352c1cd227c9ae8faeab8", null ],
    [ "g722_decode", "g722_8h.html#a9960072356db239a2861d132af06ebc5", null ],
    [ "g722_decode_free", "g722_8h.html#a8b2a4d094e437c00b4936e988e93fe28", null ],
    [ "g722_decode_init", "g722_8h.html#ad79183471278366b4e87321bb810fad7", null ],
    [ "g722_decode_release", "g722_8h.html#a9dbbe9430de1ee7aa6d22f3523a578c1", null ],
    [ "g722_encode", "g722_8h.html#a5fddb432e48aa916ba855cae0ee00743", null ],
    [ "g722_encode_free", "g722_8h.html#aa8c59c5fe90fd9f5de695fdfb5a6c867", null ],
    [ "g722_encode_init", "g722_8h.html#aa07fd4b4d86a97335bcde872e25eb288", null ],
    [ "g722_encode_release", "g722_8h.html#a11ea21bf5a03f25c3e2e225e4a5bfc56", null ]
];