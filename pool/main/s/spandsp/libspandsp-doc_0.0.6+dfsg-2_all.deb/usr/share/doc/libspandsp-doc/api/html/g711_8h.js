var g711_8h =
[
    [ "G711_ALAW_AMI_MASK", "g711_8h.html#a260f59891763fa250e597e266a4f76b3", null ],
    [ "G711_ALAW_IDLE_OCTET", "g711_8h.html#a96d9f8bcea5d58ab22035fe8250ca359", null ],
    [ "G711_ULAW_BIAS", "g711_8h.html#a4e1e65d839f235467b0b94e0ca1c045b", null ],
    [ "G711_ULAW_IDLE_OCTET", "g711_8h.html#a6d597a7e0e86d41c88d23fd314350eb9", null ],
    [ "g711_state_t", "g711_8h.html#a55896ac1952dbb17511f44f84bc9148b", null ],
    [ "G711_ALAW", "g711_8h.html#afa231099d07583c3ed0981e0bb665f55a73655fab47ebf47fbe49d91474a090ad", null ],
    [ "G711_ULAW", "g711_8h.html#afa231099d07583c3ed0981e0bb665f55a3f23bde69c043b9c3daaa9f2c4ab0194", null ],
    [ "alaw_to_ulaw", "g711_8h.html#a4934185b54b59595a44e5e1a4495a8ad", null ],
    [ "g711_decode", "g711_8h.html#aa4ead32817fb0508c80e0a66c46a39ec", null ],
    [ "g711_encode", "g711_8h.html#a70f925f742a8d4975b0be934539a112a", null ],
    [ "g711_free", "g711_8h.html#afb0f01e0452029237cbe84fec0a788c0", null ],
    [ "g711_init", "g711_8h.html#a708286ce03c09c2895bb8b1d47aae4a0", null ],
    [ "g711_release", "g711_8h.html#aca377b1f9c4a8b8f3211e5cfad9954ab", null ],
    [ "g711_transcode", "g711_8h.html#a65ad6ccd324d19f8e4376634925ac4b7", null ],
    [ "ulaw_to_alaw", "g711_8h.html#a500dc1ef00e7fa76e17e7b87ade6a219", null ]
];