var fax__modems_8c =
[
    [ "HDLC_FRAMING_OK_THRESHOLD", "fax__modems_8c.html#a35630af13cdf4a5b011b86e2d0fa935e", null ],
    [ "fax_modem_to_str", "fax__modems_8c.html#a6543d642c3f512ba79d27a1c03d4230a", null ],
    [ "fax_modems_free", "fax__modems_8c.html#aa2dbf67af3390d7a81289d632277331f", null ],
    [ "fax_modems_get_logging_state", "fax__modems_8c.html#aa72fbcbf87049b5228d59742bd9457ab", null ],
    [ "fax_modems_hdlc_tx_frame", "fax__modems_8c.html#a85db0e8b746c3a681972b828053cd044", null ],
    [ "fax_modems_init", "fax__modems_8c.html#a62c412a9010293e54f59b4b6d6709eef", null ],
    [ "fax_modems_release", "fax__modems_8c.html#a3339aec348f89b4ede60ae63295774fb", null ],
    [ "fax_modems_restart", "fax__modems_8c.html#a1e96dee30ec02d2ac4342edb59050ac5", null ],
    [ "fax_modems_set_tep_mode", "fax__modems_8c.html#a9b31c5b47dd1ec9404ef90a248146a5c", null ],
    [ "fax_modems_start_rx_modem", "fax__modems_8c.html#af403a05624eb2c8e57a63c8c1a018427", null ],
    [ "fax_modems_v17_v21_rx", "fax__modems_8c.html#a66f633c393c260bf4132b2e115b96aba", null ],
    [ "fax_modems_v17_v21_rx_fillin", "fax__modems_8c.html#a85287e8fdc68df60ff1cb2b2dbc8e210", null ],
    [ "fax_modems_v27ter_v21_rx", "fax__modems_8c.html#a8a0a3e311ff0ce330506e7c47f5f89ff", null ],
    [ "fax_modems_v27ter_v21_rx_fillin", "fax__modems_8c.html#a6239db59cf550dac9fbb3de327defac2", null ],
    [ "fax_modems_v29_v21_rx", "fax__modems_8c.html#a807b7d75c5b1d5aa013bace7487596a5", null ],
    [ "fax_modems_v29_v21_rx_fillin", "fax__modems_8c.html#a42c5dccbf8d25ba26a4f1c303ab68eae", null ]
];