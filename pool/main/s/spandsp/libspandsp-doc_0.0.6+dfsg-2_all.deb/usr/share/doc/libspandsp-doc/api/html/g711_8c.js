var g711_8c =
[
    [ "alaw_to_ulaw", "g711_8c.html#a4934185b54b59595a44e5e1a4495a8ad", null ],
    [ "g711_decode", "g711_8c.html#aa4ead32817fb0508c80e0a66c46a39ec", null ],
    [ "g711_encode", "g711_8c.html#a70f925f742a8d4975b0be934539a112a", null ],
    [ "g711_free", "g711_8c.html#afb0f01e0452029237cbe84fec0a788c0", null ],
    [ "g711_init", "g711_8c.html#a708286ce03c09c2895bb8b1d47aae4a0", null ],
    [ "g711_release", "g711_8c.html#aca377b1f9c4a8b8f3211e5cfad9954ab", null ],
    [ "g711_transcode", "g711_8c.html#a65ad6ccd324d19f8e4376634925ac4b7", null ],
    [ "ulaw_to_alaw", "g711_8c.html#a500dc1ef00e7fa76e17e7b87ade6a219", null ]
];