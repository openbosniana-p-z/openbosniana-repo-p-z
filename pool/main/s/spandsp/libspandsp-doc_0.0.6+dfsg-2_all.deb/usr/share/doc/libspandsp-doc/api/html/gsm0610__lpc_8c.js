var gsm0610__lpc_8c =
[
    [ "STEP", "gsm0610__lpc_8c.html#aacab30ba921a87b8d61d51ee943b8541", null ],
    [ "gsm0610_lpc_analysis", "gsm0610__lpc_8c.html#ae43338068ffd6523e193bbaa1097e837", null ],
    [ "gsm0610_norm", "gsm0610__lpc_8c.html#adcdea41814ed77401a3fe0b6975ebcd7", null ]
];