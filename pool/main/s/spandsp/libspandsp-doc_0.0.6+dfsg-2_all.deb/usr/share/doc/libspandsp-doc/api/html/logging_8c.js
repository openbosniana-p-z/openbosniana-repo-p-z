var logging_8c =
[
    [ "span_log", "logging_8c.html#a90f76f62c77c8b43ce48c574b67cbea9", null ],
    [ "span_log_buf", "logging_8c.html#a93b88a891d6934beb06c5f36f9dc0b3b", null ],
    [ "span_log_bump_samples", "logging_8c.html#afec643924236341abbf9b93cb9e91efe", null ],
    [ "span_log_free", "logging_8c.html#ab880e7231f28f43460db2ad35267a62d", null ],
    [ "span_log_init", "logging_8c.html#a6d70972faff33c8df8c6bfb8603a7bf0", null ],
    [ "span_log_release", "logging_8c.html#ae05624f89adf3a56428754b4536c8911", null ],
    [ "span_log_set_error_handler", "logging_8c.html#a74dd620ac3d00709057571bf44335748", null ],
    [ "span_log_set_level", "logging_8c.html#a1d664942af86b77cc2ed2073ab94336e", null ],
    [ "span_log_set_message_handler", "logging_8c.html#a902cd06eb6dbc12eae5c150a98266ae1", null ],
    [ "span_log_set_protocol", "logging_8c.html#abd5ccd925f1610b027f30c79dc4a76ff", null ],
    [ "span_log_set_sample_rate", "logging_8c.html#a5792b46637c2ccffd1b1501456949dea", null ],
    [ "span_log_set_tag", "logging_8c.html#a8c984ad65a309765c0cd41e04fbeb61a", null ],
    [ "span_log_test", "logging_8c.html#a26dbbeb78360c57999e482bf32e7fc20", null ],
    [ "span_set_error_handler", "logging_8c.html#a21aa7ccf709f0467786651a0e2f324e8", null ],
    [ "span_set_message_handler", "logging_8c.html#a4d674dc0ea5d8ea43cd9e5788025c1dd", null ]
];