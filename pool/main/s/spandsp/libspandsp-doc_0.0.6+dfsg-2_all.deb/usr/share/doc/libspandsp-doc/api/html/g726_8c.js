var g726_8c =
[
    [ "g726_decode", "g726_8c.html#a319b661736137ef72b1806c8919751cb", null ],
    [ "g726_encode", "g726_8c.html#ad7d6e89813d7c9427c061eb9aeba121d", null ],
    [ "g726_free", "g726_8c.html#a934ebc1d3fda537b4706cc881c2eea26", null ],
    [ "g726_init", "g726_8c.html#acbc9a2b4325668c35da4be882f89fcb0", null ],
    [ "g726_release", "g726_8c.html#aa0db1754d71a3d2a03c1a1b08dda2a68", null ]
];