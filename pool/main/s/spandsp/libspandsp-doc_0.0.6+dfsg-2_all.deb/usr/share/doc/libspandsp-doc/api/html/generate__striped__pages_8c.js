var generate__striped__pages_8c =
[
    [ "IMAGE_LENGTH", "generate__striped__pages_8c.html#a008ea59008bcb063601df216003e2752", null ],
    [ "IMAGE_WIDTH", "generate__striped__pages_8c.html#aafd9a8a07447ca0c0c79ae00e8e5f7e9", null ],
    [ "ROWS_PER_STRIPE", "generate__striped__pages_8c.html#ab0594c4ca6290e170e86834fa437b5b0", null ],
    [ "main", "generate__striped__pages_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ]
];