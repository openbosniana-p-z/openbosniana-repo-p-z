var oki__adpcm_8h =
[
    [ "oki_adpcm_state_t", "oki__adpcm_8h.html#a1b5dfbf70df576397dd08cfe99119084", null ],
    [ "oki_adpcm_decode", "oki__adpcm_8h.html#a0132d62367ed27a2332dbed993dce4c4", null ],
    [ "oki_adpcm_encode", "oki__adpcm_8h.html#a49a2142b1750505c833e840a849ed919", null ],
    [ "oki_adpcm_free", "oki__adpcm_8h.html#af218a728ef2e6c72378f388a4f706fb6", null ],
    [ "oki_adpcm_init", "oki__adpcm_8h.html#a6354ae754f303a5c9ca6f424f64acbc3", null ],
    [ "oki_adpcm_release", "oki__adpcm_8h.html#ae5e0f098d49a99eb77b7e90bf29f3675", null ]
];