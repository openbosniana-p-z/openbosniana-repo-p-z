var msvc_2spandsp_8h =
[
    [ "__inline__", "msvc_2spandsp_8h.html#a9f04218fe09e6ee659e045b2f11542ed", null ],
    [ "SPANDSP_USE_EXPORT_CAPABILITY", "msvc_2spandsp_8h.html#a686dd5601cda42cc153ffb46ffe52b5c", null ]
];