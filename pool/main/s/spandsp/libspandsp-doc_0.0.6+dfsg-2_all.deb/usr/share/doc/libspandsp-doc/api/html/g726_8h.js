var g726_8h =
[
    [ "g726_decoder_func_t", "g726_8h.html#af351df7614650cde652cef9bce27f721", null ],
    [ "g726_encoder_func_t", "g726_8h.html#a1e3a48879fe8d568de2fd0a25153fc80", null ],
    [ "g726_state_t", "g726_8h.html#a7759e60268eb9ef5bcd0d3eb78fffe7a", null ],
    [ "G726_ENCODING_LINEAR", "g726_8h.html#ac205be2172292384dd687b5471a87eddac080f253d85bd9bb796d965b13358069", null ],
    [ "G726_ENCODING_ULAW", "g726_8h.html#ac205be2172292384dd687b5471a87eddad93ea1357536d82a864ce5094f92fd98", null ],
    [ "G726_ENCODING_ALAW", "g726_8h.html#ac205be2172292384dd687b5471a87edda8b417cb5a73053cd0e2fa065a9e53adb", null ],
    [ "G726_PACKING_NONE", "g726_8h.html#a157d5577a5b2f5986037d0d09c7dc77da808ec60eeb2d42fe1682bde804320951", null ],
    [ "G726_PACKING_LEFT", "g726_8h.html#a157d5577a5b2f5986037d0d09c7dc77da66a109f0ca1d784daee1a3ae04bd6ec3", null ],
    [ "G726_PACKING_RIGHT", "g726_8h.html#a157d5577a5b2f5986037d0d09c7dc77da3fb41177bd1430dddabef1c8b104918a", null ],
    [ "g726_decode", "g726_8h.html#a319b661736137ef72b1806c8919751cb", null ],
    [ "g726_encode", "g726_8h.html#ad7d6e89813d7c9427c061eb9aeba121d", null ],
    [ "g726_free", "g726_8h.html#a934ebc1d3fda537b4706cc881c2eea26", null ],
    [ "g726_init", "g726_8h.html#acbc9a2b4325668c35da4be882f89fcb0", null ],
    [ "g726_release", "g726_8h.html#aa0db1754d71a3d2a03c1a1b08dda2a68", null ]
];