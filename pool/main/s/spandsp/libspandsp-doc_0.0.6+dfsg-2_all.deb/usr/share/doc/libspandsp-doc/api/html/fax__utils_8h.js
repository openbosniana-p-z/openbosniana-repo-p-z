var fax__utils_8h =
[
    [ "fax_log_final_transfer_statistics", "fax__utils_8h.html#a8ead11a931afe3f4eb92a50c2500e8ab", null ],
    [ "fax_log_page_transfer_statistics", "fax__utils_8h.html#a00e719203d54f9e0c5ab359b87e19bf8", null ],
    [ "fax_log_rx_parameters", "fax__utils_8h.html#a6ca7f49d8434e4cbaf5dedd371ddc7e9", null ],
    [ "fax_log_tx_parameters", "fax__utils_8h.html#a3c4db52af5e881666ca3f53c7fa7650f", null ],
    [ "get_tiff_total_pages", "fax__utils_8h.html#a5f48f4f5bb3599c50e0ba44deeda236c", null ]
];