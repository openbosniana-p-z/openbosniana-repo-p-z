var ima__adpcm_8h =
[
    [ "ima_adpcm_state_t", "ima__adpcm_8h.html#ad3d92f2c3bd24a48307bc7118a95df30", null ],
    [ "IMA_ADPCM_IMA4", "ima__adpcm_8h.html#a84627a72058502328269676b81780f89a7cca080abbbdc8fc1fe03094b59edd7c", null ],
    [ "IMA_ADPCM_DVI4", "ima__adpcm_8h.html#a84627a72058502328269676b81780f89a6ed22f12ea2a76aab22c29693bb6d69c", null ],
    [ "IMA_ADPCM_VDVI", "ima__adpcm_8h.html#a84627a72058502328269676b81780f89af85f733af162ae9b987f335e85f867e5", null ],
    [ "ima_adpcm_decode", "ima__adpcm_8h.html#a4a05b55e5fb0a288460d545192a4c915", null ],
    [ "ima_adpcm_encode", "ima__adpcm_8h.html#a373a16816c2f806d4a62b97730024e8f", null ],
    [ "ima_adpcm_free", "ima__adpcm_8h.html#a010d19d4deefd7b12f4c71d302512483", null ],
    [ "ima_adpcm_init", "ima__adpcm_8h.html#a5eae19c7895a2326e52c1f61b6f2acb6", null ],
    [ "ima_adpcm_release", "ima__adpcm_8h.html#a551c58909b85a213e5c0cb11cbff4d26", null ]
];