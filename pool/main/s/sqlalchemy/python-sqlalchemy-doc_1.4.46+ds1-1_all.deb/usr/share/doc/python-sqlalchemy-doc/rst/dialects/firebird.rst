.. _firebird_toplevel:

Firebird
========

.. automodule:: sqlalchemy.dialects.firebird.base

fdb
---

.. automodule:: sqlalchemy.dialects.firebird.fdb

kinterbasdb
-----------

.. automodule:: sqlalchemy.dialects.firebird.kinterbasdb
