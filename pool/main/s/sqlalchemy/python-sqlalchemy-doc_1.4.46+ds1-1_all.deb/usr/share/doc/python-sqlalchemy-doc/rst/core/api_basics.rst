===============
Core API Basics
===============

.. toctree::
    :maxdepth: 2

    event
    inspection
    exceptions
    internals
