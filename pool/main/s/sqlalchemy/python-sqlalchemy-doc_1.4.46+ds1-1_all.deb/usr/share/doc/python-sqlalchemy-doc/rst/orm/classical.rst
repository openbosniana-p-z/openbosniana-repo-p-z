:orphan:

Moved!   :ref:`orm_imperative_mapping`


