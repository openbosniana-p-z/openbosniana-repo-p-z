:orphan:

.. _declarative_inheritance:

Declarative Inheritance
=======================

See :ref:`inheritance_toplevel` for this section.
