:orphan:

.. _declarative_configuring_relationships:

=========================
Configuring Relationships
=========================

This section is covered by :ref:`orm_declarative_properties`.

.. _declarative_relationship_eval:

Evaluation of relationship arguments
=====================================

This section is moved to :ref:`orm_declarative_relationship_eval`.


.. _declarative_many_to_many:

Configuring Many-to-Many Relationships
======================================

This section is moved to :ref:`orm_declarative_relationship_secondary_eval`.

