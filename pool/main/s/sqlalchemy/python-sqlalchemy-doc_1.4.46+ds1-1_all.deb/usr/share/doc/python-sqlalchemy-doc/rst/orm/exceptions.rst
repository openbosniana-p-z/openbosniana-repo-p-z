.. _orm_exceptions_toplevel:

ORM Exceptions
==============

.. automodule:: sqlalchemy.orm.exc
    :members:
