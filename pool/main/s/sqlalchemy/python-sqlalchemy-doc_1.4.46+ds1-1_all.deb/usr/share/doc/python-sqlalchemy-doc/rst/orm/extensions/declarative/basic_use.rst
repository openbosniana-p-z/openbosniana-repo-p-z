:orphan:

=========
Basic Use
=========

This section has moved to :ref:`orm_declarative_mapping`.

Defining Attributes
===================

This section is covered by :ref:`mapping_columns_toplevel`



Accessing the MetaData
======================

This section has moved to :ref:`orm_declarative_metadata`.


Class Constructor
=================

This section has moved to :ref:`orm_mapper_configuration_overview`.

Mapper Configuration
====================

This section is moved to :ref:`orm_declarative_mapper_options`.


.. _declarative_sql_expressions:

Defining SQL Expressions
========================

See :ref:`mapper_sql_expressions` for examples on declaratively
mapping attributes to SQL expressions.

