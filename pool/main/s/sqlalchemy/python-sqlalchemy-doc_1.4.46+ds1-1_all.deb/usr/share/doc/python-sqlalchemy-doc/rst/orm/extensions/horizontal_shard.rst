.. _horizontal_sharding_toplevel:

Horizontal Sharding
===================

.. automodule:: sqlalchemy.ext.horizontal_shard

API Documentation
-----------------

.. autoclass:: ShardedSession
   :members:

.. autoclass:: ShardedQuery
   :members:

