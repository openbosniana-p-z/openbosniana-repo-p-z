.. _types_toplevel:

SQL Datatype Objects
=====================

.. toctree::
    :maxdepth: 3

    type_basics
    custom_types
    type_api
