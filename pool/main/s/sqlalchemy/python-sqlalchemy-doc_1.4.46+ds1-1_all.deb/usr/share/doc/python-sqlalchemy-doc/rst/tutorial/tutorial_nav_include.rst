.. note *_include.rst is a naming convention in conf.py

.. |tutorial_title| replace:: SQLAlchemy 1.4 / 2.0 Tutorial

.. topic:: |tutorial_title|

      This page is part of the :doc:`index`.

      Previous: |prev|   |   Next: |next|

.. footer_topic:: |tutorial_title|

      Next Tutorial Section: |next|

