.. _sqlalchemy.ext.compiler_toplevel:

Custom SQL Constructs and Compilation Extension
===============================================

.. automodule:: sqlalchemy.ext.compiler
    :members:
