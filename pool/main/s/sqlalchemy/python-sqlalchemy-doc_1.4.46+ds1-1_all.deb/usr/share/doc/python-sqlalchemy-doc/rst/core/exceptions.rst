.. _core_exceptions_toplevel:

Core Exceptions
===============

.. automodule:: sqlalchemy.exc
    :members:
