.. _indexable_toplevel:

Indexable
=========

.. automodule:: sqlalchemy.ext.indexable

API Reference
-------------

.. autoclass:: sqlalchemy.ext.indexable.index_property
    :members:

