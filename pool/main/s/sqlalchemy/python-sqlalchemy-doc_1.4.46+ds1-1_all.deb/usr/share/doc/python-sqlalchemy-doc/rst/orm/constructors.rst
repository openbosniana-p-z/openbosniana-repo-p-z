:orphan:

.. currentmodule:: sqlalchemy.orm

.. _mapping_constructors:

Constructors and Object Initialization
======================================

This document has been removed.  See :ref:`orm_mapped_class_behavior`
as well as :meth:`_orm.InstanceEvents.load` for what was covered here.

