Expression Serializer Extension
===============================

.. automodule:: sqlalchemy.ext.serializer
   :members:
   :undoc-members:
