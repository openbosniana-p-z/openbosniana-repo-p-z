:orphan:

.. _declarative_mixins:

Mixin and Custom Base Classes
=============================

See :ref:`orm_mixins_toplevel` for this section.
