.. currentmodule:: sqlalchemy.orm

Relationships API
-----------------

.. autofunction:: relationship

.. autofunction:: backref

.. autofunction:: relation

.. autofunction:: dynamic_loader

.. autofunction:: foreign

.. autofunction:: remote



