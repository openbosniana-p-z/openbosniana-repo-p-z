.. _hybrids_toplevel:

Hybrid Attributes
=================

.. automodule:: sqlalchemy.ext.hybrid

API Reference
-------------

.. autoclass:: hybrid_method
    :members:

.. autoclass:: hybrid_property
    :members:

.. autoclass:: Comparator


.. autodata:: HYBRID_METHOD

.. autodata:: HYBRID_PROPERTY
