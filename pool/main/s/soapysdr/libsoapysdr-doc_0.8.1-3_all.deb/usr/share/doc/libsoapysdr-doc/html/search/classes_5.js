var searchData=
[
  ['soapysdrarginfo_0',['SoapySDRArgInfo',['../structSoapySDRArgInfo.html',1,'']]],
  ['soapysdrkwargs_1',['SoapySDRKwargs',['../structSoapySDRKwargs.html',1,'']]],
  ['soapysdrrange_2',['SoapySDRRange',['../structSoapySDRRange.html',1,'']]]
];
