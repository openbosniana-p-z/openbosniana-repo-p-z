var searchData=
[
  ['type_0',['type',['../structSoapySDRArgInfo.html#a1a36d752e73cc4535e4cb1f5f78af812',1,'SoapySDRArgInfo::type()'],['../classSoapySDR_1_1ArgInfo.html#a1c288b5a2009c58cdd7a3c0af918ef93',1,'SoapySDR::ArgInfo::type()']]]
];
