var searchData=
[
  ['optionnames_0',['optionNames',['../structSoapySDRArgInfo.html#a929fed72ea300d13e8d042e574147f0e',1,'SoapySDRArgInfo::optionNames()'],['../classSoapySDR_1_1ArgInfo.html#a6fc666259d76c3987ebe9a683b20f342',1,'SoapySDR::ArgInfo::optionNames()']]],
  ['options_1',['options',['../structSoapySDRArgInfo.html#a62a9a7757c920642e802d3151fbac348',1,'SoapySDRArgInfo::options()'],['../classSoapySDR_1_1ArgInfo.html#a69df07a6c4e8b69ad14126cd8c86eda7',1,'SoapySDR::ArgInfo::options()']]]
];
