var searchData=
[
  ['range_0',['range',['../structSoapySDRArgInfo.html#a5c595fc875042a1fe2122081f2b424ed',1,'SoapySDRArgInfo::range()'],['../classSoapySDR_1_1ArgInfo.html#a6878e84000f63cfd5819b37caee62fe8',1,'SoapySDR::ArgInfo::range()']]]
];
