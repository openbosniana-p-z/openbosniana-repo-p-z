var searchData=
[
  ['vals_0',['vals',['../structSoapySDRKwargs.html#a9a27e6e8523613646f2c25a6d802128b',1,'SoapySDRKwargs']]],
  ['value_1',['value',['../structSoapySDRArgInfo.html#accef107af453fbec00225047da3ee853',1,'SoapySDRArgInfo::value()'],['../classSoapySDR_1_1ArgInfo.html#a843f950b5002aea712e030b7111f89d1',1,'SoapySDR::ArgInfo::value()']]]
];
