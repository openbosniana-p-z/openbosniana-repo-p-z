var searchData=
[
  ['enumerate_0',['enumerate',['../classSoapySDR_1_1Device.html#a562f4fc2cb77d134357b111d3d5256ff',1,'SoapySDR::Device::enumerate(const Kwargs &amp;args=Kwargs())'],['../classSoapySDR_1_1Device.html#a92050e1daf16615aba275b042276f3d1',1,'SoapySDR::Device::enumerate(const std::string &amp;args)']]],
  ['errtostr_1',['errToStr',['../namespaceSoapySDR.html#af78ba7977bf782f7a43a32e226cb936f',1,'SoapySDR']]]
];
