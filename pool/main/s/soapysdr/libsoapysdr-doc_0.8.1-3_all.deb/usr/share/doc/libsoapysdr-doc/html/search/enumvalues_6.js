var searchData=
[
  ['vectorized_0',['VECTORIZED',['../classSoapySDR_1_1ConverterRegistry.html#a93a150b8e96ffd99ff6fa3da63e1c75da01db734895ce3de4526af6756710f6b1',1,'SoapySDR::ConverterRegistry']]]
];
