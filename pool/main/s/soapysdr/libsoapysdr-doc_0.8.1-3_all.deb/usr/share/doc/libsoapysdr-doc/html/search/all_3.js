var searchData=
[
  ['deactivatestream_0',['deactivateStream',['../classSoapySDR_1_1Device.html#a6e5df11bb3d71e1e584fffb96fc3035f',1,'SoapySDR::Device']]],
  ['deprecated_20list_1',['Deprecated List',['../deprecated.html',1,'']]],
  ['description_2',['description',['../structSoapySDRArgInfo.html#afca2eb0168826d1bbf40f3f8316ce47f',1,'SoapySDRArgInfo::description()'],['../classSoapySDR_1_1ArgInfo.html#a6d999c94c0da4d201a13664ebb9f91fd',1,'SoapySDR::ArgInfo::description()']]],
  ['device_3',['Device',['../classSoapySDR_1_1Device.html',1,'SoapySDR']]],
  ['device_2eh_4',['Device.h',['../Device_8h.html',1,'']]],
  ['device_2ehpp_5',['Device.hpp',['../Device_8hpp.html',1,'']]]
];
