var searchData=
[
  ['kwargs_0',['Kwargs',['../namespaceSoapySDR.html#ac7c038598fa1a11acee1b0194f9dad62',1,'SoapySDR']]],
  ['kwargslist_1',['KwargsList',['../namespaceSoapySDR.html#adfeb27ccbf4f8840debd7c21757c72d6',1,'SoapySDR']]]
];
