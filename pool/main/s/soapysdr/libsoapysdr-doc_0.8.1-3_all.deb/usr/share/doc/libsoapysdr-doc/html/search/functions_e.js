var searchData=
[
  ['vlogf_0',['vlogf',['../namespaceSoapySDR.html#a0b1e9d955ef43207dbc00b74aed83a40',1,'SoapySDR']]]
];
