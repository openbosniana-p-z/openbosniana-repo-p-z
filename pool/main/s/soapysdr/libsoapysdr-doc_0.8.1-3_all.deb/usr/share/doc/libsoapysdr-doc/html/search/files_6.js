var searchData=
[
  ['registry_2ehpp_0',['Registry.hpp',['../Registry_8hpp.html',1,'']]]
];
