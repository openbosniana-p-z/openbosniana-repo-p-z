var searchData=
[
  ['description_0',['description',['../structSoapySDRArgInfo.html#afca2eb0168826d1bbf40f3f8316ce47f',1,'SoapySDRArgInfo::description()'],['../classSoapySDR_1_1ArgInfo.html#a6d999c94c0da4d201a13664ebb9f91fd',1,'SoapySDR::ArgInfo::description()']]]
];
