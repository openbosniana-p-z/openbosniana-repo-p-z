var searchData=
[
  ['closestream_0',['closeStream',['../classSoapySDR_1_1Device.html#a3af55b3e429765b8e057b2b8c2af009b',1,'SoapySDR::Device']]],
  ['converterregistry_1',['ConverterRegistry',['../classSoapySDR_1_1ConverterRegistry.html#adccc33d07d68ba9f6befdc17b0c97b88',1,'SoapySDR::ConverterRegistry']]]
];
