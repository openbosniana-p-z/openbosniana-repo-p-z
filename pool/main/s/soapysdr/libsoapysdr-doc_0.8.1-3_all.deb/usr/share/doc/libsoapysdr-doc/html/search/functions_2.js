var searchData=
[
  ['deactivatestream_0',['deactivateStream',['../classSoapySDR_1_1Device.html#a6e5df11bb3d71e1e584fffb96fc3035f',1,'SoapySDR::Device']]]
];
