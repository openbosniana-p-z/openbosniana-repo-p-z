var searchData=
[
  ['rangelist_0',['RangeList',['../namespaceSoapySDR.html#a75daa1b2fa0c08e898b805ce23d7672e',1,'SoapySDR']]]
];
