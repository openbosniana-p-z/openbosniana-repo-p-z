var searchData=
[
  ['_7edevice_0',['~Device',['../classSoapySDR_1_1Device.html#a9f0f77deffb10f48936a95d0f0f323a2',1,'SoapySDR::Device']]],
  ['_7emodulemanager_1',['~ModuleManager',['../classSoapySDR_1_1ModuleManager.html#a6d9015b554917d18cf94cfdb70bc729a',1,'SoapySDR::ModuleManager']]],
  ['_7eregistry_2',['~Registry',['../classSoapySDR_1_1Registry.html#a927ab54d6c6e52a9cccfac399ad4f4cf',1,'SoapySDR::Registry']]]
];
