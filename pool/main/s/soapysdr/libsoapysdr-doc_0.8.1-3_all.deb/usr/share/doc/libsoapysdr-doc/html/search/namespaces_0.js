var searchData=
[
  ['detail_0',['Detail',['../namespaceSoapySDR_1_1Detail.html',1,'SoapySDR']]],
  ['soapysdr_1',['SoapySDR',['../namespaceSoapySDR.html',1,'']]]
];
