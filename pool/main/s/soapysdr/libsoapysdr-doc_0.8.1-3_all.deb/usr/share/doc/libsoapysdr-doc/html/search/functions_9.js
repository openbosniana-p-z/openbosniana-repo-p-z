var searchData=
[
  ['make_0',['make',['../classSoapySDR_1_1Device.html#a8709e47f09ac1dd447514f9cd5bdb8ed',1,'SoapySDR::Device::make(const Kwargs &amp;args=Kwargs())'],['../classSoapySDR_1_1Device.html#affc4a7a7efb06e83bd50efe13e0d6511',1,'SoapySDR::Device::make(const std::string &amp;args)'],['../classSoapySDR_1_1Device.html#aebc4efb6c01904f3ac9e97b1a468bbdf',1,'SoapySDR::Device::make(const KwargsList &amp;argsList)'],['../classSoapySDR_1_1Device.html#a5fddedde4af5a8fd464be36d33a520f9',1,'SoapySDR::Device::make(const std::vector&lt; std::string &gt; &amp;argsList)']]],
  ['maximum_1',['maximum',['../classSoapySDR_1_1Range.html#a87d2e06a5e942d226c697227b463e827',1,'SoapySDR::Range']]],
  ['minimum_2',['minimum',['../classSoapySDR_1_1Range.html#ad4f7175796dfb30a936b03d11ca4780f',1,'SoapySDR::Range']]],
  ['modulemanager_3',['ModuleManager',['../classSoapySDR_1_1ModuleManager.html#a4a9a053e4f0f6aaab17975c8a22626fb',1,'SoapySDR::ModuleManager']]]
];
