var searchData=
[
  ['loghandler_0',['LogHandler',['../namespaceSoapySDR.html#aa1fee48c48d837fb5f73ae3316329dee',1,'SoapySDR']]],
  ['loglevel_1',['LogLevel',['../namespaceSoapySDR.html#a095fdafac63ba09d2d6cc1ce21c2611c',1,'SoapySDR']]]
];
