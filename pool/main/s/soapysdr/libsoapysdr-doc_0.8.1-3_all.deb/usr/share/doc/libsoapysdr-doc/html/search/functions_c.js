var searchData=
[
  ['tickstotimens_0',['ticksToTimeNs',['../namespaceSoapySDR.html#a38159df503d35fd23521643da952eb86',1,'SoapySDR']]],
  ['timenstoticks_1',['timeNsToTicks',['../namespaceSoapySDR.html#add6d6987f643cb0605063d6f5d0fe6e5',1,'SoapySDR']]],
  ['transactspi_2',['transactSPI',['../classSoapySDR_1_1Device.html#a58355399bd15c0d3060944c8274e968c',1,'SoapySDR::Device']]]
];
