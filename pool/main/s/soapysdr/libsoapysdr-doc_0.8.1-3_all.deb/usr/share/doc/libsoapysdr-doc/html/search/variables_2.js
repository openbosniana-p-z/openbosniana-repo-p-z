var searchData=
[
  ['maximum_0',['maximum',['../structSoapySDRRange.html#a7dd8665d38c6f66f306c1ce0868fd71f',1,'SoapySDRRange']]],
  ['minimum_1',['minimum',['../structSoapySDRRange.html#a6de3066aaf77a4bff5cd2599ca5e1b31',1,'SoapySDRRange']]]
];
