var searchData=
[
  ['makefunction_0',['MakeFunction',['../namespaceSoapySDR.html#acb9b70f9c6ab97a6a05ac71c6743a5bb',1,'SoapySDR']]],
  ['makefunctions_1',['MakeFunctions',['../namespaceSoapySDR.html#a19c1c1658c32d55d3faac7d7b1584626',1,'SoapySDR']]]
];
