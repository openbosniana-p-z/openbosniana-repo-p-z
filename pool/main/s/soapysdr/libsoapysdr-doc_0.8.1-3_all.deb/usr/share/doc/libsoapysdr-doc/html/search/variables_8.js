var searchData=
[
  ['u16_5fzero_5foffset_0',['U16_ZERO_OFFSET',['../namespaceSoapySDR.html#a5d1f34b37374ee3234365c04337d84ae',1,'SoapySDR']]],
  ['u32_5fzero_5foffset_1',['U32_ZERO_OFFSET',['../namespaceSoapySDR.html#a790a0183fdd2691cf4642262b7f16e29',1,'SoapySDR']]],
  ['u8_5fzero_5foffset_2',['U8_ZERO_OFFSET',['../namespaceSoapySDR.html#a3b4a7c8dc3bc80499461af6f027c39e2',1,'SoapySDR']]],
  ['units_3',['units',['../structSoapySDRArgInfo.html#ae34b1e88045abea67ed77cb57c4c7483',1,'SoapySDRArgInfo::units()'],['../classSoapySDR_1_1ArgInfo.html#a61de314975b0cb56578ffea3c30d0ec4',1,'SoapySDR::ArgInfo::units()']]]
];
