var searchData=
[
  ['modulemanager_0',['ModuleManager',['../classSoapySDR_1_1ModuleManager.html',1,'SoapySDR']]]
];
