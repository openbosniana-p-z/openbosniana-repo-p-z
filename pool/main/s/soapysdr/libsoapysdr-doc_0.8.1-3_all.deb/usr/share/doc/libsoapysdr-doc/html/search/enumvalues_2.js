var searchData=
[
  ['float_0',['FLOAT',['../classSoapySDR_1_1ArgInfo.html#acf2322d6142ab0ae1f137730b6b54aeda865a3ace9f9683e3d80652d7f85bc6b7',1,'SoapySDR::ArgInfo']]]
];
