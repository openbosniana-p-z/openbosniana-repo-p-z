var searchData=
[
  ['generic_0',['GENERIC',['../classSoapySDR_1_1ConverterRegistry.html#a93a150b8e96ffd99ff6fa3da63e1c75dae84ba59a0bdec911bc2784d99b62807a',1,'SoapySDR::ConverterRegistry']]]
];
