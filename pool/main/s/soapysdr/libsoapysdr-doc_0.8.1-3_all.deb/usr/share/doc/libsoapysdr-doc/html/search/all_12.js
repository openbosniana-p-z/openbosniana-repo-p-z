var searchData=
[
  ['vals_0',['vals',['../structSoapySDRKwargs.html#a9a27e6e8523613646f2c25a6d802128b',1,'SoapySDRKwargs']]],
  ['value_1',['value',['../structSoapySDRArgInfo.html#accef107af453fbec00225047da3ee853',1,'SoapySDRArgInfo::value()'],['../classSoapySDR_1_1ArgInfo.html#a843f950b5002aea712e030b7111f89d1',1,'SoapySDR::ArgInfo::value()']]],
  ['vectorized_2',['VECTORIZED',['../classSoapySDR_1_1ConverterRegistry.html#a93a150b8e96ffd99ff6fa3da63e1c75da01db734895ce3de4526af6756710f6b1',1,'SoapySDR::ConverterRegistry']]],
  ['version_2eh_3',['Version.h',['../Version_8h.html',1,'']]],
  ['version_2ehpp_4',['Version.hpp',['../Version_8hpp.html',1,'']]],
  ['vlogf_5',['vlogf',['../namespaceSoapySDR.html#a0b1e9d955ef43207dbc00b74aed83a40',1,'SoapySDR']]]
];
