var searchData=
[
  ['name_0',['name',['../structSoapySDRArgInfo.html#a0049552f36c64e041654b724eb57955c',1,'SoapySDRArgInfo::name()'],['../classSoapySDR_1_1ArgInfo.html#a9528b7e313bef323c32678eb239d2eec',1,'SoapySDR::ArgInfo::name()']]],
  ['numoptions_1',['numOptions',['../structSoapySDRArgInfo.html#a2e55efc4b09051aed4b7342cba94174f',1,'SoapySDRArgInfo']]]
];
