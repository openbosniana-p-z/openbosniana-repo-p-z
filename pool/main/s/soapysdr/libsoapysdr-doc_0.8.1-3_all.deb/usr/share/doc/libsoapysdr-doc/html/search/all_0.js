var searchData=
[
  ['acquirereadbuffer_0',['acquireReadBuffer',['../classSoapySDR_1_1Device.html#aa804508bf81dd9db982d884c87b79ada',1,'SoapySDR::Device']]],
  ['acquirewritebuffer_1',['acquireWriteBuffer',['../classSoapySDR_1_1Device.html#af26ebff684fedee466cc5fae867f8091',1,'SoapySDR::Device']]],
  ['activatestream_2',['activateStream',['../classSoapySDR_1_1Device.html#af778f46410037507038479670492eb01',1,'SoapySDR::Device']]],
  ['arginfo_3',['ArgInfo',['../classSoapySDR_1_1ArgInfo.html#a5d9d91c6f81dec91dee366133e0ec09f',1,'SoapySDR::ArgInfo::ArgInfo()'],['../classSoapySDR_1_1ArgInfo.html',1,'SoapySDR::ArgInfo']]],
  ['arginfolist_4',['ArgInfoList',['../namespaceSoapySDR.html#a95e03ef3609c4efd972b1178cf0b5370',1,'SoapySDR']]]
];
