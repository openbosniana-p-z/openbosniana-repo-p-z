var searchData=
[
  ['device_0',['Device',['../classSoapySDR_1_1Device.html',1,'SoapySDR']]]
];
