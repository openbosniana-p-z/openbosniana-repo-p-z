var searchData=
[
  ['custom_0',['CUSTOM',['../classSoapySDR_1_1ConverterRegistry.html#a93a150b8e96ffd99ff6fa3da63e1c75da8b91af0b17d0ab8960829605e5fdd9e1',1,'SoapySDR::ConverterRegistry']]]
];
