var searchData=
[
  ['range_0',['Range',['../classSoapySDR_1_1Range.html',1,'SoapySDR']]],
  ['registry_1',['Registry',['../classSoapySDR_1_1Registry.html',1,'SoapySDR']]]
];
