var searchData=
[
  ['s16_5ffull_5fscale_0',['S16_FULL_SCALE',['../namespaceSoapySDR.html#aefea6f7629ca0d913896886191cab7c1',1,'SoapySDR']]],
  ['s32_5ffull_5fscale_1',['S32_FULL_SCALE',['../namespaceSoapySDR.html#accc6355fa09325695dc1aede764f485f',1,'SoapySDR']]],
  ['s8_5ffull_5fscale_2',['S8_FULL_SCALE',['../namespaceSoapySDR.html#a8a5acf32b7260dbd23391ece818d1b5d',1,'SoapySDR']]],
  ['size_3',['size',['../structSoapySDRKwargs.html#a76226fa23921cbbb41f0f2179697fd41',1,'SoapySDRKwargs']]],
  ['step_4',['step',['../structSoapySDRRange.html#ae76acbec09a395ac862c370fde4edaaf',1,'SoapySDRRange']]]
];
