var searchData=
[
  ['kwargsfromstring_0',['KwargsFromString',['../namespaceSoapySDR.html#a2f1e0ae253a68264f8960a4c564aff62',1,'SoapySDR']]],
  ['kwargstostring_1',['KwargsToString',['../namespaceSoapySDR.html#ac34383e854babcc3fa4d23f0f4d71f5c',1,'SoapySDR']]]
];
