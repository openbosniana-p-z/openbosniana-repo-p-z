 
#ifndef __SPHPK_H__
#define __SPHPK_H__

#include <fortran.h>

#ifdef __cplusplus
extern "C"
{
#endif
 
 


// shpg.f
void FORTRAN_NAME(gaqd)(const int * nlat,double * dtheta,double * dwts,double * DWORK,int * ldwork,int * ier);

void FORTRAN_NAME(shagci)(const int * nlat,const int * nlon,float * wshagc,int * lwsha,double * work,int * lwrk,int * ierror); 
void FORTRAN_NAME(shagc)(const int * nlat,const int * nlon,const int * mode,const int * nt, const float * g,int *idimg,int *jdimg,float * ga,float * gb,int * mdab,int * ndab,
                    float * wshagc,int * lwsha,float * wrk2,int * lwork,int * ierror);                                                                          

void FORTRAN_NAME(shsgci)(const int * nlat,const int * nlon,float * wshsgc,int * lwshs,double * work, int * lwrk,int * ierror);
void FORTRAN_NAME(shsgc)(const int * nlat,const int * nlon,const int * mode,const int * nt, float * gh, int * idimg,int * jdimg,const float * ga,const float * gb,int * mdab,int * ndab,
                    float * wshsgc,int * lwshs,float * wrk2,int * lwork,int * ierror);
     
void FORTRAN_NAME(shpgi)(const int * nlat,const int * nlon,const int * isym,int * mtrunc,float * wshp,int * lwshp,int * iwshp,int * liwshp,float * work,int * lwrkint, int *ierror);
void FORTRAN_NAME(shpg)(const int * nlat,const int * nlon,const int * isym,int * mtrunc,float * sx,float * sy,int * idp,
        float * wshp,int * lwshp,int * iwshp,int * liwshp,float * wrk1,int * lwrk1,int * ierror);

#ifdef __cplusplus
}
#endif /* __cplusplus */     
#endif /* __SPHPK_H__ */
