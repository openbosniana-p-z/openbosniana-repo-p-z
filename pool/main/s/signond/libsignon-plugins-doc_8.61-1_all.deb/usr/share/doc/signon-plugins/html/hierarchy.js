var hierarchy =
[
    [ "Interface", "classAuthPluginInterface_1_1Interface.html", null ],
    [ "QObject", null, [
      [ "AuthPluginInterface", "classAuthPluginInterface.html", null ],
      [ "SignOn::BlobIOHandler", "classSignOn_1_1BlobIOHandler.html", null ]
    ] ],
    [ "SessionData", null, [
      [ "SignOn::UiSessionData", "classSignOn_1_1UiSessionData.html", null ]
    ] ]
];