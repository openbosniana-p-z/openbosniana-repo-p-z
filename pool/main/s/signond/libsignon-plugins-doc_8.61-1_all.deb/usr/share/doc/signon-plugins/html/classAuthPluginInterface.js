var classAuthPluginInterface =
[
    [ "AuthPluginInterface", "classAuthPluginInterface.html#a425f68f11ab1eabac0337771e31b26c1", null ],
    [ "~AuthPluginInterface", "classAuthPluginInterface.html#a559163c8ca8b04214faacc3553a922ba", null ],
    [ "abort", "classAuthPluginInterface.html#a6f64a141e8fefa7dca002365d14f1942", null ],
    [ "cancel", "classAuthPluginInterface.html#aa47f7a2c7352955044d059ff89c1a6db", null ],
    [ "error", "classAuthPluginInterface.html#a4d98544136d74f2f7ccdebde0db21804", null ],
    [ "mechanisms", "classAuthPluginInterface.html#a2ce5d0e525530d0bac81ad6d28a6d2ba", null ],
    [ "process", "classAuthPluginInterface.html#a4e0a6d3ee26c3e169c439618a058c612", null ],
    [ "refresh", "classAuthPluginInterface.html#ad08d075a313ab6e42a2d0db9a94c50d8", null ],
    [ "refreshed", "classAuthPluginInterface.html#a2cf8f6161e70145ba6faaa3ec0d1cceb", null ],
    [ "result", "classAuthPluginInterface.html#aa0fa3f3e22aa8cb0ef9cff05c0631c4d", null ],
    [ "statusChanged", "classAuthPluginInterface.html#a2eb3fe38383037c0bf23d935009cc2f5", null ],
    [ "store", "classAuthPluginInterface.html#af78aec5d9005e6c76bbcaabf8fdf053e", null ],
    [ "type", "classAuthPluginInterface.html#a3ed54cd7b060feeddf7f6fb65ec2e508", null ],
    [ "userActionFinished", "classAuthPluginInterface.html#a38d52b25a1ddb49073a8323357d9254c", null ],
    [ "userActionRequired", "classAuthPluginInterface.html#ad0f651b66b203fbcda27cd7c2dde661c", null ]
];