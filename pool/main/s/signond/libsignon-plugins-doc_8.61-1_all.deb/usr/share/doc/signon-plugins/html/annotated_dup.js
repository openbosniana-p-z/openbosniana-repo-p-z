var annotated_dup =
[
    [ "SignOn", "namespaceSignOn.html", [
      [ "UiSessionData", "classSignOn_1_1UiSessionData.html", "classSignOn_1_1UiSessionData" ],
      [ "BlobIOHandler", "classSignOn_1_1BlobIOHandler.html", "classSignOn_1_1BlobIOHandler" ]
    ] ],
    [ "AuthPluginInterface", "classAuthPluginInterface.html", "classAuthPluginInterface" ],
    [ "Interface", "classAuthPluginInterface_1_1Interface.html", null ]
];