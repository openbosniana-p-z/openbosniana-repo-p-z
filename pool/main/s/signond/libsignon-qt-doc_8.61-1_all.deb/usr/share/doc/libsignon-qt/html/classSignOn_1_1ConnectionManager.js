var classSignOn_1_1ConnectionManager =
[
    [ "ConnectionManager", "classSignOn_1_1ConnectionManager.html#a2b40c99e33f210a71f7f27fe3d7f4aeb", null ],
    [ "~ConnectionManager", "classSignOn_1_1ConnectionManager.html#a5c2a49d02244fc399deba3ce6ffe77ac", null ],
    [ "connect", "classSignOn_1_1ConnectionManager.html#a3d059e48d57169a56130428fefc76a31", null ],
    [ "connected", "classSignOn_1_1ConnectionManager.html#a7505ff495746e1e167bb3a78c499d2b6", null ],
    [ "connection", "classSignOn_1_1ConnectionManager.html#aff9b63e25a9ad45a0fe281930c8f3080", null ],
    [ "disconnected", "classSignOn_1_1ConnectionManager.html#ac98978e72c7b0a78411ce76e22506ca0", null ],
    [ "get", "classSignOn_1_1ConnectionManager.html#ab9f8bc43e745d5acc840046b6fcec0f8", null ],
    [ "hasConnection", "classSignOn_1_1ConnectionManager.html#a9cefaef9a621cf886287522db1d93106", null ],
    [ "instance", "classSignOn_1_1ConnectionManager.html#a2c061fd6ebaf437f86c7f860981e11f2", null ]
];