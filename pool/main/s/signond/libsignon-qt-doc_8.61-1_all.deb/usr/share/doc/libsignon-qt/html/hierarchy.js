var hierarchy =
[
    [ "SignOn::Error", "classSignOn_1_1Error.html", null ],
    [ "SignOn::IdentityInfo", "classSignOn_1_1IdentityInfo.html", null ],
    [ "SignOn::AuthService::IdentityRegExp", "classSignOn_1_1AuthService_1_1IdentityRegExp.html", null ],
    [ "QDBusAbstractInterface", null, [
      [ "SignOn::DBusInterface", "classSignOn_1_1DBusInterface.html", null ]
    ] ],
    [ "QObject", null, [
      [ "SignOn::AuthService", "classSignOn_1_1AuthService.html", null ],
      [ "SignOn::AuthSession", "classSignOn_1_1AuthSession.html", null ],
      [ "SignOn::ConnectionManager", "classSignOn_1_1ConnectionManager.html", null ],
      [ "SignOn::Identity", "classSignOn_1_1Identity.html", null ]
    ] ],
    [ "SignOn::SecurityContext", "classSignOn_1_1SecurityContext.html", null ],
    [ "SignOn::SessionData", "classSignOn_1_1SessionData.html", null ]
];