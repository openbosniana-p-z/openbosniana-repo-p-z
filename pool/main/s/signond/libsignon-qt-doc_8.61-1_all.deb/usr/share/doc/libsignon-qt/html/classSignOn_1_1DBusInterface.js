var classSignOn_1_1DBusInterface =
[
    [ "DBusInterface", "classSignOn_1_1DBusInterface.html#a7314222185b7a4acd547e20b8c2b855c", null ],
    [ "~DBusInterface", "classSignOn_1_1DBusInterface.html#ac5c5baed51075aea1d76cdb6d1c991df", null ],
    [ "connect", "classSignOn_1_1DBusInterface.html#a17d61f3356dc6fb4e94b542991ba0708", null ]
];