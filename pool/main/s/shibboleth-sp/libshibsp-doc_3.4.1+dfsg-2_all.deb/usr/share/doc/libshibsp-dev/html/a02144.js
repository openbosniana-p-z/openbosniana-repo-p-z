var a02144 =
[
    [ "Settings", "a02144.html#aba0504360a6328f4895fedd3b39e64e6", null ],
    [ "getSettings", "a02144.html#ae995a656aace11faffb969636315b6e2", null ]
];