var a00104 =
[
    [ "shibsp::ServiceProvider", "a02156.html", "a02156" ],
    [ "XML_SERVICE_PROVIDER", "a00104.html#ac9db06566d064ec891c592e4cadf5d17", null ],
    [ "registerServiceProviders", "a00104.html#a5f293819c9ab4f9df1ac8d6cae84ecac", null ]
];