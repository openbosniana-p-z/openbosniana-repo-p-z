var a01972 =
[
    [ "AbstractSPRequest", "a01972.html#a478c239cd5551aaf88fda363e249ee1b", null ],
    [ "getApplication", "a01972.html#a05ea4b01bafd8d7861aea063a91bf6f4", null ],
    [ "getHandlerURL", "a01972.html#a654bd25d02b89c566b991ed9a3eee063", null ],
    [ "getRequestSettings", "a01972.html#a075799881fe88e4856ae9ab361a047fb", null ],
    [ "getSecureHeader", "a01972.html#a6d3bb8aab01ffff1e2149fb8fc21032b", null ],
    [ "getServiceProvider", "a01972.html#a0b8f7734609efa0172f5a40f7b788421", null ],
    [ "getSession", "a01972.html#ae37aab5d919a8821ad8aebcb31b9c358", null ],
    [ "isPriorityEnabled", "a01972.html#aa62461a5b1af286a28dea944fde331f3", null ],
    [ "log", "a01972.html#a48e3e9cbb31b91029ded4ea14b030ae4", null ],
    [ "setAuthType", "a01972.html#a50e13cfd65487e1047fe1cb7357cb234", null ],
    [ "setRequestURI", "a01972.html#a431a770a987a014241989000f9f0a76d", null ]
];