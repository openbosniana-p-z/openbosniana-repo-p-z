var a00161 =
[
    [ "shibsp::Session", "a02160.html", "a02160" ],
    [ "shibsp::SessionCache", "a02164.html", "a02164" ],
    [ "STORAGESERVICE_SESSION_CACHE", "a00161.html#aca6058b21579a43fe131caff357839c4", null ],
    [ "registerSessionCaches", "a00161.html#a79f0871e05239eddb5d6f17e89e8f70a", null ]
];