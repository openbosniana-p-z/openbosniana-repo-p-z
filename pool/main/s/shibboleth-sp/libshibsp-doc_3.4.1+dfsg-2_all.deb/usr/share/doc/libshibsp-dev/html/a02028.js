var a02028 =
[
    [ "extractAttributes", "a02028.html#a28488c7ce3b744bfd19c42c1657095cf", null ],
    [ "generateMetadata", "a02028.html#a02b7a8fc430fddbc31ba5bf452eefdab", null ],
    [ "getAttributeIds", "a02028.html#a131bedf2cbd08a200689ecc66d76c9b3", null ]
];