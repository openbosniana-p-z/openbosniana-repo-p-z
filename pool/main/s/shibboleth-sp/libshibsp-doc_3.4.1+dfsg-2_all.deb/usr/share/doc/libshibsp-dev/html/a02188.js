var a02188 =
[
    [ "logout_type_t", "a02188.html#a64474f51fa4a58187df0cbcb6febf4de", [
      [ "LOGOUT_EVENT_UNKNOWN", "a02188.html#a64474f51fa4a58187df0cbcb6febf4dea7e3983375a9c2cabd741a37147a6faa6", null ],
      [ "LOGOUT_EVENT_INVALID", "a02188.html#a64474f51fa4a58187df0cbcb6febf4dea3a3346aadeacb31ead6d0e25444c60ca", null ],
      [ "LOGOUT_EVENT_LOCAL", "a02188.html#a64474f51fa4a58187df0cbcb6febf4dea77728c2dfa21edd535b0f63eb9a996f3", null ],
      [ "LOGOUT_EVENT_GLOBAL", "a02188.html#a64474f51fa4a58187df0cbcb6febf4deabfa0c5ca7ccc231695170004811a3424", null ],
      [ "LOGOUT_EVENT_PARTIAL", "a02188.html#a64474f51fa4a58187df0cbcb6febf4deae312dcf435cf7050ce4ffca2c3490e69", null ]
    ] ],
    [ "LogoutEvent", "a02188.html#a0479970ed9872337469a44e16bacfc94", null ],
    [ "getType", "a02188.html#a6e0fb888dd72fb5598419f9c0f2b3fec", null ],
    [ "m_saml2Request", "a02188.html#aa61619153fd58a9a10b3d7a41052537c", null ],
    [ "m_saml2Response", "a02188.html#a91328d81bee753d518dbdefecf79e2c2", null ],
    [ "m_session", "a02188.html#ae72f3944d605406d23a0cd59cc053e77", null ],
    [ "m_sessions", "a02188.html#a556cd45931240fe9c1be2b08feec32cf", null ]
];