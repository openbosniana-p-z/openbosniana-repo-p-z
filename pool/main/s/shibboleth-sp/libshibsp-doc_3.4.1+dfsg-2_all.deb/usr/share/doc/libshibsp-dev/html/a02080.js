var a02080 =
[
    [ "getType", "a02080.html#a4aa3b3db4e9d984d8b5d334740e85d46", null ]
];