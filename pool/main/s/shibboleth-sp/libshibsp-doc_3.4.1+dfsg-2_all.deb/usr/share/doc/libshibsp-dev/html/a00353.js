var a00353 =
[
    [ "shibsp::AttributeResolver", "a02032.html", "a02032" ],
    [ "CHAINING_ATTRIBUTE_RESOLVER", "a00353.html#af65115883037494d5d7b28a140a6054c", null ],
    [ "QUERY_ATTRIBUTE_RESOLVER", "a00353.html#ae17c23ff97a9da6c5d1ceda8f3be58df", null ],
    [ "SIMPLEAGGREGATION_ATTRIBUTE_RESOLVER", "a00353.html#a9c3ed3cac3af1ac43e883afe7c020bfe", null ],
    [ "registerAttributeResolvers", "a00353.html#ae3ea6ac5b6699824dbd634dbf88ceb02", null ]
];