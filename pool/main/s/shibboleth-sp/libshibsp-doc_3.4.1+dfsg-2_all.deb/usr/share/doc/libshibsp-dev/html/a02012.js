var a02012 =
[
    [ "FilterPolicyContext", "a02012.html#a718e804e8ec65ddf65379221d0dc404f", null ],
    [ "getMatchFunctors", "a02012.html#abd6ccf85563dd028180f556fcbf2eab5", null ]
];