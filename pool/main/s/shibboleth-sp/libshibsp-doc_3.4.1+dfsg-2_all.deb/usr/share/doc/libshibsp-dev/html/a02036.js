var a02036 =
[
    [ "getResolvedAssertions", "a02036.html#a36a51df33738724d1e3152154e45ec10", null ],
    [ "getResolvedAttributes", "a02036.html#acc68db0ca202edb69a3af31bbe95c88e", null ]
];