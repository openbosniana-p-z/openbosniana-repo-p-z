var a01996 =
[
    [ "ExtensibleAttribute", "a01996.html#a004ccb19129ab8c19f6fb9461f63d16c", null ],
    [ "ExtensibleAttribute", "a01996.html#a91ce09348262daa7c67645b3faabc65f", null ],
    [ "clearSerializedValues", "a01996.html#add2e2fcb164bc3fbe45e77a85a9f91fd", null ],
    [ "getScope", "a01996.html#ac4a9c0b86e3fceca46bb227fc83979b3", null ],
    [ "getSerializedValues", "a01996.html#ad64c24d3c03d505dbec15e8a557fb760", null ],
    [ "getString", "a01996.html#a8ef87616bd1ac71dfc98294563416198", null ],
    [ "getValues", "a01996.html#a85f1cf38eeacec07e9e2ab3238668ec7", null ],
    [ "marshall", "a01996.html#af45dfb9fd7cc49625b36062fa19148ef", null ],
    [ "removeValue", "a01996.html#abf4a72aa88f801ac5cb84d08b2ef250b", null ],
    [ "valueCount", "a01996.html#a0c3b45d3f3fc1419e5bb145555e03039", null ]
];