var a02076 =
[
    [ "getEventType", "a02076.html#ac7d2a6c0a8abd1280d1aa0f38e08000e", null ],
    [ "newLogoutEvent", "a02076.html#a2c7334b78d9068c8e573a7050d91bee7", null ],
    [ "notifyBackChannel", "a02076.html#a2f2043ac917e7e691cc1e569ce3e5d78", null ],
    [ "notifyFrontChannel", "a02076.html#ae0a10d798f6146af6400bedb59c818f6", null ],
    [ "receive", "a02076.html#a0a2eac36542439915f30e9e9bd6dcd62", null ],
    [ "run", "a02076.html#a1cea1a2ba3f4fbb0acb1adf8494205f6", null ],
    [ "sendLogoutPage", "a02076.html#a1306eaa63c9a80310807649f9c2e3916", null ],
    [ "m_initiator", "a02076.html#a29e69cee5e1b9537b07c6e487edad6d8", null ],
    [ "m_preserve", "a02076.html#a715933363d3d80c0adb2e829f7111329", null ]
];