var a01976 =
[
    [ "aclresult_t", "a01976.html#a0b354b88652a5f5650077fe9c1c36866", [
      [ "shib_acl_true", "a01976.html#a0b354b88652a5f5650077fe9c1c36866a004db5767e9b5eef00920f1cd9072651", null ],
      [ "shib_acl_false", "a01976.html#a0b354b88652a5f5650077fe9c1c36866a8f6fddc5d9911bb7b9d99447d189cce5", null ],
      [ "shib_acl_indeterminate", "a01976.html#a0b354b88652a5f5650077fe9c1c36866abb0118aabf09afc80925bb5d0fd49624", null ]
    ] ],
    [ "authorized", "a01976.html#a262c255771da79e36d72baa038252212", null ]
];