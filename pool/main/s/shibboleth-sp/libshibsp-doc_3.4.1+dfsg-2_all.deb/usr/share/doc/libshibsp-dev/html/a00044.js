var a00044 =
[
    [ "SHIBSP_CACHEDIR", "a00044.html#a3d07a09cd7363aea99cf5c009a0159cb", null ],
    [ "SHIBSP_CFGDIR", "a00044.html#ae04ffbe95f26d2634e93daf7ada99832", null ],
    [ "SHIBSP_LIBDIR", "a00044.html#a7cbb8172a01fcc7032e201b797287a99", null ],
    [ "SHIBSP_LOGDIR", "a00044.html#abf125af32bc7f5fb8fb0ccae2acd0810", null ],
    [ "SHIBSP_PREFIX", "a00044.html#a60656cb4c7c0e52ef02c19197c4abd19", null ],
    [ "SHIBSP_RUNDIR", "a00044.html#ac5dd1bb5e3e58d5dff76d8762f4ffc5e", null ],
    [ "SHIBSP_SCHEMAS", "a00044.html#a6bdfcca501c35591e5ffa156d96e0c89", null ],
    [ "SHIBSP_XMLDIR", "a00044.html#a635416f56e8e31dfb35d74f3be3236c3", null ]
];