var a02020 =
[
    [ "Value", "a02024.html", null ],
    [ "NameIDAttribute", "a02020.html#ac32323678d9f9c4c59edaffbe48b4a21", null ],
    [ "NameIDAttribute", "a02020.html#a1fef2b0afd608dae92ce9a1762fdd7e1", null ],
    [ "clearSerializedValues", "a02020.html#a17e51774af040f02040e1b2b72a2bb1c", null ],
    [ "getScope", "a02020.html#a5722bc00696730b51960f718f0230bdf", null ],
    [ "getSerializedValues", "a02020.html#ac096537b6ab7944d0f8d64a72532ef81", null ],
    [ "getString", "a02020.html#a164eb064e6088745ad413ef623c2c800", null ],
    [ "getValues", "a02020.html#a872d10ee12d133656b34ccc093314e68", null ],
    [ "getValues", "a02020.html#a3081c9cfbc99ff6373fe817744996efb", null ],
    [ "marshall", "a02020.html#a84bd15f97c00d90fffb349424d5a77a1", null ],
    [ "removeValue", "a02020.html#af7811befe029a157f039223471eebe7e", null ],
    [ "valueCount", "a02020.html#a3549df9c1d38e4d43e8de12fa11d2335", null ]
];