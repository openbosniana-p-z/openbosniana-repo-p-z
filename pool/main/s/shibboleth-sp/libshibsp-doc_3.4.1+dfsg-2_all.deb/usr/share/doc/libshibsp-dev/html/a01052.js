var a01052 =
[
    [ "shibsp::LogoutInitiator", "a02080.html", "a02080" ],
    [ "ADMIN_LOGOUT_INITIATOR", "a01052.html#a407631d04fa644082209a6ca4199c55f", null ],
    [ "CHAINING_LOGOUT_INITIATOR", "a01052.html#a8d0425e67cfc8dbd02530d0e08af9e44", null ],
    [ "LOCAL_LOGOUT_INITIATOR", "a01052.html#afb7a29c50bdc16341f1d97841af5d4ae", null ],
    [ "SAML2_LOGOUT_INITIATOR", "a01052.html#a9f9ec65c539acff74f2eff340130008f", null ],
    [ "registerLogoutInitiators", "a01052.html#a63ea0d068b12205b2e218e21f6a08869", null ]
];