var a00128 =
[
    [ "shibsp::ProtocolProvider", "a02056.html", "a02056" ],
    [ "XML_PROTOCOL_PROVIDER", "a00128.html#a104abcb19fbbea0b242acaf7c59d93b0", null ],
    [ "registerProtocolProviders", "a00128.html#ac881ebf7c131f012e9f7a5c6d72e6dff", null ]
];