var a02016 =
[
    [ "evaluatePermitValue", "a02016.html#ad60cf30bfdc21e3fa92ba509e0b89ad4", null ],
    [ "evaluatePolicyRequirement", "a02016.html#acb1dc73dfff9c91883622d62af37b4d6", null ]
];