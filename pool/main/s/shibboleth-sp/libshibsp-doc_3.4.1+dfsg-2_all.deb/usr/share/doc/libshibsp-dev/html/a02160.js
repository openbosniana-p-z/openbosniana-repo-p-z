var a02160 =
[
    [ "addAssertion", "a02160.html#a294cae41918eca72182fe3abc27afdf5", null ],
    [ "addAttributes", "a02160.html#ac6ba366a58ed903a99a7b556afbeaf67", null ],
    [ "getApplicationID", "a02160.html#a0c4969dfd8f0b34b998f333f075ad261", null ],
    [ "getAssertion", "a02160.html#a4819eebba7c48331b92afba2d3b8bd77", null ],
    [ "getAssertionIDs", "a02160.html#a19e7eb29a726de14620c841ba4b14dd9", null ],
    [ "getAttributes", "a02160.html#a08b2ecef7f0ec66d23ba1fb3cb8fb946", null ],
    [ "getAuthnContextClassRef", "a02160.html#a7ee8e6fc9eb0f5eb114cb1b9364bd0fd", null ],
    [ "getAuthnContextDeclRef", "a02160.html#a2ed80035e8a55dc300dc010e037cc6b8", null ],
    [ "getAuthnInstant", "a02160.html#ade8229400162484df12d9cdab786d7d5", null ],
    [ "getClientAddress", "a02160.html#a6113d586c3b2cbcd5b9d0ef0dfc6fccc", null ],
    [ "getEntityID", "a02160.html#ae28461af8d9ee0ade04272b95c80bf28", null ],
    [ "getExpiration", "a02160.html#aaa57f353290b5f817f22157351751c30", null ],
    [ "getID", "a02160.html#a57d4eaa6c4e0d1cc83a3ae6cbe717cec", null ],
    [ "getIndexedAttributes", "a02160.html#a27fed34a7bad27e3ddce9773349aeedc", null ],
    [ "getLastAccess", "a02160.html#ac86753a8065074afbace8cb00497f306", null ],
    [ "getNameID", "a02160.html#a72d20b82f7780027f68111a084fd4c72", null ],
    [ "getProtocol", "a02160.html#a847e2dc51a421edca5923e8c2ac05330", null ],
    [ "getSessionIndex", "a02160.html#a0cb314738735c321b381caa3331e4c37", null ]
];