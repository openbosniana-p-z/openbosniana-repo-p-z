var a02056 =
[
    [ "getBindings", "a02056.html#a87e7d9bd1b5bb5ecd2c756cf0a7bc242", null ],
    [ "getInitiator", "a02056.html#aee970e62a282288276fd0971e3781ab0", null ]
];