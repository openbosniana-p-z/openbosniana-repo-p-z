var a02084 =
[
    [ "addRemotedHeader", "a02084.html#a7b44e9c00f515a8b5a8f05a0e19acbdb", null ],
    [ "getRequest", "a02084.html#a4400ebe3b119be2cadb760d1c0c530a0", null ],
    [ "getRequest", "a02084.html#aa8d38226278af925cf8d3f938fb8a972", null ],
    [ "getResponse", "a02084.html#ad3ae4399a11045d137b21205e59671e3", null ],
    [ "getResponse", "a02084.html#aeacc973be63a9e49054f2715e0bcfe22", null ],
    [ "send", "a02084.html#a7dabdbc0b0e7875357cd95516ee1a995", null ],
    [ "setAddress", "a02084.html#aac18948efb6e972cb66b0e760a43f0ad", null ],
    [ "unwrap", "a02084.html#a2219f6ec7049a681e94f5efda95a3f66", null ],
    [ "wrap", "a02084.html#a718671b7916ab72cae42d9e18e6a0330", null ],
    [ "m_address", "a02084.html#a6ca6ec117a8ca16e06500a4929197d18", null ]
];