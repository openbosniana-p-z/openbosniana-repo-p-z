var a02184 =
[
    [ "LoginEvent", "a02184.html#a4637a3ca31f83a8736e1357aa182a2d7", null ],
    [ "getType", "a02184.html#ae719bb69f65d527cb86a0ffda61c1367", null ],
    [ "m_attributes", "a02184.html#a8117e3fe766b6caa2db73ebf34a2f2dc", null ],
    [ "m_saml1AuthnStatement", "a02184.html#a1de95e2d987f29c64fd3c5a5c7c31cee", null ],
    [ "m_saml1Response", "a02184.html#ae341cae051a1646631e9cd14ba00c065", null ],
    [ "m_saml2AuthnStatement", "a02184.html#a274287cefd709042e74d523832075b26", null ],
    [ "m_saml2Response", "a02184.html#ada06bd10a659b85c2fdc35fa97effde8", null ]
];