var a02172 =
[
    [ "SPLogLevel", "a02172.html#a20701bedd21eab2b73de90cb364535a1", [
      [ "SPDebug", "a02172.html#a20701bedd21eab2b73de90cb364535a1a8b6b86de88f88d57643da73278509ca2", null ],
      [ "SPInfo", "a02172.html#a20701bedd21eab2b73de90cb364535a1ac8db0518710f3315b98595cbe4f95b66", null ],
      [ "SPWarn", "a02172.html#a20701bedd21eab2b73de90cb364535a1a754fcb8e12664a0e85ecd1c14c5630e5", null ],
      [ "SPError", "a02172.html#a20701bedd21eab2b73de90cb364535a1a7a50a514a2d4ae2f2896fee6f0ddfa1f", null ],
      [ "SPCrit", "a02172.html#a20701bedd21eab2b73de90cb364535a1a75fa0137c31f598888b380ee3e9ab8a3", null ]
    ] ],
    [ "clearHeader", "a02172.html#af6dca39e5a9635362aead3fcc60077f6", null ],
    [ "getApplication", "a02172.html#a4bbd6a498b1ef721ae1c1d39a824ce09", null ],
    [ "getHandlerURL", "a02172.html#aa1a61e02edbf2ef59dc629b1e771ad24", null ],
    [ "getRequestSettings", "a02172.html#ab814d8c4e495c9a9f9ad98434e29e1b3", null ],
    [ "getSecureHeader", "a02172.html#a54940acd5472e3bb585382318ada3baa", null ],
    [ "getServiceProvider", "a02172.html#a94ad8546eb077a4a9b58e79d7c563b4d", null ],
    [ "getSession", "a02172.html#a356784d4149c18e87b23b2763eeb2e92", null ],
    [ "isPriorityEnabled", "a02172.html#a8f50e591565e6496031b0d3abfd82cc0", null ],
    [ "log", "a02172.html#a53e8bf6488851cc66eb7569f96cc39bb", null ],
    [ "returnDecline", "a02172.html#a7c033388f13a7ef5a57f7ec097aaeb5f", null ],
    [ "returnOK", "a02172.html#a89800e3d565a0088d07eb2ca2c2566b3", null ],
    [ "setAuthType", "a02172.html#a59d809a67feccbc936e75038b74feb5e", null ],
    [ "setHeader", "a02172.html#aceffe1f8e737ba0c7ccd1381f3b14da7", null ],
    [ "setRemoteUser", "a02172.html#aefc284f8c8644b7581ab735608d406d8", null ]
];