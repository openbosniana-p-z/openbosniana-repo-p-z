var a00761 =
[
    [ "shibsp::SessionInitiator", "a02092.html", "a02092" ],
    [ "CHAINING_SESSION_INITIATOR", "a00761.html#adeaaa287ac8dc693ffef23589150d74b", null ],
    [ "COOKIE_SESSION_INITIATOR", "a00761.html#a6c59597f7ac4ae5872c1745b41f63c2b", null ],
    [ "FORM_SESSION_INITIATOR", "a00761.html#a83639994467d802afb5dfa11ab6790fb", null ],
    [ "SAML2_SESSION_INITIATOR", "a00761.html#a8be14e5c6454a5f4c59c07b3a6e71206", null ],
    [ "SAMLDS_SESSION_INITIATOR", "a00761.html#aaaf3090a81b63d4354f6a22b4b7015b1", null ],
    [ "SHIB1_SESSION_INITIATOR", "a00761.html#a377b64ca94c5924ab095d64a3daf0883", null ],
    [ "TRANSFORM_SESSION_INITIATOR", "a00761.html#a9e66b87632a8fb779ac3d1c00a87d6fb", null ],
    [ "WAYF_SESSION_INITIATOR", "a00761.html#a42c38964e67d783b474bee36ed1a05fe", null ],
    [ "registerSessionInitiators", "a00761.html#a9fa087eb1a36e489433fb29826c930bf", null ]
];