var a02044 =
[
    [ "SimpleAttribute", "a02044.html#a7df8ed89d33cdd9df020013f9626d2b3", null ],
    [ "SimpleAttribute", "a02044.html#a60aa564b690362d6743579d2c9ff7095", null ],
    [ "clearSerializedValues", "a02044.html#a2b049ea93e0971f2cdff0e2fe3780cbb", null ],
    [ "getValues", "a02044.html#a5c171be17e4f78ef09bd9df71d5d5857", null ],
    [ "marshall", "a02044.html#a931789b76d7cf8a23db8293a1edc1606", null ]
];