// $Id: EODelegateResponse.h 1 2004-08-20 10:38:46Z znek $

typedef enum { 
    EODelegateRejects, 
    EODelegateApproves, 
    EODelegateOverrides
} EODelegateResponse;
