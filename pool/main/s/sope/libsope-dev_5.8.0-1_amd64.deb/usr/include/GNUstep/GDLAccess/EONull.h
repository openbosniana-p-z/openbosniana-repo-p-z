// $Id: EONull.h 1 2004-08-20 10:38:46Z znek $

#ifndef __eoaccess_EONull_H__
#define __eoaccess_EONull_H__

#import <EOControl/EONull.h>

#endif /* __eoaccess_EONull_H__ */
