// $If$

#ifndef __EOAdaptorOperation_H__
#define __EOAdaptorOperation_H__

#import <Foundation/NSObject.h>

@interface EOAdaptorOperation : NSObject
@end

#endif /* __EOAdaptorOperation_H__ */
