struct s {
  unsigned long long u;
  long long s;
};

extern struct s s;

extern void ps (void);

extern void pll (int, long long, int);

extern
long long a (int, long long, int, long long, int, long long, int, long long);
