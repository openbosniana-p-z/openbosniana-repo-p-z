extern double sqrt (double);
extern double sin (double);
extern double cos (double);
extern double tan (double);
extern double asin (double);
extern double acos (double);
extern double atan (double);
extern double atan2 (double, double);
extern double exp (double);
extern double pow (double, double);
extern double log (double);
extern double log10 (double);
extern double sinh (double);
extern double cosh (double);
extern double tanh (double);

