typedef void mvoid;

mvoid *x;
