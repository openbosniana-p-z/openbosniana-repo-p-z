var group__API__Task__Lists_structstarpu__task__list =
[
    [ "head", "group__API__Task__Lists.html#af66edbac990d8e894796ca5d5dd45138", null ],
    [ "tail", "group__API__Task__Lists.html#ad80731caf9d45900687caa7d5cc17cae", null ]
];