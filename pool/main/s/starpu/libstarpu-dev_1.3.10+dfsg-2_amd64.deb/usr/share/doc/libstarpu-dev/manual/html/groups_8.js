var searchData=
[
  ['parallel_20tasks_0',['Parallel Tasks',['../group__API__Parallel__Tasks.html',1,'']]],
  ['performance_20model_1',['Performance Model',['../group__API__Performance__Model.html',1,'']]],
  ['profiling_2',['Profiling',['../group__API__Profiling.html',1,'']]]
];
