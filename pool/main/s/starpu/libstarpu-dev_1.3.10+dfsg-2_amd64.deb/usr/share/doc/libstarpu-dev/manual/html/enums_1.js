var searchData=
[
  ['starpu_5fcluster_5ftypes_0',['starpu_cluster_types',['../group__API__Clustering__Machine.html#ga63c001ace567446514f1616e34af1bf6',1,'starpu_clusters.h']]],
  ['starpu_5fcodelet_5ftype_1',['starpu_codelet_type',['../group__API__Codelet__And__Tasks.html#gac127ad106bf376da993d3f4caa979b2f',1,'starpu_task.h']]],
  ['starpu_5fdata_5faccess_5fmode_2',['starpu_data_access_mode',['../group__API__Data__Management.html#ga1fb3a1ff8622747d653d1b5f41bc41db',1,'starpu_data.h']]],
  ['starpu_5fdata_5finterface_5fid_3',['starpu_data_interface_id',['../group__API__Data__Interfaces.html#gaa2f2140147f15e7b9eec1443690e357c',1,'starpu_data_interfaces.h']]],
  ['starpu_5fnode_5fkind_4',['starpu_node_kind',['../group__API__Workers__Properties.html#ga6f3fbb6e918d0135ccb68473a8ee5ca1',1,'starpu_worker.h']]],
  ['starpu_5fomp_5fproc_5fbind_5fvalue_5',['starpu_omp_proc_bind_value',['../group__API__OpenMP__Runtime__Support.html#gacc6078a78820c367f07d37da11c04520',1,'starpu_openmp.h']]],
  ['starpu_5fomp_5fsched_5fvalue_6',['starpu_omp_sched_value',['../group__API__OpenMP__Runtime__Support.html#ga33af06875785da29f3988d3a985e99f8',1,'starpu_openmp.h']]],
  ['starpu_5fperfmodel_5ftype_7',['starpu_perfmodel_type',['../group__API__Performance__Model.html#gae161a7cae376f3fc831a2b764e8144e6',1,'starpu_perfmodel.h']]],
  ['starpu_5fsched_5fcomponent_5fproperties_8',['starpu_sched_component_properties',['../group__API__Modularized__Scheduler.html#gab40975877d0c861348ccc96602be2cae',1,'starpu_sched_component.h']]],
  ['starpu_5ftask_5fstatus_9',['starpu_task_status',['../group__API__Codelet__And__Tasks.html#ga0088c4ab87a08b3e7a375c1a79e91202',1,'starpu_task.h']]],
  ['starpu_5fworker_5farchtype_10',['starpu_worker_archtype',['../group__API__Workers__Properties.html#ga173d616aefe98c33a47a847fd2fca37d',1,'starpu_worker.h']]],
  ['starpu_5fworker_5fcollection_5ftype_11',['starpu_worker_collection_type',['../group__API__Workers__Properties.html#ga80b06886ee8a4c0e99b09ab638113af3',1,'starpu_worker.h']]]
];
