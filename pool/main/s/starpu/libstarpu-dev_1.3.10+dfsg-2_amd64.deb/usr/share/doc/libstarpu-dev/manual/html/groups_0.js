var searchData=
[
  ['bitmap_0',['Bitmap',['../group__API__Bitmap.html',1,'']]]
];
