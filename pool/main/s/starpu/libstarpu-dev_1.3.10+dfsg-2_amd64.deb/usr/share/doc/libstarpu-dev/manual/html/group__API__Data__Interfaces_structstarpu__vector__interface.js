var group__API__Data__Interfaces_structstarpu__vector__interface =
[
    [ "id", "group__API__Data__Interfaces.html#abf4cecec3e8bcec447ec51416b8ac3d2", null ],
    [ "ptr", "group__API__Data__Interfaces.html#a763e990c19520a68ebde783297107a2b", null ],
    [ "dev_handle", "group__API__Data__Interfaces.html#a4e3533d0af8b68987b86432ce6e37a50", null ],
    [ "offset", "group__API__Data__Interfaces.html#ab02b430abde33905606cadd02374fb59", null ],
    [ "nx", "group__API__Data__Interfaces.html#ad9ae80b9516186ddfd6ee34b74c85674", null ],
    [ "elemsize", "group__API__Data__Interfaces.html#a9ea66093fee786a725d8681e11c13c33", null ],
    [ "slice_base", "group__API__Data__Interfaces.html#a90c8cddece28b8576636e6ae4953a30f", null ],
    [ "allocsize", "group__API__Data__Interfaces.html#abccb7b1d3e85a19d010bec0e2202284f", null ]
];