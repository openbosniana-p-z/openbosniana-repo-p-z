var group__API__Explicit__Dependencies =
[
    [ "starpu_tag_t", "group__API__Explicit__Dependencies.html#gac350ef8b876d63fb8885377f789853d2", null ],
    [ "starpu_task_declare_deps_array", "group__API__Explicit__Dependencies.html#gada6692ca393aa820bc105252ca19830f", null ],
    [ "starpu_task_declare_deps", "group__API__Explicit__Dependencies.html#gaccd7b337e14269be734af274fb11c1a4", null ],
    [ "starpu_task_declare_end_deps_array", "group__API__Explicit__Dependencies.html#ga2ab771900cf19e039ade46594dbc5fce", null ],
    [ "starpu_task_declare_end_deps", "group__API__Explicit__Dependencies.html#ga19e120568fbd21fcac59b93ff324c45f", null ],
    [ "starpu_task_get_task_succs", "group__API__Explicit__Dependencies.html#ga53dc7bff09b441ee6a200cae99ca2cb8", null ],
    [ "starpu_task_get_task_scheduled_succs", "group__API__Explicit__Dependencies.html#gae33176debf369b29f12e2e390f2d67e1", null ],
    [ "starpu_task_end_dep_add", "group__API__Explicit__Dependencies.html#gabaef95d742d03c96453905602e511050", null ],
    [ "starpu_task_end_dep_release", "group__API__Explicit__Dependencies.html#ga1a93d3d46ea5ade29a3a3ea76b6eb90d", null ],
    [ "starpu_tag_declare_deps", "group__API__Explicit__Dependencies.html#ga863d71b775ec517493f81e731a64d134", null ],
    [ "starpu_tag_declare_deps_array", "group__API__Explicit__Dependencies.html#gab5c86743355724ee2f9596de1ae221df", null ],
    [ "starpu_tag_wait", "group__API__Explicit__Dependencies.html#gaf5090c3c45414d693445e79ab7842992", null ],
    [ "starpu_tag_wait_array", "group__API__Explicit__Dependencies.html#gaf5cf68c72a863a6ab0ef8737c92b57ba", null ],
    [ "starpu_tag_restart", "group__API__Explicit__Dependencies.html#gaef0b7cee7536d4a5de1b10888ab13add", null ],
    [ "starpu_tag_remove", "group__API__Explicit__Dependencies.html#gadbed48d64331463d4f9a9090933e5b9f", null ],
    [ "starpu_tag_notify_from_apps", "group__API__Explicit__Dependencies.html#gabdb8d20fca507a93450fe775233dd20c", null ],
    [ "starpu_tag_notify_restart_from_apps", "group__API__Explicit__Dependencies.html#gab0761a67174503b61aa8d0e0ee1c9212", null ]
];