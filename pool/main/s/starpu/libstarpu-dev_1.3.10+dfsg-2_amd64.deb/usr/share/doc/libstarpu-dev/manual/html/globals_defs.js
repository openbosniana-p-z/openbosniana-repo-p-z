var globals_defs =
[
    [ "h", "globals_defs.html", null ],
    [ "s", "globals_defs_s.html", null ]
];