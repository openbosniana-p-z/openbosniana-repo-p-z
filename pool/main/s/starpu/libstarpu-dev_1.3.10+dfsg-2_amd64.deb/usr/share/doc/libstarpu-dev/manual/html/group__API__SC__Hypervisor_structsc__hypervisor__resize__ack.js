var group__API__SC__Hypervisor_structsc__hypervisor__resize__ack =
[
    [ "receiver_sched_ctx", "group__API__SC__Hypervisor.html#acc8469538b2b9242e312fea26e13294c", null ],
    [ "moved_workers", "group__API__SC__Hypervisor.html#a9aba37893ddb344de680aa901f686f2d", null ],
    [ "nmoved_workers", "group__API__SC__Hypervisor.html#ac6da5b817008cd1002fac2412ee1ccde", null ],
    [ "acked_workers", "group__API__SC__Hypervisor.html#a829c79920efa453ee18491e8a85c1ff6", null ]
];