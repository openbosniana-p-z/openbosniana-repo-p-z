var group__API__Toolbox =
[
    [ "STARPU_GNUC_PREREQ", "group__API__Toolbox.html#ga4fc771a29d7dc0e826da42777edbcf15", null ],
    [ "STARPU_UNLIKELY", "group__API__Toolbox.html#ga23742c6fca8b5386e1f3e3f7bbf3a692", null ],
    [ "STARPU_LIKELY", "group__API__Toolbox.html#ga4456c2db2cc8df7c98d62ecc21b2bd1d", null ],
    [ "STARPU_ATTRIBUTE_UNUSED", "group__API__Toolbox.html#ga9e7c20a6cdce868976a0046206b104e6", null ],
    [ "STARPU_ATTRIBUTE_NORETURN", "group__API__Toolbox.html#ga230129f89ca986b143c6b059a9229fb7", null ],
    [ "STARPU_ATTRIBUTE_INTERNAL", "group__API__Toolbox.html#ga903e600059ba1735d5d6bd688dc0cc7e", null ],
    [ "STARPU_ATTRIBUTE_MALLOC", "group__API__Toolbox.html#ga214c60ee1b6cbc27ab08ba6f339ef8e5", null ],
    [ "STARPU_ATTRIBUTE_WARN_UNUSED_RESULT", "group__API__Toolbox.html#ga71e28fc2a0a5267bc7edc0909d9d5117", null ],
    [ "STARPU_ATTRIBUTE_PURE", "group__API__Toolbox.html#ga057b12b615ce9e8a1fe7b5e10d9a5c2e", null ],
    [ "STARPU_ATTRIBUTE_ALIGNED", "group__API__Toolbox.html#gae8c513ecd1a5bd87a7bdd71260c49ffc", null ],
    [ "STARPU_ASSERT", "group__API__Toolbox.html#ga05ac0dda104331f57d85823a4f9318ce", null ],
    [ "STARPU_ASSERT_MSG", "group__API__Toolbox.html#gabb6941113e19ee4045a014943cd62aae", null ],
    [ "STARPU_ABORT", "group__API__Toolbox.html#ga3a4d1fb56668323d4f44c18f6a6dfb3f", null ],
    [ "STARPU_ABORT_MSG", "group__API__Toolbox.html#ga4268950ebf63c0f1dabcfd0cd8808067", null ],
    [ "STARPU_CHECK_RETURN_VALUE", "group__API__Toolbox.html#gaa3503ea5efd00806a0f9234f033e6ea1", null ],
    [ "STARPU_CHECK_RETURN_VALUE_IS", "group__API__Toolbox.html#ga1b41d799a04a1d6483e982ffb2f74432", null ],
    [ "STARPU_RMB", "group__API__Toolbox.html#gaa5363993d4f519517316ccf9dc47a7bb", null ],
    [ "STARPU_WMB", "group__API__Toolbox.html#ga07b2628bd6680fe49d92c7f816d7ce53", null ]
];