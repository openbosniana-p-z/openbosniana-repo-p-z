var group__API__Task__Lists =
[
    [ "starpu_task_list", "group__API__Task__Lists.html#structstarpu__task__list", [
      [ "head", "group__API__Task__Lists.html#af66edbac990d8e894796ca5d5dd45138", null ],
      [ "tail", "group__API__Task__Lists.html#ad80731caf9d45900687caa7d5cc17cae", null ]
    ] ],
    [ "starpu_task_list_init", "group__API__Task__Lists.html#ga5618612b0ce2f914ab9032474ddf072f", null ],
    [ "starpu_task_list_push_front", "group__API__Task__Lists.html#gabf5bb8daf00f9902ea501009720af19d", null ],
    [ "starpu_task_list_push_back", "group__API__Task__Lists.html#gae29a8aae4e82286c80656a7afdc7a106", null ],
    [ "starpu_task_list_front", "group__API__Task__Lists.html#ga78d4f98e2d6f2f73d453c86ca8ca9e95", null ],
    [ "starpu_task_list_back", "group__API__Task__Lists.html#ga56ae6bd10619777a164ace85197034c4", null ],
    [ "starpu_task_list_empty", "group__API__Task__Lists.html#gadbb9076de7513b41c19813e16a3c0773", null ],
    [ "starpu_task_list_erase", "group__API__Task__Lists.html#gaedf8ff832aea57abbb8ab94304a85c13", null ],
    [ "starpu_task_list_pop_front", "group__API__Task__Lists.html#gad0e3e0684ea77c786b7c5b83894b5e5d", null ],
    [ "starpu_task_list_pop_back", "group__API__Task__Lists.html#gad88622cd18759da0a9b30ca75c11e22b", null ],
    [ "starpu_task_list_begin", "group__API__Task__Lists.html#ga367d90424e132d762e9a11eac2a822af", null ],
    [ "starpu_task_list_end", "group__API__Task__Lists.html#ga37f7421eb2dcf9d808220db8454f0fac", null ],
    [ "starpu_task_list_next", "group__API__Task__Lists.html#ga02a847856d87dc7027c6f57e22a9e481", null ],
    [ "starpu_task_list_ismember", "group__API__Task__Lists.html#ga1a9fbeedd7b9b0f77a18a8754a1bdeab", null ]
];