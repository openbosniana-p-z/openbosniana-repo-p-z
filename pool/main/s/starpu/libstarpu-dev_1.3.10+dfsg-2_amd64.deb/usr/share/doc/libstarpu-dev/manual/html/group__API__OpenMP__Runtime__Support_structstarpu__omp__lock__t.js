var group__API__OpenMP__Runtime__Support_structstarpu__omp__lock__t =
[
    [ "internal", "group__API__OpenMP__Runtime__Support.html#acfc22eabce32bfa73fd5020f275c3cf2", null ]
];