var searchData=
[
  ['workers’_20properties_0',['Workers’ Properties',['../group__API__Workers__Properties.html',1,'']]]
];
