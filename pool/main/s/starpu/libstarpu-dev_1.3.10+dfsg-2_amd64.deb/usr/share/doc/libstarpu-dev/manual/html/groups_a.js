var searchData=
[
  ['scheduling_20context_20hypervisor_20_2d_20building_20a_20new_20resizing_20policy_0',['Scheduling Context Hypervisor - Building a new resizing policy',['../group__API__SC__Hypervisor.html',1,'']]],
  ['scheduling_20context_20hypervisor_20_2d_20linear_20programming_1',['Scheduling Context Hypervisor - Linear Programming',['../group__API__SC__Hypervisor__LP.html',1,'']]],
  ['scheduling_20context_20hypervisor_20_2d_20regular_20usage_2',['Scheduling Context Hypervisor - Regular usage',['../group__API__SC__Hypervisor__usage.html',1,'']]],
  ['scheduling_20contexts_3',['Scheduling Contexts',['../group__API__Scheduling__Contexts.html',1,'']]],
  ['scheduling_20policy_4',['Scheduling Policy',['../group__API__Scheduling__Policy.html',1,'']]],
  ['sink_5',['Sink',['../group__API__Sink.html',1,'']]],
  ['standard_20memory_20library_6',['Standard Memory Library',['../group__API__Standard__Memory__Library.html',1,'']]]
];
