var group__API__Workers__Properties_structstarpu__worker__collection =
[
    [ "workerids", "group__API__Workers__Properties.html#a0d213fc6e036df7424e05c30bfca22c4", null ],
    [ "nworkers", "group__API__Workers__Properties.html#a10961e3af7749f812b744dbd9f85da96", null ],
    [ "type", "group__API__Workers__Properties.html#acbe5dc434c779fec539a427b8e8ab1aa", null ],
    [ "has_next", "group__API__Workers__Properties.html#a6595f14b6715e60d2444f4cd09b9d73f", null ],
    [ "get_next", "group__API__Workers__Properties.html#ab92e3de048f56a4c2f59fa804594c339", null ],
    [ "add", "group__API__Workers__Properties.html#ae039a760cdd80c0d91bcc4c4da9ebb74", null ],
    [ "remove", "group__API__Workers__Properties.html#a1782f997e873faa64de39cf4bd570661", null ],
    [ "init", "group__API__Workers__Properties.html#adf52d25f085ea1f6fe2b982b3439b73f", null ],
    [ "deinit", "group__API__Workers__Properties.html#a26ad74518560f75a4cd9e1ee0cb2eb7c", null ],
    [ "init_iterator", "group__API__Workers__Properties.html#ae260b3aeb9f58a98d7adb70eea8b851c", null ]
];