var group__API__Workers__Properties_structstarpu__sched__ctx__iterator =
[
    [ "cursor", "group__API__Workers__Properties.html#a3460c754c642b2244d4c2ceb98101ece", null ]
];