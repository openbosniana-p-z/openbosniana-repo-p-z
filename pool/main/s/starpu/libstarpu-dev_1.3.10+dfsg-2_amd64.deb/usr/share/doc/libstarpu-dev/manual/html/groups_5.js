var searchData=
[
  ['initialization_20and_20termination_0',['Initialization and Termination',['../group__API__Initialization__and__Termination.html',1,'']]],
  ['interoperability_20support_1',['Interoperability Support',['../group__API__Interop__Support.html',1,'']]]
];
