var group__API__Data__Partition_structstarpu__data__filter =
[
    [ "filter_func", "group__API__Data__Partition.html#a0794c07d3fbfab35b6889760699c7b91", null ],
    [ "nchildren", "group__API__Data__Partition.html#aec46586c98b5631201151b7582724e12", null ],
    [ "get_nchildren", "group__API__Data__Partition.html#aca2a185107bc8d8adc11557248cf454b", null ],
    [ "get_child_ops", "group__API__Data__Partition.html#a6cb433cf6efd383c6739099dccb3c2b0", null ],
    [ "filter_arg", "group__API__Data__Partition.html#a6cb631e64e61f862647040852fdabe49", null ],
    [ "filter_arg_ptr", "group__API__Data__Partition.html#a1ef5f824cca130aa51505b0551eca51c", null ]
];