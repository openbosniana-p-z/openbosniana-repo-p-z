var searchData=
[
  ['b_0',['b',['../group__API__Performance__Model.html#af5497d7f073aa115e25d6d1a32c2e668',1,'starpu_perfmodel_regression_model']]],
  ['bandwidth_1',['bandwidth',['../group__API__Out__Of__Core.html#a728c7a6e4c919a72300ac8f8a3bae0b2',1,'starpu_disk_ops']]],
  ['basic_20examples_2',['Basic Examples',['../BasicExamples.html',1,'']]],
  ['beta_3',['beta',['../group__API__Performance__Model.html#aa69cc173b9ebdbf129eb1b30ca64ddd9',1,'starpu_perfmodel_regression_model']]],
  ['bitmap_4',['Bitmap',['../group__API__Bitmap.html',1,'']]],
  ['building_20and_20installing_20starpu_5',['Building and Installing StarPU',['../BuildingAndInstallingStarPU.html',1,'']]],
  ['bundle_6',['bundle',['../group__API__Codelet__And__Tasks.html#a00b8193077f6e6cd5f40de671a9d776b',1,'starpu_task']]],
  ['bus_5fcalibrate_7',['bus_calibrate',['../group__API__Initialization__and__Termination.html#a7296fd188dcf3c5cc42f2be1cfab8fe2',1,'starpu_conf']]]
];
