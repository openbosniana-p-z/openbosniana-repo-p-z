var group__API__Scheduling__Policy_structstarpu__sched__policy =
[
    [ "init_sched", "group__API__Scheduling__Policy.html#ace93b3c465e39c7e2ca894406905dc2a", null ],
    [ "deinit_sched", "group__API__Scheduling__Policy.html#a70b01dc541e85aba64f46a4b69b68eed", null ],
    [ "push_task", "group__API__Scheduling__Policy.html#a73c1677d2c6af4d4aa44f6f92de8bcdd", null ],
    [ "push_task_notify", "group__API__Scheduling__Policy.html#a126aefb44f8c9927e8c46007c29aa92d", null ],
    [ "pop_task", "group__API__Scheduling__Policy.html#a84231c0bc118e91e49b0614c24b9de4a", null ],
    [ "pop_every_task", "group__API__Scheduling__Policy.html#a2c5acd3b932929d778ff55153cb0ad9b", null ],
    [ "submit_hook", "group__API__Scheduling__Policy.html#a1b1eade0d51badd5c9a2faaa49345b3e", null ],
    [ "pre_exec_hook", "group__API__Scheduling__Policy.html#a741b2c45076cb62ca6f024b63432f232", null ],
    [ "post_exec_hook", "group__API__Scheduling__Policy.html#afd00e4e0a058e043c3d8edf916ace4f7", null ],
    [ "do_schedule", "group__API__Scheduling__Policy.html#ad720f2cd2155e8baa10f57792b68a5eb", null ],
    [ "add_workers", "group__API__Scheduling__Policy.html#a44e18efefc5e383997cc5684e014bd82", null ],
    [ "remove_workers", "group__API__Scheduling__Policy.html#a9020a364719389cd19c31a657c938293", null ],
    [ "policy_name", "group__API__Scheduling__Policy.html#a81af53e5f8e59cb12d6d0b378c4b5268", null ],
    [ "policy_description", "group__API__Scheduling__Policy.html#a3a9fac9431150cc6931f572969ba848e", null ]
];