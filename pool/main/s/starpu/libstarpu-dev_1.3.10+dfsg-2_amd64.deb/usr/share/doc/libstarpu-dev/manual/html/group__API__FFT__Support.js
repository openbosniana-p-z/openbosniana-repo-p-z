var group__API__FFT__Support =
[
    [ "starpufft_malloc", "group__API__FFT__Support.html#gabf7989748571ab9155a865a19002d1fa", null ],
    [ "starpufft_free", "group__API__FFT__Support.html#ga6809e3bc78ad0d7f9df41e99ddada069", null ],
    [ "starpufft_plan_dft_1d", "group__API__FFT__Support.html#ga642104c645445688177f1a44afeeefb0", null ],
    [ "starpufft_plan_dft_2d", "group__API__FFT__Support.html#gaf263d43c43927007819edf069cc8c93b", null ],
    [ "starpufft_start", "group__API__FFT__Support.html#ga8e37e0bd1edc887cf456dcf7d95b86c4", null ],
    [ "starpufft_start_handle", "group__API__FFT__Support.html#gabff378384df24d2c2ea296397b600569", null ],
    [ "starpufft_execute", "group__API__FFT__Support.html#gae73ea67d1d7df63938661c7a1105800a", null ],
    [ "starpufft_execute_handle", "group__API__FFT__Support.html#ga22ad2f1c869305d11132322039d38876", null ],
    [ "starpufft_cleanup", "group__API__FFT__Support.html#ga4670f7ac8c6980f78b80b48bbe561299", null ],
    [ "starpufft_destroy_plan", "group__API__FFT__Support.html#ga2b1a62489b5b48491067bc8dc39f4b16", null ]
];