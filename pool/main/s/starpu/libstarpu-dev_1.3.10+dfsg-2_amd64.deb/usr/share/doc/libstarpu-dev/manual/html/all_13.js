var searchData=
[
  ['wait_5frequest_0',['wait_request',['../group__API__Out__Of__Core.html#ae1c30bb72265e8d1e972bfb00cf6345e',1,'starpu_disk_ops']]],
  ['where_1',['where',['../group__API__Codelet__And__Tasks.html#a504b8e20f53f469358eadb1ed800f72c',1,'starpu_codelet::where()'],['../group__API__Codelet__And__Tasks.html#a4984735dbd7577884486a43dcd6d7859',1,'starpu_task::where()']]],
  ['will_5fuse_5fmpi_2',['will_use_mpi',['../group__API__Initialization__and__Termination.html#a58cc3a37dc4e60999c2c99b0ec0244ad',1,'starpu_conf']]],
  ['worker_5farchtypes_3',['worker_archtypes',['../group__API__FxT__Support.html#a41dd735e884cd2e03ecd52e9d030ec6f',1,'starpu_fxt_options']]],
  ['worker_5fcomposed_5fsched_5fcomponent_4',['worker_composed_sched_component',['../group__API__Modularized__Scheduler.html#ab9e0712a96a5431e872db511777a3ad3',1,'starpu_sched_component_specs']]],
  ['worker_5fnames_5',['worker_names',['../group__API__FxT__Support.html#a3999b83fc470285e27bcdd04c9fa7f86',1,'starpu_fxt_options']]],
  ['worker_5fto_5fbe_5fremoved_6',['worker_to_be_removed',['../sc__hypervisor__monitoring_8h.html#adfb3d97bbdc15b0f9acee62ab4ae6350',1,'sc_hypervisor_wrapper']]],
  ['workerid_7',['workerid',['../group__API__Profiling.html#a19a06e7ef34a9a4587e77949ded36644',1,'starpu_profiling_task_info::workerid()'],['../group__API__Codelet__And__Tasks.html#a6a19a060f8f417fcc1f0e0196e599d33',1,'starpu_task::workerid()']]],
  ['workerids_8',['workerids',['../group__API__Codelet__And__Tasks.html#acb6e72edfeceed6e748a5036c0cb0657',1,'starpu_task::workerids()'],['../group__API__Workers__Properties.html#a0d213fc6e036df7424e05c30bfca22c4',1,'starpu_worker_collection::workerids()']]],
  ['workerids_5flen_9',['workerids_len',['../group__API__Codelet__And__Tasks.html#a7a44ccfc9c9914027f1212173e06dc27',1,'starpu_task']]],
  ['workerorder_10',['workerorder',['../group__API__Codelet__And__Tasks.html#a704b64ae35fc117b93a88ade0e1d6910',1,'starpu_task']]],
  ['workers_11',['workers',['../group__API__Modularized__Scheduler.html#a0ad3662dfe6897d86099b59cace66b8c',1,'starpu_sched_component::workers()'],['../group__API__Modularized__Scheduler.html#ab33fe24c45821588fb1c41b628cc78f1',1,'starpu_sched_tree::workers()']]],
  ['workers_5fbindid_12',['workers_bindid',['../group__API__Initialization__and__Termination.html#a2275c89ee0aded13cc8836a0c5ef0188',1,'starpu_conf']]],
  ['workers_5fcuda_5fgpuid_13',['workers_cuda_gpuid',['../group__API__Initialization__and__Termination.html#af482c3dac3ed6d28ee51e72c9ad636e1',1,'starpu_conf']]],
  ['workers_5fin_5fctx_14',['workers_in_ctx',['../group__API__Modularized__Scheduler.html#a461cccae50507f274c135375573780ea',1,'starpu_sched_component']]],
  ['workers_5fmic_5fdeviceid_15',['workers_mic_deviceid',['../group__API__Initialization__and__Termination.html#a4c988699b09aebac518afd6d30d1e0e8',1,'starpu_conf']]],
  ['workers_5fmpi_5fms_5fdeviceid_16',['workers_mpi_ms_deviceid',['../group__API__Initialization__and__Termination.html#aba4f067cfa379cac355008a00f2b7178',1,'starpu_conf']]],
  ['workers_5fopencl_5fgpuid_17',['workers_opencl_gpuid',['../group__API__Initialization__and__Termination.html#a62170298d1991dc5a9deb44c641cd405',1,'starpu_conf']]],
  ['workers’_20properties_18',['Workers’ Properties',['../group__API__Workers__Properties.html',1,'']]],
  ['write_19',['write',['../group__API__Out__Of__Core.html#af8075b45d01d4b6a556644aed724a999',1,'starpu_disk_ops']]]
];
