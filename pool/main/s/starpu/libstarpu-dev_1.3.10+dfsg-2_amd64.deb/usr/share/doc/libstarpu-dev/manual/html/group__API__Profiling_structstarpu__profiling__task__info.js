var group__API__Profiling_structstarpu__profiling__task__info =
[
    [ "submit_time", "group__API__Profiling.html#a3a1a7c8e4ce2552a0f96a8dd4f9ad37f", null ],
    [ "push_start_time", "group__API__Profiling.html#aa28c145b4543cceed05a1bba0478577e", null ],
    [ "push_end_time", "group__API__Profiling.html#a650860076a4d4c07929e97ec64386724", null ],
    [ "pop_start_time", "group__API__Profiling.html#a55f39da3b4c223d4cfc5bf7456692179", null ],
    [ "pop_end_time", "group__API__Profiling.html#a9e1ae88eb46e9b9867cb41d0584ace7b", null ],
    [ "acquire_data_start_time", "group__API__Profiling.html#a8f1fe52f21a7fc58860cf2f163ec868a", null ],
    [ "acquire_data_end_time", "group__API__Profiling.html#a0a43cc6fa5233d8d7e7ab0821607068c", null ],
    [ "start_time", "group__API__Profiling.html#ab8de457be74df606d29c3efa1169998a", null ],
    [ "end_time", "group__API__Profiling.html#ade189cd6175d789db1eb6bfad19b3e35", null ],
    [ "release_data_start_time", "group__API__Profiling.html#aae7bd9f557dffe9883629df980eee606", null ],
    [ "release_data_end_time", "group__API__Profiling.html#a8f4291afbbd7fcf885a3d30a72f2dd78", null ],
    [ "callback_start_time", "group__API__Profiling.html#a4ad1ae7ed15ea7001b5dc8e1d9579235", null ],
    [ "callback_end_time", "group__API__Profiling.html#a3296b9aa5339bf99f00f5377517c2390", null ],
    [ "workerid", "group__API__Profiling.html#a19a06e7ef34a9a4587e77949ded36644", null ],
    [ "used_cycles", "group__API__Profiling.html#aec88f33a8b4777727d80296c16d85f24", null ],
    [ "stall_cycles", "group__API__Profiling.html#a78e32404bdff71292562d2dc5892061c", null ],
    [ "energy_consumed", "group__API__Profiling.html#a6e85ac77428f572c5380e283b943459c", null ]
];