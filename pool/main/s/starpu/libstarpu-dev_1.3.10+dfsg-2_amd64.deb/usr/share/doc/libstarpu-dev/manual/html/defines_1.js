var searchData=
[
  ['starpu_5fhave_5fhelgrind_5fh_0',['STARPU_HAVE_HELGRIND_H',['../starpu__config_8h.html#aa535e147c4094f10a17972c417f98d85',1,'starpu_config.h']]],
  ['starpu_5ftask_5finvalid_1',['STARPU_TASK_INVALID',['../starpu__task_8h.html#a01d7ce55a1643b886608e93451bcd460',1,'starpu_task.h']]]
];
