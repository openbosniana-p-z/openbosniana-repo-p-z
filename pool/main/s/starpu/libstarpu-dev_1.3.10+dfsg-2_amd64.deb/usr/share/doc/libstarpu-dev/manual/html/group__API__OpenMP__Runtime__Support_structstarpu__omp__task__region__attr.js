var group__API__OpenMP__Runtime__Support_structstarpu__omp__task__region__attr =
[
    [ "cl", "group__API__OpenMP__Runtime__Support.html#a4f4e595f12101bbace47d4748d6d3e3b", null ],
    [ "handles", "group__API__OpenMP__Runtime__Support.html#a9886b8bade17a2e0c32bb2b36cb6c392", null ],
    [ "cl_arg", "group__API__OpenMP__Runtime__Support.html#ad7d88a7759aade7ae379a88eb737993b", null ],
    [ "cl_arg_size", "group__API__OpenMP__Runtime__Support.html#a594489c9f845922d685046c25f5540e8", null ],
    [ "cl_arg_free", "group__API__OpenMP__Runtime__Support.html#ad64a8be227ee0a2c4ea8fa2eca3d20c0", null ],
    [ "if_clause", "group__API__OpenMP__Runtime__Support.html#afa30d3c752ab9665112df925a39cb4ab", null ],
    [ "final_clause", "group__API__OpenMP__Runtime__Support.html#ae97da9038c9a034dc8734ae4c34ebc21", null ],
    [ "untied_clause", "group__API__OpenMP__Runtime__Support.html#abb648c16a9ec65f2834cf05994b33df2", null ],
    [ "mergeable_clause", "group__API__OpenMP__Runtime__Support.html#a6e3c542eac204dd67f343427c8a0a17c", null ],
    [ "is_loop", "group__API__OpenMP__Runtime__Support.html#a782139c5c2358477059af82135f76cc2", null ]
];