var globals_dup =
[
    [ "a", "globals.html", null ],
    [ "e", "globals_e.html", null ],
    [ "h", "globals_h.html", null ],
    [ "s", "globals_s.html", null ]
];