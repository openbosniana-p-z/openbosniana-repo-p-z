var group__API__Data__Interfaces_structstarpu__variable__interface =
[
    [ "id", "group__API__Data__Interfaces.html#a08694d4a3eba6826b7547d3bd1322702", null ],
    [ "ptr", "group__API__Data__Interfaces.html#a22bff436f00d8f1bc3a780c3f9888759", null ],
    [ "dev_handle", "group__API__Data__Interfaces.html#a0670ed209a3743268fe08824348449f5", null ],
    [ "offset", "group__API__Data__Interfaces.html#aeb8ae0434284030f7c898374eedb5034", null ],
    [ "elemsize", "group__API__Data__Interfaces.html#a59ac4839d899cf1d8a0c5fea68652f95", null ]
];