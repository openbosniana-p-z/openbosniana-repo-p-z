var group__API__Performance__Model_structstarpu__perfmodel =
[
    [ "type", "group__API__Performance__Model.html#afe2d561aaba7bf1ad1cf03974ee8c53c", null ],
    [ "cost_function", "group__API__Performance__Model.html#a16967b7c8c6860d283fc7db434cd3c7c", null ],
    [ "arch_cost_function", "group__API__Performance__Model.html#a4efccf0f3badb8eb35a07704b0e3ef01", null ],
    [ "size_base", "group__API__Performance__Model.html#a861b8ed68d4562e477948ee1ec511645", null ],
    [ "footprint", "group__API__Performance__Model.html#a40bcf4bf061be8c34ee0e418a8f5f27a", null ],
    [ "symbol", "group__API__Performance__Model.html#a114aa08286b9f6158aa9262c995d9bcd", null ],
    [ "is_loaded", "group__API__Performance__Model.html#ae37737aa0b7abc5f5813bf61814d996f", null ],
    [ "parameters_names", "group__API__Performance__Model.html#aa22dc6b2674ed810366dc300f4abd7cc", null ],
    [ "nparameters", "group__API__Performance__Model.html#a9d94e688cfa6eef3f277047e2a0e7cb2", null ],
    [ "combinations", "group__API__Performance__Model.html#a4fc15e27386dcbfbe0bba81f917ce198", null ],
    [ "ncombinations", "group__API__Performance__Model.html#a375ec764bad3d93e9b3f830b43934fa1", null ]
];