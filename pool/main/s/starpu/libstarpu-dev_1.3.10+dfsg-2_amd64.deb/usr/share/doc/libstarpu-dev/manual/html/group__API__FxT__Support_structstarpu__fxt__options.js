var group__API__FxT__Support_structstarpu__fxt__options =
[
    [ "file_prefix", "group__API__FxT__Support.html#a069e624dee891479cec370e8078b26f5", null ],
    [ "file_offset", "group__API__FxT__Support.html#a2ce33ee285499c1ca00f149293a1978d", null ],
    [ "file_rank", "group__API__FxT__Support.html#ad989ef1acebea5296285ba1543b9b8d3", null ],
    [ "worker_names", "group__API__FxT__Support.html#a3999b83fc470285e27bcdd04c9fa7f86", null ],
    [ "worker_archtypes", "group__API__FxT__Support.html#a41dd735e884cd2e03ecd52e9d030ec6f", null ],
    [ "nworkers", "group__API__FxT__Support.html#a2a1bec69241ff9acf6f991492de18190", null ],
    [ "dumped_codelets", "group__API__FxT__Support.html#ae8b5695146698ba1d5aef8c9237b5272", null ],
    [ "dumped_codelets_count", "group__API__FxT__Support.html#a66ac04619aec557f95ddf5a5df848341", null ]
];