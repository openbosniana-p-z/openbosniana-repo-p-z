var group__API__OpenMP__Runtime__Support_structstarpu__omp__nest__lock__t =
[
    [ "internal", "group__API__OpenMP__Runtime__Support.html#ab4a1aab4aa59767666547ff12a5374a2", null ]
];