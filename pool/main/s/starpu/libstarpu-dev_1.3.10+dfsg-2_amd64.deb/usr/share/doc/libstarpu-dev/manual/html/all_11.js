var searchData=
[
  ['unpack_5fdata_0',['unpack_data',['../group__API__Data__Interfaces.html#ab997f2654cd769dbd3413f5a90090a69',1,'starpu_data_interface_ops']]],
  ['unplug_1',['unplug',['../group__API__Out__Of__Core.html#aaaff065edbd1ad085acc89352cafd253',1,'starpu_disk_ops']]],
  ['unregister_5fdata_5fhandle_2',['unregister_data_handle',['../group__API__Data__Interfaces.html#a08ea385f365a2c0e36bcbadaf229d2fa',1,'starpu_data_interface_ops']]],
  ['untied_5fclause_3',['untied_clause',['../group__API__OpenMP__Runtime__Support.html#abb648c16a9ec65f2834cf05994b33df2',1,'starpu_omp_task_region_attr']]],
  ['use_5fexplicit_5fworkers_5fbindid_4',['use_explicit_workers_bindid',['../group__API__Initialization__and__Termination.html#affd5b335a988c417ecb679d5ecf7c489',1,'starpu_conf']]],
  ['use_5fexplicit_5fworkers_5fcuda_5fgpuid_5',['use_explicit_workers_cuda_gpuid',['../group__API__Initialization__and__Termination.html#a27718585874f9012e9955ba308e2cd8f',1,'starpu_conf']]],
  ['use_5fexplicit_5fworkers_5fmic_5fdeviceid_6',['use_explicit_workers_mic_deviceid',['../group__API__Initialization__and__Termination.html#a052f3cac0ebec9932c66d8f08cd9b6d4',1,'starpu_conf']]],
  ['use_5fexplicit_5fworkers_5fmpi_5fms_5fdeviceid_7',['use_explicit_workers_mpi_ms_deviceid',['../group__API__Initialization__and__Termination.html#a3a4c940d048e3805784624c51cb45195',1,'starpu_conf']]],
  ['use_5fexplicit_5fworkers_5fopencl_5fgpuid_8',['use_explicit_workers_opencl_gpuid',['../group__API__Initialization__and__Termination.html#a30cab554913e27a02512badaf204a266',1,'starpu_conf']]],
  ['use_5ftag_9',['use_tag',['../group__API__Codelet__And__Tasks.html#a31788bf459e8db1e90aa6673b1c72fa1',1,'starpu_task']]],
  ['used_5fcycles_10',['used_cycles',['../group__API__Profiling.html#aec88f33a8b4777727d80296c16d85f24',1,'starpu_profiling_task_info::used_cycles()'],['../group__API__Profiling.html#a5f76b7a4cc42a28735e0871439040319',1,'starpu_profiling_worker_info::used_cycles()']]]
];
