var group__API__Data__Interfaces_structstarpu__csr__interface =
[
    [ "id", "group__API__Data__Interfaces.html#a8fca87a97f1f7d086377f4c40aec3f29", null ],
    [ "nnz", "group__API__Data__Interfaces.html#aad762e1231c7623b5831de7839b91a53", null ],
    [ "nrow", "group__API__Data__Interfaces.html#a94fe9c7865c4efd4ffacfeabedce1da7", null ],
    [ "nzval", "group__API__Data__Interfaces.html#a74579a6b3cb9e5cedfe7f5e2ae9254b3", null ],
    [ "colind", "group__API__Data__Interfaces.html#a41630100e7fb39af8bec44fd57a559c0", null ],
    [ "rowptr", "group__API__Data__Interfaces.html#aeb80d9cbbad4df7188003cd514355413", null ],
    [ "firstentry", "group__API__Data__Interfaces.html#a4a0da8c56586c9bb0de5001649513b63", null ],
    [ "elemsize", "group__API__Data__Interfaces.html#a45554b96395b1b711db98ceb1d4535b8", null ]
];