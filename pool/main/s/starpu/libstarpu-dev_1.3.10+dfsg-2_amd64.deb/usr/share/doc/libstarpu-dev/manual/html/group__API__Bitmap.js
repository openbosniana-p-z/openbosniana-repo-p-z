var group__API__Bitmap =
[
    [ "starpu_bitmap_create", "group__API__Bitmap.html#gad46a1d8559731ed2b5619f90240b6c1b", null ],
    [ "starpu_bitmap_destroy", "group__API__Bitmap.html#ga870bdc74a6ff9db855de24622ced5f5f", null ],
    [ "starpu_bitmap_set", "group__API__Bitmap.html#gaf7debe919f07b41a8aa4d35262838e26", null ],
    [ "starpu_bitmap_unset", "group__API__Bitmap.html#gab9dcc731b430f29d7cd65451df6d14c0", null ],
    [ "starpu_bitmap_unset_all", "group__API__Bitmap.html#gafa9cd8be3ba6463b967e1c5bcb37587e", null ],
    [ "starpu_bitmap_get", "group__API__Bitmap.html#ga997748478e809c6dd577d204deaa5d57", null ],
    [ "starpu_bitmap_unset_and", "group__API__Bitmap.html#gae528ad901cbbdda91d0aa25d4a97ff59", null ],
    [ "starpu_bitmap_or", "group__API__Bitmap.html#ga9f3c69615da232aa98ca0d82b05d2fa2", null ],
    [ "starpu_bitmap_and_get", "group__API__Bitmap.html#gac7dbca81bf45d4d07f774057ef6790bc", null ],
    [ "starpu_bitmap_cardinal", "group__API__Bitmap.html#ga03a6d6e8dc484f0be14ebb733bc587d6", null ],
    [ "starpu_bitmap_first", "group__API__Bitmap.html#ga1a0689f2f21ccded428555a580567b61", null ],
    [ "starpu_bitmap_last", "group__API__Bitmap.html#ga6e979d89f277827e58aa0e6fe84c67cf", null ],
    [ "starpu_bitmap_next", "group__API__Bitmap.html#gaa2063e19f69f9fd87dd3107cf49db94e", null ],
    [ "starpu_bitmap_has_next", "group__API__Bitmap.html#ga7765890a66b9ecb0cedfd30ad0180333", null ]
];