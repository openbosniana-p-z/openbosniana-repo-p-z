var group__API__Data__Interfaces_structstarpu__coo__interface =
[
    [ "id", "group__API__Data__Interfaces.html#a5bf21cb9a0c92c55915427fb2b4cc220", null ],
    [ "columns", "group__API__Data__Interfaces.html#ac01fd0c59e0a5740ab8b000a2681f0aa", null ],
    [ "rows", "group__API__Data__Interfaces.html#a5bfde7e67006c99a054d7b3bcc270d8a", null ],
    [ "values", "group__API__Data__Interfaces.html#a3e71b630f78f6f51a0d3942514f7ff9a", null ],
    [ "nx", "group__API__Data__Interfaces.html#af9bc59bf8aa5132dcfeaf2c48713b5e1", null ],
    [ "ny", "group__API__Data__Interfaces.html#ae739aa4a6e1eee69f1fcf144443c98d9", null ],
    [ "n_values", "group__API__Data__Interfaces.html#a84c37663a9635c0d5699228d37b31324", null ],
    [ "elemsize", "group__API__Data__Interfaces.html#acae72d4dcc23fd3901b3f126ab0c61fd", null ]
];