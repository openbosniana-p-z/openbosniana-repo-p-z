var searchData=
[
  ['data_20interfaces_0',['Data Interfaces',['../group__API__Data__Interfaces.html',1,'']]],
  ['data_20management_1',['Data Management',['../group__API__Data__Management.html',1,'']]],
  ['data_20partition_2',['Data Partition',['../group__API__Data__Partition.html',1,'']]]
];
