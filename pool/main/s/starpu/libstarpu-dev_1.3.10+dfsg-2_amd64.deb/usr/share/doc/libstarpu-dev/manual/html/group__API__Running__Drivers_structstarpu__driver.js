var group__API__Running__Drivers_structstarpu__driver =
[
    [ "type", "group__API__Running__Drivers.html#a50af396b52e8c54e4e3b23803105fc0e", null ],
    [ "id", "group__API__Running__Drivers.html#a08415dd427f53b10ce4176ad77fade39", null ]
];