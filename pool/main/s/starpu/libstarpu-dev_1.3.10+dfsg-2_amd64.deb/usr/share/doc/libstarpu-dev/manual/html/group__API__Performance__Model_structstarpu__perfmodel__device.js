var group__API__Performance__Model_structstarpu__perfmodel__device =
[
    [ "type", "group__API__Performance__Model.html#ab73609496a2f81bca58a7c864b434441", null ],
    [ "devid", "group__API__Performance__Model.html#a6d8e3b8ee5e97b0a16ccb87bbf20afe9", null ],
    [ "ncores", "group__API__Performance__Model.html#a596618da61aafe041b9ed3aae1b713fe", null ]
];