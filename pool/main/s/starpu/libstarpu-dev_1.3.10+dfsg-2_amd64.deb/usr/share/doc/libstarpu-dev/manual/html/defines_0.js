var searchData=
[
  ['have_5fmpi_5fcomm_5ff2c_0',['HAVE_MPI_COMM_F2C',['../starpu__config_8h.html#a05ed4578d8a766626ad7a774483c9f5c',1,'starpu_config.h']]]
];
