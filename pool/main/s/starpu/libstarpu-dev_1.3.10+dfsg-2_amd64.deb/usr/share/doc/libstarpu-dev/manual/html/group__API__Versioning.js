var group__API__Versioning =
[
    [ "STARPU_MAJOR_VERSION", "group__API__Versioning.html#ga61698352a3ca7e28b4bcdd8bcad8d8cc", null ],
    [ "STARPU_MINOR_VERSION", "group__API__Versioning.html#ga847f129c7b859f46c8bd69c9c8cbcde5", null ],
    [ "STARPU_RELEASE_VERSION", "group__API__Versioning.html#ga43895a109dc6f27de709208f460b321d", null ],
    [ "starpu_get_version", "group__API__Versioning.html#gaa9151820d2ef6a8231b510b4b3c19ca4", null ]
];