var group__API__Parallel__Tasks =
[
    [ "starpu_combined_worker_get_count", "group__API__Parallel__Tasks.html#ga49a6732f413550652450baa64594bc5e", null ],
    [ "starpu_combined_worker_get_id", "group__API__Parallel__Tasks.html#gae53499613fb72e9aa1abad6437a926f9", null ],
    [ "starpu_combined_worker_get_size", "group__API__Parallel__Tasks.html#ga573d2513a10cf1d14fee0467eda0884d", null ],
    [ "starpu_combined_worker_get_rank", "group__API__Parallel__Tasks.html#ga4eb5aaf2f4e0c9a7f07cbc80f3ae9664", null ],
    [ "starpu_combined_worker_assign_workerid", "group__API__Parallel__Tasks.html#ga176c8b45655615fbd09f0b70ba8b78b5", null ],
    [ "starpu_combined_worker_get_description", "group__API__Parallel__Tasks.html#ga720a70f5297ffe3b5ea5cf6eff549c8c", null ],
    [ "starpu_combined_worker_can_execute_task", "group__API__Parallel__Tasks.html#gae3fe82c940e36715145baa9fe003e453", null ],
    [ "starpu_parallel_task_barrier_init", "group__API__Parallel__Tasks.html#ga3d362cb0de1da4e2659f602eff325479", null ],
    [ "starpu_parallel_task_barrier_init_n", "group__API__Parallel__Tasks.html#gaf99bc08bf6f586b658febdd1dc6fef80", null ]
];