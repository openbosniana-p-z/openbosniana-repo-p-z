var group__API__Out__Of__Core_structstarpu__disk__ops =
[
    [ "plug", "group__API__Out__Of__Core.html#a3ff4d322bb04025abb4a23638f4594a6", null ],
    [ "unplug", "group__API__Out__Of__Core.html#aaaff065edbd1ad085acc89352cafd253", null ],
    [ "bandwidth", "group__API__Out__Of__Core.html#a728c7a6e4c919a72300ac8f8a3bae0b2", null ],
    [ "alloc", "group__API__Out__Of__Core.html#a61b0e51977bdc6cc20d75f7c3ff2d614", null ],
    [ "free", "group__API__Out__Of__Core.html#a19b47927d234281d157b9191c9f59d57", null ],
    [ "open", "group__API__Out__Of__Core.html#a60d61aa8464bc852d6f4d118f70cb44f", null ],
    [ "close", "group__API__Out__Of__Core.html#a00b4fbe01a33b0f2526bd70e8128dfbd", null ],
    [ "read", "group__API__Out__Of__Core.html#a18216c9db1b888e568af638dbb22b16f", null ],
    [ "write", "group__API__Out__Of__Core.html#af8075b45d01d4b6a556644aed724a999", null ],
    [ "full_read", "group__API__Out__Of__Core.html#aa9c45355d7c609a9deccd366fab8ab5b", null ],
    [ "full_write", "group__API__Out__Of__Core.html#a4831b8088a13f038e267e9b141af4283", null ],
    [ "async_write", "group__API__Out__Of__Core.html#a217c4a50625fa3489ff9fde9259b020e", null ],
    [ "async_read", "group__API__Out__Of__Core.html#ae0d4c45de6fe688d86f234884d26f4e0", null ],
    [ "async_full_read", "group__API__Out__Of__Core.html#ab2317c0bff32b2b338632c70d56466c6", null ],
    [ "async_full_write", "group__API__Out__Of__Core.html#a67804045d2c3a3e240ec152090885853", null ],
    [ "copy", "group__API__Out__Of__Core.html#a1c98a8168c9f6046cc3c374d13c2f9d8", null ],
    [ "wait_request", "group__API__Out__Of__Core.html#ae1c30bb72265e8d1e972bfb00cf6345e", null ],
    [ "test_request", "group__API__Out__Of__Core.html#a6c89ac6cf13a6eec0eb36491d5b8ce8f", null ],
    [ "free_request", "group__API__Out__Of__Core.html#ad76930b8488dbedad92de1b5368dbdc8", null ]
];