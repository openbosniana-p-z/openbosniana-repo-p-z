var group__API__Profiling_structstarpu__profiling__worker__info =
[
    [ "start_time", "group__API__Profiling.html#aed6a8be9b919f03e093912bfc44c5559", null ],
    [ "total_time", "group__API__Profiling.html#aae49335c3c189b58103cb649fc169096", null ],
    [ "executing_time", "group__API__Profiling.html#a050199a48e0073f892cd6dd9049a4edf", null ],
    [ "sleeping_time", "group__API__Profiling.html#acc882d8569e28d51fd5e820962fed773", null ],
    [ "executed_tasks", "group__API__Profiling.html#a73a1303e033dffe94ff162e8e21122d1", null ],
    [ "used_cycles", "group__API__Profiling.html#a5f76b7a4cc42a28735e0871439040319", null ],
    [ "stall_cycles", "group__API__Profiling.html#a24037f0f53113b23f32c7af7a39f982d", null ],
    [ "energy_consumed", "group__API__Profiling.html#a52240aa53000a12a7b913f9f5822e032", null ]
];