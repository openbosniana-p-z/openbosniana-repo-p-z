var group__API__SC__Hypervisor_structsc__hypervisor__policy =
[
    [ "name", "group__API__SC__Hypervisor.html#ac71dc391218a17c435238f6bc42d2250", null ],
    [ "custom", "group__API__SC__Hypervisor.html#ae3a65239bb98f10756743787df0b9319", null ],
    [ "size_ctxs", "group__API__SC__Hypervisor.html#a838a86b485c9091ab11ea78bfbd12edd", null ],
    [ "resize_ctxs", "group__API__SC__Hypervisor.html#a6f4bdf0b6ff0c2ab8d4150e65f2b36e5", null ],
    [ "handle_idle_cycle", "group__API__SC__Hypervisor.html#a29df9c8d9917272bd5fa8f3a08863436", null ],
    [ "handle_pushed_task", "group__API__SC__Hypervisor.html#a5245eb597997de0cafafe19ece066cdc", null ],
    [ "handle_poped_task", "group__API__SC__Hypervisor.html#ab44752ac4a1d34c397d8fe8b10e8611b", null ],
    [ "handle_idle_end", "group__API__SC__Hypervisor.html#a9a8cebea8354bedd492764a53037f000", null ],
    [ "handle_post_exec_hook", "group__API__SC__Hypervisor.html#a2633e8c38deaef91972fe466983c3869", null ],
    [ "handle_submitted_job", "group__API__SC__Hypervisor.html#afbd8b91f7650ffd4c21ecbf17771a3d0", null ],
    [ "end_ctx", "group__API__SC__Hypervisor.html#ac676ac4892a469ad4674b560c2b92514", null ],
    [ "start_ctx", "group__API__SC__Hypervisor.html#afdc378d28bfed82986912168bab0286b", null ],
    [ "init_worker", "group__API__SC__Hypervisor.html#a2e618654e060e8ee020e228085520559", null ]
];