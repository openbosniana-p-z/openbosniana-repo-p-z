var searchData=
[
  ['opencl_20extensions_0',['OpenCL Extensions',['../group__API__OpenCL__Extensions.html',1,'']]],
  ['openmp_20runtime_20support_1',['OpenMP Runtime Support',['../group__API__OpenMP__Runtime__Support.html',1,'']]],
  ['out_20of_20core_2',['Out Of Core',['../group__API__Out__Of__Core.html',1,'']]]
];
