var group__API__SC__Hypervisor_structsc__hypervisor__policy__task__pool =
[
    [ "cl", "group__API__SC__Hypervisor.html#aea7e98763fa2b2f5553cc73bf29705f7", null ],
    [ "footprint", "group__API__SC__Hypervisor.html#a79204440a1911eb6411fa6b8d803e08b", null ],
    [ "sched_ctx_id", "group__API__SC__Hypervisor.html#a577d9798523bb202f0867ea1a818c88f", null ],
    [ "n", "group__API__SC__Hypervisor.html#aec206144116e7360d2479a38a1c7f5f4", null ],
    [ "data_size", "group__API__SC__Hypervisor.html#a79c6a87b792c849cc6c388dbf17d2d49", null ],
    [ "next", "group__API__SC__Hypervisor.html#a37e61f63183852ea3f8973f3de5ca23d", null ]
];