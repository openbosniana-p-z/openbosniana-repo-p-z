var group__API__Data__Interfaces_structstarpu__matrix__interface =
[
    [ "id", "group__API__Data__Interfaces.html#aaff7aa638a24957eb76c5c40f96cddbe", null ],
    [ "ptr", "group__API__Data__Interfaces.html#a4b6ebe9c32b5ea09236351b673beb24b", null ],
    [ "dev_handle", "group__API__Data__Interfaces.html#ac4101c57f4ebdb84a770d7a6450a6f15", null ],
    [ "offset", "group__API__Data__Interfaces.html#aad976625b7cb9b3044bc698b442fb4e6", null ],
    [ "nx", "group__API__Data__Interfaces.html#af00bd371238ac5b99036775525ac4543", null ],
    [ "ny", "group__API__Data__Interfaces.html#ad608771aa4de1f8e55ec6f00092d1705", null ],
    [ "ld", "group__API__Data__Interfaces.html#a5b0873b99f5b554ba3378c41cb31a63c", null ],
    [ "elemsize", "group__API__Data__Interfaces.html#a4768b7c5a77140d416c879c797d4c0e2", null ],
    [ "allocsize", "group__API__Data__Interfaces.html#a3ced8c019dfa184f17be42f9da9ca6e9", null ]
];