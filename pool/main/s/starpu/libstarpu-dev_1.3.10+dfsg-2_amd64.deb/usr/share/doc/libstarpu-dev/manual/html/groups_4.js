var searchData=
[
  ['fft_20support_0',['FFT Support',['../group__API__FFT__Support.html',1,'']]],
  ['fxt_20support_1',['FxT Support',['../group__API__FxT__Support.html',1,'']]]
];
