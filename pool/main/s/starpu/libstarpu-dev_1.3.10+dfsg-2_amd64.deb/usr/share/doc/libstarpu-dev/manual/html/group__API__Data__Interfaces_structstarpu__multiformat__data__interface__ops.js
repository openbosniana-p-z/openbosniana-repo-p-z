var group__API__Data__Interfaces_structstarpu__multiformat__data__interface__ops =
[
    [ "cpu_elemsize", "group__API__Data__Interfaces.html#a67a1f3202dfc2512ed7ed14bed4f3623", null ],
    [ "opencl_elemsize", "group__API__Data__Interfaces.html#a7c0e09ea6559bef4579a1fb1e57f67d2", null ],
    [ "cpu_to_opencl_cl", "group__API__Data__Interfaces.html#ac1103b46f4f50af4aeaa2772b3662cb2", null ],
    [ "opencl_to_cpu_cl", "group__API__Data__Interfaces.html#ad590b623d4814111b5d931eefee5d901", null ],
    [ "cuda_elemsize", "group__API__Data__Interfaces.html#a00927819b3899892ec152968efe0b158", null ],
    [ "cpu_to_cuda_cl", "group__API__Data__Interfaces.html#aab231ea3b842e030917eb2b67e9439eb", null ],
    [ "cuda_to_cpu_cl", "group__API__Data__Interfaces.html#ad3669cbe8a1a2cb874f86b3b74d9731f", null ],
    [ "mic_elemsize", "group__API__Data__Interfaces.html#a3788fdc38fb2941ca16761d33e96c022", null ],
    [ "cpu_to_mic_cl", "group__API__Data__Interfaces.html#adc3e56ba90f959e6aec093ba0fa3d385", null ],
    [ "mic_to_cpu_cl", "group__API__Data__Interfaces.html#ab6419afca2ad5f013fb7d1f8498a1d67", null ]
];