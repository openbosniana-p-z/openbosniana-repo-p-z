var group__API__Data__Interfaces_structstarpu__bcsr__interface =
[
    [ "id", "group__API__Data__Interfaces.html#aeaaaed6dbef4bfc013c133654c1825fc", null ],
    [ "nnz", "group__API__Data__Interfaces.html#a16fe3ad95b82e3d8d698274c89fca02a", null ],
    [ "nrow", "group__API__Data__Interfaces.html#a116539ced9567e49b1c3d37cbb9daf95", null ],
    [ "nzval", "group__API__Data__Interfaces.html#af0499fdbb48df14c8630d2b45520cdad", null ],
    [ "colind", "group__API__Data__Interfaces.html#a52dd5cb526a5a1114b2c6737e9da7d1c", null ],
    [ "rowptr", "group__API__Data__Interfaces.html#a8b19dca5c5adc1c35d3733e3e0e6abaf", null ],
    [ "firstentry", "group__API__Data__Interfaces.html#aa5fa3a6032aa673db172fd46ffbabcdc", null ],
    [ "r", "group__API__Data__Interfaces.html#aaae06f78b08695614601fae3d676dd62", null ],
    [ "c", "group__API__Data__Interfaces.html#ad25ad86f33897a36c7197bcf80242df4", null ],
    [ "elemsize", "group__API__Data__Interfaces.html#a143fa2154e1a6f621f46301bd174b09d", null ]
];