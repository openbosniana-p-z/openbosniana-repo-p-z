var group__API__Data__Interfaces_structstarpu__block__interface =
[
    [ "id", "group__API__Data__Interfaces.html#ae2a9b938ace8afeb6de759dadb7181a5", null ],
    [ "ptr", "group__API__Data__Interfaces.html#a82f9e85c27ab3fc9371b6b092c8e3743", null ],
    [ "dev_handle", "group__API__Data__Interfaces.html#a87c8121d720c200b8bf5710d5b34ed87", null ],
    [ "offset", "group__API__Data__Interfaces.html#a081cbedadaaa3b94bec18dd2e71e2d58", null ],
    [ "nx", "group__API__Data__Interfaces.html#af4cf7dcbcb99e697561312b2b7c44ffa", null ],
    [ "ny", "group__API__Data__Interfaces.html#a98ab405852ad8f5b23b4c305633a8761", null ],
    [ "nz", "group__API__Data__Interfaces.html#a4f9492b1f9efc6139cd434b546e4cb28", null ],
    [ "ldy", "group__API__Data__Interfaces.html#a4e92a6ef9a315f84065f078d5643cbcc", null ],
    [ "ldz", "group__API__Data__Interfaces.html#aaaae7566c1b274a8e208828792043a1e", null ],
    [ "elemsize", "group__API__Data__Interfaces.html#ae2bd3e92fba4412cabef91740fa6d30f", null ]
];