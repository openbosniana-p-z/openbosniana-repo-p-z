var files_dup =
[
    [ "include", "dir_d44c64559bbebec7f509842c48db8b23.html", "dir_d44c64559bbebec7f509842c48db8b23" ],
    [ "mpi", "dir_13620b7f1330796542fcb7e43593aaf8.html", "dir_13620b7f1330796542fcb7e43593aaf8" ],
    [ "sc_hypervisor", "dir_2b71cc231200f5a90ab95407d7180260.html", "dir_2b71cc231200f5a90ab95407d7180260" ],
    [ "starpufft", "dir_1212eb25485da553d611e933f5534891.html", "dir_1212eb25485da553d611e933f5534891" ],
    [ "starpurm", "dir_41040452e3bc01aecd3050d3acf7270b.html", "dir_41040452e3bc01aecd3050d3acf7270b" ],
    [ "starpu_config.h", "starpu__config_8h.html", "starpu__config_8h" ]
];