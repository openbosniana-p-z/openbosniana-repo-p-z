var group__API__Performance__Model_structstarpu__perfmodel__arch =
[
    [ "ndevices", "group__API__Performance__Model.html#addc058e80e8075ecb7474da3a3de3885", null ],
    [ "devices", "group__API__Performance__Model.html#a3d1c665b09c40842120fde9f89d1ec22", null ]
];