var dir_2506f9feebdcf18e217efba11f1cd200 =
[
    [ "starpu_heteroprio.h", "starpu__heteroprio_8h.html", "starpu__heteroprio_8h" ]
];