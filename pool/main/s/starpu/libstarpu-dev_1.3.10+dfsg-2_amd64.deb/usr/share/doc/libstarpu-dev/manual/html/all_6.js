var searchData=
[
  ['get_5falloc_5fsize_0',['get_alloc_size',['../group__API__Data__Interfaces.html#aa15a9ec57fd090fa18c843dc8fadd97d',1,'starpu_data_interface_ops']]],
  ['get_5fchild_5fops_1',['get_child_ops',['../group__API__Data__Partition.html#a6cb433cf6efd383c6739099dccb3c2b0',1,'starpu_data_filter']]],
  ['get_5fnchildren_2',['get_nchildren',['../group__API__Data__Partition.html#aca2a185107bc8d8adc11557248cf454b',1,'starpu_data_filter']]],
  ['get_5fnext_3',['get_next',['../group__API__Workers__Properties.html#ab92e3de048f56a4c2f59fa804594c339',1,'starpu_worker_collection']]],
  ['get_5fsize_4',['get_size',['../group__API__Data__Interfaces.html#a0e8e1db77d7a2113df9d6d27dd4b8d17',1,'starpu_data_interface_ops']]],
  ['granularity_5',['granularity',['../sc__hypervisor__config_8h.html#a78e03b1cc0e5f7505bb7f0404955d239',1,'sc_hypervisor_policy_config']]]
];
