var group__API__Codelet__And__Tasks_structstarpu__data__descr =
[
    [ "handle", "group__API__Codelet__And__Tasks.html#acb02fc7b0a1ca4f6146cfe5eaaff8f87", null ],
    [ "mode", "group__API__Codelet__And__Tasks.html#ab5db40a50f4f086fad3207d8e50de261", null ]
];