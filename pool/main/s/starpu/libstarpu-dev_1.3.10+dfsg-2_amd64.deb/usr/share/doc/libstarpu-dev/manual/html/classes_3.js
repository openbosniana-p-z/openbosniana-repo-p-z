var searchData=
[
  ['types_5fof_5fworkers_0',['types_of_workers',['../group__API__SC__Hypervisor.html#structtypes__of__workers',1,'']]]
];
