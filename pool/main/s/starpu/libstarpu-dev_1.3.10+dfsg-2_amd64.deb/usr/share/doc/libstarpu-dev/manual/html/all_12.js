var searchData=
[
  ['valid_0',['valid',['../group__API__Performance__Model.html#a1e6c12b85fc84336010f580874ec494a',1,'starpu_perfmodel_regression_model']]],
  ['values_1',['values',['../group__API__Data__Interfaces.html#a3e71b630f78f6f51a0d3942514f7ff9a',1,'starpu_coo_interface']]],
  ['versioning_2',['Versioning',['../group__API__Versioning.html',1,'']]]
];
