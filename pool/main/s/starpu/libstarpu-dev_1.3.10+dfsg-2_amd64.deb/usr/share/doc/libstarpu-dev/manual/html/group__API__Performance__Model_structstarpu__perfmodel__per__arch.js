var group__API__Performance__Model_structstarpu__perfmodel__per__arch =
[
    [ "cost_function", "group__API__Performance__Model.html#a13f34a1532294c101254beb106f124f3", null ],
    [ "size_base", "group__API__Performance__Model.html#aa82fae955253d333733d34fe4a44e298", null ],
    [ "history", "group__API__Performance__Model.html#ae85f08cd76b524e074b5d1746fe2610a", null ],
    [ "list", "group__API__Performance__Model.html#a1bb7c98bc1c1ab6b31c718c1afad7ff7", null ],
    [ "regression", "group__API__Performance__Model.html#a1b50329c04b9326c72130f83c91c1c28", null ]
];