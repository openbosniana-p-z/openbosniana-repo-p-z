var group__API__FxT__Support =
[
    [ "starpu_fxt_codelet_event", "group__API__FxT__Support.html#structstarpu__fxt__codelet__event", null ],
    [ "starpu_fxt_options", "group__API__FxT__Support.html#structstarpu__fxt__options", [
      [ "file_prefix", "group__API__FxT__Support.html#a069e624dee891479cec370e8078b26f5", null ],
      [ "file_offset", "group__API__FxT__Support.html#a2ce33ee285499c1ca00f149293a1978d", null ],
      [ "file_rank", "group__API__FxT__Support.html#ad989ef1acebea5296285ba1543b9b8d3", null ],
      [ "worker_names", "group__API__FxT__Support.html#a3999b83fc470285e27bcdd04c9fa7f86", null ],
      [ "worker_archtypes", "group__API__FxT__Support.html#a41dd735e884cd2e03ecd52e9d030ec6f", null ],
      [ "nworkers", "group__API__FxT__Support.html#a2a1bec69241ff9acf6f991492de18190", null ],
      [ "dumped_codelets", "group__API__FxT__Support.html#ae8b5695146698ba1d5aef8c9237b5272", null ],
      [ "dumped_codelets_count", "group__API__FxT__Support.html#a66ac04619aec557f95ddf5a5df848341", null ]
    ] ],
    [ "starpu_fxt_autostart_profiling", "group__API__FxT__Support.html#ga6a7af6697ae7a67161d3655c59215c09", null ],
    [ "starpu_fxt_start_profiling", "group__API__FxT__Support.html#ga5793bf5c8fc0bedf76d18a5fa38593df", null ],
    [ "starpu_fxt_stop_profiling", "group__API__FxT__Support.html#ga52a3e1a95689315f0b789a3325ec2a90", null ],
    [ "starpu_fxt_is_enabled", "group__API__FxT__Support.html#ga92a47d1c4bdf5697906c55e32d9330e4", null ],
    [ "starpu_fxt_trace_user_event", "group__API__FxT__Support.html#ga2e55ad671e94b6161755717b1c8b44c1", null ],
    [ "starpu_fxt_trace_user_event_string", "group__API__FxT__Support.html#gabe14377ea858ed3b40c1b469d7a4a4ea", null ]
];