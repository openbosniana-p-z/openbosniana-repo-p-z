var group__API__SC__Hypervisor__LP =
[
    [ "sc_hypervisor_lp_get_nworkers_per_ctx", "group__API__SC__Hypervisor__LP.html#ga7ef6d8b50b99d2e88b053791a1d5c588", null ],
    [ "sc_hypervisor_lp_get_tmax", "group__API__SC__Hypervisor__LP.html#gacc56bcf1548a4d5a082f9287672fbc13", null ],
    [ "sc_hypervisor_lp_round_double_to_int", "group__API__SC__Hypervisor__LP.html#ga6074d44c0bedd93474d631546b90d602", null ],
    [ "sc_hypervisor_lp_redistribute_resources_in_ctxs", "group__API__SC__Hypervisor__LP.html#ga8e6a76b7b67da9a200bd7755c5af0b0d", null ],
    [ "sc_hypervisor_lp_distribute_resources_in_ctxs", "group__API__SC__Hypervisor__LP.html#ga54777bfa24810b101784e5f7e45ff356", null ],
    [ "sc_hypervisor_lp_distribute_floating_no_resources_in_ctxs", "group__API__SC__Hypervisor__LP.html#gae07ce1123bc39d71ecc437201eac151e", null ],
    [ "sc_hypervisor_lp_place_resources_in_ctx", "group__API__SC__Hypervisor__LP.html#ga563843ede9e369216c3eeb2bd8e5237b", null ],
    [ "sc_hypervisor_lp_share_remaining_resources", "group__API__SC__Hypervisor__LP.html#gafd728af46e35624005c789cdcfdb8a9e", null ],
    [ "sc_hypervisor_lp_find_tmax", "group__API__SC__Hypervisor__LP.html#ga39b4f48eb3bade0001780c1a1e1c16a8", null ],
    [ "sc_hypervisor_lp_execute_dichotomy", "group__API__SC__Hypervisor__LP.html#gaf2c86b770b3e0a0bb03db997a03104af", null ],
    [ "sc_hypervisor_lp_simulate_distrib_flops", "group__API__SC__Hypervisor__LP.html#ga9983b17edc20a128abbcdc9d0e6c8a2f", null ],
    [ "sc_hypervisor_lp_simulate_distrib_tasks", "group__API__SC__Hypervisor__LP.html#ga119a16db0b13d9d328b9644fbcfffb33", null ],
    [ "sc_hypervisor_lp_simulate_distrib_flops_on_sample", "group__API__SC__Hypervisor__LP.html#ga2cecd17791724a374b6fd2c8e1dff1f6", null ]
];