var group__API__Task__Bundles =
[
    [ "starpu_task_bundle_t", "group__API__Task__Bundles.html#gacb73894185b73d1da811a88b084ba151", null ],
    [ "starpu_task_bundle_create", "group__API__Task__Bundles.html#gadd37abde6806819967151a64146b19d6", null ],
    [ "starpu_task_bundle_insert", "group__API__Task__Bundles.html#gae8be4224d241ac2d30d9d573359e3280", null ],
    [ "starpu_task_bundle_remove", "group__API__Task__Bundles.html#gad904bbf27569e421454a2c8b25458eb3", null ],
    [ "starpu_task_bundle_close", "group__API__Task__Bundles.html#ga7fcf9fedcf2a3f79784425431980a480", null ],
    [ "starpu_task_bundle_expected_length", "group__API__Task__Bundles.html#ga278de79c7cbeaa68e5239b415cc0d29c", null ],
    [ "starpu_task_bundle_expected_data_transfer_time", "group__API__Task__Bundles.html#gaf589986f5e69b7452ba90857d1931594", null ],
    [ "starpu_task_bundle_expected_energy", "group__API__Task__Bundles.html#ga4eac9575958c784ce48d2787b908ab3b", null ]
];