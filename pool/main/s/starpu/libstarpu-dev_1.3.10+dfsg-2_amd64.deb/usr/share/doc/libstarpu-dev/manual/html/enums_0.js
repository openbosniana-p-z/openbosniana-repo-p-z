var searchData=
[
  ['e_5fstarpurm_5fdrs_5fret_0',['e_starpurm_drs_ret',['../group__API__Interop__Support.html#ga33d15f419efaa08bf329d25f054fa632',1,'starpurm.h']]]
];
