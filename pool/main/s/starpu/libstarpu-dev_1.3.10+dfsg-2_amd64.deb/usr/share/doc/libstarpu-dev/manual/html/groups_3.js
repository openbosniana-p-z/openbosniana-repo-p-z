var searchData=
[
  ['expert_20mode_0',['Expert Mode',['../group__API__Expert__Mode.html',1,'']]],
  ['explicit_20dependencies_1',['Explicit Dependencies',['../group__API__Explicit__Dependencies.html',1,'']]]
];
