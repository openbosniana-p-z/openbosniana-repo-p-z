var group__API__Expert__Mode =
[
    [ "starpu_wake_all_blocked_workers", "group__API__Expert__Mode.html#gaf5f4a32a78630fb051a846cbdcd77d8b", null ],
    [ "starpu_progression_hook_register", "group__API__Expert__Mode.html#ga4e8d1e607b2383f80b232c27ec6a9386", null ],
    [ "starpu_progression_hook_deregister", "group__API__Expert__Mode.html#ga5d52c35e46e387eed77dd9b7b39507a7", null ]
];