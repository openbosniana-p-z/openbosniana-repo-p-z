var group__API__Profiling_structstarpu__profiling__bus__info =
[
    [ "start_time", "group__API__Profiling.html#a8032d6b4c3391555b255718d7da4279c", null ],
    [ "total_time", "group__API__Profiling.html#a46492a6afad2c9069b84110d6d9e86be", null ],
    [ "transferred_bytes", "group__API__Profiling.html#a029068c588c17476bf07a4a4a2bd690b", null ],
    [ "transfer_count", "group__API__Profiling.html#a34ad3d96e949d8030473300e13aa1c0c", null ]
];