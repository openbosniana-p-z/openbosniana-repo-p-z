var searchData=
[
  ['a_0',['a',['../group__API__Performance__Model.html#ab718a53c300f99766bdc42ca1909b49b',1,'starpu_perfmodel_regression_model']]],
  ['acked_5fworkers_1',['acked_workers',['../group__API__SC__Hypervisor.html#a829c79920efa453ee18491e8a85c1ff6',1,'sc_hypervisor_resize_ack']]],
  ['acquire_5fdata_5fend_5ftime_2',['acquire_data_end_time',['../group__API__Profiling.html#a0a43cc6fa5233d8d7e7ab0821607068c',1,'starpu_profiling_task_info']]],
  ['acquire_5fdata_5fstart_5ftime_3',['acquire_data_start_time',['../group__API__Profiling.html#a8f1fe52f21a7fc58860cf2f163ec868a',1,'starpu_profiling_task_info']]],
  ['act_5fhypervisor_5fmutex_4',['act_hypervisor_mutex',['../group__API__SC__Hypervisor__usage.html#gaf192fa1a6a02127cab3482459235799a',1,'sc_hypervisor.h']]],
  ['add_5',['add',['../group__API__Workers__Properties.html#ae039a760cdd80c0d91bcc4c4da9ebb74',1,'starpu_worker_collection']]],
  ['add_5fchild_6',['add_child',['../group__API__Modularized__Scheduler.html#a27af06d3f659a32cb4f3b9599fba00d8',1,'starpu_sched_component']]],
  ['add_5fworkers_7',['add_workers',['../group__API__Scheduling__Policy.html#a44e18efefc5e383997cc5684e014bd82',1,'starpu_sched_policy']]],
  ['advanced_20examples_8',['Advanced Examples',['../AdvancedExamples.html',1,'']]],
  ['alloc_9',['alloc',['../group__API__Out__Of__Core.html#a61b0e51977bdc6cc20d75f7c3ff2d614',1,'starpu_disk_ops']]],
  ['alloc_5fcompare_10',['alloc_compare',['../group__API__Data__Interfaces.html#a223bf2a2e0fe3a2c8042bdb90605c24d',1,'starpu_data_interface_ops']]],
  ['alloc_5ffootprint_11',['alloc_footprint',['../group__API__Data__Interfaces.html#abc69fa030b4398af1663af656d91c2c5',1,'starpu_data_interface_ops']]],
  ['allocate_5fdata_5fon_5fnode_12',['allocate_data_on_node',['../group__API__Data__Interfaces.html#afb8adfbac498be2eb6a587460f161e73',1,'starpu_data_interface_ops']]],
  ['allocsize_13',['allocsize',['../group__API__Data__Interfaces.html#a3ced8c019dfa184f17be42f9da9ca6e9',1,'starpu_matrix_interface::allocsize()'],['../group__API__Data__Interfaces.html#abccb7b1d3e85a19d010bec0e2202284f',1,'starpu_vector_interface::allocsize()']]],
  ['alpha_14',['alpha',['../group__API__Performance__Model.html#afb6b1e89bf7820131bddf970bb0df58b',1,'starpu_perfmodel_regression_model']]],
  ['any_5fto_5fany_15',['any_to_any',['../group__API__Data__Interfaces.html#add029fa5a3dc52c964587d97aca34263',1,'starpu_data_copy_methods']]],
  ['arch_5fcost_5ffunction_16',['arch_cost_function',['../group__API__Performance__Model.html#a4efccf0f3badb8eb35a07704b0e3ef01',1,'starpu_perfmodel']]],
  ['async_5ffull_5fread_17',['async_full_read',['../group__API__Out__Of__Core.html#ab2317c0bff32b2b338632c70d56466c6',1,'starpu_disk_ops']]],
  ['async_5ffull_5fwrite_18',['async_full_write',['../group__API__Out__Of__Core.html#a67804045d2c3a3e240ec152090885853',1,'starpu_disk_ops']]],
  ['async_5fread_19',['async_read',['../group__API__Out__Of__Core.html#ae0d4c45de6fe688d86f234884d26f4e0',1,'starpu_disk_ops']]],
  ['async_5fwrite_20',['async_write',['../group__API__Out__Of__Core.html#a217c4a50625fa3489ff9fde9259b020e',1,'starpu_disk_ops']]]
];
