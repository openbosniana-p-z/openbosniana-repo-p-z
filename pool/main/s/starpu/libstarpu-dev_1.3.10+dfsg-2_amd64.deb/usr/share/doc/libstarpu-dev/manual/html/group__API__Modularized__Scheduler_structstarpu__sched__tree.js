var group__API__Modularized__Scheduler_structstarpu__sched__tree =
[
    [ "root", "group__API__Modularized__Scheduler.html#a5b27ab8642148517e8addec4863c2042", null ],
    [ "workers", "group__API__Modularized__Scheduler.html#ab33fe24c45821588fb1c41b628cc78f1", null ],
    [ "sched_ctx_id", "group__API__Modularized__Scheduler.html#a79f98f04b4efe58b32fe1ab4f244fe46", null ],
    [ "lock", "group__API__Modularized__Scheduler.html#a66b33bee46a8d853dd25ee16645cf673", null ]
];