var group__API__Theoretical__Lower__Bound__on__Execution__Time =
[
    [ "starpu_bound_start", "group__API__Theoretical__Lower__Bound__on__Execution__Time.html#ga284f3571becb60b2354cc1ce121e4778", null ],
    [ "starpu_bound_stop", "group__API__Theoretical__Lower__Bound__on__Execution__Time.html#ga5f1859599a28105aea4c0f33fd871218", null ],
    [ "starpu_bound_print_dot", "group__API__Theoretical__Lower__Bound__on__Execution__Time.html#ga7fc9141929ef926d346431307afb0ff1", null ],
    [ "starpu_bound_compute", "group__API__Theoretical__Lower__Bound__on__Execution__Time.html#ga99f073d0ad7604366ef3a8f805b5f060", null ],
    [ "starpu_bound_print_lp", "group__API__Theoretical__Lower__Bound__on__Execution__Time.html#ga066ce2e396d5b676af7a5209b0079610", null ],
    [ "starpu_bound_print_mps", "group__API__Theoretical__Lower__Bound__on__Execution__Time.html#gad0cf05d0bb9b21964fb911cfebf252df", null ],
    [ "starpu_bound_print", "group__API__Theoretical__Lower__Bound__on__Execution__Time.html#ga834aa7094c173d42985d4d70f1694f57", null ]
];