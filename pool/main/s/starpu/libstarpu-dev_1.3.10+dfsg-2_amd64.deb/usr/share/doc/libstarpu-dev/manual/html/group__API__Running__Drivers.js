var group__API__Running__Drivers =
[
    [ "starpu_driver", "group__API__Running__Drivers.html#structstarpu__driver", [
      [ "type", "group__API__Running__Drivers.html#a50af396b52e8c54e4e3b23803105fc0e", null ],
      [ "id", "group__API__Running__Drivers.html#a08415dd427f53b10ce4176ad77fade39", null ]
    ] ],
    [ "starpu_driver.id", "group__API__Running__Drivers.html#unionstarpu__driver_8id", null ],
    [ "starpu_driver_run", "group__API__Running__Drivers.html#ga68b320765b17e5e4a256f156c9932e69", null ],
    [ "starpu_drivers_request_termination", "group__API__Running__Drivers.html#ga497d48a24107dfebf6ef3ad40d4a6df8", null ],
    [ "starpu_driver_init", "group__API__Running__Drivers.html#gab274599ec82fe38cb41267b8a1384995", null ],
    [ "starpu_driver_run_once", "group__API__Running__Drivers.html#gad6d01b57f2f84df90f554ea205dcf90d", null ],
    [ "starpu_driver_deinit", "group__API__Running__Drivers.html#gac8f8848b64980676190d77d265fda841", null ]
];