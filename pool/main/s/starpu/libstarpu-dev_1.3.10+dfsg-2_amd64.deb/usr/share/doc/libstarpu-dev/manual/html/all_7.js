var searchData=
[
  ['handle_0',['handle',['../group__API__Codelet__And__Tasks.html#acb02fc7b0a1ca4f6146cfe5eaaff8f87',1,'starpu_data_descr']]],
  ['handle_5fidle_5fcycle_1',['handle_idle_cycle',['../group__API__SC__Hypervisor.html#a29df9c8d9917272bd5fa8f3a08863436',1,'sc_hypervisor_policy']]],
  ['handle_5fidle_5fend_2',['handle_idle_end',['../group__API__SC__Hypervisor.html#a9a8cebea8354bedd492764a53037f000',1,'sc_hypervisor_policy']]],
  ['handle_5fpoped_5ftask_3',['handle_poped_task',['../group__API__SC__Hypervisor.html#ab44752ac4a1d34c397d8fe8b10e8611b',1,'sc_hypervisor_policy']]],
  ['handle_5fpost_5fexec_5fhook_4',['handle_post_exec_hook',['../group__API__SC__Hypervisor.html#a2633e8c38deaef91972fe466983c3869',1,'sc_hypervisor_policy']]],
  ['handle_5fpushed_5ftask_5',['handle_pushed_task',['../group__API__SC__Hypervisor.html#a5245eb597997de0cafafe19ece066cdc',1,'sc_hypervisor_policy']]],
  ['handle_5fsubmitted_5fjob_6',['handle_submitted_job',['../group__API__SC__Hypervisor.html#afbd8b91f7650ffd4c21ecbf17771a3d0',1,'sc_hypervisor_policy']]],
  ['handle_5fto_5fpointer_7',['handle_to_pointer',['../group__API__Data__Interfaces.html#ae002548f6392819ff90d72f64898dca6',1,'starpu_data_interface_ops']]],
  ['handles_8',['handles',['../group__API__OpenMP__Runtime__Support.html#acf0b820ff6649f9290dbfa3d270d8cec',1,'starpu_omp_parallel_region_attr::handles()'],['../group__API__OpenMP__Runtime__Support.html#a9886b8bade17a2e0c32bb2b36cb6c392',1,'starpu_omp_task_region_attr::handles()'],['../group__API__Codelet__And__Tasks.html#af3ce0252f1ac2238325033386a726df3',1,'starpu_task::handles()']]],
  ['handles_5fsequential_5fconsistency_9',['handles_sequential_consistency',['../group__API__Codelet__And__Tasks.html#a964e4d78ecfbe8c10e392e83dd276299',1,'starpu_task']]],
  ['has_5fnext_10',['has_next',['../group__API__Workers__Properties.html#a6595f14b6715e60d2444f4cd09b9d73f',1,'starpu_worker_collection']]],
  ['have_5fmpi_5fcomm_5ff2c_11',['HAVE_MPI_COMM_F2C',['../starpu__config_8h.html#a05ed4578d8a766626ad7a774483c9f5c',1,'starpu_config.h']]],
  ['head_12',['head',['../group__API__Task__Lists.html#af66edbac990d8e894796ca5d5dd45138',1,'starpu_task_list']]],
  ['history_13',['history',['../group__API__Performance__Model.html#ae85f08cd76b524e074b5d1746fe2610a',1,'starpu_perfmodel_per_arch']]],
  ['how_20to_20define_20a_20new_20scheduling_20policy_14',['How To Define A New Scheduling Policy',['../HowToDefineANewSchedulingPolicy.html',1,'']]],
  ['hwloc_5fcache_5fcomposed_5fsched_5fcomponent_15',['hwloc_cache_composed_sched_component',['../group__API__Modularized__Scheduler.html#a59dedc6c07c0bcfd78639da0e4073d73',1,'starpu_sched_component_specs']]],
  ['hwloc_5fcomponent_5fcomposed_5fsched_5fcomponent_16',['hwloc_component_composed_sched_component',['../group__API__Modularized__Scheduler.html#ad859296dbded64c8593d613286893a93',1,'starpu_sched_component_specs']]],
  ['hwloc_5fmachine_5fcomposed_5fsched_5fcomponent_17',['hwloc_machine_composed_sched_component',['../group__API__Modularized__Scheduler.html#abec52a111491d978567b509117607aa3',1,'starpu_sched_component_specs']]],
  ['hwloc_5fsocket_5fcomposed_5fsched_5fcomponent_18',['hwloc_socket_composed_sched_component',['../group__API__Modularized__Scheduler.html#a783d5970fe203d01442fb32bc4cafb7c',1,'starpu_sched_component_specs']]],
  ['hyp_5freact_5fstart_5ftime_19',['hyp_react_start_time',['../sc__hypervisor__monitoring_8h.html#aba3d21edf846f13f3d41405ab7d99016',1,'sc_hypervisor_wrapper']]],
  ['hypervisor_5ftag_20',['hypervisor_tag',['../group__API__Codelet__And__Tasks.html#a48416cfa1692f8e8cb42d80ec9f1eb5e',1,'starpu_task']]]
];
