var searchData=
[
  ['obj_0',['obj',['../group__API__Modularized__Scheduler.html#ac2709f00c42977b8df96d30015fc9cb1',1,'starpu_sched_component']]],
  ['offline_20performance_20tools_1',['Offline Performance Tools',['../OfflinePerformanceTools.html',1,'']]],
  ['offset_2',['offset',['../group__API__Data__Interfaces.html#aad976625b7cb9b3044bc698b442fb4e6',1,'starpu_matrix_interface::offset()'],['../group__API__Data__Interfaces.html#a081cbedadaaa3b94bec18dd2e71e2d58',1,'starpu_block_interface::offset()'],['../group__API__Data__Interfaces.html#ab02b430abde33905606cadd02374fb59',1,'starpu_vector_interface::offset()'],['../group__API__Data__Interfaces.html#aeb8ae0434284030f7c898374eedb5034',1,'starpu_variable_interface::offset()']]],
  ['omp_5ftask_3',['omp_task',['../group__API__Codelet__And__Tasks.html#ab2d4ff02b79d56aff544bdd2604184de',1,'starpu_task']]],
  ['online_20performance_20tools_4',['Online Performance Tools',['../OnlinePerformanceTools.html',1,'']]],
  ['open_5',['open',['../group__API__Out__Of__Core.html#a60d61aa8464bc852d6f4d118f70cb44f',1,'starpu_disk_ops']]],
  ['opencl_20extensions_6',['OpenCL Extensions',['../group__API__OpenCL__Extensions.html',1,'']]],
  ['opencl_5felemsize_7',['opencl_elemsize',['../group__API__Data__Interfaces.html#a7c0e09ea6559bef4579a1fb1e57f67d2',1,'starpu_multiformat_data_interface_ops']]],
  ['opencl_5fflags_8',['opencl_flags',['../group__API__Codelet__And__Tasks.html#a2de77d2c65169749809c078367905a93',1,'starpu_codelet']]],
  ['opencl_5ffunc_9',['opencl_func',['../group__API__Codelet__And__Tasks.html#a20c2ee87052f53f2641736e57551011b',1,'starpu_codelet']]],
  ['opencl_5ffuncs_10',['opencl_funcs',['../group__API__Codelet__And__Tasks.html#a757a9831b9e2b5e0d503e902d9f94529',1,'starpu_codelet']]],
  ['opencl_5fto_5fcpu_5fcl_11',['opencl_to_cpu_cl',['../group__API__Data__Interfaces.html#ad590b623d4814111b5d931eefee5d901',1,'starpu_multiformat_data_interface_ops']]],
  ['opencl_5fto_5fcuda_12',['opencl_to_cuda',['../group__API__Data__Interfaces.html#a67353f606184dc10b9619049f38825e7',1,'starpu_data_copy_methods']]],
  ['opencl_5fto_5fopencl_13',['opencl_to_opencl',['../group__API__Data__Interfaces.html#a99f4a2889d2184c091620140fa517e37',1,'starpu_data_copy_methods']]],
  ['opencl_5fto_5fopencl_5fasync_14',['opencl_to_opencl_async',['../group__API__Data__Interfaces.html#ad11f3b02dcb83194f96d4e360957a262',1,'starpu_data_copy_methods']]],
  ['opencl_5fto_5fram_15',['opencl_to_ram',['../group__API__Data__Interfaces.html#a975914df540caa34fd0f469d242e3a40',1,'starpu_data_copy_methods']]],
  ['opencl_5fto_5fram_5fasync_16',['opencl_to_ram_async',['../group__API__Data__Interfaces.html#ade630b6788a5cc8ee587fda066f9fc6f',1,'starpu_data_copy_methods']]],
  ['openmp_20runtime_20support_17',['OpenMP Runtime Support',['../group__API__OpenMP__Runtime__Support.html',1,'']]],
  ['operator_28_2eior_2e_29_18',['operator(.ior.)',['../interfacefstarpu__mod_1_1operator_07_8ior_8_08.html',1,'fstarpu_mod']]],
  ['out_20of_20core_19',['Out Of Core',['../group__API__Out__Of__Core.html',1,'(Global Namespace)'],['../OutOfCore.html',1,'(Global Namespace)']]]
];
