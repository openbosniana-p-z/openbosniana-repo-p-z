var group__API__MIC__Extensions =
[
    [ "STARPU_USE_MIC", "group__API__MIC__Extensions.html#ga08715106f0b8262604d469ed0aa962aa", null ],
    [ "STARPU_MAXMICDEVS", "group__API__MIC__Extensions.html#ga06ae5976f7c5d39961019127497b097b", null ],
    [ "starpu_mic_func_symbol_t", "group__API__MIC__Extensions.html#ga29746e714fc5aaa5655a16929c48a9e4", null ],
    [ "starpu_mic_register_kernel", "group__API__MIC__Extensions.html#ga83b91d88db5e1e326149f836b7b48ea1", null ],
    [ "starpu_mic_get_kernel", "group__API__MIC__Extensions.html#ga17637a17347c4ecdec828cd996331710", null ]
];