var globals_func =
[
    [ "s", "globals_func.html", null ]
];