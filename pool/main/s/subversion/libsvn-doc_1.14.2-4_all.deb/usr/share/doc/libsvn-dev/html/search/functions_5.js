var searchData=
[
  ['name_0',['name',['../classapache_1_1subversion_1_1svnxx_1_1error.html#ad0c267f0b6b11a470cc5b87c21e60b12',1,'apache::subversion::svnxx::error::name()'],['../classapache_1_1subversion_1_1svnxx_1_1error_1_1message.html#a5656dfbab49afc54cd908c4046741a53',1,'apache::subversion::svnxx::error::message::name()']]]
];
