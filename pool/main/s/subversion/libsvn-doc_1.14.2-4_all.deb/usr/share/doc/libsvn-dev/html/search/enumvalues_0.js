var searchData=
[
  ['invalid_0',['invalid',['../classapache_1_1subversion_1_1svnxx_1_1revision.html#ab41cf9a380ae661892c83c7110401fb2afedb2d84cafe20862cb4399751a8a7e3',1,'apache::subversion::svnxx::revision']]]
];
