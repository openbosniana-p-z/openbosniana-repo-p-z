var searchData=
[
  ['base64_20encoding_2fdecoding_20functions_0',['Base64 encoding/decoding functions',['../group__base64.html',1,'']]],
  ['basic_20character_20classification_20_2d_207_2dbit_20ascii_20only_1',['Basic character classification - 7-bit ASCII only',['../group__ctype__basic.html',1,'']]],
  ['begin_20versioning_20files_2fdirectories_20in_20a_20working_20copy_2e_2',['Begin versioning files/directories in a working copy.',['../group__Add.html',1,'']]],
  ['berkeley_20db_20filesystem_20compatibility_3',['Berkeley DB filesystem compatibility',['../group__svn__fs__bdb__deprecated.html',1,'']]],
  ['berkeley_20db_20filesystems_4',['Berkeley DB filesystems',['../group__svn__fs__bdb.html',1,'']]],
  ['bitmask_20flags_20for_20svn_5ffs_5fbegin_5ftxn2_28_29_5',['Bitmask flags for svn_fs_begin_txn2()',['../group__svn__fs__begin__txn2__flags.html',1,'']]],
  ['bring_20a_20working_20copy_20up_2dto_2ddate_20with_20a_20repository_6',['Bring a working copy up-to-date with a repository',['../group__Update.html',1,'']]],
  ['built_2din_20back_2dends_7',['Built-in back-ends',['../group__svn__fs__backend__names.html',1,'']]]
];
