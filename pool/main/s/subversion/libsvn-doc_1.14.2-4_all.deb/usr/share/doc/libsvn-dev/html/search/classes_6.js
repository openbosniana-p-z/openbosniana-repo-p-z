var searchData=
[
  ['noncopyable_0',['noncopyable',['../classapache_1_1subversion_1_1svnxx_1_1detail_1_1noncopyable___1_1noncopyable.html',1,'apache::subversion::svnxx::detail::noncopyable_']]]
];
