var searchData=
[
  ['generate_20differences_20between_20paths_2e_0',['Generate differences between paths.',['../group__Diff.html',1,'']]],
  ['generic_20byte_20streams_1',['Generic byte streams',['../group__svn__io__byte__streams.html',1,'']]],
  ['generic_5ftext_2',['generic_text',['../classapache_1_1subversion_1_1svnxx_1_1error_1_1message.html#a7ae6265aa83a3b80c6eee18ff735f05d',1,'apache::subversion::svnxx::error::message']]],
  ['get_5fclient_5fstring_3',['get_client_string',['../structsvn__ra__callbacks2__t.html#a84728cc834176b36a62e3bd82b2601a8',1,'svn_ra_callbacks2_t']]],
  ['get_5fcommit_5feditor_4',['get_commit_editor',['../structsvn__ra__plugin__t.html#a223a4e84b930bebd0032e92bef9f3082',1,'svn_ra_plugin_t']]],
  ['get_5fdate_5',['get_date',['../classapache_1_1subversion_1_1svnxx_1_1revision.html#ab72b3222ae6e01e50ecbfda66411148c',1,'apache::subversion::svnxx::revision']]],
  ['get_5fdated_5frevision_6',['get_dated_revision',['../structsvn__ra__plugin__t.html#ad8517e608229d23b6b3f5375bc9cc7fb',1,'svn_ra_plugin_t']]],
  ['get_5fdir_7',['get_dir',['../structsvn__ra__plugin__t.html#af9a6e20a6da3234050508955af11bfe7',1,'svn_ra_plugin_t']]],
  ['get_5ffile_8',['get_file',['../structsvn__ra__plugin__t.html#ae6739d6ad215b51c03c8cf63b7a90d02',1,'svn_ra_plugin_t']]],
  ['get_5ffile_5frevs_9',['get_file_revs',['../structsvn__ra__plugin__t.html#adb07cc280d93187258612e7be71d5823',1,'svn_ra_plugin_t']]],
  ['get_5fkind_10',['get_kind',['../classapache_1_1subversion_1_1svnxx_1_1revision.html#ae8bfcb69e51a2fc9dc4292a64a1a8995',1,'apache::subversion::svnxx::revision']]],
  ['get_5flatest_5frevnum_11',['get_latest_revnum',['../structsvn__ra__plugin__t.html#a92c2f17e0ba14c0a370eda6affc213fd',1,'svn_ra_plugin_t']]],
  ['get_5flocations_12',['get_locations',['../structsvn__ra__plugin__t.html#a2fc308b312a5b2d2eff35a17fb86c972',1,'svn_ra_plugin_t']]],
  ['get_5flog_13',['get_log',['../structsvn__ra__plugin__t.html#a6e37639e48e478eb22872180aa68009e',1,'svn_ra_plugin_t']]],
  ['get_5fnumber_14',['get_number',['../classapache_1_1subversion_1_1svnxx_1_1revision.html#a7942e2937beef96ce2916c2be686c980',1,'apache::subversion::svnxx::revision']]],
  ['get_5frepos_5froot_15',['get_repos_root',['../structsvn__ra__plugin__t.html#a1b1e9578e172dce56853d62430de166b',1,'svn_ra_plugin_t']]],
  ['get_5fuuid_16',['get_uuid',['../structsvn__ra__plugin__t.html#aa009e880f6ef34a7d695e70b8c4fffd8',1,'svn_ra_plugin_t']]],
  ['get_5fversion_17',['get_version',['../structsvn__ra__plugin__t.html#a90de4caf2ed64df0737b90efb842d3d3',1,'svn_ra_plugin_t']]],
  ['get_5fwc_5fcontents_18',['get_wc_contents',['../structsvn__ra__callbacks2__t.html#abac945409fe4861749b64f48f9a9312c',1,'svn_ra_callbacks2_t']]],
  ['get_5fwc_5fprop_19',['get_wc_prop',['../structsvn__ra__callbacks2__t.html#a2201deaeed805e764c6ffa3b2b9ab0ea',1,'svn_ra_callbacks2_t']]]
];
