var searchData=
[
  ['warning_0',['warning',['../structsvn__repos__notify__t.html#ad45deb713b7aecfc446b8e1daadd92a8',1,'svn_repos_notify_t']]],
  ['warning_5fstr_1',['warning_str',['../structsvn__repos__notify__t.html#aa4c6dce115895ffe804e428d1fa562e2',1,'svn_repos_notify_t']]],
  ['wc_20out_2dof_2ddate_20info_20from_20the_20repository_2',['WC out-of-date info from the repository',['../group__svn__wc__status__ood.html',1,'']]],
  ['wc_5fctx_3',['wc_ctx',['../structsvn__client__ctx__t.html#af687ec14c4b5bbeef8c0ca14043ad7d8',1,'svn_client_ctx_t']]],
  ['wc_5finfo_4',['wc_info',['../structsvn__client__info2__t.html#a184ba0ca23f20496999a359ff2b2676b',1,'svn_client_info2_t']]],
  ['wc_5fis_5flocked_5',['wc_is_locked',['../structsvn__client__status__t.html#af5aac19e3f7f18ada309e38d75892b67',1,'svn_client_status_t']]],
  ['wcprop_5fchanges_6',['wcprop_changes',['../structsvn__client__commit__item2__t.html#ade34c45a89c230160b3c6b5469a44149',1,'svn_client_commit_item2_t::wcprop_changes()'],['../structsvn__client__commit__item__t.html#af8d63279594e973d9d561c8459d994e1',1,'svn_client_commit_item_t::wcprop_changes()']]],
  ['wcroot_5fabspath_7',['wcroot_abspath',['../structsvn__wc__info__t.html#a57e1153fc875ac9d750e817bb5d8c820',1,'svn_wc_info_t']]],
  ['what_8',['what',['../classapache_1_1subversion_1_1svnxx_1_1error.html#a4abc197fcda6b4754288506485d98332',1,'apache::subversion::svnxx::error']]],
  ['working_20copy_20context_9',['Working copy context',['../group__svn__wc__context.html',1,'']]],
  ['working_20copy_20management_10',['Working copy management',['../group__svn__wc.html',1,'']]],
  ['working_20copy_20roots_11',['Working copy roots',['../group__svn__wc__roots.html',1,'']]],
  ['working_20copy_20status_2e_12',['Working copy status.',['../group__svn__wc__status.html',1,'']]],
  ['working_5fsize_13',['working_size',['../structsvn__info__t.html#aa7aeb9d7901df7b61f6f12677a6fdf45',1,'svn_info_t::working_size()'],['../structsvn__wc__entry__t.html#a25ab6ea3228d960e6c170856a573ee9c',1,'svn_wc_entry_t::working_size()']]]
];
