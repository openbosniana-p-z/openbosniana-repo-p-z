var searchData=
[
  ['cancelled_0',['cancelled',['../classapache_1_1subversion_1_1svnxx_1_1cancelled.html',1,'apache::subversion::svnxx']]],
  ['context_1',['context',['../classapache_1_1subversion_1_1svnxx_1_1client_1_1context.html',1,'apache::subversion::svnxx::client']]]
];
