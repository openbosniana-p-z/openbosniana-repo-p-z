var searchData=
[
  ['id_0',['id',['../structsvn__fs__dirent__t.html#aa851e9f5f2c0b42201932b35446cabf6',1,'svn_fs_dirent_t']]],
  ['ignore_5feol_5fstyle_1',['ignore_eol_style',['../structsvn__diff__file__options__t.html#aa64547c47939b23c2718632d725bd129',1,'svn_diff_file_options_t']]],
  ['ignore_5fspace_2',['ignore_space',['../structsvn__diff__file__options__t.html#aa9af536942cd066b86c468239abe4c4f',1,'svn_diff_file_options_t']]],
  ['ignoring_20unversioned_20files_20and_20directories_3',['Ignoring unversioned files and directories',['../group__svn__wc__ignore.html',1,'']]],
  ['import_20files_20into_20the_20repository_2e_4',['Import files into the repository.',['../group__Import.html',1,'']]],
  ['incoming_5fprop_5fchanges_5',['incoming_prop_changes',['../structsvn__client__commit__item3__t.html#a88936d3f05e59d6af78d45abbdd20374',1,'svn_client_commit_item3_t']]],
  ['incomplete_6',['incomplete',['../structsvn__wc__entry__t.html#ad8b7dac0683c1542ed46833a9a41d221',1,'svn_wc_entry_t']]],
  ['inheritable_7',['inheritable',['../structsvn__merge__range__t.html#aa1a75cd9c348e308fe185b45a9a9860e',1,'svn_merge_range_t']]],
  ['init_8',['init',['../classapache_1_1subversion_1_1svnxx_1_1init.html',1,'apache::subversion::svnxx']]],
  ['init_2ehpp_9',['init.hpp',['../init_8hpp.html',1,'']]],
  ['invalid_10',['invalid',['../classapache_1_1subversion_1_1svnxx_1_1revision.html#ab41cf9a380ae661892c83c7110401fb2afedb2d84cafe20862cb4399751a8a7e3',1,'apache::subversion::svnxx::revision']]],
  ['invalidate_5fwc_5fprops_11',['invalidate_wc_props',['../structsvn__ra__callbacks2__t.html#a5fd4de25dc587e8ed6129e163fd66b00',1,'svn_ra_callbacks2_t']]],
  ['invisible_20properties_12',['Invisible properties',['../group__svn__prop__invisible__props.html',1,'']]],
  ['is_5fbinary_13',['is_binary',['../structsvn__wc__conflict__description2__t.html#a1cfc118edfbafb324f758ceb47b30bef',1,'svn_wc_conflict_description2_t::is_binary()'],['../structsvn__wc__conflict__description__t.html#a9b670ad87c4446e6b074074b49139d72',1,'svn_wc_conflict_description_t::is_binary()']]],
  ['is_5fdav_5fcomment_14',['is_dav_comment',['../structsvn__lock__t.html#a4e39f3efb7f4ca75830350e01fa36fcc',1,'svn_lock_t']]],
  ['issuer_5fdname_15',['issuer_dname',['../structsvn__auth__ssl__server__cert__info__t.html#a4fda462229f4bfff13f1756555a0cd32',1,'svn_auth_ssl_server_cert_info_t']]]
];
