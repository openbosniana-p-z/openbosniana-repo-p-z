var searchData=
[
  ['unknown_0',['unknown',['../classapache_1_1subversion_1_1svnxx_1_1tristate.html#a13748e13a78f40791f3bbe6aa14f2eb6',1,'apache::subversion::svnxx::tristate::unknown() noexcept'],['../classapache_1_1subversion_1_1svnxx_1_1tristate.html#a07dae159f06e35f0ce081dad5f23108e',1,'apache::subversion::svnxx::tristate::unknown(tristate t) noexcept']]]
];
