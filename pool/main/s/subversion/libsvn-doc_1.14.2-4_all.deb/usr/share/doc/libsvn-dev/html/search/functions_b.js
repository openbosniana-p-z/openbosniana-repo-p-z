var searchData=
[
  ['what_0',['what',['../classapache_1_1subversion_1_1svnxx_1_1error.html#a4abc197fcda6b4754288506485d98332',1,'apache::subversion::svnxx::error']]]
];
