var searchData=
[
  ['u_0',['u',['../structsvn__ra__svn__item__t.html#a07f754aa8ee1839ee4fcd49e9efbddbf',1,'svn_ra_svn_item_t']]],
  ['unknown_1',['unknown',['../classapache_1_1subversion_1_1svnxx_1_1tristate.html#a13748e13a78f40791f3bbe6aa14f2eb6',1,'apache::subversion::svnxx::tristate::unknown() noexcept'],['../classapache_1_1subversion_1_1svnxx_1_1tristate.html#a07dae159f06e35f0ce081dad5f23108e',1,'apache::subversion::svnxx::tristate::unknown(tristate t) noexcept']]],
  ['update_20and_20switch_20_28update_2dlike_20functionality_29_2',['Update and switch (update-like functionality)',['../group__svn__wc__update__switch.html',1,'']]],
  ['upgrade_20a_20working_20copy_2e_3',['Upgrade a working copy.',['../group__Upgrade.html',1,'']]],
  ['uri_2furl_20conversion_4',['URI/URL conversion',['../group__svn__path__uri__stuff.html',1,'']]],
  ['url_5',['url',['../structsvn__client__commit__item3__t.html#a4858d4312bb750b78d7f69d0bd41dea8',1,'svn_client_commit_item3_t']]],
  ['url_6',['URL',['../structsvn__info__t.html#a158d8adf66fcbbdafabce1ee8c386619',1,'svn_info_t']]],
  ['url_7',['url',['../structsvn__wc__status2__t.html#a2eb27dfa3ae98d54f08301a5f51cc813',1,'svn_wc_status2_t::url()'],['../structsvn__wc__entry__t.html#a0e04f933d63180505c633563155b0f48',1,'svn_wc_entry_t::url()'],['../structsvn__wc__notify__t.html#a5a9f84c348036479f956dd46d2eb9715',1,'svn_wc_notify_t::url()'],['../structsvn__wc__external__item__t.html#a634228c950b5e14764511871d32f974f',1,'svn_wc_external_item_t::url()'],['../structsvn__wc__external__item2__t.html#a378889695ae374518c4f7852d418f054',1,'svn_wc_external_item2_t::url()'],['../structsvn__client__commit__item__t.html#a4b5f651bb4b7c08af69b479d0ffec7b4',1,'svn_client_commit_item_t::url()'],['../structsvn__client__commit__item2__t.html#ad8b7ecb8d3658c6913f958d0972b64a5',1,'svn_client_commit_item2_t::url()']]],
  ['url_8',['URL',['../structsvn__client__info2__t.html#ab5f993b4da04e5640fe4e1602fe1eb04',1,'svn_client_info2_t']]],
  ['usec_9',['usec',['../classapache_1_1subversion_1_1svnxx_1_1revision.html#a774eccc431d9157958d7b4794cae554d',1,'apache::subversion::svnxx::revision']]],
  ['username_10',['username',['../structsvn__auth__cred__simple__t.html#aca61326f536c24bf136768f785a32344',1,'svn_auth_cred_simple_t::username()'],['../structsvn__auth__cred__username__t.html#a94b6592c04859b5a0161e789b2422de5',1,'svn_auth_cred_username_t::username()']]],
  ['uuid_11',['uuid',['../structsvn__wc__entry__t.html#a34985b8a7dc1927139ae5be4e7272996',1,'svn_wc_entry_t']]],
  ['uuid_5frecord_12',['uuid_record',['../structsvn__repos__parse__fns3__t.html#a4e5f910fcba95e12eff9bb7b146fa06e',1,'svn_repos_parse_fns3_t::uuid_record()'],['../structsvn__repos__parse__fns2__t.html#af1dcd0ad59d8c4de31283bfdf1606612',1,'svn_repos_parse_fns2_t::uuid_record()'],['../structsvn__repos__parse__fns__t.html#a68e59785169fde2297d035fece697ca6',1,'svn_repos_parse_fns_t::uuid_record()']]]
];
