var searchData=
[
  ['update_20and_20switch_20_28update_2dlike_20functionality_29_0',['Update and switch (update-like functionality)',['../group__svn__wc__update__switch.html',1,'']]],
  ['upgrade_20a_20working_20copy_2e_1',['Upgrade a working copy.',['../group__Upgrade.html',1,'']]],
  ['uri_2furl_20conversion_2',['URI/URL conversion',['../group__svn__path__uri__stuff.html',1,'']]]
];
