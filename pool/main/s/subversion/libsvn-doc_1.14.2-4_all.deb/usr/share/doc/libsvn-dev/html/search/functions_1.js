var searchData=
[
  ['code_0',['code',['../classapache_1_1subversion_1_1svnxx_1_1error.html#afbe3dbcb5348ea0885c001f2c5e2d5fe',1,'apache::subversion::svnxx::error::code()'],['../classapache_1_1subversion_1_1svnxx_1_1error_1_1message.html#a62c25c87f1b1d820d505f293501c3635',1,'apache::subversion::svnxx::error::message::code()']]]
];
