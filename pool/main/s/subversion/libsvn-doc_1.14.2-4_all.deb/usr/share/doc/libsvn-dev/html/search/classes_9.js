var searchData=
[
  ['tristate_0',['tristate',['../classapache_1_1subversion_1_1svnxx_1_1tristate.html',1,'apache::subversion::svnxx']]]
];
