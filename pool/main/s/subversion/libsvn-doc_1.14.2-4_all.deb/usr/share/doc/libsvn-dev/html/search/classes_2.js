var searchData=
[
  ['error_0',['error',['../classapache_1_1subversion_1_1svnxx_1_1error.html',1,'apache::subversion::svnxx']]]
];
