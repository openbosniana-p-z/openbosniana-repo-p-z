var searchData=
[
  ['taking_20the_20diff_20of_20two_20hash_20tables_2e_0',['Taking the diff of two hash tables.',['../group__svn__hash__diff.html',1,'']]],
  ['text_20deltas_1',['Text deltas',['../group__svn__delta__txt__delta.html',1,'']]],
  ['text_2fprop_20deltas_20using_20an_20editor_2',['Text/Prop Deltas Using an Editor',['../group__svn__wc__deltas.html',1,'']]],
  ['translation_20flags_3',['Translation flags',['../group__translate__flags.html',1,'']]],
  ['tree_20deltas_4',['Tree deltas',['../group__svn__delta__tree__deltas.html',1,'']]]
];
