var searchData=
[
  ['future_0',['future',['../classapache_1_1subversion_1_1svnxx_1_1detail_1_1future___1_1future.html',1,'apache::subversion::svnxx::detail::future_']]],
  ['future_5fbase_1',['future_base',['../classapache_1_1subversion_1_1svnxx_1_1detail_1_1future___1_1future__base.html',1,'apache::subversion::svnxx::detail::future_']]]
];
