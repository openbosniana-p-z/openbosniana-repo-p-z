var searchData=
[
  ['init_2ehpp_0',['init.hpp',['../init_8hpp.html',1,'']]]
];
