var searchData=
[
  ['noncopyable_2ehpp_0',['noncopyable.hpp',['../noncopyable_8hpp.html',1,'']]]
];
