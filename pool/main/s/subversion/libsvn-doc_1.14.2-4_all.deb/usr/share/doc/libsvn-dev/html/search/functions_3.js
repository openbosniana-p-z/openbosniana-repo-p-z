var searchData=
[
  ['generic_5ftext_0',['generic_text',['../classapache_1_1subversion_1_1svnxx_1_1error_1_1message.html#a7ae6265aa83a3b80c6eee18ff735f05d',1,'apache::subversion::svnxx::error::message']]],
  ['get_5fdate_1',['get_date',['../classapache_1_1subversion_1_1svnxx_1_1revision.html#ab72b3222ae6e01e50ecbfda66411148c',1,'apache::subversion::svnxx::revision']]],
  ['get_5fkind_2',['get_kind',['../classapache_1_1subversion_1_1svnxx_1_1revision.html#ae8bfcb69e51a2fc9dc4292a64a1a8995',1,'apache::subversion::svnxx::revision']]],
  ['get_5fnumber_3',['get_number',['../classapache_1_1subversion_1_1svnxx_1_1revision.html#a7942e2937beef96ce2916c2be686c980',1,'apache::subversion::svnxx::revision']]]
];
