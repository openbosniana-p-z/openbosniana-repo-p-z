var searchData=
[
  ['kind_0',['kind',['../classapache_1_1subversion_1_1svnxx_1_1revision.html#ae9f13fbc126750724780c147fadfc18c',1,'apache::subversion::svnxx::revision']]]
];
