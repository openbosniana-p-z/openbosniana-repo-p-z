var searchData=
[
  ['_28deprecated_29_20authz_20client_20subsystem_0',['(deprecated) AuthZ client subsystem',['../group__auth__fns__depr.html',1,'']]]
];
