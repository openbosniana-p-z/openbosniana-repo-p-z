var searchData=
[
  ['valid_5ffrom_0',['valid_from',['../structsvn__auth__ssl__server__cert__info__t.html#a25082853d863ac6f3803616d41dcbb9d',1,'svn_auth_ssl_server_cert_info_t']]],
  ['valid_5foptions_1',['valid_options',['../structsvn__opt__subcommand__desc3__t.html#afd546f8b21dfc68c59c0e32ce4ee82d4',1,'svn_opt_subcommand_desc3_t::valid_options()'],['../structsvn__opt__subcommand__desc2__t.html#ab52ff885527b0b7a977e2836492a5785',1,'svn_opt_subcommand_desc2_t::valid_options()'],['../structsvn__opt__subcommand__desc__t.html#ab919b9b43b8654f9f15850c880d27c5f',1,'svn_opt_subcommand_desc_t::valid_options()']]],
  ['valid_5funtil_2',['valid_until',['../structsvn__auth__ssl__server__cert__info__t.html#a81f46ccdddf2611a86fe7c02e6227598',1,'svn_auth_ssl_server_cert_info_t']]],
  ['value_3',['value',['../structsvn__opt__revision__t.html#a3fd7428fac9e204434428c0e4376d98f',1,'svn_opt_revision_t::value()'],['../structsvn__prop__t.html#a3d36920ed6e21ada9c74a1829c4fb068',1,'svn_prop_t::value()']]],
  ['version_4',['version',['../structsvn__version__ext__loaded__lib__t.html#a858afcfcb5eb7f09987c403be6b490c2',1,'svn_version_ext_loaded_lib_t']]],
  ['version_2fformat_20files_5',['Version/format files',['../group__svn__io__format__files.html',1,'']]],
  ['version_5fquery_6',['version_query',['../structsvn__version__checklist__t.html#a0251252c2c40caac099b3ecf9fdaf847',1,'svn_version_checklist_t']]],
  ['versioned_7',['versioned',['../structsvn__client__status__t.html#ae34445e807c42edfe24162ef58031ecd',1,'svn_client_status_t::versioned()'],['../structsvn__wc__status3__t.html#acd4d0347e573fb396f9fad8d753e6bb8',1,'svn_wc_status3_t::versioned()']]],
  ['versioned_20and_20unversioned_20properties_8',['Versioned and Unversioned Properties',['../group__svn__repos__properties.html',1,'']]],
  ['view_20information_20about_20previous_20revisions_20of_20an_20object_2e_9',['View information about previous revisions of an object.',['../group__Log.html',1,'']]],
  ['view_20the_20contents_20of_20a_20file_20in_20the_20repository_2e_10',['View the contents of a file in the repository.',['../group__Cat.html',1,'']]],
  ['visible_20properties_11',['Visible properties',['../group__svn__prop__visible__props.html',1,'']]]
];
