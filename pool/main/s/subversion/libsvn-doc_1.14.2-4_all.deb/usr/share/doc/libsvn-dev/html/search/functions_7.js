var searchData=
[
  ['revision_0',['revision',['../classapache_1_1subversion_1_1svnxx_1_1revision.html#a7505516bb479ab21bc81200249c0ff48',1,'apache::subversion::svnxx::revision::revision() noexcept'],['../classapache_1_1subversion_1_1svnxx_1_1revision.html#abc3d36b6f8ddfb6f6fd3a8ba0ad181f5',1,'apache::subversion::svnxx::revision::revision(kind revkind)'],['../classapache_1_1subversion_1_1svnxx_1_1revision.html#a661fba1cf106c53c10847634f057cac5',1,'apache::subversion::svnxx::revision::revision(number revnum_) noexcept'],['../classapache_1_1subversion_1_1svnxx_1_1revision.html#a3f0d35c624e4220d60fa654399b10fb8',1,'apache::subversion::svnxx::revision::revision(time&lt; D &gt; time_) noexcept']]]
];
