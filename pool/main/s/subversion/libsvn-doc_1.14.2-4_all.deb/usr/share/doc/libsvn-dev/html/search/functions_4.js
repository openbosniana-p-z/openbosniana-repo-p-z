var searchData=
[
  ['messages_0',['messages',['../classapache_1_1subversion_1_1svnxx_1_1error.html#aad5ea249f593985bc71b7e362057a196',1,'apache::subversion::svnxx::error']]]
];
