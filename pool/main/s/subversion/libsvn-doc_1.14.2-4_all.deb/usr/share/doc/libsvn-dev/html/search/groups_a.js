var searchData=
[
  ['keyword_20definitions_0',['Keyword definitions',['../group__svn__types__keywords.html',1,'']]]
];
