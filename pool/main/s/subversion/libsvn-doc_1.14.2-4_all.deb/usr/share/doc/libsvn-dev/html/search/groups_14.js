var searchData=
[
  ['wc_20out_2dof_2ddate_20info_20from_20the_20repository_0',['WC out-of-date info from the repository',['../group__svn__wc__status__ood.html',1,'']]],
  ['working_20copy_20context_1',['Working copy context',['../group__svn__wc__context.html',1,'']]],
  ['working_20copy_20management_2',['Working copy management',['../group__svn__wc.html',1,'']]],
  ['working_20copy_20roots_3',['Working copy roots',['../group__svn__wc__roots.html',1,'']]],
  ['working_20copy_20status_2e_4',['Working copy status.',['../group__svn__wc__status.html',1,'']]]
];
