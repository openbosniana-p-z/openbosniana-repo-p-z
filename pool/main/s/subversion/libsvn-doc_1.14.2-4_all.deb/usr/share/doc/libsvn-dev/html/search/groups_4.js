var searchData=
[
  ['data_20structures_20and_20editor_20things_20forrepository_20inspection_2e_0',['Data structures and editor things forrepository inspection.',['../group__svn__repos__inspection.html',1,'']]],
  ['dav_20property_20namespaces_1',['DAV property namespaces',['../group__svn__dav__property__xml__namespaces.html',1,'']]],
  ['dealing_20with_20conflicted_20paths_2e_2',['Dealing with conflicted paths.',['../group__Conflicts.html',1,'']]],
  ['definitions_20of_20ra_5fsvn_20dirent_20fields_3',['Definitions of ra_svn dirent fields',['../group__ra__svn__dirent__fields.html',1,'']]],
  ['delta_20generation_20and_20handling_4',['Delta generation and handling',['../group__delta__support.html',1,'']]],
  ['diffs_5',['Diffs',['../group__svn__wc__diffs.html',1,'']]],
  ['dirent_20fields_6',['Dirent fields',['../group__svn__dirent__fields.html',1,'']]],
  ['dumping_2c_20loading_20and_20verifying_20filesystem_20data_7',['Dumping, loading and verifying filesystem data',['../group__svn__repos__dump__load.html',1,'']]],
  ['dynamically_20query_20the_20server_27s_20capabilities_2e_8',['Dynamically query the server&apos;s capabilities.',['../group__Capabilities.html',1,'']]]
];
