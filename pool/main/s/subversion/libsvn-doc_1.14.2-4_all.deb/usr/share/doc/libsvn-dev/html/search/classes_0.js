var searchData=
[
  ['allocation_5ffailed_0',['allocation_failed',['../classapache_1_1subversion_1_1svnxx_1_1allocation__failed.html',1,'apache::subversion::svnxx']]]
];
