var searchData=
[
  ['show_20modification_20information_20about_20lines_20in_20a_20file_2e_0',['Show modification information about lines in a file.',['../group__Blame.html',1,'']]],
  ['show_20repository_20information_20about_20a_20working_20copy_2e_1',['Show repository information about a working copy.',['../group__Info.html',1,'']]],
  ['string_20handling_2',['String handling',['../group__svn__string.html',1,'']]],
  ['svn_2b_2b_20client_3',['SVN++ Client',['../group__svnxx__client.html',1,'']]],
  ['svn_2b_2b_20exceptions_4',['SVN++ Exceptions',['../group__svnxx__exceptions.html',1,'']]],
  ['svn_2b_2b_20implementation_20details_5',['SVN++ Implementation Details',['../group__svnxx__detail.html',1,'']]],
  ['svn_5fstring_5ft_20functions_6',['svn_string_t functions',['../group__svn__string__svn__string__t.html',1,'']]],
  ['svn_5fstringbuf_5ft_20functions_7',['svn_stringbuf_t functions',['../group__svn__string__svn__stringbuf__t.html',1,'']]],
  ['switch_20a_20working_20copy_20to_20a_20different_20repository_2e_8',['Switch a working copy to a different repository.',['../group__Relocate.html',1,'']]],
  ['switch_20a_20working_20copy_20to_20another_20location_2e_9',['Switch a working copy to another location.',['../group__Switch.html',1,'']]]
];
