var searchData=
[
  ['tuple_5fof_5ffunction_5finput_5farg_5ftypes_0',['tuple_of_function_input_arg_types',['../structsdbus_1_1tuple__of__function__input__arg__types.html',1,'sdbus']]],
  ['tuple_5fof_5ffunction_5foutput_5farg_5ftypes_1',['tuple_of_function_output_arg_types',['../structsdbus_1_1tuple__of__function__output__arg__types.html',1,'sdbus']]]
];
