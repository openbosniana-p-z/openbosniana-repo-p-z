var ProxyInterfaces_8h =
[
    [ "sdbus::ProxyObjectHolder", "classsdbus_1_1ProxyObjectHolder.html", null ],
    [ "sdbus::ProxyInterfaces< _Interfaces >", "classsdbus_1_1ProxyInterfaces.html", "classsdbus_1_1ProxyInterfaces" ]
];