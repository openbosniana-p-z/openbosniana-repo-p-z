var searchData=
[
  ['timeout_5fusec_0',['timeout_usec',['../structsdbus_1_1IConnection_1_1PollData.html#a68d5bfef63e5d69d1321ce37f6e38a02',1,'sdbus::IConnection::PollData']]]
];
