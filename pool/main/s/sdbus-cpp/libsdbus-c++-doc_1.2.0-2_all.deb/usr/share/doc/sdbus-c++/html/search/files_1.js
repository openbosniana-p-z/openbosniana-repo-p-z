var searchData=
[
  ['convenienceapiclasses_2eh_0',['ConvenienceApiClasses.h',['../ConvenienceApiClasses_8h.html',1,'']]],
  ['convenienceapiclasses_2einl_1',['ConvenienceApiClasses.inl',['../ConvenienceApiClasses_8inl.html',1,'']]]
];
