var searchData=
[
  ['setinterfaceflags_0',['setInterfaceFlags',['../classsdbus_1_1IObject.html#a0a2b953d5b344ee37121724331b13807',1,'sdbus::IObject::setInterfaceFlags(const std::string &amp;interfaceName, Flags flags)=0'],['../classsdbus_1_1IObject.html#abed87e74671ef65c61b8ef8f493d3b0f',1,'sdbus::IObject::setInterfaceFlags(const std::string &amp;interfaceName)']]],
  ['setmethodcalltimeout_1',['setMethodCallTimeout',['../classsdbus_1_1IConnection.html#a74b52622e5d60bc0b2f7f85c5d781e8c',1,'sdbus::IConnection::setMethodCallTimeout(uint64_t timeout)=0'],['../classsdbus_1_1IConnection.html#a3fe8ced14d121b3a86d2ba4f0e5119b8',1,'sdbus::IConnection::setMethodCallTimeout(const std::chrono::duration&lt; _Rep, _Period &gt; &amp;timeout)']]],
  ['setproperty_2',['setProperty',['../classsdbus_1_1IProxy.html#aab81f8ac427e0b8f163a57a6b8e23e50',1,'sdbus::IProxy']]]
];
