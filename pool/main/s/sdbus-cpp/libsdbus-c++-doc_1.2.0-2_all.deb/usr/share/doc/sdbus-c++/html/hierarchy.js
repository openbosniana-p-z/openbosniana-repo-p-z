var hierarchy =
[
    [ "sdbus::adopt_fd_t", "structsdbus_1_1adopt__fd__t.html", null ],
    [ "sdbus::adopt_message_t", "structsdbus_1_1adopt__message__t.html", null ],
    [ "sdbus::aggregate_signature< _Type >", "structsdbus_1_1aggregate__signature.html", null ],
    [ "sdbus::aggregate_signature< std::tuple< _Types... > >", "structsdbus_1_1aggregate__signature_3_01std_1_1tuple_3_01__Types_8_8_8_01_4_01_4.html", null ],
    [ "sdbus::function_traits_base< _ReturnType, _Args >::arg< _Idx >", "structsdbus_1_1function__traits__base_1_1arg.html", null ],
    [ "sdbus::AsyncMethodInvoker", "classsdbus_1_1AsyncMethodInvoker.html", null ],
    [ "sdbus::dont_request_slot_t", "structsdbus_1_1dont__request__slot__t.html", null ],
    [ "sdbus::Flags", "classsdbus_1_1Flags.html", null ],
    [ "sdbus::floating_slot_t", "structsdbus_1_1floating__slot__t.html", null ],
    [ "sdbus::function_traits< _Type >", "structsdbus_1_1function__traits.html", [
      [ "sdbus::function_traits< _Type & >", "structsdbus_1_1function__traits_3_01__Type_01_6_01_4.html", null ],
      [ "sdbus::function_traits< const _Type >", "structsdbus_1_1function__traits_3_01const_01__Type_01_4.html", null ]
    ] ],
    [ "sdbus::function_traits< FunctionType >", "structsdbus_1_1function__traits.html", [
      [ "sdbus::function_traits< std::function< FunctionType > >", "structsdbus_1_1function__traits_3_01std_1_1function_3_01FunctionType_01_4_01_4.html", null ]
    ] ],
    [ "sdbus::function_traits_base< _ReturnType, _Args >", "structsdbus_1_1function__traits__base.html", null ],
    [ "sdbus::function_traits_base< _ReturnType, _Args... >", "structsdbus_1_1function__traits__base.html", [
      [ "sdbus::function_traits< _ReturnType(_Args...)>", "structsdbus_1_1function__traits_3_01__ReturnType_07__Args_8_8_8_08_4.html", [
        [ "sdbus::function_traits< _ReturnType(*)(_Args...)>", "structsdbus_1_1function__traits_3_01__ReturnType_07_5_08_07__Args_8_8_8_08_4.html", null ],
        [ "sdbus::function_traits< _ReturnType(_ClassType::*)(_Args...) const >", "structsdbus_1_1function__traits_3_01__ReturnType_07__ClassType_1_1_5_08_07__Args_8_8_8_08_01const_01_4.html", null ],
        [ "sdbus::function_traits< _ReturnType(_ClassType::*)(_Args...) const volatile >", "structsdbus_1_1function__traits_3_01__ReturnType_07__ClassType_1_1_5_08_07__Args_8_8_8_08_01const_01volatile_01_4.html", null ],
        [ "sdbus::function_traits< _ReturnType(_ClassType::*)(_Args...) volatile >", "structsdbus_1_1function__traits_3_01__ReturnType_07__ClassType_1_1_5_08_07__Args_8_8_8_08_01volatile_01_4.html", null ],
        [ "sdbus::function_traits< _ReturnType(_ClassType::*)(_Args...)>", "structsdbus_1_1function__traits_3_01__ReturnType_07__ClassType_1_1_5_08_07__Args_8_8_8_08_4.html", null ]
      ] ]
    ] ],
    [ "sdbus::function_traits_base< std::tuple< _Results... >, _Args... >", "structsdbus_1_1function__traits__base.html", [
      [ "sdbus::function_traits< void(Result< _Results... > &&, _Args...)>", "structsdbus_1_1function__traits_3_01void_07Result_3_01__Results_8_8_8_01_4_01_6_6_00_01__Args_8_8_8_08_4.html", null ],
      [ "sdbus::function_traits< void(Result< _Results... >, _Args...)>", "structsdbus_1_1function__traits_3_01void_07Result_3_01__Results_8_8_8_01_4_00_01__Args_8_8_8_08_4.html", null ]
    ] ],
    [ "sdbus::function_traits_base< void, _Args... >", "structsdbus_1_1function__traits__base.html", [
      [ "sdbus::function_traits< void(const Error *, _Args...)>", "structsdbus_1_1function__traits_3_01void_07const_01Error_01_5_00_01__Args_8_8_8_08_4.html", null ]
    ] ],
    [ "sdbus::IConnection", "classsdbus_1_1IConnection.html", null ],
    [ "sdbus::InterfaceFlagsSetter", "classsdbus_1_1InterfaceFlagsSetter.html", null ],
    [ "sdbus::Introspectable_proxy", "classsdbus_1_1Introspectable__proxy.html", null ],
    [ "sdbus::IObject", "classsdbus_1_1IObject.html", null ],
    [ "sdbus::IProxy", "classsdbus_1_1IProxy.html", null ],
    [ "sdbus::ManagedObject_adaptor", "classsdbus_1_1ManagedObject__adaptor.html", null ],
    [ "sdbus::Message", "classsdbus_1_1Message.html", [
      [ "sdbus::MethodCall", "classsdbus_1_1MethodCall.html", null ],
      [ "sdbus::MethodReply", "classsdbus_1_1MethodReply.html", null ],
      [ "sdbus::PlainMessage", "classsdbus_1_1PlainMessage.html", null ],
      [ "sdbus::PropertyGetReply", "classsdbus_1_1PropertyGetReply.html", null ],
      [ "sdbus::PropertySetCall", "classsdbus_1_1PropertySetCall.html", null ],
      [ "sdbus::Signal", "classsdbus_1_1Signal.html", null ]
    ] ],
    [ "sdbus::MethodInvoker", "classsdbus_1_1MethodInvoker.html", null ],
    [ "sdbus::MethodRegistrator", "classsdbus_1_1MethodRegistrator.html", null ],
    [ "sdbus::ObjectHolder", "classsdbus_1_1ObjectHolder.html", [
      [ "sdbus::AdaptorInterfaces< _Interfaces >", "classsdbus_1_1AdaptorInterfaces.html", null ]
    ] ],
    [ "sdbus::ObjectManager_adaptor", "classsdbus_1_1ObjectManager__adaptor.html", null ],
    [ "sdbus::ObjectManager_proxy", "classsdbus_1_1ObjectManager__proxy.html", null ],
    [ "sdbus::Peer_proxy", "classsdbus_1_1Peer__proxy.html", null ],
    [ "sdbus::PendingAsyncCall", "classsdbus_1_1PendingAsyncCall.html", null ],
    [ "sdbus::IConnection::PollData", "structsdbus_1_1IConnection_1_1PollData.html", null ],
    [ "sdbus::Properties_adaptor", "classsdbus_1_1Properties__adaptor.html", null ],
    [ "sdbus::Properties_proxy", "classsdbus_1_1Properties__proxy.html", null ],
    [ "sdbus::PropertyGetter", "classsdbus_1_1PropertyGetter.html", null ],
    [ "sdbus::PropertyRegistrator", "classsdbus_1_1PropertyRegistrator.html", null ],
    [ "sdbus::PropertySetter", "classsdbus_1_1PropertySetter.html", null ],
    [ "sdbus::ProxyObjectHolder", "classsdbus_1_1ProxyObjectHolder.html", [
      [ "sdbus::ProxyInterfaces< _Interfaces >", "classsdbus_1_1ProxyInterfaces.html", null ]
    ] ],
    [ "sdbus::request_slot_t", "structsdbus_1_1request__slot__t.html", null ],
    [ "sdbus::Result< _Results >", "classsdbus_1_1Result.html", null ],
    [ "std::runtime_error", null, [
      [ "sdbus::Error", "classsdbus_1_1Error.html", null ]
    ] ],
    [ "sdbus::SignalEmitter", "classsdbus_1_1SignalEmitter.html", null ],
    [ "sdbus::SignalRegistrator", "classsdbus_1_1SignalRegistrator.html", null ],
    [ "sdbus::SignalSubscriber", "classsdbus_1_1SignalSubscriber.html", null ],
    [ "sdbus::SignalUnsubscriber", "classsdbus_1_1SignalUnsubscriber.html", null ],
    [ "sdbus::signature_of< _T >", "structsdbus_1_1signature__of.html", null ],
    [ "sdbus::signature_of< bool >", "structsdbus_1_1signature__of_3_01bool_01_4.html", null ],
    [ "sdbus::signature_of< char * >", "structsdbus_1_1signature__of_3_01char_01_5_01_4.html", null ],
    [ "sdbus::signature_of< char[_N]>", "structsdbus_1_1signature__of_3_01char_0f__N_0e_4.html", null ],
    [ "sdbus::signature_of< const char * >", "structsdbus_1_1signature__of_3_01const_01char_01_5_01_4.html", null ],
    [ "sdbus::signature_of< const char[_N]>", "structsdbus_1_1signature__of_3_01const_01char_0f__N_0e_4.html", null ],
    [ "sdbus::signature_of< double >", "structsdbus_1_1signature__of_3_01double_01_4.html", null ],
    [ "sdbus::signature_of< int16_t >", "structsdbus_1_1signature__of_3_01int16__t_01_4.html", null ],
    [ "sdbus::signature_of< int32_t >", "structsdbus_1_1signature__of_3_01int32__t_01_4.html", null ],
    [ "sdbus::signature_of< int64_t >", "structsdbus_1_1signature__of_3_01int64__t_01_4.html", null ],
    [ "sdbus::signature_of< ObjectPath >", "structsdbus_1_1signature__of_3_01ObjectPath_01_4.html", null ],
    [ "sdbus::signature_of< Signature >", "structsdbus_1_1signature__of_3_01Signature_01_4.html", null ],
    [ "sdbus::signature_of< std::map< _Key, _Value > >", "structsdbus_1_1signature__of_3_01std_1_1map_3_01__Key_00_01__Value_01_4_01_4.html", null ],
    [ "sdbus::signature_of< std::string >", "structsdbus_1_1signature__of_3_01std_1_1string_01_4.html", null ],
    [ "sdbus::signature_of< std::vector< _Element > >", "structsdbus_1_1signature__of_3_01std_1_1vector_3_01__Element_01_4_01_4.html", null ],
    [ "sdbus::signature_of< Struct< _ValueTypes... > >", "structsdbus_1_1signature__of_3_01Struct_3_01__ValueTypes_8_8_8_01_4_01_4.html", null ],
    [ "sdbus::signature_of< uint16_t >", "structsdbus_1_1signature__of_3_01uint16__t_01_4.html", null ],
    [ "sdbus::signature_of< uint32_t >", "structsdbus_1_1signature__of_3_01uint32__t_01_4.html", null ],
    [ "sdbus::signature_of< uint64_t >", "structsdbus_1_1signature__of_3_01uint64__t_01_4.html", null ],
    [ "sdbus::signature_of< uint8_t >", "structsdbus_1_1signature__of_3_01uint8__t_01_4.html", null ],
    [ "sdbus::signature_of< UnixFd >", "structsdbus_1_1signature__of_3_01UnixFd_01_4.html", null ],
    [ "sdbus::signature_of< Variant >", "structsdbus_1_1signature__of_3_01Variant_01_4.html", null ],
    [ "sdbus::signature_of< void >", "structsdbus_1_1signature__of_3_01void_01_4.html", null ],
    [ "sdbus::signature_of_function_input_arguments< _Function >", "structsdbus_1_1signature__of__function__input__arguments.html", null ],
    [ "sdbus::signature_of_function_output_arguments< _Function >", "structsdbus_1_1signature__of__function__output__arguments.html", null ],
    [ "std::string", null, [
      [ "sdbus::ObjectPath", "classsdbus_1_1ObjectPath.html", null ],
      [ "sdbus::Signature", "classsdbus_1_1Signature.html", null ]
    ] ],
    [ "std::tuple", null, [
      [ "sdbus::Struct< _ValueTypes >", "classsdbus_1_1Struct.html", null ]
    ] ],
    [ "sdbus::tuple_of_function_input_arg_types< _Function >", "structsdbus_1_1tuple__of__function__input__arg__types.html", null ],
    [ "sdbus::tuple_of_function_output_arg_types< _Function >", "structsdbus_1_1tuple__of__function__output__arg__types.html", null ],
    [ "sdbus::UnixFd", "classsdbus_1_1UnixFd.html", null ],
    [ "sdbus::Variant", "classsdbus_1_1Variant.html", null ],
    [ "sdbus::_Interfaces", null, [
      [ "sdbus::AdaptorInterfaces< _Interfaces >", "classsdbus_1_1AdaptorInterfaces.html", null ],
      [ "sdbus::ProxyInterfaces< _Interfaces >", "classsdbus_1_1ProxyInterfaces.html", null ]
    ] ]
];