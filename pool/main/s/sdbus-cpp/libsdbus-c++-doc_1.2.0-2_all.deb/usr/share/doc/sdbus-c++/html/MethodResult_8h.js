var MethodResult_8h =
[
    [ "sdbus::Result< _Results >", "classsdbus_1_1Result.html", null ]
];