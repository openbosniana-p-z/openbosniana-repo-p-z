var searchData=
[
  ['fd_0',['fd',['../structsdbus_1_1IConnection_1_1PollData.html#a7d51e88c0600c2a3b8860181d360fd42',1,'sdbus::IConnection::PollData']]]
];
