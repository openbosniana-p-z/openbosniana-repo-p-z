var searchData=
[
  ['leaveeventloop_0',['leaveEventLoop',['../classsdbus_1_1IConnection.html#a48552ac53ce040a7ad6e27af201a8805',1,'sdbus::IConnection']]],
  ['leaveprocessingloop_1',['leaveProcessingLoop',['../classsdbus_1_1IConnection.html#a0476ef587db5b3ae5b7024224efd9024',1,'sdbus::IConnection']]]
];
