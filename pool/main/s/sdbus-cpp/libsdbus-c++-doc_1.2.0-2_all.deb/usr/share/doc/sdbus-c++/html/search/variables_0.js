var searchData=
[
  ['events_0',['events',['../structsdbus_1_1IConnection_1_1PollData.html#a252fc9b3ea4b2764ff4f7dcb90b4debf',1,'sdbus::IConnection::PollData']]]
];
