var AdaptorInterfaces_8h =
[
    [ "sdbus::ObjectHolder", "classsdbus_1_1ObjectHolder.html", null ],
    [ "sdbus::AdaptorInterfaces< _Interfaces >", "classsdbus_1_1AdaptorInterfaces.html", "classsdbus_1_1AdaptorInterfaces" ]
];