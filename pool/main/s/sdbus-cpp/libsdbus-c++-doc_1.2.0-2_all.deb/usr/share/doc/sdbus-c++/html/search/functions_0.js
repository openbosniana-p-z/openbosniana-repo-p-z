var searchData=
[
  ['adaptorinterfaces_0',['AdaptorInterfaces',['../classsdbus_1_1AdaptorInterfaces.html#a9e4582d829372d928909596c5b549480',1,'sdbus::AdaptorInterfaces']]],
  ['addmatch_1',['addMatch',['../classsdbus_1_1IConnection.html#ae13623f4243935484b9b7d3ea795285e',1,'sdbus::IConnection::addMatch(const std::string &amp;match, message_handler callback)=0'],['../classsdbus_1_1IConnection.html#aa2c43ceea0e5d4c720a94b50d6e447ff',1,'sdbus::IConnection::addMatch(const std::string &amp;match, message_handler callback, floating_slot_t)=0']]],
  ['addobjectmanager_2',['addObjectManager',['../classsdbus_1_1IConnection.html#a5f883268beb522dd14448ab0e5aaa340',1,'sdbus::IConnection::addObjectManager(const std::string &amp;objectPath)=0'],['../classsdbus_1_1IConnection.html#a8c90ad6cf31563ab1430d4440265829a',1,'sdbus::IConnection::addObjectManager(const std::string &amp;objectPath, floating_slot_t)=0'],['../classsdbus_1_1IObject.html#ad2984e4df331b1854e7ded696a9ad656',1,'sdbus::IObject::addObjectManager()']]]
];
