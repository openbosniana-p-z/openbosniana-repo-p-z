var ConvenienceApiClasses_8h =
[
    [ "sdbus::MethodRegistrator", "classsdbus_1_1MethodRegistrator.html", null ],
    [ "sdbus::SignalRegistrator", "classsdbus_1_1SignalRegistrator.html", null ],
    [ "sdbus::PropertyRegistrator", "classsdbus_1_1PropertyRegistrator.html", null ],
    [ "sdbus::InterfaceFlagsSetter", "classsdbus_1_1InterfaceFlagsSetter.html", null ],
    [ "sdbus::SignalEmitter", "classsdbus_1_1SignalEmitter.html", null ],
    [ "sdbus::MethodInvoker", "classsdbus_1_1MethodInvoker.html", null ],
    [ "sdbus::AsyncMethodInvoker", "classsdbus_1_1AsyncMethodInvoker.html", null ],
    [ "sdbus::SignalSubscriber", "classsdbus_1_1SignalSubscriber.html", null ],
    [ "sdbus::SignalUnsubscriber", "classsdbus_1_1SignalUnsubscriber.html", null ],
    [ "sdbus::PropertyGetter", "classsdbus_1_1PropertyGetter.html", null ],
    [ "sdbus::PropertySetter", "classsdbus_1_1PropertySetter.html", null ]
];