var searchData=
[
  ['unixfd_0',['UnixFd',['../classsdbus_1_1UnixFd.html',1,'sdbus']]]
];
