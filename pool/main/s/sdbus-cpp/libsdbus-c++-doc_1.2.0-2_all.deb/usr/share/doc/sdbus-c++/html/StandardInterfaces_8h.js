var StandardInterfaces_8h =
[
    [ "sdbus::Peer_proxy", "classsdbus_1_1Peer__proxy.html", null ],
    [ "sdbus::Introspectable_proxy", "classsdbus_1_1Introspectable__proxy.html", null ],
    [ "sdbus::Properties_proxy", "classsdbus_1_1Properties__proxy.html", null ],
    [ "sdbus::ObjectManager_proxy", "classsdbus_1_1ObjectManager__proxy.html", null ],
    [ "sdbus::Properties_adaptor", "classsdbus_1_1Properties__adaptor.html", null ],
    [ "sdbus::ObjectManager_adaptor", "classsdbus_1_1ObjectManager__adaptor.html", null ],
    [ "sdbus::ManagedObject_adaptor", "classsdbus_1_1ManagedObject__adaptor.html", "classsdbus_1_1ManagedObject__adaptor" ]
];