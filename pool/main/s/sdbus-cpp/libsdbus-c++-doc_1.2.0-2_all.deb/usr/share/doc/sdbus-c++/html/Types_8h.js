var Types_8h =
[
    [ "sdbus::Variant", "classsdbus_1_1Variant.html", null ],
    [ "sdbus::Struct< _ValueTypes >", "classsdbus_1_1Struct.html", null ],
    [ "sdbus::ObjectPath", "classsdbus_1_1ObjectPath.html", null ],
    [ "sdbus::Signature", "classsdbus_1_1Signature.html", null ],
    [ "sdbus::UnixFd", "classsdbus_1_1UnixFd.html", null ]
];