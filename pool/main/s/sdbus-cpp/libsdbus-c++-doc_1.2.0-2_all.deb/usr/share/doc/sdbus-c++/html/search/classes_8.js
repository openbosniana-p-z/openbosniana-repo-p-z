var searchData=
[
  ['request_5fslot_5ft_0',['request_slot_t',['../structsdbus_1_1request__slot__t.html',1,'sdbus']]],
  ['result_1',['Result',['../classsdbus_1_1Result.html',1,'sdbus']]]
];
