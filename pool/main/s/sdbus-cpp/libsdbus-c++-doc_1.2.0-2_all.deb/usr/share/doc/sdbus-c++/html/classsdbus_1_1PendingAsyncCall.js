var classsdbus_1_1PendingAsyncCall =
[
    [ "cancel", "classsdbus_1_1PendingAsyncCall.html#a0a479c1499a142825f10a5e1c6313720", null ],
    [ "isPending", "classsdbus_1_1PendingAsyncCall.html#adc36917407ac34a6bfb0652f0849402b", null ]
];