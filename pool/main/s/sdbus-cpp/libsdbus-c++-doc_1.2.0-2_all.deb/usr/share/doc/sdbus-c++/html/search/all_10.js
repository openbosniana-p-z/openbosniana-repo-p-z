var searchData=
[
  ['variant_0',['Variant',['../classsdbus_1_1Variant.html',1,'sdbus']]]
];
