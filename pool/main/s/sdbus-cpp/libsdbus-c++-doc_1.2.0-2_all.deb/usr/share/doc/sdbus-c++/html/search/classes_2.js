var searchData=
[
  ['error_0',['Error',['../classsdbus_1_1Error.html',1,'sdbus']]]
];
