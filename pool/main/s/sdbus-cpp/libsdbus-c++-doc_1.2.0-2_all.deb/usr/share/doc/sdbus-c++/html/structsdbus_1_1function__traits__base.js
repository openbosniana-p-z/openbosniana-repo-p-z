var structsdbus_1_1function__traits__base =
[
    [ "arg", "structsdbus_1_1function__traits__base_1_1arg.html", null ]
];