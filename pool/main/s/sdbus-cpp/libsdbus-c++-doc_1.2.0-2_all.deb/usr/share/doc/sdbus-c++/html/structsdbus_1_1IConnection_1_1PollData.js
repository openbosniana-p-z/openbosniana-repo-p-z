var structsdbus_1_1IConnection_1_1PollData =
[
    [ "getAbsoluteTimeout", "structsdbus_1_1IConnection_1_1PollData.html#ab7ab21d7e1ee3625a55f502ebf6a798f", null ],
    [ "getPollTimeout", "structsdbus_1_1IConnection_1_1PollData.html#a73e9ba9d09dcdd721a419e351987e481", null ],
    [ "getRelativeTimeout", "structsdbus_1_1IConnection_1_1PollData.html#a5ea4d7a5343c5991f2112b651fb153b3", null ],
    [ "events", "structsdbus_1_1IConnection_1_1PollData.html#a252fc9b3ea4b2764ff4f7dcb90b4debf", null ],
    [ "fd", "structsdbus_1_1IConnection_1_1PollData.html#a7d51e88c0600c2a3b8860181d360fd42", null ],
    [ "timeout_usec", "structsdbus_1_1IConnection_1_1PollData.html#a68d5bfef63e5d69d1321ce37f6e38a02", null ]
];