var IConnection_8h =
[
    [ "sdbus::IConnection", "classsdbus_1_1IConnection.html", "classsdbus_1_1IConnection" ],
    [ "sdbus::IConnection::PollData", "structsdbus_1_1IConnection_1_1PollData.html", "structsdbus_1_1IConnection_1_1PollData" ],
    [ "createConnection", "IConnection_8h.html#af97a3568a21aba8df3a0c05a9d3b2f34", null ],
    [ "createConnection", "IConnection_8h.html#ace7f66e6c46d6fe02e800a7f3f2e2901", null ],
    [ "createDefaultBusConnection", "IConnection_8h.html#a324a57f39501ac6e4dd0f21211f62add", null ],
    [ "createDefaultBusConnection", "IConnection_8h.html#a3426ed2a74515a0e355444b7b129424d", null ],
    [ "createRemoteSystemBusConnection", "IConnection_8h.html#a803551c47da11b5d137c2b7132453828", null ],
    [ "createSessionBusConnection", "IConnection_8h.html#a0b7b34085806849eca7151684834734a", null ],
    [ "createSessionBusConnection", "IConnection_8h.html#a16396a6e7775b4e15af05d71e38627ec", null ],
    [ "createSessionBusConnectionWithAddress", "IConnection_8h.html#a2bb69db85ee48bdaa3419b09a254ed7a", null ],
    [ "createSystemBusConnection", "IConnection_8h.html#a0f668f4cca77b73dfd425a2123b596cf", null ],
    [ "createSystemBusConnection", "IConnection_8h.html#a5d93648918323e02185819a0e772a3c6", null ]
];