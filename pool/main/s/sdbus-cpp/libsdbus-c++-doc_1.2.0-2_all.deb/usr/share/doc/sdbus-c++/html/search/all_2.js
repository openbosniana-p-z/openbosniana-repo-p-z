var searchData=
[
  ['deprecated_20list_0',['Deprecated List',['../deprecated.html',1,'']]],
  ['dont_5frequest_5fslot_5ft_1',['dont_request_slot_t',['../structsdbus_1_1dont__request__slot__t.html',1,'sdbus']]]
];
