int global;

int main(void) {
	global = 5;
	return 0;
}
