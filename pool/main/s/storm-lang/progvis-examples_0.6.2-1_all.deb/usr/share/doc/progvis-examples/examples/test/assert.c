int main(void) {
	int i = 1;
	assert(i == 0, "Error");

	return 0;
}
