int main(void) {
	if(true){
		printf("A");
	}else{
		printf("B");
	}

	if(false)printf("A");
	else printf("B");

	int elsefoo;
	if(false)printf("C");
	elsefoo;
	return 0;
}
