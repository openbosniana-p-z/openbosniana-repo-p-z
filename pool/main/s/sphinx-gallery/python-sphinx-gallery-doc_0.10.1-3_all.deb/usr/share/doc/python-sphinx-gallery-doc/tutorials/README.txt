.. _notebook_examples:

Notebook style example
======================

You can have multiple galleries, each one for different uses. For example,
one gallery of examples and a different gallery for tutorials.

This gallery demonstrates the ability of Sphinx-Gallery to transform a file
with a Jupyter notebook style structure (i.e., with alternating text and code).
