.. _mayavi-examples-index:

Gallery of Examples using Mayavi
================================


.. _general_mayavi_examples:

Mayavi examples
---------------

Examples from the Sphinx-Gallery using Mayavi for embedding 3d plots.
