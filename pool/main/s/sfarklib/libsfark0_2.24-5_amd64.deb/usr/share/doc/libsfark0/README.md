sfArkLib
========

Library for decompressing sfArk soundfonts.

A simple command-line tool to convert sfArk files to sf2
based on this library can be found at https://github.com/raboof/sfArkXTm

Building
========

    $ make
    $ sudo make install
    $ sudo ldconfig

