Boost.Parameter [has bug](https://github.com/boostorg/parameter/issues/91)
since 1.71.0 that causes SVG++ [compilation error](https://github.com/svgpp/svgpp/issues/79).

Here is the branched Boost.Parameter 1.70.0 moved to `exboost` namespace.
