//===- SkypatNamespace.h --------------------------------------------------===//
//
//                              The SkyPat team 
//
// This file is distributed under the New BSD License.
// See LICENSE for details.
//
//===----------------------------------------------------------------------===//
#ifndef SKYPAT_SKYPAT_NAMESPACE_H
#define SKYPAT_SKYPAT_NAMESPACE_H

namespace skypat {

typedef void * HANDLE;

} // namespace of skypat

#endif
