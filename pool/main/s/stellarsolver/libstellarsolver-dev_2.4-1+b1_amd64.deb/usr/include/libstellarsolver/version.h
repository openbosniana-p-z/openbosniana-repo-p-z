/* Version information */
#define StellarSolver_VERSION "2.4"

/* Build TS */
#define StellarSolver_BUILD_TS "2022-12-20T20:39:53Z"
