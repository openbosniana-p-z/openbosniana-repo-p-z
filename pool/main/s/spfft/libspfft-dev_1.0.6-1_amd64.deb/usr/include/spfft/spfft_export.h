
#ifndef SPFFT_EXPORT_H
#define SPFFT_EXPORT_H

#ifdef SPFFT_STATIC_DEFINE
#  define SPFFT_EXPORT
#  define SPFFT_NO_EXPORT
#else
#  ifndef SPFFT_EXPORT
#    ifdef spfft_EXPORTS
        /* We are building this library */
#      define SPFFT_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define SPFFT_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef SPFFT_NO_EXPORT
#    define SPFFT_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef SPFFT_DEPRECATED
#  define SPFFT_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef SPFFT_DEPRECATED_EXPORT
#  define SPFFT_DEPRECATED_EXPORT SPFFT_EXPORT SPFFT_DEPRECATED
#endif

#ifndef SPFFT_DEPRECATED_NO_EXPORT
#  define SPFFT_DEPRECATED_NO_EXPORT SPFFT_NO_EXPORT SPFFT_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef SPFFT_NO_DEPRECATED
#    define SPFFT_NO_DEPRECATED
#  endif
#endif

#endif /* SPFFT_EXPORT_H */
