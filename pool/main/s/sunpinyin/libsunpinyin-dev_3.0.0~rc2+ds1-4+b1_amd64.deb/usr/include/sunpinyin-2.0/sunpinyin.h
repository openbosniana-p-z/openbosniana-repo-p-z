// -*- mode: c++ -*-
#ifndef ___SUNPINYIN_H___
#define ___SUNPINYIN_H___

#include <ime-core/imi_option_event.h>
#include <ime-core/imi_view.h>
#include <ime-core/imi_options.h>
#include <ime-core/imi_keys.h>
#include <ime-core/imi_option_keys.h>
#include <ime-core/imi_winHandler.h>
#include <ime-core/imi_uiobjects.h>

#endif

// -*- indent-tabs-mode: nil -*- vim:et:ts=4
