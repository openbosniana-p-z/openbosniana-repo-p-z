SunPinyin
===

SunPinyin is an SLM (Statistical Language Model) based input method
engine. To model the Chinese language, it uses a backoff bigram and
trigram language model.

Currently, SunPinyin 2.0 is available on IBus, SCIM, and as a
standalone XIM Server.

[![Build Status](https://travis-ci.org/sunpinyin/sunpinyin.svg?branch=master)](https://travis-ci.org/sunpinyin/sunpinyin)
