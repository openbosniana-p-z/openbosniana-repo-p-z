#ifndef PRIME_H
#define PRIME_H
/*****************************************
 * Computer Algebra System SINGULAR      *
 *****************************************/
/*
 *  simple prime test for int
 */

int IsPrime(int p);  /* brute force !!!! */
#endif
