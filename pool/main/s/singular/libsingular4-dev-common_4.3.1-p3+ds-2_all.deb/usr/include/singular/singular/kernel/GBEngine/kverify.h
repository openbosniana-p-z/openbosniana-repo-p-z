#ifndef KVERIFY_H
#define KVERIFY_H
#include "polys/simpleideals.h"
BOOLEAN kVerify1(ideal F, ideal Q); /* seriell*/
BOOLEAN kVerify2(ideal F, ideal Q); /* parallel */
#endif
