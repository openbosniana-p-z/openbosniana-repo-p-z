
#define HAVE_SYS_TIME_H
/* #undef HAVE_SYS_TIMEB_H */
#define HAVE_UNISTD_H 1


#define HAVE_GETTIMEOFDAY
/* #undef HAVE_GETLOCALTIME */
/* #undef HAVE_FTIME */
/* #undef HAVE_RINT */
#define HAVE_TIMEGM

#define HAVE_STD_ISNAN
#define HAVE_WORKING_STD_REGEX
/* #undef HAVE_WINDOWS_H */
#define HAVE_MKDTEMP
/* #undef HAVE_AL_EXT_H */
/* #undef HAVE_STD_INDEX_SEQUENCE */
/* #undef HAVE_STD_REMOVE_CV_T */
/* #undef HAVE_STD_REMOVE_CVREF_T */
/* #undef HAVE_STD_ENABLE_IF_T */
/* #undef HAVE_STD_BOOL_CONSTANT */

#define GCC_ATOMIC_BUILTINS_FOUND

#define SYSTEM_EXPAT
#define ENABLE_SOUND
/* #undef USE_AEONWAVE */
#define ENABLE_SIMD
/* #undef ENABLE_SIMD_CODE */
/* #undef ENABLE_GDAL */
