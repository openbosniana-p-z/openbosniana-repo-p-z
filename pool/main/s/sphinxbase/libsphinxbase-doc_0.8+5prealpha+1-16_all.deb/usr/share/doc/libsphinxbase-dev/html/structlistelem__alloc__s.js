var structlistelem__alloc__s =
[
    [ "blk_alloc", "structlistelem__alloc__s.html#ab96fd1e097105a34d6ae2e79ae8e2520", null ],
    [ "blocks", "structlistelem__alloc__s.html#a1216578b1d5416dc0a03c802cfa1def9", null ],
    [ "blocksize", "structlistelem__alloc__s.html#ada7b3fcd2f878e67e07e4bb185bb3015", null ],
    [ "elemsize", "structlistelem__alloc__s.html#a9e27c7163c45a43f8dfd667cbc014f49", null ],
    [ "freelist", "structlistelem__alloc__s.html#a2c3be8623c5bb2d4afb3ad888790a4eb", null ]
];