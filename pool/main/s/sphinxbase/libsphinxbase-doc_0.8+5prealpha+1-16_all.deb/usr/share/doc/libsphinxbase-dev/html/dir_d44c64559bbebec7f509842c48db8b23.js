var dir_d44c64559bbebec7f509842c48db8b23 =
[
    [ "android", "dir_035c76f7235f5f563d38e3ab90cb9716.html", "dir_035c76f7235f5f563d38e3ab90cb9716" ],
    [ "sphinxbase", "dir_e3d154c296a8e9be2797a4f81e9375b2.html", "dir_e3d154c296a8e9be2797a4f81e9375b2" ],
    [ "win32", "dir_626e1d022ece4ed819c63798cf035138.html", "dir_626e1d022ece4ed819c63798cf035138" ],
    [ "wince", "dir_62c6e5a1b0f237231e4a7e8e8a0f0425.html", "dir_62c6e5a1b0f237231e4a7e8e8a0f0425" ],
    [ "sphinx_config.h", "sphinx__config_8h_source.html", null ]
];