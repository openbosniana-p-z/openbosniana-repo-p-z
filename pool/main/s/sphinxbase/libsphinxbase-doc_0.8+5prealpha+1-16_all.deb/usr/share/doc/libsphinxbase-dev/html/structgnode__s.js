var structgnode__s =
[
    [ "next", "structgnode__s.html#a24798080e363f9ecf9f348022c582757", null ]
];