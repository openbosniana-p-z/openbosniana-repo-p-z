var structjsgf__s =
[
    [ "charset", "structjsgf__s.html#ac7cba2982a4c14503afbe1df5f208002", null ],
    [ "imports", "structjsgf__s.html#a7efd071684d4ef7f077b0b06ce7bbc78", null ],
    [ "links", "structjsgf__s.html#a6ee31bac19680f01c413969a75ad838a", null ],
    [ "locale", "structjsgf__s.html#a0423fa12efb23c307765d7d010908e0f", null ],
    [ "name", "structjsgf__s.html#ab418c438a9c7f7e8aee029f006897656", null ],
    [ "nstate", "structjsgf__s.html#a380c1b82e1bd776438303159e5129773", null ],
    [ "parent", "structjsgf__s.html#af05b28c1350c76d64539403791522128", null ],
    [ "rules", "structjsgf__s.html#af257160279ab56ffca65966aeac18ef9", null ],
    [ "rulestack", "structjsgf__s.html#a0980112df6f2f591e64158266eb04b69", null ],
    [ "searchpath", "structjsgf__s.html#aabb207f0909c661a831e5f931dd9f60e", null ],
    [ "version", "structjsgf__s.html#ad459d19b47134a9670ffa4e8c466c0df", null ]
];