var structjsgf__rhs__s =
[
    [ "alt", "structjsgf__rhs__s.html#ad07cf44d48798d86633b37e9e6e67ff5", null ],
    [ "atoms", "structjsgf__rhs__s.html#a53c517a31c83eb357764fb891bba7008", null ]
];