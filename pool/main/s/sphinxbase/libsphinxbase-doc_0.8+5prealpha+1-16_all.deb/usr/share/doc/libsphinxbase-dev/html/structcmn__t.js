var structcmn__t =
[
    [ "cmn_mean", "structcmn__t.html#aef0faa6cd93f1d9cf12659c5980aefd2", null ],
    [ "cmn_var", "structcmn__t.html#a72813f1c9423186f5bd66ecb39099eb5", null ],
    [ "nframe", "structcmn__t.html#a456cc3313e93fa3057b658fef64a0c53", null ],
    [ "sum", "structcmn__t.html#adb70819b1ca822d5a4ee6dc94b3b48e7", null ],
    [ "veclen", "structcmn__t.html#a10472e0ad9272f764b512ade43f37d69", null ]
];