var structngram__model__s =
[
    [ "classes", "structngram__model__s.html#a39384af3e6b53591d433436db011ac8d", null ],
    [ "flags", "structngram__model__s.html#ac609a2f867496d6ca719351d566db328", null ],
    [ "funcs", "structngram__model__s.html#ad3d9d8ad9773f958a89534220eda6fb9", null ],
    [ "lmath", "structngram__model__s.html#a2ca373109c651ac998b33153eb38fd95", null ],
    [ "log_wip", "structngram__model__s.html#a3d6bf5632760a16e52cb881d7010d774", null ],
    [ "log_zero", "structngram__model__s.html#a65425a599c4bcc4dda809d81149b8fc0", null ],
    [ "lw", "structngram__model__s.html#a76ea0c65b23de80091e7c602bdb43bde", null ],
    [ "n", "structngram__model__s.html#a3c87bc1b678662a2c8930b3b8c33a80f", null ],
    [ "n_1g_alloc", "structngram__model__s.html#a3e41109b30668bdfc077614c1ef49960", null ],
    [ "n_classes", "structngram__model__s.html#adeb914f8e9f011a5c960f5ee9cd33919", null ],
    [ "n_counts", "structngram__model__s.html#a710daed84ee676f79dcbf510fca238e8", null ],
    [ "n_words", "structngram__model__s.html#a74f85927ef0d5513a1e6c02d13864be3", null ],
    [ "refcount", "structngram__model__s.html#a3b14986e4dc40ccec1f7e206b7f41d06", null ],
    [ "tmp_wids", "structngram__model__s.html#a4f910ab2c18b0e68dce92816a27fb139", null ],
    [ "wid", "structngram__model__s.html#a75567419a8002ef6e916c81f5d9ee9ed", null ],
    [ "word_str", "structngram__model__s.html#ae625e779e340845f03fb3da164e93039", null ],
    [ "writable", "structngram__model__s.html#a78a3253febced2cae4732044da466ee6", null ]
];