var structjsgf__rule__stack__s =
[
    [ "entry", "structjsgf__rule__stack__s.html#a56107dc6cc50d45a5c1811785e8169b7", null ],
    [ "rule", "structjsgf__rule__stack__s.html#a5fd5facd2b790c949ef2efa80b07148a", null ]
];