var dir_60aae0458aa1ecc8feb93296b73d98ea =
[
    [ "_jsgf_scanner.l", "__jsgf__scanner_8l_source.html", null ],
    [ "fsg_model.c", "fsg__model_8c_source.html", null ],
    [ "jsgf.c", "jsgf_8c.html", "jsgf_8c" ],
    [ "jsgf_internal.h", "jsgf__internal_8h.html", "jsgf__internal_8h" ],
    [ "jsgf_scanner.c", "jsgf__scanner_8c_source.html", null ],
    [ "jsgf_scanner.h", "jsgf__scanner_8h_source.html", null ],
    [ "lm_trie.c", "lm__trie_8c_source.html", null ],
    [ "lm_trie.h", "lm__trie_8h_source.html", null ],
    [ "lm_trie_quant.c", "lm__trie__quant_8c_source.html", null ],
    [ "lm_trie_quant.h", "lm__trie__quant_8h_source.html", null ],
    [ "ngram_model.c", "ngram__model_8c_source.html", null ],
    [ "ngram_model_internal.h", "ngram__model__internal_8h_source.html", null ],
    [ "ngram_model_set.c", "ngram__model__set_8c.html", "ngram__model__set_8c" ],
    [ "ngram_model_set.h", "ngram__model__set_8h.html", "ngram__model__set_8h" ],
    [ "ngram_model_trie.c", "ngram__model__trie_8c_source.html", null ],
    [ "ngram_model_trie.h", "ngram__model__trie_8h_source.html", null ],
    [ "ngrams_raw.c", "ngrams__raw_8c_source.html", null ],
    [ "ngrams_raw.h", "ngrams__raw_8h_source.html", null ]
];