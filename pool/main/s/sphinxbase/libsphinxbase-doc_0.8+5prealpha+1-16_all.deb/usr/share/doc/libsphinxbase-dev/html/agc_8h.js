var agc_8h =
[
    [ "agc_s", "structagc__s.html", "structagc__s" ],
    [ "agc_t", "agc_8h.html#a5cd32209fe5e74ed52e93011ed38b22a", null ],
    [ "agc_type_t", "agc_8h.html#a5b94b552491115c4eae2ed0eef5bf9dc", null ],
    [ "agc_type_e", "agc_8h.html#aef1d2c7e32d37aa84d70c2f3675fc923", [
      [ "AGC_NONE", "agc_8h.html#aef1d2c7e32d37aa84d70c2f3675fc923aa99f202adc14c67d038a6f9b04cc1f54", null ],
      [ "AGC_MAX", "agc_8h.html#aef1d2c7e32d37aa84d70c2f3675fc923a8582bf61aafe07b9144ba2bcfcde4de7", null ],
      [ "AGC_EMAX", "agc_8h.html#aef1d2c7e32d37aa84d70c2f3675fc923a0af126cbfacfc3a07ce51623402c81f9", null ],
      [ "AGC_NOISE", "agc_8h.html#aef1d2c7e32d37aa84d70c2f3675fc923a98faaf4d5fa6901d0c627385f1eb4270", null ]
    ] ],
    [ "agc_emax", "agc_8h.html#ac2cdd4c519b46824c5b28c5b769b5ecd", null ],
    [ "agc_emax_get", "agc_8h.html#a7b439fb5d36250d09bb9d459c1e28ba5", null ],
    [ "agc_emax_set", "agc_8h.html#a4fd17f224b5d8f7bfcaa9389d11716eb", null ],
    [ "agc_emax_update", "agc_8h.html#af47b6004f2f963ae0019a67450b892c2", null ],
    [ "agc_free", "agc_8h.html#a6a050fc4b079be05b1946636d5d7f3aa", null ],
    [ "agc_get_threshold", "agc_8h.html#a77d0987174a1b3c6e8fcd63fe82f33ce", null ],
    [ "agc_init", "agc_8h.html#ad61dcf6277271680ec208f9804f7c2ea", null ],
    [ "agc_max", "agc_8h.html#a29a2a4dd80141af1c3476094c353b739", null ],
    [ "agc_noise", "agc_8h.html#ae65d4be1d74aea11b7e16e3777272d13", null ],
    [ "agc_set_threshold", "agc_8h.html#aaaa9e15f192c91ad64c343b7c6db6714", null ],
    [ "agc_type_from_str", "agc_8h.html#aebd0689591488378192e13f6d2646bc1", null ],
    [ "agc_type_str", "agc_8h.html#a6ea1b2b3d482cf08eb36084629503c80", null ]
];