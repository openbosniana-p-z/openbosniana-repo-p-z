var structagc__s =
[
    [ "max", "structagc__s.html#a6a55c54c76a2e0373a907d186b89fa8e", null ],
    [ "noise_thresh", "structagc__s.html#a4c896e65da00c79b77b23272474fcffc", null ],
    [ "obs_frame", "structagc__s.html#a5a6c2e967089085bd4f6020876bcb92a", null ],
    [ "obs_max", "structagc__s.html#a20c5289a6328895101e89cc3b418a1e4", null ],
    [ "obs_utt", "structagc__s.html#ae4ce95dcfb26c7f14ea316ac3ab202b2", null ]
];