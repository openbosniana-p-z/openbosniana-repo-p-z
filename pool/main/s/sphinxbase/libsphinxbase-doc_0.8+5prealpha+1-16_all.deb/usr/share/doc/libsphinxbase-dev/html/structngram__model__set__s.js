var structngram__model__set__s =
[
    [ "base", "structngram__model__set__s.html#a3b88f17aa148ceac4f32dd4cbf5f4f81", null ],
    [ "cur", "structngram__model__set__s.html#a031e7d7dcf1667f69e1cb980f45623cb", null ],
    [ "lms", "structngram__model__set__s.html#a862d4c4feb5a903101f4a0fdc5ba8a62", null ],
    [ "lweights", "structngram__model__set__s.html#a11068bb0029c788c506bec4507dd6d23", null ],
    [ "maphist", "structngram__model__set__s.html#af34ca232338c2d8c7dc8d13869ac09fd", null ],
    [ "n_models", "structngram__model__set__s.html#a6c28858d5631a9c9dbc7b2c9583f5c5a", null ],
    [ "names", "structngram__model__set__s.html#aff5e13c45decde4c5bf30d8aa2b1c7d9", null ],
    [ "widmap", "structngram__model__set__s.html#addebde44e2b7aa22dd82032c316fc962", null ]
];