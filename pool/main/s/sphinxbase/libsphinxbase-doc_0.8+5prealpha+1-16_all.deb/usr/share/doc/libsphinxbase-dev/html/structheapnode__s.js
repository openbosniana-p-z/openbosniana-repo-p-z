var structheapnode__s =
[
    [ "data", "structheapnode__s.html#a2cac1684dd94b922db98de988232efeb", null ],
    [ "l", "structheapnode__s.html#af25b6bfb16162294dd35851e04ad6c6b", null ],
    [ "nr", "structheapnode__s.html#ab5a21ee1a48ce5359bbcca1d416a51eb", null ],
    [ "r", "structheapnode__s.html#a92c30e27e1ccdbaea15f28aa49b0f7ea", null ],
    [ "val", "structheapnode__s.html#a02a74be7915860cf3fc436d5fed6fe7d", null ]
];