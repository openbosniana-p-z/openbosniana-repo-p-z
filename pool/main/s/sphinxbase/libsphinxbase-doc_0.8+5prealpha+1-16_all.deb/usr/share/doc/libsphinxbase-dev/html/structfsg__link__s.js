var structfsg__link__s =
[
    [ "logs2prob", "structfsg__link__s.html#a4bc31131cca140338254c43eada509dc", null ],
    [ "wid", "structfsg__link__s.html#a99b8eb916944d981adf2c492b8193d4e", null ]
];