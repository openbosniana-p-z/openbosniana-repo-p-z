var structjsgf__link__s =
[
    [ "atom", "structjsgf__link__s.html#a140a7cfbe76100928b9c7ea052435ca5", null ],
    [ "from", "structjsgf__link__s.html#a02f9b2bc3b98e802164e80d051923bb3", null ],
    [ "to", "structjsgf__link__s.html#a9da8ad9d87149f0cfca6ca815c581717", null ]
];