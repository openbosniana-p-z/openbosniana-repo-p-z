var structyy__buffer__state =
[
    [ "yy_bs_column", "structyy__buffer__state.html#a10c4fcd8be759e6bf11e6d3e8cdb0307", null ],
    [ "yy_bs_lineno", "structyy__buffer__state.html#a818e94bc9c766e683c60df1e9fd01199", null ]
];