var profile_8h =
[
    [ "pctr_t", "structpctr__t.html", "structpctr__t" ],
    [ "ptmr_t", "structptmr__t.html", "structptmr__t" ],
    [ "host_pclk", "profile_8h.html#a4315a0c6da4e9d3ef3c0ce264620ce28", null ],
    [ "pctr_free", "profile_8h.html#a90821b8f5c4593ead9f8ebea8ca6994c", null ],
    [ "pctr_increment", "profile_8h.html#a29e1c5d5f5b462d24a84204e532943fa", null ],
    [ "pctr_new", "profile_8h.html#a6cf86e967fbf7b683bbb50036fb9e815", null ],
    [ "pctr_print", "profile_8h.html#a4333e06af6db1fd806846c9f9b1f3f78", null ],
    [ "pctr_reset", "profile_8h.html#a7d072965099f09c49a58e3fd422c48f4", null ],
    [ "ptmr_init", "profile_8h.html#a5260d9143ed28fa82c2ab410abce6749", null ],
    [ "ptmr_print_all", "profile_8h.html#a08a625009ff1a5e2ee8aa02b53009f66", null ],
    [ "ptmr_reset", "profile_8h.html#a32b1bf9f877946fb455c493a6aa3613f", null ],
    [ "ptmr_reset_all", "profile_8h.html#a0aaa0953b76ae8c9947d6d982bbbd4a7", null ],
    [ "ptmr_start", "profile_8h.html#aada447eb3dc8c9ffb17fd7331ae671e7", null ],
    [ "ptmr_stop", "profile_8h.html#ade42334cf2db0bc8858ff966e55a4ffb", null ]
];