var structfsg__model__s =
[
    [ "altwords", "structfsg__model__s.html#adb51d840853d7ef3315bd833cddeb748", null ],
    [ "final_state", "structfsg__model__s.html#ada19c76db4f1fc89c8b5cd674ec865da", null ],
    [ "link_alloc", "structfsg__model__s.html#ac4e2a36305bbe62a5c7468588eb058b1", null ],
    [ "lmath", "structfsg__model__s.html#ab0b22dadb593ee1901829f89c4a47fe2", null ],
    [ "lw", "structfsg__model__s.html#aeaff529953d494b9891dbc0fdac8e97f", null ],
    [ "n_state", "structfsg__model__s.html#a80cdb0b5e7463221ce14135c9f5a3b01", null ],
    [ "n_word", "structfsg__model__s.html#a99ed2894f7690a960d11e1590d11a6b9", null ],
    [ "n_word_alloc", "structfsg__model__s.html#a329ae88c26111df8cd64657b46b9108f", null ],
    [ "name", "structfsg__model__s.html#ab23ae2c362f1a3b18bbe135b97dfb467", null ],
    [ "refcount", "structfsg__model__s.html#af329127556a42f6ea3b27f41a99a0b17", null ],
    [ "silwords", "structfsg__model__s.html#ab5709e67c1b7506ab024f2060d50331c", null ],
    [ "start_state", "structfsg__model__s.html#a4ff49da3938ecc236d45a68d009f97b9", null ],
    [ "trans", "structfsg__model__s.html#ac5cd4b72818b7a9f2dc543d6a6ac9cc7", null ],
    [ "vocab", "structfsg__model__s.html#a6bbfce2d672624d792ff964200a64031", null ]
];