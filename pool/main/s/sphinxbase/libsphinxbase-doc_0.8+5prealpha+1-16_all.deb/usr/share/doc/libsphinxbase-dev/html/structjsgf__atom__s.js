var structjsgf__atom__s =
[
    [ "name", "structjsgf__atom__s.html#ac7473e48f49258c5e5ef65bbb669b19e", null ],
    [ "tags", "structjsgf__atom__s.html#a4ecab128d84fd748efe52e338e7e2ecb", null ],
    [ "weight", "structjsgf__atom__s.html#a50672ba6d1e24c55bf8b58b97114effa", null ]
];