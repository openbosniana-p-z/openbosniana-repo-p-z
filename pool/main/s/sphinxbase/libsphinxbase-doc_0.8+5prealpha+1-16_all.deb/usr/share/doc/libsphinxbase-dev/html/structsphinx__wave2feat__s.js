var structsphinx__wave2feat__s =
[
    [ "audio", "structsphinx__wave2feat__s.html#a776c72734abe1e34162a5ee347f533e5", null ],
    [ "blocksize", "structsphinx__wave2feat__s.html#aff2646e41780ceb9dcd234c719fd25f1", null ],
    [ "byteswap", "structsphinx__wave2feat__s.html#a030717e2736fd04d1a281f51e5db2799", null ],
    [ "config", "structsphinx__wave2feat__s.html#a484d308befbde315664da8520ebc410d", null ],
    [ "fe", "structsphinx__wave2feat__s.html#a5882f148fe200890855304b46f00ee4b", null ],
    [ "feat", "structsphinx__wave2feat__s.html#ab43d8d5721133bcaf02da23c0bbb58ae", null ],
    [ "featsize", "structsphinx__wave2feat__s.html#ac041852de738a42752be67cceb16660c", null ],
    [ "in_veclen", "structsphinx__wave2feat__s.html#a3410a9e0c05c0057f31452550fb5380a", null ],
    [ "infh", "structsphinx__wave2feat__s.html#ad86834e597d4677aed93e7c06cebccb7", null ],
    [ "infile", "structsphinx__wave2feat__s.html#a6d4d1b1be4e3a3c1de82943e9e6fa65c", null ],
    [ "ot", "structsphinx__wave2feat__s.html#a929e05e041ad922f6a2e35637a98c917", null ],
    [ "outfh", "structsphinx__wave2feat__s.html#ad7340fab24fb182cbff2c73fd1fb3671", null ],
    [ "outfile", "structsphinx__wave2feat__s.html#aa50405dc75074933912da57295ec5fbf", null ],
    [ "refcount", "structsphinx__wave2feat__s.html#ae9b2fc4bfa6a3adbf2ee5a71796cdb51", null ],
    [ "veclen", "structsphinx__wave2feat__s.html#ad71e5fca7c13ae0258bcee81a6f1fa89", null ]
];