var structyyguts__t =
[
    [ "yy_buffer_stack", "structyyguts__t.html#ad0b9d576189d518a4482f20ed9b2a416", null ],
    [ "yy_buffer_stack_max", "structyyguts__t.html#a4435bb91e87f9988b096afc21386289a", null ],
    [ "yy_buffer_stack_top", "structyyguts__t.html#af92507d904af2fcd4509acde654a9850", null ]
];