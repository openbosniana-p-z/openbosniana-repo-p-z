var structarg__s =
[
    [ "deflt", "structarg__s.html#ab975459159f873ee06012460d16819c7", null ],
    [ "doc", "structarg__s.html#a706be2e230dea293579e4b03043550c0", null ],
    [ "name", "structarg__s.html#ac6c8fb7dc57cf2df9720cf96535043f9", null ],
    [ "type", "structarg__s.html#ad19743ceba37f2af159b255306bb8920", null ]
];