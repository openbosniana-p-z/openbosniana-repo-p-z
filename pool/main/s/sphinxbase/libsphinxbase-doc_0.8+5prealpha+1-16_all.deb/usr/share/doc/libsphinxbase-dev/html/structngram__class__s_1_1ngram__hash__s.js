var structngram__class__s_1_1ngram__hash__s =
[
    [ "next", "structngram__class__s_1_1ngram__hash__s.html#a88ede5798cadc2bece12c49fa038b090", null ],
    [ "prob1", "structngram__class__s_1_1ngram__hash__s.html#a6ac4c01b0c8d29f770f4780e38ab0923", null ],
    [ "wid", "structngram__class__s_1_1ngram__hash__s.html#ad0178b5a86ec23ce790b6b7cb64db0b9", null ]
];