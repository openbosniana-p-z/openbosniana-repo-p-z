var structngram__class__s =
[
    [ "ngram_hash_s", "structngram__class__s_1_1ngram__hash__s.html", "structngram__class__s_1_1ngram__hash__s" ],
    [ "n_hash", "structngram__class__s.html#a7f450019eb6dc2e31b18eb3ab6009920", null ],
    [ "n_hash_inuse", "structngram__class__s.html#a79438cd582363800bc05da31a9ca49d6", null ],
    [ "n_words", "structngram__class__s.html#af13562cbc44647435f315b18df5688dc", null ],
    [ "prob1", "structngram__class__s.html#a50077f48f135f1c666745a21574e4205", null ],
    [ "start_wid", "structngram__class__s.html#a370c88602c7c1f7e3ff1a767c027f5cb", null ],
    [ "tag_wid", "structngram__class__s.html#ab5f3cc0142c9fd91b3c3d0e59906b556", null ]
];