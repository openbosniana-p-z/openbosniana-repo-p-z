var case_8h =
[
    [ "LOWER_CASE", "case_8h.html#a44403ce2c3f4378aca12ffb732f24cef", null ],
    [ "UPPER_CASE", "case_8h.html#a3299c549655d5af1fcbc384ee7fd68e3", null ],
    [ "lcase", "case_8h.html#ac0e30dac40f15762f39270f65bd8cdba", null ],
    [ "strcmp_nocase", "case_8h.html#ad276a997bd6709d986aa6e1e4e06c210", null ],
    [ "strncmp_nocase", "case_8h.html#ae7c2a7f29d72b9516a947f5c69a043db", null ],
    [ "ucase", "case_8h.html#a79d99e36b7c2c36dcc6f7f0df746384e", null ]
];