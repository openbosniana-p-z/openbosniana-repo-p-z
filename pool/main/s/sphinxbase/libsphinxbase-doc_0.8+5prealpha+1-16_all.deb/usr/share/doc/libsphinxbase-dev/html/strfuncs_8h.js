var strfuncs_8h =
[
    [ "string_edge_e", "strfuncs_8h.html#ab5c9ca15770a4bd3047705762b815df9", [
      [ "STRING_START", "strfuncs_8h.html#ab5c9ca15770a4bd3047705762b815df9a5e4d73e6ca445be10fa48351b9571125", null ],
      [ "STRING_END", "strfuncs_8h.html#ab5c9ca15770a4bd3047705762b815df9a11f31598e50bf3cf1d0aa97d967bb9b9", null ],
      [ "STRING_BOTH", "strfuncs_8h.html#ab5c9ca15770a4bd3047705762b815df9a4fcbb0fe16fa4aa48723ba3ba10c26dd", null ]
    ] ],
    [ "atof_c", "strfuncs_8h.html#ab708351fe7308551632a782bfad75a1e", null ],
    [ "nextword", "strfuncs_8h.html#a41d9a59e4326b545bf1282401319f553", null ],
    [ "str2words", "strfuncs_8h.html#a5b520fdebcca599db86faaf75a82173f", null ],
    [ "string_join", "strfuncs_8h.html#a4fc6c9f6c763819b16c4e3307fb67cb1", null ],
    [ "string_trim", "strfuncs_8h.html#a46cec779df97c32fa432d4792722931d", null ]
];