var structptmr__t =
[
    [ "name", "structptmr__t.html#a73b51c5a047300d77b3a82a7dcaf44f1", null ],
    [ "start_cpu", "structptmr__t.html#a85c0c5f0e321cf11fb478b92a05223e8", null ],
    [ "start_elapsed", "structptmr__t.html#a1702b16a6c6bcb82f6c636f5e68af188", null ],
    [ "t_cpu", "structptmr__t.html#acbd784f7332329999925d396deae3a5d", null ],
    [ "t_elapsed", "structptmr__t.html#a743fce329d82fd7a9130cba5bbccd991", null ],
    [ "t_tot_cpu", "structptmr__t.html#a301d13acc21718143b8b39b7af8b6677", null ],
    [ "t_tot_elapsed", "structptmr__t.html#a2dc87aa035c8eb542279ca4496dd76f1", null ]
];