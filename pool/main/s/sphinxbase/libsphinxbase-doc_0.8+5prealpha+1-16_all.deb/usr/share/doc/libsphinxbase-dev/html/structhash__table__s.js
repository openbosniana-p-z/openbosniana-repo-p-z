var structhash__table__s =
[
    [ "inuse", "structhash__table__s.html#a8acfb3bc35dd96a9cf6f586dd105d878", null ],
    [ "nocase", "structhash__table__s.html#a1d1f5dbf52075c0424596ec492e2614d", null ],
    [ "size", "structhash__table__s.html#a28d173aa0ca9d9af764d4b2dc35dde07", null ]
];