var structngram__model__trie__s =
[
    [ "base", "structngram__model__trie__s.html#a9afbd810822df0ba51b693debf430bc7", null ],
    [ "trie", "structngram__model__trie__s.html#a2dc5840b57af65440a32f1d3166e0e60", null ]
];