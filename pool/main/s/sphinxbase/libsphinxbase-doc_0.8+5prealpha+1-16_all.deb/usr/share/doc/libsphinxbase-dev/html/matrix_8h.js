var matrix_8h =
[
    [ "accum_3d", "matrix_8h.html#abf02a99f3dac599148c0e1ee5640b568", null ],
    [ "band_nz_1d", "matrix_8h.html#a859d32f6b8e86fb215f676245c8deeaf", null ],
    [ "determinant", "matrix_8h.html#a0c810028195f6078c9e99f3b5c29c42b", null ],
    [ "floor_nz_1d", "matrix_8h.html#a0ec7000944b98cce317e0b63ce437b99", null ],
    [ "floor_nz_3d", "matrix_8h.html#a7b18b907fca64a8057f7406b8996d9c9", null ],
    [ "invert", "matrix_8h.html#aa20f437dbe9fcd6f0adda31f181bfbea", null ],
    [ "matrixadd", "matrix_8h.html#a545d251a51cc473bad38a83b2a05f61c", null ],
    [ "matrixmultiply", "matrix_8h.html#acaaf5d2c02d9d12f10abc462ac65cde9", null ],
    [ "norm_3d", "matrix_8h.html#af209fc89926fd184f5a02919ec7c9818", null ],
    [ "outerproduct", "matrix_8h.html#aa2d31d63ec277fd389d4ef51d3b2bc2b", null ],
    [ "scalarmultiply", "matrix_8h.html#adc8ee5f4e4792328e4f33309bc99ebfb", null ],
    [ "solve", "matrix_8h.html#a174a82dac39a15828af6c87edcba3708", null ]
];