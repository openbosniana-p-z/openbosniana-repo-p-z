var structyin__s =
[
    [ "diff_window", "structyin__s.html#a932e8441ff0aa6b9b37f5055c97a4d11", null ],
    [ "endut", "structyin__s.html#a61ca0fc8444a1bdde10aca37dc9f0f56", null ],
    [ "nfr", "structyin__s.html#af4f11d14a36bbdc19863fa8335237423", null ],
    [ "period_window", "structyin__s.html#a1928cec127e250f6cd15249085bc9fc8", null ],
    [ "search_range", "structyin__s.html#a208dfba1535fdd31962e687d82913dfd", null ],
    [ "search_threshold", "structyin__s.html#a8cca938167af6b504458ff9578420afd", null ],
    [ "wcur", "structyin__s.html#ab79376deb3761d5d3ae72f727ac25660", null ],
    [ "wsize", "structyin__s.html#a024d8e9d70f94a7f62457154fb5a4b03", null ],
    [ "wstart", "structyin__s.html#a18481851da6db4df2a469b80c2c5704e", null ]
];