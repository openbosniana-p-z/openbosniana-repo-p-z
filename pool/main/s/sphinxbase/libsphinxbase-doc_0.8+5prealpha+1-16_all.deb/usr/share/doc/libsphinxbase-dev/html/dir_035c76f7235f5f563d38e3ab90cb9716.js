var dir_035c76f7235f5f563d38e3ab90cb9716 =
[
    [ "config.h", "android_2config_8h_source.html", null ],
    [ "sphinx_config.h", "android_2sphinx__config_8h_source.html", null ]
];