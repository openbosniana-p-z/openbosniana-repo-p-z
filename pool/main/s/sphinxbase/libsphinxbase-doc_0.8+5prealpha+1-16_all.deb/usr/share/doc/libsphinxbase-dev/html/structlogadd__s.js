var structlogadd__s =
[
    [ "shift", "structlogadd__s.html#a4000a49e71ed2c09da4f34cb5ccaed4b", null ],
    [ "table", "structlogadd__s.html#a27793577d513d85cd73c2daffc140695", null ],
    [ "table_size", "structlogadd__s.html#a484c53a05b46d863d0456af679cee5d8", null ],
    [ "width", "structlogadd__s.html#a8e35a353d751d957270baf5192007c3e", null ]
];