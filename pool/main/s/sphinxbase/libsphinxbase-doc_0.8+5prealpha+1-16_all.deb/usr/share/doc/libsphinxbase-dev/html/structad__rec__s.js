var structad__rec__s =
[
    [ "bps", "structad__rec__s.html#a731523ef22607a580877bdcc563d9e5e", null ],
    [ "sps", "structad__rec__s.html#a2c5120af44acf19c5c7c63778bc932a3", null ]
];