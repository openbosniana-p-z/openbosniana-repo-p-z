var structpctr__t =
[
    [ "count", "structpctr__t.html#adc5e6467eceb66d4f56a20514d06eb55", null ],
    [ "name", "structpctr__t.html#a9674298e968c73272d477593c7b41ed5", null ]
];