var structngram__funcs__s =
[
    [ "add_ug", "structngram__funcs__s.html#aec7921e64c7cc778fa2267d6717482c3", null ],
    [ "apply_weights", "structngram__funcs__s.html#ae3cc072e20e6c1556c91b783ec061a4a", null ],
    [ "flush", "structngram__funcs__s.html#af1ab9c61d3b9fa4a4782b8df3089baa6", null ],
    [ "free", "structngram__funcs__s.html#ae13797f51aee31ddde0f150c1bbe1570", null ],
    [ "raw_score", "structngram__funcs__s.html#a9c9f83dc5151495a21b7eff16ad747d3", null ],
    [ "score", "structngram__funcs__s.html#ab74c094f1e88465559fdd29859bf4395", null ]
];