var err_8c =
[
    [ "err_get_debug_level", "err_8c.html#a393ad2383651d1fed0223c92208a6631", null ],
    [ "err_get_logfp", "err_8c.html#a028dd9600012527333ffc4ed9961e8a6", null ],
    [ "err_set_callback", "err_8c.html#ab9e9e148e2ab44b15a41a6e11a015c68", null ],
    [ "err_set_debug_level", "err_8c.html#ac7956e03cd685da5fe6e134c462f73e1", null ],
    [ "err_set_logfile", "err_8c.html#ad6ec7800ca74f21b9f8f69fcc765f30b", null ],
    [ "err_set_logfp", "err_8c.html#a1ed9de93e9eab18d18be6290b0b187e7", null ]
];