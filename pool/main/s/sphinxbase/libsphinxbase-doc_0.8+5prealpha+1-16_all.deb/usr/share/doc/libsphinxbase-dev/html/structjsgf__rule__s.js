var structjsgf__rule__s =
[
    [ "is_public", "structjsgf__rule__s.html#a36478d9850594d6a201c6724ec1f1fa4", null ],
    [ "name", "structjsgf__rule__s.html#a1b1de5afa4c0f27df4e8d51ebc47ca92", null ],
    [ "refcnt", "structjsgf__rule__s.html#aeb4c05f6daa425a37d362e2c6de1228e", null ],
    [ "rhs", "structjsgf__rule__s.html#a6923b74ad72f8b663cc00dfa99490981", null ]
];