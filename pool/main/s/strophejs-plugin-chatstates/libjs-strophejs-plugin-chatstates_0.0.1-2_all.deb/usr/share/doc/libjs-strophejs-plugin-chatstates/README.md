# XEP-0085: Chat State Notifications
This plugin implements [XEP-0085](http://xmpp.org/extensions/xep-0085.html).
