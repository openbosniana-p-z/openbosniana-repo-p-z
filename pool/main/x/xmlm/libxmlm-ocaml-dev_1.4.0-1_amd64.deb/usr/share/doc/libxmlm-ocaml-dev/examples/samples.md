* ftp://ftp.jclark.com/pub/xml/xmltest.zip
* http://www.ximpleware.com/xmls.zip
