/*
 *  This file records official patches. To: XPaint 2.2
 *
 *  $Id: patchlevel.h,v 1.17 2005/03/20 20:15:32 demailly Exp $
 */
#define PATCHLEVEL	0
