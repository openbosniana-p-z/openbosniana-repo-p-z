Xtables-addons
==============

Xtables-addons is a set of extensions that were not accepted in the
Linux kernel and/or main Xtables/iptables package.

It superseded the earlier patch-o-matic(-ng) package in that no
patching and/or recompilation of either the kernel or
Xtables/iptables is required. However, do see the INSTALL file for
the minimum requirements of Xtables-addons.


Included in this package
========================
* xt_ACCOUNT 1.16, libxt_ACCOUNT 1.3
