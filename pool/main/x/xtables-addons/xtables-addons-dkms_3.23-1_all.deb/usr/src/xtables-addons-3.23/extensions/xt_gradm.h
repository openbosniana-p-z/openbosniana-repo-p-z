#pragma once
struct xt_gradm_mtinfo {
	__u16 flags, invflags;
};
