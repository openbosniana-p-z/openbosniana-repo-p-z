#pragma once
struct xt_logmark_tginfo {
	char prefix[14];
	u_int8_t level;
};
