/*
 * $Id: uderrmsg.h,v 1.1 2000/08/07 23:15:04 emmerson Exp $
 *
 * $__Header$
 */

#ifndef UD_ERROR_H_INCLUDED
#define UD_ERROR_H_INCLUDED

#ifndef UD_FORTRAN_SOURCE

#include "udposix.h"

#if defined(__cplusplus) || defined(c_plusplus)
   extern "C" {
#endif

extern int	uderrmode	UD_PROTO((const int mode));
extern char*	uderrname	UD_PROTO((const char *name));
extern void	uderror		UD_PROTO((const char *fmt, ...));
extern int	udverror	();
extern void	udadvise	UD_PROTO((const char *fmt, ...));
extern int	udvadvise	();
extern char*	udtime_stamp	UD_PROTO((void));

#if defined(__cplusplus) || defined(c_plusplus)
   }
#endif

#endif	/* UD_FORTRAN_SOURCE not defined above */


/*
 * Global options variable. Used to control behavior of error handler.
 */
#define	UD_FATAL	1
#define	UD_VERBOSE	2


#endif	/* !UD_ERROR_H_INCLUDED */
