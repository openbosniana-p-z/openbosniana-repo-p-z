/*
 *	Copyright 1991 University Corporation for Atmospheric Research
 *	All rights reserved.
 *
 *	See file COPYRIGHT in the top-level source-directory for licensing
 *	conditions.
 */
/* $Id: inetutil.h,v 1.1 2000/08/07 23:15:03 emmerson Exp $ */

/* 
 * Miscellaneous functions to make dealing with internet addresses easier.
 */

#ifndef _INETUTIL_H_
#define _INETUTIL_H_

extern char *ghostname(/* void */) ;
extern char *hostbyaddr(/* struct sockaddr_in *paddr */) ;
extern int addrbyhost(/* char *hostname, struct sockpaddr_in *paddr */) ;
extern char *s_sockaddr_in(/* struct sockaddr_in *paddr */) ;
extern int gethostaddr_in(/* struct sockaddr_in *paddr */) ;
extern int getservport(/* char *servicename, char *proto */) ;
extern int usopen(/* char *name */) ;
extern int udpopen(/* char *hostname, char *servicename */) ;

#endif /* !_INETUTIL_H_ */
