/*
 * $Id: pathname.h,v 1.1 2000/08/07 23:15:04 emmerson Exp $
 *
 * (C) Copyright 1992 UCAR/Unidata
 *  
 * Permission to use, copy, modify, and distribute this software and
 * its documentation for any purpose without fee is hereby granted,
 * provided that the above copyright notice appear in all copies, that
 * both that copyright notice and this permission notice appear in
 * supporting documentation, and that the name of UCAR/Unidata not be
 * used in advertising or publicity pertaining to distribution of the
 * software without specific, written prior permission.  UCAR makes no
 * representations about the suitability of this software for any
 * purpose. It is provided "as is" without express or implied
 * warranty.  It is provided with no support and without obligation on
 * the part of UCAR or Unidata, to assist in its use, correction,
 * modification, or enhancement.
 * 
 * This file is the header-file for the UDAPE pathname utility functions.
 */

#ifdef	UD_FORTRAN_SOURCE
#   undef	PATHNAME_HEADER_SEEN
#endif

#ifndef	PATHNAME_HEADER_SEEN
#   define	PATHNAME_HEADER_SEEN

#   ifndef UD_FORTRAN_SOURCE

#	include "udposix.h"	/* for UD_EXTERN_FUNC() */

	/*
	 * C API:
	 */
	UD_EXTERN_FUNC(char *pnbase, (const char *pathname));
	UD_EXTERN_FUNC(char *pndir,  (const char *pathname));
	UD_EXTERN_FUNC(char *pnfile, (const char *pathname));

#endif	/* UD_FORTRAN_SOURCE was not define above */

#endif	/* PATHNAME_HEADER_SEEN was not defined above */
