This is a Tk interface to xxdiff contributed by Philippe Corbes.

From: Philippe Corbes <philippe.corbes@gmail.com>
To: blais@furius.ca
Date: Jun 16, 2007 9:39 AM
Subject: A tk interface for xxdiff



Bonjour martin,

J'ai codé une interface en tcl/tk pour xxdiff. Je pense que cela
manquait à xxdiff. L'interface est composée de 3 onglets: "Fichier",
"Repertoite" et " propos". On peut choisir l'onglet de demarrage et
initialiser jusqu'a 3 repertoires 'root'

J'espere que cette interface te convient.
N'hesite pas à me communiquer tes remarques.

A+
Philippe Corbes

2 attachments — Download all attachments
		tkxxdiff
9K Download
		GPL.txt
18K View Download

                                   
