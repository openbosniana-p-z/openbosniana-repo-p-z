#ifndef _SOURCE_M_DEPEND_H
#define _SOURCE_M_DEPEND_H 1
 
/* source/m-depend.h. Generated automatically at end of configure. */
/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Define to 1 if you have the `alarm' function. */
#ifndef LIBMDC_HAVE_ALARM
#define LIBMDC_HAVE_ALARM 1
#endif

/* Define to 1 if you have the <dlfcn.h> header file. */
#ifndef LIBMDC_HAVE_DLFCN_H
#define LIBMDC_HAVE_DLFCN_H 1
#endif

/* Define to 1 if you have the <inttypes.h> header file. */
#ifndef LIBMDC_HAVE_INTTYPES_H
#define LIBMDC_HAVE_INTTYPES_H 1
#endif

/* Define to 1 if you have the `isinf' function. */
#ifndef LIBMDC_HAVE_ISINF
#define LIBMDC_HAVE_ISINF 1
#endif

/* Define to 1 if you have the `isnan' function. */
#ifndef LIBMDC_HAVE_ISNAN
#define LIBMDC_HAVE_ISNAN 1
#endif

/* Define to 1 if you have the `m' library (-lm). */
#ifndef LIBMDC_HAVE_LIBM
#define LIBMDC_HAVE_LIBM 1
#endif

/* Define to 1 if you have the <limits.h> header file. */
#ifndef LIBMDC_HAVE_LIMITS_H
#define LIBMDC_HAVE_LIMITS_H 1
#endif

/* Define to 1 if you have the <locale.h> header file. */
#ifndef LIBMDC_HAVE_LOCALE_H
#define LIBMDC_HAVE_LOCALE_H 1
#endif

/* Define to 1 if you have the `localtime_r' function. */
#ifndef LIBMDC_HAVE_LOCALTIME_R
#define LIBMDC_HAVE_LOCALTIME_R 1
#endif

/* Define to 1 if your system has a GNU libc compatible `malloc' function, and
   to 0 otherwise. */
#ifndef LIBMDC_HAVE_MALLOC
#define LIBMDC_HAVE_MALLOC 1
#endif

/* Define to 1 if you have the `memset' function. */
#ifndef LIBMDC_HAVE_MEMSET
#define LIBMDC_HAVE_MEMSET 1
#endif

/* Define to 1 if you have the `modf' function. */
#ifndef LIBMDC_HAVE_MODF
#define LIBMDC_HAVE_MODF 1
#endif

/* Define to 1 if you have the `pow' function. */
#ifndef LIBMDC_HAVE_POW
#define LIBMDC_HAVE_POW 1
#endif

/* Define to 1 if your system has a GNU libc compatible `realloc' function,
   and to 0 otherwise. */
#ifndef LIBMDC_HAVE_REALLOC
#define LIBMDC_HAVE_REALLOC 1
#endif

/* Define to 1 if you have the `setlocale' function. */
#ifndef LIBMDC_HAVE_SETLOCALE
#define LIBMDC_HAVE_SETLOCALE 1
#endif

/* Define to 1 if you have the `sqrt' function. */
#ifndef LIBMDC_HAVE_SQRT
#define LIBMDC_HAVE_SQRT 1
#endif

/* Define to 1 if you have the <stdint.h> header file. */
#ifndef LIBMDC_HAVE_STDINT_H
#define LIBMDC_HAVE_STDINT_H 1
#endif

/* Define to 1 if you have the <stdio.h> header file. */
#ifndef LIBMDC_HAVE_STDIO_H
#define LIBMDC_HAVE_STDIO_H 1
#endif

/* Define to 1 if you have the <stdlib.h> header file. */
#ifndef LIBMDC_HAVE_STDLIB_H
#define LIBMDC_HAVE_STDLIB_H 1
#endif

/* Define to 1 if you have the `strcasecmp' function. */
#ifndef LIBMDC_HAVE_STRCASECMP
#define LIBMDC_HAVE_STRCASECMP 1
#endif

/* Define to 1 if you have the `strchr' function. */
#ifndef LIBMDC_HAVE_STRCHR
#define LIBMDC_HAVE_STRCHR 1
#endif

/* Define to 1 if you have the `strcspn' function. */
#ifndef LIBMDC_HAVE_STRCSPN
#define LIBMDC_HAVE_STRCSPN 1
#endif

/* Define to 1 if you have the `strdup' function. */
#ifndef LIBMDC_HAVE_STRDUP
#define LIBMDC_HAVE_STRDUP 1
#endif

/* Define to 1 if you have the <strings.h> header file. */
#ifndef LIBMDC_HAVE_STRINGS_H
#define LIBMDC_HAVE_STRINGS_H 1
#endif

/* Define to 1 if you have the <string.h> header file. */
#ifndef LIBMDC_HAVE_STRING_H
#define LIBMDC_HAVE_STRING_H 1
#endif

/* Define to 1 if you have the `strncasecmp' function. */
#ifndef LIBMDC_HAVE_STRNCASECMP
#define LIBMDC_HAVE_STRNCASECMP 1
#endif

/* Define to 1 if you have the `strptime' function. */
#ifndef LIBMDC_HAVE_STRPTIME
#define LIBMDC_HAVE_STRPTIME 1
#endif

/* Define to 1 if you have the `strrchr' function. */
#ifndef LIBMDC_HAVE_STRRCHR
#define LIBMDC_HAVE_STRRCHR 1
#endif

/* Define to 1 if you have the `strstr' function. */
#ifndef LIBMDC_HAVE_STRSTR
#define LIBMDC_HAVE_STRSTR 1
#endif

/* Define to 1 if you have the `strtol' function. */
#ifndef LIBMDC_HAVE_STRTOL
#define LIBMDC_HAVE_STRTOL 1
#endif

/* Define to 1 if you have the <sys/stat.h> header file. */
#ifndef LIBMDC_HAVE_SYS_STAT_H
#define LIBMDC_HAVE_SYS_STAT_H 1
#endif

/* Define to 1 if you have the <sys/time.h> header file. */
#ifndef LIBMDC_HAVE_SYS_TIME_H
#define LIBMDC_HAVE_SYS_TIME_H 1
#endif

/* Define to 1 if you have the <sys/types.h> header file. */
#ifndef LIBMDC_HAVE_SYS_TYPES_H
#define LIBMDC_HAVE_SYS_TYPES_H 1
#endif

/* Define to 1 if you have the <unistd.h> header file. */
#ifndef LIBMDC_HAVE_UNISTD_H
#define LIBMDC_HAVE_UNISTD_H 1
#endif

/* Define to 1 if the system has the type `_Bool'. */
#ifndef LIBMDC_HAVE__BOOL
#define LIBMDC_HAVE__BOOL 1
#endif

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#ifndef LIBMDC_LT_OBJDIR
#define LIBMDC_LT_OBJDIR ".libs/"
#endif

/* Name of package */
#ifndef LIBMDC_PACKAGE
#define LIBMDC_PACKAGE "xmedcon"
#endif

/* Define to the address where bug reports for this package should be sent. */
#ifndef LIBMDC_PACKAGE_BUGREPORT
#define LIBMDC_PACKAGE_BUGREPORT "enlf-at-users.sf.net"
#endif

/* Define to the full name of this package. */
#ifndef LIBMDC_PACKAGE_NAME
#define LIBMDC_PACKAGE_NAME "XMedCon"
#endif

/* Define to the full name and version of this package. */
#ifndef LIBMDC_PACKAGE_STRING
#define LIBMDC_PACKAGE_STRING "XMedCon 0.23.0"
#endif

/* Define to the one symbol short name of this package. */
#ifndef LIBMDC_PACKAGE_TARNAME
#define LIBMDC_PACKAGE_TARNAME "xmedcon"
#endif

/* Define to the home page for this package. */
#ifndef LIBMDC_PACKAGE_URL
#define LIBMDC_PACKAGE_URL "http://xmedcon.sf.net/"
#endif

/* Define to the version of this package. */
#ifndef LIBMDC_PACKAGE_VERSION
#define LIBMDC_PACKAGE_VERSION "0.23.0"
#endif

/* Define to 1 if all of the C90 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#ifndef LIBMDC_STDC_HEADERS
#define LIBMDC_STDC_HEADERS 1
#endif

/* Version number of package */
#ifndef LIBMDC_VERSION
#define LIBMDC_VERSION "0.23.0"
#endif

/* Define to empty if `const' does not conform to ANSI C. */
/* #undef const */

/* Define to rpl_malloc if the replacement function should be used. */
/* #undef malloc */

/* Define to rpl_realloc if the replacement function should be used. */
/* #undef realloc */

/* Define to `unsigned int' if <sys/types.h> does not define. */
/* #undef size_t */
 
/* once: _SOURCE_M_DEPEND_H */
#endif
