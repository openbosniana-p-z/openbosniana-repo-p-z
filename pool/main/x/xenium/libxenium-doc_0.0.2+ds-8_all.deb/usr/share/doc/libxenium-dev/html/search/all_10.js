var searchData=
[
  ['ramalhete_5fqueue_0',['ramalhete_queue',['../classxenium_1_1ramalhete__queue.html',1,'xenium']]],
  ['read_1',['read',['../structxenium_1_1left__right.html#a2eef8d5a06ea57eb3c9ca9ecee5f56e6',1,'xenium::left_right']]],
  ['reclaimer_2',['reclaimer',['../structxenium_1_1policy_1_1reclaimer.html',1,'xenium::policy']]],
  ['reclamation_20scheme_20interface_3',['Reclamation scheme interface',['../md_reclamation.html',1,'']]],
  ['region_5fextension_4',['region_extension',['../structxenium_1_1policy_1_1region__extension.html',1,'xenium::policy']]],
  ['reset_5',['reset',['../classxenium_1_1harris__michael__list__based__set_1_1iterator.html#ad6e94581072d7a801b72d13e6cb4cd33',1,'xenium::harris_michael_list_based_set::iterator::reset()'],['../classxenium_1_1marked__ptr.html#a841e1dfe722fc2ca5612a4c0d509baca',1,'xenium::marked_ptr::reset()'],['../classxenium_1_1vyukov__hash__map_1_1iterator.html#afcdff01676ca217aa35fcd5ea500f399',1,'xenium::vyukov_hash_map::iterator::reset()']]]
];
