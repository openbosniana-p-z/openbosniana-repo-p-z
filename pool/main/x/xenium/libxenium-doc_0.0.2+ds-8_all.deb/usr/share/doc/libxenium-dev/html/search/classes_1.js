var searchData=
[
  ['backoff_0',['backoff',['../structxenium_1_1policy_1_1backoff.html',1,'xenium::policy']]],
  ['bad_5fhazard_5fera_5falloc_1',['bad_hazard_era_alloc',['../classxenium_1_1reclamation_1_1bad__hazard__era__alloc.html',1,'xenium::reclamation']]],
  ['bad_5fhazard_5fpointer_5falloc_2',['bad_hazard_pointer_alloc',['../classxenium_1_1reclamation_1_1bad__hazard__pointer__alloc.html',1,'xenium::reclamation']]],
  ['buckets_3',['buckets',['../structxenium_1_1policy_1_1buckets.html',1,'xenium::policy']]]
];
