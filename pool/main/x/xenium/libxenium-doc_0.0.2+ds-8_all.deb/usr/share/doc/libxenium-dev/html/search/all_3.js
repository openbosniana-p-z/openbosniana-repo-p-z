var searchData=
[
  ['default_5fto_5fweak_0',['default_to_weak',['../structxenium_1_1policy_1_1default__to__weak.html',1,'xenium::policy']]],
  ['dynamic_5fstrategy_1',['dynamic_strategy',['../structxenium_1_1reclamation_1_1he__allocation_1_1dynamic__strategy.html',1,'xenium::reclamation::he_allocation::dynamic_strategy&lt; K, A, B &gt;'],['../structxenium_1_1reclamation_1_1hp__allocation_1_1dynamic__strategy.html',1,'xenium::reclamation::hp_allocation::dynamic_strategy&lt; K, A, B &gt;']]]
];
