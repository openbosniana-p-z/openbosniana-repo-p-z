var searchData=
[
  ['vyukov_5fbounded_5fqueue_0',['vyukov_bounded_queue',['../structxenium_1_1vyukov__bounded__queue.html#a7bc9f51a6d64fbc69f5c74ebaaae1018',1,'xenium::vyukov_bounded_queue']]]
];
