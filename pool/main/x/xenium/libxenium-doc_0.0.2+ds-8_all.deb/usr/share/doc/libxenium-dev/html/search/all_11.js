var searchData=
[
  ['scan_0',['scan',['../structxenium_1_1policy_1_1scan.html',1,'xenium::policy']]],
  ['scan_5ffrequency_1',['scan_frequency',['../structxenium_1_1policy_1_1scan__frequency.html',1,'xenium::policy']]],
  ['seqlock_2',['seqlock',['../structxenium_1_1seqlock.html#a8f211057efe62b6bf20e3708bfe6c8ba',1,'xenium::seqlock::seqlock()=default'],['../structxenium_1_1seqlock.html#ab9b85cd52f6f58f06c4db42b61e58983',1,'xenium::seqlock::seqlock(const T &amp;data)'],['../structxenium_1_1seqlock.html#a1949e19f35829139d579c798d9a85c2b',1,'xenium::seqlock::seqlock(Args &amp;&amp;... args)'],['../structxenium_1_1seqlock.html',1,'xenium::seqlock&lt; T, Policies &gt;']]],
  ['single_5fbackoff_3',['single_backoff',['../structxenium_1_1single__backoff.html',1,'xenium']]],
  ['slots_4',['slots',['../structxenium_1_1policy_1_1slots.html',1,'xenium::policy']]],
  ['stamp_5fit_5',['stamp_it',['../classxenium_1_1reclamation_1_1stamp__it.html',1,'xenium::reclamation']]],
  ['static_5fstrategy_6',['static_strategy',['../structxenium_1_1reclamation_1_1he__allocation_1_1static__strategy.html',1,'xenium::reclamation::he_allocation::static_strategy&lt; K, A, B &gt;'],['../structxenium_1_1reclamation_1_1hp__allocation_1_1static__strategy.html',1,'xenium::reclamation::hp_allocation::static_strategy&lt; K, A, B &gt;']]],
  ['store_7',['store',['../structxenium_1_1seqlock.html#a973c376a43966ce17c40edcc13542103',1,'xenium::seqlock']]]
];
