var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuvwx",
  1: "abcdeghiklmnopqrstvw",
  2: "x",
  3: "bcefglmoprstuv",
  4: "e",
  5: "w",
  6: "rx"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Pages"
};

