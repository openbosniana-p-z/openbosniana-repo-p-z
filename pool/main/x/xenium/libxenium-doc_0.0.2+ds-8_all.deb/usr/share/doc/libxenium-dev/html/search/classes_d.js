var searchData=
[
  ['padding_5fbytes_0',['padding_bytes',['../structxenium_1_1policy_1_1padding__bytes.html',1,'xenium::policy']]],
  ['pop_5fretries_1',['pop_retries',['../structxenium_1_1policy_1_1pop__retries.html',1,'xenium::policy']]]
];
