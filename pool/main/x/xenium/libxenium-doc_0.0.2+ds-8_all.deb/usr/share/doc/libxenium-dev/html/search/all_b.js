var searchData=
[
  ['managed_5fptr_0',['managed_ptr',['../structxenium_1_1managed__ptr.html',1,'xenium']]],
  ['map_5fto_5fbucket_1',['map_to_bucket',['../structxenium_1_1policy_1_1map__to__bucket.html',1,'xenium::policy']]],
  ['mark_2',['mark',['../classxenium_1_1marked__ptr.html#a34809db93adae798a79ac2d1faad9ce7',1,'xenium::marked_ptr']]],
  ['marked_5fptr_3',['marked_ptr',['../classxenium_1_1marked__ptr.html#a2be55baadca1238a5f69952fae140b5d',1,'xenium::marked_ptr::marked_ptr()'],['../classxenium_1_1marked__ptr.html',1,'xenium::marked_ptr&lt; T, MarkBits, MaxUpperMarkBits &gt;']]],
  ['memoize_5fhash_4',['memoize_hash',['../structxenium_1_1policy_1_1memoize__hash.html',1,'xenium::policy']]],
  ['michael_5fscott_5fqueue_5',['michael_scott_queue',['../classxenium_1_1michael__scott__queue.html',1,'xenium']]]
];
