var searchData=
[
  ['mark_0',['mark',['../classxenium_1_1marked__ptr.html#a34809db93adae798a79ac2d1faad9ce7',1,'xenium::marked_ptr']]],
  ['marked_5fptr_1',['marked_ptr',['../classxenium_1_1marked__ptr.html#a2be55baadca1238a5f69952fae140b5d',1,'xenium::marked_ptr']]]
];
