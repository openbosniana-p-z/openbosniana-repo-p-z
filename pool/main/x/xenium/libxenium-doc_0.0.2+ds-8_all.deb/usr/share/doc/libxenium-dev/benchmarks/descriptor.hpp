
#pragma once

#include "config.hpp"

#define DYNAMIC_PARAM "<dynamic>"

template <class T>
struct descriptor;

