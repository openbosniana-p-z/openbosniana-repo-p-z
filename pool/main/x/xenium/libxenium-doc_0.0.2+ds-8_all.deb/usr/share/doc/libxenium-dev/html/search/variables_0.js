var searchData=
[
  ['entry_5fsize_0',['entry_size',['../classxenium_1_1kirsch__bounded__kfifo__queue.html#a0afb7a74857862080b747baba1f3f0f1',1,'xenium::kirsch_bounded_kfifo_queue::entry_size()'],['../classxenium_1_1kirsch__kfifo__queue.html#a4805b227de19fca4c218494590d48a88',1,'xenium::kirsch_kfifo_queue::entry_size()']]]
];
