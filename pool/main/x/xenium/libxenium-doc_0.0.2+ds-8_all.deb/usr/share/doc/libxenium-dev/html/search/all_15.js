var searchData=
[
  ['when_5fexceeds_5fthreshold_0',['when_exceeds_threshold',['../structxenium_1_1reclamation_1_1abandon_1_1when__exceeds__threshold.html',1,'xenium::reclamation::abandon']]],
  ['with_1',['with',['../classxenium_1_1reclamation_1_1generic__epoch__based.html#a35adef0b163d71569d54cbd94c76e4ba',1,'xenium::reclamation::generic_epoch_based::with()'],['../classxenium_1_1reclamation_1_1hazard__eras.html#a85c8d89868f6a58ad913a21ede083525',1,'xenium::reclamation::hazard_eras::with()'],['../classxenium_1_1reclamation_1_1hazard__pointer.html#af200a4255aed231698546500e43e879a',1,'xenium::reclamation::hazard_pointer::with()']]]
];
