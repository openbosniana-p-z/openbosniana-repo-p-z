var searchData=
[
  ['quiescent_5fstate_5fbased_0',['quiescent_state_based',['../classxenium_1_1reclamation_1_1quiescent__state__based.html',1,'xenium::reclamation']]]
];
