var searchData=
[
  ['entries_5fper_5fnode_0',['entries_per_node',['../structxenium_1_1policy_1_1entries__per__node.html',1,'xenium::policy']]]
];
