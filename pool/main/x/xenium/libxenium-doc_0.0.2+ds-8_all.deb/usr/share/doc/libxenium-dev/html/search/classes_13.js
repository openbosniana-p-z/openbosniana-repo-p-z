var searchData=
[
  ['when_5fexceeds_5fthreshold_0',['when_exceeds_threshold',['../structxenium_1_1reclamation_1_1abandon_1_1when__exceeds__threshold.html',1,'xenium::reclamation::abandon']]]
];
