var searchData=
[
  ['ramalhete_5fqueue_0',['ramalhete_queue',['../classxenium_1_1ramalhete__queue.html',1,'xenium']]],
  ['reclaimer_1',['reclaimer',['../structxenium_1_1policy_1_1reclaimer.html',1,'xenium::policy']]],
  ['region_5fextension_2',['region_extension',['../structxenium_1_1policy_1_1region__extension.html',1,'xenium::policy']]]
];
