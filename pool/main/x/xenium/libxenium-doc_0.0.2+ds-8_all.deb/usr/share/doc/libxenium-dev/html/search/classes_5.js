var searchData=
[
  ['generic_5fepoch_5fbased_0',['generic_epoch_based',['../classxenium_1_1reclamation_1_1generic__epoch__based.html',1,'xenium::reclamation']]]
];
