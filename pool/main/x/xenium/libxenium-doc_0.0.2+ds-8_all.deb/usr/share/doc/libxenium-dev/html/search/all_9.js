var searchData=
[
  ['kirsch_5fbounded_5fkfifo_5fqueue_0',['kirsch_bounded_kfifo_queue',['../classxenium_1_1kirsch__bounded__kfifo__queue.html',1,'xenium']]],
  ['kirsch_5fkfifo_5fqueue_1',['kirsch_kfifo_queue',['../classxenium_1_1kirsch__kfifo__queue.html',1,'xenium']]]
];
