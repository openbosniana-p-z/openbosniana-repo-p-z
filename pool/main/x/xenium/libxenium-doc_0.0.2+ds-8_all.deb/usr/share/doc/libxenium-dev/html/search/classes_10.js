var searchData=
[
  ['scan_0',['scan',['../structxenium_1_1policy_1_1scan.html',1,'xenium::policy']]],
  ['scan_5ffrequency_1',['scan_frequency',['../structxenium_1_1policy_1_1scan__frequency.html',1,'xenium::policy']]],
  ['seqlock_2',['seqlock',['../structxenium_1_1seqlock.html',1,'xenium']]],
  ['single_5fbackoff_3',['single_backoff',['../structxenium_1_1single__backoff.html',1,'xenium']]],
  ['slots_4',['slots',['../structxenium_1_1policy_1_1slots.html',1,'xenium::policy']]],
  ['stamp_5fit_5',['stamp_it',['../classxenium_1_1reclamation_1_1stamp__it.html',1,'xenium::reclamation']]],
  ['static_5fstrategy_6',['static_strategy',['../structxenium_1_1reclamation_1_1he__allocation_1_1static__strategy.html',1,'xenium::reclamation::he_allocation::static_strategy&lt; K, A, B &gt;'],['../structxenium_1_1reclamation_1_1hp__allocation_1_1static__strategy.html',1,'xenium::reclamation::hp_allocation::static_strategy&lt; K, A, B &gt;']]]
];
