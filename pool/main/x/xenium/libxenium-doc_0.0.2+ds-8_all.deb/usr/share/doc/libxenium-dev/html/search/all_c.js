var searchData=
[
  ['n_5fthreads_0',['n_threads',['../structxenium_1_1reclamation_1_1scan_1_1n__threads.html',1,'xenium::reclamation::scan']]],
  ['never_1',['never',['../structxenium_1_1reclamation_1_1abandon_1_1never.html',1,'xenium::reclamation::abandon']]],
  ['no_5fbackoff_2',['no_backoff',['../structxenium_1_1no__backoff.html',1,'xenium']]]
];
