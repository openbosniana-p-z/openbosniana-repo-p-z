Flashtool
============

Flashtool is a software under a **GPLv3+** license used to flash Sony [Ericsson] phones that use the S1 protocol like Xperia line phones

![license GPLv3+](https://img.shields.io/badge/license-GPLv3+-green.svg)

WARNING about Xperia C4 and Xperia C5 : no support for those phones at the moment. I need contributors as I do not own those devices.

Please check http://www.flashtool.net for more informations
