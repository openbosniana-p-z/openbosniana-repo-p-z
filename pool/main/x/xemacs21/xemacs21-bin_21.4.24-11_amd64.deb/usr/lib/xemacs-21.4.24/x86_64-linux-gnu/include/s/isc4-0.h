/* Synched up with: FSF 19.31. */

#include "isc3-0.h"

#undef LIBS_SYSTEM
#define LIBS_SYSTEM "-linet -lcposix"

#define ISC4_0
