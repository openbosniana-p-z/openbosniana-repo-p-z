/* Synched up with: Not in FSF. */

/* For building XEmacs under SunOS 4.1.* with dynamic libraries. */

#ifdef NOT_C_CODE

#define LD_SWITCH_SYSTEM "-Bdynamic"

#endif /* NOT_C_CODE */

#include "sunos4-1.h"
