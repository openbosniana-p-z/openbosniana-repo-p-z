/* Synched up with: not in FSF. */

/* s/ file for BSDI BSD/OS 3.0 system. */

/* unlike BSD/OS 2.1, 3.0 does not require -lipc */
#include "bsdos2.h"
