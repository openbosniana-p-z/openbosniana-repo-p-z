#include "aix4-1.h"

#undef ALIGN_DATA_RELOC

