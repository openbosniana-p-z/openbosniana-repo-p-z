/* Synched up with: FSF 19.31. */

/* Interactive 386/ix.  */

#include "usg5-3.h"

#define BROKEN_TIOCGETC
