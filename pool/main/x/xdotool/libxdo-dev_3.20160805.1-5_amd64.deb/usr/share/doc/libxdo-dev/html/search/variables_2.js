var searchData=
[
  ['features_5fmask_187',['features_mask',['../structxdo.html#a2742a285cc59e82cdbc8c3167bb3e712',1,'xdo']]]
];
