var searchData=
[
  ['needs_5fbinding_15',['needs_binding',['../structcharcodemap.html#a965fff9ee5d43a112e233ba5278f954b',1,'charcodemap']]]
];
