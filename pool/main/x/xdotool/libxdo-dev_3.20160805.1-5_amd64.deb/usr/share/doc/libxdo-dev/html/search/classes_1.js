var searchData=
[
  ['dispatch_105',['dispatch',['../structdispatch.html',1,'']]]
];
