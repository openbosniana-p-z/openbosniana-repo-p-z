var searchData=
[
  ['xdpy_203',['xdpy',['../structxdo.html#a9d7679d2d36df521f575b9a0a0408915',1,'xdo']]]
];
