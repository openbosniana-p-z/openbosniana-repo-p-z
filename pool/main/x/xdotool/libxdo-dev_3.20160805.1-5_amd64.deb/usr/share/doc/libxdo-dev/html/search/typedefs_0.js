var searchData=
[
  ['xdo_5fsearch_5ft_204',['xdo_search_t',['../xdo_8h.html#a8f3b31033831735f8f36ff6f8461a270',1,'xdo.h']]],
  ['xdo_5ft_205',['xdo_t',['../xdo_8h.html#a1e7c4f872de6a3f51ae36ef7aade9d4a',1,'xdo.h']]]
];
