var searchData=
[
  ['close_5fdisplay_5fwhen_5ffreed_182',['close_display_when_freed',['../structxdo.html#a9b557baaaff741d3d33c991f3278e479',1,'xdo']]],
  ['code_183',['code',['../structcharcodemap.html#a7da121a8cb738ce073352a48a446b646',1,'charcodemap']]]
];
