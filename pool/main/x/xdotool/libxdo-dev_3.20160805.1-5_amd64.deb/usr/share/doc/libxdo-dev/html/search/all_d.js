var searchData=
[
  ['winclass_23',['winclass',['../structxdo__search.html#ac63f6c7e08c4f1ce7c3cedafe55047b9',1,'xdo_search']]],
  ['winclassname_24',['winclassname',['../structxdo__search.html#a605675534d38163215b9cd0dfbbd4c12',1,'xdo_search']]],
  ['windowmove_25',['windowmove',['../structwindowmove.html',1,'']]],
  ['winname_26',['winname',['../structxdo__search.html#af5263f13fa27b1ab4fcba53250b427af',1,'xdo_search']]]
];
