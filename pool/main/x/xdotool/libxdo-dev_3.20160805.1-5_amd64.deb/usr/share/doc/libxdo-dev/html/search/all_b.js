var searchData=
[
  ['require_19',['require',['../structxdo__search.html#a94edccd146cbbcf3c19bddf3078d0c40',1,'xdo_search']]]
];
