var searchData=
[
  ['screen_20',['screen',['../structxdo__search.html#a828a785966d37502a160c0c25ee2786f',1,'xdo_search']]],
  ['searchmask_21',['searchmask',['../structxdo__search.html#a9648155a21668da15263337b5a2c2128',1,'xdo_search']]],
  ['symbol_22',['symbol',['../structcharcodemap.html#a5c7c85b9dcf2a7e51caf782b6bfe4b33',1,'charcodemap']]]
];
