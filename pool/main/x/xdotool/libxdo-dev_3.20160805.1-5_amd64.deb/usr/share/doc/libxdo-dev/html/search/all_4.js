var searchData=
[
  ['group_10',['group',['../structcharcodemap.html#a15ca5158213e97a28cd19e5acbe9b57e',1,'charcodemap']]]
];
