var searchData=
[
  ['debug_184',['debug',['../structxdo.html#a1d47cdd17d3ba516fee2a04d34bc70a5',1,'xdo']]],
  ['desktop_185',['desktop',['../structxdo__search.html#a0786d5c36961a69ff22bb6d33841664e',1,'xdo_search']]],
  ['display_5fname_186',['display_name',['../structxdo.html#af3c5ec202f84465a7733579f6b5554b5',1,'xdo']]]
];
