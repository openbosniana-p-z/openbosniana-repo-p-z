// file      : xsd/cxx/compilers/vc-8/post.hxx
// copyright : Copyright (c) 2005-2014 Code Synthesis Tools CC
// license   : GNU GPL v2 + exceptions; see accompanying LICENSE file

#pragma warning (pop)
