pkgdatadir = '/usr/share/xrdesktop'
version = '0.15.1.'
