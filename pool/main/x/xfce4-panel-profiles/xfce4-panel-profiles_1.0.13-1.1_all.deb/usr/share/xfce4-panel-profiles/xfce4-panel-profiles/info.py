appname = 'xfce4-panel-profiles'
version = '1.0.13'
