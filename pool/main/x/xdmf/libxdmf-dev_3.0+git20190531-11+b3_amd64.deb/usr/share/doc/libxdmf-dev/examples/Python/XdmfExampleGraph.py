from Xdmf import *

if __name__ == "__main__":

        #//initialization begin

        exampleGraph = XdmfGraph.New()

        #//initialization end
