#include "XdmfDomain.hpp"

int main(int, char **)
{
        //#initialization begin

        shared_ptr<XdmfDomain> exampleDomain = XdmfDomain::New();

        //#initialization end

        return 0;
}
