from Xdmf import *

if __name__ == "__main__":

        #//initialization begin

        exampleDomain = XdmfDomain.New()

        #//initialization end
