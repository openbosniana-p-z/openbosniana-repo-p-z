from Xdmf import *

if __name__ == "__main__":
        #//getRealPath begin

        priorPath = "Path you want to convert"
        convertedPath = XdmfSystemUtils.getRealPath(priorPath)

        #//getRealPath end
