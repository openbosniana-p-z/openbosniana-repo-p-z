from Xdmf import *

if __name__ == "__main__":

        #//initialization begin

        exampleFactory = XdmfItemFactory.New()

        #//initialization end
