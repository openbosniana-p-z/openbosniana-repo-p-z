#include "XdmfDomain.hpp"

int main(int, char **)
{
        //#initialization begin

        shared_ptr<Xdmfreader> exampleReader = XdmfReader::New();

        //#initialization end

        return 0;
}
