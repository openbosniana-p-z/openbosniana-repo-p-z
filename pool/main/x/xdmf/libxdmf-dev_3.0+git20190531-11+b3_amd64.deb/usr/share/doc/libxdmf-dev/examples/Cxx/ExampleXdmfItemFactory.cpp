#include "XdmfItemFactory.hpp"

int main(int, char **)
{
        //#initialization begin

        shared_ptr<XdmfItemFactory> exampleFactory = XdmfItemFactory::New();

        //#initialization end

        return 0;
}
