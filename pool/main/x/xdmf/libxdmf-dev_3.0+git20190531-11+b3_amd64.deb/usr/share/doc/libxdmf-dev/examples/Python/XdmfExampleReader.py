from Xdmf import *

if __name__ == "__main__":

        #//initialization begin

        exampleReader = XdmfReader.New()

        #//initialization end
