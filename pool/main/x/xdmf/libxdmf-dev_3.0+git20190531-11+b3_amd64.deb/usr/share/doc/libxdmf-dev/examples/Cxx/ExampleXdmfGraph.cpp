#include "XdmfGraph.hpp"

int main(int, char **)
{
        //#initialization begin

        shared_ptr<XdmfGraph> exampleGraph = XdmfGraph::New();

        //#initialization end

        return 0;
}
