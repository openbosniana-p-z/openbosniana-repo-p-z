# CUDA kernels

This folder contains the CUDA kernels used by xpra's nvenc encoder
to handle colourspace conversion.

If this folder does not contain the *.fatbin kernel files,
then this build did not include nvenc or the kernels
and you will not be able to use the nvenc encoder.
