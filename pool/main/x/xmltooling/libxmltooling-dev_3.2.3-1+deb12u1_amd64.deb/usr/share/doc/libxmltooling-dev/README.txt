Release Notes
-----------
https://issues.shibboleth.net/jira/secure/ReleaseNote.jspa?projectId=10040

Documentation:
--------------
The OpenSAML wiki is the home for any documentation on the XMLTooling package.
https://wiki.shibboleth.net/confluence/display/OpenSAML/

Reporting Bugs:
---------------
A Jira instance is available.
https://issues.shibboleth.net/

Support:
--------
A mailing list is available.
https://wiki.shibboleth.net/confluence/display/OpenSAML/MailingList
