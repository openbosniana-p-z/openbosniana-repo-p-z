#!/usr/bin/env python3
# encoding: utf-8
# Thomas Nagy, 2005-2018 (ita)
