---
Vala Panel SNTray
---
Panel plugin to show StatusNotifierItems (also known as AppIndicators) for use with Vala Panel, xfce4-panel and mate-panel (Budgie 10.x is also planned). 

**REQUIRED DEPENDENCES**

 * GLib (>= 2.50.0)
 * GTK+ (>= 3.22.0)
 * valac (>= 0.24.0)
 
 *Special thanks:*
 snw-plugin by equiem (https://github.com/equeim/snw-plugin)

Author
===
 * Athor <ria.freelander@gmail.com>
