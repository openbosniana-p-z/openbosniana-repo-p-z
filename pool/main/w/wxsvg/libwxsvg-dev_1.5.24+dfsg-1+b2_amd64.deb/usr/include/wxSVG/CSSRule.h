//////////////////////////////////////////////////////////////////////////////
// Name:        CSSRule.h
// Author:      Alex Thuering
// Created:     2016/08/05
// Copyright:   (c) 2016 Alex Thuering
// Licence:     wxWindows licence
//////////////////////////////////////////////////////////////////////////////

#ifndef wxSVG_CSSRULE_H
#define wxSVG_CSSRULE_H

class wxCSSRule {
public:
	wxCSSRule() {}
};

#endif // wxSVG_CSSRULE_H
