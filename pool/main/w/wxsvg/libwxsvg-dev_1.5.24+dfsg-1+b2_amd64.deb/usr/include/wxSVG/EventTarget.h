//////////////////////////////////////////////////////////////////////////////
// Name:        EventTarget.h
// Purpose:     
// Author:      Alex Thuering
// Created:     2005/04/28
// RCS-ID:      $Id: EventTarget.h,v 1.1.1.1 2005/05/10 17:51:11 ntalex Exp $
// Copyright:   (c) 2005 Alex Thuering
// Licence:     wxWindows licence
//////////////////////////////////////////////////////////////////////////////

#ifndef wxSVG_EVENT_TARGET_H
#define wxSVG_EVENT_TARGET_H

struct wxEventTarget {};

#endif //wxSVG_EVENT_TARGET_H

