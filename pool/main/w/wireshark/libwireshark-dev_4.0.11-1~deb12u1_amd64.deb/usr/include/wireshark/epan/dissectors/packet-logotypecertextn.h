/* Do not modify this file. Changes will be overwritten.                      */
/* Generated automatically by the ASN.1 to Wireshark dissector compiler       */
/* packet-logotypecertextn.h                                                  */
/* asn2wrs.py -b -p logotypecertextn -c ./logotypecertextn.cnf -s ./packet-logotypecertextn-template -D . -O ../.. LogotypeCertExtn.asn */

/* Input file: packet-logotypecertextn-template.h */

#line 1 "./asn1/logotypecertextn/packet-logotypecertextn-template.h"
/* packet-logotypecertextn.h
 * Routines for RFC3907 Logotype Certificate Extensions packet dissection
 *    Ronnie Sahlberg 2004
 *
 * Wireshark - Network traffic analyzer
 * By Gerald Combs <gerald@wireshark.org>
 * Copyright 1998 Gerald Combs
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#ifndef PACKET_LOGOTYPE_CERT_EXTN_H
#define PACKET_LOGOTYPE_CERT_EXTN_H

/*#include "packet-logotypecertextn-exp.h"*/

#endif  /* PACKET_LOGOTYPE_CERT_EXTN_H */

