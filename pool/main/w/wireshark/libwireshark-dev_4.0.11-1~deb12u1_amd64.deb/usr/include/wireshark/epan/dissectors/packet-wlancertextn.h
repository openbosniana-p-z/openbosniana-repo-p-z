/* Do not modify this file. Changes will be overwritten.                      */
/* Generated automatically by the ASN.1 to Wireshark dissector compiler       */
/* packet-wlancertextn.h                                                      */
/* asn2wrs.py -b -p wlancertextn -c ./wlancertextn.cnf -s ./packet-wlancertextn-template -D . -O ../.. WLANCERTEXTN.asn */

/* Input file: packet-wlancertextn-template.h */

#line 1 "./asn1/wlancertextn/packet-wlancertextn-template.h"
/* packet-wlancertextn.h
 * Routines for Wireless Certificate Extensions (RFC3770) packet dissection
 *  Ronnie Sahlberg 2005
 *
 * Wireshark - Network traffic analyzer
 * By Gerald Combs <gerald@wireshark.org>
 * Copyright 1998 Gerald Combs
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#ifndef PACKET_WLANCERTEXTN_H
#define PACKET_WLANCERTEXTN_H

/*#include "packet-wlancertextn-exp.h"*/

#endif  /* PACKET_WLANCERTEXTN_H */

