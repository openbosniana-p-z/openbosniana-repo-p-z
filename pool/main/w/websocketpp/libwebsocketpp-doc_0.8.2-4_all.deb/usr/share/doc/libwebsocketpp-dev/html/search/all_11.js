var searchData=
[
  ['uint16_5fconverter_585',['uint16_converter',['../unionwebsocketpp_1_1frame_1_1uint16__converter.html',1,'websocketpp::frame']]],
  ['uint32_5fconverter_586',['uint32_converter',['../unionwebsocketpp_1_1frame_1_1uint32__converter.html',1,'websocketpp::frame']]],
  ['uint64_5fconverter_587',['uint64_converter',['../unionwebsocketpp_1_1frame_1_1uint64__converter.html',1,'websocketpp::frame']]],
  ['uninitialized_588',['uninitialized',['../namespacewebsocketpp_1_1extensions_1_1permessage__deflate_1_1error.html#a38e53d7586dd60059cc99a5833bbe54eaa7d37064915d0ef64357e41763b42b7e',1,'websocketpp::extensions::permessage_deflate::error']]],
  ['unrequested_5fsubprotocol_589',['unrequested_subprotocol',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68da1c2d766aa9dc1b43d4af8dac9d7de2e0',1,'websocketpp::error']]],
  ['unsupported_5fattributes_590',['unsupported_attributes',['../namespacewebsocketpp_1_1extensions_1_1permessage__deflate_1_1error.html#a38e53d7586dd60059cc99a5833bbe54ea07d85052b0885acaa098a7fe3d8f7bee',1,'websocketpp::extensions::permessage_deflate::error']]],
  ['unsupported_5fdata_591',['unsupported_data',['../namespacewebsocketpp_1_1close_1_1status.html#a5c7ca7f0416a1600f92ccac7a170b442',1,'websocketpp::close::status']]],
  ['unsupported_5fversion_592',['unsupported_version',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68da93459fd7c7609d8ebf110bb0f6754073',1,'websocketpp::error']]],
  ['upgrade_5frequired_593',['upgrade_required',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68dad50a56da7a0355b9075f98c7567523a5',1,'websocketpp::error']]],
  ['uri_594',['uri',['../classwebsocketpp_1_1uri.html',1,'websocketpp']]],
  ['uri_5fdefault_5fport_595',['uri_default_port',['../namespacewebsocketpp.html#a6e6530ad7452a88796029741c5c9fab9',1,'websocketpp']]],
  ['uri_5fdefault_5fsecure_5fport_596',['uri_default_secure_port',['../namespacewebsocketpp.html#a57ce716bd805ddf4ef561ee7f3a5767e',1,'websocketpp']]],
  ['uri_5fptr_597',['uri_ptr',['../namespacewebsocketpp.html#aae370ea5ac83a8ece7712cb39fc23f5b',1,'websocketpp']]],
  ['user_5fagent_598',['user_agent',['../namespacewebsocketpp.html#aa2de4611f1a9dc8d62b7dc849fae787a',1,'websocketpp']]],
  ['utility_20client_20example_20application_20tutorial_599',['Utility Client Example Application Tutorial',['../md_tutorials_utility_client_utility_client.html',1,'tutorials']]],
  ['utility_20server_20example_20application_20tutorial_600',['Utility Server Example Application Tutorial',['../md_tutorials_utility_server_utility_server.html',1,'tutorials']]],
  ['utility_5fserver_601',['utility_server',['../classutility__server.html',1,'']]]
];
