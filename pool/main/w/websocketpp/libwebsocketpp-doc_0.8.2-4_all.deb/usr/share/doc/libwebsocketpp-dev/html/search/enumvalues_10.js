var searchData=
[
  ['uninitialized_1302',['uninitialized',['../namespacewebsocketpp_1_1extensions_1_1permessage__deflate_1_1error.html#a38e53d7586dd60059cc99a5833bbe54eaa7d37064915d0ef64357e41763b42b7e',1,'websocketpp::extensions::permessage_deflate::error']]],
  ['unrequested_5fsubprotocol_1303',['unrequested_subprotocol',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68da1c2d766aa9dc1b43d4af8dac9d7de2e0',1,'websocketpp::error']]],
  ['unsupported_5fattributes_1304',['unsupported_attributes',['../namespacewebsocketpp_1_1extensions_1_1permessage__deflate_1_1error.html#a38e53d7586dd60059cc99a5833bbe54ea07d85052b0885acaa098a7fe3d8f7bee',1,'websocketpp::extensions::permessage_deflate::error']]],
  ['unsupported_5fversion_1305',['unsupported_version',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68da93459fd7c7609d8ebf110bb0f6754073',1,'websocketpp::error']]],
  ['upgrade_5frequired_1306',['upgrade_required',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68dad50a56da7a0355b9075f98c7567523a5',1,'websocketpp::error']]]
];
