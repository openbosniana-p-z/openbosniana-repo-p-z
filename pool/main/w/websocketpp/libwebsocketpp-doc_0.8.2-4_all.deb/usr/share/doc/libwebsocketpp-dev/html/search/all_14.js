var searchData=
[
  ['zlib_5ferror_650',['zlib_error',['../namespacewebsocketpp_1_1extensions_1_1permessage__deflate_1_1error.html#a38e53d7586dd60059cc99a5833bbe54ea9c98b21e33391203ce5f968428c03f3a',1,'websocketpp::extensions::permessage_deflate::error']]]
];
