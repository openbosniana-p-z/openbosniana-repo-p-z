var searchData=
[
  ['endpoint_5fnot_5fsecure_1232',['endpoint_not_secure',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68dab60d2206b38a89602d316dd029c33c1b',1,'websocketpp::error']]],
  ['endpoint_5funavailable_1233',['endpoint_unavailable',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68da472f65367504b2e11e63682cca469be4',1,'websocketpp::error']]],
  ['eof_1234',['eof',['../namespacewebsocketpp_1_1transport_1_1error.html#a8d371a2562d813e5a2e106e2694d4fb0a73dd0d0f22cd67b7bcc031cd6bdef743',1,'websocketpp::transport::error']]],
  ['extension_5fneg_5ffailed_1235',['extension_neg_failed',['../namespacewebsocketpp_1_1error.html#a0558d884e44e79146ad4947aea63f68da7ab039563d30f7760c3cd34f1fd680b1',1,'websocketpp::error']]],
  ['extension_5fparse_5ferror_1236',['extension_parse_error',['../namespacewebsocketpp_1_1processor_1_1error.html#ae6510ada6a25dcd7af258b6e374e3ca5a595ba53f29be3b66c51ad41bd94ee29c',1,'websocketpp::processor::error']]],
  ['extensions_5fdisabled_1237',['extensions_disabled',['../namespacewebsocketpp_1_1processor_1_1error.html#ae6510ada6a25dcd7af258b6e374e3ca5a529dc9b46308d321bd52d8ced4e566e1',1,'websocketpp::processor::error']]]
];
