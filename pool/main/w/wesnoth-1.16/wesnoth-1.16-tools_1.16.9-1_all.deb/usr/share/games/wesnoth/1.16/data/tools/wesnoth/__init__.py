# When Python looks for a package, it considers all directories with
# a file named __init__.py inside them. Therefore we need this file.
# Any code put in here would get executed on "import wesnoth".
