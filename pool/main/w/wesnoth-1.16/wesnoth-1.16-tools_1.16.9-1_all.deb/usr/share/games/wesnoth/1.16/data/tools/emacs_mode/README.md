Wesnoth Mode is a major mode for Emacs which assists in the editing of Wesnoth
Markup Language (WML) files.  Currently, this major-mode features syntax
highlighting support, automatic indentation, context-sensitive completion and
WML checking.

Wesnoth Mode can be byte-compiled with:

 $ make

If texinfo installed, the manual can be produced in PDF and info format using:

 $ make doc

Otherwise, an online version of the manual can be found here:
https://www.wesnoth.org/wiki/Wesnoth_Mode

For the latest updates and information or if you have any questions, problems
or suggestions regarding Wesnoth Mode, please direct them to:
https://www.wesnoth.org/forum/viewtopic.php?t=13798.
