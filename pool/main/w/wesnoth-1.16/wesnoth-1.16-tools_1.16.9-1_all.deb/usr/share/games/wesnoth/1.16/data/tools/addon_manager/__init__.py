#!/usr/bin/env python3
# This lets Python know about the addon_manager module.
