This is a directory of miscellaneous developer tools for Battle for Wesnoth,
mostly to support packaging, code integrity checks, and control of the
Wesnoth servers.

Tools that work on data (WML, maps, images, sounds) no longer belong here.
Go to data/tools for those.
