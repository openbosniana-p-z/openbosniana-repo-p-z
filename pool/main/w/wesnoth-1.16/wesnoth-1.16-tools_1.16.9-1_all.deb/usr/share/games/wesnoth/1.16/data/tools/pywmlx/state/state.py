class State:
    def __init__(self, regex, run, iffail):
        self.regex = regex
        self.run = run
        self.iffail = iffail
