Origin: MathML post-REC-MathML2-20031021 tarball at
http://www.w3.org/Math/DTD/mathml2.tgz, retrieved 2009-10-25, last
modified 2003-11-04.
