Generated 2010-04-22 with:

saxon \
    http://www.w3.org/2003/entities/2007xml/unicode.xml \
    http://www.w3.org/2003/entities/2007xml/entities.xsl
