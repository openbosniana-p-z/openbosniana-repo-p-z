wmfrog
======

A very very old (as in ~1999) weather dockapp I made for WindowMaker, FluxBox, OpenBox and the likes. 
Horrible code, seriously !

[http://wiki.colar.net/wmfrog_dockapp](http://wiki.colar.net/wmfrog_dockapp)
