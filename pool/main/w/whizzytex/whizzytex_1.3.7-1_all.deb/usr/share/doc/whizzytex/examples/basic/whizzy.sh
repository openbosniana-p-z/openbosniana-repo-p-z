echo "File `pwd`/.whizzy.sh being loaded"
echo "No customization"
