from .wfuzz import main

main()
