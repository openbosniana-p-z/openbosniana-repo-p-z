

class Wavelet_Binary : public Wavelet {
public:
  Wavelet_Binary();
  
  // Lifting steps on Channels
  void CakeWalk(Lifting &lifting) const ;
  void ICakeWalk(Lifting &lifting) const ;
  Wavelet_Binary *Clone(void) const;

private:
  static const char *rcsid;
};

