/*
 * monsters.h - part of WadC
 * Copyright © 2001-2008 Wouter van Oortmerssen
 * Copyright © 2008-2016 Jonathan Dowland <jon@dow.land>
 *
 * Distributed under the terms of the GNU GPL Version 2
 * See file LICENSE.txt
 */

formerhuman         { setthing(3004) }  
wolfensteinss       { setthing(  84) }  
formersergeant      { setthing(   9) }  
heavyweapondude     { setthing(  65) }  
imp                 { setthing(3001) }  
demon               { setthing(3002) }  
spectre             { setthing(  58) }  
lostsoul            { setthing(3006) }  
cacodemon           { setthing(3005) }  
hellknight          { setthing(  69) }  
baronofhell         { setthing(3003) }  
arachnotron         { setthing(  68) }  
painelemental       { setthing(  71) }  
revenant            { setthing(  66) }  
mancubus            { setthing(  67) }  
archvile            { setthing(  64) }  
spidermastermind    { setthing(   7) }  
cyberdemon          { setthing(  16) }  
bossbrain           { setthing(  88) }  
bossshooter         { setthing(  89) }  
spawnspot           { setthing(  87) }  
