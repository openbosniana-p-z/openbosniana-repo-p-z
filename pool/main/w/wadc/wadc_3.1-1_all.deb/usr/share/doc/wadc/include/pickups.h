/*
 * pickups.h - part of WadC
 * Copyright © 2001-2008 Wouter van Oortmerssen
 * Copyright © 2008-2016 Jonathan Dowland <jon@dow.land>
 *
 * Distributed under the terms of the GNU GPL Version 2
 * See file LICENSE.txt
 */

chainsaw            { setthing(2005) } 
shotgun             { setthing(2001) } 
doublebarreled      { setthing(  82) } 
chaingun            { setthing(2002) } 
rocketlauncher      { setthing(2003) } 
plasmagun           { setthing(2004) } 
bfg9000             { setthing(2006) } 
ammoclip            { setthing(2007) } 
shotgunshells       { setthing(2008) } 
arocket             { setthing(2010) } 
cellcharge          { setthing(2047) } 
boxofammo           { setthing(2048) } 
boxofshells         { setthing(2049) } 
boxofrockets        { setthing(2046) } 
cellchargepack      { setthing(  17) } 
backpack            { setthing(   8) }      
stimpak             { setthing(2011) } 
medikit             { setthing(2012) } 
healthpotion        { setthing(2014) } 
spiritarmor         { setthing(2015) } 
greenarmor          { setthing(2018) } 
bluearmor           { setthing(2019) } 
megasphere          { setthing(  83) } 
soulsphere          { setthing(2013) } 
invulnerability     { setthing(2022) } 
berserk             { setthing(2023) } 
invisibility        { setthing(2024) } 
radiationsuit       { setthing(2025) } 
computermap         { setthing(2026) } 
goggles             { setthing(2045) } 
bluekeycard         { setthing(   5) } 
blueskullkey        { setthing(  40) } 
redkeycard          { setthing(  13) } 
redskullkey         { setthing(  38) } 
yellowkeycard       { setthing(   6) } 
yellowskullkey      { setthing(  39) } 
