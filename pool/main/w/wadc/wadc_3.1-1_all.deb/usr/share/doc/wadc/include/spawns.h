/*
 * spawns.h - part of WadC
 * Copyright © 2001-2008 Wouter van Oortmerssen
 * Copyright © 2008-2016 Jonathan Dowland <jon@dow.land>
 *
 * Distributed under the terms of the GNU GPL Version 2
 * See file LICENSE.txt
 */

player1start        { setthing(   1) } 
player2start        { setthing(   2) } 
player3start        { setthing(   3) } 
player4start        { setthing(   4) } 
deathmatchstart     { setthing(  11) } 
teleportlanding     { setthing(  14) } 
