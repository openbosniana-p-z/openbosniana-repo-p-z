// this file exists only for backwards compatibility!
#include "wvstrutils.h"
