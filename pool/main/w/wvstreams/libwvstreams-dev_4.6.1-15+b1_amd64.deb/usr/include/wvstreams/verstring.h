// this file exists only for backwards compatibility!
#include "wvverstring.h"
