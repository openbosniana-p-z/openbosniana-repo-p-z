#! /bin/sh

git status --short -uno | cut -c4- | grep -v "^../" || true
