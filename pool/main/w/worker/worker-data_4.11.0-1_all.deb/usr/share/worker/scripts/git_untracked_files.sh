#! /bin/sh

git status --short -unormal | grep '^??' | cut -c4- | grep -v "^../" || true
