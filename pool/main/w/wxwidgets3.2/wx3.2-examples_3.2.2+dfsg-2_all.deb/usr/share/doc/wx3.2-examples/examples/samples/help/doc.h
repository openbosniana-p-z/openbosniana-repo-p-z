#define doc1       100
#define doc2       2
#define doc3       1
#define doc4       3
#define IDH_PANEL  300
#define IDH_TEXT   301
#define IDH_OK     302
