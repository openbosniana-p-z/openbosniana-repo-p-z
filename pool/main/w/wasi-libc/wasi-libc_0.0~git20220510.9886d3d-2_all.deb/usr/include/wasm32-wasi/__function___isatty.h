#ifndef __wasilibc___function___isatty_h
#define __wasilibc___function___isatty_h

#ifdef __cplusplus
extern "C" {
#endif

int __isatty(int fd);

#ifdef __cplusplus
}
#endif

#endif
