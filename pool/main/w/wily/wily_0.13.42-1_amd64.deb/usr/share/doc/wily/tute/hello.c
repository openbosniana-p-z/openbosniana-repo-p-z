void
main(void)
{
	printf("hello, world\n");
}
}
