#!/bin/sh
play /usr/share/wmbubble/wak.wav /usr/share/wmbubble/wak.wav > /dev/null
