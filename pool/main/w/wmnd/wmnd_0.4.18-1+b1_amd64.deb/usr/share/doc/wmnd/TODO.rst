Planned features

	* wave++: selectively include drivers and specify driver options by
	  specifying the -D flag multiple times (something like -Ddriver:params
	  and remove the per-driver -I management).

	* wave++: the snmp driver could use a single session instance.

	* Bryan: multiple snmp devices on a single instance

	* Jeff Greenfield: logarithmic graph scale.
