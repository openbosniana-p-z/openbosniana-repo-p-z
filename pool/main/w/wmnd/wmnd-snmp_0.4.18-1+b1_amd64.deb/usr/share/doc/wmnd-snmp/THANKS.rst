Reed Lai http://bv4qo.wingeer.org/:

	* Project initiation.

Arthur Korn <arthur@korn.ch>:

	* Original WMND man page author.
	* Old Makefile system maintenance.
	* Debian package maintenance: http://packages.debian.org/wmnd/

Michael Leuchtenburg:

	* Old web site administration: http://wmnd.wingeer.org/
	* English refinement of articles

Paul van Tilburg (Mozillion) http://www.utopiamoo.net/:

	* Provided ultimate test environment for function and stability
	  of WMND.

Timecop <timecop@japan.co.jp> http://www.ne.jp/asahi/linux/timecop/:

	* Source code optimization (Re-wrote the source code of WMND 0.2.0)

Yuri D'Elia (wave++) <wavexx@thregr.org> http://www.thregr.org/~wavexx/:

	* Driver architecture, new visualization structs, re-wrote source
	  code of WMND 0.3 series.
	* Many minor things (see ChangeLog)

Sebastian Liusnea <sebaks@csit-sun.pub.ro>:

	* A different Solaris port of WMND 0.2.0.

Paulo E. Abreu <qtabreu@ci.uc.pt>:

	* Old RPM package maintenance.

Michael Shigorin:

	* ALT Linux patch (better X session management).

Thomas Ashton:

	* SMD patch for WMND 0.4.2 (speed measuring divided).

Jesse Becker:

	* Enhanced trend support patches.

Rui Paulo:

	* First NetBSD ioctl driver.


And many more...
