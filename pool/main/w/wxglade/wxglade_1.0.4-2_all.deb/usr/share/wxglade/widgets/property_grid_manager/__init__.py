"""
PropertyGridManager widget module initialization

@copyright: 2002-2007 Alberto Griggio
@copyright: 2015 Franco Bugnano
@license: MIT (see LICENSE.txt) - THIS PROGRAM COMES WITH NO WARRANTY
"""
