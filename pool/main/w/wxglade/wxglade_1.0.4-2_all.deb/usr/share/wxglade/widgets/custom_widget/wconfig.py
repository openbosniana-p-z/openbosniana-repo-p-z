"""\
widget configuration to make events editable

@copyright: 2020 Dietmar Schwertberger
@license: MIT (see LICENSE.txt) - THIS PROGRAM COMES WITH NO WARRANTY
"""

config = {
    'wxklass': "CustomWidget",
    'style_defs':{},
    'events': {},
}
