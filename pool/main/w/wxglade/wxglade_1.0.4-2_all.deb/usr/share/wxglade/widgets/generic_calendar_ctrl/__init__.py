"""
generic_calendar_ctrl widget module initialization

@copyright: 2007 Alberto Griggio
@copyright: 2015 Franco Bugnano
@license: MIT (see LICENSE.txt) - THIS PROGRAM COMES WITH NO WARRANTY
"""
