var classwayland_1_1server_1_1zwp__primary__selection__source__v1__t =
[
    [ "cancelled", "classwayland_1_1server_1_1zwp__primary__selection__source__v1__t.html#ad8dedf3ef70ffd050847ffdace258c27", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zwp__primary__selection__source__v1__t.html#a74adba5e6f4e49bc655cc688729387ea", null ],
    [ "on_offer", "classwayland_1_1server_1_1zwp__primary__selection__source__v1__t.html#a86cf0e513c84257d5bc7d18a4c0f8fb9", null ],
    [ "send", "classwayland_1_1server_1_1zwp__primary__selection__source__v1__t.html#a595661de54472932ea1ca9447d1f1ef3", null ]
];