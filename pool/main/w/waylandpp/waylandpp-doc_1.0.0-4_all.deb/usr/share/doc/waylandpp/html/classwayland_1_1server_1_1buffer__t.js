var classwayland_1_1server_1_1buffer__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1buffer__t.html#a781044e2765200260e63307c61508e04", null ],
    [ "release", "classwayland_1_1server_1_1buffer__t.html#a6016826b3a5490490cacb0f476077587", null ]
];