var classwayland_1_1server_1_1zwp__input__timestamps__v1__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1zwp__input__timestamps__v1__t.html#ab95ce823c016daf28fea17cb9cb757d0", null ],
    [ "timestamp", "classwayland_1_1server_1_1zwp__input__timestamps__v1__t.html#aed5b59a191514a9c5475dbea80f13e10", null ]
];