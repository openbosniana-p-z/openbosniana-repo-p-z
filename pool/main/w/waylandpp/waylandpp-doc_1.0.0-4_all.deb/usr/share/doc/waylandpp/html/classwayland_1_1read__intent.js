var classwayland_1_1read__intent =
[
    [ "cancel", "classwayland_1_1read__intent.html#a2e663187d7766828b483c65ede83ecc4", null ],
    [ "is_finalized", "classwayland_1_1read__intent.html#a8b1aef8516e4ccbfbba356f7a29d9c15", null ],
    [ "read", "classwayland_1_1read__intent.html#a92565efbf3a622eb23fc5aefcb1a033d", null ]
];