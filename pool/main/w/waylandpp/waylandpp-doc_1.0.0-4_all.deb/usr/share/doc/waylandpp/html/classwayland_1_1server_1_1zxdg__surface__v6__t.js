var classwayland_1_1server_1_1zxdg__surface__v6__t =
[
    [ "configure", "classwayland_1_1server_1_1zxdg__surface__v6__t.html#a35b7ade08d8b1d0cf9013e7a40d58729", null ],
    [ "on_ack_configure", "classwayland_1_1server_1_1zxdg__surface__v6__t.html#a333a33780d1660273b27e000b0e49003", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zxdg__surface__v6__t.html#ae5f04dbf710017ca36e86d72aafa5ec4", null ],
    [ "on_get_popup", "classwayland_1_1server_1_1zxdg__surface__v6__t.html#a7d17825ad568180992f3d9103a95cddf", null ],
    [ "on_get_toplevel", "classwayland_1_1server_1_1zxdg__surface__v6__t.html#a6c127409758d3af8d9c47f42a2020be2", null ],
    [ "on_set_window_geometry", "classwayland_1_1server_1_1zxdg__surface__v6__t.html#accb07cb78d7f2ee47a997e944371a447", null ],
    [ "post_already_constructed", "classwayland_1_1server_1_1zxdg__surface__v6__t.html#af4e7399302fe54e9e3d94d82ca3592ad", null ],
    [ "post_not_constructed", "classwayland_1_1server_1_1zxdg__surface__v6__t.html#aacf643b21531e6ca5bd41e3c60601bdb", null ],
    [ "post_unconfigured_buffer", "classwayland_1_1server_1_1zxdg__surface__v6__t.html#ab21b439e82578df63a36dc666df2507b", null ]
];