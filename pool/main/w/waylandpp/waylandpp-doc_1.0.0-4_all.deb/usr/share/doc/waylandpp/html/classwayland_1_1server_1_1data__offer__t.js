var classwayland_1_1server_1_1data__offer__t =
[
    [ "action", "classwayland_1_1server_1_1data__offer__t.html#af63b32e274e2490a05fbf6a9c8d788e2", null ],
    [ "can_action", "classwayland_1_1server_1_1data__offer__t.html#a8d3d827f50323e51c4aa59aa8a7968d2", null ],
    [ "can_source_actions", "classwayland_1_1server_1_1data__offer__t.html#a6891dd9c484ffbd1d8e112d84b69182b", null ],
    [ "offer", "classwayland_1_1server_1_1data__offer__t.html#a1a9ae48eff5c722189021f213670aa58", null ],
    [ "on_accept", "classwayland_1_1server_1_1data__offer__t.html#a6379da11ef845ebcff76d540b8d34ec5", null ],
    [ "on_destroy", "classwayland_1_1server_1_1data__offer__t.html#a2e43a1e47041f016091918c37aa9e48f", null ],
    [ "on_finish", "classwayland_1_1server_1_1data__offer__t.html#a9e84b988b16cc2fff22fb134b2737d10", null ],
    [ "on_receive", "classwayland_1_1server_1_1data__offer__t.html#a334db71fae10e63f8ff6b07c19ec07c2", null ],
    [ "on_set_actions", "classwayland_1_1server_1_1data__offer__t.html#a483ad524cc15265864fed2521cb4102f", null ],
    [ "post_invalid_action", "classwayland_1_1server_1_1data__offer__t.html#ac225aa9702ad02193f6040300395ce82", null ],
    [ "post_invalid_action_mask", "classwayland_1_1server_1_1data__offer__t.html#af2929a3291055b5fd54e657853d08827", null ],
    [ "post_invalid_finish", "classwayland_1_1server_1_1data__offer__t.html#a65e4570a968ae6587f7d64568dc12198", null ],
    [ "post_invalid_offer", "classwayland_1_1server_1_1data__offer__t.html#add188fa375db8f489b8115233425a3e5", null ],
    [ "source_actions", "classwayland_1_1server_1_1data__offer__t.html#a5164529fa1d987c561b3fc0cc02bb096", null ]
];