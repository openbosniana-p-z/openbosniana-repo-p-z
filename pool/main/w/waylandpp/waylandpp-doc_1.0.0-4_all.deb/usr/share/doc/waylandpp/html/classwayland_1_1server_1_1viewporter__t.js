var classwayland_1_1server_1_1viewporter__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1viewporter__t.html#aae320d890f3cab6f9593ee39a8c56ba1", null ],
    [ "on_get_viewport", "classwayland_1_1server_1_1viewporter__t.html#a9142a06ec05bf01618c20fa7541d868d", null ],
    [ "post_viewport_exists", "classwayland_1_1server_1_1viewporter__t.html#abc12d90f53af1e961d0b843aa214980a", null ]
];