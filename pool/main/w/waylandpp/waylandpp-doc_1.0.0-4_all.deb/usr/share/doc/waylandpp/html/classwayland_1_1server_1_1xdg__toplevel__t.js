var classwayland_1_1server_1_1xdg__toplevel__t =
[
    [ "can_configure_bounds", "classwayland_1_1server_1_1xdg__toplevel__t.html#a307ae2e3f13de73730180194b8176660", null ],
    [ "close", "classwayland_1_1server_1_1xdg__toplevel__t.html#a55d03d0bd3c43dfd0c2a4fce54e44ac3", null ],
    [ "configure", "classwayland_1_1server_1_1xdg__toplevel__t.html#af68f45c475153129c0f50d5a47acb6e1", null ],
    [ "configure_bounds", "classwayland_1_1server_1_1xdg__toplevel__t.html#ae47704a97d1e4ced4eda6188a01b5fad", null ],
    [ "on_destroy", "classwayland_1_1server_1_1xdg__toplevel__t.html#afbbea66643dd0b266662fb581382f9f6", null ],
    [ "on_move", "classwayland_1_1server_1_1xdg__toplevel__t.html#a8bb784a7f7c41b5202d6edc0097e9a63", null ],
    [ "on_resize", "classwayland_1_1server_1_1xdg__toplevel__t.html#aab1f0743cbcb03b232df107e06ecd999", null ],
    [ "on_set_app_id", "classwayland_1_1server_1_1xdg__toplevel__t.html#a3b3ad159b8291917e6e5394fc403349c", null ],
    [ "on_set_fullscreen", "classwayland_1_1server_1_1xdg__toplevel__t.html#abb9e7656ccc80dfaca54444d26f6284d", null ],
    [ "on_set_max_size", "classwayland_1_1server_1_1xdg__toplevel__t.html#a53e845746720ca24d8d168f5f33ffbde", null ],
    [ "on_set_maximized", "classwayland_1_1server_1_1xdg__toplevel__t.html#a8daa503d9063ef9942a940932b787638", null ],
    [ "on_set_min_size", "classwayland_1_1server_1_1xdg__toplevel__t.html#a02df4a1d0a94a47b65bffe3ee03a08b9", null ],
    [ "on_set_minimized", "classwayland_1_1server_1_1xdg__toplevel__t.html#ad7fcd64ae850270d71a4870bb4056c4d", null ],
    [ "on_set_parent", "classwayland_1_1server_1_1xdg__toplevel__t.html#a3320ac857a7a1182233e0f3140b5b21b", null ],
    [ "on_set_title", "classwayland_1_1server_1_1xdg__toplevel__t.html#a8527d85a3dad762b8beffefc666328a8", null ],
    [ "on_show_window_menu", "classwayland_1_1server_1_1xdg__toplevel__t.html#a0584178f60443fcd8a17a81e3d2d9ab2", null ],
    [ "on_unset_fullscreen", "classwayland_1_1server_1_1xdg__toplevel__t.html#a2f3e09e3d2eeb57280bb7001d56f1d56", null ],
    [ "on_unset_maximized", "classwayland_1_1server_1_1xdg__toplevel__t.html#a0d703f12faf0793bf2311cd068a4586a", null ],
    [ "post_invalid_resize_edge", "classwayland_1_1server_1_1xdg__toplevel__t.html#a78ef1d1ec4b468ee3b4425dc32c21f2a", null ]
];