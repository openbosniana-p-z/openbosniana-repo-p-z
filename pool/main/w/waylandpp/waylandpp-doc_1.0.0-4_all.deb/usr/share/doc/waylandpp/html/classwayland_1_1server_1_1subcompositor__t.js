var classwayland_1_1server_1_1subcompositor__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1subcompositor__t.html#a06e05e2e021d8e7a75731daae8dbd232", null ],
    [ "on_get_subsurface", "classwayland_1_1server_1_1subcompositor__t.html#a00c66567f7d48d7037cc36d1ad0e7c58", null ],
    [ "post_bad_surface", "classwayland_1_1server_1_1subcompositor__t.html#a78f6122020f302e52642586633c4c7a5", null ]
];