var classwayland_1_1server_1_1zwp__tablet__pad__strip__v2__t =
[
    [ "frame", "classwayland_1_1server_1_1zwp__tablet__pad__strip__v2__t.html#a11de645ea9ea68f5c6df396dd6c5f5d5", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zwp__tablet__pad__strip__v2__t.html#a61e433ef06cc9826ce41f9fa27ea86ef", null ],
    [ "on_set_feedback", "classwayland_1_1server_1_1zwp__tablet__pad__strip__v2__t.html#a8f2373ae57468185ae105c93df464e25", null ],
    [ "position", "classwayland_1_1server_1_1zwp__tablet__pad__strip__v2__t.html#a290934590962ddf967d1f1c3a6a5de18", null ],
    [ "source", "classwayland_1_1server_1_1zwp__tablet__pad__strip__v2__t.html#a934ae2b70210393054c303150916f7fb", null ],
    [ "stop", "classwayland_1_1server_1_1zwp__tablet__pad__strip__v2__t.html#ae616caffed17e9f2da0eca1113a67c53", null ]
];