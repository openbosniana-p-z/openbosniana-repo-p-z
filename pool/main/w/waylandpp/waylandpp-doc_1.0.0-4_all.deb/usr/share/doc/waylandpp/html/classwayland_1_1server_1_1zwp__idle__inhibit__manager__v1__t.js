var classwayland_1_1server_1_1zwp__idle__inhibit__manager__v1__t =
[
    [ "on_create_inhibitor", "classwayland_1_1server_1_1zwp__idle__inhibit__manager__v1__t.html#a6008cf40dd83e152b0aa819abf218608", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zwp__idle__inhibit__manager__v1__t.html#a335b042b7d4ebb28c2a92d838fa15cb4", null ]
];