var classwayland_1_1server_1_1zwp__fullscreen__shell__v1__t =
[
    [ "capability", "classwayland_1_1server_1_1zwp__fullscreen__shell__v1__t.html#a5fa51a0daec34d9dc5d9c61faa1d04dd", null ],
    [ "on_present_surface", "classwayland_1_1server_1_1zwp__fullscreen__shell__v1__t.html#a57e4b8d197104c5ebf35c22a3c4a2f91", null ],
    [ "on_present_surface_for_mode", "classwayland_1_1server_1_1zwp__fullscreen__shell__v1__t.html#aece156614fe82c8cf443defd88e97602", null ],
    [ "on_release", "classwayland_1_1server_1_1zwp__fullscreen__shell__v1__t.html#ad6b98f7671eac7d80174f3867209dab4", null ],
    [ "post_invalid_method", "classwayland_1_1server_1_1zwp__fullscreen__shell__v1__t.html#ab746eb613a0488d3d1cdd0fe4de233b0", null ],
    [ "post_role", "classwayland_1_1server_1_1zwp__fullscreen__shell__v1__t.html#a1cd59c5533e4019389edbe6e6c09ff85", null ]
];