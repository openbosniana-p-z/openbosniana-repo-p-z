var classwayland_1_1server_1_1presentation__feedback__t =
[
    [ "discarded", "classwayland_1_1server_1_1presentation__feedback__t.html#a46e4a70965e5ade92806c5f7f95528d2", null ],
    [ "presented", "classwayland_1_1server_1_1presentation__feedback__t.html#a55f31492603a6f15af24c9b954223050", null ],
    [ "sync_output", "classwayland_1_1server_1_1presentation__feedback__t.html#af7a38902be5abde9a92d2ac888b8f96a", null ]
];