var classwayland_1_1server_1_1zxdg__exported__v2__t =
[
    [ "handle", "classwayland_1_1server_1_1zxdg__exported__v2__t.html#a90e84972015b28435bf204275cf0a750", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zxdg__exported__v2__t.html#a07604201bd151d398087fbf134a7d535", null ]
];