var classwayland_1_1server_1_1zwp__tablet__v1__t =
[
    [ "done", "classwayland_1_1server_1_1zwp__tablet__v1__t.html#a6cd490bdf41342d60e9ed774441c9d56", null ],
    [ "id", "classwayland_1_1server_1_1zwp__tablet__v1__t.html#a5a0721747b7f5ff7de4980fa93d03caa", null ],
    [ "name", "classwayland_1_1server_1_1zwp__tablet__v1__t.html#a4575585886d2906e97ce8e82fc4ea3d8", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zwp__tablet__v1__t.html#a6c2ced5ee8973c8b83bf6dddd99bf5ab", null ],
    [ "path", "classwayland_1_1server_1_1zwp__tablet__v1__t.html#a3d2faf86430fce83315fac2d5f9847a5", null ],
    [ "removed", "classwayland_1_1server_1_1zwp__tablet__v1__t.html#a5cc68ae4222f7d574c22124d53cb09d6", null ]
];