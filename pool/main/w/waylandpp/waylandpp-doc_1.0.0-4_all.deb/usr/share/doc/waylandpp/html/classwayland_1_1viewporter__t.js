var classwayland_1_1viewporter__t =
[
    [ "wrapper_type", "classwayland_1_1viewporter__t.html#afc44f0d53890db6bd32d9b2f0c6994e9", [
      [ "standard", "classwayland_1_1viewporter__t.html#afc44f0d53890db6bd32d9b2f0c6994e9ac00f0c4675b91fb8b918e4079a0b1bac", null ],
      [ "display", "classwayland_1_1viewporter__t.html#afc44f0d53890db6bd32d9b2f0c6994e9aebf78b512222fe4dcd14e7d5060a15b0", null ],
      [ "foreign", "classwayland_1_1viewporter__t.html#afc44f0d53890db6bd32d9b2f0c6994e9a684a72e08f24f55b1138edd5a7c2b53e", null ],
      [ "proxy_wrapper", "classwayland_1_1viewporter__t.html#afc44f0d53890db6bd32d9b2f0c6994e9ae6cc1490287e90290ddd4e0b9efeb6d5", null ]
    ] ],
    [ "c_ptr", "classwayland_1_1viewporter__t.html#a869635f7ddc6678df2b93f8a13870c95", null ],
    [ "get_class", "classwayland_1_1viewporter__t.html#a8a77c6eab2f2eb4cfcca56be8a780d3e", null ],
    [ "get_id", "classwayland_1_1viewporter__t.html#a273d7fd6604b65d4c4d24747b639a263", null ],
    [ "get_version", "classwayland_1_1viewporter__t.html#a59444022b75257f6b27d2c464c371779", null ],
    [ "get_viewport", "classwayland_1_1viewporter__t.html#ab38cd670913580c27f2b46c77d0b67bf", null ],
    [ "get_wrapper_type", "classwayland_1_1viewporter__t.html#a65253c6ac727496735c0dc42a9fd1568", null ],
    [ "operator bool", "classwayland_1_1viewporter__t.html#aafa72a9121fa69ccfad6e9eff8740b5e", null ],
    [ "operator!=", "classwayland_1_1viewporter__t.html#ac460e26f384624eb96647d533314240a", null ],
    [ "operator==", "classwayland_1_1viewporter__t.html#a3dc433db4597e77caccb07f99b26a259", null ],
    [ "proxy_has_object", "classwayland_1_1viewporter__t.html#a0c596640d7469447cb0b91dc9c8c22b2", null ],
    [ "proxy_release", "classwayland_1_1viewporter__t.html#a0af69af8f839a5a5ea354e52705e9a43", null ],
    [ "set_queue", "classwayland_1_1viewporter__t.html#a2065bb6f0ba51f29fdf16b8168bb5958", null ]
];