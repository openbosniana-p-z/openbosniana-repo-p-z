var classwayland_1_1server_1_1pointer__t =
[
    [ "axis", "classwayland_1_1server_1_1pointer__t.html#a0876eefd3bd3cadb3101aafe08757edf", null ],
    [ "axis_discrete", "classwayland_1_1server_1_1pointer__t.html#a8477a4cb6da97166c7fd6d5cf302d972", null ],
    [ "axis_source", "classwayland_1_1server_1_1pointer__t.html#a9e24c6e97468ff7d9c4c6074377f128b", null ],
    [ "axis_stop", "classwayland_1_1server_1_1pointer__t.html#a0a9f5a5d369ef805a77bf83c15319609", null ],
    [ "axis_value120", "classwayland_1_1server_1_1pointer__t.html#a8efe6c905c817f3bb728d85c3cacc027", null ],
    [ "button", "classwayland_1_1server_1_1pointer__t.html#a96b819757f2248fdfa7a8e45892778ce", null ],
    [ "can_axis_discrete", "classwayland_1_1server_1_1pointer__t.html#a543c5e113fb0f2ef14989f29fd085796", null ],
    [ "can_axis_source", "classwayland_1_1server_1_1pointer__t.html#a842bc3d0420e9bd2dc995f31b336d622", null ],
    [ "can_axis_stop", "classwayland_1_1server_1_1pointer__t.html#abfff2f47da12b2cac0f15b236b61941d", null ],
    [ "can_axis_value120", "classwayland_1_1server_1_1pointer__t.html#aa4659b4a612cbdfee423fa2ef2abfde0", null ],
    [ "can_frame", "classwayland_1_1server_1_1pointer__t.html#ac05e0c0efca8266e9c27b0f7c5bfd9ae", null ],
    [ "enter", "classwayland_1_1server_1_1pointer__t.html#aaa5f75e74518d89b6cc055e79eaf09c5", null ],
    [ "frame", "classwayland_1_1server_1_1pointer__t.html#a25fa045ccdbe0c92b86e710ca5757741", null ],
    [ "leave", "classwayland_1_1server_1_1pointer__t.html#a3cfaa8afdca550e62d70bddcd66ebeca", null ],
    [ "motion", "classwayland_1_1server_1_1pointer__t.html#a03d269fca8ffcaa505ff37ca82929eea", null ],
    [ "on_release", "classwayland_1_1server_1_1pointer__t.html#a8c804df17631438b3ffe71b02f56a130", null ],
    [ "on_set_cursor", "classwayland_1_1server_1_1pointer__t.html#a0cbe79f63cd18850facb1634198e5483", null ],
    [ "post_role", "classwayland_1_1server_1_1pointer__t.html#a345de06c0ea2784cc9decc9dd67c8b83", null ]
];