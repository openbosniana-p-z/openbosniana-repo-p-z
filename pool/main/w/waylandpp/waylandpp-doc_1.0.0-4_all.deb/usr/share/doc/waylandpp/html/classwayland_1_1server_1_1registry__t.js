var classwayland_1_1server_1_1registry__t =
[
    [ "global", "classwayland_1_1server_1_1registry__t.html#a474c0898d4f951e7c40d07efad63b3b7", null ],
    [ "global_remove", "classwayland_1_1server_1_1registry__t.html#aca5598111bced913d053eb42c5811fe5", null ],
    [ "on_bind", "classwayland_1_1server_1_1registry__t.html#aa7842aab6945afc25ec41f6f388ea423", null ]
];