var classwayland_1_1server_1_1zxdg__output__manager__v1__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1zxdg__output__manager__v1__t.html#a82ede45df3558b08c0e31f8ff6ccc311", null ],
    [ "on_get_xdg_output", "classwayland_1_1server_1_1zxdg__output__manager__v1__t.html#aee603a13f404533a837828649944ad31", null ]
];