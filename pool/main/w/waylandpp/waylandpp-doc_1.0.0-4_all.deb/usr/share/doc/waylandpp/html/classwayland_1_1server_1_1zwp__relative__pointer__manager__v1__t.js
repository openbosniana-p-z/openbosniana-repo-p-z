var classwayland_1_1server_1_1zwp__relative__pointer__manager__v1__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1zwp__relative__pointer__manager__v1__t.html#a4bccade1fa7a582a10db260482b472ec", null ],
    [ "on_get_relative_pointer", "classwayland_1_1server_1_1zwp__relative__pointer__manager__v1__t.html#ace0f8483dc164f43a1f73c93595ca697", null ]
];