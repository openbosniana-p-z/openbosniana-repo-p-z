var classwayland_1_1server_1_1zwp__pointer__gestures__v1__t =
[
    [ "on_get_hold_gesture", "classwayland_1_1server_1_1zwp__pointer__gestures__v1__t.html#a219d2d395c92ae973fff3198fe23ce25", null ],
    [ "on_get_pinch_gesture", "classwayland_1_1server_1_1zwp__pointer__gestures__v1__t.html#aabcd59259bc9add2b699435d87d8d13b", null ],
    [ "on_get_swipe_gesture", "classwayland_1_1server_1_1zwp__pointer__gestures__v1__t.html#a180073f902df686663466aa12f482039", null ],
    [ "on_release", "classwayland_1_1server_1_1zwp__pointer__gestures__v1__t.html#ab4c51f671df3db2c1e12dda4da38621c", null ]
];