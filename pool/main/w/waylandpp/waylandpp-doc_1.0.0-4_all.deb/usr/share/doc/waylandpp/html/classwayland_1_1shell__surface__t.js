var classwayland_1_1shell__surface__t =
[
    [ "wrapper_type", "classwayland_1_1shell__surface__t.html#afc44f0d53890db6bd32d9b2f0c6994e9", [
      [ "standard", "classwayland_1_1shell__surface__t.html#afc44f0d53890db6bd32d9b2f0c6994e9ac00f0c4675b91fb8b918e4079a0b1bac", null ],
      [ "display", "classwayland_1_1shell__surface__t.html#afc44f0d53890db6bd32d9b2f0c6994e9aebf78b512222fe4dcd14e7d5060a15b0", null ],
      [ "foreign", "classwayland_1_1shell__surface__t.html#afc44f0d53890db6bd32d9b2f0c6994e9a684a72e08f24f55b1138edd5a7c2b53e", null ],
      [ "proxy_wrapper", "classwayland_1_1shell__surface__t.html#afc44f0d53890db6bd32d9b2f0c6994e9ae6cc1490287e90290ddd4e0b9efeb6d5", null ]
    ] ],
    [ "c_ptr", "classwayland_1_1shell__surface__t.html#a869635f7ddc6678df2b93f8a13870c95", null ],
    [ "get_class", "classwayland_1_1shell__surface__t.html#a8a77c6eab2f2eb4cfcca56be8a780d3e", null ],
    [ "get_id", "classwayland_1_1shell__surface__t.html#a273d7fd6604b65d4c4d24747b639a263", null ],
    [ "get_version", "classwayland_1_1shell__surface__t.html#a59444022b75257f6b27d2c464c371779", null ],
    [ "get_wrapper_type", "classwayland_1_1shell__surface__t.html#a65253c6ac727496735c0dc42a9fd1568", null ],
    [ "move", "classwayland_1_1shell__surface__t.html#a2cba73c0d05391152bf6b2fdcf11195f", null ],
    [ "on_configure", "classwayland_1_1shell__surface__t.html#a85b56b7e8cf6677b662acc62d65607fe", null ],
    [ "on_ping", "classwayland_1_1shell__surface__t.html#a87e11992c3ca13bc36623702d7deab2d", null ],
    [ "on_popup_done", "classwayland_1_1shell__surface__t.html#ae254bc26962b7182478d07fd711d0424", null ],
    [ "operator bool", "classwayland_1_1shell__surface__t.html#aafa72a9121fa69ccfad6e9eff8740b5e", null ],
    [ "operator!=", "classwayland_1_1shell__surface__t.html#ac460e26f384624eb96647d533314240a", null ],
    [ "operator==", "classwayland_1_1shell__surface__t.html#a3dc433db4597e77caccb07f99b26a259", null ],
    [ "pong", "classwayland_1_1shell__surface__t.html#a8b64a118c4c15f0e4a6264a417ba4a33", null ],
    [ "proxy_has_object", "classwayland_1_1shell__surface__t.html#a0c596640d7469447cb0b91dc9c8c22b2", null ],
    [ "proxy_release", "classwayland_1_1shell__surface__t.html#a0af69af8f839a5a5ea354e52705e9a43", null ],
    [ "resize", "classwayland_1_1shell__surface__t.html#a09c3fc9cf8adc8be9fe4a83b6fa21fc7", null ],
    [ "set_class", "classwayland_1_1shell__surface__t.html#a3806cd14b7f83c12ea851817e1937362", null ],
    [ "set_fullscreen", "classwayland_1_1shell__surface__t.html#a2ad9d2ac78a2ff446687a6c75245310e", null ],
    [ "set_maximized", "classwayland_1_1shell__surface__t.html#ab70bb962317d216126b6e101a11671c0", null ],
    [ "set_popup", "classwayland_1_1shell__surface__t.html#a8b151ca747443667953b7fe368fc14f8", null ],
    [ "set_queue", "classwayland_1_1shell__surface__t.html#a2065bb6f0ba51f29fdf16b8168bb5958", null ],
    [ "set_title", "classwayland_1_1shell__surface__t.html#af75701dfcf60b2c257979164845ca7d3", null ],
    [ "set_toplevel", "classwayland_1_1shell__surface__t.html#a653eb93836395442012047cc5192a555", null ],
    [ "set_transient", "classwayland_1_1shell__surface__t.html#a63faff7498e0ea32eb8ba9d26a738a7d", null ]
];