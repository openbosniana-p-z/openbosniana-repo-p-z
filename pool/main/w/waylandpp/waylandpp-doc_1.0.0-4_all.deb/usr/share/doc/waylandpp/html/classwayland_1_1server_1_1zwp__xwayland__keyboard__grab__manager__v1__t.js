var classwayland_1_1server_1_1zwp__xwayland__keyboard__grab__manager__v1__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1zwp__xwayland__keyboard__grab__manager__v1__t.html#a70a5a00b757a4ffc699269cd2c4a6e3b", null ],
    [ "on_grab_keyboard", "classwayland_1_1server_1_1zwp__xwayland__keyboard__grab__manager__v1__t.html#a08acecd37a8f0df0cbc2b14dd45cd522", null ]
];