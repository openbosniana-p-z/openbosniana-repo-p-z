var classwayland_1_1pointer__t =
[
    [ "wrapper_type", "classwayland_1_1pointer__t.html#afc44f0d53890db6bd32d9b2f0c6994e9", [
      [ "standard", "classwayland_1_1pointer__t.html#afc44f0d53890db6bd32d9b2f0c6994e9ac00f0c4675b91fb8b918e4079a0b1bac", null ],
      [ "display", "classwayland_1_1pointer__t.html#afc44f0d53890db6bd32d9b2f0c6994e9aebf78b512222fe4dcd14e7d5060a15b0", null ],
      [ "foreign", "classwayland_1_1pointer__t.html#afc44f0d53890db6bd32d9b2f0c6994e9a684a72e08f24f55b1138edd5a7c2b53e", null ],
      [ "proxy_wrapper", "classwayland_1_1pointer__t.html#afc44f0d53890db6bd32d9b2f0c6994e9ae6cc1490287e90290ddd4e0b9efeb6d5", null ]
    ] ],
    [ "c_ptr", "classwayland_1_1pointer__t.html#a869635f7ddc6678df2b93f8a13870c95", null ],
    [ "can_release", "classwayland_1_1pointer__t.html#a8df9396f5c1a41dcce4eab29947930da", null ],
    [ "get_class", "classwayland_1_1pointer__t.html#a8a77c6eab2f2eb4cfcca56be8a780d3e", null ],
    [ "get_id", "classwayland_1_1pointer__t.html#a273d7fd6604b65d4c4d24747b639a263", null ],
    [ "get_version", "classwayland_1_1pointer__t.html#a59444022b75257f6b27d2c464c371779", null ],
    [ "get_wrapper_type", "classwayland_1_1pointer__t.html#a65253c6ac727496735c0dc42a9fd1568", null ],
    [ "on_axis", "classwayland_1_1pointer__t.html#a27dffc3d57ba0f519d8e01beafee9a2d", null ],
    [ "on_axis_discrete", "classwayland_1_1pointer__t.html#a7f4d6c7a76b39f2c4fa842489391ece5", null ],
    [ "on_axis_source", "classwayland_1_1pointer__t.html#acffbc04af1fa57a107c91cb842458d07", null ],
    [ "on_axis_stop", "classwayland_1_1pointer__t.html#ad8962336f3c5e738842dc52e7b2beb79", null ],
    [ "on_axis_value120", "classwayland_1_1pointer__t.html#a4dfe57722cb2e437bc8db4953ccc9fc9", null ],
    [ "on_button", "classwayland_1_1pointer__t.html#a456627bdaad882af8cf29c88420f5f8d", null ],
    [ "on_enter", "classwayland_1_1pointer__t.html#a019637a78e2d15b957bf5df4647f1170", null ],
    [ "on_frame", "classwayland_1_1pointer__t.html#a81ec548f9ca0853201863c235caeda9a", null ],
    [ "on_leave", "classwayland_1_1pointer__t.html#a5db737d65756420ff3bebb7f6872ffea", null ],
    [ "on_motion", "classwayland_1_1pointer__t.html#afeffaacb31105b899f7fc61b6f32a8a0", null ],
    [ "operator bool", "classwayland_1_1pointer__t.html#aafa72a9121fa69ccfad6e9eff8740b5e", null ],
    [ "operator!=", "classwayland_1_1pointer__t.html#ac460e26f384624eb96647d533314240a", null ],
    [ "operator==", "classwayland_1_1pointer__t.html#a3dc433db4597e77caccb07f99b26a259", null ],
    [ "proxy_has_object", "classwayland_1_1pointer__t.html#a0c596640d7469447cb0b91dc9c8c22b2", null ],
    [ "proxy_release", "classwayland_1_1pointer__t.html#a0af69af8f839a5a5ea354e52705e9a43", null ],
    [ "release", "classwayland_1_1pointer__t.html#a666e1b16dd64813a1b455a3ea83b6b16", null ],
    [ "set_cursor", "classwayland_1_1pointer__t.html#ad38eddbe4bf02a414bd72c291816208c", null ],
    [ "set_queue", "classwayland_1_1pointer__t.html#a2065bb6f0ba51f29fdf16b8168bb5958", null ]
];