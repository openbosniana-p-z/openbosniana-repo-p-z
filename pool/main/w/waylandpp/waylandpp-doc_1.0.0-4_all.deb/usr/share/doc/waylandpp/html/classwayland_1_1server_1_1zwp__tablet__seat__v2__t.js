var classwayland_1_1server_1_1zwp__tablet__seat__v2__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1zwp__tablet__seat__v2__t.html#a3307747117d455f25052a90d04fc91bf", null ],
    [ "pad_added", "classwayland_1_1server_1_1zwp__tablet__seat__v2__t.html#ac617f718a625c9b204e9857e5dadb01a", null ],
    [ "tablet_added", "classwayland_1_1server_1_1zwp__tablet__seat__v2__t.html#aab58182b632c660d3da345a285d2b3e1", null ],
    [ "tool_added", "classwayland_1_1server_1_1zwp__tablet__seat__v2__t.html#ae3d6d77df10c3550c6d6c18d5883e598", null ]
];