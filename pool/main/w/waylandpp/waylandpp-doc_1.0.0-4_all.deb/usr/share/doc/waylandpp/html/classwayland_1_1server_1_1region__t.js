var classwayland_1_1server_1_1region__t =
[
    [ "on_add", "classwayland_1_1server_1_1region__t.html#aee18533425af8b07c568a607f9264dfc", null ],
    [ "on_destroy", "classwayland_1_1server_1_1region__t.html#ab36db802b4e20a16363651de5b2b2469", null ],
    [ "on_subtract", "classwayland_1_1server_1_1region__t.html#af47b6622999fa0eb3991540a69e07782", null ]
];