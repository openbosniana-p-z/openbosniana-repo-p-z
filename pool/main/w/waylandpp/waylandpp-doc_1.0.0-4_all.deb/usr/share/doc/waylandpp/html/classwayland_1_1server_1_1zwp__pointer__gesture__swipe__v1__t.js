var classwayland_1_1server_1_1zwp__pointer__gesture__swipe__v1__t =
[
    [ "begin", "classwayland_1_1server_1_1zwp__pointer__gesture__swipe__v1__t.html#ae297a725e58b754e63a9e627624bf485", null ],
    [ "end", "classwayland_1_1server_1_1zwp__pointer__gesture__swipe__v1__t.html#a18187445f0854fd86ab818015693fdad", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zwp__pointer__gesture__swipe__v1__t.html#a6698add62e79c3b76288accdc34d5e1c", null ],
    [ "update", "classwayland_1_1server_1_1zwp__pointer__gesture__swipe__v1__t.html#a20d7471ae2503e9c235d95602791cc6c", null ]
];