var classwayland_1_1server_1_1shell__surface__t =
[
    [ "configure", "classwayland_1_1server_1_1shell__surface__t.html#aca26ca31ee37ef6bf2224b009ec00cd0", null ],
    [ "on_move", "classwayland_1_1server_1_1shell__surface__t.html#a16be59f3adf1bafc373c81d70fdff564", null ],
    [ "on_pong", "classwayland_1_1server_1_1shell__surface__t.html#aa8e529b20d479bf4080f60a3f9b0d8b5", null ],
    [ "on_resize", "classwayland_1_1server_1_1shell__surface__t.html#a532992f53a3a303003796b4fe1f9381a", null ],
    [ "on_set_class", "classwayland_1_1server_1_1shell__surface__t.html#a4cf82112ab1c1dd52016cc03e978259d", null ],
    [ "on_set_fullscreen", "classwayland_1_1server_1_1shell__surface__t.html#a9a013aa7e0a3aa8deeece35e4005d918", null ],
    [ "on_set_maximized", "classwayland_1_1server_1_1shell__surface__t.html#a63afb46b6ce9faa738fcdb2fd8af34ca", null ],
    [ "on_set_popup", "classwayland_1_1server_1_1shell__surface__t.html#ad079e82de1cb1fe7bee54ee85daa8844", null ],
    [ "on_set_title", "classwayland_1_1server_1_1shell__surface__t.html#a59bea1a15c54b0b606db6ad8f41fc91f", null ],
    [ "on_set_toplevel", "classwayland_1_1server_1_1shell__surface__t.html#a9f3eea6a9f1fddd395ebbcf651430ab8", null ],
    [ "on_set_transient", "classwayland_1_1server_1_1shell__surface__t.html#a5fc7951e0321f4335af0b8642a43f402", null ],
    [ "ping", "classwayland_1_1server_1_1shell__surface__t.html#a741f527ef68d16fa56e35d46c282c6cb", null ],
    [ "popup_done", "classwayland_1_1server_1_1shell__surface__t.html#ab9868e71367191e94df2b361b2f31d05", null ]
];