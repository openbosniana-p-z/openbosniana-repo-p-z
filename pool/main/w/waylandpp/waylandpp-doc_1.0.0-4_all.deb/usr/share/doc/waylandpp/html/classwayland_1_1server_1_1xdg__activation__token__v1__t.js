var classwayland_1_1server_1_1xdg__activation__token__v1__t =
[
    [ "done", "classwayland_1_1server_1_1xdg__activation__token__v1__t.html#a9120154d32242c16bb31c9f13cd5f731", null ],
    [ "on_commit", "classwayland_1_1server_1_1xdg__activation__token__v1__t.html#a6be60f8b8bf2afed78d9e9d5bdd39f19", null ],
    [ "on_destroy", "classwayland_1_1server_1_1xdg__activation__token__v1__t.html#a32d2af56dea47cb5eb21705826b87f91", null ],
    [ "on_set_app_id", "classwayland_1_1server_1_1xdg__activation__token__v1__t.html#ac79ec260cbe8e97da4b55a609a56b7c6", null ],
    [ "on_set_serial", "classwayland_1_1server_1_1xdg__activation__token__v1__t.html#ace2a4410598c69dccbc4730b92759dd9", null ],
    [ "on_set_surface", "classwayland_1_1server_1_1xdg__activation__token__v1__t.html#aa3c3ac41260205b2174d1592cf8483c7", null ],
    [ "post_already_used", "classwayland_1_1server_1_1xdg__activation__token__v1__t.html#a2161cc151432d38c5280be4416664daf", null ]
];