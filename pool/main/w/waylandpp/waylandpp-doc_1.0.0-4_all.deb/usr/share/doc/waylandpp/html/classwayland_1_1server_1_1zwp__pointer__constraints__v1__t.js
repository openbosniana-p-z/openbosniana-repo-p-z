var classwayland_1_1server_1_1zwp__pointer__constraints__v1__t =
[
    [ "on_confine_pointer", "classwayland_1_1server_1_1zwp__pointer__constraints__v1__t.html#a01de708aac5ba83983bb6b8360935fc9", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zwp__pointer__constraints__v1__t.html#a83e504c290bf74bee4f2f31e12462f32", null ],
    [ "on_lock_pointer", "classwayland_1_1server_1_1zwp__pointer__constraints__v1__t.html#acbafe1eb422e47c5f3bd346c801b7d2d", null ],
    [ "post_already_constrained", "classwayland_1_1server_1_1zwp__pointer__constraints__v1__t.html#ac8a3d8c0497b418d36170c5747642f33", null ]
];