var classwayland_1_1server_1_1zwp__tablet__pad__v2__t =
[
    [ "button", "classwayland_1_1server_1_1zwp__tablet__pad__v2__t.html#a52cfe62eb2b8dd7bf7fb3199720c6e35", null ],
    [ "buttons", "classwayland_1_1server_1_1zwp__tablet__pad__v2__t.html#a9c0477a00453d409ad4676adbe52df57", null ],
    [ "done", "classwayland_1_1server_1_1zwp__tablet__pad__v2__t.html#a86b5fe1d824a58f23ba19cfe4612579a", null ],
    [ "enter", "classwayland_1_1server_1_1zwp__tablet__pad__v2__t.html#add5b089a4cc0b39146c25f534fef63aa", null ],
    [ "group", "classwayland_1_1server_1_1zwp__tablet__pad__v2__t.html#a99087b3a86c5ba83a65d51e8f72f275d", null ],
    [ "leave", "classwayland_1_1server_1_1zwp__tablet__pad__v2__t.html#a44ab1b5c52415ca243075e4c80355dae", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zwp__tablet__pad__v2__t.html#a49077e0ee0a0510494daab0870347469", null ],
    [ "on_set_feedback", "classwayland_1_1server_1_1zwp__tablet__pad__v2__t.html#a07a9b49496ac6ae0f13749445ca6baff", null ],
    [ "path", "classwayland_1_1server_1_1zwp__tablet__pad__v2__t.html#a464c6a4e789735e1c242c46648680a0c", null ],
    [ "removed", "classwayland_1_1server_1_1zwp__tablet__pad__v2__t.html#a5f31a96082edfc93b59947ad4367aa7a", null ]
];