var classwayland_1_1server_1_1zxdg__decoration__manager__v1__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1zxdg__decoration__manager__v1__t.html#ac72dbd1984c97e772ac1b6fc5a76dced", null ],
    [ "on_get_toplevel_decoration", "classwayland_1_1server_1_1zxdg__decoration__manager__v1__t.html#a675ad6097d23eb7c9ec49e4b566c1016", null ]
];