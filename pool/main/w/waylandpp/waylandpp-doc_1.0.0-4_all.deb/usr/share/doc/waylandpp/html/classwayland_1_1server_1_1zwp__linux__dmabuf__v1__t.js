var classwayland_1_1server_1_1zwp__linux__dmabuf__v1__t =
[
    [ "can_modifier", "classwayland_1_1server_1_1zwp__linux__dmabuf__v1__t.html#a8f686eee14243e28931c697f756a7c0e", null ],
    [ "format", "classwayland_1_1server_1_1zwp__linux__dmabuf__v1__t.html#aef46b2f72db62940a51769566db55db3", null ],
    [ "modifier", "classwayland_1_1server_1_1zwp__linux__dmabuf__v1__t.html#aee9383fb5f091831bc3a4fd564f7f34f", null ],
    [ "on_create_params", "classwayland_1_1server_1_1zwp__linux__dmabuf__v1__t.html#ad9d8cc60de6ca435b292fbcb9373800f", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zwp__linux__dmabuf__v1__t.html#a8d10a1d3fb55bba5ec336a5012efba06", null ],
    [ "on_get_default_feedback", "classwayland_1_1server_1_1zwp__linux__dmabuf__v1__t.html#acc93a6eb02f41cfd9c48070c9ade27bf", null ],
    [ "on_get_surface_feedback", "classwayland_1_1server_1_1zwp__linux__dmabuf__v1__t.html#a13f03f5dd4e4be771d4d3c1182886d3a", null ]
];