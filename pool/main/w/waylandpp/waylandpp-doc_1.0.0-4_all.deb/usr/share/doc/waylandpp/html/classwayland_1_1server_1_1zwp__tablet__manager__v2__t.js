var classwayland_1_1server_1_1zwp__tablet__manager__v2__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1zwp__tablet__manager__v2__t.html#a5e40a8453adc30a414074cee2bd0c960", null ],
    [ "on_get_tablet_seat", "classwayland_1_1server_1_1zwp__tablet__manager__v2__t.html#af8f547266d34b2505baba825aa22c06a", null ]
];