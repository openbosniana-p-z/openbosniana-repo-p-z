var classwayland_1_1server_1_1zwp__keyboard__shortcuts__inhibit__manager__v1__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1zwp__keyboard__shortcuts__inhibit__manager__v1__t.html#a2e6ca445b8645fa64ab63bc597508998", null ],
    [ "on_inhibit_shortcuts", "classwayland_1_1server_1_1zwp__keyboard__shortcuts__inhibit__manager__v1__t.html#a19f562f3656eccff868026d7a15ae505", null ],
    [ "post_already_inhibited", "classwayland_1_1server_1_1zwp__keyboard__shortcuts__inhibit__manager__v1__t.html#a23fc39c18a2a9faedc2e0832460ff8b3", null ]
];