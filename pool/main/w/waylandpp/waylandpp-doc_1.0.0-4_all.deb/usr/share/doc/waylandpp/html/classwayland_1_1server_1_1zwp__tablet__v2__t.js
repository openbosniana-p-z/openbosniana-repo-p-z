var classwayland_1_1server_1_1zwp__tablet__v2__t =
[
    [ "done", "classwayland_1_1server_1_1zwp__tablet__v2__t.html#abcad465e7ca1379648c97a699906cdaa", null ],
    [ "id", "classwayland_1_1server_1_1zwp__tablet__v2__t.html#a1fda263cc8976c75f60db6a157af74ef", null ],
    [ "name", "classwayland_1_1server_1_1zwp__tablet__v2__t.html#abe6e121a6bcdc1c12afa4d4d71dc453b", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zwp__tablet__v2__t.html#af48167d0edf0dd212e30889d63bf3bf6", null ],
    [ "path", "classwayland_1_1server_1_1zwp__tablet__v2__t.html#a99c27fab7181de3d4926ac5306469a99", null ],
    [ "removed", "classwayland_1_1server_1_1zwp__tablet__v2__t.html#a043745fa970ce794eade975e8db75a4f", null ]
];