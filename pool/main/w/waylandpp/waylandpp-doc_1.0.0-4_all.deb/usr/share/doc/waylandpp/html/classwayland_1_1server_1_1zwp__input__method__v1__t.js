var classwayland_1_1server_1_1zwp__input__method__v1__t =
[
    [ "activate", "classwayland_1_1server_1_1zwp__input__method__v1__t.html#a7ec57dac46c57c315ad346fcd1372ca9", null ],
    [ "deactivate", "classwayland_1_1server_1_1zwp__input__method__v1__t.html#a8a8df7dd985044ec41ad693971810d85", null ]
];