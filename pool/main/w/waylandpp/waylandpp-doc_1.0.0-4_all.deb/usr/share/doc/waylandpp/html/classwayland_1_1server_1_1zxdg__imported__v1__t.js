var classwayland_1_1server_1_1zxdg__imported__v1__t =
[
    [ "destroyed", "classwayland_1_1server_1_1zxdg__imported__v1__t.html#a59783d2cf07b6d52fb6ee44f59212230", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zxdg__imported__v1__t.html#a8743b7bffd992dad2deb9134b0fe9e7c", null ],
    [ "on_set_parent_of", "classwayland_1_1server_1_1zxdg__imported__v1__t.html#a7e4d3d959eafffd6f6c3199d24623f9e", null ]
];