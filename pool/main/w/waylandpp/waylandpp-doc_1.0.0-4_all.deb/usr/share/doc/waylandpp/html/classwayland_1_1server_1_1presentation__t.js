var classwayland_1_1server_1_1presentation__t =
[
    [ "clock_id", "classwayland_1_1server_1_1presentation__t.html#adecf6807f7e51b7f7363ca05d91bb763", null ],
    [ "on_destroy", "classwayland_1_1server_1_1presentation__t.html#a8b094c92dc975ecbdb5d947571fdf315", null ],
    [ "on_feedback", "classwayland_1_1server_1_1presentation__t.html#a6002ca68a81cd5d9a989422a984e12fc", null ],
    [ "post_invalid_flag", "classwayland_1_1server_1_1presentation__t.html#ab9778a512fa99b57089b111e4c2bdbe4", null ],
    [ "post_invalid_timestamp", "classwayland_1_1server_1_1presentation__t.html#a020c01c934148a442cb83b4004159ac7", null ]
];