var classwayland_1_1server_1_1surface__t =
[
    [ "enter", "classwayland_1_1server_1_1surface__t.html#a0b78d1ef7ceeb774b9d80d0565e14adb", null ],
    [ "leave", "classwayland_1_1server_1_1surface__t.html#ad558be20f8bacd0ff3fdf3718f76b846", null ],
    [ "on_attach", "classwayland_1_1server_1_1surface__t.html#a0f3f8e145478dab3d9ecd0d6b512d606", null ],
    [ "on_commit", "classwayland_1_1server_1_1surface__t.html#ac0095a248d0dc2d4c8bd59f1036f6c35", null ],
    [ "on_damage", "classwayland_1_1server_1_1surface__t.html#a6a39f73a505ad75be72745654eccb781", null ],
    [ "on_damage_buffer", "classwayland_1_1server_1_1surface__t.html#acd500ed6a51b97ab834dd00089f97319", null ],
    [ "on_destroy", "classwayland_1_1server_1_1surface__t.html#ae8fb9425a661b3f11f1f794393602956", null ],
    [ "on_frame", "classwayland_1_1server_1_1surface__t.html#a7c92cf4726a865f0864a02e9089a02fd", null ],
    [ "on_offset", "classwayland_1_1server_1_1surface__t.html#a891f3b32f13ba16a609ea92a050161aa", null ],
    [ "on_set_buffer_scale", "classwayland_1_1server_1_1surface__t.html#aa0924e9e48500d35df68348de21611cb", null ],
    [ "on_set_buffer_transform", "classwayland_1_1server_1_1surface__t.html#afdf07d2be151ec750c1259494fcef848", null ],
    [ "on_set_input_region", "classwayland_1_1server_1_1surface__t.html#a30c0146bfd1e2256dc31832064ecad2c", null ],
    [ "on_set_opaque_region", "classwayland_1_1server_1_1surface__t.html#ab633f4073fea66978b5ad2fcc8e83a6b", null ],
    [ "post_invalid_offset", "classwayland_1_1server_1_1surface__t.html#a165317607ae5d10c030a2fa4e1d0b89e", null ],
    [ "post_invalid_scale", "classwayland_1_1server_1_1surface__t.html#a5f9b60343a962a22317eaee7289adc8f", null ],
    [ "post_invalid_size", "classwayland_1_1server_1_1surface__t.html#aa9392ad659256b6470df8ab43847410c", null ],
    [ "post_invalid_transform", "classwayland_1_1server_1_1surface__t.html#aea4ecffda6d845583cc70e46a098db27", null ]
];