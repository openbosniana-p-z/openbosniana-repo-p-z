var classwayland_1_1server_1_1zwp__tablet__seat__v1__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1zwp__tablet__seat__v1__t.html#a740633f36e5240799b022f5524e88865", null ],
    [ "tablet_added", "classwayland_1_1server_1_1zwp__tablet__seat__v1__t.html#a02e9bfd632eae0fee1feec44e9ab145e", null ],
    [ "tool_added", "classwayland_1_1server_1_1zwp__tablet__seat__v1__t.html#a0ae9f86630384f5f37d3c6b654fdd3a0", null ]
];