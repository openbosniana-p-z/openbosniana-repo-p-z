var classwayland_1_1server_1_1zwp__linux__buffer__params__v1__t =
[
    [ "created", "classwayland_1_1server_1_1zwp__linux__buffer__params__v1__t.html#a88901db6bfd05fcb73264f490a4c7e74", null ],
    [ "failed", "classwayland_1_1server_1_1zwp__linux__buffer__params__v1__t.html#a491b345323b54c29ee51a1716289a7cd", null ],
    [ "on_add", "classwayland_1_1server_1_1zwp__linux__buffer__params__v1__t.html#a92f3acee51e124f0aef8197f18f6331a", null ],
    [ "on_create", "classwayland_1_1server_1_1zwp__linux__buffer__params__v1__t.html#abbd681c519229a5a999baf8c5e05fede", null ],
    [ "on_create_immed", "classwayland_1_1server_1_1zwp__linux__buffer__params__v1__t.html#af6fd898da00e6e6d94ea1a2847e363e1", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zwp__linux__buffer__params__v1__t.html#aeeecf462a5414670f4531ed9f3fda1a5", null ],
    [ "post_already_used", "classwayland_1_1server_1_1zwp__linux__buffer__params__v1__t.html#a610cf734c7fc6b43f04e052372a2a6ee", null ],
    [ "post_incomplete", "classwayland_1_1server_1_1zwp__linux__buffer__params__v1__t.html#a50f53a5b43b2e10d982b2bc8785dbacb", null ],
    [ "post_invalid_dimensions", "classwayland_1_1server_1_1zwp__linux__buffer__params__v1__t.html#aede74269bbdd5c0ce461445afd9bd495", null ],
    [ "post_invalid_format", "classwayland_1_1server_1_1zwp__linux__buffer__params__v1__t.html#a91055351c2df5936c009761c27146808", null ],
    [ "post_invalid_wl_buffer", "classwayland_1_1server_1_1zwp__linux__buffer__params__v1__t.html#aaf42493309768ee398b0e4ac7672e055", null ],
    [ "post_out_of_bounds", "classwayland_1_1server_1_1zwp__linux__buffer__params__v1__t.html#a90a00d8b14471775c093c58df2c4bbf3", null ],
    [ "post_plane_idx", "classwayland_1_1server_1_1zwp__linux__buffer__params__v1__t.html#ad7f63c5f888a92d46f042d33fbc20670", null ],
    [ "post_plane_set", "classwayland_1_1server_1_1zwp__linux__buffer__params__v1__t.html#af0f76885facf68fc4741dc608a7d98c5", null ]
];