var classwayland_1_1server_1_1touch__t =
[
    [ "can_orientation", "classwayland_1_1server_1_1touch__t.html#ae21b6cf53d08d7e6b9978dcdc9ed33fc", null ],
    [ "can_shape", "classwayland_1_1server_1_1touch__t.html#aa01c960f6572977da4ed76734ec76f03", null ],
    [ "cancel", "classwayland_1_1server_1_1touch__t.html#a0dc8840519857b271a77175e43ef5d3c", null ],
    [ "down", "classwayland_1_1server_1_1touch__t.html#a49858172b4ae246a3580fd1fb0ed3225", null ],
    [ "frame", "classwayland_1_1server_1_1touch__t.html#abf62c186000788bb0706f3fee64a741d", null ],
    [ "motion", "classwayland_1_1server_1_1touch__t.html#a12cc77008fb7f855daab8155a3b67490", null ],
    [ "on_release", "classwayland_1_1server_1_1touch__t.html#aec297584792cedbb0828f35f0b523c3e", null ],
    [ "orientation", "classwayland_1_1server_1_1touch__t.html#a2a87be11cd1e3e8437ac57c6d05c01bd", null ],
    [ "shape", "classwayland_1_1server_1_1touch__t.html#a7f58e5bf3fd04f3996edd4ad482032af", null ],
    [ "up", "classwayland_1_1server_1_1touch__t.html#a3148326d0398d50042785f9d92d9ee90", null ]
];