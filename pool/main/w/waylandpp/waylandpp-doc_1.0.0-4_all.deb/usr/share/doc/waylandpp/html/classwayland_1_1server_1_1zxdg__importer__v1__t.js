var classwayland_1_1server_1_1zxdg__importer__v1__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1zxdg__importer__v1__t.html#ae0915e5d4189fd9c881c5ad38ec1e047", null ],
    [ "on_import", "classwayland_1_1server_1_1zxdg__importer__v1__t.html#ac366c7d81c30548cab5f77b310a8ed8a", null ]
];