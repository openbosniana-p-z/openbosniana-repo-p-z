var classwayland_1_1server_1_1zwp__linux__explicit__synchronization__v1__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1zwp__linux__explicit__synchronization__v1__t.html#a68e03dba43165f5533581b8a98fa5f17", null ],
    [ "on_get_synchronization", "classwayland_1_1server_1_1zwp__linux__explicit__synchronization__v1__t.html#a7d24f300295021f16711a188cae1a81f", null ],
    [ "post_synchronization_exists", "classwayland_1_1server_1_1zwp__linux__explicit__synchronization__v1__t.html#ab82090b1211d9420b816fe195c30daa4", null ]
];