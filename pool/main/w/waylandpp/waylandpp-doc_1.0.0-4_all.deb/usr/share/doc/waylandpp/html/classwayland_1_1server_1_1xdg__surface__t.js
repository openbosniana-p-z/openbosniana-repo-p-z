var classwayland_1_1server_1_1xdg__surface__t =
[
    [ "configure", "classwayland_1_1server_1_1xdg__surface__t.html#a5beec99a93f37bac70784022c9b94c16", null ],
    [ "on_ack_configure", "classwayland_1_1server_1_1xdg__surface__t.html#a83d8742245a49ce8da69177f74f058ca", null ],
    [ "on_destroy", "classwayland_1_1server_1_1xdg__surface__t.html#a1a6fb075848bb1be779998c58b4f57b6", null ],
    [ "on_get_popup", "classwayland_1_1server_1_1xdg__surface__t.html#ad75a834647e6981413bc8c2bb8df9625", null ],
    [ "on_get_toplevel", "classwayland_1_1server_1_1xdg__surface__t.html#a491c7f78cb51c3e513c16665df952a9b", null ],
    [ "on_set_window_geometry", "classwayland_1_1server_1_1xdg__surface__t.html#a609c20b4f076301ac2bc721f6b88b2fb", null ],
    [ "post_already_constructed", "classwayland_1_1server_1_1xdg__surface__t.html#a4646ec26f07f8c9aad28012f7119e896", null ],
    [ "post_not_constructed", "classwayland_1_1server_1_1xdg__surface__t.html#a38a92be1878eb3e7cfa5f8741760be23", null ],
    [ "post_unconfigured_buffer", "classwayland_1_1server_1_1xdg__surface__t.html#a503a6f682e11892069e3e0534079996b", null ]
];