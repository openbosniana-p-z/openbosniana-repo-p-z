var classwayland_1_1server_1_1zwp__linux__surface__synchronization__v1__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1zwp__linux__surface__synchronization__v1__t.html#a35dd96f927a6be4e8229a0bd2df56903", null ],
    [ "on_get_release", "classwayland_1_1server_1_1zwp__linux__surface__synchronization__v1__t.html#ab64403f5de559209e839e72a2e2ed99e", null ],
    [ "on_set_acquire_fence", "classwayland_1_1server_1_1zwp__linux__surface__synchronization__v1__t.html#a026dc35f85aadc11e0758e5af14de373", null ],
    [ "post_duplicate_fence", "classwayland_1_1server_1_1zwp__linux__surface__synchronization__v1__t.html#a80b22387376f69911e6bc67b52f82051", null ],
    [ "post_duplicate_release", "classwayland_1_1server_1_1zwp__linux__surface__synchronization__v1__t.html#a0f83ed959d2a223c79ed0ff287ccc0cb", null ],
    [ "post_invalid_fence", "classwayland_1_1server_1_1zwp__linux__surface__synchronization__v1__t.html#ab2b5b2f308bf654b269f5502c8293596", null ],
    [ "post_no_buffer", "classwayland_1_1server_1_1zwp__linux__surface__synchronization__v1__t.html#a79635d6333b8dcea2409935c4689cd63", null ],
    [ "post_no_surface", "classwayland_1_1server_1_1zwp__linux__surface__synchronization__v1__t.html#ac9f62ea6ab3a86d228ecd1204689e5a2", null ],
    [ "post_unsupported_buffer", "classwayland_1_1server_1_1zwp__linux__surface__synchronization__v1__t.html#a64f56236a1692e38a2f8b6581fe23e6d", null ]
];