var classwayland_1_1server_1_1zwp__linux__buffer__release__v1__t =
[
    [ "fenced_release", "classwayland_1_1server_1_1zwp__linux__buffer__release__v1__t.html#a8526cbc02738e8984bb582d30120b18a", null ],
    [ "immediate_release", "classwayland_1_1server_1_1zwp__linux__buffer__release__v1__t.html#a3875e6596aef3d668c4ff466c8821d55", null ]
];