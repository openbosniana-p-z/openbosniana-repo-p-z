var classwayland_1_1server_1_1zwp__pointer__gesture__hold__v1__t =
[
    [ "begin", "classwayland_1_1server_1_1zwp__pointer__gesture__hold__v1__t.html#ad9a490f63280c2807c213628af4f6c38", null ],
    [ "can_begin", "classwayland_1_1server_1_1zwp__pointer__gesture__hold__v1__t.html#ae1d760dbc4fef40c2b03cb84f86f6ee5", null ],
    [ "can_end", "classwayland_1_1server_1_1zwp__pointer__gesture__hold__v1__t.html#a06fc037904225080b23f70734f844b11", null ],
    [ "end", "classwayland_1_1server_1_1zwp__pointer__gesture__hold__v1__t.html#a2e00b7e89a745d5e29b02e2de3e004e1", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zwp__pointer__gesture__hold__v1__t.html#a635b07dab458d703fdbd5e6ac5fa9d34", null ]
];