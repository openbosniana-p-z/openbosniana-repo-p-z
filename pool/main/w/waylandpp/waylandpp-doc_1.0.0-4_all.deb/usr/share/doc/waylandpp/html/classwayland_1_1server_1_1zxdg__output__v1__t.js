var classwayland_1_1server_1_1zxdg__output__v1__t =
[
    [ "can_description", "classwayland_1_1server_1_1zxdg__output__v1__t.html#a4a5f0fc5e02220dd4ca425aa82366bcc", null ],
    [ "can_name", "classwayland_1_1server_1_1zxdg__output__v1__t.html#a289ac42d576b438031e97ec48648213c", null ],
    [ "description", "classwayland_1_1server_1_1zxdg__output__v1__t.html#ae49857c2296b8cb7cf6c5f1cb1a692ab", null ],
    [ "done", "classwayland_1_1server_1_1zxdg__output__v1__t.html#a29c268f916a439c1dc765df7330a3bd1", null ],
    [ "logical_position", "classwayland_1_1server_1_1zxdg__output__v1__t.html#a29c22bf9938b60dc6d3a6e9205483da4", null ],
    [ "logical_size", "classwayland_1_1server_1_1zxdg__output__v1__t.html#a78d703d8bb7fee5f39fa5a1db82ff2a1", null ],
    [ "name", "classwayland_1_1server_1_1zxdg__output__v1__t.html#adfe772b8ce33b36d92aafdaae5d82c58", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zxdg__output__v1__t.html#aaa447fffed2675736f3977b24280ad90", null ]
];