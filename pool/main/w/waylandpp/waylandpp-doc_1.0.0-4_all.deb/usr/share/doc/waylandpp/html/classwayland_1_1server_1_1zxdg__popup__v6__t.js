var classwayland_1_1server_1_1zxdg__popup__v6__t =
[
    [ "configure", "classwayland_1_1server_1_1zxdg__popup__v6__t.html#aff7d7589145f683fed02eacf2393a011", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zxdg__popup__v6__t.html#ac901f6f31fe221abb7ad3cfc7fc17e29", null ],
    [ "on_grab", "classwayland_1_1server_1_1zxdg__popup__v6__t.html#ab9bc559bbcc41d756c56d63e8b4a1751", null ],
    [ "popup_done", "classwayland_1_1server_1_1zxdg__popup__v6__t.html#a467113bb23ff780b626852b62a2b9651", null ],
    [ "post_invalid_grab", "classwayland_1_1server_1_1zxdg__popup__v6__t.html#a1edd1f4a3fcfc52841a0fe9721896b49", null ]
];