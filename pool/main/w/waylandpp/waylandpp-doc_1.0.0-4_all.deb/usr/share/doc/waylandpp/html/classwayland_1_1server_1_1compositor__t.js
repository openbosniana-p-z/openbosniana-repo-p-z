var classwayland_1_1server_1_1compositor__t =
[
    [ "on_create_region", "classwayland_1_1server_1_1compositor__t.html#a87d7f0172f3d3d46d95a076b4c89a166", null ],
    [ "on_create_surface", "classwayland_1_1server_1_1compositor__t.html#a13b1cb8245e09b1c5ea5d5f556636b89", null ]
];