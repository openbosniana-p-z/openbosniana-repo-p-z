var classwayland_1_1server_1_1data__device__t =
[
    [ "data_offer", "classwayland_1_1server_1_1data__device__t.html#ac76f7f97d946e4b2784622dfd03f1dab", null ],
    [ "drop", "classwayland_1_1server_1_1data__device__t.html#af169b228cad072e54fb52eaeb73dc093", null ],
    [ "enter", "classwayland_1_1server_1_1data__device__t.html#aa16dc4e2d0d33dcd02e6327688b35f8d", null ],
    [ "leave", "classwayland_1_1server_1_1data__device__t.html#ab1e60cf1bc8aecd5d56ef558aedf5bcc", null ],
    [ "motion", "classwayland_1_1server_1_1data__device__t.html#ad369438a4ca9f20e2482be5538ca5dad", null ],
    [ "on_release", "classwayland_1_1server_1_1data__device__t.html#a532067cc30d91d0ea5a99a12373b1f88", null ],
    [ "on_set_selection", "classwayland_1_1server_1_1data__device__t.html#a1ba6932ab35a4d79c18885080dc277b1", null ],
    [ "on_start_drag", "classwayland_1_1server_1_1data__device__t.html#ae7deae3d783354806c750dffa0341d5a", null ],
    [ "post_role", "classwayland_1_1server_1_1data__device__t.html#a0fc0787d10418251a2bd495d5da2798c", null ],
    [ "selection", "classwayland_1_1server_1_1data__device__t.html#af9231cb7a3963e63e4952e789527defa", null ]
];