var classwayland_1_1server_1_1zwp__keyboard__shortcuts__inhibitor__v1__t =
[
    [ "active", "classwayland_1_1server_1_1zwp__keyboard__shortcuts__inhibitor__v1__t.html#a6293e1fac7fb6b946d3d0c92bbff4412", null ],
    [ "inactive", "classwayland_1_1server_1_1zwp__keyboard__shortcuts__inhibitor__v1__t.html#a4982029e4ca6112aa3253a9bea901010", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zwp__keyboard__shortcuts__inhibitor__v1__t.html#a2d84f438f135b9715cfb4386bbdac761", null ]
];