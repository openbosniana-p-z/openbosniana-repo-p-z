var classwayland_1_1server_1_1zwp__input__panel__v1__t =
[
    [ "on_get_input_panel_surface", "classwayland_1_1server_1_1zwp__input__panel__v1__t.html#aaeda41a88f6bc1e58b58fdacacd7422b", null ]
];