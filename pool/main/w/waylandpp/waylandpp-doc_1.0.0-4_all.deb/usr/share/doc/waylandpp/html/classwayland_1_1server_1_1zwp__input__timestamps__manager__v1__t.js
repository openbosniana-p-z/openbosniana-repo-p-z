var classwayland_1_1server_1_1zwp__input__timestamps__manager__v1__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1zwp__input__timestamps__manager__v1__t.html#ad5021e50bf6ec9a40fe8ce1286c18d04", null ],
    [ "on_get_keyboard_timestamps", "classwayland_1_1server_1_1zwp__input__timestamps__manager__v1__t.html#a2ce7f5340bc7f9b0ff87d1394e05b326", null ],
    [ "on_get_pointer_timestamps", "classwayland_1_1server_1_1zwp__input__timestamps__manager__v1__t.html#abebece9160317f95ea4af7df3d9f200a", null ],
    [ "on_get_touch_timestamps", "classwayland_1_1server_1_1zwp__input__timestamps__manager__v1__t.html#aa18008d3fbb229ec8669de1dad7e3c57", null ]
];