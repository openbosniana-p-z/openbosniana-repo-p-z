var classwayland_1_1server_1_1xdg__wm__base__t =
[
    [ "on_create_positioner", "classwayland_1_1server_1_1xdg__wm__base__t.html#aae4c9169bee46ff5f469018529f028bd", null ],
    [ "on_destroy", "classwayland_1_1server_1_1xdg__wm__base__t.html#a3dc7521f9e35ac67886d45aacdd8bf2d", null ],
    [ "on_get_xdg_surface", "classwayland_1_1server_1_1xdg__wm__base__t.html#abbd1c0e252113b24164de86c83b488db", null ],
    [ "on_pong", "classwayland_1_1server_1_1xdg__wm__base__t.html#a4caaed82511e05b46fdc25cedaf7beab", null ],
    [ "ping", "classwayland_1_1server_1_1xdg__wm__base__t.html#aa1ad185e9382eeba195f73f5d796bcbf", null ],
    [ "post_defunct_surfaces", "classwayland_1_1server_1_1xdg__wm__base__t.html#a8ee9cd1bb13bc522ce8c22f586cee281", null ],
    [ "post_invalid_popup_parent", "classwayland_1_1server_1_1xdg__wm__base__t.html#a7c80e14868c9c789105602a48ad70621", null ],
    [ "post_invalid_positioner", "classwayland_1_1server_1_1xdg__wm__base__t.html#ab4a68eca6d3a0b94a66bfcb8343c4b42", null ],
    [ "post_invalid_surface_state", "classwayland_1_1server_1_1xdg__wm__base__t.html#a725e691bb13c12f9726cd7da84d4f96f", null ],
    [ "post_not_the_topmost_popup", "classwayland_1_1server_1_1xdg__wm__base__t.html#aef67e1d8059b086392fffd5c9213dc73", null ],
    [ "post_role", "classwayland_1_1server_1_1xdg__wm__base__t.html#a8a5e9b26de8e9f10501e52126e70aae2", null ]
];