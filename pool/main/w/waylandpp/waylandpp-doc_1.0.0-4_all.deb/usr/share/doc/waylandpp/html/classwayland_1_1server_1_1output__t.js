var classwayland_1_1server_1_1output__t =
[
    [ "can_description", "classwayland_1_1server_1_1output__t.html#aa59397396df6342362756386e2c7f814", null ],
    [ "can_done", "classwayland_1_1server_1_1output__t.html#a9ccffacec3ddd122bc11f2160b8ce066", null ],
    [ "can_name", "classwayland_1_1server_1_1output__t.html#a57ffaf7f5d0beac0ddd17ed9914993b7", null ],
    [ "can_scale", "classwayland_1_1server_1_1output__t.html#a9cbb3b024147abc4203f97553b6118ea", null ],
    [ "description", "classwayland_1_1server_1_1output__t.html#a9e9755f01055d6ccc622d22c049fb070", null ],
    [ "done", "classwayland_1_1server_1_1output__t.html#a616d05ced80ae242a1d6876501a767fa", null ],
    [ "geometry", "classwayland_1_1server_1_1output__t.html#a64286c62c499fe4211bb11921fad335e", null ],
    [ "mode", "classwayland_1_1server_1_1output__t.html#a5a6dc1327e868cf00f54c89cfab33912", null ],
    [ "name", "classwayland_1_1server_1_1output__t.html#a59b75192fe66244177f5a2377a5fe8e6", null ],
    [ "on_release", "classwayland_1_1server_1_1output__t.html#a4a8c8877214307998ec997930380687d", null ],
    [ "scale", "classwayland_1_1server_1_1output__t.html#a861f350d558b7a9627cbf8b84918d3a7", null ]
];