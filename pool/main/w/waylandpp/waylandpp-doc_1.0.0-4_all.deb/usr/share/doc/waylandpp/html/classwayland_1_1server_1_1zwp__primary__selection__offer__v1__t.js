var classwayland_1_1server_1_1zwp__primary__selection__offer__v1__t =
[
    [ "offer", "classwayland_1_1server_1_1zwp__primary__selection__offer__v1__t.html#a22e7d935dee90ae64b019be226c055f6", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zwp__primary__selection__offer__v1__t.html#ab84a38b866ee920c9e60352005dad76b", null ],
    [ "on_receive", "classwayland_1_1server_1_1zwp__primary__selection__offer__v1__t.html#a9c123fa69e19b483dabe4a6ad3609d76", null ]
];