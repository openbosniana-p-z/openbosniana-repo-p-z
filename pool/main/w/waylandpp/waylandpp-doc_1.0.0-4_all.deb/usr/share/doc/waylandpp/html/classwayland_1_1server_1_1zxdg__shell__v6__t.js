var classwayland_1_1server_1_1zxdg__shell__v6__t =
[
    [ "on_create_positioner", "classwayland_1_1server_1_1zxdg__shell__v6__t.html#a9b01427ec5ef50f2e8a4bc840f94da0d", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zxdg__shell__v6__t.html#ae695de212f8317bd96c2430f523f6a6a", null ],
    [ "on_get_xdg_surface", "classwayland_1_1server_1_1zxdg__shell__v6__t.html#acf4e4f49206334d0c0ad22ba2c6841dc", null ],
    [ "on_pong", "classwayland_1_1server_1_1zxdg__shell__v6__t.html#ab4e061fc7ac71a3059a79a6f5a3b2edf", null ],
    [ "ping", "classwayland_1_1server_1_1zxdg__shell__v6__t.html#a710ae423add4ad28226b718b99a878b8", null ],
    [ "post_defunct_surfaces", "classwayland_1_1server_1_1zxdg__shell__v6__t.html#a75b0b6146e85ed3d0ed54cda1d3ecdeb", null ],
    [ "post_invalid_popup_parent", "classwayland_1_1server_1_1zxdg__shell__v6__t.html#ae31e68ec2b92180f43ebfd1c79f78c6a", null ],
    [ "post_invalid_positioner", "classwayland_1_1server_1_1zxdg__shell__v6__t.html#a4b088b00203217a1aef82aa66f9a487e", null ],
    [ "post_invalid_surface_state", "classwayland_1_1server_1_1zxdg__shell__v6__t.html#a1e25a66a6ab4b709ee80fadc5e29c4b2", null ],
    [ "post_not_the_topmost_popup", "classwayland_1_1server_1_1zxdg__shell__v6__t.html#ae2f3fec994300723e0e38313f4bd8a9f", null ],
    [ "post_role", "classwayland_1_1server_1_1zxdg__shell__v6__t.html#abb6919ce24a632ba2694dad8b6cb537b", null ]
];