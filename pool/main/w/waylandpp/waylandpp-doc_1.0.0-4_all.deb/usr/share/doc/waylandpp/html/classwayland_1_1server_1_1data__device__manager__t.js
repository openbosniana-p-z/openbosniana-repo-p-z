var classwayland_1_1server_1_1data__device__manager__t =
[
    [ "on_create_data_source", "classwayland_1_1server_1_1data__device__manager__t.html#a37df0e85246437153fb5c18558a89793", null ],
    [ "on_get_data_device", "classwayland_1_1server_1_1data__device__manager__t.html#a30c6ba21ebde0a86b70a794810538478", null ]
];