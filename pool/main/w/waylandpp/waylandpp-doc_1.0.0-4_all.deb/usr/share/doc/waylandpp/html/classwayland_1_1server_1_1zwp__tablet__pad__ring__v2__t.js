var classwayland_1_1server_1_1zwp__tablet__pad__ring__v2__t =
[
    [ "angle", "classwayland_1_1server_1_1zwp__tablet__pad__ring__v2__t.html#aa367f52dd9dccd3613c552157d1be778", null ],
    [ "frame", "classwayland_1_1server_1_1zwp__tablet__pad__ring__v2__t.html#aecb48658d188bc70cb838d42339ab980", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zwp__tablet__pad__ring__v2__t.html#aa48988004de9a2071195d8a79bdf704e", null ],
    [ "on_set_feedback", "classwayland_1_1server_1_1zwp__tablet__pad__ring__v2__t.html#aadd6d7a96144bb05836469bd91559c9f", null ],
    [ "source", "classwayland_1_1server_1_1zwp__tablet__pad__ring__v2__t.html#ab1ffeb2e97b1159b5eb6d6a42835b5e0", null ],
    [ "stop", "classwayland_1_1server_1_1zwp__tablet__pad__ring__v2__t.html#ab2fae15fb1eee670ca10019b49f79199", null ]
];