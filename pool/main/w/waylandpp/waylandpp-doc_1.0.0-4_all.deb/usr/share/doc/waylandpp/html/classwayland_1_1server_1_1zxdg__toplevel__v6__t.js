var classwayland_1_1server_1_1zxdg__toplevel__v6__t =
[
    [ "close", "classwayland_1_1server_1_1zxdg__toplevel__v6__t.html#aa3a818989947944434d7081797754fdb", null ],
    [ "configure", "classwayland_1_1server_1_1zxdg__toplevel__v6__t.html#aeeb7f75b7d1edeb6e695e8f6577ddb92", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zxdg__toplevel__v6__t.html#ac10514b8ab5b3093f8cd7b46ed7472f1", null ],
    [ "on_move", "classwayland_1_1server_1_1zxdg__toplevel__v6__t.html#aa10f6452c9e694e93ce6aa38fa86f1a6", null ],
    [ "on_resize", "classwayland_1_1server_1_1zxdg__toplevel__v6__t.html#ae3f8418b338d62ba825dabaaf0e71441", null ],
    [ "on_set_app_id", "classwayland_1_1server_1_1zxdg__toplevel__v6__t.html#a5d76433632ddd2ae3c04910af6bdf77b", null ],
    [ "on_set_fullscreen", "classwayland_1_1server_1_1zxdg__toplevel__v6__t.html#a6f06a85682e3e7759cb39297bb29ead3", null ],
    [ "on_set_max_size", "classwayland_1_1server_1_1zxdg__toplevel__v6__t.html#ae670928401ca19a1e64045a44b1677f8", null ],
    [ "on_set_maximized", "classwayland_1_1server_1_1zxdg__toplevel__v6__t.html#aa7ba2ff663ff86ec81310f145faf3396", null ],
    [ "on_set_min_size", "classwayland_1_1server_1_1zxdg__toplevel__v6__t.html#ab87e6d2ecc7d1fc63d50a87c986ff0fc", null ],
    [ "on_set_minimized", "classwayland_1_1server_1_1zxdg__toplevel__v6__t.html#ae07ffb3d8abceb017a34ca0234df034b", null ],
    [ "on_set_parent", "classwayland_1_1server_1_1zxdg__toplevel__v6__t.html#aa99feded5b4fa35db441feed73ffe3b5", null ],
    [ "on_set_title", "classwayland_1_1server_1_1zxdg__toplevel__v6__t.html#a56d7bc048db88d2c9318a1ed199728c4", null ],
    [ "on_show_window_menu", "classwayland_1_1server_1_1zxdg__toplevel__v6__t.html#ab6e29131a29d245759354753c4c4bed3", null ],
    [ "on_unset_maximized", "classwayland_1_1server_1_1zxdg__toplevel__v6__t.html#aa27a523630a6e1692b9ee0777f8c2a01", null ]
];