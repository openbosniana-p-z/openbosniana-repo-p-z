var classwayland_1_1server_1_1subsurface__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1subsurface__t.html#a9bdd9ec982fbbe0044b292980998824c", null ],
    [ "on_place_above", "classwayland_1_1server_1_1subsurface__t.html#a7a460db3c471a019448daf23b9aae5ce", null ],
    [ "on_place_below", "classwayland_1_1server_1_1subsurface__t.html#a49862fa5c346c59b4563db8268f899fc", null ],
    [ "on_set_desync", "classwayland_1_1server_1_1subsurface__t.html#a1a638b3bc22168563f2fb074e20348af", null ],
    [ "on_set_position", "classwayland_1_1server_1_1subsurface__t.html#a467a60a0b26302125701029a3b4e7d9a", null ],
    [ "on_set_sync", "classwayland_1_1server_1_1subsurface__t.html#a19cfa1479c808e1b65af8e4114821cbb", null ],
    [ "post_bad_surface", "classwayland_1_1server_1_1subsurface__t.html#a891067d3ba30776f684f13a187fb30a8", null ]
];