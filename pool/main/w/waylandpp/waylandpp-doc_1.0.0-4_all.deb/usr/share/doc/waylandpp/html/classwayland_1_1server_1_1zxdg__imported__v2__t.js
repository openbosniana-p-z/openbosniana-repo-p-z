var classwayland_1_1server_1_1zxdg__imported__v2__t =
[
    [ "destroyed", "classwayland_1_1server_1_1zxdg__imported__v2__t.html#a3d648195f731e4c14b626db85abd28b3", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zxdg__imported__v2__t.html#a6c6773d4199e40022eb0a85677c9ef65", null ],
    [ "on_set_parent_of", "classwayland_1_1server_1_1zxdg__imported__v2__t.html#ae4fa9b9b6dee70f0b3322289aa4eab30", null ],
    [ "post_invalid_surface", "classwayland_1_1server_1_1zxdg__imported__v2__t.html#a2be94bff97fe6b3179359f6c3345794a", null ]
];