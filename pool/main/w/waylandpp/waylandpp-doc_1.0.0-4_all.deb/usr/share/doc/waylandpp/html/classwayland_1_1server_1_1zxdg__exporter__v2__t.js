var classwayland_1_1server_1_1zxdg__exporter__v2__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1zxdg__exporter__v2__t.html#a31f8585c731df0876d6bcbc46183a832", null ],
    [ "on_export_toplevel", "classwayland_1_1server_1_1zxdg__exporter__v2__t.html#a059ed5b15a946be9352a4c3843eeb935", null ],
    [ "post_invalid_surface", "classwayland_1_1server_1_1zxdg__exporter__v2__t.html#a174d1c132ec580282188504731133a22", null ]
];