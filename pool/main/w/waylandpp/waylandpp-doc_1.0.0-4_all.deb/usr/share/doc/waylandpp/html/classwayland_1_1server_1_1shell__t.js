var classwayland_1_1server_1_1shell__t =
[
    [ "on_get_shell_surface", "classwayland_1_1server_1_1shell__t.html#a2fe63549986d1d570c90b6010518cc73", null ],
    [ "post_role", "classwayland_1_1server_1_1shell__t.html#a48904a0e7444202d420975c278eb1250", null ]
];