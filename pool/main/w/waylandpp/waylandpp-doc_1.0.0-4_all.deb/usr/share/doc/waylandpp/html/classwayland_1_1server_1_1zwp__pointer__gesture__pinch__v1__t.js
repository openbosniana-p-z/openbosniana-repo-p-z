var classwayland_1_1server_1_1zwp__pointer__gesture__pinch__v1__t =
[
    [ "begin", "classwayland_1_1server_1_1zwp__pointer__gesture__pinch__v1__t.html#a74bd44ccfbc5a8a08d17d92cecad02f2", null ],
    [ "end", "classwayland_1_1server_1_1zwp__pointer__gesture__pinch__v1__t.html#a86925076c86ed00674b169f40c11ea7c", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zwp__pointer__gesture__pinch__v1__t.html#a1cbb3f7e867044951bf2d7b62a92004c", null ],
    [ "update", "classwayland_1_1server_1_1zwp__pointer__gesture__pinch__v1__t.html#ad5cb9e3618ec4e5ccb87ea16b16866a8", null ]
];