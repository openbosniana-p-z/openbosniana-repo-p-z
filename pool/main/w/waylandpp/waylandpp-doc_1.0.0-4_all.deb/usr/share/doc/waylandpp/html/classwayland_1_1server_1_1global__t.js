var classwayland_1_1server_1_1global__t =
[
    [ "global_t", "classwayland_1_1server_1_1global__t.html#a1ddbccd7fce8916b70cdf56c2a371cc3", null ],
    [ "has_interface", "classwayland_1_1server_1_1global__t.html#a3dd09b8c3a74ac7b20ec40ea979bbe32", null ],
    [ "on_bind", "classwayland_1_1server_1_1global__t.html#ab8542c8bd644561a6ef42eef5c225c89", null ]
];