var classwayland_1_1server_1_1zwp__tablet__manager__v1__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1zwp__tablet__manager__v1__t.html#a9fcdb52d160b6dea03847f1c4ec0faf0", null ],
    [ "on_get_tablet_seat", "classwayland_1_1server_1_1zwp__tablet__manager__v1__t.html#aee55a801c6ae38280d8bd5f2b1743f7c", null ]
];