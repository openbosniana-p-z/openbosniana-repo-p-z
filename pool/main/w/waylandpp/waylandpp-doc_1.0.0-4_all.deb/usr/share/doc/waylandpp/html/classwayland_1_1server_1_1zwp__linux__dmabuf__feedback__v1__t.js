var classwayland_1_1server_1_1zwp__linux__dmabuf__feedback__v1__t =
[
    [ "done", "classwayland_1_1server_1_1zwp__linux__dmabuf__feedback__v1__t.html#ad1a1d6959ba3561b1be139cb080ba46a", null ],
    [ "format_table", "classwayland_1_1server_1_1zwp__linux__dmabuf__feedback__v1__t.html#aa95a777880ca09c9525006e7f8ce828a", null ],
    [ "main_device", "classwayland_1_1server_1_1zwp__linux__dmabuf__feedback__v1__t.html#a807a530a68df931866bc01192fd2d8f7", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zwp__linux__dmabuf__feedback__v1__t.html#a9e99f2cc6634d715be60acecf97fcdae", null ],
    [ "tranche_done", "classwayland_1_1server_1_1zwp__linux__dmabuf__feedback__v1__t.html#aebdbf56f48bb5117e70a96b24f2ed819", null ],
    [ "tranche_flags", "classwayland_1_1server_1_1zwp__linux__dmabuf__feedback__v1__t.html#a55667e092c6b9977c6cb26978f6c28ca", null ],
    [ "tranche_formats", "classwayland_1_1server_1_1zwp__linux__dmabuf__feedback__v1__t.html#a15eba4da9f924370e4352d7411185713", null ],
    [ "tranche_target_device", "classwayland_1_1server_1_1zwp__linux__dmabuf__feedback__v1__t.html#a3f4f2d5836f48b93b9530717433d9f83", null ]
];