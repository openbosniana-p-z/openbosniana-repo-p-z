var classwayland_1_1server_1_1zwp__primary__selection__device__manager__v1__t =
[
    [ "on_create_source", "classwayland_1_1server_1_1zwp__primary__selection__device__manager__v1__t.html#a3f81fea74088739cbc3148c94ceaa572", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zwp__primary__selection__device__manager__v1__t.html#a7686eaaebd6dfee24328d5752af1c47c", null ],
    [ "on_get_device", "classwayland_1_1server_1_1zwp__primary__selection__device__manager__v1__t.html#a8385290b4aee4a7d63cb86d4365963a1", null ]
];