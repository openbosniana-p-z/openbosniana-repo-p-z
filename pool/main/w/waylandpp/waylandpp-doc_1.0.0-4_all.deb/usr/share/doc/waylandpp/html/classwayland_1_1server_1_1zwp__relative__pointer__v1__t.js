var classwayland_1_1server_1_1zwp__relative__pointer__v1__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1zwp__relative__pointer__v1__t.html#a6953d0b4a04cdcb9655611cfaa511584", null ],
    [ "relative_motion", "classwayland_1_1server_1_1zwp__relative__pointer__v1__t.html#ab29d6d09f645a04cd87888ebf09b6c25", null ]
];