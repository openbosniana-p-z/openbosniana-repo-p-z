var classwayland_1_1data__offer__t =
[
    [ "wrapper_type", "classwayland_1_1data__offer__t.html#afc44f0d53890db6bd32d9b2f0c6994e9", [
      [ "standard", "classwayland_1_1data__offer__t.html#afc44f0d53890db6bd32d9b2f0c6994e9ac00f0c4675b91fb8b918e4079a0b1bac", null ],
      [ "display", "classwayland_1_1data__offer__t.html#afc44f0d53890db6bd32d9b2f0c6994e9aebf78b512222fe4dcd14e7d5060a15b0", null ],
      [ "foreign", "classwayland_1_1data__offer__t.html#afc44f0d53890db6bd32d9b2f0c6994e9a684a72e08f24f55b1138edd5a7c2b53e", null ],
      [ "proxy_wrapper", "classwayland_1_1data__offer__t.html#afc44f0d53890db6bd32d9b2f0c6994e9ae6cc1490287e90290ddd4e0b9efeb6d5", null ]
    ] ],
    [ "accept", "classwayland_1_1data__offer__t.html#ac43fe8fe4baa984054012b4b98ee7fef", null ],
    [ "c_ptr", "classwayland_1_1data__offer__t.html#a869635f7ddc6678df2b93f8a13870c95", null ],
    [ "can_finish", "classwayland_1_1data__offer__t.html#a55cca2ee93962a3bddb52e5d30a4c519", null ],
    [ "can_set_actions", "classwayland_1_1data__offer__t.html#ab97627f2a54c4743ff382cc0e7c0d0ca", null ],
    [ "finish", "classwayland_1_1data__offer__t.html#ad12b36134b3f68bcea4b0975cf79e64b", null ],
    [ "get_class", "classwayland_1_1data__offer__t.html#a8a77c6eab2f2eb4cfcca56be8a780d3e", null ],
    [ "get_id", "classwayland_1_1data__offer__t.html#a273d7fd6604b65d4c4d24747b639a263", null ],
    [ "get_version", "classwayland_1_1data__offer__t.html#a59444022b75257f6b27d2c464c371779", null ],
    [ "get_wrapper_type", "classwayland_1_1data__offer__t.html#a65253c6ac727496735c0dc42a9fd1568", null ],
    [ "on_action", "classwayland_1_1data__offer__t.html#a2c26d3afb1ccc9b9551fa528c6cea8b9", null ],
    [ "on_offer", "classwayland_1_1data__offer__t.html#a01d9559d9422a5a05938c1b7cb8ebfd8", null ],
    [ "on_source_actions", "classwayland_1_1data__offer__t.html#aa70b0bd4cf599ed7727eed6a6c49f975", null ],
    [ "operator bool", "classwayland_1_1data__offer__t.html#aafa72a9121fa69ccfad6e9eff8740b5e", null ],
    [ "operator!=", "classwayland_1_1data__offer__t.html#ac460e26f384624eb96647d533314240a", null ],
    [ "operator==", "classwayland_1_1data__offer__t.html#a3dc433db4597e77caccb07f99b26a259", null ],
    [ "proxy_has_object", "classwayland_1_1data__offer__t.html#a0c596640d7469447cb0b91dc9c8c22b2", null ],
    [ "proxy_release", "classwayland_1_1data__offer__t.html#a0af69af8f839a5a5ea354e52705e9a43", null ],
    [ "receive", "classwayland_1_1data__offer__t.html#a6dd8de7270a492d04983534299ac47d2", null ],
    [ "set_actions", "classwayland_1_1data__offer__t.html#a299c804b3c5e97ec76e5b866b71e78d5", null ],
    [ "set_queue", "classwayland_1_1data__offer__t.html#a2065bb6f0ba51f29fdf16b8168bb5958", null ]
];