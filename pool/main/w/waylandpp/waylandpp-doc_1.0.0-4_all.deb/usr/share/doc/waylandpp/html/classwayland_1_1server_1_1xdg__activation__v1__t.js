var classwayland_1_1server_1_1xdg__activation__v1__t =
[
    [ "on_activate", "classwayland_1_1server_1_1xdg__activation__v1__t.html#aa0f98a5897a65dff4e4e7a51807e7b0a", null ],
    [ "on_destroy", "classwayland_1_1server_1_1xdg__activation__v1__t.html#a57fb322e627c533126f344b30c7fcf15", null ],
    [ "on_get_activation_token", "classwayland_1_1server_1_1xdg__activation__v1__t.html#aac93eae2a4580b30e34e75f69abd818f", null ]
];