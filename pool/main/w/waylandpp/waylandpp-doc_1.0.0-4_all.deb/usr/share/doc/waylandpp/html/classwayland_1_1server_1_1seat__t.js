var classwayland_1_1server_1_1seat__t =
[
    [ "can_name", "classwayland_1_1server_1_1seat__t.html#abda30ab7748cf0f681101840d9a39243", null ],
    [ "capabilities", "classwayland_1_1server_1_1seat__t.html#ab9cb25d665d15d44aaefece8ce406fda", null ],
    [ "name", "classwayland_1_1server_1_1seat__t.html#a20d2898c0f894f96c26d59c7c2ede1f8", null ],
    [ "on_get_keyboard", "classwayland_1_1server_1_1seat__t.html#a8f74b894e8d8b1d2fdce5b787fb54bac", null ],
    [ "on_get_pointer", "classwayland_1_1server_1_1seat__t.html#a433eac382d7ad5080ee9bb10d9398fed", null ],
    [ "on_get_touch", "classwayland_1_1server_1_1seat__t.html#a948100cf0302fe894bf823f2db5d0d8a", null ],
    [ "on_release", "classwayland_1_1server_1_1seat__t.html#a9582a3e730eee7776fc7e487a26ba97d", null ],
    [ "post_missing_capability", "classwayland_1_1server_1_1seat__t.html#a7b4e937ead53b5e984c5efa80e28765b", null ]
];