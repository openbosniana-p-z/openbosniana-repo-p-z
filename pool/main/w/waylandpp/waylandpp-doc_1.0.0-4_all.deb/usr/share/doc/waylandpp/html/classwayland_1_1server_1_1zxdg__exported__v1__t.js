var classwayland_1_1server_1_1zxdg__exported__v1__t =
[
    [ "handle", "classwayland_1_1server_1_1zxdg__exported__v1__t.html#a36e1df57379bbaac258327a5432482b2", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zxdg__exported__v1__t.html#a3c30362d9a53e86b935989d4a32f10c8", null ]
];