var classwayland_1_1server_1_1zwp__tablet__pad__group__v2__t =
[
    [ "buttons", "classwayland_1_1server_1_1zwp__tablet__pad__group__v2__t.html#a31c5da5822222f88e9ef60d57ced520c", null ],
    [ "done", "classwayland_1_1server_1_1zwp__tablet__pad__group__v2__t.html#a1bcfc1bb72c82099c112b0bdfbdb155f", null ],
    [ "mode_switch", "classwayland_1_1server_1_1zwp__tablet__pad__group__v2__t.html#a70390a50513460bf78eddf4da4194198", null ],
    [ "modes", "classwayland_1_1server_1_1zwp__tablet__pad__group__v2__t.html#a8d5d498b6ef6f2627222b8bd6cfc8ab2", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zwp__tablet__pad__group__v2__t.html#a54329d4b7981930a626deaaa5c308391", null ],
    [ "ring", "classwayland_1_1server_1_1zwp__tablet__pad__group__v2__t.html#a81430c4e8fc96e263f672ae6ea6d5f1b", null ],
    [ "strip", "classwayland_1_1server_1_1zwp__tablet__pad__group__v2__t.html#a84ab2b456c89415cd0d655b98a89e02e", null ]
];