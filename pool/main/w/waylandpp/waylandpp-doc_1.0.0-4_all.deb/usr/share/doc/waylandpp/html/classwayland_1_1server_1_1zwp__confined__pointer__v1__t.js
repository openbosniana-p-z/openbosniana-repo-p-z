var classwayland_1_1server_1_1zwp__confined__pointer__v1__t =
[
    [ "confined", "classwayland_1_1server_1_1zwp__confined__pointer__v1__t.html#ae0f78188307f376e9ca6771b8176aa0f", null ],
    [ "on_destroy", "classwayland_1_1server_1_1zwp__confined__pointer__v1__t.html#a9bb0bcc0f90d3817eaa667ce78164438", null ],
    [ "on_set_region", "classwayland_1_1server_1_1zwp__confined__pointer__v1__t.html#ac287293f07c9f709086280cb12b34b8d", null ],
    [ "unconfined", "classwayland_1_1server_1_1zwp__confined__pointer__v1__t.html#a993e42322acf2e5736e0c11e89a6f3c1", null ]
];