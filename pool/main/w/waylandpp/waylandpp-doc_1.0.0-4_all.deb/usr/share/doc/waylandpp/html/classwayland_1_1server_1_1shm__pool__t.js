var classwayland_1_1server_1_1shm__pool__t =
[
    [ "on_create_buffer", "classwayland_1_1server_1_1shm__pool__t.html#a86cd9718625fc62acc185359f5d71427", null ],
    [ "on_destroy", "classwayland_1_1server_1_1shm__pool__t.html#a03143581520ec37e844d839d1e3e2797", null ],
    [ "on_resize", "classwayland_1_1server_1_1shm__pool__t.html#a3f1a9471208095c35e557f3b9afb1128", null ]
];