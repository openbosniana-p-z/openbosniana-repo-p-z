var classwayland_1_1server_1_1zxdg__exporter__v1__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1zxdg__exporter__v1__t.html#aaeadf6ae105778132df8e7255ece5efc", null ],
    [ "on_export", "classwayland_1_1server_1_1zxdg__exporter__v1__t.html#a9f998347eca404769ff829049af13154", null ]
];