var classwayland_1_1server_1_1zwp__text__input__manager__v3__t =
[
    [ "on_destroy", "classwayland_1_1server_1_1zwp__text__input__manager__v3__t.html#acd9a155b84f64790d8c542f0fb90703d", null ],
    [ "on_get_text_input", "classwayland_1_1server_1_1zwp__text__input__manager__v3__t.html#ad602a270d0a36b3bf388520db121827f", null ]
];