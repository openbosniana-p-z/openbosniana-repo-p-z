package TheWML::Config;

use strict;
use warnings;

use parent 'Exporter';

our @EXPORT_OK = (qw(libdir datadir));

sub bindir   { return '/usr/bin'; }
sub datadir  { return '/usr/share/wml'; }
sub libdir   { return '/usr/share/wml'; } # Yes, the same as above
sub mandir   { return '/usr/share/man'; }
sub prefix   { return '/usr'; }
sub perlprog { return '/usr/bin/perl'; }

sub _VERSION
{
    return '2.32.0';
}

sub build_info
{
    return <<'EOF';
Built Environment:
    Perl: /usr/bin/perl (/usr/bin/perl)
Built Location:
    Prefix: /usr
    BinDir: /usr/bin
    LibDir: /usr/lib/x86_64-linux-gnu/wml
    DataDir: /usr/share/wml
    ManDir: /usr/share/man
EOF
}

1;

