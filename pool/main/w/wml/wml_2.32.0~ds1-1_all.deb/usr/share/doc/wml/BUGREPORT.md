BUG REPORT
==========

When you have ideas, suggestions or bugs you want to report to the WML
author, then you have the following options:

1. File an issue on the
[issue tracker](https://github.com/thewml/website-meta-language/issues)

2. Directly write an E-Mail to shlomif@shlomifish.org or see
https://www.shlomifish.org/me/contact-me/ .

Please include at least the output of `wml -V3`.
