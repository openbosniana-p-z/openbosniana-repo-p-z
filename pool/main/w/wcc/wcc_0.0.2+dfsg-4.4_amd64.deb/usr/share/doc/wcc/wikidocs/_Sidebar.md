## Contribute

The Witchcraft Compiler Collection is Licensed under the MIT License.

Feel free to contribute :)