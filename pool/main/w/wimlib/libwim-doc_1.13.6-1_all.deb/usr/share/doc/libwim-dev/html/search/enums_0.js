var searchData=
[
  ['wimlib_5fcompression_5ftype_0',['wimlib_compression_type',['../group__G__general.html#gaf713fb36023a651f206a546e645ad09e',1,'wimlib.h']]],
  ['wimlib_5ferror_5fcode_1',['wimlib_error_code',['../group__G__general.html#gadbc3c5b05b4cf56b81b9c947f3489cb3',1,'wimlib.h']]],
  ['wimlib_5fprogress_5fmsg_2',['wimlib_progress_msg',['../group__G__progress.html#ga97c710dfb412454d5d348f8581b243a7',1,'wimlib.h']]],
  ['wimlib_5fprogress_5fstatus_3',['wimlib_progress_status',['../group__G__progress.html#ga1f2be6e1746e876a20f952346ed99c51',1,'wimlib.h']]],
  ['wimlib_5fupdate_5fop_4',['wimlib_update_op',['../group__G__modifying__wims.html#gaeb573e1a7d67485f4b9483c52c59bf41',1,'wimlib.h']]]
];
