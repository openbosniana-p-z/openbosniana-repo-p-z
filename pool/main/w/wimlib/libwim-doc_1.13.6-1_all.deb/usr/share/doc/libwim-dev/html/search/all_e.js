var searchData=
[
  ['raw_5fresource_5fcompressed_5fsize_0',['raw_resource_compressed_size',['../structwimlib__resource__entry.html#afc08f5a74c04b644055404beb9c8c91d',1,'wimlib_resource_entry']]],
  ['raw_5fresource_5foffset_5fin_5fwim_1',['raw_resource_offset_in_wim',['../structwimlib__resource__entry.html#a2a2650deea5488c2d4342d7e00a5489c',1,'wimlib_resource_entry']]],
  ['raw_5fresource_5funcompressed_5fsize_2',['raw_resource_uncompressed_size',['../structwimlib__resource__entry.html#a0e4ff88abd5c1b6813fecac090029952',1,'wimlib_resource_entry']]],
  ['reference_5fcount_3',['reference_count',['../structwimlib__resource__entry.html#a0dd82c23ecb48e0c2976b1c944d36e16',1,'wimlib_resource_entry']]],
  ['rename_4',['rename',['../unionwimlib__progress__info.html#a62f80d272216b8792b3e4a2331b3765e',1,'wimlib_progress_info::rename()'],['../structwimlib__update__command.html#a5b57f3216189ffab21f8680487610c05',1,'wimlib_update_command::rename()']]],
  ['rename_5fflags_5',['rename_flags',['../structwimlib__rename__command.html#a68c9b375471ba65cfc6bc778f54a8a12',1,'wimlib_rename_command']]],
  ['reparse_5ftag_6',['reparse_tag',['../structwimlib__dir__entry.html#a3366c040dbbd87763469ab212fc2eb92',1,'wimlib_dir_entry']]],
  ['replace_7',['replace',['../unionwimlib__progress__info.html#a3a4e9cb9aabfe8318c2f00d4a66f65ea',1,'wimlib_progress_info']]],
  ['reserved_8',['reserved',['../structwimlib__capture__source.html#a6ee32a820397a3f1eb91077a4af1020e',1,'wimlib_capture_source::reserved()'],['../structwimlib__dir__entry.html#a7bb02f4dfee7f327e4323db5319a6911',1,'wimlib_dir_entry::reserved()'],['../structwimlib__stream__entry.html#a668a0030aff4c4a3e50ee5829128670e',1,'wimlib_stream_entry::reserved()'],['../structwimlib__resource__entry.html#a4c92e1bdb81d22828ab99a5713f550c0',1,'wimlib_resource_entry::reserved()'],['../structwimlib__wim__info.html#a21199622af357cd413070aaf102d7c1d',1,'wimlib_wim_info::reserved()'],['../structwimlib__progress__info_1_1wimlib__progress__info__extract.html#a970c28c6a4ef95f91963aeb3e4dc5148',1,'wimlib_progress_info::wimlib_progress_info_extract::reserved()']]],
  ['reserved2_9',['reserved2',['../structwimlib__dir__entry.html#af7832c5dcd5f4137d9a93a3beb6eefb3',1,'wimlib_dir_entry']]],
  ['reserved_5fflags_10',['reserved_flags',['../structwimlib__wim__info.html#aaacc2499b018f83f5e57a23d641d70f5',1,'wimlib_wim_info::reserved_flags()'],['../structwimlib__resource__entry.html#a07b9e60610d9cd84e0899a8bcbefa781',1,'wimlib_resource_entry::reserved_flags()']]],
  ['resource_11',['resource',['../structwimlib__stream__entry.html#a2e948614b6da52e0b34a4429b7b83bb5',1,'wimlib_stream_entry']]],
  ['resource_5fonly_12',['resource_only',['../structwimlib__wim__info.html#a5338a4e37d6aef80d244c30089ed166a',1,'wimlib_wim_info']]],
  ['retrieving_20wim_20information_20and_20directory_20listings_13',['Retrieving WIM information and directory listings',['../group__G__wim__information.html',1,'']]]
];
