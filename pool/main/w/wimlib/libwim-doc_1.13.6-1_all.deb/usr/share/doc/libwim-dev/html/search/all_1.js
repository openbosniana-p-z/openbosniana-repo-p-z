var searchData=
[
  ['birth_5fobject_5fid_0',['birth_object_id',['../structwimlib__object__id.html#a62fffaa51f8130ba09b6ab657bb8198c',1,'wimlib_object_id']]],
  ['birth_5fvolume_5fid_1',['birth_volume_id',['../structwimlib__object__id.html#a1b078aab0dbff190255523595076b9df',1,'wimlib_object_id']]],
  ['boot_5findex_2',['boot_index',['../structwimlib__wim__info.html#a8de840e47bfa9f0a039aef580af4062c',1,'wimlib_wim_info']]]
];
