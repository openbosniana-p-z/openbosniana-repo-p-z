var searchData=
[
  ['object_5fid_0',['object_id',['../structwimlib__object__id.html#a40573030ebff5c73db820b4bbf029441',1,'wimlib_object_id::object_id()'],['../structwimlib__dir__entry.html#a2720bc3078d8e519a5891975e37971ef',1,'wimlib_dir_entry::object_id()']]],
  ['offset_1',['offset',['../structwimlib__resource__entry.html#a8991b32fa3c8c9575bac51a08b54f761',1,'wimlib_resource_entry']]],
  ['op_2',['op',['../structwimlib__update__command.html#a9fcdb5936c175bbef97722700b8deaf6',1,'wimlib_update_command']]],
  ['opened_5ffrom_5ffile_3',['opened_from_file',['../structwimlib__wim__info.html#a806215acad826103e5500e41aaa3db77',1,'wimlib_wim_info']]]
];
