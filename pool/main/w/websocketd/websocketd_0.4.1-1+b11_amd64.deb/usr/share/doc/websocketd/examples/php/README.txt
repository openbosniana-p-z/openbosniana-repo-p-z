This examples directory shows some examples written in PHP.

This relies on the CLI verson of PHP being installed and in the path.
See http://www.php.net/manual/en/features.commandline.introduction.php

You can also test the command files by running from the command line.