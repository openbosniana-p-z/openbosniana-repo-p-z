#!/bin/sh
javac Echo.java
java Echo