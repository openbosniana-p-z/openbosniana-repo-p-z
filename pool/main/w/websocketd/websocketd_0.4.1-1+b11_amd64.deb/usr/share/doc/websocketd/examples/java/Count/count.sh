#!/bin/sh
javac Count.java
java Count