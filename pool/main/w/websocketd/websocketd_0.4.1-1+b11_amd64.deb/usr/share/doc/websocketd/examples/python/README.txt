This examples directory shows some examples written in Python.

You can also test the command files by running from the command line.