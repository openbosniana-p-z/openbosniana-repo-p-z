#!/bin/sh

gcc -O3 -o query  query.c -lm -lwgdb
