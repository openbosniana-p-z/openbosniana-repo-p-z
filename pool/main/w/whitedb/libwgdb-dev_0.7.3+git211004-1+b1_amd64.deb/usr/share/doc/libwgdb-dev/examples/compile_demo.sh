#!/bin/sh

gcc -O3 -o demo  demo.c -lm -lwgdb
