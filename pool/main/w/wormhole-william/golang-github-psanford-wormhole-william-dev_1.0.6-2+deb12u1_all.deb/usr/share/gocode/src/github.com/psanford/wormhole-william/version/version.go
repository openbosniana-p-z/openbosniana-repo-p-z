package version

var (
	// Default Agent identifier sent to rendezvous server
	AgentString = "go-william"
	// Default Agent version sent to rendezvous server
	AgentVersion = "v1.0.6"
)
