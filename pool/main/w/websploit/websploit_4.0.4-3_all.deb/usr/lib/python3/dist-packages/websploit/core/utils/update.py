import requests
from .version import version
from .output import CPrint


def update(where):
    print("[*] Internal update/upgrade system is disabled on Debian systems. Please, use the update system provided by your distro.")
