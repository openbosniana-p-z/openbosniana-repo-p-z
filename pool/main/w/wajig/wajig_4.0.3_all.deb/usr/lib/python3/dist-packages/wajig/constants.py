#!/usr/bin/python3
#
# wajig - GNU/Linux Administration
#
# A command line tool for managing the administration of Ubuntu.
#
# Copyright (c) Graham.Williams@togaware.com All rights reserved.
#
# This file is part of wajig.

# Define application constants.

APP = "wajig"
VERSION = "4.0.3"
