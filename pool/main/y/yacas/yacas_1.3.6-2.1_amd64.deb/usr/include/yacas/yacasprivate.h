#ifndef YACAS_YACASPRIVATE_H
#define YACAS_YACASPRIVATE_H

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "lisptype.h"
#include "stubs.h"

#endif

