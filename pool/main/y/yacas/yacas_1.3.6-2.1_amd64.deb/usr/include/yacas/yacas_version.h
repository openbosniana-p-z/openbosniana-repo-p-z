#ifndef YACAS_VERSION_H
#define YACAS_VERSION "1.3.6"
#endif
