#include <time.h>

time_t uptime(time_t *t);
