package admin

type ErrorResponse struct {
	Error string `json:"error"`
}
