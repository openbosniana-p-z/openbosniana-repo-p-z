var searchData=
[
  ['initialization_20and_20closing_20functions_0',['Initialization and closing functions',['../group__init.html',1,'']]]
];
