var searchData=
[
  ['logging_20function_0',['Logging function',['../group__log.html',1,'']]]
];
