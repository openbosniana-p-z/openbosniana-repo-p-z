# require 'pathname'
require 'yapra'

module Yapra::LegacyPlugin
end
