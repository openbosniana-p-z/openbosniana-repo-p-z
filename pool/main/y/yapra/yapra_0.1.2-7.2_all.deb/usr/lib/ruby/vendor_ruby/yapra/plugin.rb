require 'yapra'

module Yapra::Plugin

end