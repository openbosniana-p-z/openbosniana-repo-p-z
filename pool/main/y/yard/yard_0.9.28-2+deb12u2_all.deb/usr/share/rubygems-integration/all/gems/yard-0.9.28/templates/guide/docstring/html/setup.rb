# frozen_string_literal: true
include T('default/docstring/html')
