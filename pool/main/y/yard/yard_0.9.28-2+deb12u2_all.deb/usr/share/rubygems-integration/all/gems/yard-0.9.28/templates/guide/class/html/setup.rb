# frozen_string_literal: true
include T('guide/module/html')
