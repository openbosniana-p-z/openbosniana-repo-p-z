/* config.h from config.sh script
 * always empty -- see D_... defines in Make.cfg
 */
