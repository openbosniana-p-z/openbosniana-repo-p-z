These files are loosely organised info.  As many of these have now been turned into proper documentation in the Yoshimi User Guide, and with more detail, in the Advanced User Manual, they will be moved into histories, and no longer be updated.

Any additional notes are more than welcome. If you like, you can send them to me at:

abrolag@users.sourceforge.net

For the sake of completeness in the Histories archive there is some info on ZynAddSubFx from its beginning up to the time of the Yoshimi fork. Other information is being placed there from time to time.
