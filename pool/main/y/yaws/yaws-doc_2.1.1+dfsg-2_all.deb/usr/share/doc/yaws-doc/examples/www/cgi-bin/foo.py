#!/usr/bin/env python3

import cgi

print("Content-type: text/html\n\n")
print("<h1>hi there</h1>")
