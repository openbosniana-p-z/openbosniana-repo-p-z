#<cldoc:index>

Index.

yrmcds documents
----------------

yrmcds is an object cache system featuring master-slave replication.

#<cldoc:cybozu>

General utilities.

#<cldoc:yrmcds>

Implementing yrmcds.
