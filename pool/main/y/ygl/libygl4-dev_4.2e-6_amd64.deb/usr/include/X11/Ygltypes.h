/*
 * Automagically created by makeYgltypes. Do not change!
 */
typedef signed   char    Int8;
typedef unsigned char   Uint8;
typedef signed   short   Int16;
typedef unsigned short  Uint16;
typedef signed   int     Int32;
typedef unsigned int    Uint32;
typedef signed   long    Int64;
typedef unsigned long   Uint64;
typedef          float  Float32;
typedef          double Float64;
