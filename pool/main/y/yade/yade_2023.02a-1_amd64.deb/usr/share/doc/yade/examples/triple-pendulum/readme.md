This is a placeholder for scripts, which will be committed
after the paper from Janek, Klaus and Anton about yade-HP will
be published.
