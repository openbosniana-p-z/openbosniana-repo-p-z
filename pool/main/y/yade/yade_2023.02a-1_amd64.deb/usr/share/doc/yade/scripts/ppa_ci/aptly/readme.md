Specific scripts, applied on yade-dem server
