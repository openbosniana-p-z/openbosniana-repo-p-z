require_relative '../../../../../../puppet/network/http/api/master'
require_relative '../../../../../../puppet/network/http/api/server/v3/environments'

