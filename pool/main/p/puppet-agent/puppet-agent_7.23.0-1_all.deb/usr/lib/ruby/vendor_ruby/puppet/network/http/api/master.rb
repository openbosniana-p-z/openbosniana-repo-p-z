require_relative '../../../../puppet/network/http/api/server'

Puppet::Network::HTTP::API::Master = Puppet::Network::HTTP::API::Server
