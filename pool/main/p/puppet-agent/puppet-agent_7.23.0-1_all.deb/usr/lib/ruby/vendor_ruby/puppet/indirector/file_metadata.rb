# A stub class, so our constants work.
class Puppet::Indirector::FileMetadata # :nodoc:
end

require_relative '../../puppet/file_serving/metadata'
