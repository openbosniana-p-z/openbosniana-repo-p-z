require_relative '../../puppet/application/face_base'

class Puppet::Application::Help < Puppet::Application::FaceBase
  environment_mode :not_required
end
