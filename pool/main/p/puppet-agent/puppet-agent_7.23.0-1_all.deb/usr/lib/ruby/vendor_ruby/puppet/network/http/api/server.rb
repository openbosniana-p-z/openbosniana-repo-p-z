module Puppet
  module Network
    module HTTP
      class API
        module Server
        end
      end
    end
  end
end
