# OpenPaperwork Core

The core manages Plugins, Callbacks and Interfaces. This package also provide
some basic plugins that may be used in any kind of application.

[Documentation](https://doc.openpaper.work/openpaperwork_core/latest/)
