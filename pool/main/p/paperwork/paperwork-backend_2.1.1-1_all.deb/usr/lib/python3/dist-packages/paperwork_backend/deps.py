LIBREOFFICE = {
    'debian': 'libreoffice',
    'linuxmint': 'libreoffice',
    'raspian': 'libreoffice',
    'ubuntu': 'libreoffice',
}
