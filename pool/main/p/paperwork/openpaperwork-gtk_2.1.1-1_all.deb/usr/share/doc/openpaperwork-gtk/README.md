# OpenPaperwork GTK

GLib/GTK plugins.

[Documentation](https://doc.openpaper.work/openpaperwork_gtk/latest/)
