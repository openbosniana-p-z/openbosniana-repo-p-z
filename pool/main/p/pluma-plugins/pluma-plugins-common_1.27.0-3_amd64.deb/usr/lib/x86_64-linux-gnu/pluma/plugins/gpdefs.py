# -*- coding: utf-8 -*-

VERSION = "1.27.0"
PACKAGE = "pluma-plugins"
PACKAGE_STRING = "pluma-plugins 1.27.0"
GETTEXT_PACKAGE = "pluma-plugins"
GP_LOCALEDIR = "/usr/@DATADIRNAME@/locale"
