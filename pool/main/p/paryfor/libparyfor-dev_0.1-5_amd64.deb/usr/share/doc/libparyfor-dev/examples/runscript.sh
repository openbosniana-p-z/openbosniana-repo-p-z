#!/bin/sh

mkdir -p build
cd build
cmake ..
make
cd ..

[ -x bin/paryfor-test ]

#Example Usage:
#bin/paryfor-test 1 0 1
