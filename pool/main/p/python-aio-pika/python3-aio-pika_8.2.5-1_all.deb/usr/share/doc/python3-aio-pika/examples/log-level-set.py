import logging

from aio_pika import logger


logger.setLevel(logging.ERROR)
