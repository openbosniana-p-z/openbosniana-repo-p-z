pystray Package Documentation
=============================

This library allows you to create a *system tray icon*.

Supported platforms are *Linux* under *Xorg*, *GNOME* and *Ubuntu*, *macOS*
and *Windows*.

See `here <https://pystray.readthedocs.io/en/latest/>`_ for the full
documentation.
