Release notes
=============

.. include:: ../NEWS.rst
