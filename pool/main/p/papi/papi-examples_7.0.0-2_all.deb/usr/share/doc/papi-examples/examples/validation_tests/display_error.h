double display_error(long long average,
		     long long high,
		     long long low,
		     long long expected,
                     int quiet);
