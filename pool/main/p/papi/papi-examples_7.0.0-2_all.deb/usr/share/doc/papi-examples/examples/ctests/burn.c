#include <stdio.h>

#include "do_loops.h"

int
main( int argc, char **argv  )
{
	(void)argc;
	(void)argv;

	do_stuff(  );
	return 0;
}
