long long naive_matrix_multiply_estimated_flops(int quiet);
long long naive_matrix_multiply_estimated_loads(int quiet);
long long naive_matrix_multiply_estimated_stores(int quiet);
double naive_matrix_multiply(int quiet);


