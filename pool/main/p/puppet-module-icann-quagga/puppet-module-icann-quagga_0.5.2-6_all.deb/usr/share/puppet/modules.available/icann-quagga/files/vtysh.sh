# Disable the vtysh pager, it's stupid
export VTYSH_PAGER=/bin/cat
