(**************************************************************************)
(*                                                                        *)
(*  Copyright (c) 2020 Albin Coquereau                                    *)
(*                                                                        *)
(*  All rights reserved.                                                  *)
(*  This file is distributed under the terms of the                       *)
(*  Apache-2.0 license.                                                   *)
(*                                                                        *)
(**************************************************************************)


(* If you delete or rename this file, you should add
   'src/psmt2-frontend/main.ml' to the 'skip' field in "drom.toml" *)

let main () = Printf.printf "Hello world!\n"
