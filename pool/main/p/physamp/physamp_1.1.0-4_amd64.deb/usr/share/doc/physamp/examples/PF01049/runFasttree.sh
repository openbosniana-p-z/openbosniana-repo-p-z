#! /bin/bash
fasttree < PF01049_full.txt > PF01049_fasttree.dnd

