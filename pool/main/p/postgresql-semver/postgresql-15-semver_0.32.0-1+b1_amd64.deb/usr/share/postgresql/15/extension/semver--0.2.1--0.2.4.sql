-- No changes, all in the shared library.

