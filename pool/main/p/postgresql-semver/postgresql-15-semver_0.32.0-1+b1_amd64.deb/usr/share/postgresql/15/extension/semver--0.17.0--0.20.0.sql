CREATE TYPE semverrange AS RANGE (SUBTYPE = semver);
