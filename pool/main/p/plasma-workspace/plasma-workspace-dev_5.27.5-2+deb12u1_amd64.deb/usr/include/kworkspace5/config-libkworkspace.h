/* Define if you have X11 at all */
#define HAVE_X11 1
