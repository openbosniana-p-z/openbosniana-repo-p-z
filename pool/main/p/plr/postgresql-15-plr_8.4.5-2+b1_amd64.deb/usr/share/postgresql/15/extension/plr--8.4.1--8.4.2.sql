-- no changes to the sql files. Changes were require due to postgres API deprecation

-- complain if script is sourced in psql, rather than via ALTER EXTENSION
\echo Use "ALTER EXTENSION plr UPDATE to '8.4.2'" to load this file. \quit