-- no changes to the sql files. 

-- complain if script is sourced in psql, rather than via ALTER EXTENSION
\echo Use "ALTER EXTENSION plr UPDATE to '8.4.5'" to load this file. \quit