<?php

declare(strict_types=1);

namespace ProxyManager\Stub;

/**
 * Just an empty instantiable class
 */
final class EmptyClassStub
{
}
