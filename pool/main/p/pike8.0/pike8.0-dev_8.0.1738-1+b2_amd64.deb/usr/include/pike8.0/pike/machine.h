/* machine.h.  Generated from machine.h.in by configure.  */
/* machine.h.in.  Generated from configure.in by autoheader.  */
/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
*/

#ifndef MACHINE_H
#define MACHINE_H

/* We must define this *always* */
#ifndef POSIX_SOURCE
#define POSIX_SOURCE	1
#endif

/* Get more declarations in GNU libc. */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE 1
#endif

/* Get more declarations from AIX libc. */
#ifndef _ALL_SOURCE
#define _ALL_SOURCE 1
#endif

/* Building as a library? */
/* #undef LIBPIKE */

/* Where's the master.pike file installed? */
#define DEFAULT_MASTER "/usr/pike/%d.%d.%d/lib/master.pike"

/* Define this if you want run time self tests */
/* #undef PIKE_DEBUG */

/* Define this if you want some extra (possibly verbose) run time self tests */
/* #undef PIKE_EXTRA_DEBUG */

/* Define to make Pike do a full cleanup at exit to detect leaks. */
/* #undef DO_PIKE_CLEANUP */

/* Define this if you want pike to interact with valgrind. */
/* #undef USE_VALGRIND */

/* Define this to embed DTrace probes */
/* #undef USE_DTRACE */

/* Define this if you are going to use a memory access checker (like Purify) */
/* #undef __CHECKER__ */

/* Defined if Doug Leas malloc implementation is used. */
/* #undef USE_DL_MALLOC */

/* Define this if you want malloc debugging */
/* #undef DEBUG_MALLOC */

/* Define this if you want checkpoints */
/* #undef DMALLOC_TRACE */

/* Define this if you want backtraces for C code in your dmalloc output. */
/* #undef DMALLOC_C_STACK_TRACE */

/* Define this if you want dmalloc to keep track of freed memory. */
/* #undef DMALLOC_TRACK_FREE */

/* With this, dmalloc will trace malloc(3) calls */
/* #undef ENCAPSULATE_MALLOC */

/* With this, dmalloc will report leaks made by malloc(3) calls */
/* #undef REPORT_ENCAPSULATED_MALLOC */

/* Define this to enable the internal Pike security system */
/* #undef PIKE_SECURITY */

/* Define this to simulate dynamic module loading with static modules. */
/* #undef USE_SEMIDYNAMIC_MODULES */

/* Define this to enable the internal bignum conversion */
#define AUTO_BIGNUM 1

/* Define this if you want to enable the shared nodes mode of the optimizer. */
#define SHARED_NODES 1

/* Define this to use the new keypair loop. */
/* #undef PIKE_MAPPING_KEYPAIR_LOOP */

/* Define this to get portable dumped bytecode. */
#define PIKE_PORTABLE_BYTECODE 1

/* Enable profiling */
/* #undef PROFILING */

/* Enable internal profiling */
/* #undef INTERNAL_PROFILING */

/* If possible, the expansion for a "#define short" to avoid that bison
 * uses short everywhere internally. */
#define BISON_SHORT_EXPANSION int

/* The following USE_* are used by smartlink */
/* Define this if your ld sets the run path with -rpath */
/* #undef USE_RPATH */

/* Define this if your ld sets the run path with -R */
/* #undef USE_R */

/* Define this if your ld sets the run path with -YP, */
/* #undef USE_YP_ */

/* Define this if your ld sets the run path with +b */
/* #undef USE_PLUS_b */

/* Define this if your ld uses -rpath, but your cc wants -Wl,-rpath, */
/* #undef USE_Wl */

/* Define this if your ld uses Darwin-style -rpath, but your cc wants -Wl,-rpath, */
/* #undef USE_Wl_rpath_darwin */

/* Define this if your ld uses -R, but your cc wants -Wl,-R */
/* #undef USE_Wl_R */

/* Define this if your ld uses -rpath, but your cc -Qoption,ld,-rpath (icc) */
/* #undef USE_Qoption */

/* Define this if your ld uses -YP, , but your cc wants -Xlinker -YP, */
/* #undef USE_XLINKER_YP_ */

/* Define this if your ld doesn't have an option to set the run path */
/* #undef USE_LD_LIBRARY_PATH */

/* Define this on OS X to get two-level namespace support in ld */
/* #undef USE_OSX_TWOLEVEL_NAMESPACE */

/* Define if your tcc supports #pragma TenDRA longlong type allow. */
/* #undef HAVE_PRAGMA_TENDRA_LONGLONG */

/* Define if your tcc supports #pragma TenDRA set longlong type : long long. */
/* #undef HAVE_PRAGMA_TENDRA_SET_LONGLONG_TYPE */

/* The worlds most stringent C compiler? */
#ifdef __TenDRA__
/* We want to be able to use 64bit arithmetic */
#ifdef HAVE_PRAGMA_TENDRA_LONGLONG
#pragma TenDRA longlong type allow
#endif /* HAVE_PRAGMA_TENDRA_LONGLONG */
#ifdef HAVE_PRAGMA_TENDRA_SET_LONGLONG_TYPE
#pragma TenDRA set longlong type : long long
#endif /* HAVE_PRAGMA_TENDRA_SET_LONGLONG_TYPE */

#ifdef _NO_LONGLONG
/* #undef _NO_LONGLONG */
#endif /* _NO_LONGLONG */
#endif /* __TenDRA__ */


/* Define this if your compiler attempts to use _chkstk, but libc contains
 * __chkstk. */
/* #undef HAVE_BROKEN_CHKSTK */

/* Define if you have a working getcwd(3) (ie one that returns a malloc()ed
 * buffer if the first argument is NULL).
 *
 * Define to 1 if the second argument being 0 causes getcwd(3) to allocate
 * a buffer of suitable size (ie never fail with ERANGE).
 *
 * Define to 0 if the second argument MUST be > 0.
 */
#define HAVE_WORKING_GETCWD 1

/* Define for solaris */
/* #undef SOLARIS */

/* Define if the closedir function returns void instead of int.  */
/* #undef VOID_CLOSEDIR */

/* Number of args to mkdir() */
#define MKDIR_ARGS 2

/* Define to 'int' if <sys/time.h> doesn't */
/* #undef time_t */

/* Define to 'short' if <sys/types.h> doesn't */
#define pri_t short

/* Define to 'int' if <sys/types.h> doesn't */
/* #undef uid_t */

/* Define to 'int' if <sys/types.h> doesn't */
/* #undef gid_t */

/* Define to 'int' if <sys/types.h> doesn't */
/* #undef pid_t */

/* Define to 'unsigned long' if <sys/types.h> or <stddef.h> doesn't */
/* #undef size_t */

/* Define to 'long' if <sys/types.h> of <stddef.h> doesn't */
/* #undef ptrdiff_t */

/* Define to 'long' if <sys/types.h> doesn't */
/* #undef off_t */

/* Define to 'int' if <signal.h> doesn't */
/* #undef sig_atomic_t */

/* Define as the return type of signal handlers (int or void).  */
#define RETSIGTYPE void

/* define this if igonoring SIGFPE helps with core dumps */
/* #undef IGNORE_SIGFPE */

/* define if you want to use double precision floats instead of single */
#define WITH_DOUBLE_PRECISION_SVALUE 1

/* define if you want to use long double precision floats */
/* #undef WITH_LONG_DOUBLE_PRECISION_SVALUE */

/* define to the type of pike floats */
#define FLOAT_TYPE double

/* define to the size of pike floats */
#define SIZEOF_FLOAT_TYPE SIZEOF_DOUBLE

/* force this type upon ints */
#define WITH_LONG_INT 1
/* #undef WITH_LONG_LONG_INT */
/* #undef WITH_INT_INT */

/* define to the type of pike primitive ints */
#define INT_TYPE long

/* define to the size of pike primitive ints */
#define SIZEOF_INT_TYPE SIZEOF_LONG

/* If using the C implementation of alloca, define if you know the
 * direction of stack growth for your system; otherwise it will be
 * automatically deduced at run-time.
 *	STACK_DIRECTION > 0 => grows toward higher addresses
 *	STACK_DIRECTION < 0 => grows toward lower addresses
 *	STACK_DIRECTION = 0 => direction of growth unknown
 *
 * Also used by Pike's runtime C-stack checker.
 */
#define STACK_DIRECTION -1

/* Define this to the number of KB in the initial stack,
 * currently this is 1 Mb on FreeBSD, 2Mb on Linux and
 * unlimited (undefined) everywhere else
 */
#define Pike_INITIAL_STACK_SIZE 8323072

/* If so, is it restricted to user and system time? */
/* #undef GETRUSAGE_RESTRICTED */

/* Define if you have infnan */
/* #undef HAVE_INFNAN */

/* Define if you have _isnan */
/* #undef HAVE__ISNAN */

/* Define if you have isfinite */
#define HAVE_ISFINITE 1

/* Define if you have fork */
#define HAVE_FORK 1

/* Define if you have fpsetmask */
/* #undef HAVE_FPSETMASK */

/* Define if you have fpsetround */
/* #undef HAVE_FPSETROUND */

/* Define if you have isless */
#define HAVE_ISLESS 1

/* Define if you have isunordered */
#define HAVE_ISUNORDERED 1

/* Define if you have crypt.  */
#define HAVE_CRYPT 1

/* Define if you have ualarm. */
#define HAVE_UALARM 1

/* Define if your ualarm takes two args. */
#define UALARM_TAKES_TWO_ARGS 1

/* Define if your ptrace takes four args. */
#define PTRACE_TAKES_FOUR_ARGS 1

/* Define if argument 3 to ptrace is a pointer type. */
#define PTRACE_ADDR_TYPE_IS_POINTER 1

/* Define if gettimeofday takes to arguments */
#define GETTIMEOFDAY_TAKES_TWO_ARGS 1

/* Define if realloc(NULL, SZ) works. */
#define HAVE_WORKING_REALLOC_NULL 1

/* Define if gethrvtime works (i.e. even without ptime). */
/* #undef HAVE_WORKING_GETHRVTIME */

/* Define if you have gethrtime */
/* #undef HAVE_GETHRTIME */

/* Can we make our own gethrtime? */
/* #undef OWN_GETHRTIME */

/* ... by using the RDTSC instruction? */
/* #undef OWN_GETHRTIME_RDTSC */

/* Define if it is possible to allocate PROT_EXEC memory with mmap */
#define MEXEC_USES_MMAP 1

/* Define if you have gethostname */
#define HAVE_GETHOSTNAME 1

/* Define this if you have dlopen */
#define HAVE_DLOPEN 1

/* Define if you have rint.  */
#define HAVE_RINT 1

/* Define if your signals are one-shot */
/* #undef SIGNAL_ONESHOT */

/* Define this if eval_instruction gets large on your platform. */
/* #undef PIKE_SMALL_EVAL_INSTRUCTION */

/* Define if you have gcc-style computed goto, and want to use them. */
/* #undef HAVE_COMPUTED_GOTO */

/* Define this to use machine code */
/* #undef PIKE_USE_MACHINE_CODE */

/* Define if you have the RDTSC instruction */
#define HAVE_RDTSC 1

/* Define this to one of the available bytecode methods. */
#define PIKE_BYTECODE_METHOD PIKE_BYTECODE_DEFAULT

/* You have gcc-type function attributes? */
#define HAVE_FUNCTION_ATTRIBUTES 1

/* You have cl-type __declspec? */
/* #undef HAVE_DECLSPEC */

/* Your va_list is a state pointer? */
#define VA_LIST_IS_STATE_PTR 1

/* Defined if va_copy exists in stdarg.h. */
#define HAVE_VA_COPY 1

/* Does your compiler grock 'volatile' */
#define VOLATILE volatile

/* Define to empty if your compiler doesn't support C99's restrict keyword. */
/* #undef restrict */

/* Define this if your compiler doesn't allow cast of void * to function pointer */
/* #undef NO_CAST_TO_FUN */

/* How to extract a char and an unsigned char from a char * */
#define EXTRACT_CHAR_BY_CAST 1
#define EXTRACT_UCHAR_BY_CAST 1

/* Do you have IEEE floats and/or doubles (either big or little endian) ? */
/* #undef FLOAT_IS_IEEE_BIG */
#define FLOAT_IS_IEEE_LITTLE 1
/* #undef DOUBLE_IS_IEEE_BIG */
#define DOUBLE_IS_IEEE_LITTLE 1

/* The rest of this file is just to eliminate warnings */

/* define if declaration of strchr is missing */
/* #undef STRCHR_DECL_MISSING */

/* define if declaration of malloc is missing */
/* #undef MALLOC_DECL_MISSING */

/* define if declaration of getpeername is missing */
/* #undef GETPEERNAME_DECL_MISSING */

/* define if declaration of gethostname is missing */
/* #undef GETHOSTNAME_DECL_MISSING */

/* define if declaration of popen is missing */
/* #undef POPEN_DECL_MISSING */

/* define if declaration of getenv is missing */
/* #undef GETENV_DECL_MISSING */

/* define if you are using crypt.c. */
/* #undef USE_CRYPT_C */

/* Define if we can declare 'extern char **environ' */
#define DECLARE_ENVIRON 1

/* The byteorder your machine use, most use 4321, PC use 1234 */
#define PIKE_BYTEORDER 1234

/* What alignment do pointers need */
#define PIKE_POINTER_ALIGNMENT 8

/* Assembler prefix for general purpose registers */
/* #undef PIKE_CPU_REG_PREFIX */

/* define this if #include <time.h> provides an external int timezone */
#define HAVE_EXTERNAL_TIMEZONE 1

/* define this if #include <time.h> provides an external int altzone */
/* #undef HAVE_EXTERNAL_ALTZONE */

/* define this if your struct tm has a tm_gmtoff */
#define STRUCT_TM_HAS_GMTOFF 1

/* define this if your struct tm has a __tm_gmtoff */
/* #undef STRUCT_TM_HAS___TM_GMTOFF */

/* Define if you have struct timeval */
#define HAVE_STRUCT_TIMEVAL 1

/* Define if you have struct sockaddr_in6 */
#define HAVE_STRUCT_SOCKADDR_IN6 1

/* Define this if you have a struct iovec */
#define HAVE_STRUCT_IOVEC 1

/* Define this if you have a struct msghdr */
#define HAVE_STRUCT_MSGHDR 1

/* Define this if you have a struct msghdr with 'msg_control' member */
#define HAVE_STRUCT_MSGHDR_MSG_CONTROL 1

/* Define this if you have a struct msghdr with 'msg_accrights' member */
/* #undef HAVE_STRUCT_MSGHDR_MSG_ACCRIGHTS */

/* Define this to the max value of an unsigned short unless <limits.h> does.. */
/* #undef USHRT_MAX */

/* Define these if you are going to use threads */
#define PIKE_THREADS 1
#define _REENTRANT 1
#define _THREAD_SAFE 1

/* Define this if you want the UNIX taste of threads */
/* #undef _UNIX_THREADS */

/* Define this if you want the POSIX taste of threads */
#define _MIT_POSIX_THREADS 1

/* Define this if you want the SGI sproc taste of threads */
/* #undef _SGI_SPROC_THREADS */
/* #undef _SGI_MP_SOURCE */

/* Define this if you have Windows NT threads */
/* #undef NT_THREADS */

/* Use DDLs for dynamically linked modules on NT. */
/* #undef USE_DLL */

/* Define this if your THREAD_T type is a pointer type. */
/* #undef PIKE_THREAD_T_IS_POINTER */

/* Define to the flag to get an error checking mutex, if supported. */
#define PIKE_MUTEX_ERRORCHECK PTHREAD_MUTEX_ERRORCHECK

/* Define to the flag to get a recursive mutex, if supported. */
#define PIKE_MUTEX_RECURSIVE PTHREAD_MUTEX_RECURSIVE

/* Define this if your pthreads have pthread_condattr_default */
/* #undef HAVE_PTHREAD_CONDATTR_DEFAULT */

/* Define this if you need to use &pthread_condattr_default in cond_init() */
/* #undef HAVE_PTHREAD_CONDATTR_DEFAULT_AIX */

/* Define if you have the pthread_attr_setstacksize function.  */
#define HAVE_PTHREAD_ATTR_SETSTACKSIZE 1

/* Define if you have the pthread_atfork function.  */
#define HAVE_PTHREAD_ATFORK 1

/* Define if you have the pthread_cond_init function.  */
#define HAVE_PTHREAD_COND_INIT 1

/* Define if you have the pthread_yield function.  */
#define HAVE_PTHREAD_YIELD 1

/* Define if you have the pthread_yield_np function.  */
/* #undef HAVE_PTHREAD_YIELD_NP */

/* Hack for stupid glibc linuxthreads */
/* #undef HAVE_PTHREAD_INITIAL_THREAD_BOS */

/* Define if your OS has the union wait. */
/* #undef HAVE_UNION_WAIT */

/* Define if your cpp supports the ANSI concatenation operator ## */
#define HAVE_ANSI_CONCAT 1

/* Define if you don't have F_SETFD, or it doesn't work */
/* #undef HAVE_BROKEN_F_SETFD */

/* Define if your thread implementation doesn't propagate euid & egid. */
/* #undef HAVE_BROKEN_LINUX_THREAD_EUID */

/* Define if your cpp supports K&R-style concatenation */
/* #undef HAVE_KR_CONCAT */

/* Use poll() instead of select() ? */
#define HAVE_AND_USE_POLL 1

/* Enable use of /dev/epoll on Linux. */
#define WITH_EPOLL 1

/* Define to the poll device (eg "/dev/poll") */
/* #undef PIKE_POLL_DEVICE */

/* This works on Solaris or any UNIX where
 * waitpid can report ECHILD when running more than one at once
 * (or any UNIX where waitpid actually works)
 */
/* #undef USE_WAIT_THREAD */

/* This works on Linux or any UNIX where
 * waitpid works or where threads and signals bugs in
 * less annoying ways than Solaris.
 */
#define USE_SIGCHILD 1

/* Enable tracing of the compiler */
/* #undef YYDEBUG */

/* Define if your compiler has a symbol __func__ */
#define HAVE_WORKING___FUNC__ 1

/* Define if your compiler has a symbol __FUNCTION__ */
#define HAVE_WORKING___FUNCTION__ 1

/* The last argument to accept() is an ACCEPT_SIZE_T * */
#define ACCEPT_SIZE_T socklen_t

/* Define if you have the <sys/resource.h> header file.  */
#define HAVE_SYS_RESOURCE_H 1

/* set this to the modifier type string to print size_t, like "" or "l" */
#define PRINTSIZET "z"

/* set this to the modifier type string to print ptrdiff_t, like "" or "l" */
#define PRINTPTRDIFFT "t"

/* set this to the modifier type string to print off_t if that type exists */
#define PRINTOFFT "t"

/* set this to the modifier type string to print INT64 if that type exists */
#define PRINTINT64 "l"

/* Define if the compiler understands union initializations. */
#define HAVE_UNION_INIT 1

/* Define if the compiler has problems with union aliasing. */
/* #undef NO_COMBINED_TYPE_SUBTYPE */

/* Define when binary --disable-binary is used. */
/* #undef DISABLE_BINARY */

/* Define to the size of the overhead for a malloc'ed block. (Slightly
 * too much is better than slightly too little.) */
#define PIKE_MALLOC_OVERHEAD (2 * sizeof(void *))

/* Define to the page size (handled efficiently by malloc). */
#define PIKE_MALLOC_PAGE_SIZE (4 * 1024)

/* PIKE_YES if the number reported by fallback_get_cpu_time (rusage.c)
 * is thread local, PIKE_NO if it isn't, PIKE_UNKNOWN if it couldn't
 * be established. */
#define FB_CPU_TIME_IS_THREAD_LOCAL PIKE_NO


/* Define to 1 if using 'alloca.c'. */
/* #undef C_ALLOCA */

/* Whether _BitScanForward is available */
/* #undef HAS__BITSCANFORWARD */

/* Whether _BitScanForward64 is available */
/* #undef HAS__BITSCANFORWARD64 */

/* Whether _BitScanReverse is available */
/* #undef HAS__BITSCANREVERSE */

/* Whether _BitScanReverse64 is available */
/* #undef HAS__BITSCANREVERSE64 */

/* Whether _bit_scan_forward is available */
/* #undef HAS__BIT_SCAN_FORWARD */

/* Whether _bit_scan_reverse is available */
/* #undef HAS__BIT_SCAN_REVERSE */

/* Whether _bswap is available */
/* #undef HAS__BSWAP */

/* Whether _bswap64 is available */
/* #undef HAS__BSWAP64 */

/* Whether _byteswap_uint64 is available */
/* #undef HAS__BYTESWAP_UINT64 */

/* Whether _byteswap_ulong is available */
/* #undef HAS__BYTESWAP_ULONG */

/* Whether __builtin_bswap32 is available */
#define HAS___BUILTIN_BSWAP32 1

/* Whether __builtin_bswap64 is available */
#define HAS___BUILTIN_BSWAP64 1

/* Whether __builtin_clz is available */
#define HAS___BUILTIN_CLZ 1

/* Whether __builtin_clzl is available */
#define HAS___BUILTIN_CLZL 1

/* Whether __builtin_clzll is available */
#define HAS___BUILTIN_CLZLL 1

/* Whether __builtin_ctz is available */
#define HAS___BUILTIN_CTZ 1

/* Whether __builtin_ctzl is available */
#define HAS___BUILTIN_CTZL 1

/* Whether __builtin_ctzll is available */
#define HAS___BUILTIN_CTZLL 1

/* Whether __builtin_expect is available */
#define HAS___BUILTIN_EXPECT 1

/* Whether __builtin_ia32_rdrand32_step is available */
#define HAS___BUILTIN_IA32_RDRAND32_STEP 1

/* Whether __builtin_memset is available */
#define HAS___BUILTIN_MEMSET 1

/* Whether __builtin_unreachable is available */
#define HAS___BUILTIN_UNREACHABLE 1

/* Whether __cntlz4 is available */
/* #undef HAS___CNTLZ4 */

/* Whether __cntlz8 is available */
/* #undef HAS___CNTLZ8 */

/* Whether __cnttz4 is available */
/* #undef HAS___CNTTZ4 */

/* Whether __cnttz8 is available */
/* #undef HAS___CNTTZ8 */

/* Define to 1 if you have the `accept4' function. */
#define HAVE_ACCEPT4 1

/* Define to 1 if you have the `alarm' function. */
#define HAVE_ALARM 1

/* Define to 1 if you have 'alloca', as a function or macro. */
#define HAVE_ALLOCA 1

/* Define to 1 if <alloca.h> works. */
#define HAVE_ALLOCA_H 1

/* Define to 1 if you have the <arpa/inet.h> header file. */
#define HAVE_ARPA_INET_H 1

/* Define to 1 if you have the `backtrace' function. */
#define HAVE_BACKTRACE 1

/* Define to 1 if you have the `bswap16' function. */
/* #undef HAVE_BSWAP16 */

/* Define to 1 if you have the `bswap32' function. */
/* #undef HAVE_BSWAP32 */

/* Define to 1 if you have the `bswap64' function. */
/* #undef HAVE_BSWAP64 */

/* Define to 1 if you have the `CFRunLoopRunInMode' function. */
/* #undef HAVE_CFRUNLOOPRUNINMODE */

/* Define to 1 if you have the `chroot' function. */
#define HAVE_CHROOT 1

/* Define to 1 if you have the `clock_getcpuclockid' function. */
#define HAVE_CLOCK_GETCPUCLOCKID 1

/* Define to 1 if you have the `closefrom' function. */
#define HAVE_CLOSEFROM 1

/* Define to 1 if you have the <CoreServices/CoreServices.h> header file. */
/* #undef HAVE_CORESERVICES_CORESERVICES_H */

/* True if crc32 intrinsics are available */
#define HAVE_CRC32_INTRINSICS /**/

/* Define to 1 if you have the <crt/signal.h> header file. */
/* #undef HAVE_CRT_SIGNAL_H */

/* Define to 1 if you have the `crypt' function. */
#define HAVE_CRYPT 1

/* Define to 1 if you have the <crypt.h> header file. */
#define HAVE_CRYPT_H 1

/* Define to 1 if you have the <devices/timer.h> header file. */
/* #undef HAVE_DEVICES_TIMER_H */

/* Define to 1 if you have the <direct.h> header file. */
/* #undef HAVE_DIRECT_H */

/* Define to 1 if you have the `dld_get_func' function. */
/* #undef HAVE_DLD_GET_FUNC */

/* Define to 1 if you have the <dld.h> header file. */
/* #undef HAVE_DLD_H */

/* Define to 1 if you have the `dld_link' function. */
/* #undef HAVE_DLD_LINK */

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define to 1 if you have the <dl.h> header file. */
/* #undef HAVE_DL_H */

/* Define to 1 if you have the <errno.h> header file. */
#define HAVE_ERRNO_H 1

/* Define to 1 if you have the <execinfo.h> header file. */
#define HAVE_EXECINFO_H 1

/* Define to 1 if you have the <fcntl.h> header file. */
#define HAVE_FCNTL_H 1

/* Define to 1 if you have the `fdwalk' function. */
/* #undef HAVE_FDWALK */

/* Define to 1 if you have the `finite' function. */
#define HAVE_FINITE 1

/* Define to 1 if you have the <floatingpoint.h> header file. */
/* #undef HAVE_FLOATINGPOINT_H */

/* Define to 1 if you have the <float.h> header file. */
#define HAVE_FLOAT_H 1

/* Define to 1 if you have the `flock' function. */
#define HAVE_FLOCK 1

/* Define to 1 if you have the <fnord/fnord/fnord.h> header file. */
/* #undef HAVE_FNORD_FNORD_FNORD_H */

/* Define to 1 if you have the `fork1' function. */
/* #undef HAVE_FORK1 */

/* Define to 1 if you have the `fpclass' function. */
/* #undef HAVE_FPCLASS */

/* Define to 1 if you have the `fp_class_d' function. */
/* #undef HAVE_FP_CLASS_D */

/* Define to 1 if you have the <fp_class.h> header file. */
/* #undef HAVE_FP_CLASS_H */

/* Define to 1 if you have the `CoreServices' framework (-framework
   CoreServices). */
/* #undef HAVE_FRAMEWORK_CORESERVICES */

/* Define to 1 if you have the `ftruncate64' function. */
#define HAVE_FTRUNCATE64 1

/* Define to 1 if you have the `getegid' function. */
#define HAVE_GETEGID 1

/* Define to 1 if you have the `geteuid' function. */
#define HAVE_GETEUID 1

/* Define to 1 if you have the `getgid' function. */
#define HAVE_GETGID 1

/* Define to 1 if you have the `getgrent' function. */
#define HAVE_GETGRENT 1

/* Define to 1 if you have the `getgrnam' function. */
#define HAVE_GETGRNAM 1

/* Define to 1 if you have the `gethrtime' function. */
/* #undef HAVE_GETHRTIME */

/* Define to 1 if you have the `gethrvtime' function. */
/* #undef HAVE_GETHRVTIME */

/* Define to 1 if you have the `getpagesize' function. */
#define HAVE_GETPAGESIZE 1

/* Define to 1 if you have the `getpwent' function. */
#define HAVE_GETPWENT 1

/* Define to 1 if you have the `getpwnam' function. */
#define HAVE_GETPWNAM 1

/* Define to 1 if you have the `getpwuid' function. */
#define HAVE_GETPWUID 1

/* Define to 1 if you have the `getrlimit' function. */
#define HAVE_GETRLIMIT 1

/* Define to 1 if you have the `getrusage' function. */
#define HAVE_GETRUSAGE 1

/* Define to 1 if you have the `GetSystemInfo' function. */
/* #undef HAVE_GETSYSTEMINFO */

/* Define to 1 if you have the `gettimeofday' function. */
#define HAVE_GETTIMEOFDAY 1

/* Define to 1 if you have the `getuid' function. */
#define HAVE_GETUID 1

/* Define to 1 if you have the `getwd' function. */
#define HAVE_GETWD 1

/* Define to 1 if you have the `get_current_dir_name' function. */
#define HAVE_GET_CURRENT_DIR_NAME 1

/* Define to 1 if you have the <gmp.h> header file. */
#define HAVE_GMP_H 1

/* Define to 1 if you have the `gmtime_r' function. */
#define HAVE_GMTIME_R 1

/* Define to 1 if you have the `gmtime_s' function. */
/* #undef HAVE_GMTIME_S */

/* Define to 1 if you have the <gnu/stubs.h> header file. */
#define HAVE_GNU_STUBS_H 1

/* Define to 1 if you have the <group.h> header file. */
/* #undef HAVE_GROUP_H */

/* Define to 1 if you have the <grp.h> header file. */
#define HAVE_GRP_H 1

/* Define to 1 if you have the `host_get_clock_service' function. */
/* #undef HAVE_HOST_GET_CLOCK_SERVICE */

/* Define to 1 if the system has the type `HPCON'. */
/* #undef HAVE_HPCON */

/* Define to 1 if you have the <ieeefp.h> header file. */
/* #undef HAVE_IEEEFP_H */

/* Define to 1 if you have the `inet_ntop' function. */
#define HAVE_INET_NTOP 1

/* Define to 1 if you have the `initgroups' function. */
#define HAVE_INITGROUPS 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the <io.h> header file. */
/* #undef HAVE_IO_H */

/* Define to 1 if you have the `isinf' function. */
#define HAVE_ISINF 1

/* Define to 1 if you have the `isnan' function. */
#define HAVE_ISNAN 1

/* Define to 1 if you have the `iszero' function. */
/* #undef HAVE_ISZERO */

/* Define to 1 if you have the `kill' function. */
#define HAVE_KILL 1

/* Define to 1 if you have the `kqueue' function. */
/* #undef HAVE_KQUEUE */

/* Define to 1 if you have the `dl' library (-ldl). */
#define HAVE_LIBDL 1

/* Define to 1 if you have the `dld' library (-ldld). */
/* #undef HAVE_LIBDLD */

/* Define to 1 if you have the `m' library (-lm). */
#define HAVE_LIBM 1

/* Define to 1 if you have the `nsl' library (-lnsl). */
#define HAVE_LIBNSL 1

/* Define to 1 if you have the `poll' library (-lpoll). */
/* #undef HAVE_LIBPOLL */

/* Define to 1 if you have the `rt' library (-lrt). */
#define HAVE_LIBRT 1

/* Define to 1 if you have the `socket' library (-lsocket). */
/* #undef HAVE_LIBSOCKET */

/* Define to 1 if you have the `tdf' library (-ltdf). */
/* #undef HAVE_LIBTDF */

/* Define to 1 if you have the `urcu' library (-lurcu). */
/* #undef HAVE_LIBURCU */

/* Define to 1 if you have the `util' library (-lutil). */
#define HAVE_LIBUTIL 1

/* Define to 1 if you have the <limits.h> header file. */
#define HAVE_LIMITS_H 1

/* Define to 1 if you have the <locale.h> header file. */
#define HAVE_LOCALE_H 1

/* Define to 1 if you have the `localtime_s' function. */
/* #undef HAVE_LOCALTIME_S */

/* Define to 1 if you have the `lockf' function. */
#define HAVE_LOCKF 1

/* Define to 1 if the system has the type `LPPROC_THREAD_ATTRIBUTE_LIST'. */
/* #undef HAVE_LPPROC_THREAD_ATTRIBUTE_LIST */

/* Define to 1 if the system has the type `LPSTARTUPINFOEXW'. */
/* #undef HAVE_LPSTARTUPINFOEXW */

/* Define to 1 if you have the <machine/bswap.h> header file. */
/* #undef HAVE_MACHINE_BSWAP_H */

/* Define to 1 if you have the <mach/clock.h> header file. */
/* #undef HAVE_MACH_CLOCK_H */

/* Define to 1 if you have the <mach/mach.h> header file. */
/* #undef HAVE_MACH_MACH_H */

/* Define to 1 if you have the <mach/mach_init.h> header file. */
/* #undef HAVE_MACH_MACH_INIT_H */

/* Define to 1 if you have the <mach/message.h> header file. */
/* #undef HAVE_MACH_MESSAGE_H */

/* Define to 1 if you have the <mach-o/dyld.h> header file. */
/* #undef HAVE_MACH_O_DYLD_H */

/* Define to 1 if you have the <mach/task.h> header file. */
/* #undef HAVE_MACH_TASK_H */

/* Define to 1 if you have the <mach/task_info.h> header file. */
/* #undef HAVE_MACH_TASK_INFO_H */

/* Define to 1 if you have the <mach/thread_act.h> header file. */
/* #undef HAVE_MACH_THREAD_ACT_H */

/* Define to 1 if you have the `MakeDataExecutable' function. */
/* #undef HAVE_MAKEDATAEXECUTABLE */

/* Define to 1 if you have the `mallinfo' function. */
#define HAVE_MALLINFO 1

/* Define to 1 if you have the `mallinfo2' function. */
#define HAVE_MALLINFO2 1

/* Define to 1 if you have the <malloc.h> header file. */
#define HAVE_MALLOC_H 1

/* Define to 1 if you have the `mallopt' function. */
#define HAVE_MALLOPT 1

/* Define to 1 if you have the <memcheck.h> header file. */
/* #undef HAVE_MEMCHECK_H */

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define to 1 if you have the <minix/config.h> header file. */
/* #undef HAVE_MINIX_CONFIG_H */

/* Define to 1 if you have a working `mmap' system call. */
#define HAVE_MMAP 1

/* Define to 1 if you have the `munmap' function. */
#define HAVE_MUNMAP 1

/* Define to 1 if you have the `nan' function. */
#define HAVE_NAN 1

/* Define to 1 if you have the `nanosleep' function. */
#define HAVE_NANOSLEEP 1

/* Define to 1 if you have the <netinet/in.h> header file. */
#define HAVE_NETINET_IN_H 1

/* Define to 1 if you have the <net/socket.h> header file. */
/* #undef HAVE_NET_SOCKET_H */

/* Define to 1 if you have the `nice' function. */
#define HAVE_NICE 1

/* Define to 1 if you have the `openpty' function. */
#define HAVE_OPENPTY 1

/* Define to 1 if you have the <passwd.h> header file. */
/* #undef HAVE_PASSWD_H */

/* Define to 1 if you have the `pipe' function. */
#define HAVE_PIPE 1

/* Define to 1 if you have the `poll' function. */
#define HAVE_POLL 1

/* Define to 1 if you have the <poll.h> header file. */
#define HAVE_POLL_H 1

/* Define to 1 if you have the `prctl' function. */
#define HAVE_PRCTL 1

/* Define to 1 if you have the `pthread_cond_reltimedwait_np' function. */
/* #undef HAVE_PTHREAD_COND_RELTIMEDWAIT_NP */

/* Define to 1 if you have the <pthread.h> header file. */
#define HAVE_PTHREAD_H 1

/* Define to 1 if you have the `pthread_init' function. */
/* #undef HAVE_PTHREAD_INIT */

/* Define to 1 if you have the `pthread_kill' function. */
#define HAVE_PTHREAD_KILL 1

/* Define to 1 if you have the `pthread_mach_thread_np' function. */
/* #undef HAVE_PTHREAD_MACH_THREAD_NP */

/* Define to 1 if you have the `pthread_mutexattr_init' function. */
#define HAVE_PTHREAD_MUTEXATTR_INIT 1

/* Define to 1 if you have the `ptrace' function. */
#define HAVE_PTRACE 1

/* Define to 1 if you have the <pwd.h> header file. */
#define HAVE_PWD_H 1

/* Define to 1 if you have the <sched.h> header file. */
#define HAVE_SCHED_H 1

/* Define to 1 if you have the `sched_setscheduler' function. */
#define HAVE_SCHED_SETSCHEDULER 1

/* Define to 1 if you have the `sched_yield' function. */
#define HAVE_SCHED_YIELD 1

/* Define to 1 if you have the `setenv' function. */
#define HAVE_SETENV 1

/* Define to 1 if you have the `SetErrorMode' function. */
/* #undef HAVE_SETERRORMODE */

/* Define to 1 if you have the `seteuid' function. */
#define HAVE_SETEUID 1

/* Define to 1 if you have the `SetFilePointerEx' function. */
/* #undef HAVE_SETFILEPOINTEREX */

/* Define to 1 if you have the `setgid' function. */
#define HAVE_SETGID 1

/* Define to 1 if you have the `setgroups' function. */
#define HAVE_SETGROUPS 1

/* Define to 1 if you have the `setitimer' function. */
#define HAVE_SETITIMER 1

/* Define to 1 if you have the <setjmp.h> header file. */
#define HAVE_SETJMP_H 1

/* Define to 1 if you have the `setpriority' function. */
#define HAVE_SETPRIORITY 1

/* Define to 1 if you have the `setresuid' function. */
#define HAVE_SETRESUID 1

/* Define to 1 if you have the `setrlimit' function. */
#define HAVE_SETRLIMIT 1

/* Define to 1 if you have the `setsid' function. */
#define HAVE_SETSID 1

/* Define to 1 if you have the `setuid' function. */
#define HAVE_SETUID 1

/* Define to 1 if you have the `shl_load' function. */
/* #undef HAVE_SHL_LOAD */

/* Define to 1 if you have the `sigaction' function. */
#define HAVE_SIGACTION 1

/* Define to 1 if you have the `siglongjmp' function. */
#define HAVE_SIGLONGJMP 1

/* Define to 1 if you have the <signal.h> header file. */
#define HAVE_SIGNAL_H 1

/* Define to 1 if you have the `signbit' function. */
/* #undef HAVE_SIGNBIT */

/* Define to 1 if you have the `sigsetjmp' function. */
/* #undef HAVE_SIGSETJMP */

/* Define to 1 if you have the `sigvec' function. */
/* #undef HAVE_SIGVEC */

/* Define to 1 if you have the `snprintf' function. */
#define HAVE_SNPRINTF 1

/* Define to 1 if you have the `socketpair' function. */
#define HAVE_SOCKETPAIR 1

/* Define to 1 if you have the <socket.h> header file. */
/* #undef HAVE_SOCKET_H */

/* Define to 1 if you have the <stddef.h> header file. */
#define HAVE_STDDEF_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the `strcasecmp' function. */
#define HAVE_STRCASECMP 1

/* Define to 1 if you have the `strdup' function. */
#define HAVE_STRDUP 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the `strptime' function. */
#define HAVE_STRPTIME 1

/* Defined if malloc.h contains a struct mallinfo. */
#define HAVE_STRUCT_MALLINFO 1

/* Define to 1 if the system has the type `struct winsize'. */
/* #undef HAVE_STRUCT_WINSIZE */

/* Define to 1 if you have the `sync_instruction_memory' function. */
/* #undef HAVE_SYNC_INSTRUCTION_MEMORY */

/* Define to 1 if you have the <syscall.h> header file. */
#define HAVE_SYSCALL_H 1

/* Define to 1 if you have the `sysconf' function. */
#define HAVE_SYSCONF 1

/* Define to 1 if you have the <sys/devpoll.h> header file. */
/* #undef HAVE_SYS_DEVPOLL_H */

/* Define to 1 if you have the <sys/endian.h> header file. */
/* #undef HAVE_SYS_ENDIAN_H */

/* Define to 1 if you have the <sys/epoll.h> header file. */
#define HAVE_SYS_EPOLL_H 1

/* Define to 1 if you have the <sys/errno.h> header file. */
#define HAVE_SYS_ERRNO_H 1

/* Define to 1 if you have the <sys/event.h> header file. */
/* #undef HAVE_SYS_EVENT_H */

/* Define to 1 if you have the <sys/file.h> header file. */
#define HAVE_SYS_FILE_H 1

/* Define to 1 if you have the <sys/filio.h> header file. */
/* #undef HAVE_SYS_FILIO_H */

/* Define to 1 if you have the <sys/id.h> header file. */
/* #undef HAVE_SYS_ID_H */

/* Define to 1 if you have the <sys/ioctl.h> header file. */
#define HAVE_SYS_IOCTL_H 1

/* Define to 1 if you have the <sys/ioct.h> header file. */
/* #undef HAVE_SYS_IOCT_H */

/* Define to 1 if you have the <sys/mman.h> header file. */
#define HAVE_SYS_MMAN_H 1

/* Define to 1 if you have the <sys/param.h> header file. */
#define HAVE_SYS_PARAM_H 1

/* Define to 1 if you have the <sys/poll.h> header file. */
#define HAVE_SYS_POLL_H 1

/* Define to 1 if you have the <sys/prctl.h> header file. */
#define HAVE_SYS_PRCTL_H 1

/* Define to 1 if you have the <sys/priocntl.h> header file. */
/* #undef HAVE_SYS_PRIOCNTL_H */

/* Define to 1 if you have the <sys/procfs.h> header file. */
#define HAVE_SYS_PROCFS_H 1

/* Define to 1 if you have the <sys/ptrace.h> header file. */
#define HAVE_SYS_PTRACE_H 1

/* Define to 1 if you have the <sys/rusage.h> header file. */
/* #undef HAVE_SYS_RUSAGE_H */

/* Define to 1 if you have the <sys/sched.h> header file. */
/* #undef HAVE_SYS_SCHED_H */

/* Define to 1 if you have the <sys/select.h> header file. */
#define HAVE_SYS_SELECT_H 1

/* Define to 1 if you have the <sys/socket.h> header file. */
#define HAVE_SYS_SOCKET_H 1

/* Define to 1 if you have the <sys/sockio.h> header file. */
/* #undef HAVE_SYS_SOCKIO_H */

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/syscall.h> header file. */
#define HAVE_SYS_SYSCALL_H 1

/* Define to 1 if you have the <sys/termios.h> header file. */
#define HAVE_SYS_TERMIOS_H 1

/* Define to 1 if you have the <sys/termio.h> header file. */
/* #undef HAVE_SYS_TERMIO_H */

/* Define to 1 if you have the <sys/times.h> header file. */
#define HAVE_SYS_TIMES_H 1

/* Define to 1 if you have the <sys/time.h> header file. */
#define HAVE_SYS_TIME_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <sys/uio.h> header file. */
#define HAVE_SYS_UIO_H 1

/* Define to 1 if you have the <sys/user.h> header file. */
#define HAVE_SYS_USER_H 1

/* Define to 1 if you have the <sys/wait.h> header file. */
#define HAVE_SYS_WAIT_H 1

/* Define to 1 if you have the <thread.h> header file. */
/* #undef HAVE_THREAD_H */

/* Define to 1 if you have the `thread_info' function. */
/* #undef HAVE_THREAD_INFO */

/* Define to 1 if you have the `thr_yield' function. */
/* #undef HAVE_THR_YIELD */

/* Define to 1 if you have the `times' function. */
#define HAVE_TIMES 1

/* Define to 1 if you have the <time.h> header file. */
#define HAVE_TIME_H 1

/* Define to 1 if you have the `truncate64' function. */
#define HAVE_TRUNCATE64 1

/* Define to 1 if you have the `tzset' function. */
#define HAVE_TZSET 1

/* Define to 1 if you have the `ualarm' function. */
#define HAVE_UALARM 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to 1 if you have the `unsetenv' function. */
#define HAVE_UNSETENV 1

/* Define to 1 if you have the <urcu.h> header file. */
/* #undef HAVE_URCU_H */

/* Define to 1 if you have the <util.h> header file. */
/* #undef HAVE_UTIL_H */

/* Define to 1 if you have the <valgrind.h> header file. */
/* #undef HAVE_VALGRIND_H */

/* Define to 1 if you have the <valgrind/memcheck.h> header file. */
/* #undef HAVE_VALGRIND_MEMCHECK_H */

/* Define to 1 if you have the <values.h> header file. */
#define HAVE_VALUES_H 1

/* Define to 1 if you have the `vsnprintf' function. */
#define HAVE_VSNPRINTF 1

/* Define to 1 if you have the `wait3' function. */
#define HAVE_WAIT3 1

/* Define to 1 if you have the `wait4' function. */
#define HAVE_WAIT4 1

/* Define to 1 if you have the `waitpid' function. */
#define HAVE_WAITPID 1

/* Define to 1 if you have the <wchar.h> header file. */
#define HAVE_WCHAR_H 1

/* Define to 1 if you have the <winbase.h> header file. */
/* #undef HAVE_WINBASE_H */

/* Define to 1 if you have the <windows.h> header file. */
/* #undef HAVE_WINDOWS_H */

/* Define to 1 if you have the <winsock2.h> header file. */
/* #undef HAVE_WINSOCK2_H */

/* Define to 1 if you have the <winsock.h> header file. */
/* #undef HAVE_WINSOCK_H */

/* Define to 1 if you have the <ws2tcpip.h> header file. */
/* #undef HAVE_WS2TCPIP_H */

/* Define to 1 if you have the `_crypt' function. */
/* #undef HAVE__CRYPT */

/* Define to 1 if you have the `_get_daylight' function. */
/* #undef HAVE__GET_DAYLIGHT */

/* Define to 1 if you have the `_get_timezone' function. */
/* #undef HAVE__GET_TIMEZONE */

/* Define to 1 if you have the `_longjmp' function. */
#define HAVE__LONGJMP 1

/* Define to 1 if you have the `_setjmp' function. */
#define HAVE__SETJMP 1

/* Define to 1 if you have the `_snprintf' function. */
/* #undef HAVE__SNPRINTF */

/* Define to 1 if you have the `__bswap16' function. */
/* #undef HAVE___BSWAP16 */

/* Define to 1 if you have the `__bswap32' function. */
/* #undef HAVE___BSWAP32 */

/* Define to 1 if you have the `__bswap64' function. */
/* #undef HAVE___BSWAP64 */

/* Define to 1 if you have the `__priocntl' function. */
/* #undef HAVE___PRIOCNTL */

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define PACKAGE_NAME ""

/* Define to the full name and version of this package. */
#define PACKAGE_STRING ""

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME ""

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION ""

/* Defined if putenv() always requires a '=' */
/* #undef PUTENV_ALWAYS_REQUIRES_EQUAL */

/* Define as the return type of signal handlers (`int' or `void'). */
#define RETSIGTYPE void

/* The size of `char *', as computed by sizeof. */
#define SIZEOF_CHAR_P 8

/* The size of `double', as computed by sizeof. */
#define SIZEOF_DOUBLE 8

/* The size of `float', as computed by sizeof. */
#define SIZEOF_FLOAT 4

/* The size of `int', as computed by sizeof. */
#define SIZEOF_INT 4

/* The size of `long', as computed by sizeof. */
#define SIZEOF_LONG 8

/* The size of `long double', as computed by sizeof. */
#define SIZEOF_LONG_DOUBLE 16

/* The size of `long long', as computed by sizeof. */
#define SIZEOF_LONG_LONG 8

/* The size of `off_t', as computed by sizeof. */
#define SIZEOF_OFF_T 8

/* The size of `short', as computed by sizeof. */
#define SIZEOF_SHORT 2

/* The size of `time_t', as computed by sizeof. */
#define SIZEOF_TIME_T 8

/* The size of `unsigned __int128', as computed by sizeof. */
#define SIZEOF_UNSIGNED___INT128 16

/* The size of `unsigned __int128_t', as computed by sizeof. */
#define SIZEOF_UNSIGNED___INT128_T 0

/* The size of `__int128', as computed by sizeof. */
#define SIZEOF___INT128 16

/* The size of `__int128_t', as computed by sizeof. */
#define SIZEOF___INT128_T 16

/* The size of `__int64', as computed by sizeof. */
#define SIZEOF___INT64 0

/* The size of `__uint128_t', as computed by sizeof. */
#define SIZEOF___UINT128_T 16

/* If using the C implementation of alloca, define if you know the
   direction of stack growth for your system; otherwise it will be
   automatically deduced at runtime.
	STACK_DIRECTION > 0 => grows toward higher addresses
	STACK_DIRECTION < 0 => grows toward lower addresses
	STACK_DIRECTION = 0 => direction of growth unknown */
#define STACK_DIRECTION -1

/* Define to 1 if all of the C90 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define STDC_HEADERS 1

/* Define to 1 if you can safely include both <sys/time.h> and <time.h>. This
   macro is obsolete. */
#define TIME_WITH_SYS_TIME 1

/* Define to 1 if your <sys/time.h> declares `struct tm'. */
/* #undef TM_IN_SYS_TIME */

/* Define if pthreads and mach headers conflict */
/* #undef USE_DARWIN_THREADS_WITHOUT_MACH */

/* Enable extensions on AIX 3, Interix.  */
#ifndef _ALL_SOURCE
# define _ALL_SOURCE 1
#endif
/* Enable general extensions on macOS.  */
#ifndef _DARWIN_C_SOURCE
# define _DARWIN_C_SOURCE 1
#endif
/* Enable general extensions on Solaris.  */
#ifndef __EXTENSIONS__
# define __EXTENSIONS__ 1
#endif
/* Enable GNU extensions on systems that have them.  */
#ifndef _GNU_SOURCE
# define _GNU_SOURCE 1
#endif
/* Enable X/Open compliant socket functions that do not require linking
   with -lxnet on HP-UX 11.11.  */
#ifndef _HPUX_ALT_XOPEN_SOCKET_API
# define _HPUX_ALT_XOPEN_SOCKET_API 1
#endif
/* Identify the host operating system as Minix.
   This macro does not affect the system headers' behavior.
   A future release of Autoconf may stop defining this macro.  */
#ifndef _MINIX
/* # undef _MINIX */
#endif
/* Enable general extensions on NetBSD.
   Enable NetBSD compatibility extensions on Minix.  */
#ifndef _NETBSD_SOURCE
# define _NETBSD_SOURCE 1
#endif
/* Enable OpenBSD compatibility extensions on NetBSD.
   Oddly enough, this does nothing on OpenBSD.  */
#ifndef _OPENBSD_SOURCE
# define _OPENBSD_SOURCE 1
#endif
/* Define to 1 if needed for POSIX-compatible behavior.  */
#ifndef _POSIX_SOURCE
/* # undef _POSIX_SOURCE */
#endif
/* Define to 2 if needed for POSIX-compatible behavior.  */
#ifndef _POSIX_1_SOURCE
/* # undef _POSIX_1_SOURCE */
#endif
/* Enable POSIX-compatible threading on Solaris.  */
#ifndef _POSIX_PTHREAD_SEMANTICS
# define _POSIX_PTHREAD_SEMANTICS 1
#endif
/* Enable extensions specified by ISO/IEC TS 18661-5:2014.  */
#ifndef __STDC_WANT_IEC_60559_ATTRIBS_EXT__
# define __STDC_WANT_IEC_60559_ATTRIBS_EXT__ 1
#endif
/* Enable extensions specified by ISO/IEC TS 18661-1:2014.  */
#ifndef __STDC_WANT_IEC_60559_BFP_EXT__
# define __STDC_WANT_IEC_60559_BFP_EXT__ 1
#endif
/* Enable extensions specified by ISO/IEC TS 18661-2:2015.  */
#ifndef __STDC_WANT_IEC_60559_DFP_EXT__
# define __STDC_WANT_IEC_60559_DFP_EXT__ 1
#endif
/* Enable extensions specified by ISO/IEC TS 18661-4:2015.  */
#ifndef __STDC_WANT_IEC_60559_FUNCS_EXT__
# define __STDC_WANT_IEC_60559_FUNCS_EXT__ 1
#endif
/* Enable extensions specified by ISO/IEC TS 18661-3:2015.  */
#ifndef __STDC_WANT_IEC_60559_TYPES_EXT__
# define __STDC_WANT_IEC_60559_TYPES_EXT__ 1
#endif
/* Enable extensions specified by ISO/IEC TR 24731-2:2010.  */
#ifndef __STDC_WANT_LIB_EXT2__
# define __STDC_WANT_LIB_EXT2__ 1
#endif
/* Enable extensions specified by ISO/IEC 24747:2009.  */
#ifndef __STDC_WANT_MATH_SPEC_FUNCS__
# define __STDC_WANT_MATH_SPEC_FUNCS__ 1
#endif
/* Enable extensions on HP NonStop.  */
#ifndef _TANDEM_SOURCE
# define _TANDEM_SOURCE 1
#endif
/* Enable X/Open extensions.  Define to 500 only if necessary
   to make mbstate_t available.  */
#ifndef _XOPEN_SOURCE
/* # undef _XOPEN_SOURCE */
#endif


/* Define to 1 if type `char' is unsigned and your compiler does not
   predefine this macro.  */
#ifndef __CHAR_UNSIGNED__
/* # undef __CHAR_UNSIGNED__ */
#endif

/* Define to empty if `const' does not conform to ANSI C. */
/* #undef const */

/* Define to `__inline__' or `__inline' if that's what the C compiler
   calls it, or to nothing if 'inline' is not supported under any name.  */
#ifndef __cplusplus
/* #undef inline */
#endif

/* Define to `unsigned int' if <sys/types.h> does not define. */
/* #undef size_t */

/* Define to the size of the c-stack for new threads */
#define PIKE_THREAD_C_STACK_SIZE (1024 * 1024)

/* NT stuff */
/* #undef HAVE_GETSYSTEMTIMEASFILETIME */
/* #undef HAVE_LOADLIBRARY */
/* #undef HAVE_FREELIBRARY */
/* #undef HAVE_GETPROCADDRESS */
#define DL_EXPORT /**/
/* #undef USE_MY_WIN32_DLOPEN */

/* CygWin kludge. */
#if defined(HAVE_UNISTD_H) && defined(HAVE_WINDOWS_H)
/* #undef HAVE_WINDOWS_H */
/* #undef HAVE_WINBASE_H */
/* #undef HAVE_WINSOCK_H */
/* #undef HAVE_WINSOCK2_H */
/* #undef HAVE_FD_FLOCK */
#endif /* HAVE_SYS_UNISTD_H && HAVE_WINDOWS_H */

/* How to set a socket non-blocking */
/* #undef USE_IOCTL_FIONBIO */
/* #undef USE_IOCTLSOCKET_FIONBIO */
/* #undef USE_FCNTL_O_NDELAY */
/* #undef USE_FCNTL_FNDELAY */
#define USE_FCNTL_O_NONBLOCK 1

/* How well is OOB TCP working?
 * -1 = unknown
 *  0 = doesn't seem to be working at all
 *  1 = very limited functionality
 *  2 = should be working as long as you are cautious
 *  3 = works excellently
 */
#define PIKE_OOB_WORKS 0

/* dlmalloc has mallinfo. */
#if defined(USE_DL_MALLOC) && !defined(HAVE_MALLINFO)
#define HAVE_MALLINFO 1

#if defined (HAVE_MALLOC_H) && defined (HAVE_STRUCT_MALLINFO)
#include <malloc.h>
#else /* HAVE_MALLOC_H && HAVE_STRUCT_MALLINFO */

#ifndef MALLINFO_FIELD_TYPE
#define MALLINFO_FIELD_TYPE size_t
#endif  /* MALLINFO_FIELD_TYPE */

#ifdef HAVE_STDDEF_H
/* Needed for size_t. */
#include <stddef.h>
#endif

/* dlmalloc definition of struct mallinfo. */
struct mallinfo {
  MALLINFO_FIELD_TYPE arena;    /* non-mmapped space allocated from system */
  MALLINFO_FIELD_TYPE ordblks;  /* number of free chunks */
  MALLINFO_FIELD_TYPE smblks;   /* always 0 */
  MALLINFO_FIELD_TYPE hblks;    /* always 0 */
  MALLINFO_FIELD_TYPE hblkhd;   /* space in mmapped regions */
  MALLINFO_FIELD_TYPE usmblks;  /* maximum total allocated space */
  MALLINFO_FIELD_TYPE fsmblks;  /* always 0 */
  MALLINFO_FIELD_TYPE uordblks; /* total allocated space */
  MALLINFO_FIELD_TYPE fordblks; /* total free space */
  MALLINFO_FIELD_TYPE keepcost; /* releasable (via malloc_trim) space */
};

#endif /* HAVE_USR_INCLUDE_MALLOC_H */

#endif

#endif /* MACHINE_H */
