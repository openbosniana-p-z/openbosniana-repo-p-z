/* File generated on January 30, 2022 at 05:50:25 PM EST
by getwhitespace <UnicodeData.txt */

#define SPACECASE8							\
       case ' ':case '\t':case '\r':case '\n':case '\v':case '\f':	\
       case 0x85:case 0xa0:
#define SPACECASE16	SPACECASE8 \
case 0x1680:\
case 0x2000:\
case 0x2001:\
case 0x2002:\
case 0x2003:\
case 0x2004:\
case 0x2005:\
case 0x2006:\
case 0x2007:\
case 0x2008:\
case 0x2009:\
case 0x200a:\
case 0x2028:\
case 0x2029:\
case 0x202f:\
case 0x205f:\
case 0x3000:\

