/* Tree transformation code.
 *
 * This file was generated from "/home/hww3/pike-git/src/treeopt.in".
 *
 * Do NOT edit!
 */

case '?':
  if (!CAR(n)) {
    if (!CDR(n)) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""'?'{712}(-{713}, -{714})""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""-{715}""\n");
        }
#endif /* PIKE_DEBUG */
      goto zap_node;
    } else {
      if (CDR(n)->token == ':') {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""'?'{716}(-{717}, ':'{718}(*, 0 = *{720}))""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""0 = *{721}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CDDR(n),
            tmp1 = CDDR(n);
          );
          goto use_tmp1;
        }
      }
    }
  } else if (!CDR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""'?'{722}(0 = *{723}, -{724})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""0 = *{725}""\n");
      }
#endif /* PIKE_DEBUG */
    goto use_car;
  } else {
    if (CAR(n)->token == F_APPLY) {
      if (!CAAR(n)) {
      } else {
        if (CAAR(n)->token == F_CONSTANT) {
          if ((TYPEOF(CAAR(n)->u.sval) == T_FUNCTION) &&
              (SUBTYPEOF(CAAR(n)->u.sval) == FUNCTION_BUILTIN) &&
              (CAAR(n)->u.sval.u.efun->function == f_not)) {
            if (!CDR(n)) {
            } else {
              if (CDR(n)->token == ':') {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""'?'{732}(F_APPLY{733}(F_CONSTANT{734}[TYPEOF(CAAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAAR(n)->u.sval) == FUNCTION_BUILTIN][CAAR(n)->u.sval.u.efun->function == f_not], 0 = *{735}), ':'{736}(1 = *{737}, 2 = *{738}))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""'?'{739}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CDAR(n),
                  ADD_NODE_REF2(CDDR(n),
                  ADD_NODE_REF2(CADR(n),
                    tmp1 = mknode('?', CDAR(n), mknode(':', CDDR(n), CADR(n)));
                  )));
                  goto use_tmp1;
                }
              }
            }
          }
        }
      }
    } else if (CAR(n)->token == F_LAND) {
      if (!CAAR(n)) {
      } else {
        if (!CDAR(n)) {
        } else {
          if ((node_is_false(CDAR(n)))) {
            if (!CDR(n)) {
            } else {
              if (CDR(n)->token == ':') {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""'?'{756}(F_LAND{757}(0 = +{758}, +{759}[node_is_false(CDAR(n))]), ':'{760}(*, 1 = *{762}))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_COMMA_EXPR{763}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CDDR(n),
                    tmp1 = mknode(F_COMMA_EXPR, CAAR(n), CDDR(n));
                  ));
                  goto use_tmp1;
                }
              }
            }
          }
        }
      }
    } else if (CAR(n)->token == F_LOR) {
      if (!CAAR(n)) {
      } else {
        if (!CDAR(n)) {
        } else {
          if ((node_is_true(CDAR(n)))) {
            if (!CDR(n)) {
            } else {
              if (CDR(n)->token == ':') {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""'?'{766}(F_LOR{767}(0 = +{768}, +{769}[node_is_true(CDAR(n))]), ':'{770}(1 = *{771}, *))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_COMMA_EXPR{773}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CADR(n),
                    tmp1 = mknode(F_COMMA_EXPR, CAAR(n), CADR(n));
                  ));
                  goto use_tmp1;
                }
              }
            }
          }
        }
      }
    }
    if (CDR(n)->token == ':') {
      if (!CADR(n)) {
        if (!CDDR(n)) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""'?'{726}(0 = *{727}, ':'{728}(-{729}, -{730}))""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{731}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      } else if (!CDDR(n)) {
      } else {
        if ((CDDR(n) == CADR(n))
#ifdef SHARED_NODES_MK2
          || (CDDR(n) && CADR(n) &&
              ((CDDR(n)->master?CDDR(n)->master:CDDR(n))==
               (CADR(n)->master?CADR(n)->master:CADR(n))))
#endif /* SHARED_NODES_MK2 */
          ) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""'?'{776}(0 = *{777}, ':'{778}(1 = *{779}, $CADR(n)$))""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""F_COMMA_EXPR{780}""\n");
            }
#endif /* PIKE_DEBUG */
          {
            ADD_NODE_REF2(CAR(n),
            ADD_NODE_REF2(CADR(n),
              tmp1 = mknode(F_COMMA_EXPR, CAR(n), CADR(n));
            ));
            goto use_tmp1;
          }
        }
        {
          if (CADR(n)->token == F_COMMA_EXPR) {
            if (!CDDR(n)) {
            } else {
              if ((CDDR(n) == CDADR(n))
#ifdef SHARED_NODES_MK2
                || (CDDR(n) && CDADR(n) &&
                    ((CDDR(n)->master?CDDR(n)->master:CDDR(n))==
                     (CDADR(n)->master?CDADR(n)->master:CDADR(n))))
#endif /* SHARED_NODES_MK2 */
                ) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""'?'{783}(0 = *{784}, ':'{785}(F_COMMA_EXPR{786}(1 = *{787}, 2 = *{788}), $CDADR(n)$))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_COMMA_EXPR{789}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAR(n),
                  ADD_NODE_REF2(CAADR(n),
                  ADD_NODE_REF2(CDADR(n),
                    tmp1 = mknode(F_COMMA_EXPR, mknode('?', CAR(n), mknode(':', CAADR(n), 0)), CDADR(n));
                  )));
                  goto use_tmp1;
                }
              }
              {
                if (CDDR(n)->token == F_COMMA_EXPR) {
                  {
                    if ((CDDDR(n) == CDADR(n))
#ifdef SHARED_NODES_MK2
                      || (CDDDR(n) && CDADR(n) &&
                          ((CDDDR(n)->master?CDDDR(n)->master:CDDDR(n))==
                           (CDADR(n)->master?CDADR(n)->master:CDADR(n))))
#endif /* SHARED_NODES_MK2 */
                      ) {
#ifdef PIKE_DEBUG
                        if (l_flag > 4) {
                          fprintf(stderr, "Match: ""'?'{809}(0 = *{810}, ':'{811}(F_COMMA_EXPR{812}(1 = *{813}, 2 = *{814}), F_COMMA_EXPR{815}(3 = *{816}, $CDADR(n)$)))""\n");
                        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                        if (l_flag > 4) {
                          fprintf(stderr, "=> ""F_COMMA_EXPR{817}""\n");
                        }
#endif /* PIKE_DEBUG */
                      {
                        ADD_NODE_REF2(CAR(n),
                        ADD_NODE_REF2(CAADR(n),
                        ADD_NODE_REF2(CADDR(n),
                        ADD_NODE_REF2(CDADR(n),
                          tmp1 = mknode(F_COMMA_EXPR, mknode('?', CAR(n), mknode(':', CAADR(n), CADDR(n))), CDADR(n));
                        ))));
                        goto use_tmp1;
                      }
                    }
                  }
                }
              }
            }
          }
          if (CDDR(n)->token == F_COMMA_EXPR) {
            {
              if ((CDDDR(n) == CADR(n))
#ifdef SHARED_NODES_MK2
                || (CDDDR(n) && CADR(n) &&
                    ((CDDDR(n)->master?CDDDR(n)->master:CDDDR(n))==
                     (CADR(n)->master?CADR(n)->master:CADR(n))))
#endif /* SHARED_NODES_MK2 */
                ) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""'?'{796}(0 = *{797}, ':'{798}(1 = *{799}, F_COMMA_EXPR{800}(2 = *{801}, $CADR(n)$)))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_COMMA_EXPR{802}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAR(n),
                  ADD_NODE_REF2(CADDR(n),
                  ADD_NODE_REF2(CADR(n),
                    tmp1 = mknode(F_COMMA_EXPR, mknode('?', CAR(n), mknode(':', 0, CADDR(n))), CADR(n));
                  )));
                  goto use_tmp1;
                }
              }
            }
          }
          if (!CDDR(n)) {
          } else {
            if (((pike_types_le(CADR(n)->type, void_type_string) !=
		   pike_types_le(CDDR(n)->type, void_type_string)))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""'?'{824}(*, ':'{826}(0 = +{827}, +{828}[(pike_types_le(CADR(n)->type, void_type_string) !=\n"
              "\t\t   pike_types_le(CDDR(n)->type, void_type_string))]))""\n");
                }
#endif /* PIKE_DEBUG */
              {
                yyerror("The arguments to ?: may not be void.");
              }
            }
          }
        }
      }
    }
    if (( node_is_tossable(CAR(n)) )) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == ':') {
          if (!CADR(n)) {
          } else {
            if (CADR(n)->token == F_RETURN) {
              {
                if ((CAADR(n) == CAR(n))
#ifdef SHARED_NODES_MK2
                  || (CAADR(n) && CAR(n) &&
                      ((CAADR(n)->master?CAADR(n)->master:CAADR(n))==
                       (CAR(n)->master?CAR(n)->master:CAR(n))))
#endif /* SHARED_NODES_MK2 */
                  ) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""'?'{1393}(0 = +{1394}[ node_is_tossable(CAR(n)) ], ':'{1395}(F_RETURN{1396}($CAR(n)$, *), 1 = *{1398}))""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                    struct pike_type *type = CAR(n)->type;
                    struct pike_string *tmpname;
                    int tmpvar;

                    MAKE_CONST_STRING(tmpname, " ");
                    tmpvar = islocal(tmpname);
                    if(tmpvar == -1)
                    {
                      add_ref(mixed_type_string);
                      tmpvar = add_local_name(tmpname, mixed_type_string, 0);
                    }
                    if (tmpvar >= 0) {
                      
                    ADD_NODE_REF2(CDDR(n),
                    ADD_NODE_REF2(CAR(n),
                      tmp1 = mknode('?', mknode(F_ASSIGN, CAR(n), mklocalnode(tmpvar,0)),
                  		mknode(':',mknode(F_RETURN,
                  				  mksoftcastnode(type, mklocalnode(tmpvar,0)),
                  				  0),
                  		       CDDR(n)));
                    ));
                    goto use_tmp1;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    if ((node_is_false(CAR(n)))) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == ':') {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""'?'{750}(+{751}[node_is_false(CAR(n))], ':'{752}(*, 0 = *{754}))""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{755}""\n");
            }
#endif /* PIKE_DEBUG */
          {
            ADD_NODE_REF2(CDDR(n),
              tmp1 = CDDR(n);
            );
            goto use_tmp1;
          }
        }
      }
    }
    if ((node_is_true(CAR(n)))) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == ':') {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""'?'{744}(+{745}[node_is_true(CAR(n))], ':'{746}(0 = *{747}, *))""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{749}""\n");
            }
#endif /* PIKE_DEBUG */
          {
            ADD_NODE_REF2(CADR(n),
              tmp1 = CADR(n);
            );
            goto use_tmp1;
          }
        }
      }
    }
  }
  break;

case F_ADD_EQ:
  if (!CAR(n)) {
  } else if (!CDR(n)) {
  } else {
    if (CDR(n)->token == F_APPLY) {
      if (!CADR(n)) {
      } else {
        if (CADR(n)->token == F_CONSTANT) {
          if ((TYPEOF(CADR(n)->u.sval) == T_FUNCTION) &&
              (SUBTYPEOF(CADR(n)->u.sval) == FUNCTION_BUILTIN) &&
              (CADR(n)->u.sval.u.efun->function == debug_f_aggregate)) {
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "Match: ""F_ADD_EQ{939}(0 = *{940}, F_APPLY{941}(F_CONSTANT{942}[TYPEOF(CADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CADR(n)->u.sval) == FUNCTION_BUILTIN][CADR(n)->u.sval.u.efun->function == debug_f_aggregate], 1 = *{943}))""\n");
              }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "=> ""F_APPEND_ARRAY{944}""\n");
              }
#endif /* PIKE_DEBUG */
            {
              ADD_NODE_REF2(CAR(n),
              ADD_NODE_REF2(CDDR(n),
                tmp1 = mknode(F_APPEND_ARRAY, CAR(n), CDDR(n));
              ));
              goto use_tmp1;
            }
          }
          if ((TYPEOF(CADR(n)->u.sval) == T_FUNCTION) &&
              (SUBTYPEOF(CADR(n)->u.sval) == FUNCTION_BUILTIN) &&
              (CADR(n)->u.sval.u.efun->function == f_aggregate_mapping)) {
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "Match: ""F_ADD_EQ{947}(0 = *{948}, F_APPLY{949}(F_CONSTANT{950}[TYPEOF(CADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CADR(n)->u.sval) == FUNCTION_BUILTIN][CADR(n)->u.sval.u.efun->function == f_aggregate_mapping], 1 = *{951}))""\n");
              }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "=> ""F_APPEND_MAPPING{952}""\n");
              }
#endif /* PIKE_DEBUG */
            {
              ADD_NODE_REF2(CAR(n),
              ADD_NODE_REF2(CDDR(n),
                tmp1 = mknode(F_APPEND_MAPPING, CAR(n), CDDR(n));
              ));
              goto use_tmp1;
            }
          }
        }
      }
    } else if (CDR(n)->token == F_CONSTANT) {
      if ((TYPEOF(CDR(n)->u.sval) == T_INT) &&
          ((CDR(n)->u.sval.u.integer) == -1)) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_ADD_EQ{917}(0 = *{918}, 1 = F_CONSTANT{919}[TYPEOF(CDR(n)->u.sval) == T_INT][(CDR(n)->u.sval.u.integer) == -1])""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_DEC{920}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAR(n),
            tmp1 = mknode(F_DEC, CAR(n), 0);
          );
          goto use_tmp1;
        }
      }
      if ((TYPEOF(CDR(n)->u.sval) == T_INT) &&
          ((CDR(n)->u.sval.u.integer) == 1)) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_ADD_EQ{911}(0 = *{912}, 1 = F_CONSTANT{913}[TYPEOF(CDR(n)->u.sval) == T_INT][(CDR(n)->u.sval.u.integer) == 1])""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_INC{914}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAR(n),
            tmp1 = mknode(F_INC, CAR(n), 0);
          );
          goto use_tmp1;
        }
      }
    }
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_ADD_EQ{1399}(0 = +{1400}, 1 = *{1401})""\n");
      }
#endif /* PIKE_DEBUG */
    {
      struct pike_type *type = CAR(n)->type;
      int oper = ((CAR(n)->tree_info&(OPT_SIDE_EFFECT|OPT_ASSIGNMENT)) ||
    	      depend_p(CAR(n), CDR(n))) ? F_ASSIGN_SELF : F_ASSIGN;
      
      ADD_NODE_REF2(CAR(n),
      ADD_NODE_REF2(CAR(n),
      ADD_NODE_REF2(CDR(n),
        tmp1 = mknode( oper, mksoftcastnode(type,mkopernode( "`+", CAR(n), CDR(n) )), CAR(n) );
      )));
      goto use_tmp1;
    }
    if (( CAR(n)->token != F_AUTO_MAP_MARKER )) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == F_CONSTANT) {
          if ((TYPEOF(CDR(n)->u.sval) == T_INT) &&
              (!(CDR(n)->u.sval.u.integer))) {
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "Match: ""F_ADD_EQ{907}(0 = +{908}[ CAR(n)->token != F_AUTO_MAP_MARKER ], 1 = F_CONSTANT{909}[TYPEOF(CDR(n)->u.sval) == T_INT][!(CDR(n)->u.sval.u.integer)])""\n");
              }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "=> ""0 = *{910}""\n");
              }
#endif /* PIKE_DEBUG */
            goto use_car;
          }
        }
      }
    }
  }
  break;

case F_AND_EQ:
  if (!CAR(n)) {
  } else {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_AND_EQ{1405}(0 = +{1406}, 1 = *{1407})""\n");
      }
#endif /* PIKE_DEBUG */
    {
      struct pike_type *type = CAR(n)->type;
      int oper = ((CAR(n)->tree_info&(OPT_SIDE_EFFECT|OPT_ASSIGNMENT)) ||
    	      depend_p(CAR(n), CDR(n))) ? F_ASSIGN_SELF : F_ASSIGN;
      
      ADD_NODE_REF2(CAR(n),
      ADD_NODE_REF2(CAR(n),
      ADD_NODE_REF2(CDR(n),
        tmp1 = mknode( oper, mksoftcastnode(type,mkopernode( "`&", CAR(n), CDR(n) )), CAR(n) );
      )));
      goto use_tmp1;
    }
  }
  break;

case F_APPLY:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_APPLY{6}(-{7}, *)""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""F_COMMA_EXPR{9}""\n");
      }
#endif /* PIKE_DEBUG */
    {
      ADD_NODE_REF2(CDR(n),
        tmp1 = mknode(F_COMMA_EXPR, mknode(F_POP_VALUE, CDR(n), 0), mkintnode(0));
      );
      goto use_tmp1;
    }
  } else {
    if (CAR(n)->token == F_CONSTANT) {
      if ((TYPEOF(CAR(n)->u.sval) == T_FUNCTION) &&
          (SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN) &&
          (CAR(n)->u.sval.u.efun->function == f_add)) {
        if (!CDR(n)) {
        } else {
          if (CDR(n)->token == F_ARG_LIST) {
            if (!CADR(n)) {
            } else {
              if (CADR(n)->token == F_APPLY) {
                if (!CAADR(n)) {
                } else {
                  if (CAADR(n)->token == F_CONSTANT) {
                    if ((TYPEOF(CAADR(n)->u.sval) == T_FUNCTION) &&
                        (SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN) &&
                        (CAADR(n)->u.sval.u.efun->function == f_add)) {
#ifdef PIKE_DEBUG
                        if (l_flag > 4) {
                          fprintf(stderr, "Match: ""F_APPLY{114}(0 = F_CONSTANT{115}[TYPEOF(CAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->function == f_add], 2 = F_ARG_LIST{116}(F_APPLY{117}(F_CONSTANT{118}[TYPEOF(CAADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN][CAADR(n)->u.sval.u.efun->function == f_add], 1 = *{119}), 3 = *{120}))""\n");
                        }
#endif /* PIKE_DEBUG */
                      {
                          node *arglist = CDR(n);
                          ADD_NODE_REF2(CDADR(n),
                          ADD_NODE_REF2(CDDR(n),
                      		  _CDR(n) = mknode(F_ARG_LIST, CDADR(n), CDDR(n))));
                          _CDR(n)->parent = NULL;
                          fix_type_field(_CDR(n));
                          free_node(arglist);
#ifdef PIKE_DEBUG
                          if (l_flag > 4) {
                            fprintf(stderr, "Result:    ");
                            print_tree(n);
                          }
#endif /* PIKE_DEBUG */
                          continue;
                        }
                    }
                  }
                }
              }
            }
          }
        }
      }
      if ((TYPEOF(CAR(n)->u.sval) == T_FUNCTION) &&
          (SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN) &&
          (CAR(n)->u.sval.u.efun->function == f_eq)) {
        if (!CDR(n)) {
        } else {
          if (CDR(n)->token == F_ARG_LIST) {
            if (!CADR(n)) {
            } else {
              if (CADR(n)->token == F_APPLY) {
                if (!CAADR(n)) {
                } else {
                  if (CAADR(n)->token == F_CONSTANT) {
                    if ((TYPEOF(CAADR(n)->u.sval) == T_FUNCTION) &&
                        (SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN) &&
                        (CAADR(n)->u.sval.u.efun->function == f_search)) {
                      if (!CDADR(n)) {
                      } else {
                        if (CDADR(n)->token == F_ARG_LIST) {
                          if (!CADADR(n)) {
                          } else {
                            if (CADADR(n)->token == F_APPLY) {
                              if (!CAADADR(n)) {
                              } else {
                                if (CAADADR(n)->token == F_CONSTANT) {
                                  if ((TYPEOF(CAADADR(n)->u.sval) == T_FUNCTION) &&
                                      (SUBTYPEOF(CAADADR(n)->u.sval) == FUNCTION_BUILTIN) &&
                                      (CAADADR(n)->u.sval.u.efun->function == f_indices)) {
                                    if (!CDADADR(n)) {
                                    } else {
                                      if ((pike_types_le(CDADADR(n)->type, mapping_type_string))) {
                                        if (!CDDR(n)) {
                                        } else {
                                          if (CDDR(n)->token == F_CONSTANT) {
                                            if ((TYPEOF(CDDR(n)->u.sval) == T_INT) &&
                                                (CDDR(n)->u.sval.u.integer == -1)) {
#ifdef PIKE_DEBUG
                                                if (l_flag > 4) {
                                                  fprintf(stderr, "Match: ""F_APPLY{68}(F_CONSTANT{69}[TYPEOF(CAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->function == f_eq], F_ARG_LIST{70}(F_APPLY{71}(F_CONSTANT{72}[TYPEOF(CAADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN][CAADR(n)->u.sval.u.efun->function == f_search], F_ARG_LIST{73}(F_APPLY{74}(F_CONSTANT{75}[TYPEOF(CAADADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAADADR(n)->u.sval) == FUNCTION_BUILTIN][CAADADR(n)->u.sval.u.efun->function == f_indices], 0 = +{76}[pike_types_le(CDADADR(n)->type, mapping_type_string)]), 1 = *{77})), F_CONSTANT{78}[TYPEOF(CDDR(n)->u.sval) == T_INT][CDDR(n)->u.sval.u.integer == -1]))""\n");
                                                }
#endif /* PIKE_DEBUG */
                                              {
                                                
                                                ADD_NODE_REF2(CDDADR(n),
                                                ADD_NODE_REF2(CDADADR(n),
                                                  tmp1 = mkefuncallnode("zero_type",mknode(F_ARG_LIST, CDADADR(n), CDDADR(n)));
                                                ));
                                                goto use_tmp1;
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      if ((TYPEOF(CAR(n)->u.sval) == T_FUNCTION) &&
          (SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN) &&
          (CAR(n)->u.sval.u.efun->function == f_ge)) {
        if (!CDR(n)) {
        } else {
          if (CDR(n)->token == F_ARG_LIST) {
            if (!CADR(n)) {
            } else {
              if (CADR(n)->token == F_APPLY) {
                if (!CAADR(n)) {
                } else {
                  if (CAADR(n)->token == F_CONSTANT) {
                    if ((TYPEOF(CAADR(n)->u.sval) == T_FUNCTION) &&
                        (SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN) &&
                        (CAADR(n)->u.sval.u.efun->function == f_search)) {
                      if (!CDADR(n)) {
                      } else {
                        if (CDADR(n)->token == F_ARG_LIST) {
                          if (!CADADR(n)) {
                          } else {
                            if (CADADR(n)->token == F_APPLY) {
                              if (!CAADADR(n)) {
                              } else {
                                if (CAADADR(n)->token == F_CONSTANT) {
                                  if ((TYPEOF(CAADADR(n)->u.sval) == T_FUNCTION) &&
                                      (SUBTYPEOF(CAADADR(n)->u.sval) == FUNCTION_BUILTIN) &&
                                      (CAADADR(n)->u.sval.u.efun->function == f_indices)) {
                                    if (!CDADADR(n)) {
                                    } else {
                                      if ((pike_types_le(CDADADR(n)->type, mapping_type_string))) {
                                        if (!CDDR(n)) {
                                        } else {
                                          if (CDDR(n)->token == F_CONSTANT) {
                                            if ((TYPEOF(CDDR(n)->u.sval) == T_INT) &&
                                                (!CDDR(n)->u.sval.u.integer)) {
#ifdef PIKE_DEBUG
                                                if (l_flag > 4) {
                                                  fprintf(stderr, "Match: ""F_APPLY{79}(F_CONSTANT{80}[TYPEOF(CAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->function == f_ge], F_ARG_LIST{81}(F_APPLY{82}(F_CONSTANT{83}[TYPEOF(CAADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN][CAADR(n)->u.sval.u.efun->function == f_search], F_ARG_LIST{84}(F_APPLY{85}(F_CONSTANT{86}[TYPEOF(CAADADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAADADR(n)->u.sval) == FUNCTION_BUILTIN][CAADADR(n)->u.sval.u.efun->function == f_indices], 0 = +{87}[pike_types_le(CDADADR(n)->type, mapping_type_string)]), 1 = *{88})), F_CONSTANT{89}[TYPEOF(CDDR(n)->u.sval) == T_INT][!CDDR(n)->u.sval.u.integer]))""\n");
                                                }
#endif /* PIKE_DEBUG */
                                              {
                                                
                                                ADD_NODE_REF2(CDDADR(n),
                                                ADD_NODE_REF2(CDADADR(n),
                                                  tmp1 = mknode(F_NOT,mkefuncallnode("zero_type",mknode(F_ARG_LIST, CDADADR(n), CDDADR(n))),0);
                                                ));
                                                goto use_tmp1;
                                              }
                                            }
                                            if ((TYPEOF(CDDR(n)->u.sval) == T_INT) &&
                                                (CDDR(n)->u.sval.u.integer == -1)) {
#ifdef PIKE_DEBUG
                                                if (l_flag > 4) {
                                                  fprintf(stderr, "Match: ""F_APPLY{90}(F_CONSTANT{91}[TYPEOF(CAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->function == f_ge], F_ARG_LIST{92}(F_APPLY{93}(F_CONSTANT{94}[TYPEOF(CAADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN][CAADR(n)->u.sval.u.efun->function == f_search], F_ARG_LIST{95}(F_APPLY{96}(F_CONSTANT{97}[TYPEOF(CAADADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAADADR(n)->u.sval) == FUNCTION_BUILTIN][CAADADR(n)->u.sval.u.efun->function == f_indices], 0 = +{98}[pike_types_le(CDADADR(n)->type, mapping_type_string)]), 1 = *{99})), F_CONSTANT{100}[TYPEOF(CDDR(n)->u.sval) == T_INT][CDDR(n)->u.sval.u.integer == -1]))""\n");
                                                }
#endif /* PIKE_DEBUG */
                                              {
                                                
                                                ADD_NODE_REF2(CDDADR(n),
                                                ADD_NODE_REF2(CDADADR(n),
                                                  tmp1 = mknode(F_NOT,mkefuncallnode("zero_type",mknode(F_ARG_LIST, CDADADR(n), CDDADR(n))),0);
                                                ));
                                                goto use_tmp1;
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      if ((TYPEOF(CAR(n)->u.sval) == T_FUNCTION) &&
          (SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN) &&
          (CAR(n)->u.sval.u.efun->function == f_lt)) {
        if (!CDR(n)) {
        } else {
          if (CDR(n)->token == F_ARG_LIST) {
            if (!CADR(n)) {
            } else {
              if (CADR(n)->token == F_APPLY) {
                if (!CAADR(n)) {
                } else {
                  if (CAADR(n)->token == F_CONSTANT) {
                    if ((TYPEOF(CAADR(n)->u.sval) == T_FUNCTION) &&
                        (SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN) &&
                        (CAADR(n)->u.sval.u.efun->function == f_search)) {
                      if (!CDADR(n)) {
                      } else {
                        if (CDADR(n)->token == F_ARG_LIST) {
                          if (!CADADR(n)) {
                          } else {
                            if (CADADR(n)->token == F_APPLY) {
                              if (!CAADADR(n)) {
                              } else {
                                if (CAADADR(n)->token == F_CONSTANT) {
                                  if ((TYPEOF(CAADADR(n)->u.sval) == T_FUNCTION) &&
                                      (SUBTYPEOF(CAADADR(n)->u.sval) == FUNCTION_BUILTIN) &&
                                      (CAADADR(n)->u.sval.u.efun->function == f_indices)) {
                                    if (!CDADADR(n)) {
                                    } else {
                                      if ((pike_types_le(CDADADR(n)->type, mapping_type_string))) {
                                        if (!CDDR(n)) {
                                        } else {
                                          if (CDDR(n)->token == F_CONSTANT) {
                                            if ((TYPEOF(CDDR(n)->u.sval) == T_INT) &&
                                                (!CDDR(n)->u.sval.u.integer)) {
#ifdef PIKE_DEBUG
                                                if (l_flag > 4) {
                                                  fprintf(stderr, "Match: ""F_APPLY{57}(F_CONSTANT{58}[TYPEOF(CAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->function == f_lt], F_ARG_LIST{59}(F_APPLY{60}(F_CONSTANT{61}[TYPEOF(CAADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN][CAADR(n)->u.sval.u.efun->function == f_search], F_ARG_LIST{62}(F_APPLY{63}(F_CONSTANT{64}[TYPEOF(CAADADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAADADR(n)->u.sval) == FUNCTION_BUILTIN][CAADADR(n)->u.sval.u.efun->function == f_indices], 0 = +{65}[pike_types_le(CDADADR(n)->type, mapping_type_string)]), 1 = *{66})), F_CONSTANT{67}[TYPEOF(CDDR(n)->u.sval) == T_INT][!CDDR(n)->u.sval.u.integer]))""\n");
                                                }
#endif /* PIKE_DEBUG */
                                              {
                                                
                                                ADD_NODE_REF2(CDDADR(n),
                                                ADD_NODE_REF2(CDADADR(n),
                                                  tmp1 = mkefuncallnode("zero_type",mknode(F_ARG_LIST, CDADADR(n), CDDADR(n)));
                                                ));
                                                goto use_tmp1;
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      if ((TYPEOF(CAR(n)->u.sval) == T_FUNCTION) &&
          (SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN) &&
          (CAR(n)->u.sval.u.efun->function == f_minus)) {
        if (!CDR(n)) {
        } else {
          if (CDR(n)->token == F_ARG_LIST) {
            if (!CADR(n)) {
            } else {
              if (CADR(n)->token == F_APPLY) {
                if (!CAADR(n)) {
                } else {
                  if (CAADR(n)->token == F_CONSTANT) {
                    if ((TYPEOF(CAADR(n)->u.sval) == T_FUNCTION) &&
                        (SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN) &&
                        (CAADR(n)->u.sval.u.efun->function == f_minus)) {
                      if (!CDADR(n)) {
                      } else {
                        if (CDADR(n)->token == F_ARG_LIST) {
                          if (!CADADR(n)) {
                          } else {
                            if (!CDDADR(n)) {
                            } else {
#ifdef PIKE_DEBUG
                                if (l_flag > 4) {
                                  fprintf(stderr, "Match: ""F_APPLY{121}(0 = F_CONSTANT{122}[TYPEOF(CAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->function == f_minus], 2 = F_ARG_LIST{123}(F_APPLY{124}(F_CONSTANT{125}[TYPEOF(CAADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN][CAADR(n)->u.sval.u.efun->function == f_minus], 1 = F_ARG_LIST{126}(+{127}, +{128})), 3 = *{129}))""\n");
                                }
#endif /* PIKE_DEBUG */
                              {
                                  node *arglist = CDR(n);
                                  ADD_NODE_REF2(CDADR(n),
                                  ADD_NODE_REF2(CDDR(n),
                              		  _CDR(n) = mknode(F_ARG_LIST, CDADR(n), CDDR(n))));
                                  _CDR(n)->parent = NULL;
                                  fix_type_field(_CDR(n));
                                  free_node(arglist);
#ifdef PIKE_DEBUG
                                  if (l_flag > 4) {
                                    fprintf(stderr, "Result:    ");
                                    print_tree(n);
                                  }
#endif /* PIKE_DEBUG */
                                  continue;
                                }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      if ((TYPEOF(CAR(n)->u.sval) == T_FUNCTION) &&
          (SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN) &&
          (CAR(n)->u.sval.u.efun->function == f_multiply)) {
        if (!CDR(n)) {
        } else {
          if (CDR(n)->token == F_ARG_LIST) {
            if (!CADR(n)) {
            } else {
              if (CADR(n)->token == F_APPLY) {
                if (!CAADR(n)) {
                } else {
                  if (CAADR(n)->token == F_CONSTANT) {
                    if ((TYPEOF(CAADR(n)->u.sval) == T_FUNCTION) &&
                        (SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN) &&
                        (CAADR(n)->u.sval.u.efun->function == f_multiply)) {
#ifdef PIKE_DEBUG
                        if (l_flag > 4) {
                          fprintf(stderr, "Match: ""F_APPLY{130}(0 = F_CONSTANT{131}[TYPEOF(CAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->function == f_multiply], 2 = F_ARG_LIST{132}(F_APPLY{133}(F_CONSTANT{134}[TYPEOF(CAADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN][CAADR(n)->u.sval.u.efun->function == f_multiply], 1 = *{135}), 3 = *{136}))""\n");
                        }
#endif /* PIKE_DEBUG */
                      {
                          node *arglist = CDR(n);
                          ADD_NODE_REF2(CDADR(n),
                          ADD_NODE_REF2(CDDR(n),
                      		  _CDR(n) = mknode(F_ARG_LIST, CDADR(n), CDDR(n))));
                          _CDR(n)->parent = NULL;
                          fix_type_field(_CDR(n));
                          free_node(arglist);
#ifdef PIKE_DEBUG
                          if (l_flag > 4) {
                            fprintf(stderr, "Result:    ");
                            print_tree(n);
                          }
#endif /* PIKE_DEBUG */
                          continue;
                        }
                    }
                  }
                }
              }
            }
          }
        }
      }
      if ((TYPEOF(CAR(n)->u.sval) == T_FUNCTION) &&
          (SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN) &&
          (CAR(n)->u.sval.u.efun->function == f_not)) {
        if (!CDR(n)) {
        } else {
          if (CDR(n)->token == F_ARG_LIST) {
            if (!CADR(n)) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_APPLY{829}(F_CONSTANT{830}[TYPEOF(CAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->function == f_not], F_ARG_LIST{831}(-{832}, *))""\n");
                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "=> ""1 = T_INT{834}""\n");
                }
#endif /* PIKE_DEBUG */
              {
                tmp1 = mkintnode(1);
                goto use_tmp1;
              }
            } else {
              if (CADR(n)->token == F_APPLY) {
                if (!CAADR(n)) {
                } else {
                  if (CAADR(n)->token == F_CONSTANT) {
                    if ((TYPEOF(CAADR(n)->u.sval) == T_FUNCTION) &&
                        (SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN) &&
                        (CAADR(n)->u.sval.u.efun->function == f_eq)) {
                      if (!CDADR(n)) {
                      } else {
                        if (CDADR(n)->token == F_ARG_LIST) {
#ifdef PIKE_DEBUG
                            if (l_flag > 4) {
                              fprintf(stderr, "Match: ""F_APPLY{883}(F_CONSTANT{884}[TYPEOF(CAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->function == f_not], F_ARG_LIST{885}(F_APPLY{886}(F_CONSTANT{887}[TYPEOF(CAADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN][CAADR(n)->u.sval.u.efun->function == f_eq], F_ARG_LIST{888}(0 = *{889}, 1 = *{890})), *))""\n");
                            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                            if (l_flag > 4) {
                              fprintf(stderr, "=> ""F_NE{892}""\n");
                            }
#endif /* PIKE_DEBUG */
                          {
                            ADD_NODE_REF2(CADADR(n),
                            ADD_NODE_REF2(CDDADR(n),
                              tmp1 = mknode(F_NE, CADADR(n), CDDADR(n));
                            ));
                            goto use_tmp1;
                          }
                        }
                      }
                    }
                    if ((TYPEOF(CAADR(n)->u.sval) == T_FUNCTION) &&
                        (SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN) &&
                        (CAADR(n)->u.sval.u.efun->function == f_ge)) {
                      if (!CDADR(n)) {
                      } else {
                        if (CDADR(n)->token == F_ARG_LIST) {
                          if (!CADADR(n)) {
                          } else {
                            if ((pike_types_le(CADADR(n)->type, int_type_string))) {
                              if (!CDDADR(n)) {
                              } else {
                                if ((pike_types_le(CDDADR(n)->type, int_type_string))) {
#ifdef PIKE_DEBUG
                                    if (l_flag > 4) {
                                      fprintf(stderr, "Match: ""F_APPLY{871}(F_CONSTANT{872}[TYPEOF(CAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->function == f_not], F_ARG_LIST{873}(F_APPLY{874}(F_CONSTANT{875}[TYPEOF(CAADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN][CAADR(n)->u.sval.u.efun->function == f_ge], F_ARG_LIST{876}(0 = +{877}[pike_types_le(CADADR(n)->type, int_type_string)], 1 = +{878}[pike_types_le(CDDADR(n)->type, int_type_string)])), *))""\n");
                                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                                    if (l_flag > 4) {
                                      fprintf(stderr, "=> ""F_LT{880}""\n");
                                    }
#endif /* PIKE_DEBUG */
                                  {
                                    ADD_NODE_REF2(CADADR(n),
                                    ADD_NODE_REF2(CDDADR(n),
                                      tmp1 = mknode(F_LT, CADADR(n), CDDADR(n));
                                    ));
                                    goto use_tmp1;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                    if ((TYPEOF(CAADR(n)->u.sval) == T_FUNCTION) &&
                        (SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN) &&
                        (CAADR(n)->u.sval.u.efun->function == f_gt)) {
                      if (!CDADR(n)) {
                      } else {
                        if (CDADR(n)->token == F_ARG_LIST) {
                          if (!CADADR(n)) {
                          } else {
                            if ((pike_types_le(CADADR(n)->type, int_type_string))) {
                              if (!CDDADR(n)) {
                              } else {
                                if ((pike_types_le(CDDADR(n)->type, int_type_string))) {
#ifdef PIKE_DEBUG
                                    if (l_flag > 4) {
                                      fprintf(stderr, "Match: ""F_APPLY{847}(F_CONSTANT{848}[TYPEOF(CAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->function == f_not], F_ARG_LIST{849}(F_APPLY{850}(F_CONSTANT{851}[TYPEOF(CAADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN][CAADR(n)->u.sval.u.efun->function == f_gt], F_ARG_LIST{852}(0 = +{853}[pike_types_le(CADADR(n)->type, int_type_string)], 1 = +{854}[pike_types_le(CDDADR(n)->type, int_type_string)])), *))""\n");
                                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                                    if (l_flag > 4) {
                                      fprintf(stderr, "=> ""F_LE{856}""\n");
                                    }
#endif /* PIKE_DEBUG */
                                  {
                                    ADD_NODE_REF2(CADADR(n),
                                    ADD_NODE_REF2(CDDADR(n),
                                      tmp1 = mknode(F_LE, CADADR(n), CDDADR(n));
                                    ));
                                    goto use_tmp1;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                    if ((TYPEOF(CAADR(n)->u.sval) == T_FUNCTION) &&
                        (SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN) &&
                        (CAADR(n)->u.sval.u.efun->function == f_le)) {
                      if (!CDADR(n)) {
                      } else {
                        if (CDADR(n)->token == F_ARG_LIST) {
                          if (!CADADR(n)) {
                          } else {
                            if ((pike_types_le(CADADR(n)->type, int_type_string))) {
                              if (!CDDADR(n)) {
                              } else {
                                if ((pike_types_le(CDDADR(n)->type, int_type_string))) {
#ifdef PIKE_DEBUG
                                    if (l_flag > 4) {
                                      fprintf(stderr, "Match: ""F_APPLY{859}(F_CONSTANT{860}[TYPEOF(CAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->function == f_not], F_ARG_LIST{861}(F_APPLY{862}(F_CONSTANT{863}[TYPEOF(CAADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN][CAADR(n)->u.sval.u.efun->function == f_le], F_ARG_LIST{864}(0 = +{865}[pike_types_le(CADADR(n)->type, int_type_string)], 1 = +{866}[pike_types_le(CDDADR(n)->type, int_type_string)])), *))""\n");
                                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                                    if (l_flag > 4) {
                                      fprintf(stderr, "=> ""F_GT{868}""\n");
                                    }
#endif /* PIKE_DEBUG */
                                  {
                                    ADD_NODE_REF2(CADADR(n),
                                    ADD_NODE_REF2(CDDADR(n),
                                      tmp1 = mknode(F_GT, CADADR(n), CDDADR(n));
                                    ));
                                    goto use_tmp1;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                    if ((TYPEOF(CAADR(n)->u.sval) == T_FUNCTION) &&
                        (SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN) &&
                        (CAADR(n)->u.sval.u.efun->function == f_lt)) {
                      if (!CDADR(n)) {
                      } else {
                        if (CDADR(n)->token == F_ARG_LIST) {
                          if (!CADADR(n)) {
                          } else {
                            if ((pike_types_le(CADADR(n)->type, int_type_string))) {
                              if (!CDDADR(n)) {
                              } else {
                                if ((pike_types_le(CDDADR(n)->type, int_type_string))) {
#ifdef PIKE_DEBUG
                                    if (l_flag > 4) {
                                      fprintf(stderr, "Match: ""F_APPLY{835}(F_CONSTANT{836}[TYPEOF(CAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->function == f_not], F_ARG_LIST{837}(F_APPLY{838}(F_CONSTANT{839}[TYPEOF(CAADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN][CAADR(n)->u.sval.u.efun->function == f_lt], F_ARG_LIST{840}(0 = +{841}[pike_types_le(CADADR(n)->type, int_type_string)], 1 = +{842}[pike_types_le(CDDADR(n)->type, int_type_string)])), *))""\n");
                                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                                    if (l_flag > 4) {
                                      fprintf(stderr, "=> ""F_GE{844}""\n");
                                    }
#endif /* PIKE_DEBUG */
                                  {
                                    ADD_NODE_REF2(CADADR(n),
                                    ADD_NODE_REF2(CDDADR(n),
                                      tmp1 = mknode(F_GE, CADADR(n), CDDADR(n));
                                    ));
                                    goto use_tmp1;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                    if ((TYPEOF(CAADR(n)->u.sval) == T_FUNCTION) &&
                        (SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN) &&
                        (CAADR(n)->u.sval.u.efun->function == f_ne)) {
                      if (!CDADR(n)) {
                      } else {
                        if (CDADR(n)->token == F_ARG_LIST) {
#ifdef PIKE_DEBUG
                            if (l_flag > 4) {
                              fprintf(stderr, "Match: ""F_APPLY{895}(F_CONSTANT{896}[TYPEOF(CAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->function == f_not], F_ARG_LIST{897}(F_APPLY{898}(F_CONSTANT{899}[TYPEOF(CAADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAADR(n)->u.sval) == FUNCTION_BUILTIN][CAADR(n)->u.sval.u.efun->function == f_ne], F_ARG_LIST{900}(0 = *{901}, 1 = *{902})), *))""\n");
                            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                            if (l_flag > 4) {
                              fprintf(stderr, "=> ""F_EQ{904}""\n");
                            }
#endif /* PIKE_DEBUG */
                          {
                            ADD_NODE_REF2(CADADR(n),
                            ADD_NODE_REF2(CDDADR(n),
                              tmp1 = mknode(F_EQ, CADADR(n), CDDADR(n));
                            ));
                            goto use_tmp1;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      if ((TYPEOF(CAR(n)->u.sval) == T_FUNCTION) &&
          (SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN) &&
          (CAR(n)->u.sval.u.efun->function == f_sizeof)) {
        if (!CDR(n)) {
        } else {
          if (CDR(n)->token == F_APPLY) {
            if (!CADR(n)) {
            } else {
              if (CADR(n)->token == F_CONSTANT) {
                if ((TYPEOF(CADR(n)->u.sval) == T_FUNCTION) &&
                    (SUBTYPEOF(CADR(n)->u.sval) == FUNCTION_BUILTIN) &&
                    (CADR(n)->u.sval.u.efun->function == f_multiply)) {
                  if (!CDDR(n)) {
                  } else {
                    if (CDDR(n)->token == F_ARG_LIST) {
                      if (!CADDR(n)) {
                      } else {
                        if ((!match_types(object_type_string, CADDR(n)->type))) {
                          if (!CDDDR(n)) {
                          } else {
                            if ((pike_types_le(CDDDR(n)->type, int_type_string))) {
#ifdef PIKE_DEBUG
                                if (l_flag > 4) {
                                  fprintf(stderr, "Match: ""F_APPLY{43}(0 = F_CONSTANT{44}[TYPEOF(CAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->function == f_sizeof], F_APPLY{45}(1 = F_CONSTANT{46}[TYPEOF(CADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CADR(n)->u.sval) == FUNCTION_BUILTIN][CADR(n)->u.sval.u.efun->function == f_multiply], F_ARG_LIST{47}(2 = +{48}[!match_types(object_type_string, CADDR(n)->type)], 3 = +{49}[pike_types_le(CDDDR(n)->type, int_type_string)])))""\n");
                                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                                if (l_flag > 4) {
                                  fprintf(stderr, "=> ""F_APPLY{50}""\n");
                                }
#endif /* PIKE_DEBUG */
                              {
                                ADD_NODE_REF2(CADR(n),
                                ADD_NODE_REF2(CAR(n),
                                ADD_NODE_REF2(CADDR(n),
                                ADD_NODE_REF2(CDDDR(n),
                                  tmp1 = mknode(F_APPLY, CADR(n), mknode(F_ARG_LIST, mknode(F_APPLY, CAR(n), CADDR(n)), CDDDR(n)));
                                ))));
                                goto use_tmp1;
                              }
                            }
                          }
                        }
                        if ((pike_types_le(CADDR(n)->type, int_type_string))) {
                          if (!CDDDR(n)) {
                          } else {
                            if ((!match_types(object_type_string, CDDDR(n)->type))) {
#ifdef PIKE_DEBUG
                                if (l_flag > 4) {
                                  fprintf(stderr, "Match: ""F_APPLY{29}(0 = F_CONSTANT{30}[TYPEOF(CAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->function == f_sizeof], F_APPLY{31}(1 = F_CONSTANT{32}[TYPEOF(CADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CADR(n)->u.sval) == FUNCTION_BUILTIN][CADR(n)->u.sval.u.efun->function == f_multiply], F_ARG_LIST{33}(2 = +{34}[pike_types_le(CADDR(n)->type, int_type_string)], 3 = +{35}[!match_types(object_type_string, CDDDR(n)->type)])))""\n");
                                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                                if (l_flag > 4) {
                                  fprintf(stderr, "=> ""F_APPLY{36}""\n");
                                }
#endif /* PIKE_DEBUG */
                              {
                                ADD_NODE_REF2(CADR(n),
                                ADD_NODE_REF2(CADDR(n),
                                ADD_NODE_REF2(CAR(n),
                                ADD_NODE_REF2(CDDDR(n),
                                  tmp1 = mknode(F_APPLY, CADR(n), mknode(F_ARG_LIST, CADDR(n), mknode(F_APPLY, CAR(n), CDDDR(n))));
                                ))));
                                goto use_tmp1;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      if ((TYPEOF(CAR(n)->u.sval) == T_FUNCTION) &&
          (SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN) &&
          (CAR(n)->u.sval.u.efun->optimize) &&
          ( (tmp1=CAR(n)->u.sval.u.efun->optimize(n)) )) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""0 = F_APPLY{0}(F_CONSTANT{1}[TYPEOF(CAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAR(n)->u.sval) == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->optimize][ (tmp1=CAR(n)->u.sval.u.efun->optimize(n)) ], *)""\n");
          }
#endif /* PIKE_DEBUG */
        {
          goto use_tmp1;
        }
      }
      if ((TYPEOF(CAR(n)->u.sval) == T_PROGRAM) &&
          (CAR(n)->u.sval.u.program->optimize) &&
          ( (tmp1=CAR(n)->u.sval.u.program->optimize(n)) )) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""0 = F_APPLY{3}(F_CONSTANT{4}[TYPEOF(CAR(n)->u.sval) == T_PROGRAM][CAR(n)->u.sval.u.program->optimize][ (tmp1=CAR(n)->u.sval.u.program->optimize(n)) ], *)""\n");
          }
#endif /* PIKE_DEBUG */
        {
          goto use_tmp1;
        }
      }
    }
  }
  break;

case F_ARG_LIST:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_ARG_LIST{488}(-{489}, 0 = *{490})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""0 = *{491}""\n");
      }
#endif /* PIKE_DEBUG */
    goto use_cdr;
  } else if (!CDR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_ARG_LIST{492}(0 = *{493}, -{494})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""0 = *{495}""\n");
      }
#endif /* PIKE_DEBUG */
    goto use_car;
  } else {
    if (CAR(n)->token == F_BREAK) {
      if (!CDR(n)) {
      } else {
        if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_ARG_LIST{514}(0 = F_BREAK{515}, +{516}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{517}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    } else if (CAR(n)->token == F_COMMA_EXPR) {
      if (!CDAR(n)) {
      } else {
        if (CDAR(n)->token == F_BREAK) {
          if (!CDR(n)) {
          } else {
            if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_ARG_LIST{530}(0 = F_COMMA_EXPR{531}(*, F_BREAK{533}), +{534}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "=> ""0 = *{535}""\n");
                }
#endif /* PIKE_DEBUG */
              goto use_car;
            }
          }
        } else if (CDAR(n)->token == F_CONTINUE) {
          if (!CDR(n)) {
          } else {
            if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_ARG_LIST{524}(0 = F_COMMA_EXPR{525}(*, F_CONTINUE{527}), +{528}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "=> ""0 = *{529}""\n");
                }
#endif /* PIKE_DEBUG */
              goto use_car;
            }
          }
        } else if (CDAR(n)->token == F_RETURN) {
          if (!CDR(n)) {
          } else {
            if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_ARG_LIST{518}(0 = F_COMMA_EXPR{519}(*, F_RETURN{521}), +{522}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "=> ""0 = *{523}""\n");
                }
#endif /* PIKE_DEBUG */
              goto use_car;
            }
          }
        }
      }
    } else if (CAR(n)->token == F_CONTINUE) {
      if (!CDR(n)) {
      } else {
        if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_ARG_LIST{510}(0 = F_CONTINUE{511}, +{512}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{513}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    } else if (CAR(n)->token == F_RETURN) {
      if (!CDR(n)) {
      } else {
        if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_ARG_LIST{506}(0 = F_RETURN{507}, +{508}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{509}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    }
    if (CDR(n)->token == F_ARG_LIST) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_ARG_LIST{496}(0 = *{497}, F_ARG_LIST{498}(1 = *{499}, 2 = *{500}))""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""F_ARG_LIST{501}""\n");
        }
#endif /* PIKE_DEBUG */
      {
        ADD_NODE_REF2(CAR(n),
        ADD_NODE_REF2(CADR(n),
        ADD_NODE_REF2(CDDR(n),
          tmp1 = mknode(F_ARG_LIST, mknode(F_ARG_LIST, CAR(n), CADR(n)), CDDR(n));
        )));
        goto use_tmp1;
      }
    }
  }
  break;

case F_ARROW:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_ARROW{977}(-{978}, *)""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""F_COMMA_EXPR{980}""\n");
      }
#endif /* PIKE_DEBUG */
    {
      ADD_NODE_REF2(CDR(n),
        tmp1 = mknode(F_COMMA_EXPR, mknode(F_POP_VALUE, CDR(n), 0), mkintnode(0));
      );
      goto use_tmp1;
    }
  } else {
    if (CAR(n)->token == F_CONSTANT) {
      if ((TYPEOF(CAR(n)->u.sval) == T_OBJECT) &&
          (CAR(n)->u.sval.u.object->prog)) {
        if (!CDR(n)) {
        } else {
          if (CDR(n)->token == F_CONSTANT) {
            if ((TYPEOF(CDR(n)->u.sval) == T_STRING)) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_ARROW{985}(0 = F_CONSTANT{986}[TYPEOF(CAR(n)->u.sval) == T_OBJECT][CAR(n)->u.sval.u.object->prog], 1 = F_CONSTANT{987}[TYPEOF(CDR(n)->u.sval) == T_STRING])""\n");
                }
#endif /* PIKE_DEBUG */
              {
                /*
                if (find_identifier("`->", CAR(n)->u.sval.u.object->prog) == -1) {
                  int i = find_shared_string_identifier(CDR(n)->u.sval.u.string,
              					  CAR(n)->u.sval.u.object->prog);
                  if (i) {
                    struct identifier *id = ID_FROM_INT(CAR(n)->u.sval.u.object->prog, i);
                    if (IDENTIFIER_IS_VARIABLE(id->identifier_flags))
              	goto next_arrow_opt;
                  }
                  ref_push_object(CAR(n)->u.sval.u.object);
                  ref_push_string(CDR(n)->u.sval.u.string);
                  f_index(2);
                  tmp1 = mksvaluenode(sp-1);
                  pop_stack();
                  goto use_tmp1;
                }
               next_arrow_opt:
                ;
                */
              }
            }
          }
        }
      }
    }
  }
  break;

case F_ASSIGN:
  if (!CAR(n)) {
  } else {
    if (CAR(n)->token == F_APPLY) {
      if (!CAAR(n)) {
      } else {
        if (CAAR(n)->token == F_CONSTANT) {
          if ((TYPEOF(CAAR(n)->u.sval) == T_FUNCTION) &&
              (SUBTYPEOF(CAAR(n)->u.sval) == FUNCTION_BUILTIN) &&
              (CAAR(n)->u.sval.u.efun->function == debug_f_aggregate)) {
            if (!CDAR(n)) {
            } else {
              if ((count_args(CDAR(n)) >= 0)) {
                if (!CDR(n)) {
                } else {
                  if (CDR(n)->token == F_ARRAY_LVALUE) {
                    if (!CDDR(n)) {
#ifdef PIKE_DEBUG
                        if (l_flag > 4) {
                          fprintf(stderr, "Match: ""F_ASSIGN{471}(F_APPLY{472}(F_CONSTANT{473}[TYPEOF(CAAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAAR(n)->u.sval) == FUNCTION_BUILTIN][CAAR(n)->u.sval.u.efun->function == debug_f_aggregate], 0 = +{474}[count_args(CDAR(n)) >= 0]), F_ARRAY_LVALUE{475}(1 = *{476}, -{477}))""\n");
                        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                        if (l_flag > 4) {
                          fprintf(stderr, "=> ""F_MULTI_ASSIGN{478}""\n");
                        }
#endif /* PIKE_DEBUG */
                      {
                        ADD_NODE_REF2(CDAR(n),
                        ADD_NODE_REF2(CADR(n),
                          tmp1 = mknode(F_MULTI_ASSIGN, CDAR(n), CADR(n));
                        ));
                        goto use_tmp1;
                      }
                    }
                  }
                }
              }
            }
          }
          if ((TYPEOF(CAAR(n)->u.sval) == T_FUNCTION) &&
              (SUBTYPEOF(CAAR(n)->u.sval) == FUNCTION_BUILTIN) &&
              (CAAR(n)->u.sval.u.efun->function == f_allocate)) {
            if (!CDR(n)) {
            } else {
              if (CDR(n)->token == F_ARRAY_LVALUE) {
                if (!CDDR(n)) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_ASSIGN{481}(0 = F_APPLY{482}(F_CONSTANT{483}[TYPEOF(CAAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAAR(n)->u.sval) == FUNCTION_BUILTIN][CAAR(n)->u.sval.u.efun->function == f_allocate], *), F_ARRAY_LVALUE{485}(1 = *{486}, -{487}))""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                      int cnt = 0;
                      node **arg1 = my_get_arg(&_CDR(CAR(n)), 0);
                      node **arg2 = my_get_arg(&_CDR(CAR(n)), 1);
                      if (arg1) {
                        node *res;
                        node *lvalues = CADR(n);

                        if (arg2 && *arg2) {
                  	ADD_NODE_REF2(*arg2, res = *arg2;);
                        } else {
                  	res = mkintnode(0);
                        }
                        while (lvalues && (lvalues->token == F_LVALUE_LIST)) {
                  	ADD_NODE_REF2(CAR(lvalues),
                  		      res = mknode(F_ASSIGN, res, CAR(lvalues)););
                  	lvalues = CDR(lvalues);
                  	cnt++;
                        }
                        if (lvalues) {
                  	ADD_NODE_REF2(lvalues, res = mknode(F_ASSIGN, res, lvalues););
                  	cnt++;
                        }
                        /* FIXME: Check that the number of arguments actually matches arg1. */
                        
                    tmp1 = res;
                    goto use_tmp1;
                      }
                    }
                }
              }
            }
          }
        }
      }
    }
  }
  break;

case F_CAST:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_CAST{241}(-{242}, *)""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""-{244}""\n");
      }
#endif /* PIKE_DEBUG */
    goto zap_node;
  } else {
    if (CAR(n)->token == F_CAST) {
      if ((CAR(n)->type == n->type)) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""0 = F_CAST{248}(1 = F_CAST{249}[CAR(n)->type == n->type], *)""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""1 = *{253}""\n");
          }
#endif /* PIKE_DEBUG */
        goto use_car;
      }
    } else if (CAR(n)->token == F_CONSTANT) {
      if ((CAR(n)->type == n->type)) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""0 = F_CAST{254}(1 = F_CONSTANT{255}[CAR(n)->type == n->type], *)""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""1 = *{259}""\n");
          }
#endif /* PIKE_DEBUG */
        goto use_car;
      }
    }
    if ((CAR(n)->type == void_type_string)) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_CAST{245}(0 = +{246}[CAR(n)->type == void_type_string], *)""\n");
        }
#endif /* PIKE_DEBUG */
      {
        yywarning("Casting a void expression\n");
        
        ADD_NODE_REF2(CAR(n),
          tmp1 = CAR(n);
        );
        goto use_tmp1;
      }
    }
  }
  break;

case F_COMMA_EXPR:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_COMMA_EXPR{288}(-{289}, 0 = *{290})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""0 = *{291}""\n");
      }
#endif /* PIKE_DEBUG */
    goto use_cdr;
  } else if (!CDR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_COMMA_EXPR{292}(0 = *{293}, -{294})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""0 = *{295}""\n");
      }
#endif /* PIKE_DEBUG */
    goto use_car;
  } else {
    if (CAR(n)->token == F_ARG_LIST) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_COMMA_EXPR{361}(F_ARG_LIST{362}(0 = *{363}, 1 = *{364}), 2 = *{365})""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""F_COMMA_EXPR{366}""\n");
        }
#endif /* PIKE_DEBUG */
      {
        ADD_NODE_REF2(CAAR(n),
        ADD_NODE_REF2(CDAR(n),
        ADD_NODE_REF2(CDR(n),
          tmp1 = mknode(F_COMMA_EXPR, mknode(F_COMMA_EXPR, CAAR(n), CDAR(n)), CDR(n));
        )));
        goto use_tmp1;
      }
    } else if (CAR(n)->token == F_ASSIGN) {
      if (!CDAR(n)) {
      } else {
        if (CDAR(n)->token == F_LOCAL) {
          if (!CDR(n)) {
          } else {
            if (CDR(n)->token == F_COMMA_EXPR) {
              if (!CADR(n)) {
              } else {
                if (CADR(n)->token == F_DEC) {
                  if (!CDADR(n)) {
                    if (!CAADR(n)) {
                    } else {
                      if (CAADR(n)->token == F_LOCAL) {
                        if ((CDAR(n)->u.integer.a == CAADR(n)->u.integer.a) &&
                            (CDAR(n)->u.integer.b == CAADR(n)->u.integer.b)) {
#ifdef PIKE_DEBUG
                            if (l_flag > 4) {
                              fprintf(stderr, "Match: ""F_COMMA_EXPR{453}(F_ASSIGN{454}(0 = *{455}, 1 = F_LOCAL{456}), F_COMMA_EXPR{457}(F_DEC{458}(F_LOCAL{459}[CDAR(n)->u.integer.a == CAADR(n)->u.integer.a][CDAR(n)->u.integer.b == CAADR(n)->u.integer.b], -{460}), 2 = *{461}))""\n");
                            }
#endif /* PIKE_DEBUG */
                          {
                              
                            ADD_NODE_REF2(CDDR(n),
                            ADD_NODE_REF2(CDAR(n),
                            ADD_NODE_REF2(CAAR(n),
                              tmp1 = mknode(F_COMMA_EXPR,
                          		mknode(F_ASSIGN,
                          		       mkefuncallnode("`-",
                          				      mknode(F_ARG_LIST, CAAR(n), mkintnode(1))),
                          		       CDAR(n)),
                          		CDDR(n));
                            )));
                            goto use_tmp1;
                            }
                        }
                      }
                    }
                  }
                } else if (CADR(n)->token == F_INC) {
                  if (!CDADR(n)) {
                    if (!CAADR(n)) {
                    } else {
                      if (CAADR(n)->token == F_LOCAL) {
                        if ((CDAR(n)->u.integer.a == CAADR(n)->u.integer.a) &&
                            (CDAR(n)->u.integer.b == CAADR(n)->u.integer.b)) {
#ifdef PIKE_DEBUG
                            if (l_flag > 4) {
                              fprintf(stderr, "Match: ""F_COMMA_EXPR{462}(F_ASSIGN{463}(0 = *{464}, 1 = F_LOCAL{465}), F_COMMA_EXPR{466}(F_INC{467}(F_LOCAL{468}[CDAR(n)->u.integer.a == CAADR(n)->u.integer.a][CDAR(n)->u.integer.b == CAADR(n)->u.integer.b], -{469}), 2 = *{470}))""\n");
                            }
#endif /* PIKE_DEBUG */
                          {
                              
                            ADD_NODE_REF2(CDDR(n),
                            ADD_NODE_REF2(CDAR(n),
                            ADD_NODE_REF2(CAAR(n),
                              tmp1 = mknode(F_COMMA_EXPR,
                          		mknode(F_ASSIGN,
                          		       mkefuncallnode("`+",
                          				      mknode(F_ARG_LIST, CAAR(n), mkintnode(1))),
                          		       CDAR(n)),
                          		CDDR(n));
                            )));
                            goto use_tmp1;
                            }
                        }
                      }
                    }
                  }
                }
              }
            } else if (CDR(n)->token == F_DEC) {
              if (!CDDR(n)) {
                if (!CADR(n)) {
                } else {
                  if (CADR(n)->token == F_LOCAL) {
                    if (( CDAR(n)->u.integer.a == CADR(n)->u.integer.a ) &&
                        ( CDAR(n)->u.integer.b == CADR(n)->u.integer.b )) {
#ifdef PIKE_DEBUG
                        if (l_flag > 4) {
                          fprintf(stderr, "Match: ""F_COMMA_EXPR{439}(F_ASSIGN{440}(0 = *{441}, 1 = F_LOCAL{442}), F_DEC{443}(F_LOCAL{444}[ CDAR(n)->u.integer.a == CADR(n)->u.integer.a ][ CDAR(n)->u.integer.b == CADR(n)->u.integer.b ], -{445}))""\n");
                        }
#endif /* PIKE_DEBUG */
                      {
                          
                        ADD_NODE_REF2(CDAR(n),
                        ADD_NODE_REF2(CAAR(n),
                          tmp1 = mknode(F_ASSIGN,
                      		mkefuncallnode("`-",
                      			       mknode(F_ARG_LIST, CAAR(n), mkintnode(1))), CDAR(n));
                        ));
                        goto use_tmp1;
                        }
                    }
                  }
                }
              }
            } else if (CDR(n)->token == F_INC) {
              if (!CDDR(n)) {
                if (!CADR(n)) {
                } else {
                  if (CADR(n)->token == F_LOCAL) {
                    if (( CDAR(n)->u.integer.a == CADR(n)->u.integer.a ) &&
                        ( CDAR(n)->u.integer.b == CADR(n)->u.integer.b )) {
#ifdef PIKE_DEBUG
                        if (l_flag > 4) {
                          fprintf(stderr, "Match: ""F_COMMA_EXPR{446}(F_ASSIGN{447}(0 = *{448}, 1 = F_LOCAL{449}), F_INC{450}(F_LOCAL{451}[ CDAR(n)->u.integer.a == CADR(n)->u.integer.a ][ CDAR(n)->u.integer.b == CADR(n)->u.integer.b ], -{452}))""\n");
                        }
#endif /* PIKE_DEBUG */
                      {
                          
                        ADD_NODE_REF2(CDAR(n),
                        ADD_NODE_REF2(CAAR(n),
                          tmp1 = mknode(F_ASSIGN,
                      		mkefuncallnode("`+",
                      			       mknode(F_ARG_LIST, CAAR(n), mkintnode(1))), CDAR(n));
                        ));
                        goto use_tmp1;
                        }
                    }
                  }
                }
              }
            }
          }
        }
        if ((!depend_p(CDAR(n), CDAR(n)))) {
          if (!CDR(n)) {
          } else {
            if (CDR(n)->token == F_COMMA_EXPR) {
              if (!CADR(n)) {
              } else {
                if (CADR(n)->token == F_DEC) {
                  {
                    if ((CAADR(n) == CDAR(n))
#ifdef SHARED_NODES_MK2
                      || (CAADR(n) && CDAR(n) &&
                          ((CAADR(n)->master?CAADR(n)->master:CAADR(n))==
                           (CDAR(n)->master?CDAR(n)->master:CDAR(n))))
#endif /* SHARED_NODES_MK2 */
                      ) {
                      if (!CDADR(n)) {
#ifdef PIKE_DEBUG
                          if (l_flag > 4) {
                            fprintf(stderr, "Match: ""F_COMMA_EXPR{423}(F_ASSIGN{424}(0 = *{425}, 1 = +{426}[!depend_p(CDAR(n), CDAR(n))]), F_COMMA_EXPR{427}(F_DEC{428}($CDAR(n)$, -{429}), 2 = *{430}))""\n");
                          }
#endif /* PIKE_DEBUG */
                        {
                            
                          ADD_NODE_REF2(CDDR(n),
                          ADD_NODE_REF2(CDAR(n),
                          ADD_NODE_REF2(CAAR(n),
                            tmp1 = mknode(F_COMMA_EXPR,
                        		mknode(F_ASSIGN,
                        		       mkefuncallnode("`-",
                        				      mknode(F_ARG_LIST, CAAR(n), mkintnode(1))),
                        		       CDAR(n)),
                        		CDDR(n));
                          )));
                          goto use_tmp1;
                          }
                      }
                    }
                  }
                } else if (CADR(n)->token == F_INC) {
                  {
                    if ((CAADR(n) == CDAR(n))
#ifdef SHARED_NODES_MK2
                      || (CAADR(n) && CDAR(n) &&
                          ((CAADR(n)->master?CAADR(n)->master:CAADR(n))==
                           (CDAR(n)->master?CDAR(n)->master:CDAR(n))))
#endif /* SHARED_NODES_MK2 */
                      ) {
                      if (!CDADR(n)) {
#ifdef PIKE_DEBUG
                          if (l_flag > 4) {
                            fprintf(stderr, "Match: ""F_COMMA_EXPR{431}(F_ASSIGN{432}(0 = *{433}, 1 = +{434}[!depend_p(CDAR(n), CDAR(n))]), F_COMMA_EXPR{435}(F_INC{436}($CDAR(n)$, -{437}), 2 = *{438}))""\n");
                          }
#endif /* PIKE_DEBUG */
                        {
                            
                          ADD_NODE_REF2(CDDR(n),
                          ADD_NODE_REF2(CDAR(n),
                          ADD_NODE_REF2(CAAR(n),
                            tmp1 = mknode(F_COMMA_EXPR,
                        		mknode(F_ASSIGN,
                        		       mkefuncallnode("`+",
                        				      mknode(F_ARG_LIST, CAAR(n), mkintnode(1))),
                        		       CDAR(n)),
                        		CDDR(n));
                          )));
                          goto use_tmp1;
                          }
                      }
                    }
                  }
                }
              }
            } else if (CDR(n)->token == F_DEC) {
              {
                if ((CADR(n) == CDAR(n))
#ifdef SHARED_NODES_MK2
                  || (CADR(n) && CDAR(n) &&
                      ((CADR(n)->master?CADR(n)->master:CADR(n))==
                       (CDAR(n)->master?CDAR(n)->master:CDAR(n))))
#endif /* SHARED_NODES_MK2 */
                  ) {
                  if (!CDDR(n)) {
#ifdef PIKE_DEBUG
                      if (l_flag > 4) {
                        fprintf(stderr, "Match: ""F_COMMA_EXPR{411}(F_ASSIGN{412}(0 = *{413}, 1 = +{414}[!depend_p(CDAR(n), CDAR(n))]), F_DEC{415}($CDAR(n)$, -{416}))""\n");
                      }
#endif /* PIKE_DEBUG */
                    {
                        
                      ADD_NODE_REF2(CDAR(n),
                      ADD_NODE_REF2(CAAR(n),
                        tmp1 = mknode(F_ASSIGN,
                    		mkefuncallnode("`-",
                    			       mknode(F_ARG_LIST, CAAR(n), mkintnode(1))), CDAR(n));
                      ));
                      goto use_tmp1;
                      }
                  }
                }
              }
            } else if (CDR(n)->token == F_INC) {
              {
                if ((CADR(n) == CDAR(n))
#ifdef SHARED_NODES_MK2
                  || (CADR(n) && CDAR(n) &&
                      ((CADR(n)->master?CADR(n)->master:CADR(n))==
                       (CDAR(n)->master?CDAR(n)->master:CDAR(n))))
#endif /* SHARED_NODES_MK2 */
                  ) {
                  if (!CDDR(n)) {
#ifdef PIKE_DEBUG
                      if (l_flag > 4) {
                        fprintf(stderr, "Match: ""F_COMMA_EXPR{417}(F_ASSIGN{418}(0 = *{419}, 1 = +{420}[!depend_p(CDAR(n), CDAR(n))]), F_INC{421}($CDAR(n)$, -{422}))""\n");
                      }
#endif /* PIKE_DEBUG */
                    {
                        
                      ADD_NODE_REF2(CDAR(n),
                      ADD_NODE_REF2(CAAR(n),
                        tmp1 = mknode(F_ASSIGN,
                    		mkefuncallnode("`+",
                    			       mknode(F_ARG_LIST, CAAR(n), mkintnode(1))), CDAR(n));
                      ));
                      goto use_tmp1;
                      }
                  }
                }
              }
            }
          }
        }
      }
    } else if (CAR(n)->token == F_BREAK) {
      if (!CDR(n)) {
      } else {
        if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_COMMA_EXPR{389}(0 = F_BREAK{390}, +{391}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{392}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    } else if (CAR(n)->token == F_CAST) {
      if (!CDR(n)) {
      } else {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_COMMA_EXPR{348}(F_CAST{349}(0 = *{350}, *), 1 = +{352})""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_COMMA_EXPR{353}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAAR(n),
          ADD_NODE_REF2(CDR(n),
            tmp1 = mknode(F_COMMA_EXPR, CAAR(n), CDR(n));
          ));
          goto use_tmp1;
        }
      }
    } else if (CAR(n)->token == F_COMMA_EXPR) {
      if (!CDAR(n)) {
      } else {
        if (CDAR(n)->token == F_BREAK) {
          if (!CDR(n)) {
          } else {
            if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_COMMA_EXPR{405}(0 = F_COMMA_EXPR{406}(*, F_BREAK{408}), +{409}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "=> ""0 = *{410}""\n");
                }
#endif /* PIKE_DEBUG */
              goto use_car;
            }
          }
        } else if (CDAR(n)->token == F_CONSTANT) {
          if (!CDR(n)) {
          } else {
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "Match: ""F_COMMA_EXPR{304}(F_COMMA_EXPR{305}(0 = *{306}, F_CONSTANT{307}), 1 = +{308})""\n");
              }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "=> ""F_COMMA_EXPR{309}""\n");
              }
#endif /* PIKE_DEBUG */
            {
              ADD_NODE_REF2(CAAR(n),
              ADD_NODE_REF2(CDR(n),
                tmp1 = mknode(F_COMMA_EXPR, CAAR(n), CDR(n));
              ));
              goto use_tmp1;
            }
          }
        } else if (CDAR(n)->token == F_CONTINUE) {
          if (!CDR(n)) {
          } else {
            if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_COMMA_EXPR{399}(0 = F_COMMA_EXPR{400}(*, F_CONTINUE{402}), +{403}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "=> ""0 = *{404}""\n");
                }
#endif /* PIKE_DEBUG */
              goto use_car;
            }
          }
        } else if (CDAR(n)->token == F_POP_VALUE) {
          if (!CDR(n)) {
          } else {
            if (CDR(n)->token == F_POP_VALUE) {
              if (!CADR(n)) {
              } else {
                if ((!(CADR(n)->tree_info & OPT_APPLY))) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_COMMA_EXPR{332}(F_COMMA_EXPR{333}(0 = *{334}, F_POP_VALUE{335}(1 = *{336}, *)), F_POP_VALUE{338}(2 = +{339}[!(CADR(n)->tree_info & OPT_APPLY)], *))""\n");
                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "=> ""F_COMMA_EXPR{341}""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                    ADD_NODE_REF2(CAAR(n),
                    ADD_NODE_REF2(CADAR(n),
                    ADD_NODE_REF2(CADR(n),
                      tmp1 = mknode(F_COMMA_EXPR, CAAR(n), mknode(F_POP_VALUE, mknode(F_COMMA_EXPR, CADAR(n), CADR(n)), 0));
                    )));
                    goto use_tmp1;
                  }
                }
              }
            }
          }
        } else if (CDAR(n)->token == F_RETURN) {
          if (!CDR(n)) {
          } else {
            if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_COMMA_EXPR{393}(0 = F_COMMA_EXPR{394}(*, F_RETURN{396}), +{397}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "=> ""0 = *{398}""\n");
                }
#endif /* PIKE_DEBUG */
              goto use_car;
            }
          }
        }
        if ((node_is_tossable(CDAR(n)))) {
          if (!CDR(n)) {
          } else {
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "Match: ""F_COMMA_EXPR{312}(F_COMMA_EXPR{313}(0 = *{314}, +{315}[node_is_tossable(CDAR(n))]), 1 = +{316})""\n");
              }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "=> ""F_COMMA_EXPR{317}""\n");
              }
#endif /* PIKE_DEBUG */
            {
              ADD_NODE_REF2(CAAR(n),
              ADD_NODE_REF2(CDR(n),
                tmp1 = mknode(F_COMMA_EXPR, CAAR(n), CDR(n));
              ));
              goto use_tmp1;
            }
          }
        }
      }
    } else if (CAR(n)->token == F_CONSTANT) {
      if (!CDR(n)) {
      } else {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_COMMA_EXPR{296}(F_CONSTANT{297}, 0 = +{298})""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""0 = *{299}""\n");
          }
#endif /* PIKE_DEBUG */
        goto use_cdr;
      }
    } else if (CAR(n)->token == F_CONTINUE) {
      if (!CDR(n)) {
      } else {
        if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_COMMA_EXPR{385}(0 = F_CONTINUE{386}, +{387}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{388}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    } else if (CAR(n)->token == F_POP_VALUE) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == F_POP_VALUE) {
          if (!CADR(n)) {
          } else {
            if ((!(CADR(n)->tree_info & OPT_APPLY))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_COMMA_EXPR{320}(F_POP_VALUE{321}(0 = *{322}, *), F_POP_VALUE{324}(1 = +{325}[!(CADR(n)->tree_info & OPT_APPLY)], *))""\n");
                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "=> ""F_POP_VALUE{327}""\n");
                }
#endif /* PIKE_DEBUG */
              {
                ADD_NODE_REF2(CAAR(n),
                ADD_NODE_REF2(CADR(n),
                  tmp1 = mknode(F_POP_VALUE, mknode(F_COMMA_EXPR, CAAR(n), CADR(n)), 0);
                ));
                goto use_tmp1;
              }
            }
          }
        }
      }
    } else if (CAR(n)->token == F_RETURN) {
      if (!CDR(n)) {
      } else {
        if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_COMMA_EXPR{381}(0 = F_RETURN{382}, +{383}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{384}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    }
    if (CDR(n)->token == F_CAST) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_COMMA_EXPR{356}(0 = *{357}, 1 = F_CAST{358}(2 = *{359}, *))""\n");
        }
#endif /* PIKE_DEBUG */
      {
        struct pike_type *type = CDR(n)->type;
        
        ADD_NODE_REF2(CADR(n),
        ADD_NODE_REF2(CAR(n),
          tmp1 = mkcastnode(type, mknode(F_COMMA_EXPR, CAR(n), CADR(n)));
        ));
        goto use_tmp1;
      }
    } else if (CDR(n)->token == F_COMMA_EXPR) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_COMMA_EXPR{371}(0 = *{372}, F_COMMA_EXPR{373}(1 = *{374}, 2 = *{375}))""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""F_COMMA_EXPR{376}""\n");
        }
#endif /* PIKE_DEBUG */
      {
        ADD_NODE_REF2(CAR(n),
        ADD_NODE_REF2(CADR(n),
        ADD_NODE_REF2(CDDR(n),
          tmp1 = mknode(F_COMMA_EXPR, mknode(F_COMMA_EXPR, CAR(n), CADR(n)), CDDR(n));
        )));
        goto use_tmp1;
      }
    }
    if ((node_is_tossable(CAR(n)))) {
      if (!CDR(n)) {
      } else {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_COMMA_EXPR{300}(+{301}[node_is_tossable(CAR(n))], 0 = +{302})""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""0 = *{303}""\n");
          }
#endif /* PIKE_DEBUG */
        goto use_cdr;
      }
    }
  }
  break;

case F_DEC_LOOP:
  if (!CDR(n)) {
    if (!CAR(n)) {
    } else {
      if (CAR(n)->token == F_VAL_LVAL) {
        if (!CAAR(n)) {
        } else {
          if (( !(CAAR(n)->tree_info & (OPT_SIDE_EFFECT|OPT_ASSIGNMENT|
						OPT_CASE|OPT_CONTINUE|
						OPT_BREAK|OPT_RETURN)) )) {
            if (!CDAR(n)) {
            } else {
              if (( !(CDAR(n)->tree_info & (OPT_SIDE_EFFECT|OPT_ASSIGNMENT|
						OPT_CASE|OPT_CONTINUE|
						OPT_BREAK|OPT_RETURN)) )) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_DEC_LOOP{1322}(F_VAL_LVAL{1323}(0 = +{1324}[ !(CAAR(n)->tree_info & (OPT_SIDE_EFFECT|OPT_ASSIGNMENT|\n"
                "\t\t\t\t\t\tOPT_CASE|OPT_CONTINUE|\n"
                "\t\t\t\t\t\tOPT_BREAK|OPT_RETURN)) ], 1 = +{1325}[ !(CDAR(n)->tree_info & (OPT_SIDE_EFFECT|OPT_ASSIGNMENT|\n"
                "\t\t\t\t\t\tOPT_CASE|OPT_CONTINUE|\n"
                "\t\t\t\t\t\tOPT_BREAK|OPT_RETURN)) ]), -{1326})""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_POP_VALUE{1327}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CDAR(n),
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CDAR(n),
                    tmp1 = mknode(F_POP_VALUE, mknode('?', mknode(F_GT, mknode(F_DEC, CDAR(n), 0), CAAR(n)), mknode(':', mknode(F_ASSIGN, CAAR(n), CDAR(n)), 0)), 0);
                  ))));
                  goto use_tmp1;
                }
              }
            }
          }
        }
      }
    }
  }
  break;

case F_DIV_EQ:
  if (!CAR(n)) {
  } else {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_DIV_EQ{1426}(0 = +{1427}, 1 = *{1428})""\n");
      }
#endif /* PIKE_DEBUG */
    {
      struct pike_type *type = CAR(n)->type;
      int oper = ((CAR(n)->tree_info&(OPT_SIDE_EFFECT|OPT_ASSIGNMENT)) ||
    	      depend_p(CAR(n), CDR(n))) ? F_ASSIGN_SELF : F_ASSIGN;
      
      ADD_NODE_REF2(CAR(n),
      ADD_NODE_REF2(CAR(n),
      ADD_NODE_REF2(CDR(n),
        tmp1 = mknode( oper, mksoftcastnode(type,mkopernode( "`/", CAR(n), CDR(n) )), CAR(n) );
      )));
      goto use_tmp1;
    }
  }
  break;

case F_DO:
  if (!CAR(n)) {
    if (!CDR(n)) {
    } else {
      if ((node_is_true(CDR(n)))) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_DO{996}(-{997}, 0 = +{998}[node_is_true(CDR(n))])""\n");
          }
#endif /* PIKE_DEBUG */
        {
          /* Infinite loop */
          
          ADD_NODE_REF2(CDR(n),
            tmp1 = mknode(F_DO, mkefuncallnode("sleep", mkintnode(255)), CDR(n));
          );
          goto use_tmp1;
        }
      }
    }
  } else if (!CDR(n)) {
    if (!CAR(n)) {
    } else {
      if ((!(CAR(n)->tree_info & (OPT_BREAK|OPT_CONTINUE)))) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_DO{988}(0 = +{989}[!(CAR(n)->tree_info & (OPT_BREAK|OPT_CONTINUE))], -{990})""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""0 = *{991}""\n");
          }
#endif /* PIKE_DEBUG */
        goto use_car;
      }
    }
  } else {
    if ((!(CAR(n)->tree_info & (OPT_BREAK|OPT_CONTINUE)))) {
      if (!CDR(n)) {
      } else {
        if ((node_is_false(CDR(n)))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_DO{992}(0 = +{993}[!(CAR(n)->tree_info & (OPT_BREAK|OPT_CONTINUE))], +{994}[node_is_false(CDR(n))])""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{995}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    }
  }
  break;

case F_FOR:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_FOR{1066}(-{1067}, *)""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""-{1069}""\n");
      }
#endif /* PIKE_DEBUG */
    goto zap_node;
  } else if (!CDR(n)) {
    if (!CAR(n)) {
    } else {
      if (CAR(n)->token == F_DEC) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_FOR{1184}(F_DEC{1185}(0 = *{1186}, *), -{1188})""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_DEC_NEQ_LOOP{1189}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAAR(n),
            tmp1 = mknode(F_DEC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(0), CAAR(n)), 0);
          );
          goto use_tmp1;
        }
      } else if (CAR(n)->token == F_INC) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_FOR{1088}(F_INC{1089}(0 = *{1090}, *), -{1092})""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_INC_NEQ_LOOP{1093}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAAR(n),
            tmp1 = mknode(F_INC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(0), CAAR(n)), 0);
          );
          goto use_tmp1;
        }
      } else if (CAR(n)->token == F_POST_DEC) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_FOR{1232}(F_POST_DEC{1233}(0 = *{1234}, *), -{1236})""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_DEC_NEQ_LOOP{1237}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAAR(n),
            tmp1 = mknode(F_DEC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(-1), CAAR(n)), 0);
          );
          goto use_tmp1;
        }
      } else if (CAR(n)->token == F_POST_INC) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_FOR{1136}(F_POST_INC{1137}(0 = *{1138}, *), -{1140})""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_INC_NEQ_LOOP{1141}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAAR(n),
            tmp1 = mknode(F_INC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(1), CAAR(n)), 0);
          );
          goto use_tmp1;
        }
      }
      if ((node_is_false(CAR(n)))) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_FOR{1078}(+{1079}[node_is_false(CAR(n))], *)""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""-{1081}""\n");
          }
#endif /* PIKE_DEBUG */
        goto zap_node;
      }
      if ((node_is_tossable(CAR(n)))) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_FOR{1085}(0 = +{1086}[node_is_tossable(CAR(n))], -{1087})""\n");
          }
#endif /* PIKE_DEBUG */
        {
          /* CPU-wasting delay loop [bug 3907]. */
          
          ADD_NODE_REF2(CAR(n),
            tmp1 = mknode(F_FOR, CAR(n), mknode(':',
        				mkefuncallnode("sleep", mkintnode(1)),
        				0));
          );
          goto use_tmp1;
        }
      }
      if ((node_is_true(CAR(n)))) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_FOR{1082}(0 = +{1083}[node_is_true(CAR(n))], -{1084})""\n");
          }
#endif /* PIKE_DEBUG */
        {
          /* Infinite loop */
          
          ADD_NODE_REF2(CAR(n),
            tmp1 = mknode(F_FOR, CAR(n), mknode(':',
        				mkefuncallnode("sleep", mkintnode(255)),
        				0));
          );
          goto use_tmp1;
        }
      }
    }
  } else {
    if (CAR(n)->token == F_APPLY) {
      if (!CAAR(n)) {
      } else {
        if (CAAR(n)->token == F_CONSTANT) {
          if ((TYPEOF(CAAR(n)->u.sval) == T_FUNCTION) &&
              (SUBTYPEOF(CAAR(n)->u.sval) == FUNCTION_BUILTIN)) {
            if (!CDR(n)) {
            } else {
              if (CDR(n)->token == ':') {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_FOR{1292}(0 = F_APPLY{1293}(1 = F_CONSTANT{1294}[TYPEOF(CAAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAAR(n)->u.sval) == FUNCTION_BUILTIN], 2 = *{1295}), 4 = ':'{1296}(3 = *{1297}, *))""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  node **last;

                  /* Last is a pointer to the place where the incrementor is in the
                   * tree. This is needed so we can nullify this pointer later and
                   * free the rest of the tree
                   */
                  last = &_CDR(CDR(n));
                  tmp1 = *last;

                  /* We're not interested in casts to void */
                  while(tmp1 &&
                	( (tmp1->token == F_CAST && tmp1->type == void_type_string) ||
                	  tmp1->token == F_POP_VALUE))
                  {
                    last = &_CAR(tmp1);
                    tmp1 = *last;
                  }

                  /* If there is an incrementor, and it is one of x++, ++x, x-- or ++x */
                  if(tmp1 && (tmp1->token == F_INC ||
                	      tmp1->token == F_POST_INC ||
                	      tmp1->token == F_DEC ||
                	      tmp1->token == F_POST_DEC))
                  {
                    node **arg1, **arg2;
                    int oper;
                    int inc;
                    int token;

                    /* does it increment or decrement ? */
                    inc = (tmp1->token==F_INC || tmp1->token==F_POST_INC);

                    /* for(; arg1 oper arg2; z ++) p; */

                    if(CAAR(n)->u.sval.u.efun->function == f_gt)
                      oper = F_GT;
                    else if(CAAR(n)->u.sval.u.efun->function == f_ge)
                      oper = F_GE;
                    else if(CAAR(n)->u.sval.u.efun->function == f_lt)
                      oper = F_LT;
                    else if(CAAR(n)->u.sval.u.efun->function == f_le)
                      oper = F_LE;
                    else if(CAAR(n)->u.sval.u.efun->function == f_ne)
                      oper = F_NE;
                    else
                      goto next_for_opt;

                    if(count_args(CDAR(n)) != 2)
                      goto next_for_opt;

                    arg1 = my_get_arg(&_CDR(CAR(n)), 0);
                    arg2 = my_get_arg(&_CDR(CAR(n)), 1);

                    /* it was not on the form for(; x op y; z++) p; */
                    if(!node_is_eq(*arg1, CAR(tmp1)) || /* x == z */
                       depend_p(*arg2, *arg2) ||	/* does y depend on y? */
                       depend_p(*arg2, *arg1) ||	/* does y depend on x? */
                       depend_p(*arg2, CADR(n)) ||		/* does y depend on p? */
                       depend_p(*arg2, tmp1))		/* does y depend on z? */
                    {
                      /* it was not on the form for(; x op y; z++) p; */
                      if(!node_is_eq(*arg2, CAR(tmp1)) || /* y == z */
                	 depend_p(*arg1, *arg2) ||	/* does x depend on y? */
                	 depend_p(*arg1, *arg1) ||	/* does x depend on x? */
                	 depend_p(*arg1, CADR(n)) ||		/* does x depend on p? */
                	 depend_p(*arg1, tmp1))		/* does x depend on z? */
                      {
                	/* it was not on the form for(; x op y; y++) p; */
                	goto next_for_opt;
                      }else{
                	node **tmparg;
                	/* for(; x op y; y++) p; -> for(; y op^-1 x; y++) p; */
                	
                	switch(oper)
                	{
                	case F_LT: oper = F_GT; break;
                	case F_LE: oper = F_GE; break;
                	case F_GT: oper = F_LT; break;
                	case F_GE: oper = F_LE; break;
                	}
                	    
                	tmparg = arg1;
                	arg1 = arg2;
                	arg2 = tmparg;
                      }
                    }

                    if(inc)
                    {
                      if(oper == F_LE) {
                	static struct pike_string *plus_name;
                	node *fun;
                	if ((!plus_name && !(plus_name = findstring("`+"))) ||
                	    !(fun=find_module_identifier(plus_name, 0))) {
                	  yyerror("Internally used efun undefined: `+");
                	  tmp3 = mkintnode(0);
                        } else {
                	  ADD_NODE_REF2(*arg2,
                	    tmp3 = mkapplynode(fun, mknode(F_ARG_LIST, *arg2, mkintnode(1)));
                	  );
                	}
                      } else if(oper == F_LT) {
                	ADD_NODE_REF2(*arg2,
                	  tmp3 = *arg2;
                	);
                      } else
                	goto next_for_opt;
                    }else{
                      if(oper == F_GE) {
                	static struct pike_string *minus_name;
                	node *fun;
                	if ((!minus_name && !(minus_name = findstring("`-"))) ||
                	    !(fun=find_module_identifier(minus_name, 0))) {
                	  yyerror("Internally used efun undefined: `-");
                	  tmp3 = mkintnode(0);
                        } else {
                	  ADD_NODE_REF2(*arg2,
                	    tmp3 = mkapplynode(fun, mknode(F_ARG_LIST, *arg2, mkintnode(1)));
                	  );
                	}
                      } else if(oper == F_GT) {
                	ADD_NODE_REF2(*arg2,
                	  tmp3 = *arg2;
                	);
                      } else
                	goto next_for_opt;
                    }
                    if(oper == F_NE)
                    {
                      if(inc)
                	token = F_INC_NEQ_LOOP;
                      else
                	token = F_DEC_NEQ_LOOP;
                    }else{
                      if(inc)
                	token = F_INC_LOOP;
                      else
                	token = F_DEC_LOOP;
                    }

                    tmp1=CAR(*last);
                    ADD_NODE_REF(CAR(*last));
                    ADD_NODE_REF2(*arg1,
                    ADD_NODE_REF2(CADR(n),
                      tmp2 = mknode(token, mknode(F_VAL_LVAL, tmp3, *arg1), CADR(n));
                    ));

                    tmp1 = mknode(F_COMMA_EXPR, mkcastnode(void_type_string,
                					   mknode(inc ? F_DEC : F_INC, tmp1, 0)), tmp2);
                    goto use_tmp1;
                  }
                 next_for_opt:
                  ;
                }
              }
            }
          }
        }
      }
    } else if (CAR(n)->token == F_DEC) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == ':') {
          if (!CADR(n)) {
            if (!CDDR(n)) {
            } else {
              if ((!(CDDR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_FOR{1194}(F_DEC{1195}(0 = *{1196}, *), ':'{1198}(-{1199}, 1 = +{1200}[!(CDDR(n)->tree_info & OPT_CONTINUE)]))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_DEC_NEQ_LOOP{1201}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CDDR(n),
                    tmp1 = mknode(F_DEC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(0), CAAR(n)), CDDR(n));
                  ));
                  goto use_tmp1;
                }
              }
            }
          } else if (!CDDR(n)) {
            if (!CADR(n)) {
            } else {
              if ((!(CADR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_FOR{1206}(F_DEC{1207}(0 = *{1208}, *), ':'{1210}(1 = +{1211}[!(CADR(n)->tree_info & OPT_CONTINUE)], -{1212}))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_DEC_NEQ_LOOP{1213}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CADR(n),
                    tmp1 = mknode(F_DEC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(0), CAAR(n)), CADR(n));
                  ));
                  goto use_tmp1;
                }
              }
            }
          } else {
            if ((!(CADR(n)->tree_info & OPT_CONTINUE))) {
              if (!CDDR(n)) {
              } else {
                if ((!(CDDR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_FOR{1218}(F_DEC{1219}(0 = *{1220}, *), ':'{1222}(1 = +{1223}[!(CADR(n)->tree_info & OPT_CONTINUE)], 2 = +{1224}[!(CDDR(n)->tree_info & OPT_CONTINUE)]))""\n");
                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "=> ""F_DEC_NEQ_LOOP{1225}""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                    ADD_NODE_REF2(CAAR(n),
                    ADD_NODE_REF2(CADR(n),
                    ADD_NODE_REF2(CDDR(n),
                      tmp1 = mknode(F_DEC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(0), CAAR(n)), mknode(F_COMMA_EXPR, CADR(n), CDDR(n)));
                    )));
                    goto use_tmp1;
                  }
                }
              }
            }
          }
        }
      }
    } else if (CAR(n)->token == F_INC) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == ':') {
          if (!CADR(n)) {
            if (!CDDR(n)) {
            } else {
              if ((!(CDDR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_FOR{1098}(F_INC{1099}(0 = *{1100}, *), ':'{1102}(-{1103}, 1 = +{1104}[!(CDDR(n)->tree_info & OPT_CONTINUE)]))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_INC_NEQ_LOOP{1105}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CDDR(n),
                    tmp1 = mknode(F_INC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(0), CAAR(n)), CDDR(n));
                  ));
                  goto use_tmp1;
                }
              }
            }
          } else if (!CDDR(n)) {
            if (!CADR(n)) {
            } else {
              if ((!(CADR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_FOR{1110}(F_INC{1111}(0 = *{1112}, *), ':'{1114}(1 = +{1115}[!(CADR(n)->tree_info & OPT_CONTINUE)], -{1116}))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_INC_NEQ_LOOP{1117}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CADR(n),
                    tmp1 = mknode(F_INC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(0), CAAR(n)), CADR(n));
                  ));
                  goto use_tmp1;
                }
              }
            }
          } else {
            if ((!(CADR(n)->tree_info & OPT_CONTINUE))) {
              if (!CDDR(n)) {
              } else {
                if ((!(CDDR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_FOR{1122}(F_INC{1123}(0 = *{1124}, *), ':'{1126}(1 = +{1127}[!(CADR(n)->tree_info & OPT_CONTINUE)], 2 = +{1128}[!(CDDR(n)->tree_info & OPT_CONTINUE)]))""\n");
                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "=> ""F_INC_NEQ_LOOP{1129}""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                    ADD_NODE_REF2(CAAR(n),
                    ADD_NODE_REF2(CADR(n),
                    ADD_NODE_REF2(CDDR(n),
                      tmp1 = mknode(F_INC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(0), CAAR(n)), mknode(F_COMMA_EXPR, CADR(n), CDDR(n)));
                    )));
                    goto use_tmp1;
                  }
                }
              }
            }
          }
        }
      }
    } else if (CAR(n)->token == F_POST_DEC) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == ':') {
          if (!CADR(n)) {
            if (!CDDR(n)) {
            } else {
              if ((!(CDDR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_FOR{1242}(F_POST_DEC{1243}(0 = *{1244}, *), ':'{1246}(-{1247}, 1 = +{1248}[!(CDDR(n)->tree_info & OPT_CONTINUE)]))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_DEC_NEQ_LOOP{1249}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CDDR(n),
                    tmp1 = mknode(F_DEC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(-1), CAAR(n)), CDDR(n));
                  ));
                  goto use_tmp1;
                }
              }
            }
          } else if (!CDDR(n)) {
            if (!CADR(n)) {
            } else {
              if ((!(CADR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_FOR{1254}(F_POST_DEC{1255}(0 = *{1256}, *), ':'{1258}(1 = +{1259}[!(CADR(n)->tree_info & OPT_CONTINUE)], -{1260}))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_DEC_NEQ_LOOP{1261}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CADR(n),
                    tmp1 = mknode(F_DEC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(-1), CAAR(n)), CADR(n));
                  ));
                  goto use_tmp1;
                }
              }
            }
          } else {
            if ((!(CADR(n)->tree_info & OPT_CONTINUE))) {
              if (!CDDR(n)) {
              } else {
                if ((!(CDDR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_FOR{1266}(F_POST_DEC{1267}(0 = *{1268}, *), ':'{1270}(1 = +{1271}[!(CADR(n)->tree_info & OPT_CONTINUE)], 2 = +{1272}[!(CDDR(n)->tree_info & OPT_CONTINUE)]))""\n");
                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "=> ""F_DEC_NEQ_LOOP{1273}""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                    ADD_NODE_REF2(CAAR(n),
                    ADD_NODE_REF2(CADR(n),
                    ADD_NODE_REF2(CDDR(n),
                      tmp1 = mknode(F_DEC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(-1), CAAR(n)), mknode(F_COMMA_EXPR, CADR(n), CDDR(n)));
                    )));
                    goto use_tmp1;
                  }
                }
              }
            }
          }
        }
      }
    } else if (CAR(n)->token == F_POST_INC) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == ':') {
          if (!CADR(n)) {
            if (!CDDR(n)) {
            } else {
              if ((!(CDDR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_FOR{1146}(F_POST_INC{1147}(0 = *{1148}, *), ':'{1150}(-{1151}, 1 = +{1152}[!(CDDR(n)->tree_info & OPT_CONTINUE)]))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_INC_NEQ_LOOP{1153}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CDDR(n),
                    tmp1 = mknode(F_INC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(1), CAAR(n)), CDDR(n));
                  ));
                  goto use_tmp1;
                }
              }
            }
          } else if (!CDDR(n)) {
            if (!CADR(n)) {
            } else {
              if ((!(CADR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_FOR{1158}(F_POST_INC{1159}(0 = *{1160}, *), ':'{1162}(1 = +{1163}[!(CADR(n)->tree_info & OPT_CONTINUE)], -{1164}))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_INC_NEQ_LOOP{1165}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CADR(n),
                    tmp1 = mknode(F_INC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(1), CAAR(n)), CADR(n));
                  ));
                  goto use_tmp1;
                }
              }
            }
          } else {
            if ((!(CADR(n)->tree_info & OPT_CONTINUE))) {
              if (!CDDR(n)) {
              } else {
                if ((!(CDDR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_FOR{1170}(F_POST_INC{1171}(0 = *{1172}, *), ':'{1174}(1 = +{1175}[!(CADR(n)->tree_info & OPT_CONTINUE)], 2 = +{1176}[!(CDDR(n)->tree_info & OPT_CONTINUE)]))""\n");
                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "=> ""F_INC_NEQ_LOOP{1177}""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                    ADD_NODE_REF2(CAAR(n),
                    ADD_NODE_REF2(CADR(n),
                    ADD_NODE_REF2(CDDR(n),
                      tmp1 = mknode(F_INC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(1), CAAR(n)), mknode(F_COMMA_EXPR, CADR(n), CDDR(n)));
                    )));
                    goto use_tmp1;
                  }
                }
              }
            }
          }
        }
      }
    }
    if (CDR(n)->token == ':') {
      if (!CADR(n)) {
        if (!CDDR(n)) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_FOR{1070}(0 = *{1071}, ':'{1072}(-{1073}, -{1074}))""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""F_FOR{1075}""\n");
            }
#endif /* PIKE_DEBUG */
          {
            ADD_NODE_REF2(CAR(n),
              tmp1 = mknode(F_FOR, CAR(n), 0);
            );
            goto use_tmp1;
          }
        }
      } else if (!CDDR(n)) {
      } else {
        if (CDDR(n)->token == F_CAST) {
          if ((CDDR(n)->type == void_type_string)) {
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "Match: ""F_FOR{1280}(0 = *{1281}, ':'{1282}(1 = *{1283}, F_CAST{1284}[CDDR(n)->type == void_type_string](2 = *{1285}, *)))""\n");
              }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "=> ""F_FOR{1287}""\n");
              }
#endif /* PIKE_DEBUG */
            {
              ADD_NODE_REF2(CAR(n),
              ADD_NODE_REF2(CADR(n),
              ADD_NODE_REF2(CADDR(n),
                tmp1 = mknode(F_FOR, CAR(n), mknode(':', CADR(n), CADDR(n)));
              )));
              goto use_tmp1;
            }
          }
        }
      }
    }
    if ((node_is_false(CAR(n)))) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_FOR{1078}(+{1079}[node_is_false(CAR(n))], *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""-{1081}""\n");
        }
#endif /* PIKE_DEBUG */
      goto zap_node;
    }
  }
  break;

case F_FOREACH:
  if (!CAR(n)) {
  } else if (!CDR(n)) {
    if (!CAR(n)) {
    } else {
      if (CAR(n)->token == F_VAL_LVAL) {
        if (!CAAR(n)) {
        } else {
          if ((!(CAAR(n)->node_info & (OPT_SIDE_EFFECT|OPT_ASSIGNMENT)))) {
            if (!CDAR(n)) {
            } else {
              if (((CDAR(n)->token != ':'))) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_FOREACH{999}(F_VAL_LVAL{1000}(0 = +{1001}[!(CAAR(n)->node_info & (OPT_SIDE_EFFECT|OPT_ASSIGNMENT))], 1 = +{1002}[(CDAR(n)->token != ':')]), -{1003})""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  
                  
                  
                  ADD_NODE_REF2(CDAR(n),
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CAAR(n),
                    tmp1 = mknode(F_POP_VALUE,
                	      mknode('?',
                		     mkefuncallnode("sizeof", CAAR(n)),
                		     mknode(':',
                			    mknode(F_ASSIGN,
                				   mknode(F_INDEX, CAAR(n), mkintnode(-1)), CDAR(n)),
                			    NULL)),
                	      0);
                  )));
                  goto use_tmp1;
                }
              }
            }
          }
        }
      }
    }
  } else {
    if (CAR(n)->token == F_VAL_LVAL) {
      if (!CAAR(n)) {
      } else if (!CDAR(n)) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_FOREACH{1022}(F_VAL_LVAL{1023}(0 = *{1024}, -{1025}), 1 = *{1026})""\n");
          }
#endif /* PIKE_DEBUG */
        {
            
          ADD_NODE_REF2(CDR(n),
          ADD_NODE_REF2(CAAR(n),
            tmp1 = mknode(F_LOOP, mkefuncallnode("sizeof", CAAR(n)), CDR(n));
          ));
          goto use_tmp1;
          }
      } else {
        if (CAAR(n)->token == F_APPLY) {
          if (!CAAAR(n)) {
          } else {
            if (CAAAR(n)->token == F_CONSTANT) {
              if ((TYPEOF(CAAAR(n)->u.sval) == T_FUNCTION) &&
                  (SUBTYPEOF(CAAAR(n)->u.sval) == FUNCTION_BUILTIN) &&
                  (CAAAR(n)->u.sval.u.efun->function == f_divide)) {
                if (!CDAAR(n)) {
                } else {
                  if (CDAAR(n)->token == F_ARG_LIST) {
                    if (!CADAAR(n)) {
                    } else {
                      if ((pike_types_le(CADAAR(n)->type, string_type_string))) {
                        if (!CDDAAR(n)) {
                        } else {
                          if (CDDAAR(n)->token == F_CONSTANT) {
                            if ((TYPEOF(CDDAAR(n)->u.sval) == T_STRING) &&
                                (CDDAAR(n)->u.sval.u.string->len == 1)) {
#ifdef PIKE_DEBUG
                                if (l_flag > 4) {
                                  fprintf(stderr, "Match: ""F_FOREACH{1027}(F_VAL_LVAL{1028}(F_APPLY{1029}(F_CONSTANT{1030}[TYPEOF(CAAAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAAAR(n)->u.sval) == FUNCTION_BUILTIN][CAAAR(n)->u.sval.u.efun->function == f_divide], F_ARG_LIST{1031}(0 = +{1032}[pike_types_le(CADAAR(n)->type, string_type_string)], 1 = F_CONSTANT{1033}[TYPEOF(CDDAAR(n)->u.sval) == T_STRING][CDDAAR(n)->u.sval.u.string->len == 1])), 2 = *{1034}), 3 = *{1035})""\n");
                                }
#endif /* PIKE_DEBUG */
                              {
                                extern struct program *string_split_iterator_program;
                                node *vars;
                                p_wchar2 split = index_shared_string(CDDAAR(n)->u.sval.u.string, 0);

                                ADD_NODE_REF2(CDAR(n),
                                  if (CDAR(n)->token == ':') {
                                    vars = CDAR(n);
                                  } else {
                                    /* Old-style. Convert to new-style. */
                                    vars = mknode(':', NULL, CDAR(n));
                                  }
                                );

                                
                                ADD_NODE_REF2(CDR(n),
                                ADD_NODE_REF2(CADAAR(n),
                                  tmp1 = mknode(F_FOREACH,
                              	      mknode(F_VAL_LVAL,
                              		     mkapplynode(mkprgnode(string_split_iterator_program),
                              				 mknode(F_ARG_LIST, CADAAR(n),
                              					mkintnode(split))),
                              		     vars),
                              	      CDR(n));
                                ));
                                goto use_tmp1;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
              if ((TYPEOF(CAAAR(n)->u.sval) == T_FUNCTION) &&
                  (SUBTYPEOF(CAAAR(n)->u.sval) == FUNCTION_BUILTIN) &&
                  (CAAAR(n)->u.sval.u.efun->function == f_minus)) {
                if (!CDAAR(n)) {
                } else {
                  if (CDAAR(n)->token == F_ARG_LIST) {
                    if (!CADAAR(n)) {
                    } else {
                      if (CADAAR(n)->token == F_APPLY) {
                        if (!CAADAAR(n)) {
                        } else {
                          if (CAADAAR(n)->token == F_CONSTANT) {
                            if ((TYPEOF(CAADAAR(n)->u.sval) == T_FUNCTION) &&
                                (SUBTYPEOF(CAADAAR(n)->u.sval) == FUNCTION_BUILTIN) &&
                                (CAADAAR(n)->u.sval.u.efun->function == f_divide)) {
                              if (!CDADAAR(n)) {
                              } else {
                                if (CDADAAR(n)->token == F_ARG_LIST) {
                                  if (!CADADAAR(n)) {
                                  } else {
                                    if ((pike_types_le(CADADAAR(n)->type, string_type_string))) {
                                      if (!CDDADAAR(n)) {
                                      } else {
                                        if (CDDADAAR(n)->token == F_CONSTANT) {
                                          if ((TYPEOF(CDDADAAR(n)->u.sval) == T_STRING) &&
                                              (CDDADAAR(n)->u.sval.u.string->len == 1)) {
                                            if (!CDDAAR(n)) {
                                            } else {
                                              if (CDDAAR(n)->token == F_APPLY) {
                                                if (!CADDAAR(n)) {
                                                } else {
                                                  if (CADDAAR(n)->token == F_CONSTANT) {
                                                    if ((TYPEOF(CADDAAR(n)->u.sval) == T_FUNCTION) &&
                                                        (SUBTYPEOF(CADDAAR(n)->u.sval) == FUNCTION_BUILTIN) &&
                                                        (CADDAAR(n)->u.sval.u.efun->function == f_allocate)) {
                                                      if (!CDDDAAR(n)) {
                                                      } else {
                                                        if (CDDDAAR(n)->token == F_ARG_LIST) {
                                                          if (!CADDDAAR(n)) {
                                                          } else {
                                                            if (CADDDAAR(n)->token == F_CONSTANT) {
                                                              if ((TYPEOF(CADDDAAR(n)->u.sval) == T_INT) &&
                                                                  (CADDDAAR(n)->u.sval.u.integer == 1)) {
                                                                if (!CDDDDAAR(n)) {
                                                                } else {
                                                                  if (CDDDDAAR(n)->token == F_CONSTANT) {
                                                                    if ((TYPEOF(CDDDDAAR(n)->u.sval) == T_STRING) &&
                                                                        (CDDDDAAR(n)->u.sval.u.string->len == 0)) {
#ifdef PIKE_DEBUG
                                                                        if (l_flag > 4) {
                                                                          fprintf(stderr, "Match: ""F_FOREACH{1049}(F_VAL_LVAL{1050}(F_APPLY{1051}(F_CONSTANT{1052}[TYPEOF(CAAAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAAAR(n)->u.sval) == FUNCTION_BUILTIN][CAAAR(n)->u.sval.u.efun->function == f_minus], F_ARG_LIST{1053}(F_APPLY{1054}(F_CONSTANT{1055}[TYPEOF(CAADAAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAADAAR(n)->u.sval) == FUNCTION_BUILTIN][CAADAAR(n)->u.sval.u.efun->function == f_divide], F_ARG_LIST{1056}(0 = +{1057}[pike_types_le(CADADAAR(n)->type, string_type_string)], 1 = F_CONSTANT{1058}[TYPEOF(CDDADAAR(n)->u.sval) == T_STRING][CDDADAAR(n)->u.sval.u.string->len == 1])), F_APPLY{1059}(F_CONSTANT{1060}[TYPEOF(CADDAAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CADDAAR(n)->u.sval) == FUNCTION_BUILTIN][CADDAAR(n)->u.sval.u.efun->function == f_allocate], F_ARG_LIST{1061}(F_CONSTANT{1062}[TYPEOF(CADDDAAR(n)->u.sval) == T_INT][CADDDAAR(n)->u.sval.u.integer == 1], F_CONSTANT{1063}[TYPEOF(CDDDDAAR(n)->u.sval) == T_STRING][CDDDDAAR(n)->u.sval.u.string->len == 0])))), 2 = *{1064}), 3 = *{1065})""\n");
                                                                        }
#endif /* PIKE_DEBUG */
                                                                      {
                                                                        extern struct program *string_split_iterator_program;
                                                                        node *vars;
                                                                        p_wchar2 split = index_shared_string(CDDADAAR(n)->u.sval.u.string, 0);

                                                                        ADD_NODE_REF2(CDAR(n),
                                                                          if (CDAR(n)->token == ':') {
                                                                            vars = CDAR(n);
                                                                          } else {
                                                                            /* Old-style. Convert to new-style. */
                                                                            vars = mknode(':', NULL, CDAR(n));
                                                                          }
                                                                        );

                                                                        
                                                                        ADD_NODE_REF2(CDR(n),
                                                                        ADD_NODE_REF2(CADADAAR(n),
                                                                          tmp1 = mknode(F_FOREACH,
                                                                      	      mknode(F_VAL_LVAL,
                                                                      		     mkapplynode(mkprgnode(string_split_iterator_program),
                                                                      				 mknode(F_ARG_LIST, CADADAAR(n),
                                                                      					mknode(F_ARG_LIST,
                                                                      					       mkintnode(split),
                                                                      					       mkintnode(1)))),
                                                                      		     vars),
                                                                      	      CDR(n));
                                                                        ));
                                                                        goto use_tmp1;
                                                                      }
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              } else if (CDDAAR(n)->token == F_CONSTANT) {
                                                if ((TYPEOF(CDDAAR(n)->u.sval) == T_ARRAY) &&
                                                    (CDDAAR(n)->u.sval.u.array->size == 1) &&
                                                    (TYPEOF(CDDAAR(n)->u.sval.u.array->item[0]) == T_STRING) &&
                                                    (CDDAAR(n)->u.sval.u.array->item[0].u.string->len == 0)) {
#ifdef PIKE_DEBUG
                                                    if (l_flag > 4) {
                                                      fprintf(stderr, "Match: ""F_FOREACH{1036}(F_VAL_LVAL{1037}(F_APPLY{1038}(F_CONSTANT{1039}[TYPEOF(CAAAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAAAR(n)->u.sval) == FUNCTION_BUILTIN][CAAAR(n)->u.sval.u.efun->function == f_minus], F_ARG_LIST{1040}(F_APPLY{1041}(F_CONSTANT{1042}[TYPEOF(CAADAAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAADAAR(n)->u.sval) == FUNCTION_BUILTIN][CAADAAR(n)->u.sval.u.efun->function == f_divide], F_ARG_LIST{1043}(0 = +{1044}[pike_types_le(CADADAAR(n)->type, string_type_string)], 1 = F_CONSTANT{1045}[TYPEOF(CDDADAAR(n)->u.sval) == T_STRING][CDDADAAR(n)->u.sval.u.string->len == 1])), F_CONSTANT{1046}[TYPEOF(CDDAAR(n)->u.sval) == T_ARRAY][CDDAAR(n)->u.sval.u.array->size == 1][TYPEOF(CDDAAR(n)->u.sval.u.array->item[0]) == T_STRING][CDDAAR(n)->u.sval.u.array->item[0].u.string->len == 0])), 2 = *{1047}), 3 = *{1048})""\n");
                                                    }
#endif /* PIKE_DEBUG */
                                                  {
                                                    extern struct program *string_split_iterator_program;
                                                    node *vars;
                                                    p_wchar2 split = index_shared_string(CDDADAAR(n)->u.sval.u.string, 0);

                                                    ADD_NODE_REF2(CDAR(n),
                                                      if (CDAR(n)->token == ':') {
                                                        vars = CDAR(n);
                                                      } else {
                                                        /* Old-style. Convert to new-style. */
                                                        vars = mknode(':', NULL, CDAR(n));
                                                      }
                                                    );

                                                    
                                                    ADD_NODE_REF2(CDR(n),
                                                    ADD_NODE_REF2(CADADAAR(n),
                                                      tmp1 = mknode(F_FOREACH,
                                                  	      mknode(F_VAL_LVAL,
                                                  		     mkapplynode(mkprgnode(string_split_iterator_program),
                                                  				 mknode(F_ARG_LIST, CADADAAR(n),
                                                  					mknode(F_ARG_LIST,
                                                  					       mkintnode(split),
                                                  					       mkintnode(1)))),
                                                  		     vars),
                                                  	      CDR(n));
                                                    ));
                                                    goto use_tmp1;
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        if (( pike_types_le(CAAR(n)->type, array_type_string) )) {
          if (!CDAR(n)) {
          } else {
            if (CDAR(n)->token == ':') {
              if (!CADAR(n)) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_FOREACH{1010}(F_VAL_LVAL{1011}(0 = +{1012}[ pike_types_le(CAAR(n)->type, array_type_string) ], ':'{1013}(-{1014}, 1 = *{1015})), 2 = *{1016})""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_FOREACH{1017}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CDDAR(n),
                  ADD_NODE_REF2(CDR(n),
                    tmp1 = mknode(F_FOREACH, mknode(F_VAL_LVAL, CAAR(n), CDDAR(n)), CDR(n));
                  )));
                  goto use_tmp1;
                }
              }
            }
          }
        }
      }
    }
  }
  break;

case F_INC_LOOP:
  if (!CAR(n)) {
  } else if (!CDR(n)) {
    if (!CAR(n)) {
    } else {
      if (CAR(n)->token == F_VAL_LVAL) {
        if (!CAAR(n)) {
        } else {
          if (( !(CAAR(n)->tree_info & (OPT_SIDE_EFFECT|OPT_ASSIGNMENT|
						OPT_CASE|OPT_CONTINUE|
						OPT_BREAK|OPT_RETURN)) )) {
            if (!CDAR(n)) {
            } else {
              if (( !(CDAR(n)->tree_info & (OPT_SIDE_EFFECT|OPT_ASSIGNMENT|
						OPT_CASE|OPT_CONTINUE|
						OPT_BREAK|OPT_RETURN)) )) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_INC_LOOP{1304}(F_VAL_LVAL{1305}(0 = +{1306}[ !(CAAR(n)->tree_info & (OPT_SIDE_EFFECT|OPT_ASSIGNMENT|\n"
                "\t\t\t\t\t\tOPT_CASE|OPT_CONTINUE|\n"
                "\t\t\t\t\t\tOPT_BREAK|OPT_RETURN)) ], 1 = +{1307}[ !(CDAR(n)->tree_info & (OPT_SIDE_EFFECT|OPT_ASSIGNMENT|\n"
                "\t\t\t\t\t\tOPT_CASE|OPT_CONTINUE|\n"
                "\t\t\t\t\t\tOPT_BREAK|OPT_RETURN)) ]), -{1308})""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_POP_VALUE{1309}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CDAR(n),
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CDAR(n),
                    tmp1 = mknode(F_POP_VALUE, mknode('?', mknode(F_LT, mknode(F_INC, CDAR(n), 0), CAAR(n)), mknode(':', mknode(F_ASSIGN, CAAR(n), CDAR(n)), 0)), 0);
                  ))));
                  goto use_tmp1;
                }
              }
            }
          }
        }
      }
    }
  } else {
    if (CAR(n)->token == F_VAL_LVAL) {
      if (!CAAR(n)) {
      } else {
        if (( !(CAAR(n)->tree_info & (OPT_SIDE_EFFECT|OPT_ASSIGNMENT|
						OPT_CASE|OPT_CONTINUE|
						OPT_BREAK|OPT_RETURN)) )) {
          if (!CDAR(n)) {
          } else {
            if (( !(CDAR(n)->tree_info & (OPT_SIDE_EFFECT|OPT_ASSIGNMENT|
						OPT_CASE|OPT_CONTINUE|
						OPT_BREAK|OPT_RETURN)) )) {
              if (!CDR(n)) {
              } else {
                if (( !(CDR(n)->tree_info & (OPT_BREAK|OPT_CONTINUE)) ) &&
                    ( !depend2_p(CDR(n), CDAR(n)) )) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_INC_LOOP{1299}(F_VAL_LVAL{1300}(0 = +{1301}[ !(CAAR(n)->tree_info & (OPT_SIDE_EFFECT|OPT_ASSIGNMENT|\n"
                  "\t\t\t\t\t\tOPT_CASE|OPT_CONTINUE|\n"
                  "\t\t\t\t\t\tOPT_BREAK|OPT_RETURN)) ], 1 = +{1302}[ !(CDAR(n)->tree_info & (OPT_SIDE_EFFECT|OPT_ASSIGNMENT|\n"
                  "\t\t\t\t\t\tOPT_CASE|OPT_CONTINUE|\n"
                  "\t\t\t\t\t\tOPT_BREAK|OPT_RETURN)) ]), 2 = +{1303}[ !(CDR(n)->tree_info & (OPT_BREAK|OPT_CONTINUE)) ][ !depend2_p(CDR(n), CDAR(n)) ])""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                      
                    ADD_NODE_REF2(CDAR(n),
                    ADD_NODE_REF2(CDAR(n),
                    ADD_NODE_REF2(CAAR(n),
                    ADD_NODE_REF2(CAAR(n),
                    ADD_NODE_REF2(CDR(n),
                      tmp1 = mknode(F_COMMA_EXPR,
                  		mknode(F_LOOP,
                  		       mkefuncallnode("`+",
                  				      mknode(F_ARG_LIST,
                  					     mkefuncallnode("`-", CDAR(n)),
                  					     mknode(F_ARG_LIST,
                  						    mkintnode(-1),
                  						    CAAR(n)))), CDR(n)),
                  		mkcastnode(void_type_string, mknode(F_ASSIGN, CAAR(n), CDAR(n))));
                    )))));
                    goto use_tmp1;
                    }
                }
              }
            }
          }
        }
      }
    }
  }
  break;

case F_INDEX:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_INDEX{963}(-{964}, *)""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""F_COMMA_EXPR{966}""\n");
      }
#endif /* PIKE_DEBUG */
    {
      ADD_NODE_REF2(CDR(n),
        tmp1 = mknode(F_COMMA_EXPR, mknode(F_POP_VALUE, CDR(n), 0), mkintnode(0));
      );
      goto use_tmp1;
    }
  } else {
    if (( !match_types(CAR(n)->type, object_type_string) )) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == F_CONSTANT) {
          if ((TYPEOF(CDR(n)->u.sval) == T_STRING)) {
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "Match: ""F_INDEX{971}(0 = +{972}[ !match_types(CAR(n)->type, object_type_string) ], 1 = F_CONSTANT{973}[TYPEOF(CDR(n)->u.sval) == T_STRING])""\n");
              }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "=> ""F_ARROW{974}""\n");
              }
#endif /* PIKE_DEBUG */
            {
              ADD_NODE_REF2(CAR(n),
              ADD_NODE_REF2(CDR(n),
                tmp1 = mknode(F_ARROW, CAR(n), CDR(n));
              ));
              goto use_tmp1;
            }
          }
        }
      }
    }
  }
  break;

case F_LAND:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_LAND{642}(-{643}, 0 = *{644})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""-{645}""\n");
      }
#endif /* PIKE_DEBUG */
    goto zap_node;
  } else if (!CDR(n)) {
    if (!CAR(n)) {
    } else {
      if ((node_is_false(CAR(n)))) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_LAND{702}(0 = +{703}[node_is_false(CAR(n))], *)""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""0 = *{705}""\n");
          }
#endif /* PIKE_DEBUG */
        goto use_car;
      }
      if ((node_is_true(CAR(n)))) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_LAND{698}(+{699}[node_is_true(CAR(n))], 0 = *{700})""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""0 = *{701}""\n");
          }
#endif /* PIKE_DEBUG */
        goto use_cdr;
      }
    }
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_LAND{646}(0 = *{647}, -{648})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""F_COMMA_EXPR{649}""\n");
      }
#endif /* PIKE_DEBUG */
    {
      ADD_NODE_REF2(CAR(n),
        tmp1 = mknode(F_COMMA_EXPR, CAR(n), mkintnode(0));
      );
      goto use_tmp1;
    }
  } else {
    if (CAR(n)->token == F_APPLY) {
      if (!CAAR(n)) {
      } else {
        if (CAAR(n)->token == F_CONSTANT) {
          if ((TYPEOF(CAAR(n)->u.sval) == T_FUNCTION) &&
              (SUBTYPEOF(CAAR(n)->u.sval) == FUNCTION_BUILTIN) &&
              (CAAR(n)->u.sval.u.efun->function == f_not)) {
            if (!CDR(n)) {
            } else {
              if (CDR(n)->token == F_APPLY) {
                if (!CADR(n)) {
                } else {
                  if (CADR(n)->token == F_CONSTANT) {
                    if ((TYPEOF(CADR(n)->u.sval) == T_FUNCTION) &&
                        (SUBTYPEOF(CADR(n)->u.sval) == FUNCTION_BUILTIN) &&
                        (CADR(n)->u.sval.u.efun->function == f_not)) {
#ifdef PIKE_DEBUG
                        if (l_flag > 4) {
                          fprintf(stderr, "Match: ""F_LAND{652}(F_APPLY{653}(0 = F_CONSTANT{654}[TYPEOF(CAAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAAR(n)->u.sval) == FUNCTION_BUILTIN][CAAR(n)->u.sval.u.efun->function == f_not], 1 = *{655}), F_APPLY{656}(F_CONSTANT{657}[TYPEOF(CADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CADR(n)->u.sval) == FUNCTION_BUILTIN][CADR(n)->u.sval.u.efun->function == f_not], 2 = *{658}))""\n");
                        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                        if (l_flag > 4) {
                          fprintf(stderr, "=> ""F_APPLY{659}""\n");
                        }
#endif /* PIKE_DEBUG */
                      {
                        ADD_NODE_REF2(CAAR(n),
                        ADD_NODE_REF2(CDAR(n),
                        ADD_NODE_REF2(CDDR(n),
                          tmp1 = mknode(F_APPLY, CAAR(n), mknode(F_LOR, CDAR(n), CDDR(n)));
                        )));
                        goto use_tmp1;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else if (CAR(n)->token == F_ASSIGN) {
      if (!CDAR(n)) {
      } else {
        if ((node_is_false(CDAR(n)))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_LAND{682}(0 = F_ASSIGN{683}(*, +{685}[node_is_false(CDAR(n))]), *)""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{687}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
        if ((node_is_true(CDAR(n)))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_LAND{674}(0 = F_ASSIGN{675}(*, +{677}[node_is_true(CDAR(n))]), 2 = *{678})""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""F_COMMA_EXPR{679}""\n");
            }
#endif /* PIKE_DEBUG */
          {
            ADD_NODE_REF2(CAR(n),
            ADD_NODE_REF2(CDR(n),
              tmp1 = mknode(F_COMMA_EXPR, CAR(n), CDR(n));
            ));
            goto use_tmp1;
          }
        }
      }
    } else if (CAR(n)->token == F_COMMA_EXPR) {
      if (!CDAR(n)) {
      } else {
        if ((CDAR(n)->token != F_POP_VALUE)) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_LAND{688}(F_COMMA_EXPR{689}(0 = *{690}, 1 = +{691}[CDAR(n)->token != F_POP_VALUE]), 2 = *{692})""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""F_COMMA_EXPR{693}""\n");
            }
#endif /* PIKE_DEBUG */
          {
            ADD_NODE_REF2(CAAR(n),
            ADD_NODE_REF2(CDAR(n),
            ADD_NODE_REF2(CDR(n),
              tmp1 = mknode(F_COMMA_EXPR, CAAR(n), mknode(F_LAND, CDAR(n), CDR(n)));
            )));
            goto use_tmp1;
          }
        }
      }
    } else if (CAR(n)->token == F_LAND) {
      if (!CDAR(n)) {
      } else {
        if ((node_is_false(CDAR(n)))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_LAND{706}(0 = F_LAND{707}(*, +{709}[node_is_false(CDAR(n))]), *)""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{711}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    }
    if (CDR(n)->token == F_LAND) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_LAND{664}(0 = *{665}, F_LAND{666}(1 = *{667}, 2 = *{668}))""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""F_LAND{669}""\n");
        }
#endif /* PIKE_DEBUG */
      {
        ADD_NODE_REF2(CAR(n),
        ADD_NODE_REF2(CADR(n),
        ADD_NODE_REF2(CDDR(n),
          tmp1 = mknode(F_LAND, mknode(F_LAND, CAR(n), CADR(n)), CDDR(n));
        )));
        goto use_tmp1;
      }
    }
    if ((node_is_false(CAR(n)))) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_LAND{702}(0 = +{703}[node_is_false(CAR(n))], *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{705}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    }
    if ((node_is_true(CAR(n)))) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_LAND{698}(+{699}[node_is_true(CAR(n))], 0 = *{700})""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{701}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_cdr;
    }
  }
  break;

case F_LOOP:
  if (!CAR(n)) {
  } else if (!CDR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_LOOP{1004}(0 = *{1005}, -{1006})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""F_POP_VALUE{1007}""\n");
      }
#endif /* PIKE_DEBUG */
    {
      ADD_NODE_REF2(CAR(n),
        tmp1 = mknode(F_POP_VALUE, CAR(n), 0);
      );
      goto use_tmp1;
    }
  } else {
    if (CDR(n)->token == F_POP_VALUE) {
      if (!CDDR(n)) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_LOOP{1340}(0 = *{1341}, F_POP_VALUE{1342}(1 = *{1343}, -{1344}))""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_LOOP{1345}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAR(n),
          ADD_NODE_REF2(CADR(n),
            tmp1 = mknode(F_LOOP, CAR(n), CADR(n));
          ));
          goto use_tmp1;
        }
      }
    }
    if (( !depend_p(CAR(n), CAR(n)) )) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == F_DEC) {
          if (( pike_types_le(CDR(n)->type, int_type_string) )) {
            if (!CDDR(n)) {
              if (!CADR(n)) {
              } else {
                if (( !depend_p(CADR(n), CADR(n)) )) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_LOOP{1368}(0 = +{1369}[ !depend_p(CAR(n), CAR(n)) ], F_DEC{1370}[ pike_types_le(CDR(n)->type, int_type_string) ](1 = +{1371}[ !depend_p(CADR(n), CADR(n)) ], -{1372}))""\n");
                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "=> ""F_POP_VALUE{1373}""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                    ADD_NODE_REF2(CADR(n),
                    ADD_NODE_REF2(CAR(n),
                      tmp1 = mknode(F_POP_VALUE, mknode(F_SUB_EQ, CADR(n), CAR(n)), 0);
                    ));
                    goto use_tmp1;
                  }
                }
              }
            }
          }
        } else if (CDR(n)->token == F_INC) {
          if (( pike_types_le(CDR(n)->type, int_type_string) )) {
            if (!CDDR(n)) {
              if (!CADR(n)) {
              } else {
                if (( !depend_p(CADR(n), CADR(n)) )) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_LOOP{1348}(0 = +{1349}[ !depend_p(CAR(n), CAR(n)) ], F_INC{1350}[ pike_types_le(CDR(n)->type, int_type_string) ](1 = +{1351}[ !depend_p(CADR(n), CADR(n)) ], -{1352}))""\n");
                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "=> ""F_POP_VALUE{1353}""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                    ADD_NODE_REF2(CADR(n),
                    ADD_NODE_REF2(CAR(n),
                      tmp1 = mknode(F_POP_VALUE, mknode(F_ADD_EQ, CADR(n), CAR(n)), 0);
                    ));
                    goto use_tmp1;
                  }
                }
              }
            }
          }
        } else if (CDR(n)->token == F_POST_DEC) {
          if (( pike_types_le(CDR(n)->type, int_type_string) )) {
            if (!CDDR(n)) {
              if (!CADR(n)) {
              } else {
                if (( !depend_p(CADR(n), CADR(n)) )) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_LOOP{1378}(0 = +{1379}[ !depend_p(CAR(n), CAR(n)) ], F_POST_DEC{1380}[ pike_types_le(CDR(n)->type, int_type_string) ](1 = +{1381}[ !depend_p(CADR(n), CADR(n)) ], -{1382}))""\n");
                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "=> ""F_POP_VALUE{1383}""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                    ADD_NODE_REF2(CADR(n),
                    ADD_NODE_REF2(CAR(n),
                      tmp1 = mknode(F_POP_VALUE, mknode(F_SUB_EQ, CADR(n), CAR(n)), 0);
                    ));
                    goto use_tmp1;
                  }
                }
              }
            }
          }
        } else if (CDR(n)->token == F_POST_INC) {
          if (( pike_types_le(CDR(n)->type, int_type_string) )) {
            if (!CDDR(n)) {
              if (!CADR(n)) {
              } else {
                if (( !depend_p(CADR(n), CADR(n)) )) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_LOOP{1358}(0 = +{1359}[ !depend_p(CAR(n), CAR(n)) ], F_POST_INC{1360}[ pike_types_le(CDR(n)->type, int_type_string) ](1 = +{1361}[ !depend_p(CADR(n), CADR(n)) ], -{1362}))""\n");
                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "=> ""F_POP_VALUE{1363}""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                    ADD_NODE_REF2(CADR(n),
                    ADD_NODE_REF2(CAR(n),
                      tmp1 = mknode(F_POP_VALUE, mknode(F_ADD_EQ, CADR(n), CAR(n)), 0);
                    ));
                    goto use_tmp1;
                  }
                }
              }
            }
          }
        }
      }
    }
    if (( !depend_p(CAR(n), CAR(n))) &&
        ( !(CAR(n)->tree_info & (OPT_SIDE_EFFECT|OPT_ASSIGNMENT|
			    OPT_CASE|OPT_CONTINUE|
			    OPT_BREAK|OPT_RETURN)) )) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == F_ADD_EQ) {
          if (!CADR(n)) {
          } else {
            if (( !depend_p(CADR(n), CADR(n)) )) {
              if (!CDDR(n)) {
              } else {
                if (( !depend_p(CDDR(n), CADR(n)) ) &&
                    ( !depend_p(CDDR(n), CDDR(n)) ) &&
                    ( !(CDDR(n)->tree_info & OPT_SIDE_EFFECT) ) &&
                    ( (((CDDR(n)->type == int_type_string) &&
		    (CADR(n)->type == int_type_string)) ||
		   pike_types_le(CDDR(n)->type, string_type_string)) )) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_LOOP{1388}(0 = +{1389}[ !depend_p(CAR(n), CAR(n))][ !(CAR(n)->tree_info & (OPT_SIDE_EFFECT|OPT_ASSIGNMENT|\n"
                  "\t\t\t    OPT_CASE|OPT_CONTINUE|\n"
                  "\t\t\t    OPT_BREAK|OPT_RETURN)) ], F_ADD_EQ{1390}(1 = +{1391}[ !depend_p(CADR(n), CADR(n)) ], 2 = +{1392}[ !depend_p(CDDR(n), CADR(n)) ][ !depend_p(CDDR(n), CDDR(n)) ][ !(CDDR(n)->tree_info & OPT_SIDE_EFFECT) ][ (((CDDR(n)->type == int_type_string) &&\n"
                  "\t\t    (CADR(n)->type == int_type_string)) ||\n"
                  "\t\t   pike_types_le(CDDR(n)->type, string_type_string)) ]))""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                      
                    ADD_NODE_REF2(CAR(n),
                    ADD_NODE_REF2(CAR(n),
                    ADD_NODE_REF2(CDDR(n),
                    ADD_NODE_REF2(CADR(n),
                      tmp1 = mknode(F_POP_VALUE,
                  		mknode('?',
                  		       mkefuncallnode("`>",
                  				      mknode(F_ARG_LIST,
                  					     CAR(n), mkintnode(0))),
                  		       mknode(':',
                  			      mknode(F_ADD_EQ,
                  				     CADR(n),
                  				     mkefuncallnode("`*",
                  						    mknode(F_ARG_LIST,
                  							   CDDR(n), CAR(n)))),
                  			      mkintnode(0))),
                  		NULL);
                    ))));
                    goto use_tmp1;
                    }
                }
              }
            }
          }
        }
      }
    }
  }
  break;

case F_LOR:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_LOR{574}(-{575}, 0 = *{576})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""0 = *{577}""\n");
      }
#endif /* PIKE_DEBUG */
    goto use_cdr;
  } else if (!CDR(n)) {
    if (!CAR(n)) {
    } else {
      if ((node_is_false(CAR(n)))) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_LOR{628}(+{629}[node_is_false(CAR(n))], 0 = *{630})""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""0 = *{631}""\n");
          }
#endif /* PIKE_DEBUG */
        goto use_cdr;
      }
      if ((node_is_true(CAR(n)))) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_LOR{632}(0 = +{633}[node_is_true(CAR(n))], *)""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""0 = *{635}""\n");
          }
#endif /* PIKE_DEBUG */
        goto use_car;
      }
    }
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_LOR{578}(0 = *{579}, -{580})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""0 = *{581}""\n");
      }
#endif /* PIKE_DEBUG */
    goto use_car;
  } else {
    if (CAR(n)->token == F_APPLY) {
      if (!CAAR(n)) {
      } else {
        if (CAAR(n)->token == F_CONSTANT) {
          if ((TYPEOF(CAAR(n)->u.sval) == T_FUNCTION) &&
              (SUBTYPEOF(CAAR(n)->u.sval) == FUNCTION_BUILTIN) &&
              (CAAR(n)->u.sval.u.efun->function == f_not)) {
            if (!CDR(n)) {
            } else {
              if (CDR(n)->token == F_APPLY) {
                if (!CADR(n)) {
                } else {
                  if (CADR(n)->token == F_CONSTANT) {
                    if ((TYPEOF(CADR(n)->u.sval) == T_FUNCTION) &&
                        (SUBTYPEOF(CADR(n)->u.sval) == FUNCTION_BUILTIN) &&
                        (CADR(n)->u.sval.u.efun->function == f_not)) {
#ifdef PIKE_DEBUG
                        if (l_flag > 4) {
                          fprintf(stderr, "Match: ""F_LOR{582}(F_APPLY{583}(0 = F_CONSTANT{584}[TYPEOF(CAAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAAR(n)->u.sval) == FUNCTION_BUILTIN][CAAR(n)->u.sval.u.efun->function == f_not], 1 = *{585}), F_APPLY{586}(F_CONSTANT{587}[TYPEOF(CADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CADR(n)->u.sval) == FUNCTION_BUILTIN][CADR(n)->u.sval.u.efun->function == f_not], 2 = *{588}))""\n");
                        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                        if (l_flag > 4) {
                          fprintf(stderr, "=> ""F_APPLY{589}""\n");
                        }
#endif /* PIKE_DEBUG */
                      {
                        ADD_NODE_REF2(CAAR(n),
                        ADD_NODE_REF2(CDAR(n),
                        ADD_NODE_REF2(CDDR(n),
                          tmp1 = mknode(F_APPLY, CAAR(n), mknode(F_LAND, CDAR(n), CDDR(n)));
                        )));
                        goto use_tmp1;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else if (CAR(n)->token == F_ASSIGN) {
      if (!CDAR(n)) {
      } else {
        if ((node_is_false(CDAR(n)))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_LOR{604}(0 = F_ASSIGN{605}(*, +{607}[node_is_false(CDAR(n))]), 2 = *{608})""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""F_COMMA_EXPR{609}""\n");
            }
#endif /* PIKE_DEBUG */
          {
            ADD_NODE_REF2(CAR(n),
            ADD_NODE_REF2(CDR(n),
              tmp1 = mknode(F_COMMA_EXPR, CAR(n), CDR(n));
            ));
            goto use_tmp1;
          }
        }
        if ((node_is_true(CDAR(n)))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_LOR{622}(0 = F_ASSIGN{623}(*, +{625}[node_is_true(CDAR(n))]), *)""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{627}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    } else if (CAR(n)->token == F_COMMA_EXPR) {
      if (!CDAR(n)) {
      } else {
        if ((CDAR(n)->token != F_POP_VALUE)) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_LOR{612}(F_COMMA_EXPR{613}(0 = *{614}, 1 = +{615}[CDAR(n)->token != F_POP_VALUE]), 2 = *{616})""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""F_COMMA_EXPR{617}""\n");
            }
#endif /* PIKE_DEBUG */
          {
            ADD_NODE_REF2(CAAR(n),
            ADD_NODE_REF2(CDAR(n),
            ADD_NODE_REF2(CDR(n),
              tmp1 = mknode(F_COMMA_EXPR, CAAR(n), mknode(F_LOR, CDAR(n), CDR(n)));
            )));
            goto use_tmp1;
          }
        }
      }
    } else if (CAR(n)->token == F_LOR) {
      if (!CDAR(n)) {
      } else {
        if ((node_is_true(CDAR(n)))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_LOR{636}(0 = F_LOR{637}(*, +{639}[node_is_true(CDAR(n))]), *)""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{641}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    }
    if (CDR(n)->token == F_LOR) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_LOR{594}(0 = *{595}, F_LOR{596}(1 = *{597}, 2 = *{598}))""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""F_LOR{599}""\n");
        }
#endif /* PIKE_DEBUG */
      {
        ADD_NODE_REF2(CAR(n),
        ADD_NODE_REF2(CADR(n),
        ADD_NODE_REF2(CDDR(n),
          tmp1 = mknode(F_LOR, mknode(F_LOR, CAR(n), CADR(n)), CDDR(n));
        )));
        goto use_tmp1;
      }
    }
    if ((node_is_false(CAR(n)))) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_LOR{628}(+{629}[node_is_false(CAR(n))], 0 = *{630})""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{631}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_cdr;
    }
    if ((node_is_true(CAR(n)))) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_LOR{632}(0 = +{633}[node_is_true(CAR(n))], *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{635}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    }
  }
  break;

case F_LSH_EQ:
  if (!CAR(n)) {
  } else {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_LSH_EQ{1414}(0 = +{1415}, 1 = *{1416})""\n");
      }
#endif /* PIKE_DEBUG */
    {
      struct pike_type *type = CAR(n)->type;
      int oper = ((CAR(n)->tree_info&(OPT_SIDE_EFFECT|OPT_ASSIGNMENT)) ||
    	      depend_p(CAR(n), CDR(n))) ? F_ASSIGN_SELF : F_ASSIGN;
      
      ADD_NODE_REF2(CAR(n),
      ADD_NODE_REF2(CAR(n),
      ADD_NODE_REF2(CDR(n),
        tmp1 = mknode( oper, mksoftcastnode(type,mkopernode( "`<<", CAR(n), CDR(n))), CAR(n) );
      )));
      goto use_tmp1;
    }
  }
  break;

case F_LVALUE_LIST:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_LVALUE_LIST{536}(-{537}, 0 = *{538})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""0 = *{539}""\n");
      }
#endif /* PIKE_DEBUG */
    goto use_cdr;
  } else if (!CDR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_LVALUE_LIST{540}(0 = *{541}, -{542})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""0 = *{543}""\n");
      }
#endif /* PIKE_DEBUG */
    goto use_car;
  } else {
    if (CAR(n)->token == F_BREAK) {
      if (!CDR(n)) {
      } else {
        if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_LVALUE_LIST{552}(0 = F_BREAK{553}, +{554}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{555}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    } else if (CAR(n)->token == F_COMMA_EXPR) {
      if (!CDAR(n)) {
      } else {
        if (CDAR(n)->token == F_BREAK) {
          if (!CDR(n)) {
          } else {
            if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_LVALUE_LIST{568}(0 = F_COMMA_EXPR{569}(*, F_BREAK{571}), +{572}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "=> ""0 = *{573}""\n");
                }
#endif /* PIKE_DEBUG */
              goto use_car;
            }
          }
        } else if (CDAR(n)->token == F_CONTINUE) {
          if (!CDR(n)) {
          } else {
            if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_LVALUE_LIST{562}(0 = F_COMMA_EXPR{563}(*, F_CONTINUE{565}), +{566}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "=> ""0 = *{567}""\n");
                }
#endif /* PIKE_DEBUG */
              goto use_car;
            }
          }
        } else if (CDAR(n)->token == F_RETURN) {
          if (!CDR(n)) {
          } else {
            if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_LVALUE_LIST{556}(0 = F_COMMA_EXPR{557}(*, F_RETURN{559}), +{560}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "=> ""0 = *{561}""\n");
                }
#endif /* PIKE_DEBUG */
              goto use_car;
            }
          }
        }
      }
    } else if (CAR(n)->token == F_CONTINUE) {
      if (!CDR(n)) {
      } else {
        if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_LVALUE_LIST{548}(0 = F_CONTINUE{549}, +{550}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{551}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    } else if (CAR(n)->token == F_RETURN) {
      if (!CDR(n)) {
      } else {
        if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_LVALUE_LIST{544}(0 = F_RETURN{545}, +{546}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{547}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    }
  }
  break;

case F_MOD_EQ:
  if (!CAR(n)) {
  } else {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_MOD_EQ{1423}(0 = +{1424}, 1 = *{1425})""\n");
      }
#endif /* PIKE_DEBUG */
    {
      struct pike_type *type = CAR(n)->type;
      int oper = ((CAR(n)->tree_info&(OPT_SIDE_EFFECT|OPT_ASSIGNMENT)) ||
    	      depend_p(CAR(n), CDR(n))) ? F_ASSIGN_SELF : F_ASSIGN;
      
      ADD_NODE_REF2(CAR(n),
      ADD_NODE_REF2(CAR(n),
      ADD_NODE_REF2(CDR(n),
        tmp1 = mknode( oper, mksoftcastnode(type,mkopernode( "`%", CAR(n), CDR(n) )), CAR(n) );
      )));
      goto use_tmp1;
    }
  }
  break;

case F_MULT_EQ:
  if (!CAR(n)) {
  } else {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_MULT_EQ{1420}(0 = +{1421}, 1 = *{1422})""\n");
      }
#endif /* PIKE_DEBUG */
    {
      struct pike_type *type = CAR(n)->type;
      int oper = ((CAR(n)->tree_info&(OPT_SIDE_EFFECT|OPT_ASSIGNMENT)) ||
    	      depend_p(CAR(n), CDR(n))) ? F_ASSIGN_SELF : F_ASSIGN;
      
      ADD_NODE_REF2(CAR(n),
      ADD_NODE_REF2(CAR(n),
      ADD_NODE_REF2(CDR(n),
        tmp1 = mknode( oper, mksoftcastnode(type,mkopernode( "`*", CAR(n), CDR(n) )), CAR(n) );
      )));
      goto use_tmp1;
    }
  }
  break;

case F_OR_EQ:
  if (!CAR(n)) {
  } else if (!CDR(n)) {
  } else {
    if (CDR(n)->token == F_APPLY) {
      if (!CADR(n)) {
      } else {
        if (CADR(n)->token == F_CONSTANT) {
          if ((TYPEOF(CADR(n)->u.sval) == T_FUNCTION) &&
              (SUBTYPEOF(CADR(n)->u.sval) == FUNCTION_BUILTIN) &&
              (CADR(n)->u.sval.u.efun->function == f_aggregate_mapping)) {
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "Match: ""F_OR_EQ{955}(0 = *{956}, F_APPLY{957}(F_CONSTANT{958}[TYPEOF(CADR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CADR(n)->u.sval) == FUNCTION_BUILTIN][CADR(n)->u.sval.u.efun->function == f_aggregate_mapping], 1 = *{959}))""\n");
              }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "=> ""F_APPEND_MAPPING{960}""\n");
              }
#endif /* PIKE_DEBUG */
            {
              ADD_NODE_REF2(CAR(n),
              ADD_NODE_REF2(CDDR(n),
                tmp1 = mknode(F_APPEND_MAPPING, CAR(n), CDDR(n));
              ));
              goto use_tmp1;
            }
          }
        }
      }
    }
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_OR_EQ{1408}(0 = +{1409}, 1 = *{1410})""\n");
      }
#endif /* PIKE_DEBUG */
    {
      struct pike_type *type = CAR(n)->type;
      int oper = ((CAR(n)->tree_info&(OPT_SIDE_EFFECT|OPT_ASSIGNMENT)) ||
    	      depend_p(CAR(n), CDR(n))) ? F_ASSIGN_SELF : F_ASSIGN;
      
      ADD_NODE_REF2(CAR(n),
      ADD_NODE_REF2(CAR(n),
      ADD_NODE_REF2(CDR(n),
        tmp1 = mknode( oper, mksoftcastnode(type,mkopernode( "`|", CAR(n), CDR(n) )), CAR(n) );
      )));
      goto use_tmp1;
    }
  }
  break;

case F_POP_VALUE:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_POP_VALUE{137}(-{138}, *)""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""-{140}""\n");
      }
#endif /* PIKE_DEBUG */
    goto zap_node;
  } else {
    if (CAR(n)->token == '?') {
      if (!CDAR(n)) {
      } else {
        if (CDAR(n)->token == ':') {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_POP_VALUE{225}('?'{226}(0 = *{227}, ':'{228}(1 = *{229}, 2 = *{230})), *)""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr,
                      "Setting line position to %s:%ld\n",
                      CAR(n)->current_file->str,
                      (long)CAR(n)->line_number);
            }
#endif /* PIKE_DEBUG */
          c->lex.current_line = CAR(n)->line_number;
          c->lex.current_file = CAR(n)->current_file;
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""'?'{232}""\n");
            }
#endif /* PIKE_DEBUG */
          {
            ADD_NODE_REF2(CAAR(n),
            ADD_NODE_REF2(CADAR(n),
            ADD_NODE_REF2(CDDAR(n),
              tmp1 = mknode('?', CAAR(n), mknode(':', mknode(F_POP_VALUE, CADAR(n), 0), mknode(F_POP_VALUE, CDDAR(n), 0)));
            )));
            goto use_tmp1;
          }
        }
      }
    } else if (CAR(n)->token == F_BREAK) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{177}(0 = F_BREAK{178}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{180}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_CASE) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{181}(0 = F_CASE{182}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{184}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_CASE_RANGE) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{185}(0 = F_CASE_RANGE{186}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{188}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_CONSTANT) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{145}(F_CONSTANT{146}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""-{148}""\n");
        }
#endif /* PIKE_DEBUG */
      goto zap_node;
    } else if (CAR(n)->token == F_CONTINUE) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{173}(0 = F_CONTINUE{174}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{176}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_DEC_LOOP) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{205}(0 = F_DEC_LOOP{206}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{208}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_DEC_NEQ_LOOP) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{213}(0 = F_DEC_NEQ_LOOP{214}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{216}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_DEFAULT) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{189}(0 = F_DEFAULT{190}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{192}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_EXTERNAL) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{161}(F_EXTERNAL{162}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""-{164}""\n");
        }
#endif /* PIKE_DEBUG */
      goto zap_node;
    } else if (CAR(n)->token == F_FOR) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{193}(0 = F_FOR{194}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{196}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_FOREACH) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{197}(0 = F_FOREACH{198}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{200}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_GET_SET) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{165}(F_GET_SET{166}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""-{168}""\n");
        }
#endif /* PIKE_DEBUG */
      goto zap_node;
    } else if (CAR(n)->token == F_GLOBAL) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{157}(F_GLOBAL{158}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""-{160}""\n");
        }
#endif /* PIKE_DEBUG */
      goto zap_node;
    } else if (CAR(n)->token == F_INC_LOOP) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{201}(0 = F_INC_LOOP{202}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{204}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_INC_NEQ_LOOP) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{209}(0 = F_INC_NEQ_LOOP{210}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{212}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_LOCAL) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{153}(F_LOCAL{154}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""-{156}""\n");
        }
#endif /* PIKE_DEBUG */
      goto zap_node;
    } else if (CAR(n)->token == F_LOOP) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{217}(0 = F_LOOP{218}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{220}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_POP_VALUE) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{141}(0 = F_POP_VALUE{142}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{144}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_RETURN) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{169}(0 = F_RETURN{170}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{172}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_SWITCH) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{221}(0 = F_SWITCH{222}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{224}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    }
    if ((node_is_tossable(CAR(n)))) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{149}(+{150}[node_is_tossable(CAR(n))], *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""-{152}""\n");
        }
#endif /* PIKE_DEBUG */
      goto zap_node;
    }
  }
  break;

case F_PUSH_ARRAY:
  if (!CAR(n)) {
  } else {
    if (CAR(n)->token == F_APPLY) {
      if (!CAAR(n)) {
      } else {
        if (CAAR(n)->token == F_CONSTANT) {
          if ((TYPEOF(CAAR(n)->u.sval) == T_FUNCTION) &&
              (SUBTYPEOF(CAAR(n)->u.sval) == FUNCTION_BUILTIN) &&
              (CAAR(n)->u.sval.u.efun->function == debug_f_aggregate)) {
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "Match: ""F_PUSH_ARRAY{20}(F_APPLY{21}(F_CONSTANT{22}[TYPEOF(CAAR(n)->u.sval) == T_FUNCTION][SUBTYPEOF(CAAR(n)->u.sval) == FUNCTION_BUILTIN][CAAR(n)->u.sval.u.efun->function == debug_f_aggregate], 0 = *{23}), *)""\n");
              }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "=> ""0 = *{25}""\n");
              }
#endif /* PIKE_DEBUG */
            {
              ADD_NODE_REF2(CDAR(n),
                tmp1 = CDAR(n);
              );
              goto use_tmp1;
            }
          }
        }
      }
    } else if (CAR(n)->token == F_CONSTANT) {
      if ((TYPEOF(CAR(n)->u.sval) == T_ARRAY)) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_PUSH_ARRAY{26}(0 = F_CONSTANT{27}[TYPEOF(CAR(n)->u.sval) == T_ARRAY], *)""\n");
          }
#endif /* PIKE_DEBUG */
        {
            struct array *a = CAR(n)->u.sval.u.array;
            node *res = NULL;
            int i;
            for(i=0; i<a->size; i++) {
              if (res) {
        	res = mknode(F_ARG_LIST, res, mksvaluenode(a->item+i));
              } else {
        	/* i is always 0 here. */
        	res = mksvaluenode(a->item);
              }
            }
            
          tmp1 = res;
          goto use_tmp1;
          }
      }
    }
  }
  break;

case F_RANGE:
  if (!CDR(n)) {
  } else {
    if (CDR(n)->token == ':') {
      if (!CADR(n)) {
      } else if (!CDDR(n)) {
      } else {
        if (CADR(n)->token == F_RANGE_FROM_BEG) {
          if (!CAADR(n)) {
          } else {
            if (CAADR(n)->token == F_CONSTANT) {
              if ((TYPEOF(CAADR(n)->u.sval) == T_INT)) {
                if (!CDDR(n)) {
                } else {
                  if (CDDR(n)->token == F_RANGE_FROM_BEG) {
                    if (!CADDR(n)) {
                    } else {
                      if (CADDR(n)->token == F_CONSTANT) {
                        if ((TYPEOF(CADDR(n)->u.sval) == T_INT) &&
                            (CADDR(n)->u.sval.u.integer < CAADR(n)->u.sval.u.integer)) {
#ifdef PIKE_DEBUG
                            if (l_flag > 4) {
                              fprintf(stderr, "Match: ""F_RANGE{279}(0 = *{280}, ':'{281}(F_RANGE_FROM_BEG{282}(1 = F_CONSTANT{283}[TYPEOF(CAADR(n)->u.sval) == T_INT], *), F_RANGE_FROM_BEG{285}(F_CONSTANT{286}[TYPEOF(CADDR(n)->u.sval) == T_INT][CADDR(n)->u.sval.u.integer < CAADR(n)->u.sval.u.integer], *)))""\n");
                            }
#endif /* PIKE_DEBUG */
                          {
                            /* Objects may want to use the range for obscure purposes. */
                            if (!match_types(object_type_string, CAR(n)->type)) {
                              yywarning("Range is always empty.");
                              if (pike_types_le(CAR(n)->type, string_type_string)) {
                                
                            tmp1 = mkstrnode(empty_pike_string);
                            goto use_tmp1;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        } else if (CADR(n)->token == F_RANGE_OPEN) {
          if (!CDDR(n)) {
          } else {
            if (CDDR(n)->token == F_RANGE_OPEN) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_RANGE{274}(0 = *{275}, ':'{276}(F_RANGE_OPEN{277}, F_RANGE_OPEN{278}))""\n");
                }
#endif /* PIKE_DEBUG */
              {
                /* Objects may want to use the range for obscure purposes. */
                if (!match_types(object_type_string, CAR(n)->type)) {
                  yywarning("Redundant range operator.");
                  
                ADD_NODE_REF2(CAR(n),
                  tmp1 = CAR(n);
                );
                goto use_tmp1;
                }
              }
            }
          }
        }
        if (CDDR(n)->token == F_RANGE_FROM_BEG) {
          if (!CADDR(n)) {
          } else {
            if (CADDR(n)->token == F_CONSTANT) {
              if ((TYPEOF(CADDR(n)->u.sval) == T_FLOAT) &&
                  (CADDR(n)->u.sval.u.float_number < 0.0)) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_RANGE{267}(*, ':'{269}(*, F_RANGE_FROM_BEG{271}(F_CONSTANT{272}[TYPEOF(CADDR(n)->u.sval) == T_FLOAT][CADDR(n)->u.sval.u.float_number < 0.0], *)))""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  yywarning("Range end is negative.");
                }
              }
              if ((TYPEOF(CADDR(n)->u.sval) == T_INT) &&
                  (CADDR(n)->u.sval.u.integer < 0)) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_RANGE{260}(*, ':'{262}(*, F_RANGE_FROM_BEG{264}(F_CONSTANT{265}[TYPEOF(CADDR(n)->u.sval) == T_INT][CADDR(n)->u.sval.u.integer < 0], *)))""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  yywarning("Range end is negative.");
                }
              }
            }
          }
        }
      }
    }
  }
  break;

case F_RETURN:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_RETURN{14}(-{15}, *)""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""F_RETURN{17}""\n");
      }
#endif /* PIKE_DEBUG */
    {
      tmp1 = mknode(F_RETURN, mkintnode(0), 0);
      goto use_tmp1;
    }
  }
  break;

case F_RSH_EQ:
  if (!CAR(n)) {
  } else {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_RSH_EQ{1417}(0 = +{1418}, 1 = *{1419})""\n");
      }
#endif /* PIKE_DEBUG */
    {
      struct pike_type *type = CAR(n)->type;
      int oper = ((CAR(n)->tree_info&(OPT_SIDE_EFFECT|OPT_ASSIGNMENT)) ||
    	      depend_p(CAR(n), CDR(n))) ? F_ASSIGN_SELF : F_ASSIGN;
      
      ADD_NODE_REF2(CAR(n),
      ADD_NODE_REF2(CAR(n),
      ADD_NODE_REF2(CDR(n),
        tmp1 = mknode( oper, mksoftcastnode(type,mkopernode( "`>>", CAR(n), CDR(n))), CAR(n) );
      )));
      goto use_tmp1;
    }
  }
  break;

case F_SSCANF:
  if (!CAR(n)) {
  } else {
    if (CAR(n)->token == ':') {
      if (!CAAR(n)) {
      } else {
        if (!CDAR(n)) {
        } else {
          if (CDAR(n)->token == F_ARG_LIST) {
            if (!CADAR(n)) {
            } else {
              if (CADAR(n)->token == F_RANGE) {
                if (!CAADAR(n)) {
                } else {
                  if (( pike_types_le(CAADAR(n)->type,
						     string_type_string))) {
                    if (!CDADAR(n)) {
                    } else {
                      if (CDADAR(n)->token == ':') {
                        if (!CADADAR(n)) {
                        } else {
                          if (CADADAR(n)->token == F_RANGE_FROM_BEG) {
                            if (!CDADADAR(n)) {
                              if (!CAADADAR(n)) {
                              } else {
                                if (( pike_types_le(CAADADAR(n)->type,
									  int_type_string))) {
                                  if (!CDDADAR(n)) {
                                  } else {
                                    if (CDDADAR(n)->token == F_RANGE_OPEN) {
                                      if (!CDDAR(n)) {
                                      } else {
#ifdef PIKE_DEBUG
                                          if (l_flag > 4) {
                                            fprintf(stderr, "Match: ""F_SSCANF{101}(':'{102}(4 = +{103}, F_ARG_LIST{104}(F_RANGE{105}(0 = +{106}[ pike_types_le(CAADAR(n)->type,\n"
                                        "\t\t\t\t\t\t     string_type_string)], ':'{107}(F_RANGE_FROM_BEG{108}(1 = +{109}[ pike_types_le(CAADADAR(n)->type,\n"
                                        "\t\t\t\t\t\t\t\t\t  int_type_string)], -{110}), F_RANGE_OPEN{111})), 2 = +{112})), 3 = *{113})""\n");
                                          }
#endif /* PIKE_DEBUG */
                                        {
                                          struct pike_string *percent_star_string;
                                          struct pike_string *s_string;
                                          MAKE_CONST_STRING(percent_star_string, "%*!");
                                          MAKE_CONST_STRING(s_string, "s");
                                          
                                          ADD_NODE_REF2(CDR(n),
                                          ADD_NODE_REF2(CDDAR(n),
                                          ADD_NODE_REF2(CAADADAR(n),
                                          ADD_NODE_REF2(CAADAR(n),
                                          ADD_NODE_REF2(CAAR(n),
                                            tmp1 = mkopernode("`-",
                                        		  mknode(F_LOR,
                                        			 mknode(F_SSCANF,
                                        				mknode(':', CAAR(n),
                                        				mknode(F_ARG_LIST, CAADAR(n),
                                        				       mkopernode("`+",
                                        						  mknode(F_ARG_LIST,
                                        							 mkstrnode(percent_star_string),
                                        							 CAADADAR(n)),
                                        						  mknode(F_ARG_LIST,
                                        							 mkstrnode(s_string),
                                        							 CDDAR(n))))),
                                        				CDR(n)),
                                        			 mkintnode(1)),
                                        		  mkintnode(1));
                                          )))));
                                          goto use_tmp1;
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  break;

case F_SUB_EQ:
  if (!CAR(n)) {
  } else if (!CDR(n)) {
  } else {
    if (CDR(n)->token == F_CONSTANT) {
      if ((TYPEOF(CDR(n)->u.sval) == T_INT) &&
          ((CDR(n)->u.sval.u.integer) == -1)) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_SUB_EQ{933}(0 = *{934}, 1 = F_CONSTANT{935}[TYPEOF(CDR(n)->u.sval) == T_INT][(CDR(n)->u.sval.u.integer) == -1])""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_INC{936}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAR(n),
            tmp1 = mknode(F_INC, CAR(n), 0);
          );
          goto use_tmp1;
        }
      }
      if ((TYPEOF(CDR(n)->u.sval) == T_INT) &&
          ((CDR(n)->u.sval.u.integer) == 1)) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_SUB_EQ{927}(0 = *{928}, 1 = F_CONSTANT{929}[TYPEOF(CDR(n)->u.sval) == T_INT][(CDR(n)->u.sval.u.integer) == 1])""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_DEC{930}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAR(n),
            tmp1 = mknode(F_DEC, CAR(n), 0);
          );
          goto use_tmp1;
        }
      }
    }
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_SUB_EQ{1402}(0 = +{1403}, 1 = *{1404})""\n");
      }
#endif /* PIKE_DEBUG */
    {
      struct pike_type *type = CAR(n)->type;
      int oper = ((CAR(n)->tree_info&(OPT_SIDE_EFFECT|OPT_ASSIGNMENT)) ||
    	      depend_p(CAR(n), CDR(n))) ? F_ASSIGN_SELF : F_ASSIGN;
      
      ADD_NODE_REF2(CAR(n),
      ADD_NODE_REF2(CAR(n),
      ADD_NODE_REF2(CDR(n),
        tmp1 = mknode( oper, mksoftcastnode(type,mkopernode( "`-", CAR(n), CDR(n) )), CAR(n) );
      )));
      goto use_tmp1;
    }
    if (( CAR(n)->token != F_AUTO_MAP_MARKER )) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == F_CONSTANT) {
          if ((TYPEOF(CDR(n)->u.sval) == T_INT) &&
              (!(CDR(n)->u.sval.u.integer))) {
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "Match: ""F_SUB_EQ{923}(0 = +{924}[ CAR(n)->token != F_AUTO_MAP_MARKER ], 1 = F_CONSTANT{925}[TYPEOF(CDR(n)->u.sval) == T_INT][!(CDR(n)->u.sval.u.integer)])""\n");
              }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "=> ""0 = *{926}""\n");
              }
#endif /* PIKE_DEBUG */
            goto use_car;
          }
        }
      }
    }
  }
  break;

case F_XOR_EQ:
  if (!CAR(n)) {
  } else {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_XOR_EQ{1411}(0 = +{1412}, 1 = *{1413})""\n");
      }
#endif /* PIKE_DEBUG */
    {
      struct pike_type *type = CAR(n)->type;
      int oper = ((CAR(n)->tree_info&(OPT_SIDE_EFFECT|OPT_ASSIGNMENT)) ||
    	      depend_p(CAR(n), CDR(n))) ? F_ASSIGN_SELF : F_ASSIGN;
      
      ADD_NODE_REF2(CAR(n),
      ADD_NODE_REF2(CAR(n),
      ADD_NODE_REF2(CDR(n),
        tmp1 = mknode( oper, mksoftcastnode(type,mkopernode( "`^", CAR(n), CDR(n) )), CAR(n) );
      )));
      goto use_tmp1;
    }
  }
  break;

