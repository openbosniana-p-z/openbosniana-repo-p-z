#if __VERSION__ > 7.6
#warning fifo.h is deprecated.
#endif
import Thread;
