proftpd-mod_kafka
=================

Status
------
[![GitHub Actions CI Status](https://github.com/Castaglia/proftpd-mod_kafka/actions/workflows/ci.yml/badge.svg?branch=master)](https://github.com/Castaglia/proftpd-mod_kafka/actions/workflows/ci.yml)
[![License](https://img.shields.io/badge/license-GPL-brightgreen.svg)](https://img.shields.io/badge/license-GPL-brightgreen.svg)


Synopsis
--------

The `mod_kafka` module for ProFTPD allows for sending log messages, as JSON,
to Kafka brokers using the [librdkafka](https://github.com/edenhill/librdkafka)
client library.

See the [mod_kafka.html](https://htmlpreview.github.io/?https://github.com/Castaglia/proftpd-mod_kafka/blob/master/mod_kafka.html) documentation for more details.
