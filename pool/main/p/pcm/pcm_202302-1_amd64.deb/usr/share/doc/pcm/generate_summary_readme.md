Step 1

```pip3 install pipreqs```

Step 2

```cd /path/to/pcm/scripts```

Step 3

```python3 -m  pipreqs.pipreqs --encoding utf-8 .```

Step 4

```pip3 install -r requirements.txt```

Step 5

```python3 generate_summary.py --help```

Step 6

```python3 generate_summary.py <filename.csv> -{argument1} -{argument2} ....-{argumentN}```
 

