# Slim example

1. Run php server

      ```text
      $ php -S localhost:8888 -t example /usr/share/doc/php-slim/examples/index.php
      ```

2. Open browser

      Open http://localhost:8888 in your browser and you will see 'Welcome to Slim!'
