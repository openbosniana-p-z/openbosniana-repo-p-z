<?php

namespace Pheanstalk;

/**
 * An exception originating from the Pheanstalk package.
 *
 * @author  Paul Annesley
 */
class Exception extends \Exception
{
}
