<?php

namespace Pheanstalk\Exception;

/**
 * An exception relating to the connection socket.
 *
 * @author  Paul Annesley
 */
class SocketException extends ClientException
{
}
