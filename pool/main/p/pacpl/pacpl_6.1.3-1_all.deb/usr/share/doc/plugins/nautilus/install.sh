#!/bin/sh

echo
echo "Installing Nautilus Action Script......"
echo
ln -sv /usr/share/pacpl/bin/PACPL-Convert $HOME/.local/share/nautilus/scripts
echo
sleep 1
echo "Done.."
