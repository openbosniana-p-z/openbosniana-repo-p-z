var searchData=
[
  ['next_5fprime_0',['next_prime',['../structprimesieve_1_1iterator.html#a78a262b57c6125b7cf1550e757589cbe',1,'primesieve::iterator']]],
  ['nth_5fprime_1',['nth_prime',['../primesieve_8hpp.html#a559e8ba0e9b3b9c8b3a75ca9419a1afb',1,'primesieve']]]
];
