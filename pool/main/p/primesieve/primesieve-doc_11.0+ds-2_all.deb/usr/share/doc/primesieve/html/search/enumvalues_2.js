var searchData=
[
  ['short_5fprimes_0',['SHORT_PRIMES',['../primesieve_8h.html#a06fc87d81c62e9abb8790b6e5713c55bab7448409fcfa6db6af17659bb8f5dd62',1,'primesieve.h']]]
];
