var searchData=
[
  ['primesieve_5ferror_0',['PRIMESIEVE_ERROR',['../primesieve_8h.html#aa15f4d1456167707e37c0d6de61a86e3',1,'primesieve.h']]]
];
