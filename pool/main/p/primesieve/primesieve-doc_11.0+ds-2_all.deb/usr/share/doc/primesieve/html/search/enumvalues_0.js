var searchData=
[
  ['int16_5fprimes_0',['INT16_PRIMES',['../primesieve_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba53ac418c6ca05f258d22b93c98efc854',1,'primesieve.h']]],
  ['int32_5fprimes_1',['INT32_PRIMES',['../primesieve_8h.html#a06fc87d81c62e9abb8790b6e5713c55baa71fa0872d80f6079a5f80e47fb87cec',1,'primesieve.h']]],
  ['int64_5fprimes_2',['INT64_PRIMES',['../primesieve_8h.html#a06fc87d81c62e9abb8790b6e5713c55baf8809aba6f85c1d3532132f0f72601c5',1,'primesieve.h']]],
  ['int_5fprimes_3',['INT_PRIMES',['../primesieve_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba997df1c563fc9a3cc67950ef91afbf7e',1,'primesieve.h']]]
];
