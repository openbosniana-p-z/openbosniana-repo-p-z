var searchData=
[
  ['set_5fnum_5fthreads_0',['set_num_threads',['../primesieve_8hpp.html#a620522a113c81237cd8ae9a5a058c0f1',1,'primesieve']]],
  ['set_5fsieve_5fsize_1',['set_sieve_size',['../primesieve_8hpp.html#a83a4e509144f3da3ee24d9e0d0d10e8d',1,'primesieve']]]
];
