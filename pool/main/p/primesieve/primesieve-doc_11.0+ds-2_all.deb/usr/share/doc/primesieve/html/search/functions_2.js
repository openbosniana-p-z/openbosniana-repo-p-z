var searchData=
[
  ['iterator_0',['iterator',['../structprimesieve_1_1iterator.html#a91f7ef7e48f90dfdd4539800286b7ad7',1,'primesieve::iterator::iterator() noexcept'],['../structprimesieve_1_1iterator.html#a6ffa2cd12864a115846bae49e664b2ed',1,'primesieve::iterator::iterator(uint64_t start, uint64_t stop_hint=std::numeric_limits&lt; uint64_t &gt;::max()) noexcept'],['../structprimesieve_1_1iterator.html#a7a3a02497cf18280a945a61c300ac639',1,'primesieve::iterator::iterator(const iterator &amp;)=delete'],['../structprimesieve_1_1iterator.html#ab93b0314e7f95c2d8d48f76f67308202',1,'primesieve::iterator::iterator(iterator &amp;&amp;) noexcept']]]
];
