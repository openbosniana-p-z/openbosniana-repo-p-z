var searchData=
[
  ['generate_5fn_5fprimes_0',['generate_n_primes',['../primesieve_8hpp.html#a349c51938884cf1a77b04e32218b68ef',1,'primesieve::generate_n_primes(uint64_t n, vect *primes)'],['../primesieve_8hpp.html#a19e2278ebd142d847fdf4bd61e56fc79',1,'primesieve::generate_n_primes(uint64_t n, uint64_t start, vect *primes)']]],
  ['generate_5fprimes_1',['generate_primes',['../primesieve_8hpp.html#a2cc143dc1954a3a09edaddd18a684da6',1,'primesieve::generate_primes(uint64_t stop, vect *primes)'],['../primesieve_8hpp.html#a5c6a4f51857c58f38660aa462205028c',1,'primesieve::generate_primes(uint64_t start, uint64_t stop, vect *primes)']]],
  ['get_5fmax_5fstop_2',['get_max_stop',['../primesieve_8hpp.html#ab9b2f9df590eee04918ee2674cfc447a',1,'primesieve']]],
  ['get_5fnum_5fthreads_3',['get_num_threads',['../primesieve_8hpp.html#ac0f5ac18ae2ed2ab1dc5c686894919c0',1,'primesieve']]],
  ['get_5fsieve_5fsize_4',['get_sieve_size',['../primesieve_8hpp.html#a4239a2d00a804cd0f49cc754e8b7c33d',1,'primesieve']]]
];
