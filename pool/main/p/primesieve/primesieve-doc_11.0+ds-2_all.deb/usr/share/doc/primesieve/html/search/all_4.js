var searchData=
[
  ['long_5fprimes_0',['LONG_PRIMES',['../primesieve_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba2fcc5349ef8cb2c06cdde994fbc8ed55',1,'primesieve.h']]],
  ['longlong_5fprimes_1',['LONGLONG_PRIMES',['../primesieve_8h.html#a06fc87d81c62e9abb8790b6e5713c55bab8bdafd4db61276586e5178d5047aba5',1,'primesieve.h']]]
];
