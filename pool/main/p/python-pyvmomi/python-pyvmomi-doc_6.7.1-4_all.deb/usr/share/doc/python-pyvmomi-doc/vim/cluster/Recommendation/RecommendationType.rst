.. _vim.cluster.Recommendation: ../../../vim/cluster/Recommendation.rst

.. _vim.cluster.Recommendation.RecommendationType: ../../../vim/cluster/Recommendation/RecommendationType.rst

vim.cluster.Recommendation.RecommendationType
=============================================
  Pre-defined constants for possible recommendation types. Virtual Center uses this information to coordinate with the clients.
  :contained by: `vim.cluster.Recommendation`_

  :type: `vim.cluster.Recommendation.RecommendationType`_

  :name: V1

values:
--------

V1
   V1
