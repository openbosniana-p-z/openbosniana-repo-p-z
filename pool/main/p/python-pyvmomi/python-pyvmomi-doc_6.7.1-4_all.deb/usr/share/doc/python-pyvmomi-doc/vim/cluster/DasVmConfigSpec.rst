.. _vim.option.ArrayUpdateSpec: ../../vim/option/ArrayUpdateSpec.rst

.. _vim.cluster.DasVmConfigInfo: ../../vim/cluster/DasVmConfigInfo.rst


vim.cluster.DasVmConfigSpec
===========================
  An incremental update to the per-virtual-machine vSphere HA configuration.
:extends: vim.option.ArrayUpdateSpec_

Attributes:
    info (`vim.cluster.DasVmConfigInfo`_, optional):

