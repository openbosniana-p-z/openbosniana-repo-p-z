.. _vim.Task: ../vim/Task.rst

.. _VI API 2.5: ../vim/version.rst#vimversionversion2


vim.VirtualizationManager
=========================
  The VirtualizationManager is the interface for discover and consolidate host and services from physical environment to virtualization environment.


:since: `VI API 2.5`_


Attributes
----------


Methods
-------


