.. _str: https://docs.python.org/2/library/stdtypes.html

.. _vim.Description: ../vim/Description.rst


vim.ElementDescription
======================
  Static strings used for describing an object model string or enumeration.
:extends: vim.Description_

Attributes:
    key (`str`_):

       Enumeration or literal ID being described.
