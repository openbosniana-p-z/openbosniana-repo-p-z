.. _vmodl.DynamicData: ../vmodl/DynamicData.rst

.. _vim.ElementDescription: ../vim/ElementDescription.rst


vim.AuthorizationDescription
============================
  Static strings for authorization.
:extends: vmodl.DynamicData_

Attributes:
    privilege ([`vim.ElementDescription`_]):

       Description of the privilege.
    privilegeGroup ([`vim.ElementDescription`_]):

       Description of a category of similar privileges, grouped together for convenience.
