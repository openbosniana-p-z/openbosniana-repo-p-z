.. _vSphere API 4.1: ../../vim/version.rst#vimversionversion6

.. _vim.cluster.GroupInfo: ../../vim/cluster/GroupInfo.rst

.. _vim.option.ArrayUpdateSpec: ../../vim/option/ArrayUpdateSpec.rst


vim.cluster.GroupSpec
=====================
  An incremental update to the cluster-wide groups.
:extends: vim.option.ArrayUpdateSpec_
:since: `vSphere API 4.1`_

Attributes:
    info (`vim.cluster.GroupInfo`_, optional):

