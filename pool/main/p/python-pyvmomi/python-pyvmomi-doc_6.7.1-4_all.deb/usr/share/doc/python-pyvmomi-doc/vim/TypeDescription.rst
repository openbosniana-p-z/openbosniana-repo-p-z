.. _str: https://docs.python.org/2/library/stdtypes.html

.. _vim.Description: ../vim/Description.rst


vim.TypeDescription
===================
  Static strings used for describing an object type.
:extends: vim.Description_

Attributes:
    key (`str`_):

       Type being described
