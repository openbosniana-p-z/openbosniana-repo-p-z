.. _vSphere API 5.5: ../../../vim/version.rst#vimversionversion9

.. _vim.dvs.TrafficRule.Action: ../../../vim/dvs/TrafficRule/Action.rst


vim.dvs.TrafficRule.PuntAction
==============================
  This class defines network rule action to punt. i.e, forward packets to an associated slow-path service Virtual Machine.
:extends: vim.dvs.TrafficRule.Action_
:since: `vSphere API 5.5`_

Attributes:
