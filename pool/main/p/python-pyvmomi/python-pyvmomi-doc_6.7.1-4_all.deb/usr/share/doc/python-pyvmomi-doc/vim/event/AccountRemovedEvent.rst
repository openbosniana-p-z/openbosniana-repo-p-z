.. _str: https://docs.python.org/2/library/stdtypes.html

.. _bool: https://docs.python.org/2/library/stdtypes.html

.. _vim.event.HostEvent: ../../vim/event/HostEvent.rst


vim.event.AccountRemovedEvent
=============================
  This event records that an account was removed from a host.
:extends: vim.event.HostEvent_

Attributes:
    account (`str`_):

    group (`bool`_):

