.. _vSphere API 5.5: ../../../vim/version.rst#vimversionversion9

.. _vmodl.DynamicData: ../../../vmodl/DynamicData.rst


vim.dvs.TrafficRule.Action
==========================
  This class is the base class for network rule action.
:extends: vmodl.DynamicData_
:since: `vSphere API 5.5`_

Attributes:
