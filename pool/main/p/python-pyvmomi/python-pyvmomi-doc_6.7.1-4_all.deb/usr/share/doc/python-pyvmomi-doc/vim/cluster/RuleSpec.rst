.. _vim.cluster.RuleInfo: ../../vim/cluster/RuleInfo.rst

.. _vim.option.ArrayUpdateSpec: ../../vim/option/ArrayUpdateSpec.rst


vim.cluster.RuleSpec
====================
  An incremental update to the cluster rules.
:extends: vim.option.ArrayUpdateSpec_

Attributes:
    info (`vim.cluster.RuleInfo`_, optional):

