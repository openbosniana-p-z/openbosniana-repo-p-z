.. _object: https://docs.python.org/2/library/stdtypes.html

.. _vmodl.DynamicData: ../../vmodl/DynamicData.rst


vim.action.MethodActionArgument
===============================
  This data object type defines a named argument for an operation.
:extends: vmodl.DynamicData_

Attributes:
    value (`object`_, optional):

       The value of the argument.
