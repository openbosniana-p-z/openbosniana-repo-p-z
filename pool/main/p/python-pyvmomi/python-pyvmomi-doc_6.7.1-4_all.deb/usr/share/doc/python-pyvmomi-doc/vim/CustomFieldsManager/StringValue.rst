.. _str: https://docs.python.org/2/library/stdtypes.html

.. _vim.CustomFieldsManager.Value: ../../vim/CustomFieldsManager/Value.rst


vim.CustomFieldsManager.StringValue
===================================
  Subtype for string values (currently the only supported type).
:extends: vim.CustomFieldsManager.Value_

Attributes:
    value (`str`_):

       Value assigned to the custom field.
