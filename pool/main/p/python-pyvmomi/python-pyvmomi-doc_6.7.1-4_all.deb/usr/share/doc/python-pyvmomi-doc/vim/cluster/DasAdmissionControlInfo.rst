.. _vSphere API 4.0: ../../vim/version.rst#vimversionversion5

.. _vmodl.DynamicData: ../../vmodl/DynamicData.rst


vim.cluster.DasAdmissionControlInfo
===================================
  Base class for admission control related information of a vSphere HA cluster.
:extends: vmodl.DynamicData_
:since: `vSphere API 4.0`_

Attributes:
