.. _str: https://docs.python.org/2/library/stdtypes.html

.. _vim.LicenseManager.LicenseSource: ../../vim/LicenseManager/LicenseSource.rst


vim.LicenseManager.LocalLicense
===============================
  Specify license key data to store locally.
:extends: vim.LicenseManager.LicenseSource_

Attributes:
    licenseKeys (`str`_):

       The size of this string is implementation dependent. It must contain ASCII or ISO Latin-1 characters only.
