.. _vim.HostSystem: ../../../vim/HostSystem.rst

.. _vSphere API 4.1: ../../../vim/version.rst#vimversionversion6

.. _vim.dvs.DistributedVirtualSwitchManager.HostDvsFilterSpec: ../../../vim/dvs/DistributedVirtualSwitchManager/HostDvsFilterSpec.rst


vim.dvs.DistributedVirtualSwitchManager.HostArrayFilter
=======================================================
  Check host compatibility against all hosts specified in the array.
:extends: vim.dvs.DistributedVirtualSwitchManager.HostDvsFilterSpec_
:since: `vSphere API 4.1`_

Attributes:
    host ([`vim.HostSystem`_]):

       List of hosts to consider.
