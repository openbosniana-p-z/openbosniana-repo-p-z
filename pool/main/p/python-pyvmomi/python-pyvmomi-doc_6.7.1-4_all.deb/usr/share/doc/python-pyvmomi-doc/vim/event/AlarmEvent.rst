.. _vim.event.Event: ../../vim/event/Event.rst

.. _vim.event.AlarmEventArgument: ../../vim/event/AlarmEventArgument.rst


vim.event.AlarmEvent
====================
  This event is an alarm events.
:extends: vim.event.Event_

Attributes:
    alarm (`vim.event.AlarmEventArgument`_):

       The associated alarm object.
