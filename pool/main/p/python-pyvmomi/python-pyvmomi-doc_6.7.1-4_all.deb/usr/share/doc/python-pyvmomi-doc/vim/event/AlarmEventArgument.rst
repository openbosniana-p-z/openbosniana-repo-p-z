.. _vim.alarm.Alarm: ../../vim/alarm/Alarm.rst

.. _vim.event.EntityEventArgument: ../../vim/event/EntityEventArgument.rst


vim.event.AlarmEventArgument
============================
  The event argument is an Alarm object.
:extends: vim.event.EntityEventArgument_

Attributes:
    alarm (`vim.alarm.Alarm`_):

       The Alarm object.
