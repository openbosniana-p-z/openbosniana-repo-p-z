.. _VI API 2.5: ../../vim/version.rst#vimversionversion2

.. _vim.cluster.Action: ../../vim/cluster/Action.rst

.. _vim.cluster.DrsMigration: ../../vim/cluster/DrsMigration.rst


vim.cluster.MigrationAction
===========================
  Describes a single VM migration action.
:extends: vim.cluster.Action_
:since: `VI API 2.5`_

Attributes:
    drsMigration (`vim.cluster.DrsMigration`_, optional):

       The details of the migration action
