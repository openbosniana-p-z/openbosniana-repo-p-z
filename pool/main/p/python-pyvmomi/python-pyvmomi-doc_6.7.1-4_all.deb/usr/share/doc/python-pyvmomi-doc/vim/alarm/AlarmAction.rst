.. _vmodl.DynamicData: ../../vmodl/DynamicData.rst


vim.alarm.AlarmAction
=====================
  Action invoked by triggered alarm.This is an abstract type.
:extends: vmodl.DynamicData_

Attributes:
