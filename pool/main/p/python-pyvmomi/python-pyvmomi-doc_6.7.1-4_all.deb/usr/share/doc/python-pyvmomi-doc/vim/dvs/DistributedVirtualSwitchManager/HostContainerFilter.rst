.. _vSphere API 4.1: ../../../vim/version.rst#vimversionversion6

.. _DistributedVirtualSwitchManagerHostContainer: ../../../vim/dvs/DistributedVirtualSwitchManager/HostContainer.rst

.. _vim.dvs.DistributedVirtualSwitchManager.HostContainer: ../../../vim/dvs/DistributedVirtualSwitchManager/HostContainer.rst

.. _vim.dvs.DistributedVirtualSwitchManager.HostDvsFilterSpec: ../../../vim/dvs/DistributedVirtualSwitchManager/HostDvsFilterSpec.rst


vim.dvs.DistributedVirtualSwitchManager.HostContainerFilter
===========================================================
  Check host compatibility against all hosts in this `DistributedVirtualSwitchManagerHostContainer`_ 
:extends: vim.dvs.DistributedVirtualSwitchManager.HostDvsFilterSpec_
:since: `vSphere API 4.1`_

Attributes:
    hostContainer (`vim.dvs.DistributedVirtualSwitchManager.HostContainer`_):

       Container of hosts that are part of the filter.
