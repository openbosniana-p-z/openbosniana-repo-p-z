.. _vSphere API 4.0: ../../../vim/version.rst#vimversionversion5

.. _vim.InheritablePolicy: ../../../vim/InheritablePolicy.rst


vim.dvs.VmwareDistributedVirtualSwitch.VlanSpec
===============================================
  Base class for Vlan Specifiation for ports.
:extends: vim.InheritablePolicy_
:since: `vSphere API 4.0`_

Attributes:
