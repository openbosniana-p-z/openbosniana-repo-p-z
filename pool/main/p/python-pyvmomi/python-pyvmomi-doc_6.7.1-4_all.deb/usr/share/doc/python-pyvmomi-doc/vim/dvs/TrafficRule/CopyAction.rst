.. _vSphere API 5.5: ../../../vim/version.rst#vimversionversion9

.. _vim.dvs.TrafficRule.Action: ../../../vim/dvs/TrafficRule/Action.rst


vim.dvs.TrafficRule.CopyAction
==============================
  This class defines network rule action to copy the packet to an associated slow-path service Virtual Machine and let the original frame continue.
:extends: vim.dvs.TrafficRule.Action_
:since: `vSphere API 5.5`_

Attributes:
