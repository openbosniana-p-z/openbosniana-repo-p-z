.. _int: https://docs.python.org/2/library/stdtypes.html

.. _vSphere API 5.5: ../../../vim/version.rst#vimversionversion9

.. _vim.dvs.TrafficRule.IpPort: ../../../vim/dvs/TrafficRule/IpPort.rst


vim.dvs.TrafficRule.SingleIpPort
================================
  This class defines a Single Port
:extends: vim.dvs.TrafficRule.IpPort_
:since: `vSphere API 5.5`_

Attributes:
    portNumber (`int`_):

       The IP port number.
