.. _bool: https://docs.python.org/2/library/stdtypes.html

.. _vim.event.HostEvent: ../../vim/event/HostEvent.rst

.. _vim.host.LocalAccountManager.AccountSpecification: ../../vim/host/LocalAccountManager/AccountSpecification.rst


vim.event.AccountUpdatedEvent
=============================
  This event records that an account was updated on a host.
:extends: vim.event.HostEvent_

Attributes:
    spec (`vim.host.LocalAccountManager.AccountSpecification`_):

    group (`bool`_):

