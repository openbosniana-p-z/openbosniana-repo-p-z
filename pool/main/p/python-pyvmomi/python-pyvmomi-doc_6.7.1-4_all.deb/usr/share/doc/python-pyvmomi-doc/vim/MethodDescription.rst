.. _str: https://docs.python.org/2/library/stdtypes.html

.. _vim.Description: ../vim/Description.rst


vim.MethodDescription
=====================
  Static strings used for describing an object model method.
:extends: vim.Description_

Attributes:
    key (`str`_):

       Method being described.
