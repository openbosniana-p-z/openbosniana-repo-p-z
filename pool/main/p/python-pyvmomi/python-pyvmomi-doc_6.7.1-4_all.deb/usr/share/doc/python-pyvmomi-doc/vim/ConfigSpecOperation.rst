.. _vim.ConfigSpecOperation: ../vim/ConfigSpecOperation.rst

vim.ConfigSpecOperation
=======================
  Config spec operation type.

  :type: `vim.ConfigSpecOperation`_

  :name: remove

values:
--------

edit
   Indicates the change of an element in the configuration.

add
   Indicates the addition of an element to the configuration.

remove
   Indicates the removal of an element in the configuration.
