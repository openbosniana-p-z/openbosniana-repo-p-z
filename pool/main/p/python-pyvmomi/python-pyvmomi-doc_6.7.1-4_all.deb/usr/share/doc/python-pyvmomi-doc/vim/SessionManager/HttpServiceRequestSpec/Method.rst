.. _vim.SessionManager.HttpServiceRequestSpec: ../../../vim/SessionManager/HttpServiceRequestSpec.rst

.. _vim.SessionManager.HttpServiceRequestSpec.Method: ../../../vim/SessionManager/HttpServiceRequestSpec/Method.rst

vim.SessionManager.HttpServiceRequestSpec.Method
================================================
  HTTP request methods.
  :contained by: `vim.SessionManager.HttpServiceRequestSpec`_

  :type: `vim.SessionManager.HttpServiceRequestSpec.Method`_

  :name: httpConnect

values:
--------

httpGet
   httpGet

httpTrace
   httpTrace

httpHead
   httpHead

httpOptions
   httpOptions

httpDelete
   httpDelete

httpPost
   httpPost

httpConnect
   httpConnect

httpPut
   httpPut
