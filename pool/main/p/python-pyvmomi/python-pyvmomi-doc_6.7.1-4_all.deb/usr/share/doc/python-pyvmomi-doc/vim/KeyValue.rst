.. _str: https://docs.python.org/2/library/stdtypes.html

.. _VI API 2.5: ../vim/version.rst#vimversionversion2

.. _vmodl.DynamicData: ../vmodl/DynamicData.rst


vim.KeyValue
============
  Non-localized key/value pair
:extends: vmodl.DynamicData_
:since: `VI API 2.5`_

Attributes:
    key (`str`_):

       Key.
    value (`str`_):

       Value.
