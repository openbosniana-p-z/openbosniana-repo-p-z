.. _vim.DrsStatsManager.InjectorWorkload: ../../../vim/DrsStatsManager/InjectorWorkload.rst

.. _vim.DrsStatsManager.InjectorWorkload.CorrelationState: ../../../vim/DrsStatsManager/InjectorWorkload/CorrelationState.rst

vim.DrsStatsManager.InjectorWorkload.CorrelationState
=====================================================
  Correlation state as computed by storageRM module on host.
  :contained by: `vim.DrsStatsManager.InjectorWorkload`_

  :type: `vim.DrsStatsManager.InjectorWorkload.CorrelationState`_

  :name: Uncorrelated

values:
--------

Correlated
   Correlated

Uncorrelated
   Uncorrelated
