.. _vim.Datastore: ../../../vim/Datastore.rst

.. _vim.HostSystem: ../../../vim/HostSystem.rst

.. _vSphere API 5.0: ../../../vim/version.rst#vimversionversion7

.. _vmodl.DynamicData: ../../../vmodl/DynamicData.rst


vim.cluster.DasAdvancedRuntimeInfo.HeartbeatDatastoreInfo
=========================================================
  Class for the selection of heartbeat datastores
:extends: vmodl.DynamicData_
:since: `vSphere API 5.0`_

Attributes:
    datastore (`vim.Datastore`_):

    hosts ([`vim.HostSystem`_]):

