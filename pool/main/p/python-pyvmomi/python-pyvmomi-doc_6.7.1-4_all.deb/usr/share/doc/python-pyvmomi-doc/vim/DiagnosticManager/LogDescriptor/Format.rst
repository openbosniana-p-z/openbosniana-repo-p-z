.. _vim.DiagnosticManager.LogDescriptor: ../../../vim/DiagnosticManager/LogDescriptor.rst

.. _vim.DiagnosticManager.LogDescriptor.Format: ../../../vim/DiagnosticManager/LogDescriptor/Format.rst

vim.DiagnosticManager.LogDescriptor.Format
==========================================
  Constants for defined formats. For more information, see the comment for the format property.
  :contained by: `vim.DiagnosticManager.LogDescriptor`_

  :type: `vim.DiagnosticManager.LogDescriptor.Format`_

  :name: plain

values:
--------

plain
   A standard ASCII-based line-based log file.
