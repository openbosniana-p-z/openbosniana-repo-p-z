.. _str: https://docs.python.org/2/library/stdtypes.html

.. _vSphere API 5.0: ../../vim/version.rst#vimversionversion7

.. _vim.SelectionSet: ../../vim/SelectionSet.rst


vim.dvs.DistributedVirtualSwitchSelection
=========================================
  Class to specify selection criteria of vSphere Distributed Switch.
:extends: vim.SelectionSet_
:since: `vSphere API 5.0`_

Attributes:
    dvsUuid (`str`_):

       vSphere Distributed Switch uuid
