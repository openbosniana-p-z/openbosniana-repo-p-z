.. _type: ../vim/PerformanceManager/CounterInfo/StatsType.rst

.. _vmodl.DynamicData: ../vmodl/DynamicData.rst

.. _vim.ElementDescription: ../vim/ElementDescription.rst


vim.PerformanceDescription
==========================
  Static strings for performance metrics.
:extends: vmodl.DynamicData_

Attributes:
    counterType ([`vim.ElementDescription`_]):

       Identifies the `type`_ of the counter.
    statsType ([`vim.ElementDescription`_]):

       Identifies the `type`_ of statistic.
