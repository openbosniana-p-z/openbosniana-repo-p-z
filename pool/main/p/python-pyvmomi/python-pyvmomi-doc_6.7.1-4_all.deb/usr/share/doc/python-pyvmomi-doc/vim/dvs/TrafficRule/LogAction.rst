.. _vSphere API 5.5: ../../../vim/version.rst#vimversionversion9

.. _vim.dvs.TrafficRule.Action: ../../../vim/dvs/TrafficRule/Action.rst


vim.dvs.TrafficRule.LogAction
=============================
  This class defines network rule action to just log the rule.
:extends: vim.dvs.TrafficRule.Action_
:since: `vSphere API 5.5`_

Attributes:
