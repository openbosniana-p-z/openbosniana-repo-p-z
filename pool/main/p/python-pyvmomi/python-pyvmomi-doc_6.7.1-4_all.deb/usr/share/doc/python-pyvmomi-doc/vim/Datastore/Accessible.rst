.. _vim.Datastore: ../../vim/Datastore.rst

.. _vim.Datastore.Accessible: ../../vim/Datastore/Accessible.rst

vim.Datastore.Accessible
========================
  :contained by: `vim.Datastore`_

  :type: `vim.Datastore.Accessible`_

  :name: False

values:
--------

False
   Is not accessible

True
   Is accessible
