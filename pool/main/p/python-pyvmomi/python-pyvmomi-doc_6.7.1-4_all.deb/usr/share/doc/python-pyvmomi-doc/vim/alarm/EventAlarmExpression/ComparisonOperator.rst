.. _vim.alarm.EventAlarmExpression: ../../../vim/alarm/EventAlarmExpression.rst

.. _vim.alarm.EventAlarmExpression.ComparisonOperator: ../../../vim/alarm/EventAlarmExpression/ComparisonOperator.rst

vim.alarm.EventAlarmExpression.ComparisonOperator
=================================================
  Basic Comparison operators
  :contained by: `vim.alarm.EventAlarmExpression`_

  :type: `vim.alarm.EventAlarmExpression.ComparisonOperator`_

  :name: doesNotEndWith

values:
--------

startsWith
   attribute starts with specified value

notEqualTo
   attribute does not equal specified value

doesNotEndWith
   attribute does not end with specified value

equals
   attribute equals specified value

endsWith
   attribute ends with specified value

doesNotStartWith
   attribute does not start with specified value
