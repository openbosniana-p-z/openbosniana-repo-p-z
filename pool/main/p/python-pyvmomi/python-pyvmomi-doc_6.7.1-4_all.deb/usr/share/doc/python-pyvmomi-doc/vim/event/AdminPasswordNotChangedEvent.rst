.. _VI API 2.5: ../../vim/version.rst#vimversionversion2

.. _vim.event.HostEvent: ../../vim/event/HostEvent.rst


vim.event.AdminPasswordNotChangedEvent
======================================
  Default password for the Admin user on the host has not been changed.
:extends: vim.event.HostEvent_
:since: `VI API 2.5`_

Attributes:
