.. _vSphere API 4.0: ../../vim/version.rst#vimversionversion5

.. _vim.OvfManager.CommonParams: ../../vim/OvfManager/CommonParams.rst


vim.OvfManager.ValidateHostParams
=================================
  
:extends: vim.OvfManager.CommonParams_
:since: `vSphere API 4.0`_

Attributes:
