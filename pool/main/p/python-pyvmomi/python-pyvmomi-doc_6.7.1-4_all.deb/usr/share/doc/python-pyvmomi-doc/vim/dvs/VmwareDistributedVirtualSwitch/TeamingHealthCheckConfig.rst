.. _vSphere API 5.1: ../../../vim/version.rst#vimversionversion8

.. _vim.dvs.VmwareDistributedVirtualSwitch.VmwareHealthCheckConfig: ../../../vim/dvs/VmwareDistributedVirtualSwitch/VmwareHealthCheckConfig.rst


vim.dvs.VmwareDistributedVirtualSwitch.TeamingHealthCheckConfig
===============================================================
  This class defines the teaming health check configuration. Teaming health check is used to check whether the teaming policy configuration of the vSphere Distributed Switch matches the physical switch.
:extends: vim.dvs.VmwareDistributedVirtualSwitch.VmwareHealthCheckConfig_
:since: `vSphere API 5.1`_

Attributes:
