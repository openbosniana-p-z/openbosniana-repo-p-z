.. _vSphere API 5.5: ../../../vim/version.rst#vimversionversion9

.. _vim.NegatableExpression: ../../../vim/NegatableExpression.rst


vim.dvs.TrafficRule.IpPort
==========================
  Base class for specifying Ports. Objects of the base class represent any port (single/range/list).
:extends: vim.NegatableExpression_
:since: `vSphere API 5.5`_

Attributes:
