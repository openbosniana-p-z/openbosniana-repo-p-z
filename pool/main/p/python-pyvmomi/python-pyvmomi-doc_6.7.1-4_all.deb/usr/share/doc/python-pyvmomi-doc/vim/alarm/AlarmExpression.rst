.. _vmodl.DynamicData: ../../vmodl/DynamicData.rst


vim.alarm.AlarmExpression
=========================
  Base type for the expressions specifying the conditions that define the status of an alarm.
:extends: vmodl.DynamicData_

Attributes:
