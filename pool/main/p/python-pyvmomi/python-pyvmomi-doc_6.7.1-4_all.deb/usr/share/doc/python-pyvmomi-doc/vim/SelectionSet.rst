.. _vSphere API 5.0: ../vim/version.rst#vimversionversion7

.. _vmodl.DynamicData: ../vmodl/DynamicData.rst


vim.SelectionSet
================
  Base class for selecting entities
:extends: vmodl.DynamicData_
:since: `vSphere API 5.0`_

Attributes:
