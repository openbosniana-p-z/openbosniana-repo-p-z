.. _vSphere API 5.5: ../vim/version.rst#vimversionversion9

.. _vim.NegatableExpression: ../vim/NegatableExpression.rst


vim.MacAddress
==============
  Base class for specifying MAC addresses.
:extends: vim.NegatableExpression_
:since: `vSphere API 5.5`_

Attributes:
