.. _vim.action.Action: ../../vim/action/Action.rst


vim.action.SendSNMPAction
=========================
  This data object type specifies an SNMP trap that is triggered by an alarm.
:extends: vim.action.Action_

Attributes:
