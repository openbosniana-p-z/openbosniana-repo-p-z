.. _vmodl.DynamicData: ../../vmodl/DynamicData.rst


vim.action.Action
=================
  This data object type defines the action initiated by a scheduled task or alarm.This is an abstract type. A client creates a scheduled task or an alarm each of which triggers an action, defined by a subclass of this type.
:extends: vmodl.DynamicData_

Attributes:
