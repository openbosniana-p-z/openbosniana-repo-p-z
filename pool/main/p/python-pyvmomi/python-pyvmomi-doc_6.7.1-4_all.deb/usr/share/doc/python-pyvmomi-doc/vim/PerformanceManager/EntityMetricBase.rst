.. _PerfEntityMetric: ../../vim/PerformanceManager/EntityMetric.rst

.. _vmodl.DynamicData: ../../vmodl/DynamicData.rst

.. _vmodl.ManagedObject: ../../vim.ExtensibleManagedObject.rst


vim.PerformanceManager.EntityMetricBase
=======================================
  Base type for the various `PerfEntityMetric`_ encodings.
:extends: vmodl.DynamicData_

Attributes:
    entity (`vmodl.ManagedObject`_):

       Performance provider ID.
