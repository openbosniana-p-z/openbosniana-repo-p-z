.. _str: https://docs.python.org/2/library/stdtypes.html

.. _vSphere API 5.1: ../../vim/version.rst#vimversionversion8

.. _vmodl.DynamicData: ../../vmodl/DynamicData.rst


vim.IpPoolManager.IpAllocation
==============================
  Describes an IP allocation.
:extends: vmodl.DynamicData_
:since: `vSphere API 5.1`_

Attributes:
    ipAddress (`str`_):

       IP address
    allocationId (`str`_):

       The allocation ID
