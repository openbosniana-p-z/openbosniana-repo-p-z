.. _vmodl.DynamicData: ../../vmodl/DynamicData.rst


vim.LicenseManager.LicenseSource
================================
  This data object type is used to communicate configuration about where to find licenses to use for this system.
:extends: vmodl.DynamicData_

Attributes:
