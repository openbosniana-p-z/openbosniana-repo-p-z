.. _vim.TaskReason: ../vim/TaskReason.rst


vim.TaskReasonSystem
====================
  Indicates that the task was started by the system (a default task).
:extends: vim.TaskReason_

Attributes:
