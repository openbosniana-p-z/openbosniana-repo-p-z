.. _int: https://docs.python.org/2/library/stdtypes.html

.. _vmodl.DynamicData: ../../vmodl/DynamicData.rst


vim.CustomFieldsManager.Value
=============================
  Base type for storing values.
:extends: vmodl.DynamicData_

Attributes:
    key (`int`_):

       The ID of the field to which this value belongs.
