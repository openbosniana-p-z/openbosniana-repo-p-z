.. _vSphere API 4.1: ../../../vim/version.rst#vimversionversion6

.. _vim.DistributedVirtualSwitch: ../../../vim/DistributedVirtualSwitch.rst

.. _vim.dvs.DistributedVirtualSwitchManager.HostDvsFilterSpec: ../../../vim/dvs/DistributedVirtualSwitchManager/HostDvsFilterSpec.rst


vim.dvs.DistributedVirtualSwitchManager.HostDvsMembershipFilter
===============================================================
  Check host compatibility against all hosts in the DVS (or not in the DVS if inclusive flag in base class is false)
:extends: vim.dvs.DistributedVirtualSwitchManager.HostDvsFilterSpec_
:since: `vSphere API 4.1`_

Attributes:
    distributedVirtualSwitch (`vim.DistributedVirtualSwitch`_):

