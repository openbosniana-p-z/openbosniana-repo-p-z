.. _vSphere API 4.0: ../../vim/version.rst#vimversionversion5

.. _vmodl.DynamicData: ../../vmodl/DynamicData.rst

.. _vmodl.KeyAnyValue: ../../vmodl/KeyAnyValue.rst


vim.LicenseManager.EvaluationInfo
=================================
  Encapsulates product evaluation information
:extends: vmodl.DynamicData_
:since: `vSphere API 4.0`_

Attributes:
    properties ([`vmodl.KeyAnyValue`_]):

       Evaluation properties
