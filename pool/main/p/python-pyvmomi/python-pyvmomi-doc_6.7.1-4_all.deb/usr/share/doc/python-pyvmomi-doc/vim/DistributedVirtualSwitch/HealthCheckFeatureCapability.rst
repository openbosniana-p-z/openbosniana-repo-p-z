.. _vSphere API 5.1: ../../vim/version.rst#vimversionversion8

.. _vmodl.DynamicData: ../../vmodl/DynamicData.rst


vim.DistributedVirtualSwitch.HealthCheckFeatureCapability
=========================================================
  Health check capabilities of health check supported by the vSphere Distributed Switch
:extends: vmodl.DynamicData_
:since: `vSphere API 5.1`_

Attributes:
