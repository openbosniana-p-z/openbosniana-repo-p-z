.. _str: https://docs.python.org/2/library/stdtypes.html

.. _vmodl.DynamicData: ../vmodl/DynamicData.rst


vim.Description
===============
  Static strings used for describing an object or property.
:extends: vmodl.DynamicData_

Attributes:
    label (`str`_):

       Display label.
    summary (`str`_):

       Summary description.
