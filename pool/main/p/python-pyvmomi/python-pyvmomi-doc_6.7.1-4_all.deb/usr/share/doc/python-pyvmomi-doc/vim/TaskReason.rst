.. _vmodl.DynamicData: ../vmodl/DynamicData.rst


vim.TaskReason
==============
  Base type for all task reasons. Task reasons represent the kind of entity responsible for a task's creation.
:extends: vmodl.DynamicData_

Attributes:
