.. _vSphere API 4.0: ../../vim/version.rst#vimversionversion5

.. _vmodl.DynamicData: ../../vmodl/DynamicData.rst


vim.cluster.DasHostInfo
=======================
  HA specific advanced information pertaining to the hosts in the cluster.
:extends: vmodl.DynamicData_
:since: `vSphere API 4.0`_

Attributes:
