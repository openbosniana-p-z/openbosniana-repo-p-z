.. _vSphere API 4.0: ../../vim/version.rst#vimversionversion5

.. _vmodl.DynamicData: ../../vmodl/DynamicData.rst


vim.cluster.DasAdmissionControlPolicy
=====================================
  Base class for specifying how admission control should be done for vSphere HA.
:extends: vmodl.DynamicData_
:since: `vSphere API 4.0`_

Attributes:
