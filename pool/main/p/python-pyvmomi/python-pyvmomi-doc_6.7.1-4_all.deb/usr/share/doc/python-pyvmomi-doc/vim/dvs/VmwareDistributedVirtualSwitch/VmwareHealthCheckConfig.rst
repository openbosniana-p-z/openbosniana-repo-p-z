.. _vSphere API 5.1: ../../../vim/version.rst#vimversionversion8

.. _vim.DistributedVirtualSwitch.HealthCheckConfig: ../../../vim/DistributedVirtualSwitch/HealthCheckConfig.rst


vim.dvs.VmwareDistributedVirtualSwitch.VmwareHealthCheckConfig
==============================================================
  This class defines health check configuration for VMware vSphere Distributed Switch.
:extends: vim.DistributedVirtualSwitch.HealthCheckConfig_
:since: `vSphere API 5.1`_

Attributes:
