.. _str: https://docs.python.org/2/library/stdtypes.html

.. _vSphere API 5.1: ../../../vim/version.rst#vimversionversion8

.. _vmodl.DynamicData: ../../../vmodl/DynamicData.rst


vim.dvs.HostMember.HealthCheckResult
====================================
  This class defines healthcheck result of the vSphere Distributed Switch.
:extends: vmodl.DynamicData_
:since: `vSphere API 5.1`_

Attributes:
    summary (`str`_, optional):

       The summary of health check result.
