.. _vim.cluster.HostPowerAction: ../../../vim/cluster/HostPowerAction.rst

.. _vim.cluster.HostPowerAction.OperationType: ../../../vim/cluster/HostPowerAction/OperationType.rst

vim.cluster.HostPowerAction.OperationType
=========================================
  :contained by: `vim.cluster.HostPowerAction`_

  :type: `vim.cluster.HostPowerAction.OperationType`_

  :name: powerOff

values:
--------

powerOff
   Power Off Operation. Power off operation puts the host in a state that can be woken up remotely.

powerOn
   Power On Operation
