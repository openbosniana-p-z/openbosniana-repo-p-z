#!/bin/sh

#Set the inputReads and reference -- change at your leisure
inputReads=filtered_subreads.fastq
reference=lambda_modified.fasta

echo "PIEMapping"
Honey pie $inputReads $reference -o mappingFinal.sam

echo "Sam To Bam"
samtools view -bt $reference mappingFinal.sam |
    samtools sort - > mappingFinal.bam
samtools index mappingFinal.bam

echo "Calling Tails"
Honey tails mappingFinal.bam

echo "Calling Spots"
Honey spots --reference $reference mappingFinal.bam

