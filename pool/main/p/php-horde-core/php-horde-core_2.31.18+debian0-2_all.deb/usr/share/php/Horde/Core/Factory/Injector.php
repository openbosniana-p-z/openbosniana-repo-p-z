<?php
/**
 * The abstract Horde injector class.
 *
 * PHP version 5
 *
 * @category Horde
 * @package  Core
 * @author   Michael Slusarz <slusarz@horde.org>
 * @license  http://www.horde.org/licenses/lgpl21 LGPL 2.1
 */

/**
 * The abstract Horde injector class.
 *
 * This class is used for factories that are intended to be directly called
 * by the Horde_Injector instance.
 *
 * Copyright 2011-2017 Horde LLC (http://www.horde.org/)
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.horde.org/licenses/lgpl21.
 *
 * @category Horde
 * @package  Core
 * @author   Michael Slusarz <slusarz@horde.org>
 * @license  http://www.horde.org/licenses/lgpl21 LGPL 2.1
 */
abstract class Horde_Core_Factory_Injector extends Horde_Core_Factory_Base
{
    /**
     * @throws Horde_Exception
     */
    abstract public function create(Horde_Injector $injector);

}
