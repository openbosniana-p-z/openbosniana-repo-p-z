  SET log_min_duration_sample TO -1;
