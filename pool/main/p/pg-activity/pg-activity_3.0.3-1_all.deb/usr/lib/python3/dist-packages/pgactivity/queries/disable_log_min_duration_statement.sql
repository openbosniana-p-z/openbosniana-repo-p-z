  SET log_min_duration_statement TO -1;
