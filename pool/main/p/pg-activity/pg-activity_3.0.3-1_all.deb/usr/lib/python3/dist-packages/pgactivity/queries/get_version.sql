-- Get the server's version
SELECT version() AS pg_version;
