-- Get the server and client inet addresses
SELECT inet_server_addr() AS inet_server_addr, inet_client_addr() AS inet_client_addr;
