-- Get the path of the pidfile
SHOW data_directory;
