-- Check if we are connected with the user with the SUPERUSER attribute
SELECT current_setting('is_superuser') AS is_superuser;
