RESET statement_timeout;
