SET statement_timeout TO %(timeout)s
