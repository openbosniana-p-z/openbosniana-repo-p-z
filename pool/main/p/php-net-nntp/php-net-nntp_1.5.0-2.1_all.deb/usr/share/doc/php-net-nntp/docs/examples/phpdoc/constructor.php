$nntp = new Net_NNTP_Client();
