
<div id="page-footer">

 <hr />

 <div class="copyright">
  Copyright &copy; 2011 by Heino H. Gehlsen. All rights reserved. This work is distributed under the <a href="http://www.w3.org/Consortium/Legal/2002/copyright-software-20021231">W3C Software License</a> in the hope that it will be useful, but WITHOUT ANY WARRANTY of any kind.
 </div>

</div>

</body>

</html>
