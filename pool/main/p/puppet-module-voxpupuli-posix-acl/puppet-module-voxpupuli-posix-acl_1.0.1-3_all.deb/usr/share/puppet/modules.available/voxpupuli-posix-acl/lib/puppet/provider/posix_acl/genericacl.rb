Puppet::Type.type(:posix_acl).provide(:genericacl, parent: Puppet::Provider) do
end
