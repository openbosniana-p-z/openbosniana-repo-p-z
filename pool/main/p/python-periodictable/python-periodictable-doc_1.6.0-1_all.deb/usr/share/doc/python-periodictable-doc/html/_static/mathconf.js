MathJax.Hub.Config({
  TeX: {
    Macros: {
      AA: '\\unicode{x212B}',
    }
  }
});
