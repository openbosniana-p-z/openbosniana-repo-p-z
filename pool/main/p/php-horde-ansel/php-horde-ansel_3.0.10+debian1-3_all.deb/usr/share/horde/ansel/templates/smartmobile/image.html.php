<div data-role="page" data-theme="h" id="imageview">
  <div data-role="header">
    <a data-role="button" data-icon="arrow-l" href="#" id="ansel-image-back"><?php echo _("Back")?></a>
    <h1></h1>
  </div>
  <div id="anselimageview"></div>
  <div data-role="footer" class="ui-bar" data-position="fixed">
    <div data-role="controlgroup" data-type="horizontal">
      <a href="#" id="ansel-image-prev" data-role="button" data-icon="arrow-l"><?php echo _("Previous") ?></a>
      <a href="#" id="ansel-image-next" data-role="button" data-icon="arrow-r"><?php echo _("Next") ?></a>
    </div>
  </div>
</div>