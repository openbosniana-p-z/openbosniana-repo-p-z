<div data-role="page" data-theme="h" id="galleryview">
  <div data-role="header">
    <a data-role="button" data-icon="arrow-l" href="#" id="ansel-gallery-back"></a>
    <h1></h1>
  </div>
  <div id="anselgalleryview">
   <ul class="anselgalleries" data-role="listview" data-inset="true"></ul>
   <ul id="thumbs" class="thumbView"></ul>
  </div>
</div>