<?php
/**
 * @author  Duck <duck@obala.net>
 * @package Ansel
 */
class Ansel_Faces_User extends Ansel_Faces_Base
{
}
