<!-- Start Widget -->
<div class="anselWidget" style="background-color:<?php echo $this->background ?>;">
  <h2 class="header tagTitle"><?php echo $this->title ?></h2>