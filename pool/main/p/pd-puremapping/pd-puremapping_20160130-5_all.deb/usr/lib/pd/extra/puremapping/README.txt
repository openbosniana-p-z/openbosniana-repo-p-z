This collection of abstraction are made to facilitate the use of sensors and to create complex relations between input and output of a dynamic system Puremapping was create based on la-kitchen library, and the mapping library. Most object of puremapping should be compatible with the mapping lib object.
They do however have no dependency.
