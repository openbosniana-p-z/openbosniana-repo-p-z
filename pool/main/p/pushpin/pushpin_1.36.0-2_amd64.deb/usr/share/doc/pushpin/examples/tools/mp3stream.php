<?php header('Grip-Hold: stream');
      header('Grip-Channel: music');
      header('Content-Type: audio/mpeg'); ?>
