<?php header('Grip-Hold: response');
      header('Grip-Channel: test');
      header('Grip-Timeout: 55');
      header('Content-Type: text/plain'); ?>
nothing for now
