Document: discord.py
Title: discord.py Documentation
Abstract: Documentation for discord.py, a Python API wrapper for Discord.
Section: Programming/Python

Format: HTML
Index: /usr/share/doc/python-discord-doc/html/index.html
Files: /usr/share/doc/python-discord-doc/html/*.html
