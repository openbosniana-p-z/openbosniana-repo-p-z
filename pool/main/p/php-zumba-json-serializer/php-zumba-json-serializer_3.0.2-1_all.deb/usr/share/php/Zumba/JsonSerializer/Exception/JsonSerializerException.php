<?php

namespace Zumba\JsonSerializer\Exception;

use RuntimeException;

class JsonSerializerException extends RuntimeException
{
}
