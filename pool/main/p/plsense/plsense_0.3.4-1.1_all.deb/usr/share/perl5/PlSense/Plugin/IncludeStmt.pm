package PlSense::Plugin::IncludeStmt;

use strict;
use warnings;
use Class::Std;
{
    sub include_statement {
        my ($self, $mdl, $stmt) = @_;
    }
}

1;

__END__
