package File::Copy;

use strict;
use warnings;

sub dummy_copy {
    return "";
}

1;

