#!/bin/bash
# pbuilder example script.
# Copyright 2003 Junichi Uekawa
#Distributed under GPL version 2 or later
#
# this is parameter testing script for
# pbuilder execute.
# This program will output the command-line


echo "--- parameters given to this script"
echo "[$@]"

