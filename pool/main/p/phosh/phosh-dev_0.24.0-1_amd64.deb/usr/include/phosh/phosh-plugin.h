/*
 * Copyright (C) 2022 Guido Günther
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Author: Guido Günther <agx@sigxcpu.org>
 */

#pragma once

#define PHOSH_PLUGIN_EXTENSION_POINT_LOCKSCREEN_WIDGET "phosh-lockscreen-widget"
#define PHOSH_PLUGIN_EXTENSION_POINT_LOCKSCREEN_WIDGET_PREFS "phosh-lockscreen-widget-prefs"
