"""Run PyCorrFit"""
from .gui import main

main.Main()
