#!/usr/bin/env python
# This file was created automatically
longversion = '2019.10.24-21-53-49'
