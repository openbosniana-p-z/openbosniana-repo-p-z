#!/bin/bash

autoreconf -fvi
