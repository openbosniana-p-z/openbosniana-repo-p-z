## usage: use_plplot
##
## This function is deprecated.  Use toggle_plplot_use instead.

## File: use_plplot.m
## Author: Rafael Laboissiere <rafael@icp.inpg.fr>
## Modified: Joao Cardoso
## Created on: Sun Oct 18 22:03:10 CEST 1998
## Last modified on: Fri Mar  7 09:37:51 CET 2003
##
## Copyright (C) 1998, 2003  Rafael Laboissiere
##
## PLplot is free software, distributable under the GPL. No
## warranties, use it at your own risk.  It  was originally written for
## inclusion in the Debian octave-plplot package.

function use_plplot ()
  printf ("This function is deprecated.  Use toggle_plplot_use instead.\n");
endfunction
