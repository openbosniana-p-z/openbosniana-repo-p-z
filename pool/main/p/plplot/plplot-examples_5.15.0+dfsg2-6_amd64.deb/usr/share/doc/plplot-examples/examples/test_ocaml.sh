#!/bin/bash
# Test suite for ocaml examples.
#
# Copyright (C) 2008  Andrew Ross
#
# This file is part of PLplot.
#
# PLplot is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License as published
# by the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# PLplot is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Library General Public License for more details.
#
# You should have received a copy of the GNU Library General Public License
# along with PLplot; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA

# This is called from plplot-test.sh with $ocamldir, $device, $dsuffix,
# $options, and possibly $verbose_test defined.

# Do the standard non-interactive examples.
lang="ocaml"
# Consequently disable all tests on MIPS platform since they tend to
# hang forever
uname -m | grep -qi mips && exit 0
for index in 00 01 02 03 04 05 06 07 08 09 10 11 12 13 15 16 18 19 20 21 22 23 24 25 26 27 28 30 31 33 ${critical_examples} ; do
    if [ "$verbose_test" ] ; then
	echo "x${index}ocaml"
    fi
    if [ "$index" = "14" ] ; then
	echo "${OUTPUT_DIR}"/x${index}a${lang}%n.$dsuffix | \
	"$ocamldir"/x${index}${lang} -dev $device -o "${OUTPUT_DIR}"/x${index}${lang}%n.$dsuffix \
	    $options 2> ocaml_${device}_test.error >| "${OUTPUT_DIR}"/x${index}${lang}_${dsuffix}.txt
	# Look for any status codes (segfaults, plexit) from the examples themselves.
	status_code=$?
    else
	"$ocamldir"/x${index}ocaml -dev $device -o "${OUTPUT_DIR}"/x${index}${lang}%n.$dsuffix \
	    $options 2> ocaml_${device}_test.error >| "${OUTPUT_DIR}"/x${index}${lang}_${dsuffix}.txt
    # Look for any status codes (segfaults, plexit) from the examples themselves.
	status_code=$?
    fi
    cat ocaml_${device}_test.error
done
