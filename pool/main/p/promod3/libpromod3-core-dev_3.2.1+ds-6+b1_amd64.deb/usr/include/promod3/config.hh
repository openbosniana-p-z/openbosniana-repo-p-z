// Copyright (c) 2013-2020, SIB - Swiss Institute of Bioinformatics and
//                          Biozentrum - University of Basel
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//   http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


/*
  DO NOT EDIT the '.hh' file, it is processed from a template '.hh.in' by CMake.
*/

#ifndef PROMOD3_CONFIG_HH
#define PROMOD3_CONFIG_HH

#include <cstdlib>
#include <ost/log.hh>
#include <promod3/core/message.hh>
#include <boost/filesystem/path.hpp>
#include <boost/filesystem/operations.hpp>

/* fetch version from top level CMakeLists.txt */
#define PROMOD3_VERSION_MAJOR 3
#define PROMOD3_VERSION_MINOR 2
#define PROMOD3_VERSION_STRING "3.2.1"

// control profiling level: 0 = none, else up to that level
// PM3_RUNTIME_PROFILING_LEVEL fetched from top level CMakeLists.txt
#define PM3_RUNTIME_PROFILING_LEVEL 0

// specify, whether SSE is enabled
#define PM3_ENABLE_SSE 0

namespace promod3 {

/// \brief Get path to the shared data folder. Used for binaries.
/// This is taken from the env. variable PROMOD3_SHARED_DATA_PATH.
/// If the emv. var. is not set, it uses the compile-time location as fallback.
inline String GetProMod3SharedDataPath() {
  char* my_path = getenv("PROMOD3_SHARED_DATA_PATH");
  if (my_path) {
    return String(my_path);
  } else {
    return String("/build/promod3-5ie8V1/promod3-3.2.1+ds/obj-x86_64-linux-gnu/stage/share/promod3");
  }
}

/// \brief Get location of a binary in a subpath of the shared data folder.
/// Throws an exception and logs if it fails to find the desired file.
inline String GetProMod3BinaryPath(const String& subpath, const String& filename) {
  boost::filesystem::path shared_path(GetProMod3SharedDataPath());
  boost::filesystem::path my_path = shared_path / subpath / filename;
  if (boost::filesystem::is_regular_file(my_path)) {
    return my_path.string();
  } else {
    String m = "Could not find " + my_path.string() + ". "
               "Make sure that the env. var. PROMOD3_SHARED_DATA_PATH is set "
               " properly (currently set to " + shared_path.string() + ").";
    LOG_ERROR(m);
    throw promod3::Error(m);
  }
}

} //ns

#endif
