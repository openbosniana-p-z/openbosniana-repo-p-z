package peco

func init() {
	// This is the value we pass to anchor offset when we're running
	// on windows platform
	extraOffset = 1
}
