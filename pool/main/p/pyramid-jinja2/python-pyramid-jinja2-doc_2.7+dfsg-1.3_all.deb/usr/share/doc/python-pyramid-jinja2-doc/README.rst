Jinja2 bindings for Pyramid
===========================

These are bindings for the `Jinja2 templating system <http://jinja.pocoo.org>`_
for the `Pyramid <https://trypyramid.com>`_ web framework.

See http://docs.pylonsproject.org/projects/pyramid-jinja2/en/latest/ for
documentation or ``index.rst`` in the ``docs`` sub-directory of the source
distribution.
