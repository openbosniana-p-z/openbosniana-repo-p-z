\echo Use "ALTER EXTENSION pgmemcache UPDATE" to load this file. \quit
