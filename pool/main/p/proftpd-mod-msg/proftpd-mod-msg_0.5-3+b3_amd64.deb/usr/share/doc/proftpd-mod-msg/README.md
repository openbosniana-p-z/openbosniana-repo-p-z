proftpd-mod_msg
===============

Status
------
[![Build Status](https://travis-ci.org/Castaglia/proftpd-mod_msg.svg?branch=master)](https://travis-ci.org/Castaglia/proftpd-mod_msg)
[![License](https://img.shields.io/badge/license-GPL-brightgreen.svg)](https://img.shields.io/badge/license-GPL-brightgreen.svg)


Synopsis
--------
The `mod_msg` module for ProFTPD supports sending messages to connected FTP
clients.

For further module documentation, see [mod_msg.html](https://htmlpreview.github.io/?https://github.com/Castaglia/proftpd-mod_msg/blob/master/mod_msg.html).
