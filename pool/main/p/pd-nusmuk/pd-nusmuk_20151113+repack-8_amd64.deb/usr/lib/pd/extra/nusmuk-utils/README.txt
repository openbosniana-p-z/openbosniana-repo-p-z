This are a collection of usefull abstraction and that can be usefull.

This lib is made by Cyrille Henry (exept pbank for zack settel), you can contact him on his webpage : 
http://www.chnry.net/ch/?001-Cyrille-Henry

This lib is realese under the GNU Public License.

To build it, just type make.
