((window.gitter = {}).chat = {}).options = {
  room: 'python-gitlab/Lobby'
};
