<?php
require_once 'Horde/Test/Bootstrap.php';
Horde_Test_Bootstrap::bootstrap(dirname(__FILE__));
