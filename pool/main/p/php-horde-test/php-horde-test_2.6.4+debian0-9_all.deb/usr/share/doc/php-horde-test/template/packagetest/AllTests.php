<?php
require_once 'Horde/Test/AllTests.php';
Horde_Test_AllTests::init(__FILE__)->run();
