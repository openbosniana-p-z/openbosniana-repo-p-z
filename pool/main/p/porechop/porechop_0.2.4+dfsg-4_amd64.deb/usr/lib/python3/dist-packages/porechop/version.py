"""
The version is stored here in a separate file so it can exist in only one place.
http://stackoverflow.com/questions/458550
"""
__version__ = '0.2.4'
