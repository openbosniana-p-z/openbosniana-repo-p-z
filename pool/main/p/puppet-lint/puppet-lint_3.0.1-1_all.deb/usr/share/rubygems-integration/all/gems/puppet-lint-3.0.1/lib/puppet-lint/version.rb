class PuppetLint
  VERSION = '3.0.1'.freeze
end
