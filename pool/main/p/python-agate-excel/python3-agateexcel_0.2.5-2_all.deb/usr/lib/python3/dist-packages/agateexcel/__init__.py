#!/usr/bin/env python

import agateexcel.table_xls
import agateexcel.table_xlsx
