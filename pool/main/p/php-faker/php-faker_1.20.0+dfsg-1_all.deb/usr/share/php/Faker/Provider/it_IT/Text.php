<?php

namespace Faker\Provider\it_IT;

class Text extends \Faker\Provider\Text
{
    protected static $baseText = <<<'EOT'
Fake italian
EOT;
}
