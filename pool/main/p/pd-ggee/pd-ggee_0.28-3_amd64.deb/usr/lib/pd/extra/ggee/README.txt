
ggee is a library by Guenter Geiger with five sections: control, experimental,
filters, gui, and signal.

 * objects for controlling things: constant rl serial_ms sl getdir rtout
   serial_mt stripdir inv serial_bird shell unserialize qread serialize sinh
   unwonk

 * experimental synths: fofsynth~ tabwrite4~ pvocfreq

 * objects for controlling filters: bandpass highpass hlshelf lowshelf notch
   equalizer highshelf lowpass moog~

 * GUI objects: button fatom image sliderh ticker envgen gcanvas slider state
   toddle

 * manipulating signals: atan2~ mixer~ sfwrite~ streamin~ streamout~

Guenter Geiger
