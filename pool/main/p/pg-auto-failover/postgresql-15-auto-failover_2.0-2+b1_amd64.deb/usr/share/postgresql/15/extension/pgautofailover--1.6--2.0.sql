--
-- extension update file from 1.6 to 2.0
--
-- complain if script is sourced in psql, rather than via CREATE EXTENSION
\echo Use "CREATE EXTENSION pgautofailover" to load this file. \quit

-- no changes, just the version number
