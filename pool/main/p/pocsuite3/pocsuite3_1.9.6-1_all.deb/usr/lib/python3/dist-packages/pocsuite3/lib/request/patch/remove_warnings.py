from urllib3 import disable_warnings


disable_warnings()
