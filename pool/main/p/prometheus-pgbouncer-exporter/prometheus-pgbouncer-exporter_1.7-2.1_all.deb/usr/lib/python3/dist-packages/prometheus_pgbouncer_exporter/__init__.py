__ver_major__ = 1
__ver_minor__ = 7
__version__ = "%d.%d" % (__ver_major__, __ver_minor__)
