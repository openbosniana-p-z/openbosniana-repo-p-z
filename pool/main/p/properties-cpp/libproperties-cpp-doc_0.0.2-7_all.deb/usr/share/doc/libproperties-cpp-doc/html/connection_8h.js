var connection_8h =
[
    [ "core::Connection", "classcore_1_1Connection.html", "classcore_1_1Connection" ],
    [ "core::ScopedConnection", "classcore_1_1ScopedConnection.html", "classcore_1_1ScopedConnection" ]
];