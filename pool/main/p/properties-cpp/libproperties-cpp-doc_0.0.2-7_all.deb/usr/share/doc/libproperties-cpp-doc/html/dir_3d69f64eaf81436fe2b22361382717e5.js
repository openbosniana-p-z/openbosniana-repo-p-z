var dir_3d69f64eaf81436fe2b22361382717e5 =
[
    [ "connection.h", "connection_8h.html", "connection_8h" ],
    [ "property.h", "property_8h.html", "property_8h" ],
    [ "signal.h", "signal_8h.html", "signal_8h" ]
];