var classcore_1_1Connection =
[
    [ "Dispatcher", "classcore_1_1Connection.html#ac073a4aabc3e8d4b3c4e50b0ae3c809c", null ],
    [ "disconnect", "classcore_1_1Connection.html#a3ffa9ab26c05270903eb817de03a33dd", null ],
    [ "dispatch_via", "classcore_1_1Connection.html#a1d043d81b605debddfa7e766281d0d44", null ],
    [ "is_connected", "classcore_1_1Connection.html#abb966cafec649a4c0dc61109ad3a4dba", null ],
    [ "ScopedConnection", "classcore_1_1Connection.html#a51d6c2b8cfd94e2b25e658d1cc2db75a", null ],
    [ "Signal", "classcore_1_1Connection.html#a19896c11ac72db2063eec99f7cdcf96c", null ]
];