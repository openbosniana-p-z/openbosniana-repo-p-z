var namespacecore =
[
    [ "Connection", "classcore_1_1Connection.html", "classcore_1_1Connection" ],
    [ "Property", "classcore_1_1Property.html", "classcore_1_1Property" ],
    [ "ScopedConnection", "classcore_1_1ScopedConnection.html", "classcore_1_1ScopedConnection" ],
    [ "Signal", "classcore_1_1Signal.html", "classcore_1_1Signal" ],
    [ "Signal< void >", "classcore_1_1Signal_3_01void_01_4.html", "classcore_1_1Signal_3_01void_01_4" ]
];