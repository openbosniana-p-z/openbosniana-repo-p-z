var files_dup =
[
    [ "CMakeFiles", "dir_37d8b042556d19a269382dcc5ce14122.html", "dir_37d8b042556d19a269382dcc5ce14122" ],
    [ "include", "dir_d44c64559bbebec7f509842c48db8b23.html", "dir_d44c64559bbebec7f509842c48db8b23" ],
    [ "tests", "dir_59425e443f801f1f2fd8bbe4959a3ccf.html", "dir_59425e443f801f1f2fd8bbe4959a3ccf" ]
];