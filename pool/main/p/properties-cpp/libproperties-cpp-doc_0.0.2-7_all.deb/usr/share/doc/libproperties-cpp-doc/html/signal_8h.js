var signal_8h =
[
    [ "core::Signal< Arguments >", "classcore_1_1Signal.html", "classcore_1_1Signal" ],
    [ "core::Signal< void >", "classcore_1_1Signal_3_01void_01_4.html", "classcore_1_1Signal_3_01void_01_4" ]
];