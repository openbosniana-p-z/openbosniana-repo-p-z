# frozen_string_literal: true

class Pry
  VERSION = '0.13.1'.freeze
end
