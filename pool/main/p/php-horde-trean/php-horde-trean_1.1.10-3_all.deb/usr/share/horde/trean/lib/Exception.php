<?php
class Trean_Exception extends Horde_Exception
{
}
