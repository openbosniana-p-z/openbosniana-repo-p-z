"""
We create our interface groups here.
"""
# setup an interface/group alias here, for example:
# add_interface("int", "eth0 ppp+")

# 'any interface' is a good choice for "never ever accept" rules.
add_interface("any", "*")
