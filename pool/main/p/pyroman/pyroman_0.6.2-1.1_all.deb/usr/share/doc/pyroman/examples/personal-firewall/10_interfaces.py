"""
Treat all interfaces the same for the single-host setup.
"""
add_interface("any", "*")
