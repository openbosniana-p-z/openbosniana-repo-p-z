# Importing the PyMOL module will create the window.

import pymol

# Call the function below before using any PyMOL modules.

# THIS DOES NOT WORK ON macOS
pymol.finish_launching()

# Now we can import cmd

from pymol import cmd
if os.path.exists("$PYMOL_PATH/test/dat/pept.pdb"):
    cmd.load("$PYMOL_PATH/test/dat/pept.pdb")
else:
    from inspect import getsourcefile
    current_file_dir = os.path.dirname(os.path.abspath(getsourcefile(lambda:0)))
    cmd.load(os.path.join(current_file_dir, "../../test/dat/pept.pdb"))
# Note that in typical Debian package installation test/... directory would be
# located at /usr/share/pymol directory, and $PYMOL_PATH will point to different
# location.
cmd.show("sticks")
