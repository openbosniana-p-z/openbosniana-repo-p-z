(** @canonical Ppx_compare_expander.Ppx_compare_expander_intf *)
module Ppx_compare_expander_intf = Ppx_compare_expander__Ppx_compare_expander_intf
