from sfml import sf

texture = sf.Texture.from_file("image.jpg")
