Ppx_derivers
------------

Ppx_derivers is a tiny package whose sole purpose is to allow
[ppx_deriving](https://github.com/whitequark/ppx_deriving) and
[ppx_type_conv](https://github.com/janestreet/ppx_type_conv) to inter-operate
gracefully when linked as part of the same
[ocaml-migrate-parsetree](https://github.com/let-def/ocaml-migrate-parsetree)
driver.

