<?php
$_prefs['add_source']['hook'] = true;
$_prefs['search_sources']['hook'] = true;
$_prefs['search_fields']['hook'] = true;
