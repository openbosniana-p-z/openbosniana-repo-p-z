RSpec.configure do |c|
  c.filter_run_excluding(excl: true)
end
