ALTER TABLE cryptokeys ADD published BOOL NULL DEFAULT 1 AFTER active;
