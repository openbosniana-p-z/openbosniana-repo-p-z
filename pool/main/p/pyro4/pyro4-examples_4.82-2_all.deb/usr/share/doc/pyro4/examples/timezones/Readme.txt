This example exercises the support for pytz/dateutil timezones in the serializers.

Pickle is able to serialize everything just fine.
Not everything works for the other serializers, consider it a work in progress for now.