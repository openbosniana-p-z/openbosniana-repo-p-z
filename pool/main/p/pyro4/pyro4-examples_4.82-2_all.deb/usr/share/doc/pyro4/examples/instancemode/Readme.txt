This example shows the use of the instance_mode option when exposing a class.

Please make sure a name server is running somewhere first,
before starting the server and client.
