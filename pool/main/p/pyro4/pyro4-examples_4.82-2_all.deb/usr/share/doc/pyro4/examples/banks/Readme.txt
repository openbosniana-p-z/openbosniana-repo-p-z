This is a simple electronic banking example.

There are two banks:-
Rabobank and ABN (don't ask - I'm from Holland)
Their services are started with BankServer.py.


The client runs some transactions on both banks (if found), like:-
-creating accounts
-deleting accounts
-deposit money
-withdraw money
-inquire balance

The ABN bank will not allow the client to overdraw and have a negative
balance, the Rabobank will.
