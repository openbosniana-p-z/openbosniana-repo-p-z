<?php echo $this->textFieldTag($this->tagname, $this->escape($this->val), array('size' => 40)); ?>
