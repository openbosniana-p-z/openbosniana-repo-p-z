Please see http://phpldapadmin.sourceforge.net/wiki/index.php/Translate now for information on
translating PLA.
