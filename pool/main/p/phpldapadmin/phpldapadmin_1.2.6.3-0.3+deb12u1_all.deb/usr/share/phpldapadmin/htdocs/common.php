<?php
/**
 * This script provides a convienent method to call the proper common.php
 *
 * @package phpLDAPadmin
 */

/**
 */

if (! defined('LIBDIR'))
	define('LIBDIR',sprintf('%s/',realpath('../lib/')));
require_once LIBDIR.'common.php';
?>
