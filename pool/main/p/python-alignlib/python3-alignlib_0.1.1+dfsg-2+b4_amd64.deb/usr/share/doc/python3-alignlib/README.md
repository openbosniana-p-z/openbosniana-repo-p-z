# alignlib

A small Python module providing edit distance and Hamming distance computation.
