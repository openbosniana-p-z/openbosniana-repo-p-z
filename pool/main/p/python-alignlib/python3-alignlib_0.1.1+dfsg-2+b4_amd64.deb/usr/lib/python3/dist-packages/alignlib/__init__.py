from ._core import edit_distance, hamming_distance
from ._version import version as __version__
