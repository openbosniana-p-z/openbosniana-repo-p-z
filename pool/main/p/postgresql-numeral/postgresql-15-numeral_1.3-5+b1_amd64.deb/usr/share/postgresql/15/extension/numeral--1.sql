/*
Copyright (C) 2017 Christoph Berg

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/

-- type definition

CREATE TYPE numeral;

CREATE OR REPLACE FUNCTION numeral_in(cstring)
	RETURNS numeral
	AS '$libdir/numeral'
	LANGUAGE C IMMUTABLE STRICT;

CREATE OR REPLACE FUNCTION numeral_out(numeral)
	RETURNS cstring
	AS '$libdir/numeral'
	LANGUAGE C IMMUTABLE STRICT;

CREATE TYPE numeral (
	internallength = 8,
	input = numeral_in,
	output = numeral_out,
	passedbyvalue,
	alignment = double,
	category = 'N'
);

/* numeral is as good as bigint, make casts */

CREATE CAST (numeral AS bigint)
	WITHOUT FUNCTION
	AS IMPLICIT;

CREATE CAST (bigint AS numeral)
	WITHOUT FUNCTION;

/* steal bigint's operators */

CREATE FUNCTION numeraleq(numeral, numeral) RETURNS boolean
	AS 'int8eq' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR = (
	leftarg = numeral, rightarg = numeral,
	procedure = numeraleq,
	commutator = =, negator = <>,
	restrict = eqsel, join = eqjoinsel,
	hashes, merges
);

CREATE FUNCTION numeralne(numeral, numeral) RETURNS boolean
	AS 'int8ne' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR <> (
	leftarg = numeral, rightarg = numeral,
	procedure = numeralne,
	commutator = <>, negator = =,
	restrict = neqsel, join = neqjoinsel
);

CREATE FUNCTION numerallt(numeral, numeral) RETURNS boolean
	AS 'int8lt' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR < (
	leftarg = numeral, rightarg = numeral,
	procedure = numerallt,
	commutator = >, negator = >=,
	restrict = scalarltsel, join = scalarltjoinsel
);

CREATE FUNCTION numeralgt(numeral, numeral) RETURNS boolean
	AS 'int8gt' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR > (
	leftarg = numeral, rightarg = numeral,
	procedure = numeralgt,
	commutator = <, negator = <=,
	restrict = scalargtsel, join = scalargtjoinsel
);

CREATE FUNCTION numeralle(numeral, numeral) RETURNS boolean
	AS 'int8le' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR <= (
	leftarg = numeral, rightarg = numeral,
	procedure = numeralle,
	commutator = >=, negator = >,
	restrict = scalarltsel, join = scalarltjoinsel
);

CREATE FUNCTION numeralge(numeral, numeral) RETURNS boolean
	AS 'int8ge' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR >= (
	leftarg = numeral, rightarg = numeral,
	procedure = numeralge,
	commutator = <=, negator = <,
	restrict = scalargtsel, join = scalargtjoinsel
);


CREATE FUNCTION numeralmod(numeral, numeral) RETURNS numeral
	AS 'int8mod' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR % (
	leftarg = numeral, rightarg = numeral,
	procedure = numeralmod
);

CREATE FUNCTION numeralpl(numeral, numeral) RETURNS numeral
	AS 'int8pl' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR + (
	leftarg = numeral, rightarg = numeral,
	procedure = numeralpl,
	commutator = +
);

CREATE FUNCTION numeralmi(numeral, numeral) RETURNS numeral
	AS 'int8mi' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR - (
	leftarg = numeral, rightarg = numeral,
	procedure = numeralmi
);

CREATE FUNCTION numeralmul(numeral, numeral) RETURNS numeral
	AS 'int8mul' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR * (
	leftarg = numeral, rightarg = numeral,
	procedure = numeralmul,
	commutator = *
);

CREATE FUNCTION numeraldiv(numeral, numeral) RETURNS numeral
	AS 'int8div' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR / (
	leftarg = numeral, rightarg = numeral,
	procedure = numeraldiv
);

CREATE FUNCTION numeraland(numeral, numeral) RETURNS numeral
	AS 'int8and' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR & (
	leftarg = numeral, rightarg = numeral,
	procedure = numeraland,
	commutator = &
);

CREATE FUNCTION numeralor(numeral, numeral) RETURNS numeral
	AS 'int8or' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR | (
	leftarg = numeral, rightarg = numeral,
	procedure = numeralor,
	commutator = |
);

CREATE FUNCTION numeralxor(numeral, numeral) RETURNS numeral
	AS 'int8xor' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR # (
	leftarg = numeral, rightarg = numeral,
	procedure = numeralxor,
	commutator = #
);


CREATE FUNCTION numeralabs(numeral) RETURNS numeral
	AS 'int8abs' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR @ (
	rightarg = numeral,
	procedure = numeralabs
);

CREATE FUNCTION numeralum(numeral) RETURNS numeral
	AS 'int8um' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR - (
	rightarg = numeral,
	procedure = numeralum
);

CREATE FUNCTION numeralnot(numeral) RETURNS numeral
	AS 'int8not' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR ~ (
	rightarg = numeral,
	procedure = numeralnot
);

CREATE FUNCTION numeralup(numeral) RETURNS numeral
	AS 'int8up' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR + (
	rightarg = numeral,
	procedure = numeralup
);

/*
Copyright (C) 2017 Christoph Berg

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/

-- type definition

CREATE TYPE zahl;

CREATE OR REPLACE FUNCTION zahl_in(cstring)
	RETURNS zahl
	AS '$libdir/numeral'
	LANGUAGE C IMMUTABLE STRICT;

CREATE OR REPLACE FUNCTION zahl_out(zahl)
	RETURNS cstring
	AS '$libdir/numeral'
	LANGUAGE C IMMUTABLE STRICT;

CREATE TYPE zahl (
	internallength = 8,
	input = zahl_in,
	output = zahl_out,
	passedbyvalue,
	alignment = double,
	category = 'N'
);

/* zahl is as good as bigint, make casts */

CREATE CAST (zahl AS bigint)
	WITHOUT FUNCTION
	AS IMPLICIT;

CREATE CAST (bigint AS zahl)
	WITHOUT FUNCTION;

/* steal bigint's operators */

CREATE FUNCTION zahleq(zahl, zahl) RETURNS boolean
	AS 'int8eq' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR = (
	leftarg = zahl, rightarg = zahl,
	procedure = zahleq,
	commutator = =, negator = <>,
	restrict = eqsel, join = eqjoinsel,
	hashes, merges
);

CREATE FUNCTION zahlne(zahl, zahl) RETURNS boolean
	AS 'int8ne' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR <> (
	leftarg = zahl, rightarg = zahl,
	procedure = zahlne,
	commutator = <>, negator = =,
	restrict = neqsel, join = neqjoinsel
);

CREATE FUNCTION zahllt(zahl, zahl) RETURNS boolean
	AS 'int8lt' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR < (
	leftarg = zahl, rightarg = zahl,
	procedure = zahllt,
	commutator = >, negator = >=,
	restrict = scalarltsel, join = scalarltjoinsel
);

CREATE FUNCTION zahlgt(zahl, zahl) RETURNS boolean
	AS 'int8gt' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR > (
	leftarg = zahl, rightarg = zahl,
	procedure = zahlgt,
	commutator = <, negator = <=,
	restrict = scalargtsel, join = scalargtjoinsel
);

CREATE FUNCTION zahlle(zahl, zahl) RETURNS boolean
	AS 'int8le' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR <= (
	leftarg = zahl, rightarg = zahl,
	procedure = zahlle,
	commutator = >=, negator = >,
	restrict = scalarltsel, join = scalarltjoinsel
);

CREATE FUNCTION zahlge(zahl, zahl) RETURNS boolean
	AS 'int8ge' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR >= (
	leftarg = zahl, rightarg = zahl,
	procedure = zahlge,
	commutator = <=, negator = <,
	restrict = scalargtsel, join = scalargtjoinsel
);


CREATE FUNCTION zahlmod(zahl, zahl) RETURNS zahl
	AS 'int8mod' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR % (
	leftarg = zahl, rightarg = zahl,
	procedure = zahlmod
);

CREATE FUNCTION zahlpl(zahl, zahl) RETURNS zahl
	AS 'int8pl' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR + (
	leftarg = zahl, rightarg = zahl,
	procedure = zahlpl,
	commutator = +
);

CREATE FUNCTION zahlmi(zahl, zahl) RETURNS zahl
	AS 'int8mi' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR - (
	leftarg = zahl, rightarg = zahl,
	procedure = zahlmi
);

CREATE FUNCTION zahlmul(zahl, zahl) RETURNS zahl
	AS 'int8mul' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR * (
	leftarg = zahl, rightarg = zahl,
	procedure = zahlmul,
	commutator = *
);

CREATE FUNCTION zahldiv(zahl, zahl) RETURNS zahl
	AS 'int8div' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR / (
	leftarg = zahl, rightarg = zahl,
	procedure = zahldiv
);

CREATE FUNCTION zahland(zahl, zahl) RETURNS zahl
	AS 'int8and' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR & (
	leftarg = zahl, rightarg = zahl,
	procedure = zahland,
	commutator = &
);

CREATE FUNCTION zahlor(zahl, zahl) RETURNS zahl
	AS 'int8or' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR | (
	leftarg = zahl, rightarg = zahl,
	procedure = zahlor,
	commutator = |
);

CREATE FUNCTION zahlxor(zahl, zahl) RETURNS zahl
	AS 'int8xor' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR # (
	leftarg = zahl, rightarg = zahl,
	procedure = zahlxor,
	commutator = #
);


CREATE FUNCTION zahlabs(zahl) RETURNS zahl
	AS 'int8abs' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR @ (
	rightarg = zahl,
	procedure = zahlabs
);

CREATE FUNCTION zahlum(zahl) RETURNS zahl
	AS 'int8um' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR - (
	rightarg = zahl,
	procedure = zahlum
);

CREATE FUNCTION zahlnot(zahl) RETURNS zahl
	AS 'int8not' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR ~ (
	rightarg = zahl,
	procedure = zahlnot
);

CREATE FUNCTION zahlup(zahl) RETURNS zahl
	AS 'int8up' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR + (
	rightarg = zahl,
	procedure = zahlup
);

/*
Copyright (C) 2017 Christoph Berg

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/

-- type definition

CREATE TYPE roman;

CREATE OR REPLACE FUNCTION roman_in(cstring)
	RETURNS roman
	AS '$libdir/numeral'
	LANGUAGE C IMMUTABLE STRICT;

CREATE OR REPLACE FUNCTION roman_out(roman)
	RETURNS cstring
	AS '$libdir/numeral'
	LANGUAGE C IMMUTABLE STRICT;

CREATE TYPE roman (
	internallength = 8,
	input = roman_in,
	output = roman_out,
	passedbyvalue,
	alignment = double,
	category = 'N'
);

/* roman is as good as bigint, make casts */

CREATE CAST (roman AS bigint)
	WITHOUT FUNCTION
	AS IMPLICIT;

CREATE CAST (bigint AS roman)
	WITHOUT FUNCTION;

/* steal bigint's operators */

CREATE FUNCTION romaneq(roman, roman) RETURNS boolean
	AS 'int8eq' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR = (
	leftarg = roman, rightarg = roman,
	procedure = romaneq,
	commutator = =, negator = <>,
	restrict = eqsel, join = eqjoinsel,
	hashes, merges
);

CREATE FUNCTION romanne(roman, roman) RETURNS boolean
	AS 'int8ne' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR <> (
	leftarg = roman, rightarg = roman,
	procedure = romanne,
	commutator = <>, negator = =,
	restrict = neqsel, join = neqjoinsel
);

CREATE FUNCTION romanlt(roman, roman) RETURNS boolean
	AS 'int8lt' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR < (
	leftarg = roman, rightarg = roman,
	procedure = romanlt,
	commutator = >, negator = >=,
	restrict = scalarltsel, join = scalarltjoinsel
);

CREATE FUNCTION romangt(roman, roman) RETURNS boolean
	AS 'int8gt' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR > (
	leftarg = roman, rightarg = roman,
	procedure = romangt,
	commutator = <, negator = <=,
	restrict = scalargtsel, join = scalargtjoinsel
);

CREATE FUNCTION romanle(roman, roman) RETURNS boolean
	AS 'int8le' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR <= (
	leftarg = roman, rightarg = roman,
	procedure = romanle,
	commutator = >=, negator = >,
	restrict = scalarltsel, join = scalarltjoinsel
);

CREATE FUNCTION romange(roman, roman) RETURNS boolean
	AS 'int8ge' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR >= (
	leftarg = roman, rightarg = roman,
	procedure = romange,
	commutator = <=, negator = <,
	restrict = scalargtsel, join = scalargtjoinsel
);


CREATE FUNCTION romanmod(roman, roman) RETURNS roman
	AS 'int8mod' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR % (
	leftarg = roman, rightarg = roman,
	procedure = romanmod
);

CREATE FUNCTION romanpl(roman, roman) RETURNS roman
	AS 'int8pl' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR + (
	leftarg = roman, rightarg = roman,
	procedure = romanpl,
	commutator = +
);

CREATE FUNCTION romanmi(roman, roman) RETURNS roman
	AS 'int8mi' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR - (
	leftarg = roman, rightarg = roman,
	procedure = romanmi
);

CREATE FUNCTION romanmul(roman, roman) RETURNS roman
	AS 'int8mul' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR * (
	leftarg = roman, rightarg = roman,
	procedure = romanmul,
	commutator = *
);

CREATE FUNCTION romandiv(roman, roman) RETURNS roman
	AS 'int8div' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR / (
	leftarg = roman, rightarg = roman,
	procedure = romandiv
);

CREATE FUNCTION romanand(roman, roman) RETURNS roman
	AS 'int8and' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR & (
	leftarg = roman, rightarg = roman,
	procedure = romanand,
	commutator = &
);

CREATE FUNCTION romanor(roman, roman) RETURNS roman
	AS 'int8or' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR | (
	leftarg = roman, rightarg = roman,
	procedure = romanor,
	commutator = |
);

CREATE FUNCTION romanxor(roman, roman) RETURNS roman
	AS 'int8xor' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR # (
	leftarg = roman, rightarg = roman,
	procedure = romanxor,
	commutator = #
);


CREATE FUNCTION romanabs(roman) RETURNS roman
	AS 'int8abs' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR @ (
	rightarg = roman,
	procedure = romanabs
);

CREATE FUNCTION romanum(roman) RETURNS roman
	AS 'int8um' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR - (
	rightarg = roman,
	procedure = romanum
);

CREATE FUNCTION romannot(roman) RETURNS roman
	AS 'int8not' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR ~ (
	rightarg = roman,
	procedure = romannot
);

CREATE FUNCTION romanup(roman) RETURNS roman
	AS 'int8up' LANGUAGE internal IMMUTABLE STRICT;

CREATE OPERATOR + (
	rightarg = roman,
	procedure = romanup
);

