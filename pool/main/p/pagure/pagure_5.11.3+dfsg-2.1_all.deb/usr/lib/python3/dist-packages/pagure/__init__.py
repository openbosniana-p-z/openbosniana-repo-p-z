# -*- coding: utf-8 -*-

"""
 (c) 2014-2019 - Copyright Red Hat Inc

 Authors:
   Pierre-Yves Chibon <pingou@pingoured.fr>

"""

from __future__ import unicode_literals, absolute_import


__api_version__ = "0.30"
__version__ = "5.11.3"
