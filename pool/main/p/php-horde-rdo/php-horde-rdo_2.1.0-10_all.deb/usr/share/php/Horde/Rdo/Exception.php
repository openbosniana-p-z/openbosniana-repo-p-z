<?php
/**
 * @category Horde
 * @package  Rdo
 */

/**
 * @category Horde
 * @package  Rdo
 */
class Horde_Rdo_Exception extends Horde_Exception_Wrapped
{
}
