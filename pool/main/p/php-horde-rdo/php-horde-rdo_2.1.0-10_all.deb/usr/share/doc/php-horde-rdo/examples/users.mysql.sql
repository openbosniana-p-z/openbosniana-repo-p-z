CREATE TABLE users (
    id INT(11) auto_increment  NOT NULL,
    name varchar(255),
    favorite_id int(11),
    phone varchar(20),
    created varchar(10),
    updated varchar(10),

    PRIMARY KEY  (id)
);
