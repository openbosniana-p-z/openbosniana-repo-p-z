#!/usr/bin/env python
# This file was created automatically
longversion = '2020.06.05-09-17-21'
