from .gui_wx import main

main.Main()
