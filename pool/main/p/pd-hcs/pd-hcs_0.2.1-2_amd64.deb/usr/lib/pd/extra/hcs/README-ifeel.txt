
You need the iFeel linux kernel module from 
http://sourceforge.net/projects/tactile in order to use this external.

The iFeel mouse uses periodic pulses to create the various haptic 
effects.


------------------------------------------------------------------------------
control type		raw range	pd range
------------------------------------------------------------------------------
strength of pulse	1-255		0 - 1
delay between pulses	1-255		0 - infinite milliseconds
number of pulses	1-255		0 - infinite


