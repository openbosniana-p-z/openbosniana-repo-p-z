srvLoader.setMetaData({name: "New Classic"});
