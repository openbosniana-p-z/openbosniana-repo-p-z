srvLoader.setMetaData({
	name: "LunnaCat Classic",
	version: "1.2",
	authors: ["majik <maksim.maj@gmail.com>","Sergey Ilinykh <rion4ik@gmail.com>"],
	description: "Classic dark theme with nice background.",
	url: "http://psi-im.org"
});
