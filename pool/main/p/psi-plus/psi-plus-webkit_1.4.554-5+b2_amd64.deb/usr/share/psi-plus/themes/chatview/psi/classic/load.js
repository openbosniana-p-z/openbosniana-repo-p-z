srvLoader.setMetaData({
	name: "Classic",
	version: "1.0",
	authors: ["Sergey Ilinykh <rion4ik@gmail.com>"],
	description: "Classic chat view as it was before themes support.",
	url: "https://psi-im.org"
});
