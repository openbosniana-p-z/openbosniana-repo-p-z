Name			= silk
Author			= http://www.famfamfam.com/lab/icons/silk/
Made for Psi		= maksim.maj@gmail.com, ky6uk@jabber.ufanet.ru
Date			= Thu, 25 Dec 2008 01:42:32 +0500
Version			= 1.1