# Migration

In this guide you will find specifics regarding changes from version 2 to
version 3 of laminas-eventmanager, including recommendations for forward-proofing
your v2 applications such that they will work under v3.
