<?php

namespace Laminas\EventManager\Exception;

/**
 * Invalid callback exception
 */
class InvalidCallbackException extends DomainException implements ExceptionInterface
{
}
