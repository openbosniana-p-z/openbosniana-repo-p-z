<?php

namespace Laminas\EventManager\Exception;

use Throwable;

/**
 * Base exception interface
 */
interface ExceptionInterface extends Throwable
{
}
