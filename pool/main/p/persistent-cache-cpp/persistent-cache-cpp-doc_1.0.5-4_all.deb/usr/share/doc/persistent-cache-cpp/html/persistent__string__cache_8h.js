var persistent__string__cache_8h =
[
    [ "core::PersistentStringCache", "classcore_1_1PersistentStringCache.html", "classcore_1_1PersistentStringCache" ],
    [ "core::PersistentStringCache::Data", "structcore_1_1PersistentStringCache_1_1Data.html", "structcore_1_1PersistentStringCache_1_1Data" ]
];