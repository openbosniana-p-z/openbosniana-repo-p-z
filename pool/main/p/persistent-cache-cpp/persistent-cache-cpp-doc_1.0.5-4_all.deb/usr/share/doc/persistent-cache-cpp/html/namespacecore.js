var namespacecore =
[
    [ "CacheCodec", "structcore_1_1CacheCodec.html", null ],
    [ "PersistentCache", "classcore_1_1PersistentCache.html", "classcore_1_1PersistentCache" ],
    [ "PersistentCacheStats", "classcore_1_1PersistentCacheStats.html", "classcore_1_1PersistentCacheStats" ],
    [ "PersistentStringCache", "classcore_1_1PersistentStringCache.html", "classcore_1_1PersistentStringCache" ],
    [ "Optional", "namespacecore.html#afdb9bed163cd42fbf86a52f2e8f775a4", null ],
    [ "CacheDiscardPolicy", "namespacecore.html#a2e77cb6543f624a64853a66237d75c2b", [
      [ "lru_ttl", "namespacecore.html#a2e77cb6543f624a64853a66237d75c2baa4914aeb48bd09b6575063d9431dbb2b", null ],
      [ "lru_only", "namespacecore.html#a2e77cb6543f624a64853a66237d75c2ba0e315111b8a159b5ee979b18c98336a2", null ]
    ] ],
    [ "CacheEvent", "namespacecore.html#aca9c25d2a4df9c9a4787c58cc94330da", [
      [ "get", "namespacecore.html#aca9c25d2a4df9c9a4787c58cc94330daab5eda0a74558a342cf659187f06f746f", null ],
      [ "put", "namespacecore.html#aca9c25d2a4df9c9a4787c58cc94330daa8e13ffc9fd9d6a6761231a764bdf106b", null ],
      [ "invalidate", "namespacecore.html#aca9c25d2a4df9c9a4787c58cc94330daac9ef7a446d9608ed2229ef347d13af7e", null ],
      [ "touch", "namespacecore.html#aca9c25d2a4df9c9a4787c58cc94330daab96ba508e3690f5168e4b0e68b15b178", null ],
      [ "miss", "namespacecore.html#aca9c25d2a4df9c9a4787c58cc94330daade13fc4490fbd29a732bf77eb7476650", null ],
      [ "evict_ttl", "namespacecore.html#aca9c25d2a4df9c9a4787c58cc94330daa3707be4e6d7473f7bcb7e83394c3ed4d", null ],
      [ "evict_lru", "namespacecore.html#aca9c25d2a4df9c9a4787c58cc94330daa94f8a15c716e0386fee0d3cef663eeea", null ],
      [ "END_", "namespacecore.html#aca9c25d2a4df9c9a4787c58cc94330daa27971df3fbc1599e250791ae5099a4e9", null ]
    ] ],
    [ "operator&", "namespacecore.html#abdab6325725bb4a8601f89253c7619b0", null ],
    [ "operator&=", "namespacecore.html#a172f527a6ec30695bb07bbab55488c7a", null ],
    [ "operator|", "namespacecore.html#a7fe8baf2f0d4ce11b0d958b65e6ab46c", null ],
    [ "operator|=", "namespacecore.html#a4abac310601dffd5001e822a45152344", null ],
    [ "operator~", "namespacecore.html#aeb50e1247398a15e7ec14229075eb14f", null ]
];