var structcore_1_1PersistentStringCache_1_1Data =
[
    [ "metadata", "structcore_1_1PersistentStringCache_1_1Data.html#aaf382b3f6b3eeab532ff2d23cd3d6e6d", null ],
    [ "value", "structcore_1_1PersistentStringCache_1_1Data.html#a6ebef0002b55e86817cd4841b424819d", null ]
];