var persistent__cache_8h =
[
    [ "core::PersistentCache< K, V, M >", "classcore_1_1PersistentCache.html", "classcore_1_1PersistentCache" ],
    [ "core::PersistentCache< K, V, M >::Data", "structcore_1_1PersistentCache_1_1Data.html", "structcore_1_1PersistentCache_1_1Data" ]
];