var structcore_1_1PersistentCache_1_1Data =
[
    [ "metadata", "structcore_1_1PersistentCache_1_1Data.html#ac1a911857863e062b9436805b5642652", null ],
    [ "value", "structcore_1_1PersistentCache_1_1Data.html#a8c836c8ee6a91c95eefa60f2eb7479db", null ]
];