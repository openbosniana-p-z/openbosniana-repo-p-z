var annotated_dup =
[
    [ "core", "namespacecore.html", [
      [ "CacheCodec", "structcore_1_1CacheCodec.html", null ],
      [ "PersistentCache", "classcore_1_1PersistentCache.html", "classcore_1_1PersistentCache" ],
      [ "PersistentCacheStats", "classcore_1_1PersistentCacheStats.html", "classcore_1_1PersistentCacheStats" ],
      [ "PersistentStringCache", "classcore_1_1PersistentStringCache.html", "classcore_1_1PersistentStringCache" ]
    ] ]
];