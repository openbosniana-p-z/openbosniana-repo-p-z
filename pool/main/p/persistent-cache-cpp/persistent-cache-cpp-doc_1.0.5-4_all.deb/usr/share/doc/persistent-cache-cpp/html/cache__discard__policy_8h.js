var cache__discard__policy_8h =
[
    [ "CacheDiscardPolicy", "cache__discard__policy_8h.html#a2e77cb6543f624a64853a66237d75c2b", [
      [ "lru_ttl", "cache__discard__policy_8h.html#a2e77cb6543f624a64853a66237d75c2baa4914aeb48bd09b6575063d9431dbb2b", null ],
      [ "lru_only", "cache__discard__policy_8h.html#a2e77cb6543f624a64853a66237d75c2ba0e315111b8a159b5ee979b18c98336a2", null ]
    ] ]
];