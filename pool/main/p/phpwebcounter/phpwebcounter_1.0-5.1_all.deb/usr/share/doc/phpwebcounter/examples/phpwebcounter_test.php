<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta content="text/html; charset=ISO-8859-1"
 http-equiv="content-type">
  <title>Counter Test</title>
</head>
<body>
<div style="text-align: center;"><big
 style="font-weight: bold; color: rgb(255, 0, 0);"><big><big><big>Counter
Test</big></big></big></big><br>
<br>
<big><big>Hits:</big></big><br>
<?php require("/phpwebcounter/phpwebcounter.php"); ?><br>
</div>
</body>
</html>
