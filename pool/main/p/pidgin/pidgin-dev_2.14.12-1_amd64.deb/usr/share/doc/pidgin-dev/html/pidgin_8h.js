var pidgin_8h =
[
    [ "PIDGIN_UI", "pidgin_8h.html#a54a05b44a5b8579df1f00392982e7077", null ]
];