var group__finch =
[
    [ "gntaccount.h", "gntaccount_8h.html", null ],
    [ "gntblist.h", "gntblist_8h.html", null ],
    [ "gntcertmgr.h", "gntcertmgr_8h.html", null ],
    [ "gntconn.h", "gntconn_8h.html", null ],
    [ "gntconv.h", "gntconv_8h.html", null ],
    [ "gntdebug.h", "gntdebug_8h.html", null ],
    [ "gntft.h", "gntft_8h.html", null ],
    [ "gntidle.h", "gntidle_8h.html", null ],
    [ "gntlog.h", "gntlog_8h.html", null ],
    [ "gntmedia.h", "gntmedia_8h.html", null ],
    [ "gntnotify.h", "gntnotify_8h.html", null ],
    [ "gntplugin.h", "gntplugin_8h.html", null ],
    [ "gntpounce.h", "gntpounce_8h.html", null ],
    [ "gntprefs.h", "gntprefs_8h.html", null ],
    [ "gntrequest.h", "gntrequest_8h.html", null ],
    [ "gntroomlist.h", "gntroomlist_8h.html", null ],
    [ "gntsound.h", "gntsound_8h.html", null ],
    [ "gntstatus.h", "gntstatus_8h.html", null ]
];