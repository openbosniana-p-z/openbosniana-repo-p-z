var gtkaccount_8h =
[
    [ "pidgin_account_dialog_show", "gtkaccount_8h.html#af51b91e5021e80328de80bc44139647b", null ],
    [ "pidgin_account_get_handle", "gtkaccount_8h.html#a1914445b5ab83327c6fef92a594a162d", null ],
    [ "pidgin_account_init", "gtkaccount_8h.html#ae5856f128af32722b5c4bcf45e456e5a", null ],
    [ "pidgin_account_uninit", "gtkaccount_8h.html#a4426b88101df8ddf8b3be98615862cfe", null ],
    [ "pidgin_accounts_get_ui_ops", "gtkaccount_8h.html#a0e367c73261b18cfee655df528ee8934", null ],
    [ "pidgin_accounts_window_hide", "gtkaccount_8h.html#a121b2d5f41672bbefcb2ad2b26c62cc6", null ],
    [ "pidgin_accounts_window_show", "gtkaccount_8h.html#a4d57fbcd3ac83b03e3ff4e7206fd90af", null ]
];