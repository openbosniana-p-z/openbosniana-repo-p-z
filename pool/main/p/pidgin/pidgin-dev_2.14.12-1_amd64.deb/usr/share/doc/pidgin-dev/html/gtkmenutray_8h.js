var gtkmenutray_8h =
[
    [ "_PidginMenuTray", "struct__PidginMenuTray.html", "struct__PidginMenuTray" ],
    [ "_PidginMenuTrayClass", "struct__PidginMenuTrayClass.html", "struct__PidginMenuTrayClass" ],
    [ "pidgin_menu_tray_append", "gtkmenutray_8h.html#a34354b96d81ca8d81caa2fb1f7872c80", null ],
    [ "pidgin_menu_tray_get_box", "gtkmenutray_8h.html#adf9b7e8c723e75dff387ac6ce9b1aa29", null ],
    [ "pidgin_menu_tray_get_gtype", "gtkmenutray_8h.html#aa8e327da979a5461bf8639a014aefb14", null ],
    [ "pidgin_menu_tray_new", "gtkmenutray_8h.html#ad15612ec43db589f01c9755d860bc303", null ],
    [ "pidgin_menu_tray_prepend", "gtkmenutray_8h.html#afe800a0135a5127246316bebca123cba", null ],
    [ "pidgin_menu_tray_set_tooltip", "gtkmenutray_8h.html#a553db049595a88af584413292a76bbeb", null ]
];