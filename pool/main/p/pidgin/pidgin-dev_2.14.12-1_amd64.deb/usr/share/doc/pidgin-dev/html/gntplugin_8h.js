var gntplugin_8h =
[
    [ "FINCH_PLUGIN_UI_INFO", "gntplugin_8h.html#a78e94cfdd9159587874beb605e0c263f", null ],
    [ "PURPLE_IS_GNT_PLUGIN", "gntplugin_8h.html#a888681a90a979d6ced2ba23142e664e0", null ],
    [ "finch_plugins_save_loaded", "gntplugin_8h.html#afe64ec3451ac2de336ec3ad934c263ab", null ],
    [ "finch_plugins_show_all", "gntplugin_8h.html#a228fc2951e0d93d2efcd1bc6b3a170e7", null ]
];