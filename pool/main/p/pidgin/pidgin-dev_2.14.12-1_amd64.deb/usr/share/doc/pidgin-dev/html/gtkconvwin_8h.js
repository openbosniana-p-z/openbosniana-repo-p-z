var gtkconvwin_8h =
[
    [ "_PidginWindow", "struct__PidginWindow.html", "struct__PidginWindow" ]
];