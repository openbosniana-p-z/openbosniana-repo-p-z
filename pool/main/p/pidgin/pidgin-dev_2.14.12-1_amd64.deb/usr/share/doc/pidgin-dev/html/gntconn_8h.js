var gntconn_8h =
[
    [ "finch_connections_get_ui_ops", "gntconn_8h.html#ada6944641d06db69d943edc544cd07e6", null ],
    [ "finch_connections_init", "gntconn_8h.html#a6d58d284de1e462d703973311c282cba", null ],
    [ "finch_connections_uninit", "gntconn_8h.html#a7c91bcfedaf294c1bb1f8c4ba0e6a71d", null ]
];