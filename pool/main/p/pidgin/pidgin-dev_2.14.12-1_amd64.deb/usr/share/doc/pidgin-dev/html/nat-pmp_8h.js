var nat_pmp_8h =
[
    [ "purple_pmp_create_map", "nat-pmp_8h.html#a1419bc4f651f62514b15208635897181", null ],
    [ "purple_pmp_destroy_map", "nat-pmp_8h.html#a1a4373fa9eb5c53b4ac250af3f922895", null ],
    [ "purple_pmp_init", "nat-pmp_8h.html#a407ea8dd4109dff4fd3ad03f25a35619", null ]
];