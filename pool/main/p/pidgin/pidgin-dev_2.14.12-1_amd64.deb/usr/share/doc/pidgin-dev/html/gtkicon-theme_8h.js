var gtkicon_theme_8h =
[
    [ "_PidginIconTheme", "struct__PidginIconTheme.html", null ],
    [ "_PidginIconThemeClass", "struct__PidginIconThemeClass.html", null ],
    [ "PidginIconTheme", "gtkicon-theme_8h.html#a3ed60b0f2fff3a161b1d44222716a516", null ],
    [ "pidgin_icon_theme_get_icon", "gtkicon-theme_8h.html#a022f7ac5c4224470083590eba4e0715c", null ],
    [ "pidgin_icon_theme_get_type", "gtkicon-theme_8h.html#a7ef25a09fe50de62c614a84c308699c8", null ],
    [ "pidgin_icon_theme_set_icon", "gtkicon-theme_8h.html#a263c56186d4c6ea6128d5edd180b0910", null ]
];