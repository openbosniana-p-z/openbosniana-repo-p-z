var gntprefs_8h =
[
    [ "finch_prefs_init", "gntprefs_8h.html#a0c4287ffe09cf25fcc70906988364fd9", null ],
    [ "finch_prefs_show_all", "gntprefs_8h.html#a837408d237a361e118da8d29c02b77d3", null ],
    [ "finch_prefs_update_old", "gntprefs_8h.html#a1c7364f7c3ae0565147fa9aa5c7a7aac", null ]
];