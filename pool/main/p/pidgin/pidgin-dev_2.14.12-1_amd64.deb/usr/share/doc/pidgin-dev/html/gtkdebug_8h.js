var gtkdebug_8h =
[
    [ "pidgin_debug_get_handle", "gtkdebug_8h.html#a1852fb8cee45925ccf0ffbbb5123d044", null ],
    [ "pidgin_debug_get_ui_ops", "gtkdebug_8h.html#a703edcdf58d432a4fc2f4e71de270cbc", null ],
    [ "pidgin_debug_init", "gtkdebug_8h.html#ae21835bfa64fa3370a59a9f3e3d0feb2", null ],
    [ "pidgin_debug_uninit", "gtkdebug_8h.html#a6fc0569f7540f8c131c5008ccb321332", null ],
    [ "pidgin_debug_window_hide", "gtkdebug_8h.html#a3c7e9a506bc8ddccb6796377d82244a3", null ],
    [ "pidgin_debug_window_show", "gtkdebug_8h.html#a4d87b841ff1602d10bf0ad9e6dea607a", null ]
];