var gntroomlist_8h =
[
    [ "finch_roomlist_get_ui_ops", "gntroomlist_8h.html#a6aeebc225afff8de7ecce0466c892756", null ],
    [ "finch_roomlist_init", "gntroomlist_8h.html#a829164f7b39bd578b9b7dbf532ebed58", null ],
    [ "finch_roomlist_show_all", "gntroomlist_8h.html#af25e13e597a85d6672b02fa4ec4a6e67", null ],
    [ "finch_roomlist_uninit", "gntroomlist_8h.html#a6bd9c8ef41d33378972c90db37faa67d", null ]
];