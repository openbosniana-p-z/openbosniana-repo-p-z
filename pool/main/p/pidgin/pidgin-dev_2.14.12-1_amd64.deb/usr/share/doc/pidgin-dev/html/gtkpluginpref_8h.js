var gtkpluginpref_8h =
[
    [ "pidgin_plugin_pref_create_frame", "gtkpluginpref_8h.html#a98b857667fca67081cf041c033bed8da", null ]
];