var desktopitem_8h =
[
    [ "purple_desktop_item_copy", "desktopitem_8h.html#a1b2bac089b946022cabcec648c49ba38", null ],
    [ "purple_desktop_item_get_entry_type", "desktopitem_8h.html#a3df3569e78341a481dfb99767261e1f6", null ],
    [ "purple_desktop_item_get_string", "desktopitem_8h.html#a8ba8f7a215bef443709fa9a09ac69585", null ],
    [ "purple_desktop_item_new_from_file", "desktopitem_8h.html#aae722e9683e4eb0a79436a909f04292f", null ],
    [ "purple_desktop_item_unref", "desktopitem_8h.html#a702c238974487ed13d12253fc155423e", null ]
];