var gntstatus_8h =
[
    [ "finch_savedstatus_edit", "gntstatus_8h.html#a6874d1b0b73aa7e5cce41f22c2ca7be9", null ],
    [ "finch_savedstatus_show_all", "gntstatus_8h.html#aabea427047c90dcc679454e6d29ccb47", null ]
];