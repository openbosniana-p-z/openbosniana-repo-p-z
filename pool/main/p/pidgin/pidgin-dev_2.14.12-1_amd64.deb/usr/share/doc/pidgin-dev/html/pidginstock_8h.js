var pidginstock_8h =
[
    [ "_PidginStockIconTheme", "struct__PidginStockIconTheme.html", null ],
    [ "_PidginStockIconThemeClass", "struct__PidginStockIconThemeClass.html", null ],
    [ "PIDGIN_ICON_SIZE_TANGO_MICROSCOPIC", "pidginstock_8h.html#a1ee67f88b8540064500caa29c0a88934", null ],
    [ "PidginStockIconTheme", "pidginstock_8h.html#a042b5b244f33d0893c02df4c792a25b4", null ],
    [ "pidgin_stock_icon_theme_get_type", "pidginstock_8h.html#ae134447bb8a09e02ea7dea2184ebbb26", null ],
    [ "pidgin_stock_init", "pidginstock_8h.html#a00867e80b8e5d280548bd6f0654fa28d", null ],
    [ "pidgin_stock_load_status_icon_theme", "pidginstock_8h.html#a1a91ce752b92aff4425d37126df1de8c", null ]
];