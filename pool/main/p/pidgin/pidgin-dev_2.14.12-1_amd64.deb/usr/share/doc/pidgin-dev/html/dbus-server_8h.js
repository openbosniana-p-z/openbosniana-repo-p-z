var dbus_server_8h =
[
    [ "_PurpleDBusType", "struct__PurpleDBusType.html", null ],
    [ "DBUS_EXPORT", "dbus-server_8h.html#ab64386a75b748deb7e3bc41a417d5661", null ],
    [ "PurpleDBusType", "dbus-server_8h.html#a1234bae23cbd69c488442872ca8d95a0", null ],
    [ "purple_dbus_get_handle", "dbus-server_8h.html#aebc4cb1ac533b4c483dd0007c97644b4", null ],
    [ "purple_dbus_get_init_error", "dbus-server_8h.html#a543d94f5063e2511d984f6816b6100be", null ],
    [ "purple_dbus_init", "dbus-server_8h.html#a82be09d2c488a528e9ce7c2d8fbcbe41", null ],
    [ "purple_dbus_init_ids", "dbus-server_8h.html#a70247e06faa51b537ea13005b7a75a27", null ],
    [ "purple_dbus_is_owner", "dbus-server_8h.html#a68f8adcd04586eccfdd0c7d24471ac32", null ],
    [ "purple_dbus_register_pointer", "dbus-server_8h.html#a49018f65d18352cd60428339b36c7c0d", null ],
    [ "purple_dbus_signal_emit_purple", "dbus-server_8h.html#a8872c1a006fdd95b949d24188dde5b7e", null ],
    [ "purple_dbus_uninit", "dbus-server_8h.html#a339663ca9782725b2e85f28bc694ac99", null ],
    [ "purple_dbus_unregister_pointer", "dbus-server_8h.html#a5f9feac692adced1a8ef142f953e9d87", null ]
];