var imgstore_8h =
[
    [ "PurpleStoredImage", "imgstore_8h.html#aa767d45f7df5f9d64bcf4466bdd229a0", null ],
    [ "purple_imgstore_add", "imgstore_8h.html#a4d5cb5f04e3355bae7306bbca7776421", null ],
    [ "purple_imgstore_add_with_id", "imgstore_8h.html#a6e992b86c90965143d380c9454132749", null ],
    [ "purple_imgstore_find_by_id", "imgstore_8h.html#a0ffc1942cf38f01105b39a803ceb93bc", null ],
    [ "purple_imgstore_get_data", "imgstore_8h.html#a05cbe0f94db8e8d45e57054ac80d8d44", null ],
    [ "purple_imgstore_get_extension", "imgstore_8h.html#ab688837239e14c3807baa2f086885bc6", null ],
    [ "purple_imgstore_get_filename", "imgstore_8h.html#a55219d753ac24b79cd0ca8270d7db110", null ],
    [ "purple_imgstore_get_handle", "imgstore_8h.html#a05465ec343088b8c1a5f9037c51e7714", null ],
    [ "purple_imgstore_get_size", "imgstore_8h.html#a132d917d32da2a93f03214fe779894b4", null ],
    [ "purple_imgstore_init", "imgstore_8h.html#a54313105aa003b9c70f93083580e0c83", null ],
    [ "purple_imgstore_new_from_file", "imgstore_8h.html#a5f871a2c813086a5106cc27c4844deba", null ],
    [ "purple_imgstore_ref", "imgstore_8h.html#afc324728653125d05e932b8dee365bf3", null ],
    [ "purple_imgstore_ref_by_id", "imgstore_8h.html#a55ab8dc8a12fb896ea6775af9eb434cc", null ],
    [ "purple_imgstore_uninit", "imgstore_8h.html#a81de0fa870dfc9e9a8933d086963e7d3", null ],
    [ "purple_imgstore_unref", "imgstore_8h.html#af27adc6652a56e9a5ce1c33ffb322ebf", null ],
    [ "purple_imgstore_unref_by_id", "imgstore_8h.html#a8924cdc29ff85b40f9fd68c581224bad", null ]
];