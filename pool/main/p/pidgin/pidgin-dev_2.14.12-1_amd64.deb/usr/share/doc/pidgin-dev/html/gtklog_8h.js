var gtklog_8h =
[
    [ "_PidginLogViewer", "struct__PidginLogViewer.html", "struct__PidginLogViewer" ],
    [ "pidgin_log_get_handle", "gtklog_8h.html#a21e4c40fdd707cc7ec0927fe25d76fe1", null ],
    [ "pidgin_log_init", "gtklog_8h.html#a5aa14789ac507b7c4178f44fedeb3362", null ],
    [ "pidgin_log_uninit", "gtklog_8h.html#af2ec5329b5fe65ae153754b17a0c3d38", null ]
];