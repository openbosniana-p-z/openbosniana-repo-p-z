var gtkprivacy_8h =
[
    [ "pidgin_privacy_dialog_hide", "gtkprivacy_8h.html#af86b43def6c05b25a6c82999acb64b4a", null ],
    [ "pidgin_privacy_dialog_show", "gtkprivacy_8h.html#a6a6679bbb8a4617201d3a8dfcc2bc131", null ],
    [ "pidgin_privacy_get_ui_ops", "gtkprivacy_8h.html#a549a7a42f9885a76c4693b3da9b093c5", null ],
    [ "pidgin_privacy_init", "gtkprivacy_8h.html#aa11830622b7e700c6d086560b9930b8b", null ],
    [ "pidgin_request_add_block", "gtkprivacy_8h.html#a50802f552e0f3345ea68bf1ddb9579c0", null ],
    [ "pidgin_request_add_permit", "gtkprivacy_8h.html#a02d3f6cb719e0c1f3943a9e0e22d062d", null ]
];