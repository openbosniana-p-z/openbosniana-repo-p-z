var gtkidle_8h =
[
    [ "pidgin_idle_get_ui_ops", "gtkidle_8h.html#a7f768c358187ce43a0ee660f8487ff4a", null ]
];