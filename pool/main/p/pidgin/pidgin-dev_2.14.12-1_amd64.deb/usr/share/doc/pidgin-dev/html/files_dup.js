var files_dup =
[
    [ "finch", "dir_cd8aa332fe6d08d569d8c46b12fdf7b2.html", "dir_cd8aa332fe6d08d569d8c46b12fdf7b2" ],
    [ "libpurple", "dir_e0d8e5251bd4975c42d339564d664d96.html", "dir_e0d8e5251bd4975c42d339564d664d96" ],
    [ "pidgin", "dir_55b5f44c5e4b0b88c99a920107bdef6e.html", "dir_55b5f44c5e4b0b88c99a920107bdef6e" ]
];