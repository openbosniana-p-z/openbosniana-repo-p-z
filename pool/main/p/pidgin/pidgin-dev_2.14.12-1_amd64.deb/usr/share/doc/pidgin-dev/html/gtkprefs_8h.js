var gtkprefs_8h =
[
    [ "pidgin_prefs_checkbox", "gtkprefs_8h.html#ac9a3431731f08bde3530d983438da6cf", null ],
    [ "pidgin_prefs_dropdown", "gtkprefs_8h.html#a1694f5370c4ec983994898654e0482c9", null ],
    [ "pidgin_prefs_dropdown_from_list", "gtkprefs_8h.html#aeb51f8dfb65d1fd44faf8ae62b9cb8d3", null ],
    [ "pidgin_prefs_init", "gtkprefs_8h.html#a833c508204bed9f273d2cc4033a264a6", null ],
    [ "pidgin_prefs_labeled_entry", "gtkprefs_8h.html#a240ae6fe9fbd2a562e41ac76612ec741", null ],
    [ "pidgin_prefs_labeled_password", "gtkprefs_8h.html#a52670265c3a88863839fa6b2d3684c5e", null ],
    [ "pidgin_prefs_labeled_spin_button", "gtkprefs_8h.html#a2bb390ab5b84cde8eb78d12f5950191b", null ],
    [ "pidgin_prefs_show", "gtkprefs_8h.html#ac3b85e6867b7a78f8c71589c861e9cdf", null ],
    [ "pidgin_prefs_update_old", "gtkprefs_8h.html#a2327ce96d9a0fe687885ae6e3b289118", null ]
];