var gtkdnd_hints_8h =
[
    [ "DndHintPosition", "gtkdnd-hints_8h.html#a5fa15e8c708a621aa0cd2a7601928fe7", [
      [ "HINT_POSITION_RIGHT", "gtkdnd-hints_8h.html#a5fa15e8c708a621aa0cd2a7601928fe7a34bd66790f6770630f1836fc9b0a9b55", null ],
      [ "HINT_POSITION_LEFT", "gtkdnd-hints_8h.html#a5fa15e8c708a621aa0cd2a7601928fe7a4ef0d390956f3f8d986bd0109c9eda2a", null ],
      [ "HINT_POSITION_TOP", "gtkdnd-hints_8h.html#a5fa15e8c708a621aa0cd2a7601928fe7ae714e656edc5177c9164fbddfdc0c98b", null ],
      [ "HINT_POSITION_BOTTOM", "gtkdnd-hints_8h.html#a5fa15e8c708a621aa0cd2a7601928fe7a9d6fffd0f4f47db3293083854beff8b2", null ],
      [ "HINT_POSITION_CENTER", "gtkdnd-hints_8h.html#a5fa15e8c708a621aa0cd2a7601928fe7a8ea804ba7327c4b01cff8604c1a0ecbc", null ]
    ] ],
    [ "DndHintWindowId", "gtkdnd-hints_8h.html#a1bd294771df51d9ed5cbae38ea34b42f", [
      [ "HINT_ARROW_UP", "gtkdnd-hints_8h.html#a1bd294771df51d9ed5cbae38ea34b42faafdab27d94e28d4262b6d8109f3dbdca", null ],
      [ "HINT_ARROW_DOWN", "gtkdnd-hints_8h.html#a1bd294771df51d9ed5cbae38ea34b42fa04cf23915e31f81435be9fa6c47a878e", null ],
      [ "HINT_ARROW_LEFT", "gtkdnd-hints_8h.html#a1bd294771df51d9ed5cbae38ea34b42fa33adcec76cdbfebbebb43014979e2f63", null ],
      [ "HINT_ARROW_RIGHT", "gtkdnd-hints_8h.html#a1bd294771df51d9ed5cbae38ea34b42fa53e5ca9cb566a1d10e9b27dc75823404", null ]
    ] ],
    [ "dnd_hints_hide", "gtkdnd-hints_8h.html#aa15428d44b30b6383a5d72c1364f7603", null ],
    [ "dnd_hints_hide_all", "gtkdnd-hints_8h.html#abf2f3e386341c07c1aa422b9fb87e4b9", null ],
    [ "dnd_hints_show", "gtkdnd-hints_8h.html#a5dda8d89ec10b825329e9e872dd105af", null ],
    [ "dnd_hints_show_relative", "gtkdnd-hints_8h.html#ae33ba2d4f768138fa01a0cd6c631c2d2", null ]
];