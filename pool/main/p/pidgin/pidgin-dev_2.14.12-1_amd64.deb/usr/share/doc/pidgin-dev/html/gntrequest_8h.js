var gntrequest_8h =
[
    [ "finch_request_field_get_widget", "gntrequest_8h.html#a55b36eeed267a671ff27beecb877985a", null ],
    [ "finch_request_get_ui_ops", "gntrequest_8h.html#a058d1c0c062aa2278f870b4eee003dc1", null ],
    [ "finch_request_init", "gntrequest_8h.html#a88439e55af7f4af58ca948f379f29f0f", null ],
    [ "finch_request_save_in_prefs", "gntrequest_8h.html#a4a0418fa0a3a4d4758c4c976d0476dd1", null ],
    [ "finch_request_uninit", "gntrequest_8h.html#a4f1b9fa8a74485cf82205077f631225a", null ]
];