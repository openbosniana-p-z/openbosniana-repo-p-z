var gtkft_8h =
[
    [ "PidginXferDialog", "gtkft_8h.html#a4e79f8e13755cac9d1f5f0605fc2edec", null ],
    [ "pidgin_get_xfer_dialog", "gtkft_8h.html#a024307bff49f0638ec639ff7059d1951", null ],
    [ "pidgin_set_xfer_dialog", "gtkft_8h.html#afb71ce092a12af78785d4bc116f13fc9", null ],
    [ "pidgin_xfer_dialog_add_xfer", "gtkft_8h.html#a364eabc185d68ab1f3d20616c17ea22f", null ],
    [ "pidgin_xfer_dialog_cancel_xfer", "gtkft_8h.html#ab6f6dd56cf25a0183c0ba21aa6cb7bac", null ],
    [ "pidgin_xfer_dialog_destroy", "gtkft_8h.html#a2b6c2c177a8c0ad444deb234ce3cd5b7", null ],
    [ "pidgin_xfer_dialog_hide", "gtkft_8h.html#a9023a6256ecfbf354eb2c2f329b12b79", null ],
    [ "pidgin_xfer_dialog_new", "gtkft_8h.html#a0906f22ab5e9fed509c30fcee1afddb8", null ],
    [ "pidgin_xfer_dialog_remove_xfer", "gtkft_8h.html#ab6178169961d1f8273700d396f566994", null ],
    [ "pidgin_xfer_dialog_show", "gtkft_8h.html#a0c3c630841cd3f9a4bf7efba1dd3ea41", null ],
    [ "pidgin_xfer_dialog_update_xfer", "gtkft_8h.html#afa4b257d038adc776acee3e47a12a8cf", null ],
    [ "pidgin_xfers_get_ui_ops", "gtkft_8h.html#a0ed8479b90cdfb125cbf72d37305550d", null ],
    [ "pidgin_xfers_init", "gtkft_8h.html#a1571ff7166f39e88496df94550763f14", null ],
    [ "pidgin_xfers_uninit", "gtkft_8h.html#aa084b26d542fe554b390463bf9c489ed", null ]
];