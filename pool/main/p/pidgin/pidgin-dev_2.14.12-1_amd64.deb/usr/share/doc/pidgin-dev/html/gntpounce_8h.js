var gntpounce_8h =
[
    [ "finch_pounce_editor_show", "gntpounce_8h.html#a0ca254725ebfc37c20c318c1f9bfa05a", null ],
    [ "finch_pounces_get_handle", "gntpounce_8h.html#a09bc6166408d6b2cf4055bed978547bb", null ],
    [ "finch_pounces_init", "gntpounce_8h.html#a0878a1ffbadf6bbb89d01f8c69da6fd6", null ],
    [ "finch_pounces_manager_hide", "gntpounce_8h.html#a2db0036ed35c1ca9ef4b788df67abd8a", null ],
    [ "finch_pounces_manager_show", "gntpounce_8h.html#ab495cdd571c6da33a9218a7e87af44f1", null ],
    [ "finch_pounces_uninit", "gntpounce_8h.html#af45792252abf2a2bfa347b4a3281b183", null ]
];