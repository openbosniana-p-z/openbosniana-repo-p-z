var gtkconv_8h =
[
    [ "_PidginImPane", "struct__PidginImPane.html", null ],
    [ "_PidginChatPane", "struct__PidginChatPane.html", null ],
    [ "_PidginConversation", "struct__PidginConversation.html", "struct__PidginConversation" ],
    [ "PidginUnseenState", "gtkconv_8h.html#a342abe4cf67398e3b2827e74c29bd6d8", [
      [ "PIDGIN_UNSEEN_NONE", "gtkconv_8h.html#a342abe4cf67398e3b2827e74c29bd6d8aff19a8147fe376b2a93a1ac47f3624c5", null ],
      [ "PIDGIN_UNSEEN_EVENT", "gtkconv_8h.html#a342abe4cf67398e3b2827e74c29bd6d8ab3e5699bc48e002600e27623ed647c8e", null ],
      [ "PIDGIN_UNSEEN_NO_LOG", "gtkconv_8h.html#a342abe4cf67398e3b2827e74c29bd6d8ac775c631145fd54748445a87cda8ad4f", null ],
      [ "PIDGIN_UNSEEN_TEXT", "gtkconv_8h.html#a342abe4cf67398e3b2827e74c29bd6d8aae2ba117909b13a91d73cd125e160972", null ],
      [ "PIDGIN_UNSEEN_NICK", "gtkconv_8h.html#a342abe4cf67398e3b2827e74c29bd6d8a6c2b59f2feb5191ecd40ff4552235290", null ]
    ] ],
    [ "pidgin_conv_attach_to_conversation", "gtkconv_8h.html#a66187b6413947df138c2798a09c438ff", null ],
    [ "pidgin_conv_present_conversation", "gtkconv_8h.html#a2c874d882a2cb1e3868b6860980ede44", null ],
    [ "pidgin_conv_switch_active_conversation", "gtkconv_8h.html#a3b3d60195f89f2fa9d8152a35452cc25", null ],
    [ "pidgin_conv_update_buddy_icon", "gtkconv_8h.html#abbda3eed2b0e6d900f2166b2647803b8", null ],
    [ "pidgin_conv_update_buttons_by_protocol", "gtkconv_8h.html#a2e3bdc38d7401d01c98a2c8241f724ea", null ],
    [ "pidgin_conversations_fill_menu", "gtkconv_8h.html#aa02aa4d04e3de4df0b0cfae2a18f5831", null ],
    [ "pidgin_conversations_find_unseen_list", "gtkconv_8h.html#ad74d58bfa6f9739eac498b4254304072", null ],
    [ "pidgin_conversations_get_conv_ui_ops", "gtkconv_8h.html#a592959b200bd2051ed526cd6b43e1356", null ],
    [ "pidgin_conversations_get_handle", "gtkconv_8h.html#a6cb81fe45ba222cfffe93b3cd33d102d", null ],
    [ "pidgin_conversations_init", "gtkconv_8h.html#a23b3be44ab48c63a62e41befa5e76696", null ],
    [ "pidgin_conversations_uninit", "gtkconv_8h.html#a1936ccc33cbbbc84705c5d7c476c9385", null ]
];