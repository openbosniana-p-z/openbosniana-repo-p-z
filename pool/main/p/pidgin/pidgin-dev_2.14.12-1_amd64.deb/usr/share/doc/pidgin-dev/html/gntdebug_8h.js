var gntdebug_8h =
[
    [ "finch_debug_get_ui_ops", "gntdebug_8h.html#a1e11e18e8837964576dd5b5c8721b046", null ],
    [ "finch_debug_init", "gntdebug_8h.html#a5828ec18d175223eec7eb96aacc6295f", null ],
    [ "finch_debug_uninit", "gntdebug_8h.html#a6da9867f24f903e825d27a85d71ce798", null ],
    [ "finch_debug_window_show", "gntdebug_8h.html#a98f7ab33fe33d5f767907e8de81f88b1", null ]
];