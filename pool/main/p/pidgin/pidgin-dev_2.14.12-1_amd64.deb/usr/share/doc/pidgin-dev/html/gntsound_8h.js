var gntsound_8h =
[
    [ "finch_sound_get_active_profile", "gntsound_8h.html#a2c9f4f02d4d5e3a8b2f4d18629c51648", null ],
    [ "finch_sound_get_profiles", "gntsound_8h.html#a1c4065b776082c3c63faf384fb75288c", null ],
    [ "finch_sound_get_ui_ops", "gntsound_8h.html#ad62bf9cf216e7541d847a41c81f85908", null ],
    [ "finch_sound_is_enabled", "gntsound_8h.html#abf53780fccdf153d686f9cf1e563e79a", null ],
    [ "finch_sound_set_active_profile", "gntsound_8h.html#a8f43733c6f221fa89272974f7aa67003", null ],
    [ "finch_sounds_show_all", "gntsound_8h.html#adf82aef51efafadc34e0b23cee76b2be", null ]
];