var gtkroomlist_8h =
[
    [ "pidgin_roomlist_dialog_show", "gtkroomlist_8h.html#a2a839ad8e526688c2a45fd27c29885ef", null ],
    [ "pidgin_roomlist_dialog_show_with_account", "gtkroomlist_8h.html#aec92be3a1432a28da4bbe4b5e4893a10", null ],
    [ "pidgin_roomlist_init", "gtkroomlist_8h.html#a0bf5475aa87644fc7b86f51d3528eb93", null ],
    [ "pidgin_roomlist_is_showable", "gtkroomlist_8h.html#ad573dc4b6084d9d15a643e766b618190", null ]
];