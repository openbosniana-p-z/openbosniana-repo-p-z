var gtkwhiteboard_8h =
[
    [ "_PidginWhiteboard", "struct__PidginWhiteboard.html", "struct__PidginWhiteboard" ],
    [ "PidginWhiteboard", "gtkwhiteboard_8h.html#a6f86aea59e7760da0b9e88097a17419b", null ],
    [ "pidgin_whiteboard_get_ui_ops", "gtkwhiteboard_8h.html#a131b6cf1f5a8ecdb8803a3ddf86dddf0", null ]
];