var gtkplugin_8h =
[
    [ "_PidginPluginUiInfo", "struct__PidginPluginUiInfo.html", "struct__PidginPluginUiInfo" ],
    [ "pidgin_plugin_dialog_show", "gtkplugin_8h.html#a709ed516b7971abd6443d127e65dd8b1", null ],
    [ "pidgin_plugin_get_config_frame", "gtkplugin_8h.html#a3de23ce45bceea39c9eca02053f7193f", null ],
    [ "pidgin_plugins_save", "gtkplugin_8h.html#a24c257e0748da087c4c8254584682a71", null ]
];