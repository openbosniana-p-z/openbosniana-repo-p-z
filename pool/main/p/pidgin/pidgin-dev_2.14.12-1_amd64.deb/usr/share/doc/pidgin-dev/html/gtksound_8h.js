var gtksound_8h =
[
    [ "pidgin_sound_get_event_label", "gtksound_8h.html#a46bc9955214061f80f1a515cafcefa5b", null ],
    [ "pidgin_sound_get_event_option", "gtksound_8h.html#a1be0ef2a1a19dacd4de97b32a2afa5da", null ],
    [ "pidgin_sound_get_handle", "gtksound_8h.html#a70acf7d51012e8047d4d92027f3f1395", null ],
    [ "pidgin_sound_get_ui_ops", "gtksound_8h.html#aaf13b84a2db75bdd44076b8d9a9d3cee", null ],
    [ "pidgin_sound_is_customized", "gtksound_8h.html#a81bfdd7c2f7af5b5ab045bcb0219b078", null ]
];