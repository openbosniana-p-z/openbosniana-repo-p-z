/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "pidgin", "index.html", [
    [ "Pidgin/Finch/libpurple API Documentation", "index.html", null ],
    [ "Account Signals", "account-signals.html", [
      [ "account-created", "account-signals.html#account-created", null ],
      [ "account-destroying", "account-signals.html#account-destroying", null ],
      [ "account-added", "account-signals.html#account-added", null ],
      [ "account-connecting", "account-signals.html#account-connecting", null ],
      [ "account-removed", "account-signals.html#account-removed", null ],
      [ "account-disabled", "account-signals.html#account-disabled", null ],
      [ "account-enabled", "account-signals.html#account-enabled", null ],
      [ "account-setting-info", "account-signals.html#account-setting-info", null ],
      [ "account-set-info", "account-signals.html#account-set-info", null ],
      [ "account-status-changed", "account-signals.html#account-status-changed", null ],
      [ "account-actions-changed", "account-signals.html#account-actions-changed", null ],
      [ "account-alias-changed", "account-signals.html#account-alias-changed", null ],
      [ "account-authorization-requested", "account-signals.html#account-authorization-requested", null ],
      [ "account-authorization-requested-with-message", "account-signals.html#account-authorization-requested-with-message", null ],
      [ "account-authorization-denied", "account-signals.html#account-authorization-denied", null ],
      [ "account-authorization-granted", "account-signals.html#account-authorization-granted", null ],
      [ "account-error-changed", "account-signals.html#account-error-changed", null ],
      [ "account-signed-on", "account-signals.html#account-signed-on", null ],
      [ "account-signed-off", "account-signals.html#account-signed-off", null ],
      [ "account-connection-error", "account-signals.html#account-connection-error", null ]
    ] ],
    [ "Buddy List Signals", "blist-signals.html", [
      [ "buddy-status-changed", "blist-signals.html#buddy-status-changed", null ],
      [ "buddy-idle-changed", "blist-signals.html#buddy-idle-changed", null ],
      [ "buddy-signed-on", "blist-signals.html#buddy-signed-on", null ],
      [ "buddy-signed-off", "blist-signals.html#buddy-signed-off", null ],
      [ "update-idle", "blist-signals.html#update-idle", null ],
      [ "blist-node-extended-menu", "blist-signals.html#blist-node-extended-menu", null ],
      [ "blist-node-added", "blist-signals.html#blist-node-added", null ],
      [ "blist-node-removed", "blist-signals.html#blist-node-removed", null ],
      [ "buddy-added", "blist-signals.html#buddy-added", null ],
      [ "buddy-removed", "blist-signals.html#buddy-removed", null ],
      [ "buddy-icon-changed", "blist-signals.html#buddy-icon-changed", null ],
      [ "blist-node-aliased", "blist-signals.html#blist-node-aliased", null ],
      [ "buddy-caps-changed", "blist-signals.html#buddy-caps-changed", null ],
      [ "ui-caps-changed", "blist-signals.html#ui-caps-changed", null ]
    ] ],
    [ "C Plugin HOWTO", "c-howto.html", [
      [ "Introduction", "c-howto.html#Introduction", null ],
      [ "Getting Started", "c-howto.html#getting_started", null ],
      [ "Hello World!", "c-howto.html#hello_world", null ]
    ] ],
    [ "Certificate Signals", "certificate-signals.html", [
      [ "certificate-stored", "certificate-signals.html#certificate-stored", null ],
      [ "certificate-deleted", "certificate-signals.html#certificate-deleted", null ]
    ] ],
    [ "Cipher Signals", "cipher-signals.html", [
      [ "cipher-added", "cipher-signals.html#cipher-added", null ],
      [ "cipher-removed", "cipher-signals.html#cipher-removed", null ]
    ] ],
    [ "Connection Signals", "connection-signals.html", [
      [ "signing-on", "connection-signals.html#signing-on", null ],
      [ "signed-on", "connection-signals.html#signed-on", null ],
      [ "autojoin", "connection-signals.html#autojoin", null ],
      [ "signing-off", "connection-signals.html#signing-off", null ],
      [ "signed-off", "connection-signals.html#signed-off", null ],
      [ "connection-error", "connection-signals.html#connection-error", null ]
    ] ],
    [ "Conversation Signals", "conversation-signals.html", [
      [ "writing-im-msg", "conversation-signals.html#writing-im-msg", null ],
      [ "wrote-im-msg", "conversation-signals.html#wrote-im-msg", null ],
      [ "sending-im-msg", "conversation-signals.html#sending-im-msg", null ],
      [ "sent-im-msg", "conversation-signals.html#sent-im-msg", null ],
      [ "receiving-im-msg", "conversation-signals.html#receiving-im-msg", null ],
      [ "received-im-msg", "conversation-signals.html#received-im-msg", null ],
      [ "blocked-im-msg", "conversation-signals.html#blocked-im-msg", null ],
      [ "writing-chat-msg", "conversation-signals.html#writing-chat-msg", null ],
      [ "wrote-chat-msg", "conversation-signals.html#wrote-chat-msg", null ],
      [ "sending-chat-msg", "conversation-signals.html#sending-chat-msg", null ],
      [ "sent-chat-msg", "conversation-signals.html#sent-chat-msg", null ],
      [ "receiving-chat-msg", "conversation-signals.html#receiving-chat-msg", null ],
      [ "received-chat-msg", "conversation-signals.html#received-chat-msg", null ],
      [ "conversation-created", "conversation-signals.html#conversation-created", null ],
      [ "conversation-updated", "conversation-signals.html#conversation-updated", null ],
      [ "deleting-conversation", "conversation-signals.html#deleting-conversation", null ],
      [ "buddy-typing", "conversation-signals.html#buddy-typing", null ],
      [ "buddy-typing-stopped", "conversation-signals.html#buddy-typing-stopped", null ],
      [ "chat-buddy-joining", "conversation-signals.html#chat-buddy-joining", null ],
      [ "chat-buddy-joined", "conversation-signals.html#chat-buddy-joined", null ],
      [ "chat-join-failed", "conversation-signals.html#chat-join-failed", null ],
      [ "chat-buddy-flags", "conversation-signals.html#chat-buddy-flags", null ],
      [ "chat-buddy-leaving", "conversation-signals.html#chat-buddy-leaving", null ],
      [ "chat-buddy-left", "conversation-signals.html#chat-buddy-left", null ],
      [ "chat-inviting-user", "conversation-signals.html#chat-inviting-user", null ],
      [ "chat-invited-user", "conversation-signals.html#chat-invited-user", null ],
      [ "chat-invited", "conversation-signals.html#chat-invited", null ],
      [ "chat-invite-blocked", "conversation-signals.html#chat-invite-blocked", null ],
      [ "chat-joined", "conversation-signals.html#chat-joined", null ],
      [ "chat-left", "conversation-signals.html#chat-left", null ],
      [ "chat-topic-changed", "conversation-signals.html#chat-topic-changed", null ],
      [ "conversation-extended-menu", "conversation-signals.html#conversation-extended-menu", null ],
      [ "cleared-message-history", "conversation-signals.html#cleared-message-history", null ],
      [ "sent-attention", "conversation-signals.html#sent-attention", null ],
      [ "got-attention", "conversation-signals.html#got-attention", null ]
    ] ],
    [ "Core Signals", "core-signals.html", [
      [ "quitting", "core-signals.html#quitting", null ],
      [ "uri-handler", "core-signals.html#uri-handler", null ]
    ] ],
    [ "DBus Server Signals", "dbus-server-signals.html", [
      [ "dbus-method-called", "dbus-server-signals.html#dbus-method-called", null ],
      [ "dbus-introspect", "dbus-server-signals.html#dbus-introspect", null ]
    ] ],
    [ "GtkAccount Signals", "gtkaccount-signals.html", [
      [ "account-modified", "gtkaccount-signals.html#account-modified", null ]
    ] ],
    [ "GtkBlist Signals", "gtkblist-signals.html", [
      [ "gtkblist-hiding", "gtkblist-signals.html#gtkblist-hiding", null ],
      [ "gtkblist-unhiding", "gtkblist-signals.html#gtkblist-unhiding", null ],
      [ "gtkblist-created", "gtkblist-signals.html#gtkblist-created", null ],
      [ "drawing-tooltip", "gtkblist-signals.html#drawing-tooltip", null ],
      [ "drawing-buddy", "gtkblist-signals.html#drawing-buddy", null ]
    ] ],
    [ "GtkConv Signals", "gtkconv-signals.html", [
      [ "conversation-dragging", "gtkconv-signals.html#conversation-dragging", null ],
      [ "conversation-timestamp", "gtkconv-signals.html#conversation-timestamp", null ],
      [ "displaying-im-msg", "gtkconv-signals.html#displaying-im-msg", null ],
      [ "displayed-im-msg", "gtkconv-signals.html#displayed-im-msg", null ],
      [ "displaying-chat-msg", "gtkconv-signals.html#displaying-chat-msg", null ],
      [ "displayed-chat-msg", "gtkconv-signals.html#displayed-chat-msg", null ],
      [ "conversation-switched", "gtkconv-signals.html#conversation-switched", null ],
      [ "conversation-hiding", "gtkconv-signals.html#conversation-hiding", null ],
      [ "conversation-displayed", "gtkconv-signals.html#conversation-displayed", null ]
    ] ],
    [ "GtkIMHtml Signals", "gtkimhtml-signals.html", [
      [ "url_clicked", "gtkimhtml-signals.html#url_clicked", null ],
      [ "format_buttons_update", "gtkimhtml-signals.html#format_buttons_update", null ],
      [ "format_function_clear", "gtkimhtml-signals.html#format_function_clear", null ],
      [ "format_function_toggle", "gtkimhtml-signals.html#format_function_toggle", null ],
      [ "format_function_update", "gtkimhtml-signals.html#format_function_update", null ],
      [ "paste", "gtkimhtml-signals.html#paste", null ]
    ] ],
    [ "GtkLog Signals", "gtklog-signals.html", [
      [ "log-displaying", "gtklog-signals.html#log-displaying", null ]
    ] ],
    [ "Image Store Signals", "imgstore-signals.html", [
      [ "image-deleting", "imgstore-signals.html#image-deleting", null ]
    ] ],
    [ "Jabber Signals", "jabber-signals.html", [
      [ "jabber-receiving-iq", "jabber-signals.html#jabber-receiving-iq", null ],
      [ "jabber-receiving-message", "jabber-signals.html#jabber-receiving-message", null ],
      [ "jabber-receiving-presence", "jabber-signals.html#jabber-receiving-presence", null ],
      [ "jabber-watched-iq", "jabber-signals.html#jabber-watched-iq", null ],
      [ "jabber-register-namespace-watcher", "jabber-signals.html#jabber-register-namespace-watcher", null ],
      [ "jabber-unregister-namespace-watcher", "jabber-signals.html#jabber-unregister-namespace-watcher", null ],
      [ "jabber-sending-xmlnode", "jabber-signals.html#jabber-sending-xmlnode", null ],
      [ "jabber-receiving-xmlnode", "jabber-signals.html#jabber-receiving-xmlnode", null ]
    ] ],
    [ "Log Signals", "log-signals.html", [
      [ "log-timestamp", "log-signals.html#log-timestamp", null ]
    ] ],
    [ "Notification Signals", "notify-signals.html", [
      [ "displaying-userinfo", "notify-signals.html#displaying-userinfo", null ],
      [ "displaying-email-notification", "notify-signals.html#displaying-email-notification", null ],
      [ "displaying-emails-notification", "notify-signals.html#displaying-emails-notification", null ]
    ] ],
    [ "Perl Scripting HOWTO", "perl-howto.html", [
      [ "Writing your first script", "perl-howto.html#first-script", null ],
      [ "Account and Account Option Functions", "perl-howto.html#account-api", null ],
      [ "Buddylist, Group and Chat API", "perl-howto.html#buddylist-api", null ],
      [ "Connection API", "perl-howto.html#conn-api", null ],
      [ "Conversation API", "perl-howto.html#conv-api", null ],
      [ "Plugin Preference and Gtk Preference API", "perl-howto.html#plugin-pref-api", null ],
      [ "Request Dialog Box API", "perl-howto.html#request-api", null ],
      [ "Misc: Plugin Actions, Timeouts and Callbacks", "perl-howto.html#timeout-cb", null ],
      [ "Resources", "perl-howto.html#Resources", null ]
    ] ],
    [ "Third Party Plugin Translation Support", "plugin-i18n.html", null ],
    [ "Plugin IDs", "plugin-ids.html", [
      [ "Format", "plugin-ids.html#Format", null ],
      [ "One Last Rule for Plugin IDs", "plugin-ids.html#nospaces", null ],
      [ "Exceptions to the Rule", "plugin-ids.html#exceptions", null ],
      [ "Examples of Well-Chosen Plugin IDs", "plugin-ids.html#examples", null ],
      [ "Plugin Database", "plugin-ids.html#plugin-db", null ]
    ] ],
    [ "Plugin Signals", "plugin-signals.html", [
      [ "plugin-load", "plugin-signals.html#plugin-load", null ],
      [ "plugin-unload", "plugin-signals.html#plugin-unload", null ]
    ] ],
    [ "Saved Status Signals", "savedstatus-signals.html", [
      [ "savedstatus-changed", "savedstatus-signals.html#savedstatus-changed", null ]
    ] ],
    [ "Signals HOWTO", "signal-howto.html", [
      [ "Overview of Signals", "signal-howto.html#overview", null ],
      [ "Registering a Signal", "signal-howto.html#registering_signal", [
        [ "Instance", "signal-howto.html#Instance", null ],
        [ "Signal Name", "signal-howto.html#signalname", null ],
        [ "Callback function definition", "signal-howto.html#therest", [
          [ "Marshal Function", "signal-howto.html#marshalfunc", null ],
          [ "Callback return value type", "signal-howto.html#cb_ret_type", null ],
          [ "Number of arguments", "signal-howto.html#num_args", null ],
          [ "Type of argument", "signal-howto.html#type_arg", null ]
        ] ]
      ] ],
      [ "Connecting to the signal", "signal-howto.html#connect", null ],
      [ "Emitting a signal", "signal-howto.html#emit-signal", null ]
    ] ],
    [ "Sound Signals", "sound-signals.html", [
      [ "playing-sound-event", "sound-signals.html#playing-sound-event", null ]
    ] ],
    [ "Tcl Scripting HOWTO", "tcl-howto.html", [
      [ "Intoduction", "tcl-howto.html#Intoduction", null ],
      [ "Getting Started", "tcl-howto.html#start", null ],
      [ "Interpreter Details", "tcl-howto.html#details", null ],
      [ "purple Internal Procedures and Variables", "tcl-howto.html#internals", null ],
      [ "Signals", "tcl-howto.html#Signals", null ]
    ] ],
    [ "File Transfer Signals", "xfer-signals.html", [
      [ "file-recv-accept", "xfer-signals.html#file-recv-accept", null ],
      [ "file-recv-start", "xfer-signals.html#file-recv-start", null ],
      [ "file-recv-cancel", "xfer-signals.html#file-recv-cancel", null ],
      [ "file-recv-complete", "xfer-signals.html#file-recv-complete", null ],
      [ "file-recv-request", "xfer-signals.html#file-recv-request", null ],
      [ "file-send-accept", "xfer-signals.html#file-send-accept", null ],
      [ "file-send-start", "xfer-signals.html#file-send-start", null ],
      [ "file-send-cancel", "xfer-signals.html#file-send-cancel", null ],
      [ "file-send-complete", "xfer-signals.html#file-send-complete", null ]
    ] ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Todo List", "todo.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"account-signals.html",
"globals__.html",
"globals_func__.html",
"gntft_8h.html",
"sound-theme-loader_8h.html#a67aee185f1ef372303a75b8cccde5006",
"struct__PurpleAccount.html#ad5f87680b2657133cf67e05cfd828c41",
"struct__PurpleLogLogger.html#a1b5a77ab279730e26a1fb9b628e0acda",
"theme-manager_8h.html#a7c9da6a8c149da73dbcfb2e294d8c26d"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';