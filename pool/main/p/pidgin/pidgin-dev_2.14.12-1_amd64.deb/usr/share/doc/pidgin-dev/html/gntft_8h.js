var gntft_8h =
[
    [ "finch_xfer_dialog_add_xfer", "gntft_8h.html#a3f4fadfd84bab3ae62fd644a58009f0b", null ],
    [ "finch_xfer_dialog_cancel_xfer", "gntft_8h.html#a101b01554b3e943fa9822e6606898010", null ],
    [ "finch_xfer_dialog_destroy", "gntft_8h.html#a4661662a283995558ee8c4efc9a59f19", null ],
    [ "finch_xfer_dialog_hide", "gntft_8h.html#ac4a8b8db194282fea4abf964c71dab00", null ],
    [ "finch_xfer_dialog_new", "gntft_8h.html#a91dee363afc40281b46bc9f6acd360e4", null ],
    [ "finch_xfer_dialog_remove_xfer", "gntft_8h.html#a80d1c72af8cea479ec5f69fcffb16adb", null ],
    [ "finch_xfer_dialog_show", "gntft_8h.html#a34002896adc94e3f832be2ddef9d56e2", null ],
    [ "finch_xfer_dialog_update_xfer", "gntft_8h.html#a278883c1ae6d3f8d55145dc5a975f7b7", null ],
    [ "finch_xfers_get_ui_ops", "gntft_8h.html#a022a0cf2649835eadd90459d92cc68c1", null ],
    [ "finch_xfers_init", "gntft_8h.html#a5a135bdd641b97db97f535ce2b7aae49", null ],
    [ "finch_xfers_uninit", "gntft_8h.html#a9c884b5ce2ec3bd9fd5ab6e7b8a3633b", null ]
];