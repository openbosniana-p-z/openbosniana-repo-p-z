var minidialog_8h =
[
    [ "PidginMiniDialog", "structPidginMiniDialog.html", "structPidginMiniDialog" ],
    [ "PidginMiniDialogClass", "structPidginMiniDialogClass.html", null ],
    [ "PidginMiniDialogCallback", "minidialog_8h.html#a75761249eee7694778c792fc1c001579", null ],
    [ "pidgin_mini_dialog_add_button", "minidialog_8h.html#adfad9d189f8c70739a8c37805c268836", null ],
    [ "pidgin_mini_dialog_add_non_closing_button", "minidialog_8h.html#a5204bce40199d9bf66ae1944b7433b20", null ],
    [ "pidgin_mini_dialog_enable_description_markup", "minidialog_8h.html#aeaafd5c53910ebaec140378e17336284", null ],
    [ "pidgin_mini_dialog_get_num_children", "minidialog_8h.html#a6f49bd3456064ddfc0b0695fc3d6c2f1", null ],
    [ "pidgin_mini_dialog_get_type", "minidialog_8h.html#a5c3f94237c1e1fbc672d87207bb672a1", null ],
    [ "pidgin_mini_dialog_links_supported", "minidialog_8h.html#a899d235036eb73b8c65c5433ac7a2ac8", null ],
    [ "pidgin_mini_dialog_new", "minidialog_8h.html#a8fda67d2ce0499bd49e045f037f10ff7", null ],
    [ "pidgin_mini_dialog_new_with_custom_icon", "minidialog_8h.html#af3c0a2d4253597663d7a144982eb55d4", null ],
    [ "pidgin_mini_dialog_set_custom_icon", "minidialog_8h.html#a076a8115d274d9d39ff59c45785238f1", null ],
    [ "pidgin_mini_dialog_set_description", "minidialog_8h.html#acefe1bd7d12fb510f08986dc1a02871c", null ],
    [ "pidgin_mini_dialog_set_icon_name", "minidialog_8h.html#acfcfbc9a96115297e73fc8107034c1e7", null ],
    [ "pidgin_mini_dialog_set_link_callback", "minidialog_8h.html#a9323e19ef72c969032c609edc766082d", null ],
    [ "pidgin_mini_dialog_set_title", "minidialog_8h.html#a2037a1a655ed51d29058b6d61552e1bf", null ]
];