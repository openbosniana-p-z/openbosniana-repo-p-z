var gntnotify_8h =
[
    [ "finch_notify_get_ui_ops", "gntnotify_8h.html#a646bbca10661d8af3ac4d7f83cc66178", null ],
    [ "finch_notify_init", "gntnotify_8h.html#ae4c8a14eb37713263949e0d1e0f9ba58", null ],
    [ "finch_notify_uninit", "gntnotify_8h.html#a13176bd94d38aa5805d2234eb5c43240", null ]
];