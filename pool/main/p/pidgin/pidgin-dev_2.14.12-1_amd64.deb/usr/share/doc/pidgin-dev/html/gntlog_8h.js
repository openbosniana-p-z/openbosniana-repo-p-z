var gntlog_8h =
[
    [ "_FinchLogViewer", "struct__FinchLogViewer.html", "struct__FinchLogViewer" ],
    [ "finch_log_get_handle", "gntlog_8h.html#a5d9e0855ed2647d6e475f66e51ee583c", null ],
    [ "finch_log_init", "gntlog_8h.html#a4b4c7202ee3f5c52d6d717077c34b0ad", null ],
    [ "finch_log_uninit", "gntlog_8h.html#aeee57dfb3ce2827e4319283646025801", null ]
];