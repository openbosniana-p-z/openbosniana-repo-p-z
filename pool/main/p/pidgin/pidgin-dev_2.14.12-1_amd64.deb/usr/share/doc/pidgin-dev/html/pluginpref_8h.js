var pluginpref_8h =
[
    [ "PurplePluginPrefType", "pluginpref_8h.html#acede68a2c07b3b7c0bfc13e08dc05944", [
      [ "PURPLE_PLUGIN_PREF_NONE", "pluginpref_8h.html#acede68a2c07b3b7c0bfc13e08dc05944a69fc9ff9e5e5ff8b890d5825057d5924", null ],
      [ "PURPLE_PLUGIN_PREF_CHOICE", "pluginpref_8h.html#acede68a2c07b3b7c0bfc13e08dc05944a5795caba61389f29d1e70231d87e752e", null ],
      [ "PURPLE_PLUGIN_PREF_INFO", "pluginpref_8h.html#acede68a2c07b3b7c0bfc13e08dc05944a9eaa8ef107ce060c765b5c2a25cb790b", null ],
      [ "PURPLE_PLUGIN_PREF_STRING_FORMAT", "pluginpref_8h.html#acede68a2c07b3b7c0bfc13e08dc05944a84981c7eaee1b5aac4be93f9f5be048b", null ]
    ] ],
    [ "PurpleStringFormatType", "pluginpref_8h.html#ad62d81da8a6cef846ac03f227f900b59", [
      [ "PURPLE_STRING_FORMAT_TYPE_NONE", "pluginpref_8h.html#ad62d81da8a6cef846ac03f227f900b59ac5704239bca29f017f27db92902b9732", null ],
      [ "PURPLE_STRING_FORMAT_TYPE_MULTILINE", "pluginpref_8h.html#ad62d81da8a6cef846ac03f227f900b59a1d291699bbf9bc20bacf5f56e26b737e", null ],
      [ "PURPLE_STRING_FORMAT_TYPE_HTML", "pluginpref_8h.html#ad62d81da8a6cef846ac03f227f900b59aca35e2cd6e873e557bb6526e0698ebc1", null ]
    ] ],
    [ "purple_plugin_pref_add_choice", "pluginpref_8h.html#a29681b75e9ff1eaa0a3f5433c1e1f445", null ],
    [ "purple_plugin_pref_destroy", "pluginpref_8h.html#a81e1f24910c29ba08a180851a88a28c5", null ],
    [ "purple_plugin_pref_frame_add", "pluginpref_8h.html#afc8406c4aeb7cc60d13ee5959a7f6b20", null ],
    [ "purple_plugin_pref_frame_destroy", "pluginpref_8h.html#ae50fbf49ea5308b34ffadf03b2426605", null ],
    [ "purple_plugin_pref_frame_get_prefs", "pluginpref_8h.html#a9ef813b22957b73959a0acbc569d881a", null ],
    [ "purple_plugin_pref_frame_new", "pluginpref_8h.html#afbe4b51fab09467f7decc39c3a592dd7", null ],
    [ "purple_plugin_pref_get_bounds", "pluginpref_8h.html#a0136975dc5be96335f0ae0ba6dda82ae", null ],
    [ "purple_plugin_pref_get_choices", "pluginpref_8h.html#a9ac8db45e8cbe97b03746eb82f1e61b5", null ],
    [ "purple_plugin_pref_get_format_type", "pluginpref_8h.html#a0e8b444019c855353a218d0866db86a3", null ],
    [ "purple_plugin_pref_get_label", "pluginpref_8h.html#acbe8b8a96c2f5247e58c49f4ec17d018", null ],
    [ "purple_plugin_pref_get_masked", "pluginpref_8h.html#aa119515282b8aacfe2536cd35c2fb5d6", null ],
    [ "purple_plugin_pref_get_max_length", "pluginpref_8h.html#a11ffe3adc0ad08fa27c9f6fef97ea120", null ],
    [ "purple_plugin_pref_get_name", "pluginpref_8h.html#a80536408cef49e9958cd02e330a0100d", null ],
    [ "purple_plugin_pref_get_type", "pluginpref_8h.html#aa69dcd1013ff1053fc105580881fe151", null ],
    [ "purple_plugin_pref_new", "pluginpref_8h.html#ab5dc9c7b28e84fb99c91db141c26e9fd", null ],
    [ "purple_plugin_pref_new_with_label", "pluginpref_8h.html#a285645393525c2f62b3b961da637a686", null ],
    [ "purple_plugin_pref_new_with_name", "pluginpref_8h.html#a11ab34d7ba29a32a463d32ddb68e550a", null ],
    [ "purple_plugin_pref_new_with_name_and_label", "pluginpref_8h.html#a0eeb27acab9cce312aaa2930ddef8418", null ],
    [ "purple_plugin_pref_set_bounds", "pluginpref_8h.html#a108d68997fe1d17e63a5951f016641d1", null ],
    [ "purple_plugin_pref_set_format_type", "pluginpref_8h.html#ae7103c6bba3d065bc35717860b3240ae", null ],
    [ "purple_plugin_pref_set_label", "pluginpref_8h.html#a22fd9a905162ea81cacb53eb244afb6d", null ],
    [ "purple_plugin_pref_set_masked", "pluginpref_8h.html#a514747d1558968a6b1bf4c9f966691b5", null ],
    [ "purple_plugin_pref_set_max_length", "pluginpref_8h.html#a2c288d0d206af9793a9444738db4016d", null ],
    [ "purple_plugin_pref_set_name", "pluginpref_8h.html#a8c98a59cc9f08fcc2ce5d45b6b4b871a", null ],
    [ "purple_plugin_pref_set_type", "pluginpref_8h.html#abfda197c183dd94007e3effbace5548b", null ]
];