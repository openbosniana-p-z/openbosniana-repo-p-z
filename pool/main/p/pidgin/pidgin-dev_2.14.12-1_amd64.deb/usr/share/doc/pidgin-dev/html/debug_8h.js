var debug_8h =
[
    [ "PurpleDebugUiOps", "structPurpleDebugUiOps.html", null ],
    [ "PurpleDebugLevel", "debug_8h.html#ae4789d7a365e1d70da6f232248a08259", [
      [ "PURPLE_DEBUG_ALL", "debug_8h.html#ae4789d7a365e1d70da6f232248a08259aaa2efef6a1db232369cb3706b543859a", null ],
      [ "PURPLE_DEBUG_MISC", "debug_8h.html#ae4789d7a365e1d70da6f232248a08259ab95b4fa442155d6e401a96a7a5433594", null ],
      [ "PURPLE_DEBUG_INFO", "debug_8h.html#ae4789d7a365e1d70da6f232248a08259acfc8c6be922bc8163e9c7c6856e668ac", null ],
      [ "PURPLE_DEBUG_WARNING", "debug_8h.html#ae4789d7a365e1d70da6f232248a08259a3fce6f428fe7e68c0ff30874088dffcf", null ],
      [ "PURPLE_DEBUG_ERROR", "debug_8h.html#ae4789d7a365e1d70da6f232248a08259a3007a5f818a44295dabe18afca6fe021", null ],
      [ "PURPLE_DEBUG_FATAL", "debug_8h.html#ae4789d7a365e1d70da6f232248a08259a76424dc2e922c256994fa4376270de2b", null ]
    ] ],
    [ "purple_debug", "debug_8h.html#af08b9149e8a54cd07db52999a32e6898", null ],
    [ "purple_debug_error", "debug_8h.html#a92d772544aec6c280006448aa9a1ef50", null ],
    [ "purple_debug_fatal", "debug_8h.html#a848784bca52270d9ba10fd7b2d5f2018", null ],
    [ "purple_debug_get_ui_ops", "debug_8h.html#ad87734cdeccb0fab44548f7b50bb610b", null ],
    [ "purple_debug_info", "debug_8h.html#a112ab6ae0c750309516442f315002bee", null ],
    [ "purple_debug_init", "debug_8h.html#af8faf391ea58eb558ee33c06f7f4be68", null ],
    [ "purple_debug_is_enabled", "debug_8h.html#a624022781c6b6462b307e8860e2559a8", null ],
    [ "purple_debug_is_unsafe", "debug_8h.html#adddf1af70a861af48847d477b04f64aa", null ],
    [ "purple_debug_is_verbose", "debug_8h.html#af84ec43cd1c61a7af89b5c31a8c1ace7", null ],
    [ "purple_debug_misc", "debug_8h.html#a89b6474a316d3e177cc91b35897ae20a", null ],
    [ "purple_debug_set_enabled", "debug_8h.html#a0213b0d62c72e09446575f4bc74be51a", null ],
    [ "purple_debug_set_ui_ops", "debug_8h.html#af3ca793411ba941b7772d8b225586054", null ],
    [ "purple_debug_set_unsafe", "debug_8h.html#a36afb4f3594fd583cd001c7ee603863d", null ],
    [ "purple_debug_set_verbose", "debug_8h.html#a547e2c5ac9a1b173f25e73971c1f29a0", null ],
    [ "purple_debug_warning", "debug_8h.html#a73ce6863806209621433421e69487799", null ]
];