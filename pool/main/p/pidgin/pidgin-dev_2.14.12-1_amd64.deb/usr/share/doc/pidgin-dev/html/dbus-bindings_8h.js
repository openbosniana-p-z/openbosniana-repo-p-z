var dbus_bindings_8h =
[
    [ "PurpleDBusBinding", "structPurpleDBusBinding.html", null ]
];