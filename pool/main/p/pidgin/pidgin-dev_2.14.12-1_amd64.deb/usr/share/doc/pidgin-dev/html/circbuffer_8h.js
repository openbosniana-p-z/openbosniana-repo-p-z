var circbuffer_8h =
[
    [ "_PurpleCircBuffer", "struct__PurpleCircBuffer.html", "struct__PurpleCircBuffer" ],
    [ "purple_circ_buffer_append", "circbuffer_8h.html#a1f3bffbe4898aabf51036a0deff08ed2", null ],
    [ "purple_circ_buffer_destroy", "circbuffer_8h.html#a635a8f2340bed1af0101f0998bdfd6df", null ],
    [ "purple_circ_buffer_get_max_read", "circbuffer_8h.html#accec2e61649e3d1868fa755775e9692b", null ],
    [ "purple_circ_buffer_mark_read", "circbuffer_8h.html#a9c8b7b6bbdb72a1e9e533ca0a7048487", null ],
    [ "purple_circ_buffer_new", "circbuffer_8h.html#a1e5145ee5120c038134bce2eb3caed40", null ]
];