var media_gst_8h =
[
    [ "PurpleMediaElementInfo", "media-gst_8h.html#ad524deb3cc23a50cab8df912f317a38b", null ],
    [ "PurpleMediaElementType", "media-gst_8h.html#a79799b9458c7696c144fe35d275eec93", [
      [ "PURPLE_MEDIA_ELEMENT_NONE", "media-gst_8h.html#a79799b9458c7696c144fe35d275eec93a412dccaca6c112308ceb81191d6c5167", null ],
      [ "PURPLE_MEDIA_ELEMENT_AUDIO", "media-gst_8h.html#a79799b9458c7696c144fe35d275eec93adbaeee202629230b7dff9b541e1d9e31", null ],
      [ "PURPLE_MEDIA_ELEMENT_VIDEO", "media-gst_8h.html#a79799b9458c7696c144fe35d275eec93a89e160e2b402a37806e63305aee6d730", null ],
      [ "PURPLE_MEDIA_ELEMENT_AUDIO_VIDEO", "media-gst_8h.html#a79799b9458c7696c144fe35d275eec93a53d600384f167cc3f92efbb85ae807f8", null ],
      [ "PURPLE_MEDIA_ELEMENT_NO_SRCS", "media-gst_8h.html#a79799b9458c7696c144fe35d275eec93aa513c0e612ee7224ffd4b04a96daad1e", null ],
      [ "PURPLE_MEDIA_ELEMENT_ONE_SRC", "media-gst_8h.html#a79799b9458c7696c144fe35d275eec93aee4e583d69a7d7c922c2345382dcec10", null ],
      [ "PURPLE_MEDIA_ELEMENT_MULTI_SRC", "media-gst_8h.html#a79799b9458c7696c144fe35d275eec93a09ee6bf747eb0a8ea1f9d339b6bf0fd4", null ],
      [ "PURPLE_MEDIA_ELEMENT_REQUEST_SRC", "media-gst_8h.html#a79799b9458c7696c144fe35d275eec93acd443ea8f42b01f3d049fa5e025fa152", null ],
      [ "PURPLE_MEDIA_ELEMENT_NO_SINKS", "media-gst_8h.html#a79799b9458c7696c144fe35d275eec93a4c52bc1dedd5536a869ebb2d512b6b24", null ],
      [ "PURPLE_MEDIA_ELEMENT_ONE_SINK", "media-gst_8h.html#a79799b9458c7696c144fe35d275eec93aaf714cc0e23c0b1bcf7d0fc5b071e664", null ],
      [ "PURPLE_MEDIA_ELEMENT_MULTI_SINK", "media-gst_8h.html#a79799b9458c7696c144fe35d275eec93abadb16fba732ce6047c1751cb9f26c11", null ],
      [ "PURPLE_MEDIA_ELEMENT_REQUEST_SINK", "media-gst_8h.html#a79799b9458c7696c144fe35d275eec93a711383fdc9671f2737d98a6e6490de34", null ],
      [ "PURPLE_MEDIA_ELEMENT_UNIQUE", "media-gst_8h.html#a79799b9458c7696c144fe35d275eec93a37b3a59e5136f2880bfa9483ee0f3e8f", null ],
      [ "PURPLE_MEDIA_ELEMENT_SRC", "media-gst_8h.html#a79799b9458c7696c144fe35d275eec93aa54d3ff66567869255818fb644dc9bdb", null ],
      [ "PURPLE_MEDIA_ELEMENT_SINK", "media-gst_8h.html#a79799b9458c7696c144fe35d275eec93a383b3e66f17065b592d7dd4c2f68c29b", null ],
      [ "PURPLE_MEDIA_ELEMENT_APPLICATION", "media-gst_8h.html#a79799b9458c7696c144fe35d275eec93a6416f607c5649f22c764b56225d533cb", null ]
    ] ],
    [ "purple_media_element_info_get_type", "media-gst_8h.html#a5370258ac0c6ab56c97643a7446afd72", null ],
    [ "purple_media_element_type_get_type", "media-gst_8h.html#a07bbf05f23f1b6769bc7e1394a0e86b8", null ],
    [ "purple_media_get_src", "media-gst_8h.html#a3085146c86fc735ca761895bda2eaadd", null ],
    [ "purple_media_get_tee", "media-gst_8h.html#a544aa057d50d2b9e241b4b7fd09598d4", null ],
    [ "purple_media_manager_enumerate_elements", "media-gst_8h.html#a319f602effbccf5ace7cd3a7423090ee", null ],
    [ "purple_media_manager_get_element", "media-gst_8h.html#a8fc7fd392c0d152ad9985faa3537dd20", null ],
    [ "purple_media_manager_get_pipeline", "media-gst_8h.html#a1f9e184a7c2c623766ac09c1a10ed5f5", null ],
    [ "purple_media_manager_get_video_caps", "media-gst_8h.html#ae693a42d1843ac004b69737684346420", null ],
    [ "purple_media_manager_set_video_caps", "media-gst_8h.html#a016f4af83bb09ab2c0d21ba14684f5e1", null ]
];