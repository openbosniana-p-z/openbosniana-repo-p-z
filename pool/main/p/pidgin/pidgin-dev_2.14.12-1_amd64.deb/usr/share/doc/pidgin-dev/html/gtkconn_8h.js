var gtkconn_8h =
[
    [ "pidgin_connection_get_handle", "gtkconn_8h.html#abe405c5e88bfc1aa691ede4e618b3890", null ],
    [ "pidgin_connection_init", "gtkconn_8h.html#a086e1d6c7fc916fba9dd5d6b1727fd89", null ],
    [ "pidgin_connection_uninit", "gtkconn_8h.html#a4d3021e6bddcef928b2ed4b860494189", null ],
    [ "pidgin_connections_get_ui_ops", "gtkconn_8h.html#ae57b352c180868779229c253e1f79323", null ]
];