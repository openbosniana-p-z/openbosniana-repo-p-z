var gntidle_8h =
[
    [ "finch_idle_get_ui_ops", "gntidle_8h.html#a8202e7e50cf664d6f0ed37621f318e95", null ]
];