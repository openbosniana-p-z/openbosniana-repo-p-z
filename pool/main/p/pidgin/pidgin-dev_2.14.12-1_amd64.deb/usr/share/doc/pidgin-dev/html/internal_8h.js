var internal_8h =
[
    [ "common_sockaddr_t", "unioncommon__sockaddr__t.html", null ],
    [ "_purple_connection_destroy", "internal_8h.html#afd2bb0387727c9aabc36990e0911efdf", null ],
    [ "_purple_connection_new", "internal_8h.html#ad677da9f8bd705357fd74579ab546d34", null ],
    [ "_purple_connection_new_unregister", "internal_8h.html#a5f2f20255efd164d257987fc278bd5d7", null ],
    [ "_purple_network_set_common_socket_flags", "internal_8h.html#a7fc5ad4da12d36dcd0849ac35058d2f2", null ]
];