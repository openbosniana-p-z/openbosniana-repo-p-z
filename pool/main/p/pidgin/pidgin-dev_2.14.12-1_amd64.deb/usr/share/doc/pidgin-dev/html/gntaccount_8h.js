var gntaccount_8h =
[
    [ "finch_account_dialog_show", "gntaccount_8h.html#adaab1a3af6814da70c93116bd8d0faef", null ],
    [ "finch_accounts_get_ui_ops", "gntaccount_8h.html#a8ec0f6a21d6d614f55ac781ed1221932", null ],
    [ "finch_accounts_init", "gntaccount_8h.html#aa7bc2145f1d45b9a5c41061d693bb489", null ],
    [ "finch_accounts_show_all", "gntaccount_8h.html#ad9668853d9d8175240ab604d0e4ea493", null ],
    [ "finch_accounts_uninit", "gntaccount_8h.html#aa3bb16add90ac8f1cea6e022d2bb064b", null ]
];