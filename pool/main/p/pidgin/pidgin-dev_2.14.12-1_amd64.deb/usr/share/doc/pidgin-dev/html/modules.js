var modules =
[
    [ "libpurple", "group__core.html", "group__core" ],
    [ "Finch (GNT User Interface)", "group__finch.html", "group__finch" ],
    [ "Pidgin (GTK+ User Interface)", "group__pidgin.html", "group__pidgin" ]
];