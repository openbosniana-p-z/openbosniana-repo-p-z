var gntconv_8h =
[
    [ "_FinchConv", "struct__FinchConv.html", null ],
    [ "_FinchConvChat", "struct__FinchConvChat.html", null ],
    [ "_FinchConvIm", "struct__FinchConvIm.html", null ],
    [ "finch_conv_get_ui_ops", "gntconv_8h.html#a845f86a43ece459ab082a393cc65bdb8", null ],
    [ "finch_conversation_init", "gntconv_8h.html#ae8ac33e2ee2b3d4c080f15170b638a96", null ],
    [ "finch_conversation_set_active", "gntconv_8h.html#afb0c2d75b6bd61698fb1d5793d1d261e", null ],
    [ "finch_conversation_set_info_widget", "gntconv_8h.html#a1075f42377f8e48515196738242de892", null ],
    [ "finch_conversation_uninit", "gntconv_8h.html#a8bb8efdf009e5cc182405270d8987ed0", null ]
];