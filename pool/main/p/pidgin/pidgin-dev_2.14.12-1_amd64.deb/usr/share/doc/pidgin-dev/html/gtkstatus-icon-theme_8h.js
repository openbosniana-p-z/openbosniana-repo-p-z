var gtkstatus_icon_theme_8h =
[
    [ "_PidginStatusIconTheme", "struct__PidginStatusIconTheme.html", null ],
    [ "_PidginStatusIconThemeClass", "struct__PidginStatusIconThemeClass.html", null ],
    [ "PidginStatusIconTheme", "gtkstatus-icon-theme_8h.html#a7de4e5b662eeddf85ffc9bb63676ce35", null ],
    [ "pidgin_status_icon_theme_get_type", "gtkstatus-icon-theme_8h.html#aa20ccccf96e1effb16b295e703aff043", null ]
];