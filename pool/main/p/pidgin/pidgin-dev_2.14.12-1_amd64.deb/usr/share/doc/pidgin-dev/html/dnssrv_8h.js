var dnssrv_8h =
[
    [ "_PurpleSrvResponse", "struct__PurpleSrvResponse.html", null ],
    [ "_PurpleTxtResponse", "struct__PurpleTxtResponse.html", null ],
    [ "PurpleSrvTxtQueryUiOps", "structPurpleSrvTxtQueryUiOps.html", "structPurpleSrvTxtQueryUiOps" ],
    [ "PurpleSrvCallback", "dnssrv_8h.html#a0b498b50e1d40f378dcd6bbbb1dac01a", null ],
    [ "PurpleTxtCallback", "dnssrv_8h.html#a9016935b6c476812e2ab1b48b0b2d3eb", null ],
    [ "purple_srv_cancel", "dnssrv_8h.html#a7ed02c02ec2a8a2a4ac67d853027fc5c", null ],
    [ "purple_srv_resolve", "dnssrv_8h.html#a26194994439c3991146942ad1419d94d", null ],
    [ "purple_srv_resolve_account", "dnssrv_8h.html#a90b44e8486a4bcbfe9008f90be83066e", null ],
    [ "purple_srv_txt_query_destroy", "dnssrv_8h.html#adb1520098a36283b39ec0580a68e21a6", null ],
    [ "purple_srv_txt_query_get_query", "dnssrv_8h.html#a3479ef6afc3ced69e11db52dc2543ec5", null ],
    [ "purple_srv_txt_query_get_type", "dnssrv_8h.html#abe8a15814df32809933c11146ed5ca04", null ],
    [ "purple_srv_txt_query_get_ui_ops", "dnssrv_8h.html#a9795908d6391a3bf11ca3ba8dc9290fd", null ],
    [ "purple_srv_txt_query_set_ui_ops", "dnssrv_8h.html#acc4fcf49676d7b6742e9cd72362d35f9", null ],
    [ "purple_txt_cancel", "dnssrv_8h.html#a848bfae8a862f834131701403be44330", null ],
    [ "purple_txt_resolve", "dnssrv_8h.html#a246e414a1dc6216a03de654481164620", null ],
    [ "purple_txt_resolve_account", "dnssrv_8h.html#a6b07950d2688194b3928f6c1c28d3212", null ],
    [ "purple_txt_response_destroy", "dnssrv_8h.html#a7376e0ed51442518abf237ad411be1cd", null ],
    [ "purple_txt_response_get_content", "dnssrv_8h.html#a029a70d10cfa8dba35d5753dad0794b1", null ]
];