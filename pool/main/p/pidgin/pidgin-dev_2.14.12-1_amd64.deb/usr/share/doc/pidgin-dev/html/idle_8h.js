var idle_8h =
[
    [ "PurpleIdleUiOps", "structPurpleIdleUiOps.html", null ],
    [ "purple_idle_get_ui_ops", "idle_8h.html#a0e7a72cbf34e98eeed9f73266e4a3dcb", null ],
    [ "purple_idle_init", "idle_8h.html#a6d736d1e59a31a0839a8b33adb63f1cd", null ],
    [ "purple_idle_set", "idle_8h.html#a0815feed205b7824d507e96978455aab", null ],
    [ "purple_idle_set_ui_ops", "idle_8h.html#a11f8f3b903ceb0909aea659ef61db10e", null ],
    [ "purple_idle_touch", "idle_8h.html#a5997df5d074c4651f8bc7ac4bd6a74af", null ],
    [ "purple_idle_uninit", "idle_8h.html#a3c1781e6e1fbf88e1484392aae76c6d6", null ]
];