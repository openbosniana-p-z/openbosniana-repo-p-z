var eventloop_8h =
[
    [ "_PurpleEventLoopUiOps", "struct__PurpleEventLoopUiOps.html", "struct__PurpleEventLoopUiOps" ],
    [ "PurpleEventLoopUiOps", "eventloop_8h.html#ae2a7e4d9cf6a79e31e65e6ee6179adb1", null ],
    [ "PurpleInputFunction", "eventloop_8h.html#a53388b64eb47425f014a180c8f442c01", null ],
    [ "PurpleInputCondition", "eventloop_8h.html#ae16a4b18f1da57dff1eb139e934fffb3", [
      [ "PURPLE_INPUT_READ", "eventloop_8h.html#ae16a4b18f1da57dff1eb139e934fffb3a04a9339a9f5df8019b8afc3af679ec9e", null ],
      [ "PURPLE_INPUT_WRITE", "eventloop_8h.html#ae16a4b18f1da57dff1eb139e934fffb3a00c293d57b62e5a9c09e4539ade9d51c", null ]
    ] ],
    [ "purple_eventloop_get_ui_ops", "eventloop_8h.html#a015f1ded441a18e9fb446eb7f5f3b874", null ],
    [ "purple_eventloop_set_ui_ops", "eventloop_8h.html#a1f09559d8fcaa746239294dabd7201eb", null ],
    [ "purple_input_add", "eventloop_8h.html#ae685f5a211f4b798ec3b615c9312a02b", null ],
    [ "purple_input_get_error", "eventloop_8h.html#a7a6efcc7e111a1ea4c72b90a5e8a11eb", null ],
    [ "purple_input_remove", "eventloop_8h.html#aff54afc6806a985e8adc82582488784a", null ],
    [ "purple_timeout_add", "eventloop_8h.html#aadefb8b6d8b677ba989e47cbf8a05806", null ],
    [ "purple_timeout_add_seconds", "eventloop_8h.html#a17752ee1277e09350a612b0b88921fc5", null ],
    [ "purple_timeout_remove", "eventloop_8h.html#a23c409532bdde6e9155ee606a7c6dc87", null ]
];