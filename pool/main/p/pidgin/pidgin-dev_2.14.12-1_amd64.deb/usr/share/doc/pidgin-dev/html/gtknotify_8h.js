var gtknotify_8h =
[
    [ "pidgin_notify_get_ui_ops", "gtknotify_8h.html#a2f59a2cff5a9608d63bddfff496fc47b", null ],
    [ "pidgin_notify_init", "gtknotify_8h.html#a3bf969081e0edb8a0404058bc47906b4", null ],
    [ "pidgin_notify_pounce_add", "gtknotify_8h.html#a2bd2c5da635a809f0848d66c7287a42b", null ],
    [ "pidgin_notify_uninit", "gtknotify_8h.html#a1145211cd911c2ad027018692ea76dde", null ]
];