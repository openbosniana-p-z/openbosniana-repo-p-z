var gtksavedstatuses_8h =
[
    [ "pidgin_status_editor_show", "gtksavedstatuses_8h.html#a825bed41af5d5442fdd98ac1a340e8dc", null ],
    [ "pidgin_status_get_handle", "gtksavedstatuses_8h.html#adc0556af8041e54ec992ca785d9c0120", null ],
    [ "pidgin_status_init", "gtksavedstatuses_8h.html#a3145c95a23d702f60248e39eac046551", null ],
    [ "pidgin_status_menu", "gtksavedstatuses_8h.html#a82d42288e8cd93660b81a089d342f6e5", null ],
    [ "pidgin_status_uninit", "gtksavedstatuses_8h.html#ae4b691b4c9aec7964811e5be5dc777a5", null ],
    [ "pidgin_status_window_hide", "gtksavedstatuses_8h.html#a637082f1794636cb6054e1e9628fc207", null ],
    [ "pidgin_status_window_show", "gtksavedstatuses_8h.html#a1f709fa707774b9a6d7759afd29812ab", null ]
];