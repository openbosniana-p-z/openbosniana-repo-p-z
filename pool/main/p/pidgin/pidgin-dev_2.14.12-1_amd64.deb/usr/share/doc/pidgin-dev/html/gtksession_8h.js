var gtksession_8h =
[
    [ "pidgin_session_end", "gtksession_8h.html#a95749b11f956228cb1c6bc98566ee48b", null ],
    [ "pidgin_session_init", "gtksession_8h.html#af607dbc0b20c92dcc79fc93ffacf20df", null ]
];