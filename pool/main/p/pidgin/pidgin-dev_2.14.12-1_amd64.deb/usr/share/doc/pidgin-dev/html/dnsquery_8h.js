var dnsquery_8h =
[
    [ "PurpleDnsQueryUiOps", "structPurpleDnsQueryUiOps.html", "structPurpleDnsQueryUiOps" ],
    [ "PurpleDnsQueryConnectFunction", "dnsquery_8h.html#aa3d446893729a4eb95bace73feb2f1ea", null ],
    [ "PurpleDnsQueryData", "dnsquery_8h.html#a93d37ef72996eb70fb6f569fbb3c0fc3", null ],
    [ "PurpleDnsQueryResolvedCallback", "dnsquery_8h.html#a8dc0948a46769dfe47864631b51b1f91", null ],
    [ "purple_dnsquery_a", "dnsquery_8h.html#a3f3e9b039b4632a70972f3ffa84da765", null ],
    [ "purple_dnsquery_a_account", "dnsquery_8h.html#a47b50fdd56b9828ecf7707674a6103ee", null ],
    [ "purple_dnsquery_destroy", "dnsquery_8h.html#a8297317dce5871139cfa417fc55e134d", null ],
    [ "purple_dnsquery_get_host", "dnsquery_8h.html#a005d891dd519e147be443d42b8ba30ac", null ],
    [ "purple_dnsquery_get_port", "dnsquery_8h.html#ae5922ec0794e2453fca534e934d97a07", null ],
    [ "purple_dnsquery_get_ui_ops", "dnsquery_8h.html#af929654f9739b96d48169705868c436f", null ],
    [ "purple_dnsquery_init", "dnsquery_8h.html#a785caa5683e0aa85d4d2ce7f66a4c885", null ],
    [ "purple_dnsquery_set_ui_ops", "dnsquery_8h.html#a0e2f18e8817a685f04496443f8b6224d", null ],
    [ "purple_dnsquery_uninit", "dnsquery_8h.html#a9100431c18faee4b93082a3cc7413f37", null ]
];