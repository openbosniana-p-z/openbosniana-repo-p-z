var gtkcertmgr_8h =
[
    [ "_PidginCertificateManager", "struct__PidginCertificateManager.html", "struct__PidginCertificateManager" ],
    [ "pidgin_certmgr_hide", "gtkcertmgr_8h.html#a62f6a421272862e2bc958d79ec74d188", null ],
    [ "pidgin_certmgr_show", "gtkcertmgr_8h.html#af68cfc3c03c1f17ea89bce43fdcba9e8", null ]
];