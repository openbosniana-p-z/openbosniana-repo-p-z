var gtkstyle_8h =
[
    [ "pidgin_style_adjust_contrast", "gtkstyle_8h.html#af279b3811774bb51b22162a185c37b11", null ],
    [ "pidgin_style_is_dark", "gtkstyle_8h.html#a89491d5ebe6df0d219c32f38e7ccb29b", null ]
];