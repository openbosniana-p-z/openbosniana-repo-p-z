var gtkpounce_8h =
[
    [ "pidgin_pounce_editor_show", "gtkpounce_8h.html#ac5ef7e45bd6a24b4d2e9a01170c08a0b", null ],
    [ "pidgin_pounces_get_handle", "gtkpounce_8h.html#a2d77b0d1be1d4339cc967baaa509716e", null ],
    [ "pidgin_pounces_init", "gtkpounce_8h.html#a365b8fda19bf6a73713188e169c5012d", null ],
    [ "pidgin_pounces_manager_hide", "gtkpounce_8h.html#a334bbc4bbfc93ce32689139c8cb3fdc7", null ],
    [ "pidgin_pounces_manager_show", "gtkpounce_8h.html#af2451cf7de6f97d1db9141d0a225e11c", null ]
];