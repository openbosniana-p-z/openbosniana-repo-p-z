var cmds_8h =
[
    [ "PurpleCommandsUiOps", "structPurpleCommandsUiOps.html", "structPurpleCommandsUiOps" ],
    [ "PurpleCmdFlag", "cmds_8h.html#a344cae1725acd453a5f3e149efec1950", null ],
    [ "PurpleCmdFunc", "cmds_8h.html#a5a2ef8cdcaa0d880dc6f587880484f6d", null ],
    [ "PurpleCmdId", "cmds_8h.html#a8bbe0c132aaa475ef61cc1d491efcff5", null ],
    [ "PurpleCmdRet", "cmds_8h.html#a2adf42cd1e40888c2de8c338c30a4ad9", null ],
    [ "PurpleCmdStatus", "cmds_8h.html#aa492439ab68bf57a78302e1454ded74e", null ],
    [ "_PurpleCmdFlag", "cmds_8h.html#a5ec1c1266311361080610b102d343c11", [
      [ "PURPLE_CMD_FLAG_IM", "cmds_8h.html#a5ec1c1266311361080610b102d343c11ac58fb76623647e38b4045369f1da0cd8", null ],
      [ "PURPLE_CMD_FLAG_CHAT", "cmds_8h.html#a5ec1c1266311361080610b102d343c11ac91925dcefb4b8347ae74276e5ec1327", null ],
      [ "PURPLE_CMD_FLAG_PRPL_ONLY", "cmds_8h.html#a5ec1c1266311361080610b102d343c11aa6428ca3ff8d3f6eac4190d274b4c815", null ],
      [ "PURPLE_CMD_FLAG_ALLOW_WRONG_ARGS", "cmds_8h.html#a5ec1c1266311361080610b102d343c11ae8245e1ab47ddb1d08f4d24f3908eddc", null ]
    ] ],
    [ "_PurpleCmdRet", "cmds_8h.html#a0b6659ad1a1053fbc5650440b184aeea", [
      [ "PURPLE_CMD_RET_OK", "cmds_8h.html#a0b6659ad1a1053fbc5650440b184aeeaad46a48a629ea012f20055cea60aaa14f", null ],
      [ "PURPLE_CMD_RET_FAILED", "cmds_8h.html#a0b6659ad1a1053fbc5650440b184aeeaaa34cc2f90ed8d87741f5dbe00a253b69", null ],
      [ "PURPLE_CMD_RET_CONTINUE", "cmds_8h.html#a0b6659ad1a1053fbc5650440b184aeeaa8293a30dc00de42f0af755b8c33d2031", null ]
    ] ],
    [ "_PurpleCmdStatus", "cmds_8h.html#a91f818bb85bca0210e5ce82d3a7e1078", [
      [ "PURPLE_CMD_STATUS_OK", "cmds_8h.html#a91f818bb85bca0210e5ce82d3a7e1078a17fc426b4efef1b7cdfac4e5bd61961f", null ],
      [ "PURPLE_CMD_STATUS_FAILED", "cmds_8h.html#a91f818bb85bca0210e5ce82d3a7e1078abf2977b52b41df93e340311d58c2c863", null ],
      [ "PURPLE_CMD_STATUS_NOT_FOUND", "cmds_8h.html#a91f818bb85bca0210e5ce82d3a7e1078a6fcedddf0f6af2e76a7a83de32387510", null ],
      [ "PURPLE_CMD_STATUS_WRONG_ARGS", "cmds_8h.html#a91f818bb85bca0210e5ce82d3a7e1078a4e283d80ca82bdf03a37e766fab2b639", null ],
      [ "PURPLE_CMD_STATUS_WRONG_PRPL", "cmds_8h.html#a91f818bb85bca0210e5ce82d3a7e1078a8b559479dfc6dca8f8b83eb4bb9bca86", null ],
      [ "PURPLE_CMD_STATUS_WRONG_TYPE", "cmds_8h.html#a91f818bb85bca0210e5ce82d3a7e1078a81b544f4fd3c3c761437ac798348394a", null ]
    ] ],
    [ "purple_cmd_do_command", "cmds_8h.html#a2c983d5d16b4aeec1a6ed44ade75e2a0", null ],
    [ "purple_cmd_execute", "cmds_8h.html#a1ee26a01405580efed1c32a3951cd2bd", null ],
    [ "purple_cmd_help", "cmds_8h.html#a4535820f1a5aea6831911800176f81df", null ],
    [ "purple_cmd_list", "cmds_8h.html#a3569ad96a8202c31d72e3eb628b6fe73", null ],
    [ "purple_cmd_register", "cmds_8h.html#a88007878787dd597532a904ad0cd4190", null ],
    [ "purple_cmd_unregister", "cmds_8h.html#ac7f420c0cdc72a878e733ae83d854a94", null ],
    [ "purple_cmds_get_handle", "cmds_8h.html#a651e2054a8a123640e32f60bfa02f472", null ],
    [ "purple_cmds_get_ui_ops", "cmds_8h.html#ac5690dc8930ad3eaaf817f30a3af7e27", null ],
    [ "purple_cmds_init", "cmds_8h.html#ab4bf78480f52aad1dd1dad7af200525d", null ],
    [ "purple_cmds_set_ui_ops", "cmds_8h.html#a53215426adc2e15694fbbd152e993ae6", null ],
    [ "purple_cmds_uninit", "cmds_8h.html#aa9933bfbf99a3a3a6cf03e0befe7559f", null ]
];