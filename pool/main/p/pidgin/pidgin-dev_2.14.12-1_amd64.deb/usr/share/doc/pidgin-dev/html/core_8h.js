var core_8h =
[
    [ "PurpleCoreUiOps", "structPurpleCoreUiOps.html", "structPurpleCoreUiOps" ],
    [ "purple_core_ensure_single_instance", "core_8h.html#a9b3101962d22fc0b5aa7bd431c9f5d19", null ],
    [ "purple_core_get_ui", "core_8h.html#a6945b2de3e4bdc696c997de717194132", null ],
    [ "purple_core_get_ui_info", "core_8h.html#a5283e097bf166e22553bd603fdf25b0c", null ],
    [ "purple_core_get_ui_ops", "core_8h.html#a27811a09231d365643c3b9fce48108e0", null ],
    [ "purple_core_get_version", "core_8h.html#a61f8489273927c9a01c07d3d15786dbc", null ],
    [ "purple_core_init", "core_8h.html#ad20890a146cd862fab74799dfef26f73", null ],
    [ "purple_core_migrate", "core_8h.html#af6c49bbf2da0d995bd36730d5dc75590", null ],
    [ "purple_core_quit", "core_8h.html#a2c33442d748304eb47834db83a5ce69f", null ],
    [ "purple_core_quit_cb", "core_8h.html#ac74d81c46698b432d383c936fcb2e15a", null ],
    [ "purple_core_set_ui_ops", "core_8h.html#ab11f672706d2023bcd8f0030f54e9288", null ],
    [ "purple_get_core", "core_8h.html#a9da362cedf09620edfd6142357b90676", null ]
];