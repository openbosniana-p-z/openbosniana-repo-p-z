Puppet::Type.type(:designate_tlds_config).provide(
  :openstackconfig,
  :parent => Puppet::Type.type(:openstack_config).provider(:ruby)
) do

  def self.file_path
    '/etc/designate-tlds/designate-tlds.conf'
  end

end
