.. include:: ../../README.rst

See also
~~~~~~~~

See also :doc:`/man/bashate`.
