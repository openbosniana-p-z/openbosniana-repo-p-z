Examples for Lark
=================

**How to run the examples**:

After cloning the repo, open the terminal into the root directory of the
project, and run the following:

.. code:: bash

   [lark]$ python -m examples.<name_of_example>

For example, the following will parse all the Python files in the
standard library of your local installation:

.. code:: bash

   [lark]$ python -m examples.advanced.python_parser

Beginner Examples
~~~~~~~~~~~~~~~~~
