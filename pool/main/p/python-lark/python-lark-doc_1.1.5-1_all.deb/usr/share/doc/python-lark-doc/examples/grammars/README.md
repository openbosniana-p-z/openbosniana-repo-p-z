# Example Grammars

This directory is a collection of lark grammars, taken from real world projects.

- [Verilog](verilog.lark) - Taken from https://github.com/circuitgraph/circuitgraph/blob/master/circuitgraph/parsing/verilog.lark
