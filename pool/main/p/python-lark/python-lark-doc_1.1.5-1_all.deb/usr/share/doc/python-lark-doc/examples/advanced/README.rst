Advanced Examples
~~~~~~~~~~~~~~~~~
