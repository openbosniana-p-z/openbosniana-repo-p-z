sigpack version 0.04

signal object library for pure-data

objects:
sp_chop~ sp_decimate~ sp_diode~ sp_foldback~ sp_foldover~ sp_freqdiv~
sp_freqshift~ sp_hardlimit~ sp_harmgen~ sp_impulse~ sp_rectify~ sp_round~ sp_saturate~ sp_shape~ sp_sieve~
sp_split~ sp_transient~ sp_ustep~ sp_valverect~ sp_vowel~ sp_wavewrap~

released under the GNU/GPL-license
this is software with absolutely no warranty
use it at your own risk

contact
<postmeister@weiss-archiv.de>
<http://www.weiss-archiv.de>

-----------------v0.04-------------------
::cleaning up code a bit
::add GNU/GPL license.txt
::new objects:
  sp_hardlimit~ sp_impulse~ sp_shape~ sp_transient~ sp_valverect~ sp_wavewrap~

-----------------v0.03b------------------
::change prefix to "sp_", so every extern compiles as single object (for pd-extended)

-----------------v0.03-------------------
::add prefix "sp." to avoid nameclash
::new objects:
  sp_diode~ sp_freqshift~ sp_round~ sp_sieve~

-----------------v0.02-------------------
::new objects:
  sp_chop~ sp_decimate~ sp_foldover~ sp_freqdiv~ sp_harmgen~ sp_saturate~ sp_vowel~
  
-----------------v0.01-------------------
::initial release