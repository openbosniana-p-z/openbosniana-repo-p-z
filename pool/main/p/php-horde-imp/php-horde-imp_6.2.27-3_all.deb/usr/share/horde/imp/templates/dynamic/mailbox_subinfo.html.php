<?php if ($this->quota): ?>
<span id="quota-text"></span>
<?php endif ?>
<span id="mailboxLabel">
 <span id="mailboxName"><?php echo _("Loading...") ?></span>
 <span class="iconImg readonlyImg" style="display:none" title="<?php echo _("Read-Only") ?>"></span>
</span>
