<div id="qreply" style="display:none">
 <?php echo $this->qreply ?>
</div>
