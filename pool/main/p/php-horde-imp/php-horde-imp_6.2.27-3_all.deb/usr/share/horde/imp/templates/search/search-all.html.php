<option value="" disabled="disabled">- - - - - - - -</option>
<option value="<?php echo $this->allsearch ?>"><?php echo _("All Mailboxes") ?></option>
<option value="" disabled="disabled">- - - - - - - -</option>
