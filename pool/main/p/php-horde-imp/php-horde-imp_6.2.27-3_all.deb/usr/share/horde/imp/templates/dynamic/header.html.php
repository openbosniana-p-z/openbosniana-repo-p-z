<div style="display:none">
 <span id="largeaddrspan">
  <span class="largeaddrtoggle">
   <span class="largeaddrlist"><?php echo _("Show Addresses (%d)") ?></span>
   <span class="largeaddrlist" style="display:none"><?php echo _("Hide Addresses") ?></span>
  </span>
  <span class="dispaddrlist" style="display:none">
   <span class="largeaddrlistlimit" style="display:none"><?php echo _("Load All Addresses") ?></span>
  </span>
 </span>
</div>
