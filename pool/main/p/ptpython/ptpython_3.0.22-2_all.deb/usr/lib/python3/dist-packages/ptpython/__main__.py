"""
Make `python -m ptpython` an alias for running `./ptpython`.
"""
from .entry_points.run_ptpython import run

run()
