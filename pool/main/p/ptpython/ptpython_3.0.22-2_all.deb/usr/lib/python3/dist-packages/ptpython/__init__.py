from .repl import embed

__all__ = ["embed"]
