<?php

// PSR-4 compatibility with Pear_CHAP.php

require_once __DIR__ . '/../../Pear_CHAP.php';
