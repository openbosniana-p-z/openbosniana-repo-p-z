(** @canonical Ppx_import.Compat *)
module Compat = Ppx_import__Compat


(** @canonical Ppx_import.Ppx_types_migrate *)
module Ppx_types_migrate = Ppx_import__Ppx_types_migrate
