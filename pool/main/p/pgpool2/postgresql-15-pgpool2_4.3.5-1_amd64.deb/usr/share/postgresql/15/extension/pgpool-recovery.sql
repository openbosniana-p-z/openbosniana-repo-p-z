CREATE FUNCTION pgpool_recovery(IN script_name text,
	   IN remote_host text,
	   IN remote_data_directory text,
	   IN primary_port text,
	   IN remote_node integer,
	   IN remote_port text,
	   IN primary_host text)
RETURNS bool
AS '$libdir/pgpool-recovery', 'pgpool_recovery'
LANGUAGE C STRICT;

CREATE FUNCTION pgpool_recovery(IN script_name text,
	   IN remote_host text,
	   IN remote_data_directory text,
	   IN primary_port text,
	   IN remote_node integer,
	   IN remote_port text)
RETURNS bool
AS '$libdir/pgpool-recovery', 'pgpool_recovery'
LANGUAGE C STRICT;

CREATE FUNCTION pgpool_recovery(IN script_name text,
	   IN remote_host text,
	   IN remote_data_directory text,
	   IN primary_port text,
	   IN remote_node integer)
RETURNS bool
AS '$libdir/pgpool-recovery', 'pgpool_recovery'
LANGUAGE C STRICT;

CREATE FUNCTION pgpool_recovery(IN script_name text,
	   IN remote_host text,
	   IN remote_data_directory text,
	   IN primary_port text)
RETURNS bool
AS '$libdir/pgpool-recovery', 'pgpool_recovery'
LANGUAGE C STRICT;

CREATE FUNCTION pgpool_recovery(IN script_name text,
	   IN remote_host text,
	   IN remote_data_directory text)
RETURNS bool
AS '$libdir/pgpool-recovery', 'pgpool_recovery'
LANGUAGE C STRICT;

CREATE FUNCTION pgpool_remote_start(text, text)
RETURNS bool
AS '$libdir/pgpool-recovery', 'pgpool_remote_start'
LANGUAGE C STRICT;

CREATE FUNCTION pgpool_pgctl(text, text)
RETURNS bool
AS '$libdir/pgpool-recovery', 'pgpool_pgctl'
LANGUAGE C STRICT;

CREATE FUNCTION pgpool_switch_xlog(text)
RETURNS text
AS '$libdir/pgpool-recovery', 'pgpool_switch_xlog'
LANGUAGE C STRICT;
