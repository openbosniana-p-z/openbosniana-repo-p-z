version="2.11.1-2"

versionString="Pymecavideo version %s" %version

