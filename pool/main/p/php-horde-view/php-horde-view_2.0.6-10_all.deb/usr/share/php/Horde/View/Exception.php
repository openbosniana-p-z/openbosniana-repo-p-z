<?php
/**
 * @category Horde
 * @package View
 */

/**
 * @category Horde
 * @package View
 */
class Horde_View_Exception extends Exception
{
}
