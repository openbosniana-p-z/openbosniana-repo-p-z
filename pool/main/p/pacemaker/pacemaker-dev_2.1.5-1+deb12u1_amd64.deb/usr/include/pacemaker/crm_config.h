/* include/crm_config.h.  Generated from crm_config.h.in by configure.  */
/*
 * Copyright 2006-2021 the Pacemaker project contributors
 *
 * The version control history for this file may have further details.
 *
 * This source code is licensed under the GNU General Public License version 2
 * or later (GPLv2+) WITHOUT ANY WARRANTY.
 */

#ifndef PCMK__CRM_CONFIG__H
#define PCMK__CRM_CONFIG__H

/****** Versions ******/

/* Current pacemaker version */
#define PACEMAKER_VERSION "2.1.5"

/* Build version */
#define BUILD_VERSION "a3f44794f94"

/****** Other ******/

/* Group to run Pacemaker daemons as */
#define CRM_DAEMON_GROUP "haclient"

/* User to run Pacemaker daemons as */
#define CRM_DAEMON_USER "hacluster"

/****** Directories ******/

/* Where Pacemaker can store log files */
#define CRM_LOG_DIR "/var/log/pacemaker"

/* Location for Pacemaker daemons */
#define CRM_DAEMON_DIR "/usr/lib/pacemaker"

/* Where to keep blackbox dumps */
#define CRM_BLACKBOX_DIR "/var/lib/pacemaker/blackbox"

/* Where to keep configuration files */
#define CRM_CONFIG_DIR "/var/lib/pacemaker/cib"

/* Where to keep scheduler outputs */
#define PE_STATE_DIR "/var/lib/pacemaker/pengine"

/* Location to store core files produced by Pacemaker daemons */
#define CRM_CORE_DIR "/var/lib/pacemaker/cores"

/* Where to keep state files and sockets */
#define CRM_STATE_DIR "/run/crm"

/* Location for the Pacemaker Relax-NG Schema */
#define CRM_SCHEMA_DIRECTORY "/usr/share/pacemaker"

/* Where to keep configuration files like authkey */
#define PACEMAKER_CONFIG_DIR "/etc/pacemaker"

/* Where OCF resource agents and libraries can be found */
#define OCF_ROOT_DIR "/usr/lib/ocf"

/****** Features ******/

/* Set of enabled features */
#define CRM_FEATURES "agent-manpages cibsecrets corosync-ge-2 generated-manpages lha monotonic nagios ncurses remote systemd"

/* Support the Corosync messaging and membership layer */
#define SUPPORT_COROSYNC 1

/* Support systemd based system services */
#define SUPPORT_SYSTEMD 1

/* Support upstart based system services */
#define SUPPORT_UPSTART 0

#endif /* CRM_CONFIG__H */
