<?php

declare(strict_types=1);

namespace AsyncAws\Core\Exception;

class InvalidArgument extends \InvalidArgumentException implements Exception
{
}
