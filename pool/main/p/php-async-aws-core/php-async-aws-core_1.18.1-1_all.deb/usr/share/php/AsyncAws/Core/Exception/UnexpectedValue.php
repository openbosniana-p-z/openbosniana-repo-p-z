<?php

declare(strict_types=1);

namespace AsyncAws\Core\Exception;

class UnexpectedValue extends \UnexpectedValueException implements Exception
{
}
