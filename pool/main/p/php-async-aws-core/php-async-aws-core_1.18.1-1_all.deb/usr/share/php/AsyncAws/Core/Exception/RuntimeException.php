<?php

declare(strict_types=1);

namespace AsyncAws\Core\Exception;

class RuntimeException extends \RuntimeException implements Exception
{
}
