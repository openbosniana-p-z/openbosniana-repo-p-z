<?php

declare(strict_types=1);

namespace AsyncAws\Core\Exception;

class LogicException extends \LogicException implements Exception
{
}
