**************
Test functions
**************

.. contents:: :local:

Test a variety of more difficult problems to see how well DREAM can recover
the correct probability definition.


.. toctree::

    anticor.rst
    bounded.rst
    cross.rst
