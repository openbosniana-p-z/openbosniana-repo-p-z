from sitedoc import fit_model
fit_model('curve.py')