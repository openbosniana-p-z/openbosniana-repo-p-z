# Copyright 2014-2021 The aiosmtpd Developers
# SPDX-License-Identifier: Apache-2.0

from aiosmtpd.main import main

if __name__ == '__main__':
    main()
