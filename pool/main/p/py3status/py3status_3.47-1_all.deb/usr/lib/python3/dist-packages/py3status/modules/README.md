# Modules documentation

Up to date modules documentation: https://py3status.readthedocs.io/en/latest/user-guide/modules
