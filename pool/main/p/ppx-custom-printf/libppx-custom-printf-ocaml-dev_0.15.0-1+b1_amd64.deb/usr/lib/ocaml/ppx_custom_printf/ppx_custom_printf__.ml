(** @canonical Ppx_custom_printf.Format_lifter *)
module Format_lifter = Ppx_custom_printf__Format_lifter
