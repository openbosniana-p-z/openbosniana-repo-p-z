Regression tests for fixed bugs or known broken bugs (XFAIL).

Each test should return EXIT_SUCCESS on success and EXIT_FAILURE on
failure.
