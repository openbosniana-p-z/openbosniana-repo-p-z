void test_func() {
    printf("OK\n");
}
