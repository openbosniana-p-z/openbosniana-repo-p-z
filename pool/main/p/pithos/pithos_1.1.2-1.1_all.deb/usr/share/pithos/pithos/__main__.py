from pithos.pithos import main

main()
