<?php 

namespace RtfHtmlPhp;

/**
 * Element is the parent class of all RTF elements,
 * like Group, ControlWord and ControlSymbol.
 */
class Element
{
}
