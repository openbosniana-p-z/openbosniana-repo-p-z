<?php
namespace TheSeer\Autoload;

interface StaticListRenderer {

    /**
     * @return string
     */
    public function render(array $list);
}
