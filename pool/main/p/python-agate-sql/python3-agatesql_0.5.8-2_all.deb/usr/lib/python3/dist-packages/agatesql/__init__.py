#!/usr/bin/env python

import agatesql.table
