#!/bin/bash
# properties = {properties}

if [ 'yes' = 'yes' ]; then
    export R_LIBS_SITE=""
    export PYTHONPATH=""
fi

env

{exec_job}
