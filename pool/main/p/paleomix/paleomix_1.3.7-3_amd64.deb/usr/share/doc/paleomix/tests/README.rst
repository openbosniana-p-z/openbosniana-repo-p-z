To run the test suite, install and run 'tox':

    $ pip install --user tox
    $ tox
