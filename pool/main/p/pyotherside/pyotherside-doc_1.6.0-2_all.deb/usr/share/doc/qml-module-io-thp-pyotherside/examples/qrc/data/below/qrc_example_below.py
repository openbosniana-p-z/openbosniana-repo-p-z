import sys
import pyotherside

print('Hello from below!')
print('sys.path =', sys.path)
print('pyotherside =', pyotherside)
