def info():
    return 'This is the nested.module module'

value = 123
