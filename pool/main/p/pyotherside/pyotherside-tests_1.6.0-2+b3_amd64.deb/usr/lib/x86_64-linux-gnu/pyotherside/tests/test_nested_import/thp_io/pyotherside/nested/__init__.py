def info():
    return 'This is the nested package'
