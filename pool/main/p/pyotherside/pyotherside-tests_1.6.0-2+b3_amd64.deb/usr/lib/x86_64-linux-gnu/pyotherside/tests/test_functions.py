def function_that_takes_one_parameter(parameter):
    '''For tst_model_add_one:call_sync_with_parameters'''
    assert parameter == 1
    return 1
