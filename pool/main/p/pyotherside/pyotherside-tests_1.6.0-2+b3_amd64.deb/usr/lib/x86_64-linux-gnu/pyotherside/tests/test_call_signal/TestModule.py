import pyotherside

def makeCalls(obj):
    print(f'result of callFunction: {obj.callFunction()}')
    print(f'result of callSignal: {obj.callSignal()}')
