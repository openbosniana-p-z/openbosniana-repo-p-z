<?php

class Text_Wiki_Render_Creole_Prefilter extends Text_Wiki_Render {
    function token()
    {
        return '';
    }
}

?>