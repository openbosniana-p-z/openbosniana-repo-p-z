<?php

class Text_Wiki_Render_Latex_Newline extends Text_Wiki_Render {
    
    
    function token($options)
    {
        return "\\newline\n";
    }
}

?>