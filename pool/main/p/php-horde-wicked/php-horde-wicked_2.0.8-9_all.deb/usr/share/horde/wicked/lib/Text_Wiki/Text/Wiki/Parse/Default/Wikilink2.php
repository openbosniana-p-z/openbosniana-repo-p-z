<?php

require_once 'Text/Wiki/Parse/Default/Wikilink.php';

/**
 * Placeholder class as a complement to the Wikilink2 renderer.
 *
 * @package Wicked
 */
class Text_Wiki_Parse_Wikilink2 extends Text_Wiki_Parse_Wikilink { }
