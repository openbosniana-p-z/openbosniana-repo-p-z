<?php

class Text_Wiki_Render_Creole_Newline extends Text_Wiki_Render {


    function token($options)
    {
        return "\n";
    }
}

?>