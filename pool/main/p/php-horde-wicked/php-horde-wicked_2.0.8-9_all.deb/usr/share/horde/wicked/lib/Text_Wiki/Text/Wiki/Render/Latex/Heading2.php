<?php
/**
 * @package Wicked
 */
class Text_Wiki_Render_Latex_Heading2 extends Text_Wiki_Render_Latex_Heading
{
}
