<?php

require_once 'Text/Wiki/Render/Cowiki/Wikilink.php';

class Text_Wiki_Render_CoWiki_Freelink extends Text_Wiki_Render_CoWiki_Wikilink {
    // renders identically to wikilinks, only the parsing is different :-)
}

?>