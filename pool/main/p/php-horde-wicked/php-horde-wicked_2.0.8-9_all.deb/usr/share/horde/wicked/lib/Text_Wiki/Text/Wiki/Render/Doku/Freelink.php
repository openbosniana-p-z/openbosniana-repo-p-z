<?php

require_once 'Text/Wiki/Render/Doku/Wikilink.php';

class Text_Wiki_Render_Doku_Freelink extends Text_Wiki_Render_Doku_Wikilink {
    // renders identically to wikilinks, only the parsing is different :-)
}

?>