<?php
require_once 'Text/Wiki/Render/Latex/Wikilink.php';

class Text_Wiki_Render_Latex_Freelink extends Text_Wiki_Render_Latex_Wikilink
{
    // renders identically to wikilinks, only the parsing is different :-)    
}
?>
