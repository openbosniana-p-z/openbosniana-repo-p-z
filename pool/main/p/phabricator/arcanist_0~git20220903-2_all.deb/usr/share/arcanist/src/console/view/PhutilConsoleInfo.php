<?php

final class PhutilConsoleInfo
  extends PhutilConsoleLogLine {

  protected function getLogLineColor() {
    return 'green';
  }

}
