<?php

require_once dirname(dirname(__FILE__)).'/support/init/init-script.php';
