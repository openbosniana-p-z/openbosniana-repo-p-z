<?php

final class ArcanistDiffByteSizeException extends Exception {}
