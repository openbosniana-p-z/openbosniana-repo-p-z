<?php

final class ArcanistNoURIConduitException
  extends ArcanistConduitException {}
