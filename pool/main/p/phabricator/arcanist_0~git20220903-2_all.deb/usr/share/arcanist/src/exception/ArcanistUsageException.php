<?php

/**
 * Thrown when there is a problem with how a user is invoking a command, rather
 * than a technical problem.
 *
 * @concrete-extensible
 */
class ArcanistUsageException extends Exception {}
