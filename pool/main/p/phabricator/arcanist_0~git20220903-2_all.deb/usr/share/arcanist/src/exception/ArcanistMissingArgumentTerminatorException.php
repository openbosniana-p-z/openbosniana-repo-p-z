<?php

final class ArcanistMissingArgumentTerminatorException
  extends Exception {}
