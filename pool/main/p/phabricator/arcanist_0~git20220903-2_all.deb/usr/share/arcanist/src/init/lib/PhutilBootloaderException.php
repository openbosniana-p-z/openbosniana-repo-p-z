<?php

final class PhutilBootloaderException extends Exception {}
