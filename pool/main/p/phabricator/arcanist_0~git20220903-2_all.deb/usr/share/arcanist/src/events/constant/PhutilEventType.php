<?php

/**
 * @concrete-extensible
 */
class PhutilEventType extends PhutilEventConstants {

  const TYPE_ALL              = '*';

}
