<?php

final class PhutilConsoleWarning
  extends PhutilConsoleLogLine {

  protected function getLogLineColor() {
    return 'yellow';
  }

}
