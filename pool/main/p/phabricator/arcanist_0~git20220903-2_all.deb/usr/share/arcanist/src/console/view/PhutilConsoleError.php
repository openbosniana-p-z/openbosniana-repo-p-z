<?php

final class PhutilConsoleError
  extends PhutilConsoleLogLine {

  protected function getLogLineColor() {
    return 'red';
  }

}
