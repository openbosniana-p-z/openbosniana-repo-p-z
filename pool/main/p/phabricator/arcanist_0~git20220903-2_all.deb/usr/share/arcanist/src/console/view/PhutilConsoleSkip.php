<?php

final class PhutilConsoleSkip
  extends PhutilConsoleLogLine {

  protected function getLogLineColor() {
    return 'blue';
  }

}
