-- complain if this upgrade script is run via psql
\echo Use "ALTER EXTENSION pg_sphere UPDATE TO '1.0_gavo'" to load this file. \quit
