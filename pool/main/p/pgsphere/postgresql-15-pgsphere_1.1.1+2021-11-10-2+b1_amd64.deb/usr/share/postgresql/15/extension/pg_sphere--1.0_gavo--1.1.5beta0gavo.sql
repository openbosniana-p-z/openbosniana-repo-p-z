-- complain if this upgrade script is run via psql
\echo Use "ALTER EXTENSION pg_sphere UPDATE TO '1.1.5beta0gavo'" to load this file. \quit
-- conversions to / from Healpix indexing

CREATE OR REPLACE FUNCTION nest2ring(integer, bigint)
RETURNS bigint
AS 'MODULE_PATHNAME', 'pg_nest2ring'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION nest2ring(integer, bigint) IS
'converts nested Healpix index to a ring Healpix index for the specified integer level (first argument)';

CREATE OR REPLACE FUNCTION ring2nest(integer, bigint)
RETURNS bigint
AS 'MODULE_PATHNAME', 'pg_ring2nest'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION ring2nest(integer, bigint) IS
'converts ringe Healpix index to a nested Healpix index for the specified integer level (first argument)';

CREATE OR REPLACE FUNCTION healpix_convert_nest(integer, integer, bigint)
RETURNS bigint
AS 'MODULE_PATHNAME'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION healpix_convert_nest(integer, integer, bigint) IS
'converts nested Healpix index (last argument) from level of second argument to level of first argument';

CREATE OR REPLACE FUNCTION healpix_convert_ring(integer, integer, bigint)
RETURNS bigint
AS 'MODULE_PATHNAME'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION healpix_convert_ring(integer, integer, bigint) IS
'converts ring Healpix index (last argument) from level of second argument to level of first argument';

CREATE OR REPLACE FUNCTION nside2order(bigint)
RETURNS integer
AS 'MODULE_PATHNAME', 'pg_nside2order'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION nside2order(bigint) IS
'returns integer part of base-two logarithm of argument for powers of two up to 29';

CREATE OR REPLACE FUNCTION order2nside(integer)
RETURNS bigint
AS 'MODULE_PATHNAME', 'pg_order2nside'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION order2nside(integer) IS
'returns power of two for non-negative values up to 29';

CREATE OR REPLACE FUNCTION nside2npix(bigint)
RETURNS bigint
AS 'MODULE_PATHNAME', 'pg_nside2npix'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION nside2npix(bigint) IS
'returns 12 * nside ^ 2, the number of Healpix elements for the nside parameter';

CREATE OR REPLACE FUNCTION npix2nside(bigint)
RETURNS bigint
AS 'MODULE_PATHNAME', 'pg_npix2nside'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION npix2nside(bigint) IS
'returns the nside parameter correspondig to the number of Healpix elements';

CREATE OR REPLACE FUNCTION healpix_nest(integer, spoint)
RETURNS bigint
AS 'MODULE_PATHNAME'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION healpix_nest(integer, spoint) IS
'nested Healpix index of a spherical point for the specified integer level (first argument)';

CREATE OR REPLACE FUNCTION healpix_ring(integer, spoint)
RETURNS bigint
AS 'MODULE_PATHNAME'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION healpix_ring(integer, spoint) IS
'Healpix ring index of a spherical point for the specified integer level (first argument)';

CREATE OR REPLACE FUNCTION centre_of_healpix_nest(integer, bigint)
RETURNS spoint
AS 'MODULE_PATHNAME', 'inv_healpix_nest'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION centre_of_healpix_nest(integer, bigint) IS
'spherical point designating the centre of a nested Healpix element for the specified integer level (first argument)';

CREATE OR REPLACE FUNCTION centre_of_healpix_ring(integer, bigint)
RETURNS spoint
AS 'MODULE_PATHNAME', 'inv_healpix_ring'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION centre_of_healpix_ring(integer, bigint) IS
'spherical point designating the centre of a ring Healpix element for the specified integer level (first argument)';

CREATE OR REPLACE FUNCTION center_of_healpix_nest(integer, bigint)
RETURNS spoint
AS 'MODULE_PATHNAME', 'inv_healpix_nest'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION center_of_healpix_nest(integer, bigint) IS
'spherical point designating the center of a nested Healpix element for the specified integer level (first argument)';

CREATE OR REPLACE FUNCTION center_of_healpix_ring(integer, bigint)
RETURNS spoint
AS 'MODULE_PATHNAME', 'inv_healpix_ring'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION center_of_healpix_ring(integer, bigint) IS
'spherical point designating the center of a ring Healpix element for the specified integer level (first argument)';
-- create the next generation operator class for spherical points

CREATE FUNCTION g_spoint3_union(bytea, internal)
	RETURNS spherekey
	AS 'MODULE_PATHNAME', 'g_spoint3_union'
	LANGUAGE 'c';	

CREATE FUNCTION g_spoint3_penalty (internal, internal, internal)
	RETURNS internal
	AS 'MODULE_PATHNAME', 'g_spoint3_penalty'
	LANGUAGE 'c'
	STRICT;

CREATE FUNCTION g_spoint3_picksplit(internal, internal)
	RETURNS internal
	AS 'MODULE_PATHNAME', 'g_spoint3_picksplit'
	LANGUAGE 'c';

CREATE FUNCTION g_spoint3_same (bytea, bytea, internal)
	RETURNS internal
	AS 'MODULE_PATHNAME', 'g_spoint3_same'
	LANGUAGE 'c';

CREATE FUNCTION g_spoint3_compress(internal)
	RETURNS internal
	AS 'MODULE_PATHNAME', 'g_spoint3_compress'
	LANGUAGE 'c';	

CREATE FUNCTION g_spoint3_consistent(internal, internal, int4, oid, internal)
	RETURNS internal
	AS 'MODULE_PATHNAME', 'g_spoint3_consistent'
	LANGUAGE 'c';	

CREATE FUNCTION g_spoint3_distance(internal, internal, int4, oid)
	RETURNS float8
	AS 'MODULE_PATHNAME', 'g_spoint3_distance'
	LANGUAGE 'c';	

CREATE FUNCTION g_spoint3_fetch(internal)
	RETURNS internal
	AS 'MODULE_PATHNAME', 'g_spoint3_fetch'
	LANGUAGE 'c'
	STRICT;

CREATE OPERATOR CLASS spoint3
	FOR TYPE spoint USING gist AS
	OPERATOR   1 = (spoint, spoint),
	OPERATOR  11 @ (spoint, scircle),
	OPERATOR  12 @ (spoint, sline),
	OPERATOR  13 @ (spoint, spath),
	OPERATOR  14 @ (spoint, spoly),
	OPERATOR  15 @ (spoint, sellipse),
	OPERATOR  16 @ (spoint, sbox),
	OPERATOR  37 <@ (spoint, scircle),
	OPERATOR  38 <@ (spoint, sline),
	OPERATOR  39 <@ (spoint, spath),
	OPERATOR  40 <@ (spoint, spoly),
	OPERATOR  41 <@ (spoint, sellipse),
	OPERATOR  42 <@ (spoint, sbox),
	OPERATOR  100 <-> (spoint, spoint) FOR ORDER BY float_ops,
	FUNCTION  1 g_spoint3_consistent (internal, internal, int4, oid, internal),
	FUNCTION  2 g_spoint3_union (bytea, internal),
	FUNCTION  3 g_spoint3_compress (internal),
	FUNCTION  4 g_spherekey_decompress (internal),
	FUNCTION  5 g_spoint3_penalty (internal, internal, internal),
	FUNCTION  6 g_spoint3_picksplit (internal, internal),
	FUNCTION  7 g_spoint3_same (bytea, bytea, internal),
	FUNCTION  8 g_spoint3_distance (internal, internal, int4, oid),
	STORAGE	pointkey;
-- fix typo in commutator of OPERATOR !@>(spoly, sellipse) (a.k.a. !~) introduced in commits 2798ed96f9282ddeee21d5ddd3e256bbb9b4f36f and 244c1549c492426b62bc926c9ac2ad21f3ccd0c1

DROP OPERATOR !@> (spoly, sellipse) CASCADE;
DROP OPERATOR  !~ (spoly, sellipse) CASCADE;

CREATE OPERATOR !@> (
   LEFTARG    = spoly,
   RIGHTARG   = sellipse,
   PROCEDURE  = spoly_contains_ellipse_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);
COMMENT ON OPERATOR !@> (spoly, sellipse) IS 'true if spherical polygon (LHS) does not contain spherical ellipse (RHS)';

CREATE OPERATOR !~ (
   LEFTARG    = spoly,
   RIGHTARG   = sellipse,
   PROCEDURE  = spoly_contains_ellipse_neg,
   COMMUTATOR = '!@',
   NEGATOR    = '~',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);
COMMENT ON OPERATOR !~ (spoly, sellipse) IS 'true if spherical polygon (LHS) does not contain spherical ellipse (RHS)';
DROP OPERATOR CLASS IF EXISTS spoint2 USING gist CASCADE;
DROP FUNCTION IF EXISTS g_spoint2_union(bytea, internal) CASCADE;
DROP FUNCTION IF EXISTS g_spoint2_penalty (internal, internal, internal) CASCADE;
DROP FUNCTION IF EXISTS g_spoint2_picksplit(internal, internal) CASCADE;
DROP FUNCTION IF EXISTS g_spoint2_same (bytea, bytea, internal) CASCADE;
DROP FUNCTION IF EXISTS g_spoint2_compress(internal) CASCADE;
DROP FUNCTION IF EXISTS g_spoint2_consistent(internal, internal, int4, oid, internal) CASCADE;
DROP FUNCTION IF EXISTS g_spoint2_distance(internal, internal, int4, oid) CASCADE;

DROP FUNCTION IF EXISTS crossmatch(text, text, float8);
DROP FUNCTION IF EXISTS crossmatch(text, text, float8, sbox);
