-- complain if this upgrade script is run via psql
\echo Use "CREATE EXTENSION pg_sphere FROM unpackaged" to load this file. \quit
-- versions before 2009-11-01 (i.e., release 1.1.1.) lack pg_sphere_version(),
-- see https://postgrespro.ru/list/id/20091101150558.9B87B1073FEE@pgfoundry.org

CREATE OR REPLACE FUNCTION pg_sphere_version()
   RETURNS CSTRING
   AS 'MODULE_PATHNAME', 'pg_sphere_version'
   LANGUAGE 'c';
--- scircle vs scircle

CREATE OPERATOR @> (
   LEFTARG    = scircle,
   RIGHTARG   = scircle,
   PROCEDURE  = scircle_contains_circle,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (scircle, scircle) IS 'true if spherical circle (LHS) contains spherical circle (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = scircle,
   RIGHTARG   = scircle,
   PROCEDURE  = scircle_contained_by_circle,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (scircle, scircle) IS 'true if spherical circle (LHS) is contained by spherical circle (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = scircle,
   RIGHTARG   = scircle,
   PROCEDURE  = scircle_contains_circle_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (scircle, scircle) IS 'true if spherical circle (LHS) does not contain spherical circle (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = scircle,
   RIGHTARG   = scircle,
   PROCEDURE  = scircle_contained_by_circle_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (scircle, scircle) IS 'true if spherical circle (LHS) is not contained by spherical circle (RHS)';

--- spoint vs scircle

CREATE OPERATOR @> (
   LEFTARG    = scircle,
   RIGHTARG   = spoint,
   PROCEDURE  = spoint_contained_by_circle_com,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (scircle, spoint) IS 'true if spherical circle (LHS) contains spherical point (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = spoint,
   RIGHTARG   = scircle,
   PROCEDURE  = spoint_contained_by_circle,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (spoint, scircle) IS 'true if spherical point (LHS) is contained by spherical circle (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = scircle,
   RIGHTARG   = spoint,
   PROCEDURE  = spoint_contained_by_circle_com_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (scircle, spoint) IS 'true if spherical circle (LHS) does not contain spherical point (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = spoint,
   RIGHTARG   = scircle,
   PROCEDURE  = spoint_contained_by_circle_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (spoint, scircle) IS 'true if spherical point (LHS) is not contained by spherical circle (RHS)';

--- spoly vs spoly

CREATE OPERATOR @> (
   LEFTARG    = spoly,
   RIGHTARG   = spoly,
   PROCEDURE  = spoly_contains_polygon,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (spoly, spoly) IS 'true if spherical polygon (LHS) contains spherical polygon (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = spoly,
   RIGHTARG   = spoly,
   PROCEDURE  = spoly_contains_polygon_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (spoly, spoly) IS 'true if spherical polygon (LHS) is contained by spherical polygon (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = spoly,
   RIGHTARG   = spoly,
   PROCEDURE  = spoly_contains_polygon_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (spoly, spoly) IS 'true if spherical polygon (LHS) does not contain spherical polygon (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = spoly,
   RIGHTARG   = spoly,
   PROCEDURE  = spoly_contains_polygon_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (spoly, spoly) IS 'true if spherical polygon (LHS) is not contained by spherical polygon (RHS)';

--  spoly vs spoint

CREATE OPERATOR @> (
   LEFTARG    = spoly,
   RIGHTARG   = spoint,
   PROCEDURE  = spoly_contains_point,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (spoly, spoint) IS 'true if spherical polygon (LHS) contains spherical point (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = spoint,
   RIGHTARG   = spoly,
   PROCEDURE  = spoly_contains_point_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (spoint, spoly) IS 'true if spherical point (LHS) is contained by spherical polygon (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = spoly,
   RIGHTARG   = spoint,
   PROCEDURE  = spoly_contains_point_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (spoly, spoint) IS 'true if spherical polygon (LHS) does not contain spherical point (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = spoint,
   RIGHTARG   = spoly,
   PROCEDURE  = spoly_contains_point_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (spoint, spoly) IS 'true if spherical point (LHS) is not contained by spherical polygon (RHS)';


--- scircle vs spoly

CREATE OPERATOR @> (
   LEFTARG    = scircle,
   RIGHTARG   = spoly,
   PROCEDURE  = scircle_contains_polygon,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (scircle, spoly) IS 'true if spherical circle (LHS) contains spherical polygon (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = spoly,
   RIGHTARG   = scircle,
   PROCEDURE  = scircle_contains_polygon_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (spoly, scircle) IS 'true if spherical polygon (LHS) is contained by spherical circle (LHS)';

CREATE OPERATOR !@> (
   LEFTARG    = scircle,
   RIGHTARG   = spoly,
   PROCEDURE  = scircle_contains_polygon_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (scircle, spoly) IS 'true if spherical circle (LHS) does not contain spherical polygon (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = spoly,
   RIGHTARG   = scircle,
   PROCEDURE  = scircle_contains_polygon_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (spoly, scircle) IS 'true if spherical polygon (LHS) is not contained spherical circle (RHS)';

CREATE OPERATOR @> (
   LEFTARG    = spoly,
   RIGHTARG   = scircle,
   PROCEDURE  = spoly_contains_circle,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (spoly, scircle) IS 'true if spherical polygon (LHS) contains spherical circle (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = scircle,
   RIGHTARG   = spoly,
   PROCEDURE  = spoly_contains_circle_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (scircle, spoly) IS 'true if spherical circle (LHS) is contained by spherical polygon (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = spoly,
   RIGHTARG   = scircle,
   PROCEDURE  = spoly_contains_circle_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (spoly, scircle) IS 'true if spherical polygon (LHS) does not contain spherical circle (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = scircle,
   RIGHTARG   = spoly,
   PROCEDURE  = spoly_contains_circle_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (scircle, spoly) IS 'true if spherical circle (LHS) is not contained by spherical polygon (RHS)';


--- sbox vs sbox

CREATE OPERATOR @> (
   LEFTARG    = sbox,
   RIGHTARG   = sbox,
   PROCEDURE  = sbox_contains_box,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (sbox, sbox) IS 'true if spherical box (LHS) contains spherical box (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = sbox,
   RIGHTARG   = sbox,
   PROCEDURE  = sbox_contains_box_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (sbox, sbox) IS 'true if spherical box (LHS) is contained by spherical box (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = sbox,
   RIGHTARG   = sbox,
   PROCEDURE  = sbox_contains_box_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (sbox, sbox) IS 'true if spherical box (LHS) does not contain spherical box (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = sbox,
   RIGHTARG   = sbox,
   PROCEDURE  = sbox_contains_box_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (sbox, sbox) IS 'true if spherical box (LHS) is not contained by spherical box (RHS)';

--- sbox vs spoint

CREATE OPERATOR @> (
   LEFTARG    = sbox,
   RIGHTARG   = spoint,
   PROCEDURE  = sbox_cont_point,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (sbox, spoint) IS 'true if spherical box (LHS) contains spherical point (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = spoint,
   RIGHTARG   = sbox,
   PROCEDURE  = sbox_cont_point_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (spoint, sbox) IS 'true if spherical point (LHS) is contained by spherical box (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = sbox,
   RIGHTARG   = spoint,
   PROCEDURE  = sbox_cont_point_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (sbox, spoint) IS 'true if spherical box (LHS) does not contain spherical point (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = spoint,
   RIGHTARG   = sbox,
   PROCEDURE  = sbox_cont_point_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (spoint, sbox) IS 'true if spherical point (LHS) is not contained by spherical box (RHS)';

--- scircle vs sbox

CREATE OPERATOR @> (
   LEFTARG    = scircle,
   RIGHTARG   = sbox,
   PROCEDURE  = scircle_contains_box,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (scircle, sbox) IS 'true if spherical circle (LHS) contains spherical box (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = sbox,
   RIGHTARG   = scircle,
   PROCEDURE  = scircle_contains_box_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (sbox, scircle) IS 'true if spherical box (LHS) is contained by spherical circle (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = scircle,
   RIGHTARG   = sbox,
   PROCEDURE  = scircle_contains_box_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (scircle, sbox) IS 'true if spherical circle (LHS) does not contain spherical box (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = sbox,
   RIGHTARG   = scircle,
   PROCEDURE  = scircle_contains_box_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (sbox, scircle) IS 'true if spherical box (LHS) is not contained by spherical circle (RHS)';

CREATE OPERATOR @> (
   LEFTARG    = sbox,
   RIGHTARG   = scircle,
   PROCEDURE  = sbox_contains_circle,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (sbox, scircle) IS 'true if spherical box (LHS) contains spherical circle (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = scircle,
   RIGHTARG   = sbox,
   PROCEDURE  = sbox_contains_circle_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (scircle, sbox) IS 'true if spherical circle (LHS) contains spherical box (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = sbox,
   RIGHTARG   = scircle,
   PROCEDURE  = sbox_contains_circle_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (sbox, scircle) IS 'true if spherical box (LHS) does not contain spherical circle (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = scircle,
   RIGHTARG   = sbox,
   PROCEDURE  = sbox_contains_circle_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (scircle, sbox) IS 'true if spherical circle (LHS) is not contained by spherical box (RHS)';


--- sbox vs spoly

CREATE OPERATOR @> (
   LEFTARG    = spoly,
   RIGHTARG   = sbox,
   PROCEDURE  = spoly_contains_box,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (spoly, sbox) IS 'true if spherical polygon (LHS) contains spherical box (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = sbox,
   RIGHTARG   = spoly,
   PROCEDURE  = spoly_contains_box_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (sbox, spoly) IS 'true if spherical box (LHS) is contained by spherical polygon (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = spoly,
   RIGHTARG   = sbox,
   PROCEDURE  = spoly_contains_box_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (spoly, sbox) IS 'true if spherical polygon (LHS) does not contain spherical box (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = sbox,
   RIGHTARG   = spoly,
   PROCEDURE  = spoly_contains_box_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (sbox, spoly) IS 'true if spherical box (LHS) is not contained by spherical polygon (RHS)';

CREATE OPERATOR @> (
   LEFTARG    = sbox,
   RIGHTARG   = spoly,
   PROCEDURE  = sbox_contains_poly,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (sbox, spoly) IS 'true if spherical box (LHS) contains spherical polygon (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = spoly,
   RIGHTARG   = sbox,
   PROCEDURE  = sbox_contains_poly_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (spoly, sbox) IS 'true if spherical polygon (LHS) is contained by spherical box (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = sbox,
   RIGHTARG   = spoly,
   PROCEDURE  = sbox_contains_poly_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (sbox, spoly) IS 'true if spherical box (LHS) does not contain spherical polygon (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = spoly,
   RIGHTARG   = sbox,
   PROCEDURE  = sbox_contains_poly_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (spoly, sbox) IS 'true if spherical polygon (LHS) is not contained by spherical box (RHS)';

-- new stuff --

CREATE OPERATOR <@ (
   LEFTARG    = spoint,
   RIGHTARG   = sline,
   PROCEDURE  = sline_contains_point_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (spoint, sline) IS 'true if spherical point (LHS) is contained by spherical line (RHS)';

CREATE OPERATOR @> (
   LEFTARG    = sline,
   RIGHTARG   = spoint,
   PROCEDURE  = sline_contains_point,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (sline, spoint) IS 'true if spherical line (LHS) contains the spherical point (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = sline,
   RIGHTARG   = spoint,
   PROCEDURE  = sline_contains_point_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (sline, spoint) IS 'true if spherical line (LHS) does not contain spherical point (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = spoint,
   RIGHTARG   = sline,
   PROCEDURE  = sline_contains_point_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (spoint, sline) IS 'true if spherical point (LHS) is not contained by spherical line (RHS)';

CREATE OPERATOR @> (
   LEFTARG    = scircle,
   RIGHTARG   = sline,
   PROCEDURE  = scircle_contains_line,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (scircle, sline) IS 'true if spherical circle (LHS) contains spherical line (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = sline,
   RIGHTARG   = scircle,
   PROCEDURE  = scircle_contains_line_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (sline, scircle) IS 'true if spherical line (LHS) is contained by spherical circle (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = scircle,
   RIGHTARG   = sline,
   PROCEDURE  = scircle_contains_line_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (scircle, sline) IS 'true if spherical circle (LHS) does not contain spherical line (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = sline,
   RIGHTARG   = scircle,
   PROCEDURE  = scircle_contains_line_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (sline, scircle) IS 'true if spherical line (LHS) is not contained by spherical circle (RHS)';

CREATE OPERATOR @> (
   LEFTARG    = spoly,
   RIGHTARG   = sline,
   PROCEDURE  = spoly_contains_line,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (spoly, sline) IS 'true if spherical polygon (LHS) contains spherical line (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = sline,
   RIGHTARG   = spoly,
   PROCEDURE  = spoly_contains_line_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (sline, spoly) IS 'true if spherical line (LHS) is contained by spherical polygon (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = spoly,
   RIGHTARG   = sline,
   PROCEDURE  = spoly_contains_line,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (spoly, sline) IS 'true if spherical polygon (LHS) does not contain spherical line (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = sline,
   RIGHTARG   = spoly,
   PROCEDURE  = spoly_contains_line_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (sline, spoly) IS 'true if spherical line (LHS) is not contained by spherical polygon (RHS)';



CREATE OPERATOR @> (
   LEFTARG    = sellipse,
   RIGHTARG   = sellipse,
   PROCEDURE  = sellipse_contains_ellipse,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (sellipse, sellipse) IS 'true if spherical ellipse (LHS) contains spherical ellipse (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = sellipse,
   RIGHTARG   = sellipse,
   PROCEDURE  = sellipse_contains_ellipse_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (sellipse, sellipse) IS 'true if spherical ellipse (LHS) is contained by spherical ellipse (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = sellipse,
   RIGHTARG   = sellipse,
   PROCEDURE  = sellipse_contains_ellipse_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (sellipse, sellipse) IS 'true if spherical ellipse (LHS) does not contain spherical ellipse (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = sellipse,
   RIGHTARG   = sellipse,
   PROCEDURE  = sellipse_contains_ellipse_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (sellipse, sellipse) IS 'true if spherical ellipse (LHS) is not contained by spherical ellipse (RHS)';


CREATE OPERATOR @> (
   LEFTARG    = sellipse,
   RIGHTARG   = spoint,
   PROCEDURE  = sellipse_contains_point,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (sellipse, spoint) IS 'true if spherical ellipse (LHS) contains spherical point (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = spoint,
   RIGHTARG   = sellipse,
   PROCEDURE  = sellipse_contains_point_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (spoint, sellipse) IS 'true if spherical point (LHS) is contained by spherical ellipse (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = sellipse,
   RIGHTARG   = spoint,
   PROCEDURE  = sellipse_contains_point_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (sellipse, spoint) IS 'true if spherical ellipse (LHS) does not contain spherical point (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = spoint,
   RIGHTARG   = sellipse,
   PROCEDURE  = sellipse_contains_point_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (spoint, sellipse) IS 'true if spherical point (LHS) is not contained by spherical ellipse (RHS)';

CREATE OPERATOR @> (
   LEFTARG    = sbox,
   RIGHTARG   = sellipse,
   PROCEDURE  = sbox_contains_ellipse,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (sbox, sellipse) IS 'true if spherical box (LHS) contains spherical ellipse (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = sellipse,
   RIGHTARG   = sbox,
   PROCEDURE  = sbox_contains_ellipse_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (sellipse, sbox) IS
  'true if spherical ellipse (LHS) is contained by spherical box (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = sbox,
   RIGHTARG   = sellipse,
   PROCEDURE  = sbox_contains_ellipse_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (sbox, sellipse) IS 'true if spherical box (LHS) does not contain spherical ellipse (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = sellipse,
   RIGHTARG   = sbox,
   PROCEDURE  = sbox_contains_ellipse_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (sellipse, sbox) IS 'true if spherical ellipse (LHS) is not contained by spherical box (RHS)';

CREATE OPERATOR @> (
   LEFTARG    = sellipse,
   RIGHTARG   = sbox,
   PROCEDURE  = sellipse_contains_box,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (sellipse, sbox) IS 'true if spherical ellipse (LHS) contains spherical box (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = sbox,
   RIGHTARG   = sellipse,
   PROCEDURE  = sellipse_contains_box_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (sbox, sellipse) IS 'true if spherical box (LHS) is contained by spherical ellipse (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = sellipse,
   RIGHTARG   = sbox,
   PROCEDURE  = sellipse_contains_box_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (sellipse, sbox) IS 'true if spherical ellipse (LHS) does not contain spherical box (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = sbox,
   RIGHTARG   = sellipse,
   PROCEDURE  = sellipse_contains_box_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (sbox, sellipse) IS 'true if spherical box (LHS) is not containe by spherical ellipse (RHS)';

CREATE OPERATOR @> (
   LEFTARG    = sellipse,
   RIGHTARG   = scircle,
   PROCEDURE  = sellipse_contains_circle,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (sellipse, scircle) IS 'true if spherical ellipse (LHS) contains spherical circle (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = scircle,
   RIGHTARG   = sellipse,
   PROCEDURE  = sellipse_contains_circle_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (scircle, sellipse) IS 'true if spherical circle (LHS) is contained by spherical ellipse (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = sellipse,
   RIGHTARG   = scircle,
   PROCEDURE  = sellipse_contains_circle_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (sellipse, scircle) IS 'true if spherical ellipse (LHS) does not contain spherical circle (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = scircle,
   RIGHTARG   = sellipse,
   PROCEDURE  = sellipse_contains_circle_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (scircle, sellipse) IS 'true if spherical circle (LHS) is not contained by spherical ellipse (RHS)';

CREATE OPERATOR @> (
   LEFTARG    = scircle,
   RIGHTARG   = sellipse,
   PROCEDURE  = scircle_contains_ellipse,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (scircle, sellipse) IS 'true if spherical circle (LHS) contains spherical ellipse (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = sellipse,
   RIGHTARG   = scircle,
   PROCEDURE  = scircle_contains_ellipse_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (sellipse, scircle) IS 'true if spherical ellipse (LHS) is contained by spherical circle (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = scircle,
   RIGHTARG   = sellipse,
   PROCEDURE  = scircle_contains_ellipse_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (scircle, sellipse) IS 'true if spherical circle (LHS) does not contain spherical ellipse (RHS)';


CREATE OPERATOR !<@ (
   LEFTARG    = sellipse,
   RIGHTARG   = scircle,
   PROCEDURE  = scircle_contains_ellipse_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (sellipse, scircle) IS 'true if spherical ellipse (LHS) is not contained by spherical circle (RHS)';


CREATE OPERATOR @> (
   LEFTARG    = sellipse,
   RIGHTARG   = sline,
   PROCEDURE  = sellipse_contains_line,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (sellipse, sline) IS 'true if spherical ellipse (LHS) contains spherical line (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = sline,
   RIGHTARG   = sellipse,
   PROCEDURE  = sellipse_contains_line_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (sline, sellipse) IS 'true if spherical line is contained by spherical ellipse';

CREATE OPERATOR !@> (
   LEFTARG    = sellipse,
   RIGHTARG   = sline,
   PROCEDURE  = sellipse_contains_line_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (sellipse, sline) IS 'true if spherical ellipse (LHS) does not contain spherical line (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = sline,
   RIGHTARG   = sellipse,
   PROCEDURE  = sellipse_contains_line_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (sline, sellipse) IS 'true if spherical line (LHS) is not contained by spherical line (RHS)';


CREATE OPERATOR @> (
   LEFTARG    = spoly,
   RIGHTARG   = sellipse,
   PROCEDURE  = spoly_contains_ellipse,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (spoly, sellipse) IS 'true if spherical polygon (LHS) contains spherical ellipse (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = sellipse,
   RIGHTARG   = spoly,
   PROCEDURE  = spoly_contains_ellipse_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (sellipse, spoly) IS 'true if spherical ellipse (LHS) is contained by spherical polygon (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = spoly,
   RIGHTARG   = sellipse,
   PROCEDURE  = spoly_contains_ellipse_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (spoly, sellipse) IS 'true if spherical polygon (LHS) does not contain spherical ellipse (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = sellipse,
   RIGHTARG   = spoly,
   PROCEDURE  = spoly_contains_ellipse_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (sellipse, spoly) IS 'true if spherical ellipse (LHS) is not contained by spherical polygon (RHS)';

CREATE OPERATOR @> (
   LEFTARG    = sellipse,
   RIGHTARG   = spoly,
   PROCEDURE  = sellipse_contains_polygon,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (sellipse, spoly) IS 'true if spherical ellipse (LHS) contains spherical polygon (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = spoly,
   RIGHTARG   = sellipse,
   PROCEDURE  = sellipse_contains_polygon_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (spoly, sellipse) IS 'true if spherical polygon (LHS) is contained by spherical ellipse (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = sellipse,
   RIGHTARG   = spoly,
   PROCEDURE  = sellipse_contains_polygon_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (sellipse, spoly) IS 'true if spherical ellipse (LHS) does not contain spherical polygon (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = spoly,
   RIGHTARG   = sellipse,
   PROCEDURE  = sellipse_contains_polygon_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (spoly, sellipse) IS 'true if spherical polygon (LHS) is not contained by spherical ellipse (RHS)';

CREATE OPERATOR @> (
   LEFTARG    = spath,
   RIGHTARG   = spoint,
   PROCEDURE  = spath_contains_point,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (spath, spoint) IS 'true if spherical path (LHS) contains spherical point (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = spoint,
   RIGHTARG   = spath,
   PROCEDURE  = spath_contains_point_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (spoint, spath) IS 'true if spherical point (LHS) is contained by spherical path (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = spath,
   RIGHTARG   = spoint,
   PROCEDURE  = spath_contains_point_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (spath, spoint) IS 'true if spherical path (LHS) does not contain spherical point (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = spoint,
   RIGHTARG   = spath,
   PROCEDURE  = spath_contains_point_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (spoint, spath) IS 'true if spherical point (LHS) is not contained by spherical path (RHS)';

CREATE OPERATOR @> (
   LEFTARG    = sbox,
   RIGHTARG   = spath,
   PROCEDURE  = sbox_contains_path,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (sbox, spath) IS 'true if spherical box (LHS) contains spherical path (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = spath,
   RIGHTARG   = sbox,
   PROCEDURE  = sbox_contains_path_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (spath, sbox) IS 'true if spherical path is contained by spherical box (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = sbox,
   RIGHTARG   = spath,
   PROCEDURE  = sbox_contains_path_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (sbox, spath) IS 'true if spherical box (LHS) does not contain spherical path (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = spath,
   RIGHTARG   = sbox,
   PROCEDURE  = sbox_contains_path_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (spath, sbox) IS
  'true if spherical path (LHS) is not contained by spherical box (RHS)';

CREATE OPERATOR @> (
   LEFTARG    = scircle,
   RIGHTARG   = spath,
   PROCEDURE  = scircle_contains_path,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (scircle, spath) IS 'true if spherical circle (LHS) contains spherical path (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = spath,
   RIGHTARG   = scircle,
   PROCEDURE  = scircle_contains_path_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (spath, scircle) IS 'true if spherical path (LHS) is contained by spherical circle (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = scircle,
   RIGHTARG   = spath,
   PROCEDURE  = scircle_contains_path_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (scircle, spath) IS 'true if spherical circle (LHS) does not contain spherical path (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = spath,
   RIGHTARG   = scircle,
   PROCEDURE  = scircle_contains_path_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (spath, scircle) IS 'true if spherical path (LHS) is not contained by spherical circle (RHS)';

CREATE OPERATOR @> (
   LEFTARG    = sellipse,
   RIGHTARG   = spath,
   PROCEDURE  = sellipse_contains_path,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (sellipse, spath) IS 'true if spherical ellipse (LHS) contains spherical path (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = spath,
   RIGHTARG   = sellipse,
   PROCEDURE  = sellipse_contains_path_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (spath, sellipse) IS 'true if spherical path (LHS) is contained by spherical ellipse (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = sellipse,
   RIGHTARG   = spath,
   PROCEDURE  = sellipse_contains_path_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (sellipse, spath) IS 'true if spherical ellipse (LHS) does not contain spherical path (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = spath,
   RIGHTARG   = sellipse,
   PROCEDURE  = sellipse_contains_path_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (spath, sellipse) IS 'true if spherical path is not contained by spherical ellipse (RHS)';

CREATE OPERATOR @> (
   LEFTARG    = spoly,
   RIGHTARG   = spath,
   PROCEDURE  = spoly_contains_path,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (spoly, spath) IS 'true if spherical polygon (LHS) contains spherical path (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = spath,
   RIGHTARG   = spoly,
   PROCEDURE  = spoly_contains_path_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (spath, spoly) IS 'true if spherical path (LHS) is contained by spherical polygon (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = spoly,
   RIGHTARG   = spath,
   PROCEDURE  = spoly_contains_path_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (spoly, spath) IS 'true if spherical polygon (LHS) does not contain spherical path (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = spath,
   RIGHTARG   = spoly,
   PROCEDURE  = spoly_contains_path_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (spath, spoly) IS 'true if spherical path (LHS) is not contained by spherical polygon (RHS)';

CREATE OPERATOR @> (
   LEFTARG    = sbox,
   RIGHTARG   = sline,
   PROCEDURE  = sbox_contains_line,
   COMMUTATOR = '<@',
   NEGATOR    = '!@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR @> (sbox, sline) IS 'true if spherical box (LHS) contains spherical line (RHS)';

CREATE OPERATOR <@ (
   LEFTARG    = sline,
   RIGHTARG   = sbox,
   PROCEDURE  = sbox_contains_line_com,
   COMMUTATOR = '@>',
   NEGATOR    = '!<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR <@ (sline, sbox) IS 'true if spherical line (LHS) is contained by spherical box (RHS)';

CREATE OPERATOR !@> (
   LEFTARG    = sbox,
   RIGHTARG   = sline,
   PROCEDURE  = sbox_contains_line_neg,
   COMMUTATOR = '!<@',
   NEGATOR    = '@>',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !@> (sbox, sline) IS 'true if spherical box (LHS) does not contain spherical line (RHS)';

CREATE OPERATOR !<@ (
   LEFTARG    = sline,
   RIGHTARG   = sbox,
   PROCEDURE  = sbox_contains_line_com_neg,
   COMMUTATOR = '!@>',
   NEGATOR    = '<@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);

COMMENT ON OPERATOR !<@ (sline, sbox) IS 'true if spherical line (LHS) is not contained by spherical box (RHS)';
-- gnomonic projection and its inverse

CREATE OR REPLACE FUNCTION gnomonic_proj(spoint, spoint)
RETURNS point
AS 'MODULE_PATHNAME'
LANGUAGE C IMMUTABLE STRICT;

COMMENT ON FUNCTION gnomonic_proj(spoint, spoint) IS
'gnomonic projection, the second argument is the tangential point';

CREATE OR REPLACE FUNCTION gnomonic_inv(point, spoint)
RETURNS spoint
AS 'MODULE_PATHNAME'
LANGUAGE C IMMUTABLE STRICT;

COMMENT ON FUNCTION gnomonic_inv(point, spoint) IS
'inverse of gnomonic projection, the second argument is the tangential point';
CREATE FUNCTION pointkey_in(CSTRING)
   RETURNS pointkey
   AS 'MODULE_PATHNAME', 'pointkey_in'
   LANGUAGE 'c'
   IMMUTABLE STRICT;


CREATE FUNCTION pointkey_out(pointkey)
   RETURNS CSTRING
   AS 'MODULE_PATHNAME', 'pointkey_out'
   LANGUAGE 'c'
   IMMUTABLE STRICT;

CREATE FUNCTION pointkey_volume(pointkey)
   RETURNS float8
   AS 'MODULE_PATHNAME', 'pointkey_volume'
   LANGUAGE 'c'
   IMMUTABLE STRICT;

CREATE FUNCTION pointkey_area(pointkey)
   RETURNS float8
   AS 'MODULE_PATHNAME', 'pointkey_area'
   LANGUAGE 'c'
   IMMUTABLE STRICT;

CREATE FUNCTION pointkey_perimeter(pointkey)
   RETURNS float8
   AS 'MODULE_PATHNAME', 'pointkey_perimeter'
   LANGUAGE 'c'
   IMMUTABLE STRICT;

CREATE TYPE pointkey (
   input = pointkey_in,
   output = pointkey_out,
   internallength = VARIABLE,
   ALIGNMENT = double,
   STORAGE = PLAIN
);
-- conversions to / from Healpix indexing

CREATE OR REPLACE FUNCTION nest2ring(integer, bigint)
RETURNS bigint
AS 'MODULE_PATHNAME', 'pg_nest2ring'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION nest2ring(integer, bigint) IS
'converts nested Healpix index to a ring Healpix index for the specified integer level (first argument)';

CREATE OR REPLACE FUNCTION ring2nest(integer, bigint)
RETURNS bigint
AS 'MODULE_PATHNAME', 'pg_ring2nest'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION ring2nest(integer, bigint) IS
'converts ringe Healpix index to a nested Healpix index for the specified integer level (first argument)';

CREATE OR REPLACE FUNCTION healpix_convert_nest(integer, integer, bigint)
RETURNS bigint
AS 'MODULE_PATHNAME'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION healpix_convert_nest(integer, integer, bigint) IS
'converts nested Healpix index (last argument) from level of second argument to level of first argument';

CREATE OR REPLACE FUNCTION healpix_convert_ring(integer, integer, bigint)
RETURNS bigint
AS 'MODULE_PATHNAME'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION healpix_convert_ring(integer, integer, bigint) IS
'converts ring Healpix index (last argument) from level of second argument to level of first argument';

CREATE OR REPLACE FUNCTION nside2order(bigint)
RETURNS integer
AS 'MODULE_PATHNAME', 'pg_nside2order'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION nside2order(bigint) IS
'returns integer part of base-two logarithm of argument for powers of two up to 29';

CREATE OR REPLACE FUNCTION order2nside(integer)
RETURNS bigint
AS 'MODULE_PATHNAME', 'pg_order2nside'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION order2nside(integer) IS
'returns power of two for non-negative values up to 29';

CREATE OR REPLACE FUNCTION nside2npix(bigint)
RETURNS bigint
AS 'MODULE_PATHNAME', 'pg_nside2npix'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION nside2npix(bigint) IS
'returns 12 * nside ^ 2, the number of Healpix elements for the nside parameter';

CREATE OR REPLACE FUNCTION npix2nside(bigint)
RETURNS bigint
AS 'MODULE_PATHNAME', 'pg_npix2nside'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION npix2nside(bigint) IS
'returns the nside parameter correspondig to the number of Healpix elements';

CREATE OR REPLACE FUNCTION healpix_nest(integer, spoint)
RETURNS bigint
AS 'MODULE_PATHNAME'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION healpix_nest(integer, spoint) IS
'nested Healpix index of a spherical point for the specified integer level (first argument)';

CREATE OR REPLACE FUNCTION healpix_ring(integer, spoint)
RETURNS bigint
AS 'MODULE_PATHNAME'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION healpix_ring(integer, spoint) IS
'Healpix ring index of a spherical point for the specified integer level (first argument)';

CREATE OR REPLACE FUNCTION centre_of_healpix_nest(integer, bigint)
RETURNS spoint
AS 'MODULE_PATHNAME', 'inv_healpix_nest'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION centre_of_healpix_nest(integer, bigint) IS
'spherical point designating the centre of a nested Healpix element for the specified integer level (first argument)';

CREATE OR REPLACE FUNCTION centre_of_healpix_ring(integer, bigint)
RETURNS spoint
AS 'MODULE_PATHNAME', 'inv_healpix_ring'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION centre_of_healpix_ring(integer, bigint) IS
'spherical point designating the centre of a ring Healpix element for the specified integer level (first argument)';

CREATE OR REPLACE FUNCTION center_of_healpix_nest(integer, bigint)
RETURNS spoint
AS 'MODULE_PATHNAME', 'inv_healpix_nest'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION center_of_healpix_nest(integer, bigint) IS
'spherical point designating the center of a nested Healpix element for the specified integer level (first argument)';

CREATE OR REPLACE FUNCTION center_of_healpix_ring(integer, bigint)
RETURNS spoint
AS 'MODULE_PATHNAME', 'inv_healpix_ring'
LANGUAGE C IMMUTABLE STRICT;
COMMENT ON FUNCTION center_of_healpix_ring(integer, bigint) IS
'spherical point designating the center of a ring Healpix element for the specified integer level (first argument)';
ALTER EXTENSION pg_sphere ADD FUNCTION spoint_in(CSTRING);
ALTER EXTENSION pg_sphere ADD FUNCTION spoint_out(spoint);
ALTER EXTENSION pg_sphere ADD TYPE spoint;
ALTER EXTENSION pg_sphere ADD FUNCTION strans_in(CSTRING);
ALTER EXTENSION pg_sphere ADD FUNCTION strans_out(strans);
ALTER EXTENSION pg_sphere ADD TYPE strans;
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_in(CSTRING);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_out(scircle);
ALTER EXTENSION pg_sphere ADD TYPE scircle;
ALTER EXTENSION pg_sphere ADD FUNCTION sline_in(CSTRING);
ALTER EXTENSION pg_sphere ADD FUNCTION sline_out(sline);
ALTER EXTENSION pg_sphere ADD TYPE sline;
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_in(CSTRING);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_out(sellipse);
ALTER EXTENSION pg_sphere ADD TYPE sellipse;
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_in(CSTRING);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_out(spoly);
ALTER EXTENSION pg_sphere ADD TYPE spoly;
ALTER EXTENSION pg_sphere ADD FUNCTION spath_in(CSTRING);
ALTER EXTENSION pg_sphere ADD FUNCTION spath_out(spath);
ALTER EXTENSION pg_sphere ADD TYPE spath;
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_in(CSTRING);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_out(sbox);
ALTER EXTENSION pg_sphere ADD TYPE sbox;
ALTER EXTENSION pg_sphere ADD FUNCTION spoint(FLOAT8, FLOAT8);
ALTER EXTENSION pg_sphere ADD FUNCTION set_sphere_output_precision(INT4);
ALTER EXTENSION pg_sphere ADD FUNCTION set_sphere_output(CSTRING);
ALTER EXTENSION pg_sphere ADD FUNCTION long(spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION lat(spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION x(spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION y(spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION xyz(spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION z(spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION spoint_equal(spoint, spoint);
ALTER EXTENSION pg_sphere ADD OPERATOR =(spoint, spoint);
ALTER EXTENSION pg_sphere ADD OPERATOR <>(spoint, spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION dist(spoint, spoint);
ALTER EXTENSION pg_sphere ADD OPERATOR <->(spoint, spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION strans_zxz(strans);
ALTER EXTENSION pg_sphere ADD FUNCTION strans(FLOAT8, FLOAT8, FLOAT8);
ALTER EXTENSION pg_sphere ADD FUNCTION strans(FLOAT8, FLOAT8, FLOAT8, CSTRING);
ALTER EXTENSION pg_sphere ADD FUNCTION phi(strans);
ALTER EXTENSION pg_sphere ADD FUNCTION theta(strans);
ALTER EXTENSION pg_sphere ADD FUNCTION psi(strans);
ALTER EXTENSION pg_sphere ADD FUNCTION axes(strans);
ALTER EXTENSION pg_sphere ADD FUNCTION strans_equal(strans, strans);
ALTER EXTENSION pg_sphere ADD OPERATOR =(strans, strans);
ALTER EXTENSION pg_sphere ADD FUNCTION strans_not_equal(strans, strans);
ALTER EXTENSION pg_sphere ADD OPERATOR <>(strans, strans);
ALTER EXTENSION pg_sphere ADD FUNCTION strans(strans);
ALTER EXTENSION pg_sphere ADD OPERATOR +(NONE, strans);
ALTER EXTENSION pg_sphere ADD FUNCTION strans_invert(strans);
ALTER EXTENSION pg_sphere ADD OPERATOR -(NONE, strans);
ALTER EXTENSION pg_sphere ADD FUNCTION strans_point(spoint, strans);
ALTER EXTENSION pg_sphere ADD OPERATOR +(spoint, strans);
ALTER EXTENSION pg_sphere ADD FUNCTION strans_point_inverse(spoint, strans);
ALTER EXTENSION pg_sphere ADD OPERATOR -(spoint, strans);
ALTER EXTENSION pg_sphere ADD FUNCTION strans_trans(strans, strans);
ALTER EXTENSION pg_sphere ADD OPERATOR +(strans, strans);
ALTER EXTENSION pg_sphere ADD FUNCTION strans_trans_inv(strans, strans);
ALTER EXTENSION pg_sphere ADD OPERATOR -(strans, strans);
ALTER EXTENSION pg_sphere ADD FUNCTION area(scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION radius(scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle(spoint, float8);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle(spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_equal(scircle, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR =(scircle, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_equal_neg(scircle, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR <>(scircle, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_overlap(scircle, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(scircle, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_overlap_neg(scircle, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(scircle, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION center(scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR @@(NONE, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION circum(scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR @-@(NONE, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_contained_by_circle(scircle, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION spoint_contained_by_circle(spoint, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION spoint_contained_by_circle_neg(spoint, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION spoint_contained_by_circle_com(scircle, spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION spoint_contained_by_circle_com_neg(scircle, spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION dist(scircle, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR <->(scircle, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION dist(scircle, spoint);
ALTER EXTENSION pg_sphere ADD OPERATOR <->(scircle, spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION dist(spoint, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR <->(spoint, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION strans_circle(scircle, strans);
ALTER EXTENSION pg_sphere ADD OPERATOR +(scircle, strans);
ALTER EXTENSION pg_sphere ADD FUNCTION strans_circle_inverse(scircle, strans);
ALTER EXTENSION pg_sphere ADD OPERATOR -(scircle, strans);
ALTER EXTENSION pg_sphere ADD FUNCTION sline(spoint, spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION sline(strans, float8);
ALTER EXTENSION pg_sphere ADD FUNCTION meridian(float8);
ALTER EXTENSION pg_sphere ADD FUNCTION sl_beg(sline);
ALTER EXTENSION pg_sphere ADD FUNCTION sl_end(sline);
ALTER EXTENSION pg_sphere ADD FUNCTION strans(sline);
ALTER EXTENSION pg_sphere ADD FUNCTION sline(spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION sline_equal(sline, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR =(sline, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION sline_equal_neg(sline, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR <>(sline, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION length(sline);
ALTER EXTENSION pg_sphere ADD OPERATOR @-@(NONE, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION swap(sline);
ALTER EXTENSION pg_sphere ADD OPERATOR -(NONE, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION turn(sline);
ALTER EXTENSION pg_sphere ADD OPERATOR !(NONE, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION sline_crosses(sline, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR #(sline, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION sline_crosses_neg(sline, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR !#(sline, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION sline_overlap(sline, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(sline, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION sline_overlap_neg(sline, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(sline, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION strans_line(sline, strans);
ALTER EXTENSION pg_sphere ADD OPERATOR +(sline, strans);
ALTER EXTENSION pg_sphere ADD FUNCTION strans_line_inverse(sline, strans);
ALTER EXTENSION pg_sphere ADD OPERATOR -(sline, strans);
ALTER EXTENSION pg_sphere ADD FUNCTION sline_overlap_circle(sline, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(sline, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION sline_overlap_circle_com(scircle, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(scircle, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION sline_overlap_circle_neg(sline, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(sline, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION sline_overlap_circle_com_neg(scircle, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(scircle, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_contains_line(scircle, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_contains_line_com(sline, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_contains_line_neg(scircle, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_contains_line_com_neg(sline, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse(spoint, float8, float8, float8);
ALTER EXTENSION pg_sphere ADD FUNCTION inc(sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION lrad(sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION srad(sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse(spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle(sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse(scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION strans(sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION center(sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR @@(NONE, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_equal(sellipse, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR =(sellipse, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_equal_neg(sellipse, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR <>(sellipse, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_ellipse(sellipse, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_ellipse_com(sellipse, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_ellipse_neg(sellipse, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_ellipse_com_neg(sellipse, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_overlap_ellipse(sellipse, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(sellipse, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_overlap_ellipse_neg(sellipse, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(sellipse, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_point(sellipse, spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_point_com(spoint, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_point_neg(sellipse, spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_point_com_neg(spoint, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION strans_ellipse(sellipse, strans);
ALTER EXTENSION pg_sphere ADD OPERATOR +(sellipse, strans);
ALTER EXTENSION pg_sphere ADD OPERATOR -(sellipse, strans);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_circle(sellipse, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_circle_com(scircle, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_circle_neg(sellipse, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_circle_com_neg(scircle, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_contains_ellipse(scircle, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_contains_ellipse_com(sellipse, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_contains_ellipse_neg(scircle, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_contains_ellipse_com_neg(sellipse, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_overlap_circle(sellipse, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(sellipse, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_overlap_circle_com(scircle, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(scircle, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_overlap_circle_neg(sellipse, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(sellipse, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_overlap_circle_com_neg(scircle, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(scircle, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(sellipse, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_overlap_line_com(sline, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(sline, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(sellipse, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_overlap_line_com_neg(sline, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(sline, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_line(sellipse, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_line_com(sline, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_line_neg(sellipse, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_line_com_neg(sline, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION npoints(spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION area(spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_equal(spoly, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR =(spoly, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_not_equal(spoly, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR <>(spoly, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION circum(spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR @-@(NONE, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_polygon(spoly, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_polygon_com(spoly, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_polygon_neg(spoly, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_polygon_com_neg(spoly, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_overlap_polygon(spoly, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(spoly, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_overlap_polygon_neg(spoly, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(spoly, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_point(spoly, spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_point_com(spoint, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_point_neg(spoly, spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_point_com_neg(spoint, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION strans_poly(spoly, strans);
ALTER EXTENSION pg_sphere ADD OPERATOR +(spoly, strans);
ALTER EXTENSION pg_sphere ADD FUNCTION strans_poly_inverse(spoly, strans);
ALTER EXTENSION pg_sphere ADD OPERATOR -(spoly, strans);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_circle(spoly, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_circle_com(scircle, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_circle_neg(spoly, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_circle_com_neg(scircle, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_contains_polygon(scircle, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_contains_polygon_com(spoly, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_contains_polygon_neg(scircle, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_contains_polygon_com_neg(spoly, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_overlap_circle(spoly, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(spoly, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_overlap_circle_com(scircle, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(scircle, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_overlap_circle_neg(spoly, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(spoly, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_overlap_circle_com_neg(scircle, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(scircle, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_line(spoly, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_line_com(sline, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_line_neg(spoly, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_line_com_neg(sline, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_overlap_line(spoly, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(spoly, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_overlap_line_com(sline, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(sline, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_overlap_line_neg(spoly, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(spoly, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_overlap_line_com_neg(sline, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(sline, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_ellipse(spoly, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_ellipse_com(sellipse, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_ellipse_neg(spoly, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_ellipse_com_neg(sellipse, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_polygon(sellipse, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_polygon_com(spoly, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_polygon_neg(sellipse, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_polygon_com_neg(spoly, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_overlap_ellipse(spoly, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(spoly, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_overlap_ellipse_com(sellipse, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(sellipse, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_overlap_ellipse_neg(spoly, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(spoly, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_overlap_ellipse_com_neg(sellipse, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(sellipse, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION npoints(spath);
ALTER EXTENSION pg_sphere ADD FUNCTION spoint(spath, int4);
ALTER EXTENSION pg_sphere ADD FUNCTION spoint(spath, float8);
ALTER EXTENSION pg_sphere ADD FUNCTION spath_equal(spath, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR =(spath, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION spath_equal_neg(spath, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR <>(spath, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION length(spath);
ALTER EXTENSION pg_sphere ADD OPERATOR @-@(NONE, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION swap(spath);
ALTER EXTENSION pg_sphere ADD OPERATOR -(NONE, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION spath_overlap_path(spath, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(spath, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION spath_overlap_path_neg(spath, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(spath, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION spath_contains_point(spath, spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION spath_contains_point_com(spoint, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION spath_contains_point_neg(spath, spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION spath_contains_point_com_neg(spoint, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION strans_path(spath, strans);
ALTER EXTENSION pg_sphere ADD OPERATOR +(spath, strans);
ALTER EXTENSION pg_sphere ADD FUNCTION strans_path_inverse(spath, strans);
ALTER EXTENSION pg_sphere ADD OPERATOR -(spath, strans);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_contains_path(scircle, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_contains_path_com(spath, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_contains_path_neg(scircle, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_contains_path_com_neg(spath, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_overlap_path(scircle, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(scircle, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_overlap_path_com(spath, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(spath, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_overlap_path_neg(scircle, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(scircle, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_overlap_path_com_neg(spath, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(spath, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION spath_overlap_line(spath, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(spath, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION spath_overlap_line_com(sline, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(sline, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION spath_overlap_line_neg(spath, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(spath, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION spath_overlap_line_com_neg(sline, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(sline, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_path(sellipse, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_path_com(spath, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_path_neg(sellipse, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_path_com_neg(spath, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_overlap_path(sellipse, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(sellipse, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_overlap_path_com(spath, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(spath, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_overlap_path_neg(sellipse, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(sellipse, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_overlap_path_com_neg(spath, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(spath, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_path(spoly, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_path_com(spath, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_path_neg(spoly, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_path_com_neg(spath, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_overlap_path(spoly, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(spoly, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_overlap_path_com(spath, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(spath, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_overlap_path_neg(spoly, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(spoly, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_overlap_path_com_neg(spath, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(spath, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox(spoint, spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION sw(sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION se(sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION nw(sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION ne(sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION area(sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION circum(sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR @-@(NONE, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_equal(sbox, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR =(sbox, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR <>(sbox, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_box(sbox, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_box_com(sbox, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_box_neg(sbox, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_box_com_neg(sbox, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_box(sbox, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(sbox, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_box_neg(sbox, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(sbox, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_cont_point_com(spoint, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_cont_point_com_neg(spoint, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_cont_point(sbox, spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_cont_point_neg(sbox, spoint);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_circle(sbox, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_circle_com(scircle, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_circle_neg(sbox, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_circle_com_neg(scircle, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_contains_box(scircle, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_contains_box_com(sbox, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_contains_box_neg(scircle, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION scircle_contains_box_com_neg(sbox, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_circle(sbox, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(sbox, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_circle_com(scircle, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(scircle, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_circle_neg(sbox, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(sbox, scircle);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_circle_com_neg(scircle, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(scircle, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_line(sbox, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_line_com(sline, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_line_neg(sbox, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_line_com_neg(sline, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_line(sbox, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(sbox, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_line_com(sline, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(sline, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_line_neg(sbox, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(sbox, sline);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_line_com_neg(sline, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(sline, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_ellipse(sbox, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_ellipse_com(sellipse, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_ellipse_neg(sbox, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_ellipse_com_neg(sellipse, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_box(sellipse, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_box_com(sbox, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_box_neg(sellipse, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sellipse_contains_box_com_neg(sbox, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_ellipse(sbox, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(sbox, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_ellipse_com(sellipse, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(sellipse, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_ellipse_neg(sbox, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(sbox, sellipse);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_ellipse_com_neg(sellipse, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(sellipse, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_poly(sbox, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_poly_com(spoly, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_poly_neg(sbox, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_poly_com_neg(spoly, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_box(spoly, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_box_com(sbox, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_box_neg(spoly, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION spoly_contains_box_com_neg(sbox, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_poly(sbox, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(sbox, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_poly_com(spoly, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(spoly, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_poly_neg(sbox, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(sbox, spoly);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_poly_com_neg(spoly, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(spoly, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_path(sbox, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_path_com(spath, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_path_neg(sbox, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_contains_path_com_neg(spath, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_path(sbox, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(sbox, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_path_com(spath, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR &&(spath, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_path_neg(sbox, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(sbox, spath);
ALTER EXTENSION pg_sphere ADD FUNCTION sbox_overlap_path_com_neg(spath, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR !&&(spath, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(scircle, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR @(scircle, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(scircle, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(scircle, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(scircle, spoint);
ALTER EXTENSION pg_sphere ADD OPERATOR @(spoint, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(scircle, spoint);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(spoint, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(spoly, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR @(spoly, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(spoly, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(spoly, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(spoly, spoint);
ALTER EXTENSION pg_sphere ADD OPERATOR @(spoint, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(spoly, spoint);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(spoint, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(scircle, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR @(spoly, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(scircle, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(spoly, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(spoly, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR @(scircle, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(spoly, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(scircle, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(sbox, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR @(sbox, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(sbox, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(sbox, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(sbox, spoint);
ALTER EXTENSION pg_sphere ADD OPERATOR @(spoint, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(sbox, spoint);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(spoint, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(scircle, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR @(sbox, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(scircle, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(sbox, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(sbox, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR @(scircle, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(sbox, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(scircle, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(spoly, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR @(sbox, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(spoly, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(sbox, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(sbox, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR @(spoly, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(sbox, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(spoly, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR @(spoint, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(sline, spoint);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(sline, spoint);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(spoint, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(scircle, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR @(sline, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(scircle, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(sline, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(spoly, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR @(sline, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(spoly, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(sline, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(sellipse, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR @(sellipse, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(sellipse, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(sellipse, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(sellipse, spoint);
ALTER EXTENSION pg_sphere ADD OPERATOR @(spoint, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(sellipse, spoint);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(spoint, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(sbox, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR @(sellipse, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(sbox, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(sellipse, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(sellipse, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR @(sbox, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(sellipse, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(sbox, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(sellipse, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR @(scircle, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(sellipse, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(scircle, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(scircle, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR @(sellipse, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(scircle, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(sellipse, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(sellipse, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR @(sline, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(sellipse, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(sline, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(spoly, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR @(sellipse, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(spoly, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(sellipse, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(sellipse, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR @(spoly, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(sellipse, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(spoly, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(spath, spoint);
ALTER EXTENSION pg_sphere ADD OPERATOR @(spoint, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(spath, spoint);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(spoint, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(sbox, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR @(spath, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(sbox, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(spath, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(scircle, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR @(spath, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(scircle, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(spath, scircle);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(sellipse, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR @(spath, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(sellipse, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(spath, sellipse);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(spoly, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR @(spath, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(spoly, spath);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(spath, spoly);
ALTER EXTENSION pg_sphere ADD OPERATOR ~(sbox, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR @(sline, sbox);
ALTER EXTENSION pg_sphere ADD OPERATOR !~(sbox, sline);
ALTER EXTENSION pg_sphere ADD OPERATOR !@(sline, sbox);
ALTER EXTENSION pg_sphere ADD FUNCTION spherekey_in(CSTRING);
ALTER EXTENSION pg_sphere ADD FUNCTION spherekey_out(spherekey);
ALTER EXTENSION pg_sphere ADD TYPE spherekey;
ALTER EXTENSION pg_sphere ADD FUNCTION g_spherekey_decompress(internal);
ALTER EXTENSION pg_sphere ADD FUNCTION g_spherekey_union(bytea, internal);
ALTER EXTENSION pg_sphere ADD FUNCTION g_spherekey_picksplit(internal, internal);
ALTER EXTENSION pg_sphere ADD FUNCTION g_spoint_compress(internal);
ALTER EXTENSION pg_sphere ADD FUNCTION g_spoint_consistent(internal, internal, int4, oid, internal);
ALTER EXTENSION pg_sphere ADD OPERATOR CLASS spoint USING gist;
ALTER EXTENSION pg_sphere ADD FUNCTION g_scircle_compress(internal);
ALTER EXTENSION pg_sphere ADD FUNCTION g_scircle_consistent(internal, internal, int4, oid, internal);
ALTER EXTENSION pg_sphere ADD OPERATOR CLASS scircle USING gist;
ALTER EXTENSION pg_sphere ADD FUNCTION g_sline_compress(internal);
ALTER EXTENSION pg_sphere ADD FUNCTION g_sline_consistent(internal, internal, int4, oid, internal);
ALTER EXTENSION pg_sphere ADD OPERATOR CLASS sline USING gist;
ALTER EXTENSION pg_sphere ADD FUNCTION g_sellipse_compress(internal);
ALTER EXTENSION pg_sphere ADD FUNCTION g_sellipse_consistent(internal, internal, int4, oid, internal);
ALTER EXTENSION pg_sphere ADD OPERATOR CLASS sellipse USING gist;
ALTER EXTENSION pg_sphere ADD FUNCTION g_spoly_compress(internal);
ALTER EXTENSION pg_sphere ADD FUNCTION g_spoly_consistent(internal, internal, int4, oid, internal);
ALTER EXTENSION pg_sphere ADD OPERATOR CLASS spoly USING gist;
ALTER EXTENSION pg_sphere ADD FUNCTION g_spath_compress(internal);
ALTER EXTENSION pg_sphere ADD FUNCTION g_spath_consistent(internal, internal, int4, oid, internal);
ALTER EXTENSION pg_sphere ADD OPERATOR CLASS spath USING gist;
ALTER EXTENSION pg_sphere ADD FUNCTION g_sbox_compress(internal);
ALTER EXTENSION pg_sphere ADD FUNCTION g_sbox_consistent(internal, internal, int4, oid, internal);
ALTER EXTENSION pg_sphere ADD OPERATOR CLASS sbox USING gist;
ALTER OPERATOR FAMILY spoint USING gist ADD
	OPERATOR  37 <@ (spoint, scircle),
	OPERATOR  38 <@ (spoint, sline),
	OPERATOR  39 <@ (spoint, spath),
	OPERATOR  40 <@ (spoint, spoly),
	OPERATOR  41 <@ (spoint, sellipse),
	OPERATOR  42 <@ (spoint, sbox);

ALTER OPERATOR FAMILY scircle USING gist ADD
	OPERATOR  37 <@  (scircle, scircle),
	OPERATOR  38 <@  (scircle, spoly),
	OPERATOR  39 <@  (scircle, sellipse),
	OPERATOR  40 <@  (scircle, sbox),
	OPERATOR  43 @> (scircle, spoint),
	OPERATOR  44 @> (scircle, scircle),
	OPERATOR  45 @> (scircle, sline),
	OPERATOR  46 @> (scircle, spath),
	OPERATOR  47 @> (scircle, spoly),
	OPERATOR  48 @> (scircle, sellipse),
	OPERATOR  49 @> (scircle, sbox);

ALTER OPERATOR FAMILY sline USING gist ADD
	OPERATOR  37 <@  (sline, scircle),
	OPERATOR  38 <@  (sline, spoly),
	OPERATOR  39 <@  (sline, sellipse),
	OPERATOR  40 <@  (sline, sbox),
	OPERATOR  43 @> (sline, spoint);

ALTER OPERATOR FAMILY sellipse USING gist ADD
	OPERATOR  37 <@  (sellipse, scircle),
	OPERATOR  38 <@  (sellipse, spoly),
	OPERATOR  39 <@  (sellipse, sellipse),
	OPERATOR  40 <@  (sellipse, sbox),
	OPERATOR  43 @> (sellipse, spoint),
	OPERATOR  44 @> (sellipse, scircle),
	OPERATOR  45 @> (sellipse, sline),
	OPERATOR  46 @> (sellipse, spath),
	OPERATOR  47 @> (sellipse, spoly),
	OPERATOR  48 @> (sellipse, sellipse),
	OPERATOR  49 @> (sellipse, sbox);

ALTER OPERATOR FAMILY spoly USING gist ADD
	OPERATOR  37 <@  (spoly, scircle),
	OPERATOR  38 <@  (spoly, spoly),
	OPERATOR  39 <@  (spoly, sellipse),
	OPERATOR  40 <@  (spoly, sbox),
	OPERATOR  43 @> (spoly, spoint),
	OPERATOR  44 @> (spoly, scircle),
	OPERATOR  45 @> (spoly, sline),
	OPERATOR  46 @> (spoly, spath),
	OPERATOR  47 @> (spoly, spoly),
	OPERATOR  48 @> (spoly, sellipse),
	OPERATOR  49 @> (spoly, sbox);

ALTER OPERATOR FAMILY spath USING gist ADD
	OPERATOR  37 <@  (spath, scircle),
	OPERATOR  38 <@  (spath, spoly),
	OPERATOR  39 <@  (spath, sellipse),
	OPERATOR  40 <@  (spath, sbox),
	OPERATOR  43 @> (spath, spoint);

ALTER OPERATOR FAMILY sbox USING gist ADD
	OPERATOR  37 <@  (sbox, scircle),
	OPERATOR  38 <@  (sbox, spoly),
	OPERATOR  39 <@  (sbox, sellipse),
	OPERATOR  40 <@  (sbox, sbox),
	OPERATOR  43 @> (sbox, spoint),
	OPERATOR  44 @> (sbox, scircle),
	OPERATOR  45 @> (sbox, sline),
	OPERATOR  46 @> (sbox, spath),
	OPERATOR  47 @> (sbox, spoly),
	OPERATOR  48 @> (sbox, sellipse),
	OPERATOR  49 @> (sbox, sbox);
-- catch up with the operator definitions that were fixed by commit bcdef9dcd2a8406d384f0d2cedd3aa349fd63cf3

DROP OPERATOR !~ (sline, spoint) CASCADE;
DROP OPERATOR !@ (spoint, sline) CASCADE;
DROP OPERATOR !~ (spoly, spoint) CASCADE;

CREATE OPERATOR !~ (
   LEFTARG    = sline,
   RIGHTARG   = spoint,
   PROCEDURE  = sline_contains_point_neg,
   COMMUTATOR = '!@',
   NEGATOR    = '~',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);
COMMENT ON OPERATOR !~ (sline, spoint) IS 'true if spherical line (LHS) does not contain spherical point (RHS)';

CREATE OPERATOR !@ (
   LEFTARG    = spoint,
   RIGHTARG   = sline,
   PROCEDURE  = sline_contains_point_com_neg,
   COMMUTATOR = '!~',
   NEGATOR    = '@',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);
COMMENT ON OPERATOR !@ (spoint, sline) IS 'true if spherical point (LHS) is not contained by spherical line (RHS)';

CREATE OPERATOR !~ (
   LEFTARG    = spoly,
   RIGHTARG   = spoint,
   PROCEDURE  = spoly_contains_point_neg,
   COMMUTATOR = '!@',
   NEGATOR    = '~',
   RESTRICT   = contsel,
   JOIN       = contjoinsel
);
COMMENT ON OPERATOR !~ (spoly, spoint) IS 'true if spherical polygon (LHS) does not contain spherical point (RHS)';

