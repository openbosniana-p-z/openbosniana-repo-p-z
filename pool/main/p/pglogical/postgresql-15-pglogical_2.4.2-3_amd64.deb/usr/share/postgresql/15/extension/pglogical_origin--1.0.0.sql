\echo Use "CREATE EXTENSION pglogical_origin" to load this file. \quit
