DROP INDEX local_node_onlyone;
