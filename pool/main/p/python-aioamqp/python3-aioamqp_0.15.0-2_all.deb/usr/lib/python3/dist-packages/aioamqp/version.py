__version__ = '0.15.0'
__packagename__ = 'aioamqp'
