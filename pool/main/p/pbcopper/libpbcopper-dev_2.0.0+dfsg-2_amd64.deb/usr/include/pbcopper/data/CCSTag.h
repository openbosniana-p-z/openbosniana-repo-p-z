#ifndef PBCOPPER_DATA_CCSTAG_H
#define PBCOPPER_DATA_CCSTAG_H

#include <pbcopper/PbcopperConfig.h>

namespace PacBio {
namespace Data {

// used as a 'tag' for overloading methods
struct CCSTag
{
};

}  // namespace Data
}  // namespace PacBio

#endif  // PBCOPPER_DATA_CCSTAG_H
