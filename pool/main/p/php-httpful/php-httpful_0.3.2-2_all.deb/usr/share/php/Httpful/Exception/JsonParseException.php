<?php

namespace Httpful\Exception;

class JsonParseException extends \Exception
{
}