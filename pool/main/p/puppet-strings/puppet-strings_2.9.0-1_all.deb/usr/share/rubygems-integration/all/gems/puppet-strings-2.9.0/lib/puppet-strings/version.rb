# frozen_string_literal: true

module PuppetStrings
  VERSION = '2.9.0'
end
