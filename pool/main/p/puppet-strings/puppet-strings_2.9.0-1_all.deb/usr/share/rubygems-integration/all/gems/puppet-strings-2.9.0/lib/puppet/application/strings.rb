# frozen_string_literal: true

require 'puppet/application/face_base'

# Implements the 'puppet strings' application.
class Puppet::Application::Strings < Puppet::Application::FaceBase
end
