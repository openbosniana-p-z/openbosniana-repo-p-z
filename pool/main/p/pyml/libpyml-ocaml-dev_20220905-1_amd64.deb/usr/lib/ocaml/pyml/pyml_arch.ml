type t = Windows | Mac | Unix

let os = Unix




  external fd_of_int : int -> Unix.file_descr = "%identity"
