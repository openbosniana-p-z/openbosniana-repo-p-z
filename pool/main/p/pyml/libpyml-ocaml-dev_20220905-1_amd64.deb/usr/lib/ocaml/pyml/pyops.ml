let ( .@() ) = Py.Object.find_attr

let ( .@$() ) = Py.Object.find_attr_string

let ( .@()<- ) = Py.Object.set_attr

let ( .@$()<- ) = Py.Object.set_attr_string

let ( .![] ) = Py.Object.find

let ( .!$[] ) = Py.Object.find_string

let ( .![]<- ) = Py.Object.set_item

let ( .!$[]<- ) = Py.Object.set_item_string

let ( .%[] ) = Py.Dict.find

let ( .%$[] ) = Py.Dict.find_string

let ( .%[]<- ) = Py.Dict.set_item

let ( .%$[]<- ) = Py.Dict.set_item_string

let ( .&() ) = Py.Module.get_function

let ( .&()<- ) = Py.Module.set_function
