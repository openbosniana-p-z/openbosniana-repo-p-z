require 'puppet-openstack_spec_helper/litmus_spec_helper'
