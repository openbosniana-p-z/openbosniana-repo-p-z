# presets
[![PyPI](https://img.shields.io/pypi/v/presets.svg)](https://pypi.python.org/pypi/presets)
[![Build Status](https://travis-ci.org/bmcfee/presets.svg?branch=master)](https://travis-ci.org/bmcfee/presets)
[![Coverage Status](https://coveralls.io/repos/bmcfee/presets/badge.svg?branch=master&service=github)](https://coveralls.io/github/bmcfee/presets?branch=master)
[![License](https://img.shields.io/github/license/bmcfee/presets.svg)]()
[![Documentation Status](https://readthedocs.org/projects/presets/badge/?version=latest)](http://presets.readthedocs.org/en/latest/?badge=latest)

A python module to manipulate default parameters of a module's functions.

For instructions, please refer to the [documentation](http://presets.readthedocs.org/en/latest/).
