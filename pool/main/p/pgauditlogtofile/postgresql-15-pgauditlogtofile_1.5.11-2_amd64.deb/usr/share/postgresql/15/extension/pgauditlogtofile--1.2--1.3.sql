/* pgauditlogtofile/pgauditlogtofile--1.2--1.3.sql */

-- complain if script is sourced in psql, rather than via ALTER EXTENSION
\echo Use "ALTER EXTENSION pgauditlogtofile UPDATE TO '1.3'" to load this file. \quit
