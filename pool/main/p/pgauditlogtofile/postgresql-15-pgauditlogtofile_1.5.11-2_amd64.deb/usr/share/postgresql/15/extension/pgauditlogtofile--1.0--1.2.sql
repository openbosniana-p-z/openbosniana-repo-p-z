/* pgauditlogtofile/pgauditlogtofile--1.0--1.2.sql */

-- complain if script is sourced in psql, rather than via ALTER EXTENSION
\echo Use "ALTER EXTENSION pgauditlogtofile UPDATE TO '1.2'" to load this file. \quit

