/* pgauditlogtofile/pgauditlogtofile--1.3--1.4.sql */

-- complain if script is sourced in psql, rather than via ALTER EXTENSION
\echo Use "ALTER EXTENSION pgauditlogtofile UPDATE TO '1.4'" to load this file. \quit
