/* pgauditlogtofile/pgauditlogtofile--1.4--1.5.sql */

-- complain if script is sourced in psql, rather than via ALTER EXTENSION
\echo Use "ALTER EXTENSION pgauditlogtofile UPDATE TO '1.5'" to load this file. \quit
