/* Copyright (c) 2001 Jeff Johnston  <jjohnstn@redhat.com> */
/* dummy header file to support BSD compiler */
