/* Copyright (c) 2002 Jeff Johnston  <jjohnstn@redhat.com> */
#define __MAX_BAUD  B4000000
