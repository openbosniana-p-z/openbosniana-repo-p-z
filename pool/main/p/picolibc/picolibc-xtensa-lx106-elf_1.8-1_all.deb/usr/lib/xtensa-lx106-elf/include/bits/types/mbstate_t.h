#ifndef _PICOLIBC_BITS_TYPES_MBSTATE_T_H
#define _PICOLIBC_BITS_TYPES_MBSTATE_T_H

#include <sys/_types.h>

typedef _mbstate_t mbstate_t;

#endif /* _PICOLIBC_BITS_TYPES_MBSTATE_T_H */
