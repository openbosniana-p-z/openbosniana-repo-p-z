## Docs have moved!

Puppetserver's markdown for documentation has moved to https://github.com/puppetlabs/osp-docs. Please file a ticket in the SERVER JIRA project to request changes.

Published docs can be found at https://puppet.com/docs/puppet/latest/server/about_server.html.
