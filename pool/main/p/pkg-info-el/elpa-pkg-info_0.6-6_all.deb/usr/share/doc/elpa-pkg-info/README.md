pkg-info.el
===========

Provide information about Emacs packages.

Functions
---------

This library defines the following functions for use in your Emacs extensions:

- `pkg-info-library-original-version` extracts the *original version* from the
  header of a library.
- `pkg-info-library-version` extracts the *version* from the header of a library.
- `pkg-info-defining-library-version` extracts the *version* from the header of
  a library defining a function.
- `pkg-info-defining-library-original-version` extracts the *original version*
  from the header of a library defining a function.
- `pkg-info-package-version` gets the *version* of an installed package.
- `pkg-info-format-version` formats a *version* as human readable string.
- `pkg-info-get-melpa-recipe` gets the MELPA recipe for a package.
- `pkg-info-wiki-package-p` determines whether a package was build from
  EmacsWiki on MELPA.

All of these functions are interactive commands as well.

A *version* is the version from the Library Headers, i.e. either from the
`Version` or from the `Package-Version` headers.  An *original version* is the
version from the `X-Original-Version` header added by MELPA_ to preserve
upstream versions.

Versions are represented as version lists, as returned by `version-to-list`.
