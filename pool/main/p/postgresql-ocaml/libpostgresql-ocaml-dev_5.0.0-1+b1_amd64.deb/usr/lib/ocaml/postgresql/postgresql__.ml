(** @canonical Postgresql.Error_code *)
module Error_code = Postgresql__Error_code


(** @canonical Postgresql.Error_field *)
module Error_field = Postgresql__Error_field
