#! /usr/bin/python3.11
print '#coding=0'
