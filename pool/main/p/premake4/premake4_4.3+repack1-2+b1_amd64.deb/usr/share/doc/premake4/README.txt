PREMAKE
A build configuration tool

 Copyright (C) 2002-2010 by Jason Perkins
 Distributed under the terms of the BSD License.

 The Lua language and runtime library is (C) TeCGraf, PUC-Rio.
 See their website at http://www.lua.org/


 For questions, comments, or more information, visit the project
 website at http://industriousone.com/premake
