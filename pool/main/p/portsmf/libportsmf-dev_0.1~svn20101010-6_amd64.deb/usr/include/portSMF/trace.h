void trace(char *format, ...);

