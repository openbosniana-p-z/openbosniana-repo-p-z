require 'puppet/util/inifile'
require 'puppet/provider/openstack'
require 'puppet/provider/openstack/auth'
require 'puppet/provider/openstack/credentials'
class Puppet::Provider::Barbican < Puppet::Provider::Openstack

  extend Puppet::Provider::Openstack::Auth

  def self.conf_filename
    '/etc/barbican/barbican.conf'
  end

  def self.barbican_conf
    return @barbican_conf if @barbican_conf
    @barbican_conf = Puppet::Util::IniConfig::File.new
    @barbican_conf.read(conf_filename)
    @barbican_conf
  end

  def self.request(service, action, properties=nil)
    begin
      super
    rescue Puppet::Error::OpenstackAuthInputError => error
      barbican_request(service, action, error, properties)
    end
  end

  def self.barbican_request(service, action, error, properties=nil)
    properties ||= []
    @credentials.username = barbican_credentials['username']
    @credentials.password = barbican_credentials['password']
    @credentials.project_name = barbican_credentials['project_name']
    @credentials.auth_url = auth_endpoint
    if barbican_credentials['region_name']
      @credentials.region_name = barbican_credentials['region_name']
    end
    @credentials.user_domain_name = barbican_credentials['user_domain_name']
    @credentials.project_domain_name = barbican_credentials['project_domain_name']

    raise error unless @credentials.set?
    Puppet::Provider::Openstack.request(service, action, properties, @credentials)
  end

  def self.barbican_credentials
    @barbican_credentials ||= get_barbican_credentials
  end

  def barbican_credentials
    self.class.barbican_credentials
  end

  def self.get_barbican_credentials
    auth_keys = ['www_authenticate_uri', 'project_name', 'username',
                 'password']
    conf = barbican_conf
    if conf and conf['keystone_authtoken'] and
        auth_keys.all?{|k| !conf['keystone_authtoken'][k].nil?}
      creds = Hash[ auth_keys.map \
                   { |k| [k, conf['keystone_authtoken'][k].strip] } ]
      if conf['project_domain_name']
        creds['project_domain_name'] = conf['project_domain_name']
      else
        creds['project_domain_name'] = 'Default'
      end
      if conf['user_domain_name']
        creds['user_domain_name'] = conf['user_domain_name']
      else
        creds['user_domain_name'] = 'Default'
      end
      if conf['DEFAULT'] and conf['DEFAULT']['os_region_name']
        creds['region_name'] = conf['DEFAULT']['os_region_name']
      end
      return creds
    else
      raise(Puppet::Error, "File: #{conf_filename} does not contain all " +
            "required sections. Barbican types will not work if barbican is not " +
            "correctly configured.")
    end
  end

  def self.get_auth_endpoint
    q = barbican_credentials
    "#{q['www_authenticate_uri']}"
  end

  def self.auth_endpoint
    @auth_endpoint ||= get_auth_endpoint
  end

  def self.reset
    @barbican_conf = nil
    @barbican_credentials = nil
  end

end
