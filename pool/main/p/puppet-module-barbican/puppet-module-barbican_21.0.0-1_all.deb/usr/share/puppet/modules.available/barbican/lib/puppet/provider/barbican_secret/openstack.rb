require File.join(File.dirname(__FILE__), '..','..','..', 'puppet/provider/barbican')
Puppet::Type.type(:barbican_secret).provide(
  :openstack,
  :parent => Puppet::Provider::Barbican
) do

  desc "Provider to manage Barbican secrets."

  @credentials = Puppet::Provider::Openstack::CredentialsV3.new

  def initialize(value={})
    super(value)
    @property_flush = {}
  end

  def self.get_url(myname)
    opts = []
    opts << "--name" << myname
    list = request('secret', 'list', opts)
    reallist = list.collect do |secret|
      url = secret[:'Secret href']
      return url
    end
  end

  def create
    opts = []
    opts << "--name=#{@resource[:name]}"
    opts << '--algorithm=aes'
    opts << '--bit-length=256'
    opts << '--mode=ctr'
    opts << '--secret-type=symmetric'
    opts << "--payload=#{@resource[:payload]}"

    @property_hash = self.class.request('secret', 'store', opts)
  end

  def destroy
    url = self.get_url(@resource[:name])
    self.self.request('secret', 'delete', url)
    @property_hash.clear
  end

  def flush
    @property_flush.clear
  end

#  def exists?
#    return true if @property_hash[:ensure] == :present
#    url = self.class.get_url(@resource[:name])
#    return false if url.nil?
#    true
#  end
  def exists?
    @property_hash[:ensure] == :present
  end

  mk_resource_methods

  # Types properties
  def payload=(value)
    @property_flush[:payload] = value
  end

  def self.instances
    list = request('secret', 'list')
    reallist = list.collect do |secret|
      debug "Found secret, calling get_url()"
      url = self.get_url(secret[:name])
#      properties = Hash[attrs[:properties].scan(/(\S+)='([^']*)'/)] rescue nil
      new(
        :ensure           => :present,
        :name             => secret[:name],
        :url              => url,
      )
    end
  end

  def self.prefetch(resources)
    secret = instances
    resources.keys.each do |name|
       if provider = secret.find{ |secret| secret.name == name.downcase }
        resources[name].provider = provider
      end
    end
  end
end
