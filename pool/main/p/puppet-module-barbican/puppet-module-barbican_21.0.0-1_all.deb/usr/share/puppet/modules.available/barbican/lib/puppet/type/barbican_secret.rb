File.expand_path('../../../../openstacklib/lib', File.dirname(__FILE__)).tap { |dir| $LOAD_PATH.unshift(dir) unless $LOAD_PATH.include?(dir) }
Puppet::Type.newtype(:barbican_secret) do
  desc <<-EOT
    This allows manifests to declare a Barbican secret.

    barbican_secret {"super-secret":
      ensure  => present,
      payload => "a_super_big_secret",
    }
  EOT

  ensurable do
    defaultto(:present)
    newvalue(:present) do
      provider.create
    end
    newvalue(:absent) do
      provider.destroy
    end
  end

  newparam(:name, :namevar => true) do
    desc 'The secret name'
    newvalues(/.*/)
  end

  newproperty(:payload) do
    desc "The secret value to store"
    newvalues(/.*/)
  end

  autorequire(:service) do
    ['barbican-api']
  end

  validate do
    if self[:ensure] == :present and ! self[:payload]
      raise ArgumentError, 'must set payload when creating secret' unless self[:payload]
    end
  end

end
