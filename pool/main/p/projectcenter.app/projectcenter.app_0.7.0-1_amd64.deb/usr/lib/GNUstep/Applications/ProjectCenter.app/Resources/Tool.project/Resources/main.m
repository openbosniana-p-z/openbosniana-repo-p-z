/*
   Project: $PROJECTNAME$

   Author: $FULLUSERNAME$

   Created: $DATE$ by $USERNAME$
*/

#import <Foundation/Foundation.h>

int
main(int argc, const char *argv[])
{
  id pool = [[NSAutoreleasePool alloc] init];

  // Your code here...

  // The end...
  [pool release];

  return 0;
}

