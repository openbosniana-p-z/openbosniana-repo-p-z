#!/usr/bin/env python


import sys

sys.path.insert(1, "/usr/share/mkdocs/themes")

# For acceptable version formats, see https://www.python.org/dev/peps/pep-0440/
__version__ = '1.4.2'
