<?php
/**
 * Horde_Share_Exception
 *
 *
 */
class Horde_Share_Exception extends Horde_Exception_Wrapped
{
}