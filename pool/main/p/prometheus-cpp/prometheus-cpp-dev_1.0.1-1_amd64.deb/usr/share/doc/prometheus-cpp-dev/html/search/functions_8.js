var searchData=
[
  ['registry_71',['Registry',['../classprometheus_1_1Registry.html#a85d43814dbb94b75c0b0aa1730cac159',1,'prometheus::Registry::Registry(InsertBehavior insert_behavior=InsertBehavior::Merge)'],['../classprometheus_1_1Registry.html#a834cd4b4d608f29ef847370c4f433697',1,'prometheus::Registry::Registry(const Registry &amp;)=delete'],['../classprometheus_1_1Registry.html#a8a8d7426e717f4463643e16abfee156a',1,'prometheus::Registry::Registry(Registry &amp;&amp;)=delete']]],
  ['remove_72',['Remove',['../classprometheus_1_1Family.html#a2fb0871bbda996810bbefe62ff92c8fe',1,'prometheus::Family::Remove()'],['../classprometheus_1_1Registry.html#aa495e7d7a59efe59c0ab862ec6217c5c',1,'prometheus::Registry::Remove()']]]
];
