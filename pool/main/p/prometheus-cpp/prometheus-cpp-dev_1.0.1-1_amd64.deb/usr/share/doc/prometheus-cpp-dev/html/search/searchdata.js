var indexSectionsWithContent =
{
  0: "abcdefghilmopqrstuv~",
  1: "bcefghlmqrstu",
  2: "acdfghiorsv~",
  3: "i",
  4: "mt",
  5: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "enums",
  4: "enumvalues",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Enumerations",
  4: "Enumerator",
  5: "Pages"
};

