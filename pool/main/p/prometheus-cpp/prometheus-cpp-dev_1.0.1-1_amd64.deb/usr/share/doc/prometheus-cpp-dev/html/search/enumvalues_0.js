var searchData=
[
  ['merge_79',['Merge',['../classprometheus_1_1Registry.html#ae8018ea1ad010207ee4c0045e18d1a40a68be4837f6c739877233e527a996dd00',1,'prometheus::Registry']]]
];
