var searchData=
[
  ['basicauthhandler_38',['BasicAuthHandler',['../classprometheus_1_1BasicAuthHandler.html',1,'prometheus']]],
  ['bucket_39',['Bucket',['../structprometheus_1_1ClientMetric_1_1Bucket.html',1,'prometheus::ClientMetric']]]
];
