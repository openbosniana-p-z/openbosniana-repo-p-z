var searchData=
[
  ['histogram_47',['Histogram',['../structprometheus_1_1ClientMetric_1_1Histogram.html',1,'prometheus::ClientMetric::Histogram'],['../classprometheus_1_1Histogram.html',1,'prometheus::Histogram']]]
];
