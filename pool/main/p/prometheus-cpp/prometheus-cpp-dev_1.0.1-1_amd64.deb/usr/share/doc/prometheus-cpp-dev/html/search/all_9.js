var searchData=
[
  ['label_19',['Label',['../structprometheus_1_1ClientMetric_1_1Label.html',1,'prometheus::ClientMetric']]]
];
