var searchData=
[
  ['untyped_55',['Untyped',['../structprometheus_1_1ClientMetric_1_1Untyped.html',1,'prometheus::ClientMetric']]]
];
