var searchData=
[
  ['gateway_45',['Gateway',['../classprometheus_1_1Gateway.html',1,'prometheus']]],
  ['gauge_46',['Gauge',['../structprometheus_1_1ClientMetric_1_1Gauge.html',1,'prometheus::ClientMetric::Gauge'],['../classprometheus_1_1Gauge.html',1,'prometheus::Gauge']]]
];
