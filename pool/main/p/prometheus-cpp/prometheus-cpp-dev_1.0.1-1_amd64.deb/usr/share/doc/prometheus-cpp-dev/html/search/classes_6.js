var searchData=
[
  ['label_48',['Label',['../structprometheus_1_1ClientMetric_1_1Label.html',1,'prometheus::ClientMetric']]]
];
