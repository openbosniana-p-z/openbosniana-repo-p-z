var searchData=
[
  ['registry_51',['Registry',['../classprometheus_1_1Registry.html',1,'prometheus']]]
];
