var searchData=
[
  ['_7eregistry_77',['~Registry',['../classprometheus_1_1Registry.html#a7b8e8e947d2ed2de5f94c90829b52460',1,'prometheus::Registry']]]
];
