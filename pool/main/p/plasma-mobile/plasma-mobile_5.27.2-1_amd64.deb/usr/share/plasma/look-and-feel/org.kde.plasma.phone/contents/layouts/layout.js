// SPDX-FileCopyrightText: 2022 Devin Lin <devin@kde.org>
// SPDX-License-Identifier: GPL-2.0-or-later

// no default layout, needed to have lookandfeelmanager in plasma-workspace recognize the LnF as affecting desktop layout.
