<?php

namespace Illuminate\Pagination;

use RuntimeException;

/**
 * @deprecated Will be removed in a future Laravel version.
 */
class CursorPaginationException extends RuntimeException
{
    //
}
