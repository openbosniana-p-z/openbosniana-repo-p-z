<?php

namespace Illuminate\Foundation\Http\Middleware;

class CheckForMaintenanceMode extends PreventRequestsDuringMaintenance
{
    //
}
