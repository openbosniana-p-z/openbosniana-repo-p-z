<?php

// Require
require_once 'Carbon/autoload.php';
require_once 'Cron/autoload.php';
require_once 'Doctrine/Inflector/autoload.php';
require_once 'Dotenv/autoload.php';
require_once 'Egulias/EmailValidator/autoload.php';
require_once 'Illuminate/Auth/autoload.php';
require_once 'Illuminate/Broadcasting/autoload.php';
require_once 'Illuminate/Bus/autoload.php';
require_once 'Illuminate/Cache/autoload.php';
require_once 'Illuminate/Collections/autoload.php';
require_once 'Illuminate/Config/autoload.php';
require_once 'Illuminate/Console/autoload.php';
require_once 'Illuminate/Container/autoload.php';
require_once 'Illuminate/Contracts/autoload.php';
require_once 'Illuminate/Cookie/autoload.php';
require_once 'Illuminate/Database/autoload.php';
require_once 'Illuminate/Encryption/autoload.php';
require_once 'Illuminate/Events/autoload.php';
require_once 'Illuminate/Filesystem/autoload.php';
require_once 'Illuminate/Hashing/autoload.php';
require_once 'Illuminate/Http/autoload.php';
require_once 'Illuminate/Log/autoload.php';
require_once 'Illuminate/Macroable/autoload.php';
require_once 'Illuminate/Mail/autoload.php';
require_once 'Illuminate/Notifications/autoload.php';
require_once 'Illuminate/Pagination/autoload.php';
require_once 'Illuminate/Pipeline/autoload.php';
require_once 'Illuminate/Queue/autoload.php';
require_once 'Illuminate/Redis/autoload.php';
require_once 'Illuminate/Routing/autoload.php';
require_once 'Illuminate/Session/autoload.php';
require_once 'Illuminate/Support/autoload.php';
require_once 'Illuminate/Testing/autoload.php';
require_once 'Illuminate/Translation/autoload.php';
require_once 'Illuminate/Validation/autoload.php';
require_once 'Illuminate/View/autoload.php';
require_once 'Laravel/SerializableClosure/autoload.php';
require_once 'League/CommonMark/autoload.php';
require_once 'League/Flysystem/autoload.php';
require_once 'Monolog/autoload.php';
require_once 'Opis/Closure/autoload.php';
require_once 'Psr/Container/autoload.php';
require_once 'Psr/Log/autoload.php';
require_once 'Psr/SimpleCache/autoload.php';
require_once 'Ramsey/Uuid/autoload.php';
require_once 'Swift/swift_required.php';
require_once 'Symfony/Component/Console/autoload.php';
require_once 'Symfony/Component/ErrorHandler/autoload.php';
require_once 'Symfony/Component/Finder/autoload.php';
require_once 'Symfony/Component/HttpFoundation/autoload.php';
require_once 'Symfony/Component/HttpKernel/autoload.php';
require_once 'Symfony/Component/Mime/autoload.php';
require_once 'Symfony/Component/Process/autoload.php';
require_once 'Symfony/Component/Routing/autoload.php';
require_once 'Symfony/Component/VarDumper/autoload.php';
require_once 'TijsVerkoyen/CssToInlineStyles/autoload.php';
require_once 'voku/helper/autoload.php';

// Suggest
if (stream_resolve_include_path('Ably/Php/autoload.php')) { include_once 'Ably/Php/autoload.php'; }
if (stream_resolve_include_path('Aws/SdkPhp/autoload.php')) { include_once 'Aws/SdkPhp/autoload.php'; }
if (stream_resolve_include_path('Brianium/Paratest/autoload.php')) { include_once 'Brianium/Paratest/autoload.php'; }
if (stream_resolve_include_path('Doctrine/DBAL/autoload.php')) { include_once 'Doctrine/DBAL/autoload.php'; }
if (stream_resolve_include_path('Fakerphp/Faker/autoload.php')) { include_once 'Fakerphp/Faker/autoload.php'; }
if (stream_resolve_include_path('Filp/Whoops/autoload.php')) { include_once 'Filp/Whoops/autoload.php'; }
if (stream_resolve_include_path('Guzzlehttp/Guzzle/autoload.php')) { include_once 'Guzzlehttp/Guzzle/autoload.php'; }
if (stream_resolve_include_path('Laravel/Tinker/autoload.php')) { include_once 'Laravel/Tinker/autoload.php'; }
if (stream_resolve_include_path('League/FlysystemAwsS3V3/autoload.php')) { include_once 'League/FlysystemAwsS3V3/autoload.php'; }
if (stream_resolve_include_path('League/FlysystemCachedAdapter/autoload.php')) { include_once 'League/FlysystemCachedAdapter/autoload.php'; }
if (stream_resolve_include_path('League/FlysystemSftp/autoload.php')) { include_once 'League/FlysystemSftp/autoload.php'; }
if (stream_resolve_include_path('Mockery/autoload.php')) { include_once 'Mockery/autoload.php'; }
if (stream_resolve_include_path('Nyholm/Psr7/autoload.php')) { include_once 'Nyholm/Psr7/autoload.php'; }
if (stream_resolve_include_path('Pda/Pheanstalk/autoload.php')) { include_once 'Pda/Pheanstalk/autoload.php'; }
if (stream_resolve_include_path('Phpunit/autoload.php')) { include_once 'Phpunit/autoload.php'; }
if (stream_resolve_include_path('Predis/autoload.php')) { include_once 'Predis/autoload.php'; }
if (stream_resolve_include_path('Psr/Http/Message/autoload.php')) { include_once 'Psr/Http/Message/autoload.php'; }
if (stream_resolve_include_path('Pusher/PhpServer/autoload.php')) { include_once 'Pusher/PhpServer/autoload.php'; }
if (stream_resolve_include_path('Symfony/Component/Cache/autoload.php')) { include_once 'Symfony/Component/Cache/autoload.php'; }
if (stream_resolve_include_path('Symfony/Filesystem/autoload.php')) { include_once 'Symfony/Filesystem/autoload.php'; }
if (stream_resolve_include_path('Symfony/PsrHttpMessageBridge/autoload.php')) { include_once 'Symfony/PsrHttpMessageBridge/autoload.php'; }
if (stream_resolve_include_path('Wildbit/SwiftmailerPostmark/autoload.php')) { include_once 'Wildbit/SwiftmailerPostmark/autoload.php'; }

// @codingStandardsIgnoreFile
// @codeCoverageIgnoreStart
// this is an autogenerated file - do not edit
spl_autoload_register(
    function($class) {
        static $classes = null;
        if ($classes === null) {
            $classes = array(
                'illuminate\\foundation\\aliasloader' => '/Foundation/AliasLoader.php',
                'illuminate\\foundation\\application' => '/Foundation/Application.php',
                'illuminate\\foundation\\auth\\access\\authorizable' => '/Foundation/Auth/Access/Authorizable.php',
                'illuminate\\foundation\\auth\\access\\authorizesrequests' => '/Foundation/Auth/Access/AuthorizesRequests.php',
                'illuminate\\foundation\\auth\\emailverificationrequest' => '/Foundation/Auth/EmailVerificationRequest.php',
                'illuminate\\foundation\\auth\\user' => '/Foundation/Auth/User.php',
                'illuminate\\foundation\\bootstrap\\bootproviders' => '/Foundation/Bootstrap/BootProviders.php',
                'illuminate\\foundation\\bootstrap\\handleexceptions' => '/Foundation/Bootstrap/HandleExceptions.php',
                'illuminate\\foundation\\bootstrap\\loadconfiguration' => '/Foundation/Bootstrap/LoadConfiguration.php',
                'illuminate\\foundation\\bootstrap\\loadenvironmentvariables' => '/Foundation/Bootstrap/LoadEnvironmentVariables.php',
                'illuminate\\foundation\\bootstrap\\registerfacades' => '/Foundation/Bootstrap/RegisterFacades.php',
                'illuminate\\foundation\\bootstrap\\registerproviders' => '/Foundation/Bootstrap/RegisterProviders.php',
                'illuminate\\foundation\\bootstrap\\setrequestforconsole' => '/Foundation/Bootstrap/SetRequestForConsole.php',
                'illuminate\\foundation\\bus\\dispatchable' => '/Foundation/Bus/Dispatchable.php',
                'illuminate\\foundation\\bus\\dispatchesjobs' => '/Foundation/Bus/DispatchesJobs.php',
                'illuminate\\foundation\\bus\\pendingchain' => '/Foundation/Bus/PendingChain.php',
                'illuminate\\foundation\\bus\\pendingclosuredispatch' => '/Foundation/Bus/PendingClosureDispatch.php',
                'illuminate\\foundation\\bus\\pendingdispatch' => '/Foundation/Bus/PendingDispatch.php',
                'illuminate\\foundation\\composerscripts' => '/Foundation/ComposerScripts.php',
                'illuminate\\foundation\\console\\castmakecommand' => '/Foundation/Console/CastMakeCommand.php',
                'illuminate\\foundation\\console\\channelmakecommand' => '/Foundation/Console/ChannelMakeCommand.php',
                'illuminate\\foundation\\console\\clearcompiledcommand' => '/Foundation/Console/ClearCompiledCommand.php',
                'illuminate\\foundation\\console\\closurecommand' => '/Foundation/Console/ClosureCommand.php',
                'illuminate\\foundation\\console\\componentmakecommand' => '/Foundation/Console/ComponentMakeCommand.php',
                'illuminate\\foundation\\console\\configcachecommand' => '/Foundation/Console/ConfigCacheCommand.php',
                'illuminate\\foundation\\console\\configclearcommand' => '/Foundation/Console/ConfigClearCommand.php',
                'illuminate\\foundation\\console\\consolemakecommand' => '/Foundation/Console/ConsoleMakeCommand.php',
                'illuminate\\foundation\\console\\downcommand' => '/Foundation/Console/DownCommand.php',
                'illuminate\\foundation\\console\\environmentcommand' => '/Foundation/Console/EnvironmentCommand.php',
                'illuminate\\foundation\\console\\eventcachecommand' => '/Foundation/Console/EventCacheCommand.php',
                'illuminate\\foundation\\console\\eventclearcommand' => '/Foundation/Console/EventClearCommand.php',
                'illuminate\\foundation\\console\\eventgeneratecommand' => '/Foundation/Console/EventGenerateCommand.php',
                'illuminate\\foundation\\console\\eventlistcommand' => '/Foundation/Console/EventListCommand.php',
                'illuminate\\foundation\\console\\eventmakecommand' => '/Foundation/Console/EventMakeCommand.php',
                'illuminate\\foundation\\console\\exceptionmakecommand' => '/Foundation/Console/ExceptionMakeCommand.php',
                'illuminate\\foundation\\console\\jobmakecommand' => '/Foundation/Console/JobMakeCommand.php',
                'illuminate\\foundation\\console\\kernel' => '/Foundation/Console/Kernel.php',
                'illuminate\\foundation\\console\\keygeneratecommand' => '/Foundation/Console/KeyGenerateCommand.php',
                'illuminate\\foundation\\console\\listenermakecommand' => '/Foundation/Console/ListenerMakeCommand.php',
                'illuminate\\foundation\\console\\mailmakecommand' => '/Foundation/Console/MailMakeCommand.php',
                'illuminate\\foundation\\console\\modelmakecommand' => '/Foundation/Console/ModelMakeCommand.php',
                'illuminate\\foundation\\console\\notificationmakecommand' => '/Foundation/Console/NotificationMakeCommand.php',
                'illuminate\\foundation\\console\\observermakecommand' => '/Foundation/Console/ObserverMakeCommand.php',
                'illuminate\\foundation\\console\\optimizeclearcommand' => '/Foundation/Console/OptimizeClearCommand.php',
                'illuminate\\foundation\\console\\optimizecommand' => '/Foundation/Console/OptimizeCommand.php',
                'illuminate\\foundation\\console\\packagediscovercommand' => '/Foundation/Console/PackageDiscoverCommand.php',
                'illuminate\\foundation\\console\\policymakecommand' => '/Foundation/Console/PolicyMakeCommand.php',
                'illuminate\\foundation\\console\\providermakecommand' => '/Foundation/Console/ProviderMakeCommand.php',
                'illuminate\\foundation\\console\\queuedcommand' => '/Foundation/Console/QueuedCommand.php',
                'illuminate\\foundation\\console\\requestmakecommand' => '/Foundation/Console/RequestMakeCommand.php',
                'illuminate\\foundation\\console\\resourcemakecommand' => '/Foundation/Console/ResourceMakeCommand.php',
                'illuminate\\foundation\\console\\routecachecommand' => '/Foundation/Console/RouteCacheCommand.php',
                'illuminate\\foundation\\console\\routeclearcommand' => '/Foundation/Console/RouteClearCommand.php',
                'illuminate\\foundation\\console\\routelistcommand' => '/Foundation/Console/RouteListCommand.php',
                'illuminate\\foundation\\console\\rulemakecommand' => '/Foundation/Console/RuleMakeCommand.php',
                'illuminate\\foundation\\console\\servecommand' => '/Foundation/Console/ServeCommand.php',
                'illuminate\\foundation\\console\\storagelinkcommand' => '/Foundation/Console/StorageLinkCommand.php',
                'illuminate\\foundation\\console\\stubpublishcommand' => '/Foundation/Console/StubPublishCommand.php',
                'illuminate\\foundation\\console\\testmakecommand' => '/Foundation/Console/TestMakeCommand.php',
                'illuminate\\foundation\\console\\upcommand' => '/Foundation/Console/UpCommand.php',
                'illuminate\\foundation\\console\\vendorpublishcommand' => '/Foundation/Console/VendorPublishCommand.php',
                'illuminate\\foundation\\console\\viewcachecommand' => '/Foundation/Console/ViewCacheCommand.php',
                'illuminate\\foundation\\console\\viewclearcommand' => '/Foundation/Console/ViewClearCommand.php',
                'illuminate\\foundation\\environmentdetector' => '/Foundation/EnvironmentDetector.php',
                'illuminate\\foundation\\events\\discoverevents' => '/Foundation/Events/DiscoverEvents.php',
                'illuminate\\foundation\\events\\dispatchable' => '/Foundation/Events/Dispatchable.php',
                'illuminate\\foundation\\events\\localeupdated' => '/Foundation/Events/LocaleUpdated.php',
                'illuminate\\foundation\\events\\maintenancemodedisabled' => '/Foundation/Events/MaintenanceModeDisabled.php',
                'illuminate\\foundation\\events\\maintenancemodeenabled' => '/Foundation/Events/MaintenanceModeEnabled.php',
                'illuminate\\foundation\\events\\vendortagpublished' => '/Foundation/Events/VendorTagPublished.php',
                'illuminate\\foundation\\exceptions\\handler' => '/Foundation/Exceptions/Handler.php',
                'illuminate\\foundation\\exceptions\\registererrorviewpaths' => '/Foundation/Exceptions/RegisterErrorViewPaths.php',
                'illuminate\\foundation\\exceptions\\reportablehandler' => '/Foundation/Exceptions/ReportableHandler.php',
                'illuminate\\foundation\\exceptions\\whoopshandler' => '/Foundation/Exceptions/WhoopsHandler.php',
                'illuminate\\foundation\\http\\events\\requesthandled' => '/Foundation/Http/Events/RequestHandled.php',
                'illuminate\\foundation\\http\\exceptions\\maintenancemodeexception' => '/Foundation/Http/Exceptions/MaintenanceModeException.php',
                'illuminate\\foundation\\http\\formrequest' => '/Foundation/Http/FormRequest.php',
                'illuminate\\foundation\\http\\kernel' => '/Foundation/Http/Kernel.php',
                'illuminate\\foundation\\http\\maintenancemodebypasscookie' => '/Foundation/Http/MaintenanceModeBypassCookie.php',
                'illuminate\\foundation\\http\\middleware\\checkformaintenancemode' => '/Foundation/Http/Middleware/CheckForMaintenanceMode.php',
                'illuminate\\foundation\\http\\middleware\\convertemptystringstonull' => '/Foundation/Http/Middleware/ConvertEmptyStringsToNull.php',
                'illuminate\\foundation\\http\\middleware\\preventrequestsduringmaintenance' => '/Foundation/Http/Middleware/PreventRequestsDuringMaintenance.php',
                'illuminate\\foundation\\http\\middleware\\transformsrequest' => '/Foundation/Http/Middleware/TransformsRequest.php',
                'illuminate\\foundation\\http\\middleware\\trimstrings' => '/Foundation/Http/Middleware/TrimStrings.php',
                'illuminate\\foundation\\http\\middleware\\validatepostsize' => '/Foundation/Http/Middleware/ValidatePostSize.php',
                'illuminate\\foundation\\http\\middleware\\verifycsrftoken' => '/Foundation/Http/Middleware/VerifyCsrfToken.php',
                'illuminate\\foundation\\inspiring' => '/Foundation/Inspiring.php',
                'illuminate\\foundation\\mix' => '/Foundation/Mix.php',
                'illuminate\\foundation\\packagemanifest' => '/Foundation/PackageManifest.php',
                'illuminate\\foundation\\providerrepository' => '/Foundation/ProviderRepository.php',
                'illuminate\\foundation\\providers\\artisanserviceprovider' => '/Foundation/Providers/ArtisanServiceProvider.php',
                'illuminate\\foundation\\providers\\composerserviceprovider' => '/Foundation/Providers/ComposerServiceProvider.php',
                'illuminate\\foundation\\providers\\consolesupportserviceprovider' => '/Foundation/Providers/ConsoleSupportServiceProvider.php',
                'illuminate\\foundation\\providers\\formrequestserviceprovider' => '/Foundation/Providers/FormRequestServiceProvider.php',
                'illuminate\\foundation\\providers\\foundationserviceprovider' => '/Foundation/Providers/FoundationServiceProvider.php',
                'illuminate\\foundation\\support\\providers\\authserviceprovider' => '/Foundation/Support/Providers/AuthServiceProvider.php',
                'illuminate\\foundation\\support\\providers\\eventserviceprovider' => '/Foundation/Support/Providers/EventServiceProvider.php',
                'illuminate\\foundation\\support\\providers\\routeserviceprovider' => '/Foundation/Support/Providers/RouteServiceProvider.php',
                'illuminate\\foundation\\testing\\concerns\\interactswithauthentication' => '/Foundation/Testing/Concerns/InteractsWithAuthentication.php',
                'illuminate\\foundation\\testing\\concerns\\interactswithconsole' => '/Foundation/Testing/Concerns/InteractsWithConsole.php',
                'illuminate\\foundation\\testing\\concerns\\interactswithcontainer' => '/Foundation/Testing/Concerns/InteractsWithContainer.php',
                'illuminate\\foundation\\testing\\concerns\\interactswithdatabase' => '/Foundation/Testing/Concerns/InteractsWithDatabase.php',
                'illuminate\\foundation\\testing\\concerns\\interactswithdeprecationhandling' => '/Foundation/Testing/Concerns/InteractsWithDeprecationHandling.php',
                'illuminate\\foundation\\testing\\concerns\\interactswithexceptionhandling' => '/Foundation/Testing/Concerns/InteractsWithExceptionHandling.php',
                'illuminate\\foundation\\testing\\concerns\\interactswithredis' => '/Foundation/Testing/Concerns/InteractsWithRedis.php',
                'illuminate\\foundation\\testing\\concerns\\interactswithsession' => '/Foundation/Testing/Concerns/InteractsWithSession.php',
                'illuminate\\foundation\\testing\\concerns\\interactswithtime' => '/Foundation/Testing/Concerns/InteractsWithTime.php',
                'illuminate\\foundation\\testing\\concerns\\interactswithviews' => '/Foundation/Testing/Concerns/InteractsWithViews.php',
                'illuminate\\foundation\\testing\\concerns\\makeshttprequests' => '/Foundation/Testing/Concerns/MakesHttpRequests.php',
                'illuminate\\foundation\\testing\\concerns\\mocksapplicationservices' => '/Foundation/Testing/Concerns/MocksApplicationServices.php',
                'illuminate\\foundation\\testing\\databasemigrations' => '/Foundation/Testing/DatabaseMigrations.php',
                'illuminate\\foundation\\testing\\databasetransactions' => '/Foundation/Testing/DatabaseTransactions.php',
                'illuminate\\foundation\\testing\\lazilyrefreshdatabase' => '/Foundation/Testing/LazilyRefreshDatabase.php',
                'illuminate\\foundation\\testing\\refreshdatabase' => '/Foundation/Testing/RefreshDatabase.php',
                'illuminate\\foundation\\testing\\refreshdatabasestate' => '/Foundation/Testing/RefreshDatabaseState.php',
                'illuminate\\foundation\\testing\\testcase' => '/Foundation/Testing/TestCase.php',
                'illuminate\\foundation\\testing\\traits\\canconfiguremigrationcommands' => '/Foundation/Testing/Traits/CanConfigureMigrationCommands.php',
                'illuminate\\foundation\\testing\\withfaker' => '/Foundation/Testing/WithFaker.php',
                'illuminate\\foundation\\testing\\withoutevents' => '/Foundation/Testing/WithoutEvents.php',
                'illuminate\\foundation\\testing\\withoutmiddleware' => '/Foundation/Testing/WithoutMiddleware.php',
                'illuminate\\foundation\\testing\\wormhole' => '/Foundation/Testing/Wormhole.php',
                'illuminate\\foundation\\validation\\validatesrequests' => '/Foundation/Validation/ValidatesRequests.php'
            );
        }
        $cn = strtolower($class);
        if (isset($classes[$cn])) {
            require __DIR__ . $classes[$cn];
        }
    },
    true,
    false
);
// @codeCoverageIgnoreEnd

// Files
require_once __DIR__.'/Collections/helpers.php';
require_once __DIR__.'/Events/functions.php';
require_once __DIR__.'/Foundation/helpers.php';
require_once __DIR__.'/Support/helpers.php';
