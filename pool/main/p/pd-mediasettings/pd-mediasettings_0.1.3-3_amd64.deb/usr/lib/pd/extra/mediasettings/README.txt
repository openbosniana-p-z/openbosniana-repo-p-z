
mediasettings - get/set audio and MIDI settings within Pd

NOTE: this library has been developed for the IntegraLive
project http://integralive.org

IOhannes m zmoelnig (zmoelnig AT iem DOT at)
