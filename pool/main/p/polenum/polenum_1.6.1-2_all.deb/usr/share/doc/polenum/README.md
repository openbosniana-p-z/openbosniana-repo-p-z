# polenum
Uses Core's Impacket Library to get the password policy from a windows machine

This is a fork of the original polenum which is available at Portcullis Labs Research and Development (https://labs.portcullis.co.uk/tools/polenum/)

This version supports the latest impacket DCERPC v5 library.
