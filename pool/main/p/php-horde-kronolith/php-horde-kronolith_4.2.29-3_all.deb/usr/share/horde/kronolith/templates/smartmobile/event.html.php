<div data-role="dialog" data-theme="b" id="eventview">
 <?php echo $this->smartmobileHeader(array('title' => _("Event"))) ?>
 <div data-role="content" class="ui-body"></div>
</div>
