var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuvw",
  1: "bcdefipuv",
  2: "p",
  3: "bcdeiptv",
  4: "abcdefghilnoprstvw",
  5: "m",
  6: "ceipv",
  7: "p",
  8: "p",
  9: "dpu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Macros",
  9: "Pages"
};

