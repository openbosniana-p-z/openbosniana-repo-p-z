var searchData=
[
  ['invalid_5flength_5fexception_203',['invalid_length_exception',['../structprotozero_1_1invalid__length__exception.html',1,'protozero']]],
  ['invalid_5ftag_5fexception_204',['invalid_tag_exception',['../structprotozero_1_1invalid__tag__exception.html',1,'protozero']]],
  ['iterator_5frange_205',['iterator_range',['../classprotozero_1_1iterator__range.html',1,'protozero']]]
];
