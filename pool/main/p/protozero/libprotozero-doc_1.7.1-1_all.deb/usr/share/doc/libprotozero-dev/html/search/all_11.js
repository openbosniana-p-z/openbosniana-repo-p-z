var searchData=
[
  ['unknown_5fpbf_5fwire_5ftype_5fexception_184',['unknown_pbf_wire_type_exception',['../structprotozero_1_1unknown__pbf__wire__type__exception.html',1,'protozero']]],
  ['upgrading_185',['Upgrading',['../md_UPGRADING.html',1,'']]]
];
