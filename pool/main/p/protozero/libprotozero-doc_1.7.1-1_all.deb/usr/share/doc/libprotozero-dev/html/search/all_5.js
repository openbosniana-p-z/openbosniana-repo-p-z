var searchData=
[
  ['fixed_5fsize_5fbuffer_5fadaptor_84',['fixed_size_buffer_adaptor',['../classprotozero_1_1fixed__size__buffer__adaptor.html#a6dd1c97e4ae69e444b8e5ed398d379bc',1,'protozero::fixed_size_buffer_adaptor::fixed_size_buffer_adaptor(char *data, std::size_t capacity) noexcept'],['../classprotozero_1_1fixed__size__buffer__adaptor.html#a2a1b492a65805ff3518898d66c76b1de',1,'protozero::fixed_size_buffer_adaptor::fixed_size_buffer_adaptor(T &amp;container)'],['../classprotozero_1_1fixed__size__buffer__adaptor.html',1,'protozero::fixed_size_buffer_adaptor']]],
  ['front_85',['front',['../classprotozero_1_1iterator__range.html#a514e051415f0f47ce68d04ab32eb4ff1',1,'protozero::iterator_range']]]
];
