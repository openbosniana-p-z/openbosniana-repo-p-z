var searchData=
[
  ['iterator_5frange_318',['iterator_range',['../classprotozero_1_1iterator__range.html#a08129bc1b1aeb8083343075122338344',1,'protozero::iterator_range::iterator_range()'],['../classprotozero_1_1iterator__range.html#a89175b70d663d62545d4dd0569740e05',1,'protozero::iterator_range::iterator_range(iterator &amp;&amp;first_iterator, iterator &amp;&amp;last_iterator)']]]
];
