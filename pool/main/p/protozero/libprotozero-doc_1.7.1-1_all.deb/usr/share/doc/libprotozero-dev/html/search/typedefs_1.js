var searchData=
[
  ['enum_5ftype_363',['enum_type',['../classprotozero_1_1basic__pbf__builder.html#a5ffc3f047d42b38f13feffe8b424ad21',1,'protozero::basic_pbf_builder::enum_type()'],['../classprotozero_1_1pbf__message.html#a2a9358ea2446286ff4a508dab91de7bf',1,'protozero::pbf_message::enum_type()']]]
];
