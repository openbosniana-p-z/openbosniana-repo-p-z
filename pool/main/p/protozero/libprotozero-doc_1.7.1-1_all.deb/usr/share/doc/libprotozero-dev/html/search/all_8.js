var searchData=
[
  ['invalid_5flength_5fexception_120',['invalid_length_exception',['../structprotozero_1_1invalid__length__exception.html',1,'protozero']]],
  ['invalid_5ftag_5fexception_121',['invalid_tag_exception',['../structprotozero_1_1invalid__tag__exception.html',1,'protozero']]],
  ['iterator_122',['iterator',['../classprotozero_1_1iterator__range.html#af89a78d4a3c6690802922c7a612b54e9',1,'protozero::iterator_range']]],
  ['iterator_5frange_123',['iterator_range',['../classprotozero_1_1iterator__range.html#a08129bc1b1aeb8083343075122338344',1,'protozero::iterator_range::iterator_range()'],['../classprotozero_1_1iterator__range.html#a89175b70d663d62545d4dd0569740e05',1,'protozero::iterator_range::iterator_range(iterator &amp;&amp;first_iterator, iterator &amp;&amp;last_iterator)'],['../classprotozero_1_1iterator__range.html',1,'protozero::iterator_range&lt; T, P &gt;']]],
  ['iterators_2ehpp_124',['iterators.hpp',['../iterators_8hpp.html',1,'']]]
];
