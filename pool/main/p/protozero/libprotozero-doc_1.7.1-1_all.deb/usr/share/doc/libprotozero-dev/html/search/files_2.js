var searchData=
[
  ['data_5fview_2ehpp_219',['data_view.hpp',['../data__view_8hpp.html',1,'']]]
];
