var searchData=
[
  ['what_343',['what',['../structprotozero_1_1exception.html#a83ffcd6b8cdc2886716a49acf7200942',1,'protozero::exception::what()'],['../structprotozero_1_1varint__too__long__exception.html#a09c0b17307b4b9322370e311502fb9d3',1,'protozero::varint_too_long_exception::what()'],['../structprotozero_1_1unknown__pbf__wire__type__exception.html#ae601f0ec450da52e0768beb43b18bf64',1,'protozero::unknown_pbf_wire_type_exception::what()'],['../structprotozero_1_1end__of__buffer__exception.html#a8d5ab0a012eb3407ebe084d6a1d56378',1,'protozero::end_of_buffer_exception::what()'],['../structprotozero_1_1invalid__tag__exception.html#a9e7f370f58443f2c7ee9c06ad1c7a3cb',1,'protozero::invalid_tag_exception::what()'],['../structprotozero_1_1invalid__length__exception.html#a1b5d7a77f10afb758cbd277ea474da15',1,'protozero::invalid_length_exception::what()']]],
  ['wire_5ftype_344',['wire_type',['../classprotozero_1_1pbf__reader.html#a5ca5b3aadcae68416af7382fc75d2bb0',1,'protozero::pbf_reader']]],
  ['write_5fvarint_345',['write_varint',['../namespaceprotozero.html#af4282d45345a3f82cd78a5786054be30',1,'protozero']]]
];
