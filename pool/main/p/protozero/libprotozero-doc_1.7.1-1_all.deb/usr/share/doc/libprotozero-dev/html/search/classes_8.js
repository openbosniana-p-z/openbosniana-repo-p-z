var searchData=
[
  ['varint_5ftoo_5flong_5fexception_209',['varint_too_long_exception',['../structprotozero_1_1varint__too__long__exception.html',1,'protozero']]]
];
