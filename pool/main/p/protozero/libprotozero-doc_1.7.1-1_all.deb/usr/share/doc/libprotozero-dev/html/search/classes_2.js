var searchData=
[
  ['data_5fview_199',['data_view',['../classprotozero_1_1data__view.html',1,'protozero']]]
];
