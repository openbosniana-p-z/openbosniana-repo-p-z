var searchData=
[
  ['fixed_5fsize_5fbuffer_5fadaptor_202',['fixed_size_buffer_adaptor',['../classprotozero_1_1fixed__size__buffer__adaptor.html',1,'protozero']]]
];
