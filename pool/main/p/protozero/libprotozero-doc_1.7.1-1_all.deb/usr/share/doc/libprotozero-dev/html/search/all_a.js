var searchData=
[
  ['m_5fdata_127',['m_data',['../classprotozero_1_1const__varint__iterator.html#ae1ee98f7eeacb06097bf547b7004a8e2',1,'protozero::const_varint_iterator']]],
  ['m_5fend_128',['m_end',['../classprotozero_1_1const__varint__iterator.html#a58562c36576af044a7347da7353559b4',1,'protozero::const_varint_iterator']]],
  ['max_5fvarint_5flength_129',['max_varint_length',['../namespaceprotozero.html#aa8764084cb14dd32333989057627d620',1,'protozero']]]
];
