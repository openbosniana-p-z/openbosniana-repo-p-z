var searchData=
[
  ['end_5fof_5fbuffer_5fexception_200',['end_of_buffer_exception',['../structprotozero_1_1end__of__buffer__exception.html',1,'protozero']]],
  ['exception_201',['exception',['../structprotozero_1_1exception.html',1,'protozero']]]
];
