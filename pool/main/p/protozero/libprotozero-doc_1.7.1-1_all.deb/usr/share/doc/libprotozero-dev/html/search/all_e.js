var searchData=
[
  ['reserve_174',['reserve',['../classprotozero_1_1basic__pbf__writer.html#a583e6b3f12c62b5b3e5c0cff8c5cdac6',1,'protozero::basic_pbf_writer']]],
  ['rollback_175',['rollback',['../classprotozero_1_1basic__pbf__writer.html#a01b8ee63716693eec0296a008b89743c',1,'protozero::basic_pbf_writer']]]
];
