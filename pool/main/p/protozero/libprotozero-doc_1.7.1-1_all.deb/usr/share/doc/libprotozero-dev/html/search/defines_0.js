var searchData=
[
  ['protozero_5fversion_5fcode_385',['PROTOZERO_VERSION_CODE',['../version_8hpp.html#af15d11f8a409f52e17bc9bf8b04cb13e',1,'version.hpp']]],
  ['protozero_5fversion_5fmajor_386',['PROTOZERO_VERSION_MAJOR',['../version_8hpp.html#a4b95d9219503be246b4dee74b048a0ec',1,'version.hpp']]],
  ['protozero_5fversion_5fminor_387',['PROTOZERO_VERSION_MINOR',['../version_8hpp.html#af4fcf14afa60ac819afc4d047b785e0e',1,'version.hpp']]],
  ['protozero_5fversion_5fpatch_388',['PROTOZERO_VERSION_PATCH',['../version_8hpp.html#aefd38ef90480d80ffd73aab13cf42470',1,'version.hpp']]],
  ['protozero_5fversion_5fstring_389',['PROTOZERO_VERSION_STRING',['../version_8hpp.html#adb88d9e403ac52d851f8edcec6b58dac',1,'version.hpp']]]
];
