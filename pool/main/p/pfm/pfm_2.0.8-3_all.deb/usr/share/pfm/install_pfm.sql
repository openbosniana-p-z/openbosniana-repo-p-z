-- install_pfm.sql

-- Version 1.5.0

-- The character encoding of this file is iso8859-1 (latin1).

-- When imported via the 'Tools -> install pfm_* tables' menu, pfm
-- converts it to UTF-8 before offering it to psql, which is always
-- running with client_encoding 'UNICODE(=UTF-8)' when invoked by pfm.

CREATE TABLE pfm_version (
    seqnr serial NOT NULL,
    version text,
    date date,
    "comment" text
);

INSERT INTO pfm_version (version, "date", comment)
VALUES ('1.5.0', CURRENT_DATE, 'install_pfm.sql');

CREATE TABLE pfm_attribute (
    attribute text NOT NULL,
    typeofattrib text,
    typeofget text,
    sqlselect text,
    nr integer,
    form text NOT NULL,
    valuelist text,
    "default" text
);

CREATE TABLE pfm_form (
    name text NOT NULL,
    tablename text,
    showform boolean DEFAULT true,
    "view" boolean DEFAULT false,
    sqlselect text,
    sqlfrom text,
    groupby text,
    help text,
    pkey text,
    sqlorderby text,
    sqllimit text
);

CREATE TABLE pfm_link (
    linkname text NOT NULL,
    sqlwhere text,
    orderby text,
    displayattrib text,
    fromform text NOT NULL,
    toform text
);

CREATE TABLE pfm_report (
    name text NOT NULL,
    description text,
    sqlselect text
);

CREATE TABLE pfm_section (
    report text NOT NULL,
    "level" integer NOT NULL,
    fieldlist text,
    layout text,
    summary text,
    CONSTRAINT level_min_1 CHECK (("level" >= 1))
);

CREATE TABLE pfm_value (
    value text NOT NULL,
    description text,
    valuelist text NOT NULL
);

CREATE TABLE pfm_value_list (
    name text NOT NULL
);

COPY pfm_attribute (attribute, typeofattrib, typeofget, sqlselect, nr, form, valuelist, "default") FROM stdin;
linkname	taQuoted	tgDirect		1	pfm_link	none	\N
value	taQuoted	tgDirect	\N	2	pfm_value	none	\N
sqlwhere	taQuoted	tgDirect		4	pfm_link	none	\N
orderby	taQuoted	tgDirect		5	pfm_link	none	\N
displayattrib	taQuoted	tgDirect		6	pfm_link	none	\N
description	taQuoted	tgDirect		3	pfm_value	none	\N
name	taQuoted	tgDirect		1	pfm_report	none	\N
description	taQuoted	tgDirect		2	pfm_report	none	\N
report	taQuoted	tgLink	select name, description from pfm_report order by name	1	pfm_section	none	\N
nr	taNotQuoted	tgDirect		7	pfm_attribute	none	\N
name	taQuoted	tgDirect		1	pfm_form	none	\N
tablename	taQuoted	tgDirect		2	pfm_form	none	\N
attribute	taQuoted	tgDirect		2	pfm_attribute	none	\N
sqlselect	taQuoted	tgDirect		5	pfm_attribute	none	\N
form	taQuoted	tgLink	SELECT name FROM pfm_form ORDER BY name	1	pfm_attribute	none	\N
fromform	taQuoted	tgLink	SELECT name FROM pfm_form ORDER BY name	2	pfm_link	none	\N
toform	taQuoted	tgLink	SELECT name FROM pfm_form ORDER BY name	3	pfm_link	none	\N
valuelist	taQuoted	tgLink	SELECT name FROM pfm_value_list ORDER BY name	1	pfm_value	none	\N
name	taQuoted	tgDirect		1	pfm_value_list	none	\N
sqlselect	taQuoted	tgDirect		3	pfm_report	none	\N
sqlselect	taQuoted	tgDirect	\N	4	pfm_form	none	\N
sqlfrom	taQuoted	tgDirect	\N	5	pfm_form	none	\N
groupby	taQuoted	tgDirect		6	pfm_form	none	\N
pkey	taQuoted	tgDirect		3	pfm_form	none	
default	taQuoted	tgDirect		8	pfm_attribute	none	
typeofattrib	taQuoted	tgList		3	pfm_attribute	typeofattribute	taQuoted
typeofget	taQuoted	tgList	\N	4	pfm_attribute	typeofget	tgDirect
valuelist	taQuoted	tgLink	SELECT name FROM pfm_value_list ORDER BY name	6	pfm_attribute	none	none
help	taQuoted	tgDirect		11	pfm_form	none	\N
showform	taQuoted	tgList		9	pfm_form	boolean	t
view	taQuoted	tgList		10	pfm_form	boolean	f
sqlorderby	taQuoted	tgDirect		7	pfm_form	none	
sqllimit	taQuoted	tgDirect		8	pfm_form	none	
summary	taQuoted	tgDirect		6	pfm_section	none	
fieldlist	taQuoted	tgDirect		5	pfm_section	none	\N
layout	taQuoted	tgList		4	pfm_section	layout	table
level	taNotQuoted	tgDirect		3	pfm_section	none	1
sqlselect	taQuoted	tgReadOnly		2	pfm_section	none	
\.

COPY pfm_form (name, tablename, showform, "view", sqlselect, sqlfrom, groupby, help, pkey, sqlorderby, sqllimit) FROM stdin;
pfm_attribute	pfm_attribute	f	f	attribute, typeofattrib, typeofget, sqlselect, nr, form, valuelist, "default"	pfm_attribute	\N	The table "pfm_attribute" defines all the properties of form attributes.\n\nIt has the following attributes:\n\n    - form : the "name" of the form to which the attribute\n      belongs;\n\n    - attribute : the name of the attribute; this must be equal\n      to the name of the corresponding attribute of the form's SQL\n      SELECT statement;\n\n    - typeofattrib : the type of attribute:\n\n        o taQuoted: the value provided by the user is put\n             between single quotes when it is transferred to SQL\n             UPDATE or INSERT statements;\n            \n        o taNotQuoted: the value provided by the user is not\n             quoted when it is transferred to SQL UPDATE or INSERT\n             statements.\n\n          Hint: In general, all attribute values must be quoted, exept\n                the values or expressions for numeric attributes.\n\n    - typeofget: defines how the user provides a value for the\n      attribute; possible values are:\n\n          o tgDirect: the user types the value directly;\n\n          o tgExpression: the user types an expression which is first\n            evaluated before it is passed to SQL UPDATE or INSERT;\n\n            Note: Even with tgDirect it is possible to enter an\n                  expression as new value for an attribute, but then\n                  the expression is evaluated by postgresql whereas\n                  with tgExpression, the expression is first evaluated\n                  by Tcl before the SQL statement is sent to\n                  postgresql.\n\n          o tgList: the user selects a value by means of a list box\n            containing a list of values defined in table "pfm_value";\n\n          o tgLink: the user selects a value by means of a list box\n            containing a list of values which is the result from a\n            query on another table.\n\n          o tgReadOnly: this attribute cannot be modified by\n            the user.\n\n            Note: All calculated attributes and all attributes from\n                  tables other than the form's main table should be\n                  declared 'read-only'. If this rule is not observed,\n                  the Add and Update operations on this form will fail.\n\n    - sqlselect: the SQL SELECT statement which is used to fill the\n      list box with possible values for the attribute (only meaningful\n      if typeofget = tgLink).\n\n      Note :\n\n         o The sqlselect may return more than 1 attribute. If so, all\n           the attributes are displayed in the list-box, but only the\n           first one is used for updating the attribute.\n\n    - valuelist : the "name" of the value list defined in table\n      "pfm_value_list" (only meaningful if typeofget = tgList);\n\n    - nr: a number which determines the order in which attributes are\n      displayed on the form;\n\n    - default: a default value for this attribute which is used when\n      adding a record. If the first character is an '=' sign, the\n      following characters should be an SQL SELECT statement which\n      returns just one value.\n\n      Example:\n\n      default: =SELECT nextval('seq_person_id')\n\n      In this example the default value is the next value of the\n      sequenece 'seq_person_id'.\n	form attribute	form, nr	\N
pfm_link	pfm_link	f	f	linkname, sqlwhere, orderby, displayattrib, fromform, toform	pfm_link	\N	A link is a navigation tool which allows you to follow a "one-to-many"\nor "many-to-one" relationship from one form to another.\n\nEvery link is stored as a record in the pfm_link table, which has the\nfollowing attributes:\n\n    - linkname : the name of the link, which is displayed on\n      a link button on the "fromform";\n\n    - fromform : the name of the form from which the link\n      originates;\n\n    - toform : the name of the form to which the link leads;\n\n    - sqlwhere : the "WHERE"-clause which is used to open the\n      "toform" and in which the value of an attribute of the\n      "fromform" may be represented by $(attrib-x), where\n      'attrib-x' is the name of the attribute;\n\n    - orderby : an 'order by' clause which determines the order of the\n      records in the 'toform';\n\n    - displayattrib : a space separated list of\n      attributes of the 'fromform', the value of which is displayed on\n      the 'toform' to remind the user from which record the link\n      originated.\n\nNote: Postgres Forms does not provide any checks to safeguard\n      the referential integrity of the data base in case of updates or\n      deletions. However, postgreSQL provides these functions as\n      'foreign key' table constraints (see postgreSQL documentation).	fromform linkname	fromform, linkname	\N
pfm_report	pfm_report	f	f	name, description, sqlselect	pfm_report	\N	The table pfm_report defines all the reports for the current data\nbase.\n\npfm_report has the following attributes:\n\n    - name: the name of the report. This is the name that\n      appears in the selection list of the "Run Report" function.\n\n    - description: free text describing the purpose of the\n      report in more detail.\n\n    - sqlselect: an SQL SELECT statement that generates the\n      data for the report.\n\nThe sqlselect may contain one or more parameters for which a\nvalue is requested at "Run report" time. A parameter in the sqlwhere\nmust be formatted as $(parameter_name).\n\nExample:\n\nsqlselect: \n\n    SELECT g.name AS "group", g.description, p.id, p.name,\n           p.christian_name, p.street, p."ZIPcode", p.town, p.country\n    FROM "group" g\n       LEFT JOIN memberlist m ON g.name = m."group"\n       LEFT JOIN person p ON m.person = p.id\n    WHERE "group" = '$(group)'\n    ORDER BY g.name, p.name, p.christian_name\n\nWhen the report is run, the user is prompted to enter a value for the\nparameter "group". Then the report data are generated by executing the\nsqlselect statement in which $(group) is replaced with the value\nentered by the user.	name	name	\N
pfm_value	pfm_value	f	f	value, description, valuelist	pfm_value	\N	The table "pfm_value" contains all the values of the lists defined in\npfm_value_list.\n\nIt has the following attributes:\n\n    - valuelist : the name of the valuelist to which this value belongs\n\n    - value : a character string;\n\n    - description : a description of the value.\n	valuelist value	valuelist, value	\N
pfm_value_list	pfm_value_list	f	f	name	pfm_value_list	\N	The table "pfm_value_list" contains all the value lists of all the forms.\n\nIts only attribute is\n\n    - name : a name uniquely identifying the value list.\n	name	name	\N
pfm_form	pfm_form	f	f	name, tablename, sqlselect, sqlfrom, groupby, showform, "view", help, pkey, sqlorderby, sqllimit	pfm_form	\N	A form allows the user to administer the data of just one table. This\ntable is henceforth referred to as "the form's main table".\n\nHowever, a form also has an SQL SELECT statement, which generates the\ndata that are displayed on it.\n\nIn the simplest case the SQL SELECT statement is just:\n\n    SELECT <attributes of main table> FROM <main table>\n\nIn that case, the data which can be administered and the data which\nare displayed on the form are the same.\n\nIn more complex cases, the <main table> can be JOINED with other\ntables, which makes it possible to display data of other related\ntables as well. These data cannot be modified by means of the form.\n\nThe table "pfm_form" has the following attributes:\n\n    - name : the name of the form (usually equal to the name of\n      the form's table);\n\n    - tablename : the name of the form's main table;\n\n    - pkey : the primary key of the form's main table, which may\n      consist of more than one attribute. In that case pkey is a SPACE\n      separated list of the attributes of the primary key;\n\n      Note: If pkey is empty, the form is read-only, since pfm is\n            unable to uniquely identify a record. You can use the\n            'oid' as primary key, but according to the PostgreSQL\n            documentation that is not recommended, unless you set a\n            UNIQUE constraint on the 'oid'.\n\n    - sqlselect : the attribute list of the form's SQL SELECT\n      statement, not including the word 'SELECT';\n\n    - sqlfrom : the FROM clause of the form's SQL SELECT statement,\n      not including the word 'FROM';\n\n    - groupby : an optional 'GROUP BY' clause, not including the words\n      'GROUP BY';\n\n    - sqlorderby : an optional 'ORDER BY' clause, not including the\n      words 'ORDER BY';\n\n    - sqllimit : an optional 'LIMIT' clause, only specifying the limit\n      value as a positive integer;\n\n      Notes:\n\n          - This enables the designer of the form to avoid excessive\n            memory usage by limiting the number of records loaded in\n            the form's internal buffer. This may be useful for\n            handling large tables.\n\n          - If sqllimit is a positive integer, a\n\n                   LIMIT sqllimit OFFSET 0\n\n            is added to the form's SELECT when opening the form.\n\n            This means that only 'sqllimit' records are loaded into\n            the form's internal buffer. When the user moves beyond the\n            last record in the internal buffer, the internal buffer is\n            first cleared and then reloaded with the next 'sqllimit'\n            records by re-executing the form's SELECT but now with\n            another OFFSET in the LIMIT clause.\n\n          - If sqllimit is an empty string, no LIMIT clause is\n            appended to the form's SELECT.\n\n          - Always specify an 'sqlorderby' if you specify an\n            'sqllimit'.  See PostgreSQL documentation of LIMIT-clause\n            in SELECT statement for more details.\n\n    - showform : a boolean indicating whether the form is shown\n      in "normal mode" (showform = 'true') or in "design mode"\n      (showform = 'false'). Typically, showform is set 'true' for user\n      defined forms and 'false' for the predefined pfm_* forms.\n\n    - view : a boolean indicating whether or not the\n      "tablename" is a view;\n\n    - help : a text which is displayed when the user presses\n      the [Help] key on the form.\n\nThe form's main table is defined by tablename. Only the data of\nthat table can be administered by using the form.\n\nAll the data generated by the form's SQL SELECT statement can be\ndisplayed on the form. The SQL SELECT statement is defined by:\n\n    - the sqlselect, sqlfrom, groupby, sqlorderby and sqllimit\n      attributes of pfm_form; and\n\n    - the optional WHERE and ORDER BY clauses provided by the user\n      when opening the form.\n\nNote: The WHERE clause provided by the user when opening the form, becomes\n      a HAVING clause, if there is a GROUP BY clause.\n\nThe following rules should be observed when filling out sqlselect and\nsqlfrom:\n\n    1. The form's main table must appear in 'sqlfrom', and must not be\n       aliased. Similarly, the main table's attributes appearing in\n       'sqlselect' must not be aliased. The other tables appearing in\n       the 'sqlfrom' may be aliased.\n\n    2. The fields appearing in 'sqlselect' must have a unique, simple\n       name without the need to precede them with a tablename. So,\n       calculated fields must be given a name by aliasing and\n       attributes of tables other than the main table may need to be\n       aliased in order to have a unique, simple name.\n\n    3. The 'sqlfrom' is either just the name of the form's main table,\n       or it is a JOIN clause in which the 'LEFT' table is the form's\n       main table. Several join clauses can be nested in order to\n       involve more than 2 tables. See examples below.\n\n\nExample 1: the SQL SELECT for the person form of the addressbook database\n\n\ntablename:\n    person\n\npkey:\n    id\n\nsqlselect:\n    id, christian_name, name, street, town, "ZIPcode",\n    country, category, description\n\nsqlfrom:\n    person\n\ngroupby:\n    -\n\n\nExample 2: the SQL SELECT for the memberlist form of the addressbook database\n\n\ntablename:\n    memberlist\n\npkey:\n    group person\n\nsqlselect:\n    memberlist."group", memberlist.person, p.christian_name, p.name\n\nsqlfrom:\n    memberlist LEFT OUTER JOIN person p ON (p.id = memberlist.person)\n\ngroupby:\n    -	name	showform DESC, name	\N
pfm_section	pfm_section	f	f	pfm_section.report, r.sqlselect, pfm_section."level", pfm_section.fieldlist,\npfm_section.layout, pfm_section.summary	pfm_section LEFT OUTER JOIN pfm_report r ON (pfm_section.report = r.name)	\N	The data returned by the report's SQL SELECT statement may be\nconsidered as a table with a column for each 'field' specified after\nthe word 'SELECT' and with a row for each record.\n\nBy specifying an 'ORDER BY' clause in the report's SQL SELECT\nstatement, it is possible to group rows with the same values for some\nfields together.\n\nThe report generator has an "economy" algorithm which avoids printing\nthe same data repeatedly.\n\nTo control this you have to distribute the fields (columns) of the\ntable over n sections such that section 1 contains the fields that are\nchanging least frequently (when moving from one row to the next),\nsection 2 contains the fields that are changing more frequently, and\nsection n contains the fields that are changing at every row.\n\nWhen the data of the first row of the table are printed, the data of\nsection 1 are printed first. Then, on the following line, indented by\none tab stop, the data of section 2 are printed. Then, on the\nfollowing line, indented by 2 tab stops, data of section 2 are\nprinted, etc.\n\n[section 1] <--- row 1\n\n    [section 2] <--- row 1\n\n        [section 3]  <--- row 1\n\nThen, when the next rows are being printed, data of the lower numbered\nsections are only printed if they are different from the data of the\nlast printed section of the same number:\n\n[section 1]\n\n    [section 2]\n\n        [section 3]  <--- row 1\n        [section 3]  <--- row 2\n        [section 3]  <--- row 3\n\n    [section 2]\n\n        [section 3]  <--- row 4\n        [section 3]  <--- row 5\n\n[section 1]\n\n    [section 2]\n\n        [section 3]  <--- row 6\n        [section 3]  <--- row 7\n\nThe report generator also enables you to print a summary at every\npoint where a higher numbered section is about to be followed by a\nlower numbered section:\n\n[section 1]\n\n    [section 2]\n\n        [section 3]  <--- row 1\n        [section 3]  <--- row 2\n        [section 3]  <--- row 3\n\n        [summary 3]\n\n    [section 2]\n\n        [section 3]  <--- row 4\n        [section 3]  <--- row 5\n\n        [summary 3]\n\n    [summary 2]\n\n[section 1]\n\n    [section 2]\n\n        [section 3]  <--- row 6\n        [section 3]  <--- row 7\n\n        [summary 3]\n\n    [summary 2]\n\n[summary 1]\n\nA summary i is printed just before a lower numbered section j (j < i).\nIts data can be calculated:\n\n    - by applying one of the aggregate funtions: COUNT, SUM, AVG,\n      STDDEV, MIN, MAX;\n\n    - on the fields of the sections j (j >= i), between the last\n      printed lower numbered section k (k < i), till the next (not\n      yet printed) lower numbered section k (k < i).\n\nIn particular, summary 1 is printed at the end of the report, is\ncalculated from all the sections of the report and may be calculated\nfrom all the fields.\n\nA record in pfm_section defines a section and a summary of a report.\n\nThe table pfm_section has the following attributes:\n\n    - report: the name of the report to which the section belongs\n\n    - level: a number 1, 2, 3, 4, ... . The first level must be\n      '1'. The next levels must be numbered consecutively. In the most\n      simple report, there is only a section with level 1.\n\n    - layout: can be "row", "column" or "table".\n\n    - fieldlist: a space separated list of field specifiers,\n      one for each field to be printed in the sections of this level\n      (see below for details).\n\n    - summary: a space separated list of summary field\n      specifiers (see below for details).\n\nThe fieldlist is a SPACE separated list of field specifiers\n\n    field_spec_1 field_spec_2 ... field_spec_N\n\nwhere each field specifier is formatted as follows:\n\n    {field_i label_i alignment_i max_length_i}\n\nwhere :\n\n    - field_i is the name of one of the columns returned by the\n      report's SQL SELECT statement;\n\n    - label_i is a string which has to be used as label for printing\n      the i-th field of this section; if it consists of more than 1\n      word, it must be delimited by double quotes (" .... ");\n\n    - alignment_i is optional; if present, it is either l or r,\n      indicating whether this field should be left or right aligned.\n\n    - max_length_i is optional: if present, it is the maximum number\n      of characters per line for printing the data of this field;\n      lines longer than max_length_i will be wrapped by inserting\n      one or more line breaks before printing.\n\n      Notes :\n\n          o The alignment is optional. If it is left out, left\n            alignment is assumed by default.\n\n          o The alignment only influences the table layout. Column and\n            row layouts are unaffected by the alignment indicator.\n\n          o Multi-line fields, i.e. fields containing more than one\n            line of text are only formatted properly in a column or\n            table layout.\n\n          o For a table layout, pfm automatically calculates the column\n            width that is required to display all data. So, normally\n            you don't have to worry about column widths. However,\n            sometimes, the data of a few records, make the columns\n            excessively wide. That is where you might consider using\n            "max_length_i" in the field specifier. If the data do not\n            exceed that maximum, it won't have any effect.\n\n          o Although 'alignment' and 'max_length' are both optional,\n            you have to specify 'alignment' if you want to specify\n            max_length.\n\nFor every section, the layout can be defined as:\n\n    - row: the section's field labels and field values are\n      printed in one row in a format: label_1 : value_1; label_2 :\n      value_2; ... etc.\n\n    - column: the section's field labels are printed in a first\n      column, the section's field values are printed in a second column.\n\n    - table: the section's values are printed in a table with a\n      column per field and a row per record, the section's field\n      labels are used as column headers for the table.\n\nThe summary must be formatted as a space separated list of summary\nspecifiers:\n\n    summary_spec_1 summary_sepc_2 .... summary_sepc_N\n\nwhere each summary_spec is formatted as follows:\n\n    {field_i aggregate_i format_i}\n\nwhere:\n\n    - field_i is the name of a field defined in the fieldlist of\n      either this section, or another, higher numbered section;\n\n    - aggregate_i is one of the aggregate functions: COUNT, SUM, AVG,\n      STDDEV, MIN, MAX (see below for details); and\n\n    - format_i is an optional 'ANSI C sprintf' formatting string (see\n      below for details). If it is left out, the number is printed\n      with maximum precision.\n\n\nAggregate functions:\n\nIn general, the aggregate functions, use the same "economy" algorithm\nthat is used for printing section data.\n\nWhen all the fields of a section, which is not the highest numbered\nsection of the report, have the same values for a number of\nconsecutive rows, this section's data are only printed once for these\nrows.\n\nSimilarly, these rows are only counted once by the aggregate functions\napplied to a field of this section.\n\nThe aggregate functions that can be used in a summary are:\n\n    - COUNT: Counts the number of rows. In this case, the field_i that\n           is specified only determines which section is counted.\n\n    - SUM: Calculates the sum of all the values of the specified\n           field.\n\n    - AVG: Calculates the average of the values of the specified\n           field.\n\n    - STDDEV: Calculates the sample standard deviation for the values of the\n           specified field:\n\n           SQRT (SUM( (value_i - AVG(value))**2 ) / (N - 1))\n\n\t   where :\n\n               - value_1, value_2, ... value_N are the values of the\n                 considered field;\n\n               - AVG(value) is the average of the considered values;\n\n               - N is the number of values.\n\n    - MIN: Calculates the minimum of the values of the specified\n           field.\n\n    - MAX: Calculated the maximum of the values of the specified\n           field.\n\n\n'ANSI C sprintf' formatting string:\n\nHere is a short overview of the 'ANSI C sprintf' formatting string. In\ngeneral its form is:\n\n     %'MinWidth'.'Precision''Conversion'\n\nwhere:\n\n    - 'MinWidth' is an integer defining the minimum width (as number\n      of characters) for the number to be printed. If the number does\n      not need so much space, spaces are inserted in front of the\n      number, unless MinWidth is negative. In that case, spaces are\n      appended at the end. If the number needs more space than\n      MinWidth, more space is used.\n\n    - 'Precision' is an integer defining how many digits to print\n      after the decimal point, or, in the case of g or G conversion,\n      the total number of digits to appear, including those on both\n      sides of the decimal point\n\n    - 'Conversion' is one of:\n\n          o d : convert integer to signed decimal string. In this case,\n                there is no need to define a 'Precision'.\n\n                Example: %1d\n\n                         prints an integer and uses as many characters\n                         as required.\n\n          o f : convert floating point number to fixed point\n                notation. In this case, 'Precision' defines the number\n                of digits to print after the decimal point. If there\n                are not enough digits available, trailing zeroes are\n                appended.\n\n                Example: %1.2f\n\n                         prints a floating point number wiht 2 digits\n                         after the decimal point and uses as many\n                         characters as required.\n\n          o e or E : Convert floating-point number to scientific\n                notation in the form x.yyye�zz, where the number of\n                y's is determined by the 'Precision' (default: 6). If\n                the precision is 0 then no decimal point is output. If\n                the E form is used then E is printed instead of e.\n\n                Example: %1.5E\n\n                         prints a floating point number in the form\n                         x.yyyyy E�zz \n\n          o g or G : If the exponent is less than -4 or greater than\n                or equal to the precision, then convert floating-point\n                number as for %e or %E. Otherwise convert as for\n                %f. Trailing zeroes and a trailing decimal point are\n                omitted. In this case the 'Precision' specifies the\n                total number of digits to appear, including those on\n                both sides of the decimal point\n\n                Example: %1.4G\n\n                          prints 2345.0 as 2345\n                          prints 234567.0 as 2.346E+05\n                          prints 0.003456 as 0.003456\n                          prints 0.00003456 as 3.456E-05	report level	report, "level"	\N
\.

COPY pfm_link (linkname, sqlwhere, orderby, displayattrib, fromform, toform) FROM stdin;
Report	name='$(report)'		level	pfm_section	pfm_report
Sections	report='$(name)'	level	name	pfm_report	pfm_section
Attributes	form='$(name)'	nr	name	pfm_form	pfm_attribute
incoming links	toform='$(name)'	fromform	name	pfm_form	pfm_link
outgoing links	fromform='$(name)'	toform	name	pfm_form	pfm_link
Where used?	valuelist='$(name)'		name	pfm_value_list	pfm_attribute
Values	valuelist='$(name)'	value	name	pfm_value_list	pfm_value
Value list	name='$(valuelist)'		attribute	pfm_attribute	pfm_value_list
from Form	name='$(fromform)'		linkname	pfm_link	pfm_form
to Form	name='$(toform)'		linkname	pfm_link	pfm_form
Valuelist	name='$(valuelist)'		value	pfm_value	pfm_value_list
Form	name='$(form)'		attribute	pfm_attribute	pfm_form
\.

COPY pfm_report (name, description, sqlselect) FROM stdin;
\.

COPY pfm_section (report, "level", fieldlist, layout, summary) FROM stdin;
\.

COPY pfm_value (value, description, valuelist) FROM stdin;
taQuoted	Value must be enclosed in ' ' for SQL.	typeofattribute
taNotQuoted	Value must not be enclosed in ' ' for SQL.	typeofattribute
tgDirect	Value directly typed by user.	typeofget
tgExpression	Value may be given as an expression.	typeofget
tgList	Value comes from a valuelist.	typeofget
tgLink	Value comes from 'sqlselect'.	typeofget
t	TRUE	boolean
f	FALSE	boolean
column	A column for the labels, a second column for the corresponding values	layout
table	A table with the labels as table header	layout
row	Labels and values on 1 row	layout
tgReadOnly	User cannot change the value of this attribute	typeofget
\.

COPY pfm_value_list (name) FROM stdin;
typeofattribute
typeofget
boolean
layout
none
\.

ALTER TABLE ONLY pfm_attribute
    ADD CONSTRAINT pfm_attribute_pkey PRIMARY KEY (form, attribute);

ALTER TABLE ONLY pfm_form
    ADD CONSTRAINT pfm_form_pkey PRIMARY KEY (name);

ALTER TABLE ONLY pfm_link
    ADD CONSTRAINT pfm_link_pkey PRIMARY KEY (fromform, linkname);

ALTER TABLE ONLY pfm_report
    ADD CONSTRAINT pfm_report_pkey PRIMARY KEY (name);

ALTER TABLE ONLY pfm_section
    ADD CONSTRAINT pfm_section_pkey PRIMARY KEY (report, "level");

ALTER TABLE ONLY pfm_value_list
    ADD CONSTRAINT pfm_value_list_pkey PRIMARY KEY (name);

ALTER TABLE ONLY pfm_value
    ADD CONSTRAINT pfm_value_pkey PRIMARY KEY (valuelist, value);

ALTER TABLE ONLY pfm_version
    ADD CONSTRAINT pfm_version_pkey PRIMARY KEY (seqnr);

ALTER TABLE ONLY pfm_attribute
    ADD CONSTRAINT ref_form FOREIGN KEY (form) REFERENCES pfm_form(name) ON UPDATE CASCADE ON DELETE CASCADE;

ALTER TABLE ONLY pfm_link
    ADD CONSTRAINT ref_fromform FOREIGN KEY (fromform) REFERENCES pfm_form(name) ON UPDATE CASCADE ON DELETE CASCADE;

ALTER TABLE ONLY pfm_value
    ADD CONSTRAINT ref_list FOREIGN KEY (valuelist) REFERENCES pfm_value_list(name) ON UPDATE CASCADE ON DELETE CASCADE;

ALTER TABLE ONLY pfm_section
    ADD CONSTRAINT ref_sections FOREIGN KEY (report) REFERENCES pfm_report(name) ON UPDATE CASCADE ON DELETE CASCADE;

ALTER TABLE ONLY pfm_link
    ADD CONSTRAINT ref_toform FOREIGN KEY (toform) REFERENCES pfm_form(name) ON UPDATE CASCADE ON DELETE CASCADE;

ALTER TABLE ONLY pfm_attribute
    ADD CONSTRAINT ref_value_list FOREIGN KEY (valuelist) REFERENCES pfm_value_list(name) ON UPDATE CASCADE ON DELETE RESTRICT;

