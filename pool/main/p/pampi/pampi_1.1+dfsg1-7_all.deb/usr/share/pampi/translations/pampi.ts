<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>Dialog</name>
    <message>
        <location filename="../libs/plugins/ui_video.py" line="134"/>
        <source>Video parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_audio.py" line="130"/>
        <source>Identifier:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_video.py" line="140"/>
        <source>Poster Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_video.py" line="135"/>
        <source>Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_video.py" line="139"/>
        <source>Choose the poster image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_video.py" line="136"/>
        <source>Video properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_video.py" line="141"/>
        <source>Video starters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_audio.py" line="133"/>
        <source>Add starter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_audio.py" line="132"/>
        <source>Starter&apos;s name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_audio.py" line="127"/>
        <source>Audio parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_audio.py" line="128"/>
        <source>Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_audio.py" line="129"/>
        <source>Audio properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_audio.py" line="131"/>
        <source>Audio starters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_anim.py" line="61"/>
        <source>Animation settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_anim.py" line="63"/>
        <source>Animation range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_anim.py" line="64"/>
        <source>Global</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_anim.py" line="65"/>
        <source>Text only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_anim.py" line="66"/>
        <source>div</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_anim.py" line="62"/>
        <source>class=&quot;anim-rotate-x&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_anim.py" line="68"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_anim.py" line="67"/>
        <source>Animation contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_title.py" line="74"/>
        <source>Make a title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_title.py" line="75"/>
        <source>Title category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_title.py" line="76"/>
        <source>Level 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_title.py" line="77"/>
        <source>Level 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_title.py" line="78"/>
        <source>Level 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_title.py" line="79"/>
        <source>Level 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_title.py" line="80"/>
        <source>Level 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/ui_title.py" line="81"/>
        <source>Title contents</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../libs/ui_main.py" line="331"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="333"/>
        <source>Title:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="337"/>
        <source>CSS:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="340"/>
        <source>Color:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="374"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="343"/>
        <source>Tools:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="383"/>
        <source>Cheat Sheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="347"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="349"/>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="381"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="353"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="354"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="355"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="356"/>
        <source>Open file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="357"/>
        <source>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="363"/>
        <source>Presentation in full screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="359"/>
        <source>Open presentations dir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="377"/>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="360"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="361"/>
        <source>Save file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="362"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="364"/>
        <source>Toggle fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="365"/>
        <source>Ctrl+F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="367"/>
        <source>View in web browser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="368"/>
        <source>Ctrl+B, Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="369"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="348"/>
        <source>Recent Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="370"/>
        <source>Wizard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="371"/>
        <source>Save as...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="372"/>
        <source>Export the presentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="373"/>
        <source>Create a launcher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="375"/>
        <source>Background color of presentation. Click to edit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="376"/>
        <source>Save, convert and preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="366"/>
        <source>Open in the browser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="350"/>
        <source>Other Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="378"/>
        <source>Create PDF file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="358"/>
        <source>Open the presentation folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="379"/>
        <source>Move the presentation folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="380"/>
        <source>Update the presentation folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="382"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="335"/>
        <source>Here you can define the title that will be displayed in the browser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="339"/>
        <source>If you are using a custom CSS file, enter its name here (without extension)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="342"/>
        <source>Some additional tools for your presentations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="344"/>
        <source>Make the file editable to add your own examples</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="346"/>
        <source>Edit Cheat Sheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/ui_main.py" line="384"/>
        <source>A list of examples to copy-paste</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../libs/utils.py" line="249"/>
        <source>Select a directory for presentations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="501"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="616"/>
        <source>Save as...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_about.py" line="85"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="361"/>
        <source>The file has been modified.
Do you want to save your changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="616"/>
        <source>Markdown Files (*.md)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="612"/>
        <source>No name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="651"/>
        <source>Select a directory to export the presentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="721"/>
        <source>Choose the Directory where the desktop file will be created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="769"/>
        <source>PANDOC IS NOT INSTALLED.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="771"/>
        <source>This is the tool to convert Markdown files to html.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="773"/>
        <source>See the PAMPI help page:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="817"/>
        <source>Cannot read file {0}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="939"/>
        <source>Select a directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="966"/>
        <source>This action will update the tools and examples provided with PAMPI.
Your personal files will not be deleted.

Do you want to continue ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/main.py" line="1036"/>
        <source>Select color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_about.py" line="62"/>
        <source>About {0}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_about.py" line="66"/>
        <source>(version {0})</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_about.py" line="88"/>
        <source>License</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_about.py" line="93"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_functions.py" line="165"/>
        <source>information message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_functions.py" line="166"/>
        <source>question message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_functions.py" line="167"/>
        <source>warning message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_functions.py" line="168"/>
        <source>critical message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_functions.py" line="208"/>
        <source>END !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_functions.py" line="209"/>
        <source>Images are saved in the folder:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_pdf.py" line="115"/>
        <source>PDF export configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_pdf.py" line="118"/>
        <source>YES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_pdf.py" line="120"/>
        <source>NO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_pdf.py" line="136"/>
        <source>Print the notes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_pdf.py" line="149"/>
        <source>Open the html file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_pdf.py" line="162"/>
        <source>Create the PDF file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_pdf.py" line="175"/>
        <source>PDF file name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_pdf.py" line="180"/>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_wizard.py" line="186"/>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_wizard.py" line="190"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_pdf.py" line="221"/>
        <source>pdf File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_pdf.py" line="224"/>
        <source>pdf files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_wizard.py" line="64"/>
        <source>File Creation Wizard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_wizard.py" line="66"/>
        <source>Select a presentation template and then use the available settings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_wizard.py" line="90"/>
        <source>regular polygon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_wizard.py" line="91"/>
        <source>arrangement in table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_wizard.py" line="92"/>
        <source>circular helix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_wizard.py" line="93"/>
        <source>carousel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_wizard.py" line="100"/>
        <source>Presentation template:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_wizard.py" line="111"/>
        <source>Number of steps (not counting the title):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_wizard.py" line="121"/>
        <source>Radius:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_wizard.py" line="131"/>
        <source>Offset:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_wizard.py" line="141"/>
        <source>Number of columns:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_wizard.py" line="151"/>
        <source>Number of rows:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_wizard.py" line="172"/>
        <source>Copy only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/utils_wizard.py" line="174"/>
        <source>If you check this box, the result will be copied to the clipboard instead of replacing your current file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/image.py" line="25"/>
        <source>Insert an image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/_template.py" line="38"/>
        <source>Insert some template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/_template.py" line="73"/>
        <source>Generic plugin, does nothing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/image.py" line="44"/>
        <source>Open Image File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/video.py" line="249"/>
        <source>Images (*.png *.xpm *.jpg *.jpeg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/video.py" line="179"/>
        <source>Insert a video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/video.py" line="197"/>
        <source>Open Video File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/video.py" line="197"/>
        <source>Videos (*.webm *.mkv *.ogv *.avi *.mov *.wmv *.mp4 *.m4v *.mpg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/video.py" line="249"/>
        <source>Open Poster Image File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/audio.py" line="81"/>
        <source>Unnamed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/audio.py" line="166"/>
        <source>Insert an audio track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/audio.py" line="184"/>
        <source>Open Audio File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/audio.py" line="184"/>
        <source>Audios (*.wav *.ogg *.mp3 *.m4a *.wma)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/image.py" line="44"/>
        <source>Images (*.gif *.png *.xpm *.jpg *.jpeg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/anim_rotate_x.py" line="18"/>
        <source>Make a rotation around X axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/anim_rotate_x.py" line="18"/>
        <source>Rotate X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/anim_rotate_y.py" line="18"/>
        <source>Make a rotation around Y axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/anim_rotate_y.py" line="18"/>
        <source>Rotate Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/anim_rotate_z.py" line="18"/>
        <source>Make a rotation around Z axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/anim_rotate_z.py" line="18"/>
        <source>Rotate Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/anim_rotate_y_infinite.py" line="18"/>
        <source>Make an oscillation around Y axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/anim_rotate_y_infinite.py" line="18"/>
        <source>Oscillate Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/anim_scale.py" line="18"/>
        <source>Make a scaling animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/anim_scale.py" line="18"/>
        <source>Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/title.py" line="55"/>
        <source>Make a title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/title.py" line="71"/>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/bold.py" line="18"/>
        <source>Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/_font_template.py" line="67"/>
        <source>REPLACE ME</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/_template.py" line="67"/>
        <source>Module name: {}, icon: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/italic.py" line="18"/>
        <source>Italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/tt.py" line="18"/>
        <source>Typewriter text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libs/plugins/underlined.py" line="18"/>
        <source>Underlined</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
