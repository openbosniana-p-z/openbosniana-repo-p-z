<!--
HEADER FOR PAMPI CONFIG
TITLE:titre
-->




#  {.step data-scale=4}

## 5 QUESTIONS




#  {.step data-x=-6000 data-y=3000 data-scale=1 data-rotate=0}

## Question 1

![](data/pampi-help/splash.png)




#  {.step data-x=-3000 data-y=4000}

## Question 2

![](data/pampi-help/splash.png)




#  {.step data-x=0 data-y=5000}

## Question 3

![](data/pampi-help/splash.png)




# {.step data-x=3000 data-y=4000}

## Question 4

![](data/pampi-help/splash.png)




#  {.step data-x=6000 data-y=3000}

## Question 5

![](data/pampi-help/splash.png)









# {#overview .step data-x=0 data-y=0 data-scale=15}
