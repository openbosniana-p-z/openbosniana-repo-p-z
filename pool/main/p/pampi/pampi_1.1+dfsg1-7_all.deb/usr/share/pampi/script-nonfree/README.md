The script `pampi-nonfree`
==========================

The script `pampi-nonfree` is used to install some missing files, in the
context of a free-libre distribution (for instance with a Debian package)

Here is a copy of the begin of the file debian/copyright which is used
to create a free-libre debian package, complying with
[the Debian Free Software Guidelines](https://www.debian.org/social_contract#guidelines):

```
Format: https://www.debian.org/doc/packaging-manuals/copyright-format/1.0/
Files-Excluded: pampi/presentations/assets/css/bootstrap*
 pampi/presentations/assets/fonts/*
 pampi/presentations/assets/js/impress.js
 pampi/presentations/assets/tools/D3/c3*.js
 pampi/presentations/assets/tools/D3/d3*.js
 pampi/presentations/assets/tools/GeoGebra/deployggb.js
 pampi/presentations/assets/tools/JSXGraph/*
 pampi/presentations/assets/tools/katex/fonts/*
 pampi/presentations/assets/tools/katex/katex*
 pampi/presentations/assets/tools/katex/auto-render.min.js
 pampi/files/md/bootstrap*
 pampi/files/md/marked*
 pampi/libs/win/pandoc.exe
 pampi/libs/icons
 pampi/translations/*.qm
 pampi/presentations/assets/tools/Vis/vis*
```

Replacement of excluded files:
==============================

Links to other Debian packages
------------------------------

Most of the excluded files already exist in other already distributed
Debian packages, so it is the consequence of a non-redundancy principle to
replace them by links to equivalent files, which Debian provides.

The packages which provide those files are *dependencies*, whose list is:

>   pandoc, libjs-bootstrap(>=3.4.1+dfsg-2), fonts-sil-andika,
>   fonts-opendyslexic, libjs-impress(>=1.0.0-1), hovercraft (>=2.7-2),
>   libjs-c3 (>=0.4.11+dfsg-4), jsxgraph, fonts-katex, libjs-katex,
>   libjs-marked, macaulay2-common

Downloading non-free files
--------------------------

A few files cannot be distributed accordingly with
[the Debian Free Software Guidelines](https://www.debian.org/social_contract#guidelines),
for various reasons:

 - non-commercial license (hence non-free)
 - difficulties to find the author and the license, even when the file was spread around Internet, and may probably be thought of as a "Public Domain" file.
 - the file exists in a format which is not human-readable: it can be the case of minified JS or CSS files, where all carriage returns and indentations have been removed, which makes the source rather tough.

In such a case, the script `pampi-nonfree` allows on to download those files,
if one agrees with their license peculiarities. The files are installed in
user space (the user who accepted this installation), they are not available
for other users on the same computer.
