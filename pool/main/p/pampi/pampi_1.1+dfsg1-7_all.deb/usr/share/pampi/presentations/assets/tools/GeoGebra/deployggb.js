/**
 * this file is here just to inform about the missing file
 * deployggb.js
 **/

window.onload = function(){
    alert("The file deployggb.js is not currently installed, as there are\n" +
	  "some issues with its distribution in a free-libre Debian package.\n" +
	  "Some features of this presentation may not work. You can try\n" +
	  "to launch the utility pampi-nonfree to install this file\n" +
	  "from another source.")
}
