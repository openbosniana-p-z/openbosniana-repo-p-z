<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>Dialog</name>
    <message>
        <location filename="ui_pampi_nonfree.py" line="67"/>
        <source>PAMPI non-free files download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_pampi_nonfree.py" line="68"/>
        <source>Please read information about authors and licenses of the files you want to download.
Then you can check those files which are interesting for download.

Some files cannot be distributed in the Debian package &quot;pampi&quot;, because their are non-free, or because they are frozen old versions of files currently distributed by Debian.

If you want to install them, please have a look at their licenses and copyrights, then download them, so they will be installed in your user space.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_pampi_nonfree.py" line="74"/>
        <source>deployggb.js</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_pampi_nonfree.py" line="75"/>
        <source>Install deployggb.js</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_pampi_nonfree.py" line="76"/>
        <source>@author: GeoGebra - Dynamic Mathematics for Everyone, http://www.geogebra.org

@license: This file is subject to the GeoGebra Non-Commercial License Agreement, see http://www.geogebra.org/license. For questions please write us at office@geogebra.org. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_pampi_nonfree.py" line="79"/>
        <source>Vis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_pampi_nonfree.py" line="80"/>
        <source>Install vis.min.css and vis.min.js</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_pampi_nonfree.py" line="81"/>
        <source>vis.js
======

https://github.com/almende/vis

A dynamic, browser-based visualization library.

@version 4.18.1
@date    2017-01-29

@license
Copyright (C) 2011-2016 Almende B.V, http://almende.com

Vis.js is dual licensed under both

* The Apache 2.0 License
  http://www.apache.org/licenses/LICENSE-2.0

and

* The MIT License
  http://opensource.org/licenses/MIT

Vis.js may be distributed under either license.
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MonDialogue</name>
    <message>
        <location filename="pampi-nonfree" line="57"/>
        <source>Download OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pampi-nonfree" line="59"/>
        <source>Download Failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pampi-nonfree" line="59"/>
        <source>{} is not downloaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pampi-nonfree" line="57"/>
        <source>{} was successfully downloaded,
to{}</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
