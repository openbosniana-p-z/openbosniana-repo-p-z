<!--
HEADER FOR PAMPI CONFIG
TITLE:titre
-->




#  {.step data-x=-5000 data-y=-5000 data-rotate=360 data-scale=4}

## TABLEAU







#  {.step data-x=-4000 data-y=-2000}

## 1

![](data/pampi-help/splash.png)



#  {.step data-x=-2000 data-y=-2000}

## 2

![](data/pampi-help/splash.png)



#  {.step data-x=0 data-y=-2000}

## 3

![](data/pampi-help/splash.png)



#  {.step data-x=2000 data-y=-2000}

## 4

![](data/pampi-help/splash.png)



#  {.step data-x=4000 data-y=-2000}

## 5

![](data/pampi-help/splash.png)



#  {.step data-x=6000 data-y=-2000}

## 6

![](data/pampi-help/splash.png)








#  {.step data-x=-4000 data-y=0}

## 7

![](data/pampi-help/splash.png)



#  {.step data-x=-2000 data-y=0}

## 8

![](data/pampi-help/splash.png)



#  {.step data-x=0 data-y=0}

## 9

![](data/pampi-help/splash.png)



#  {.step data-x=2000 data-y=0}

## 10

![](data/pampi-help/splash.png)



#  {.step data-x=4000 data-y=0}

## 11

![](data/pampi-help/splash.png)



#  {.step data-x=6000 data-y=0}

## 12

![](data/pampi-help/splash.png)








#  {.step data-x=-4000 data-y=2000}

## 13

![](data/pampi-help/splash.png)



#  {.step data-x=-2000 data-y=2000}

## 14

![](data/pampi-help/splash.png)



#  {.step data-x=0 data-y=2000}

## 15

![](data/pampi-help/splash.png)



#  {.step data-x=2000 data-y=2000}

## 16

![](data/pampi-help/splash.png)



#  {.step data-x=4000 data-y=2000}

## 17

![](data/pampi-help/splash.png)



#  {.step data-x=6000 data-y=2000}

## 18

![](data/pampi-help/splash.png)










# {#overview .step data-x=0 data-y=0 data-scale=15}
