Le script `pampi-nonfree`
=========================

Le script `pampi-nonfree` sert à mettre en place quelques pièces manquantes,
dans le cadre d'une distribution libre (par exemple avec un paquet Debian)

Voici une copie du début du fichier debian/copyright qui est utilisé
pour créer un paquet libre selon
[la charte Debian](https://www.debian.org/social_contract#guidelines) :

```
Format: https://www.debian.org/doc/packaging-manuals/copyright-format/1.0/
Files-Excluded: pampi/presentations/assets/css/bootstrap*
 pampi/presentations/assets/fonts/*
 pampi/presentations/assets/js/impress.js
 pampi/presentations/assets/tools/D3/c3*.js
 pampi/presentations/assets/tools/D3/d3*.js
 pampi/presentations/assets/tools/GeoGebra/deployggb.js
 pampi/presentations/assets/tools/JSXGraph/*
 pampi/presentations/assets/tools/katex/fonts/*
 pampi/presentations/assets/tools/katex/katex*
 pampi/presentations/assets/tools/katex/auto-render.min.js
 pampi/files/md/bootstrap*
 pampi/files/md/marked*
 pampi/libs/win/pandoc.exe
 pampi/libs/icons
 pampi/translations/*.qm
 pampi/presentations/assets/tools/Vis/vis*
```

Remplacement des fichiers exclus
================================

Liens à d'autres paquets Debian
-------------------------------

Pour la plupart d'entre eux, les fichiers exclus du paquet source pour Debian
existent déjà dans la distribution, et c'est appliquer un principe de
non-redondance que de remplacer ces fichiers par des liens vers les fichiers
équivalents, que la distribution Debian fournit.

Les paquets qui fournissent ces fichiers sont autant de *dépendances*, dont
la liste est :

>   pandoc, libjs-bootstrap(>=3.4.1+dfsg-2), fonts-sil-andika,
>   fonts-opendyslexic, libjs-impress(>=1.0.0-1), hovercraft (>=2.7-2),
>   libjs-c3 (>=0.4.11+dfsg-4), jsxgraph, fonts-katex, libjs-katex,
>   libjs-marked, macaulay2-common

Téléchargement des fichiers non-libres
--------------------------------------

Quelques fichiers ne peuvent pas être distribués en conformité avec
 [la charte Debian](https://www.debian.org/social_contract#guidelines),
 pour des raisons diverses :

 - licence non-commerciale (donc non libre)
 - difficulté à retrouver l'auteur et la licence, même quand ce fichier s'est trouvé répandu sur plusieurs sites web, et fait probablement partie d'un « domaine commun » au sens large
 - fichier existant sous une forme difficile à lire pour un humain : ça peut être le cas de fichiers JS ou CSS minifiés, où tous les passages à la ligne ont été supprimés, ainsi que les indentations qui facilitent la compréhension de la source.

Dans ce cas, le script `pampi-nonfree` permet de télécharger ces fichiers,
si on est d'accord avec les particularités de leurs licences. Les fichiers
sont installés dans la zone personnelle propre à l'utilisateur qui a
accepté cette installation, ils ne se mettent pas en place pour tous les
utilisateurs du même ordinateur.
