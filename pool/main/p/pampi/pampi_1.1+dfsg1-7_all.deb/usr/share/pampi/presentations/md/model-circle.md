<!--
HEADER FOR PAMPI CONFIG
TITLE:titre
-->


# {.step data-scale=4}

##  CERCLE







# {.step data-x=5000 data-scale=2 data-rotate=-90}

##  1

![](data/pampi-help/splash.png)



# {.step data-x=3536 data-y=-3536 data-scale=2 data-rotate=-135}

##  2

![](data/pampi-help/splash.png)



# {.step data-x=0 data-y=-5000 data-scale=2 data-rotate=-180}

##  3

![](data/pampi-help/splash.png)



# {.step data-x=-3536 data-y=-3536 data-scale=2 data-rotate=-225}

##  4

![](data/pampi-help/splash.png)



# {.step data-x=-5000 data-y=0 data-scale=2 data-rotate=-270}

##  5

![](data/pampi-help/splash.png)



# {.step data-x=-3536 data-y=3536 data-scale=2 data-rotate=-315}

##  6

![](data/pampi-help/splash.png)



# {.step data-x=0 data-y=5000 data-scale=2 data-rotate=-360}

##  7

![](data/pampi-help/splash.png)





# {.step data-x=3536 data-y=3536 data-scale=2 data-rotate=-405}

##  8

![](data/pampi-help/splash.png)









# {#overview .step data-x=0 data-y=0 data-scale=15}
