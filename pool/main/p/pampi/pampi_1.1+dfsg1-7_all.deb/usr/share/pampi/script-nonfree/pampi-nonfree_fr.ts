<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr">
<context>
    <name>Dialog</name>
    <message>
        <location filename="ui_pampi_nonfree.py" line="67"/>
        <source>PAMPI non-free files download</source>
        <translation>Téléchargement de fichiers : PAMPI non-libre</translation>
    </message>
    <message>
        <location filename="ui_pampi_nonfree.py" line="68"/>
        <source>Please read information about authors and licenses of the files you want to download.
Then you can check those files which are interesting for download.

Some files cannot be distributed in the Debian package &quot;pampi&quot;, because their are non-free, or because they are frozen old versions of files currently distributed by Debian.

If you want to install them, please have a look at their licenses and copyrights, then download them, so they will be installed in your user space.</source>
        <translation>Veuillez lire les informations au sujet des auteurs et des licences pour le fichiers à télécharger.
Vous pourrez alors cocher les fichiers qui vous intéressent.

Quelques fichiers ne peuvent être distribués dans le paquet Debian « pampi », parce qu'ils sont non-libres, ou parce que ce sont des versions anciennes « gelées » de fichiers distribués actuellement par Debian.

Si vous voulez les installer, veuillez examiner leur licence et leur copyright, puis les télécharger ; alors ils seront installés dans votre espace utilisateur.</translation>
    </message>
    <message>
        <location filename="ui_pampi_nonfree.py" line="74"/>
        <source>deployggb.js</source>
        <translation>deployggb.js</translation>
    </message>
    <message>
        <location filename="ui_pampi_nonfree.py" line="75"/>
        <source>Install deployggb.js</source>
        <translation>Installer deployggb.js</translation>
    </message>
    <message>
        <location filename="ui_pampi_nonfree.py" line="76"/>
        <source>@author: GeoGebra - Dynamic Mathematics for Everyone, http://www.geogebra.org

@license: This file is subject to the GeoGebra Non-Commercial License Agreement, see http://www.geogebra.org/license. For questions please write us at office@geogebra.org. </source>
        <translation>@author: GeoGebra - Dynamic Mathematics for Everyone, http://www.geogebra.org

@license: This file is subject to the GeoGebra Non-Commercial License Agreement, see http://www.geogebra.org/license. For questions please write us at office@geogebra.org. </translation>
    </message>
    <message>
        <location filename="ui_pampi_nonfree.py" line="91"/>
        <source>GeogebraReader.js</source>
        <translation type="obsolete">GeogebraReader.js</translation>
    </message>
    <message>
        <location filename="ui_pampi_nonfree.py" line="92"/>
        <source>Install GeogebraReader.js</source>
        <translation type="obsolete">Installer GeogebraReader.js</translation>
    </message>
    <message>
        <location filename="ui_pampi_nonfree.py" line="93"/>
        <source>JSXGraph 0.99.5
===============

Copyright 2008-2016
      Matthias Ehmann,
      Michael Gerhaeuser,
      Carsten Miller,
      Bianca Valentin,
      Alfred Wassermann,
      Peter Wilfahrt

This file is part of JSXGraph.
JSXGraph is free software dual licensed under the GNU LGPL or MIT License.

You can redistribute it and/or modify it under the terms of the

* GNU Lesser General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version
OR
* MIT License: https://github.com/jsxgraph/jsxgraph/blob/master/LICENSE.MIT

JSXGraph is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.
You should have received a copy of the GNU Lesser General Public License and
the MIT License along with JSXGraph. If not, see &lt;http://www.gnu.org/licenses/&gt;
and &lt;http://opensource.org/licenses/MIT/&gt;.</source>
        <translation type="obsolete">JSXGraph 0.99.5
===============

Copyright 2008-2016
      Matthias Ehmann,
      Michael Gerhaeuser,
      Carsten Miller,
      Bianca Valentin,
      Alfred Wassermann,
      Peter Wilfahrt

This file is part of JSXGraph.
JSXGraph is free software dual licensed under the GNU LGPL or MIT License.

You can redistribute it and/or modify it under the terms of the

* GNU Lesser General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version
OR
* MIT License: https://github.com/jsxgraph/jsxgraph/blob/master/LICENSE.MIT

JSXGraph is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.
You should have received a copy of the GNU Lesser General Public License and
the MIT License along with JSXGraph. If not, see &lt;http://www.gnu.org/licenses/&gt;
and &lt;http://opensource.org/licenses/MIT/&gt;.</translation>
    </message>
    <message>
        <location filename="ui_pampi_nonfree.py" line="79"/>
        <source>Vis</source>
        <translation>Vis</translation>
    </message>
    <message>
        <location filename="ui_pampi_nonfree.py" line="80"/>
        <source>Install vis.min.css and vis.min.js</source>
        <translation>Installer vis.min.css et vis.min.js</translation>
    </message>
    <message>
        <location filename="ui_pampi_nonfree.py" line="81"/>
        <source>vis.js
======

https://github.com/almende/vis

A dynamic, browser-based visualization library.

@version 4.18.1
@date    2017-01-29

@license
Copyright (C) 2011-2016 Almende B.V, http://almende.com

Vis.js is dual licensed under both

* The Apache 2.0 License
  http://www.apache.org/licenses/LICENSE-2.0

and

* The MIT License
  http://opensource.org/licenses/MIT

Vis.js may be distributed under either license.
</source>
        <translation>vis.js
======

https://github.com/almende/vis

A dynamic, browser-based visualization library.

@version 4.18.1
@date    2017-01-29

@license
Copyright (C) 2011-2016 Almende B.V, http://almende.com

Vis.js is dual licensed under both

* The Apache 2.0 License
  http://www.apache.org/licenses/LICENSE-2.0

and

* The MIT License
  http://opensource.org/licenses/MIT

Vis.js may be distributed under either license.
</translation>
    </message>
</context>
<context>
    <name>MonDialogue</name>
    <message>
        <location filename="pampi-nonfree" line="57"/>
        <source>Download OK</source>
        <translation>Téléchargement OK</translation>
    </message>
    <message>
        <location filename="pampi-nonfree" line="60"/>
        <source>{} was successfully downloaded</source>
        <translation type="obsolete">{} est téléchargé avec succès</translation>
    </message>
    <message>
        <location filename="pampi-nonfree" line="59"/>
        <source>Download Failed</source>
        <translation>Téléchargement manqué</translation>
    </message>
    <message>
        <location filename="pampi-nonfree" line="59"/>
        <source>{} is not downloaded</source>
        <translation>Échec au téléchargement de {}</translation>
    </message>
    <message>
        <location filename="pampi-nonfree" line="57"/>
        <source>{} was successfully downloaded,
to{}</source>
        <translation>{} est téléchargé avec succès,
vers {}</translation>
    </message>
</context>
</TS>
