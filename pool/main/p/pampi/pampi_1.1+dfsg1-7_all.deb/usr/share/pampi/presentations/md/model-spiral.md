<!--
HEADER FOR PAMPI CONFIG
TITLE:titre
-->




#  {.step data-scale=4}

## SPIRALE









#  {.step data-x=0 data-y=600 data-rotate=0 data-scale=0.2}

## 1

![](data/pampi-help/splash.png)



#  {.step data-x=849 data-y=849 data-rotate=-45 data-scale=0.4}

## 2

![](data/pampi-help/splash.png)



#  {.step data-x=1800 data-y=0 data-rotate=-90 data-scale=0.6}

## 3

![](data/pampi-help/splash.png)



#  {.step data-x=1697 data-y=-1697 data-rotate=-135 data-scale=0.8}

## 4

![](data/pampi-help/splash.png)



#  {.step data-x=0 data-y=-3000 data-rotate=-180 data-scale=1}

## 5

![](data/pampi-help/splash.png)




#  {.step data-x=-2546 data-y=-2546 data-rotate=-225 data-scale=1.2}

## 6

![](data/pampi-help/splash.png)



#  {.step data-x=-4200 data-y=0 data-rotate=-270 data-scale=1.4}

## 7

![](data/pampi-help/splash.png)



#  {.step data-x=-3394 data-y=3394 data-rotate=-315 data-scale=1.6}

## 8

![](data/pampi-help/splash.png)



#  {.step data-x=0 data-y=5400 data-rotate=-360 data-scale=1.8}

## 9

![](data/pampi-help/splash.png)



#  {.step data-x=4243 data-y=4243 data-rotate=-405 data-scale=2}

## 10

![](data/pampi-help/splash.png)







# {#overview .step data-x=0 data-y=0 data-scale=16}
