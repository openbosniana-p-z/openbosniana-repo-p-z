/* src/include/pcp/configsz.h.  Generated from configsz.h.in by configure.  */
/*
 * Copyright (c) 2014-2017 Red Hat.
 *
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
 * License for more details.
 */
#ifndef PCP_CONFIGSZ_H
#define PCP_CONFIGSZ_H

/* sizeof long */
#define HAVE_64BIT_LONG 1

/* sizeof long */
/* #undef HAVE_32BIT_LONG */

/* pointer size */
/* #undef HAVE_32BIT_PTR */

/* pointer size */
#define HAVE_64BIT_PTR 1

/* sizeof suseconds_t ... only ever going to exist on linux-like systems */
#define PM_SIZEOF_SUSECONDS_T 8

/* sizeof time_t */
#define PM_SIZEOF_TIME_T 8

#ifndef PM_SIZEOF_TIME_T
#error Unknown time_t size
#endif

#endif /* PCP_CONFIGSZ_H */
