/* src/include/pcp/config.h.  Generated from config.h.in by configure.  */
/* src/include/pcp/config.h.in.  Generated from configure.ac by autoheader.  */

/* Define to 1 if `TIOCGWINSZ' requires <sys/ioctl.h>. */
#define GWINSZ_IN_SYS_IOCTL 1

/* AI_ADDRCONFIG macro */
#define HAVE_AI_ADDRCONFIG 1

/* altzone global */
/* #undef HAVE_ALTZONE */

/* Define to 1 if you have the <arpa/inet.h> header file. */
#define HAVE_ARPA_INET_H 1

/* Define to 1 if you have the `atexit' function. */
#define HAVE_ATEXIT 1

/* Service discovery via Avahi */
/* #undef HAVE_AVAHI */

/* Define to 1 if you have the <avahi-client/publish.h> header file. */
/* #undef HAVE_AVAHI_CLIENT_PUBLISH_H */

/* Define to 1 if you have the <avahi-common/alternative.h> header file. */
#define HAVE_AVAHI_COMMON_ALTERNATIVE_H 1

/* Define to 1 if you have the `backtrace' function. */
#define HAVE_BACKTRACE 1

/* basename API */
#define HAVE_BASENAME 1

/* left-to-right bitfield ordering */
/* #undef HAVE_BITFIELDS_LTOR */

/* Define to 1 if you have the <bits/wordsize.h> header file. */
#define HAVE_BITS_WORDSIZE_H 1

/* Define to 1 if you have the `brk' function. */
#define HAVE_BRK 1

/* compiler casts u64 to double */
#define HAVE_CAST_U64_DOUBLE 1

/* Define to 1 if you have the `chown' function. */
#define HAVE_CHOWN 1

/* clock_gettime API */
#define HAVE_CLOCK_GETTIME 1

/* const arg for scandir() select method */
#define HAVE_CONST_DIRENT 1

/* LL suffix on constants */
#define HAVE_CONST_LONGLONG 1

/* struct dirent d_off field */
#define HAVE_DIRENT_D_OFF 1

/* Define to 1 if you have the <dirent.h> header file, and it defines `DIR'.
   */
#define HAVE_DIRENT_H 1

/* dirname API */
#define HAVE_DIRNAME 1

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* dlopen API */
#define HAVE_DLOPEN 1

/* Define to 1 if you have the <dl.h> header file. */
/* #undef HAVE_DL_H */

/* Define to 1 if you don't have `vprintf' but do have `_doprnt.' */
/* #undef HAVE_DOPRNT */

/* Define to 1 if you have the <endian.h> header file. */
#define HAVE_ENDIAN_H 1

/* Define to 1 if you have the <execinfo.h> header file. */
#define HAVE_EXECINFO_H 1

/* Define to 1 if you have the `fchmod' function. */
#define HAVE_FCHMOD 1

/* Define to 1 if you have the `fchown' function. */
#define HAVE_FCHOWN 1

/* Define to 1 if you have the `fcntl' function. */
#define HAVE_FCNTL 1

/* Define to 1 if you have the <fcntl.h> header file. */
#define HAVE_FCNTL_H 1

/* flog10 math API */
/* #undef HAVE_FLOG10 */

/* FNDELAY macro */
#define HAVE_FNDELAY 1

/* fpclassify math API */
#define HAVE_FPCLASSIFY 1

/* Define to 1 if you have the <fts.h> header file. */
#define HAVE_FTS_H 1

/* Define to 1 if you have the `getcwd' function. */
#define HAVE_GETCWD 1

/* Define to 1 if you have the `getdomainname' function. */
#define HAVE_GETDOMAINNAME 1

/* Define to 1 if you have the `getgid' function. */
#define HAVE_GETGID 1

/* Define to 1 if you have the `getgrent' function. */
#define HAVE_GETGRENT 1

/* Define to 1 if you have the `getgrent_r' function. */
#define HAVE_GETGRENT_R 1

/* Define to 1 if you have the `getgrgid' function. */
#define HAVE_GETGRGID 1

/* Define to 1 if you have the `getgrgid_r' function. */
#define HAVE_GETGRGID_R 1

/* Define to 1 if you have the `getgrnam' function. */
#define HAVE_GETGRNAM 1

/* Define to 1 if you have the `getgrnam_r' function. */
#define HAVE_GETGRNAM_R 1

/* Define to 1 if you have the `gethostname' function. */
#define HAVE_GETHOSTNAME 1

/* Define to 1 if you have the `getmachineid' function. */
/* #undef HAVE_GETMACHINEID */

/* Define to 1 if you have the `getmouse' function. */
#define HAVE_GETMOUSE 1

/* Define to 1 if you have the `getpeereid' function. */
/* #undef HAVE_GETPEEREID */

/* Define to 1 if you have the `getpeerucred' function. */
/* #undef HAVE_GETPEERUCRED */

/* Define to 1 if you have the `getpwent' function. */
#define HAVE_GETPWENT 1

/* Define to 1 if you have the `getpwent_r' function. */
#define HAVE_GETPWENT_R 1

/* Define to 1 if you have the `getpwnam' function. */
#define HAVE_GETPWNAM 1

/* Define to 1 if you have the `getpwnam_r' function. */
#define HAVE_GETPWNAM_R 1

/* Define to 1 if you have the `getpwuid' function. */
#define HAVE_GETPWUID 1

/* Define to 1 if you have the `getpwuid_r' function. */
#define HAVE_GETPWUID_R 1

/* Define to 1 if you have the `getrusage' function. */
#define HAVE_GETRUSAGE 1

/* Define to 1 if you have the `getuid' function. */
#define HAVE_GETUID 1

/* gid_t type */
#define HAVE_GID_T 1

/* Define to 1 if you have the <grp.h> header file. */
#define HAVE_GRP_H 1

/* Define to 1 if you have the <ieeefp.h> header file. */
/* #undef HAVE_IEEEFP_H */

/* Define to 1 if you have the <infiniband/mad.h> header file. */
#define HAVE_INFINIBAND_MAD_H 1

/* Define to 1 if you have the <infiniband/umad.h> header file. */
#define HAVE_INFINIBAND_UMAD_H 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the `ioctl' function. */
#define HAVE_IOCTL 1

/* Define to 1 if you have the <iphlpapi.h> header file. */
/* #undef HAVE_IPHLPAPI_H */

/* Define to 1 if you have the <iptypes.h> header file. */
/* #undef HAVE_IPTYPES_H */

/* isnan math API */
/* #undef HAVE_ISNAN */

/* isnanf math API */
/* #undef HAVE_ISNANF */

/* Define to 1 if you have the `kill' function. */
#define HAVE_KILL 1

/* Define to 1 if you have the `dl' library (-ldl). */
/* #undef HAVE_LIBDL */

/* Define to 1 if you have the `gen' library (-lgen). */
/* #undef HAVE_LIBGEN */

/* Define to 1 if you have the <libgen.h> header file. */
#define HAVE_LIBGEN_H 1

/* Define to 1 if you have the `ibmad' library (-libmad). */
#define HAVE_LIBIBMAD 1

/* Define to 1 if you have the `ibumad' library (-libumad). */
#define HAVE_LIBIBUMAD 1

/* Define to 1 if you have the `m' library (-lm). */
#define HAVE_LIBM 1

/* Define to 1 if you have the `readline' library (-lreadline). */
#define HAVE_LIBREADLINE 1

/* Define to 1 if you have the `regex' library (-lregex). */
/* #undef HAVE_LIBREGEX */

/* Define to 1 if you have the `rt' library (-lrt). */
/* #undef HAVE_LIBRT */

/* Define to 1 if you have the <libzfs.h> header file. */
/* #undef HAVE_LIBZFS_H */

/* Define to 1 if you have the <limits.h> header file. */
#define HAVE_LIMITS_H 1

/* Define to 1 if you have the <linux/perf_event.h> header file. */
#define HAVE_LINUX_PERF_EVENT_H 1

/* lzma decompression */
#define HAVE_LZMA_DECOMPRESSION 1

/* Define to 1 if you have the <lzma.h> header file. */
#define HAVE_LZMA_H 1

/* machine/endian.h */
/* #undef HAVE_MACHINE_ENDIAN_H */

/* Define to 1 if you have the <malloc.h> header file. */
#define HAVE_MALLOC_H 1

/* Define to 1 if you have the <math.h> header file. */
#define HAVE_MATH_H 1

/* Define to 1 if you have the `memalign' function. */
#define HAVE_MEMALIGN 1

/* Define to 1 if you have the <memory.h> header file. */
/* #undef HAVE_MEMORY_H */

/* Define to 1 if you have the `mkstemp' function. */
#define HAVE_MKSTEMP 1

/* Define to 1 if you have the `mktime' function. */
#define HAVE_MKTIME 1

/* Define to 1 if you have the `nanosleep' function. */
#define HAVE_NANOSLEEP 1

/* Define to 1 if you have the <curses.h> header file. */
#define HAVE_CURSES_H 1

/* Define to 1 if you have the <ncurses.h> header file. */
#define HAVE_NCURSES_H 1

/* Define to 1 if you have the <ncurses/curses.h> header file. */
/* #undef HAVE_NCURSES_CURSES_H */

/* Define to 1 if you have the <ncurses/ncurses.h> header file. */
/* #undef HAVE_NCURSES_NCURSES_H */

/* Define to 1 if you have the <ncursesw/curses.h> header file. */
#define HAVE_NCURSESW_CURSES_H 1

/* Define to 1 if you have the <ndir.h> header file, and it defines `DIR'. */
/* #undef HAVE_NDIR_H */

/* Define to 1 if you have the <netdb.h> header file. */
#define HAVE_NETDB_H 1

/* Define to 1 if you have the <netinet/in.h> header file. */
#define HAVE_NETINET_IN_H 1

/* Define to 1 if you have the <netinet/tcp.h> header file. */
#define HAVE_NETINET_TCP_H 1

/* Define to 1 if you have the <netioapi.h> header file. */
/* #undef HAVE_NETIOAPI_H */

/* Define to 1 if you have the <net/if.h> header file. */
#define HAVE_NET_IF_H 1

/* Define to 1 if you have the <nspr4/nspr.h> header file. */
/* #undef HAVE_NSPR4_NSPR_H */

/* Define to 1 if you have the <nspr/nspr.h> header file. */
/* #undef HAVE_NSPR_NSPR_H */

/* Define to 1 if you have the <nss3/nss.h> header file. */
/* #undef HAVE_NSS3_NSS_H */

/* Define to 1 if you have the <nss/nss.h> header file. */
/* #undef HAVE_NSS_NSS_H */

/* Define to 1 if you have the <perfmon/pfmlib_perf_event.h> header file. */
#define HAVE_PERFMON_PFMLIB_PERF_EVENT_H 1

/* Define to 1 if you have the `pipe2' function. */
#define HAVE_PIPE2 1

/* pma_query_via API */
#define HAVE_PMA_QUERY_VIA 1

/* Define to 1 if you have the <poll.h> header file. */
#define HAVE_POLL_H 1

/* port_performance_query_via API */
/* #undef HAVE_PORT_PERFORMANCE_QUERY_VIA */

/* Define to 1 if you have the `posix_memalign' function. */
#define HAVE_POSIX_MEMALIGN 1

/* pow math API */
#define HAVE_POW 1

/* Define to 1 if you have the `prctl' function. */
#define HAVE_PRCTL 1

/* printf %p produces 0x */
#define HAVE_PRINTF_P_PFX 1

/* PR_SET_PDEATHSIG constant */
#define HAVE_PR_SET_PDEATHSIG 1

/* PR_TERMCHILD constant */
/* #undef HAVE_PR_TERMCHILD */

/* pthread_barrier_t type */
#define HAVE_PTHREAD_BARRIER_T 1

/* Define to 1 if you have the <pthread.h> header file. */
#define HAVE_PTHREAD_H 1

/* pthread_mutex_t type */
#define HAVE_PTHREAD_MUTEX_T 1

/* ptrdiff_t type */
#define HAVE_PTRDIFF_T 1

/* Define to 1 if you have the <pwd.h> header file. */
#define HAVE_PWD_H 1

/* readline API */
#define HAVE_READLINE 1

/* Define to 1 if you have the `recvmsg' function. */
#define HAVE_RECVMSG 1

/* Define to 1 if you have the `regcmp' function. */
/* #undef HAVE_REGCMP */

/* Define to 1 if you have the `regcomp' function. */
#define HAVE_REGCOMP 1

/* Define to 1 if you have the `regex' function. */
/* #undef HAVE_REGEX */

/* Define to 1 if you have the `regexec' function. */
#define HAVE_REGEXEC 1

/* Define to 1 if you have the <regex.h> header file. */
#define HAVE_REGEX_H 1

/* Define to 1 if you have the <sasl/sasl.h> header file. */
/* #undef HAVE_SASL_SASL_H */

/* SA_SIGINFO macro */
#define HAVE_SA_SIGINFO 1

/* Define to 1 if you have the `sbrk' function. */
#define HAVE_SBRK 1

/* Define to 1 if you have the `scandir' function. */
#define HAVE_SCANDIR 1

/* Define to 1 if you have the <sched.h> header file. */
#define HAVE_SCHED_H 1

/* Encrypted sockets */
#define HAVE_SECURE_SOCKETS 1

/* Define to 1 if you have the `select' function. */
#define HAVE_SELECT 1

/* Define to 1 if you have the `sendmsg' function. */
#define HAVE_SENDMSG 1

/* Service discovery mechanisms */
/* #undef HAVE_SERVICE_DISCOVERY */

/* Define to 1 if you have the `setlinebuf' function. */
#define HAVE_SETLINEBUF 1

/* Define to 1 if you have the `setns' function. */
#define HAVE_SETNS 1

/* Define to 1 if you have the `set_escdelay' function. */
#define HAVE_SET_ESCDELAY 1

/* sid type */
/* #undef HAVE_SID */

/* SIGBUS signal */
#define HAVE_SIGBUS 1

/* Define to 1 if you have the `sighold' function. */
#define HAVE_SIGHOLD 1

/* SIGHUP signal */
#define HAVE_SIGHUP 1

/* Define to 1 if you have the `signal' function. */
#define HAVE_SIGNAL 1

/* SIG_PF typedef */
/* #undef HAVE_SIGPF */

/* SIGPIPE signal */
#define HAVE_SIGPIPE 1

/* Define to 1 if you have the `sigrelse' function. */
#define HAVE_SIGRELSE 1

/* Define to 1 if you have the `socket' function. */
#define HAVE_SOCKET 1

/* socklen_t type */
#define HAVE_SOCKLEN_T 1

/* Define to 1 if you have the <standards.h> header file. */
/* #undef HAVE_STANDARDS_H */

/* Static probes (dtrace, systemtap) */
/* #undef HAVE_STATIC_PROBES */

/* timespec type */
#define HAVE_STAT_TIMESPEC 1

/* timespec_t type */
/* #undef HAVE_STAT_TIMESPEC_T */

/* timestruc_t type */
/* #undef HAVE_STAT_TIMESTRUC */

/* time_t type */
/* #undef HAVE_STAT_TIME_T */

/* Define to 1 if you have the <stddef.h> header file. */
#define HAVE_STDDEF_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the `strchrnul' function. */
#define HAVE_STRCHRNUL 1

/* strerror_r return */
#define HAVE_STRERROR_R_PTR 1

/* strftime with %z */
#define HAVE_STRFTIME_z 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the `strndup' function. */
#define HAVE_STRNDUP 1

/* Define to 1 if you have the `strtod' function. */
#define HAVE_STRTOD 1

/* Define to 1 if you have the `strtol' function. */
#define HAVE_STRTOL 1

/* Define to 1 if you have the `strtoll' function. */
#define HAVE_STRTOLL 1

/* Define to 1 if you have the `strtoull' function. */
#define HAVE_STRTOULL 1

/* sockaddr_un type */
#define HAVE_STRUCT_SOCKADDR_UN 1

/* timespec type */
#define HAVE_STRUCT_TIMESPEC 1

/* ucred type */
#define HAVE_STRUCT_UCRED 1

/* st_mtime stat field */
/* #undef HAVE_ST_MTIME_WITH_E */

/* st_mtimespec stat field */
/* #undef HAVE_ST_MTIME_WITH_SPEC */

/* Define to 1 if you have the `sysinfo' function. */
#define HAVE_SYSINFO 1

/* Define to 1 if you have the `syslog' function. */
#define HAVE_SYSLOG 1

/* Define to 1 if you have the <syslog.h> header file. */
#define HAVE_SYSLOG_H 1

/* Define to 1 if you have the <sys/byteorder.h> header file. */
/* #undef HAVE_SYS_BYTEORDER_H */

/* Define to 1 if you have the <sys/dir.h> header file, and it defines `DIR'.
   */
/* #undef HAVE_SYS_DIR_H */

/* IRIX sys/endian.h */
/* #undef HAVE_SYS_ENDIAN_H */

/* Define to 1 if you have the <sys/ioctl.h> header file. */
#define HAVE_SYS_IOCTL_H 1

/* Define to 1 if you have the <sys/mman.h> header file. */
#define HAVE_SYS_MMAN_H 1

/* Define to 1 if you have the <sys/mount.h> header file. */
#define HAVE_SYS_MOUNT_H 1

/* Define to 1 if you have the <sys/ndir.h> header file, and it defines `DIR'.
   */
/* #undef HAVE_SYS_NDIR_H */

/* Define to 1 if you have the <sys/prctl.h> header file. */
#define HAVE_SYS_PRCTL_H 1

/* Define to 1 if you have the <sys/resource.h> header file. */
#define HAVE_SYS_RESOURCE_H 1

/* Define to 1 if you have the <sys/sdt.h> header file. */
/* #undef HAVE_SYS_SDT_H */

/* Define to 1 if you have the <sys/select.h> header file. */
#define HAVE_SYS_SELECT_H 1

/* Define to 1 if you have the <sys/socket.h> header file. */
#define HAVE_SYS_SOCKET_H 1

/* Define to 1 if you have the <sys/statfs.h> header file. */
#define HAVE_SYS_STATFS_H 1

/* Define to 1 if you have the <sys/statvfs.h> header file. */
#define HAVE_SYS_STATVFS_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/sysinfo.h> header file. */
#define HAVE_SYS_SYSINFO_H 1

/* Define to 1 if you have the <sys/systeminfo.h> header file. */
/* #undef HAVE_SYS_SYSTEMINFO_H */

/* Define to 1 if you have the <sys/termios.h> header file. */
#define HAVE_SYS_TERMIOS_H 1

/* Define to 1 if you have the <sys/times.h> header file. */
#define HAVE_SYS_TIMES_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <sys/un.h> header file. */
#define HAVE_SYS_UN_H 1

/* Define to 1 if you have the <sys/wait.h> header file. */
#define HAVE_SYS_WAIT_H 1

/* Define to 1 if you have the `tcgetattr' function. */
#define HAVE_TCGETATTR 1

/* Define to 1 if you have the <termios.h> header file. */
#define HAVE_TERMIOS_H 1

/* Define to 1 if you have the <termio.h> header file. */
#define HAVE_TERMIO_H 1

/* Define to 1 if you have the `trace_back_stack' function. */
/* #undef HAVE_TRACE_BACK_STACK */

/* Transparent decompression */
#define HAVE_TRANSPARENT_DECOMPRESSION 1

/* uid_t type */
#define HAVE_UID_T 1

/* Define to 1 if you have the `uname' function. */
#define HAVE_UNAME 1

/* _environ declared globally */
/* #undef HAVE_UNDERBAR_ENVIRON */

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to 1 if you have the `unsetenv' function. */
#define HAVE_UNSETENV 1

/* Define to 1 if you have the `usleep' function. */
#define HAVE_USLEEP 1

/* uv_pipe_chmod API. */
#define HAVE_UV_PIPE_CHMOD 1

/* Define to 1 if you have the `valloc' function. */
#define HAVE_VALLOC 1

/* Define to 1 if you have the <values.h> header file. */
#define HAVE_VALUES_H 1

/* Define to 1 if you have the `vprintf' function. */
#define HAVE_VPRINTF 1

/* Define to 1 if you have the `wait3' system call. Deprecated, you should no
   longer depend upon `wait3'. */
#define HAVE_WAIT3 1

/* Define to 1 if you have the `waitpid' function. */
#define HAVE_WAITPID 1

/* indirect signal.h */
#define HAVE_WAIT_INCLUDES_SIGNAL 1

/* Define to 1 if you have the <windows.h> header file. */
/* #undef HAVE_WINDOWS_H */

/* Define to 1 if you have the <winsock2.h> header file. */
/* #undef HAVE_WINSOCK2_H */

/* Define to 1 if you have the <ws2tcpip.h> header file. */
/* #undef HAVE_WS2TCPIP_H */

/* Define to 1 if you have the <systemd/sd-daemon.h> header file. */
#define HAVE_SYSTEMD_SD_DAEMON_H 1

/* 3-arg zfs_iter_snapshots */
/* #undef HAVE_ZFS_ITER_SNAPSHOTS_3ARG */

/* 4-arg zfs_iter_snapshots */
/* #undef HAVE_ZFS_ITER_SNAPSHOTS_4ARG */

/* 4-arg zpool_vdev_name */
/* #undef HAVE_ZPOOL_VDEV_NAME_4ARG */

/* 5-arg zpool_vdev_name */
/* #undef HAVE_ZPOOL_VDEV_NAME_5ARG */

/* Define to 1 if you have the `__clone' function. */
#define HAVE___CLONE 1

/* __psint_t type */
/* #undef HAVE___PSINT_T */

/* __thread private data */
#define HAVE___THREAD 1

/* Platform is AIX */
/* #undef IS_AIX */

/* Platform is Darwin (Mac OS X) */
/* #undef IS_DARWIN */

/* Platform is FreeBSD */
/* #undef IS_FREEBSD */

/* Platform is GNU Hurd */
/* #undef IS_GNU */

/* Platform is Linux */
#define IS_LINUX 1

/* Platform is MinGW (Windows) */
/* #undef IS_MINGW */

/* Platform is NetBSD */
/* #undef IS_NETBSD */

/* Platform is OpenBSD */
/* #undef IS_OPENBSD */

/* Platform is Solaris */
/* #undef IS_SOLARIS */

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define PACKAGE_NAME ""

/* Define to the full name and version of this package. */
#define PACKAGE_STRING ""

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME ""

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION ""

/* Define as the return type of signal handlers (`int' or `void'). */
#define RETSIGTYPE void

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Define to 1 if you can safely include both <sys/time.h> and <time.h>. */
#define TIME_WITH_SYS_TIME 1

/* Define to 1 if your <sys/time.h> declares `struct tm'. */
/* #undef TM_IN_SYS_TIME */

/* Define to 1 if the X Window System is missing or not being used. */
/* #undef X_DISPLAY_MISSING */

/* Define to 1 if `lex' declares `yytext' as a `char *' by default, not a
   `char[]'. */
#define YYTEXT_POINTER 1

/* Define to `int' if <sys/types.h> does not define. */
/* #undef __int32_t */

/* Define to `long long' if <sys/types.h> does not define. */
/* #undef __int64_t */

/* Define to `unsigned int' if <sys/types.h> does not define. */
/* #undef __uint32_t */

/* Define to `unsigned long long' if <sys/types.h> does not define. */
/* #undef __uint64_t */

/* Define to empty if `const' does not conform to ANSI C. */
/* #undef const */

/* Define to `__inline__' or `__inline' if that's what the C compiler
   calls it, or to nothing if 'inline' is not supported under any name.  */
#ifndef __cplusplus
/* #undef inline */
#endif

/* Define to `long int' if <sys/types.h> does not define. */
/* #undef off_t */

/* Define to `int' if <sys/types.h> does not define. */
/* #undef pid_t */

/* Define to `unsigned int' if <sys/types.h> does not define. */
/* #undef size_t */

/* Default strtoint64 to strtoll */
#define strtoint64 strtoll

/* Default strtouint64 to strtoull */
#define strtouint64 strtoull

/* Define to `unsigned int' if <sys/types.h> does not define. */
#define uint_t unsigned int

/* backtrace support */
#define HAVE___EXECUTABLE_START 1
#define HAVE___ETEXT 1
#define HAVE__ETEXT 1
#define HAVE_ETEXT 1
