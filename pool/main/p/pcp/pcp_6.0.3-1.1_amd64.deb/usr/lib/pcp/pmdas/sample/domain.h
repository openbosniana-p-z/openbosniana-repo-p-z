/*
 * built from ../../../pmns/stdpmid
 */
#define SAMPLE 29
