/*
 * built from ../../pmns/stdpmid
 */
#define MOUNTS 72
