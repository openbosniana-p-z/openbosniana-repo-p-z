/*
 * built from ../../pmns/stdpmid
 */
#define PODMAN 33
