/*
 * built from ../../pmns/stdpmid
 */
#define NVML 120
