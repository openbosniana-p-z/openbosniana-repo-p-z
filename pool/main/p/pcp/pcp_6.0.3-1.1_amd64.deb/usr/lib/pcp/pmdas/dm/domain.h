/*
 * built from ../../pmns/stdpmid
 */
#define DM 129
