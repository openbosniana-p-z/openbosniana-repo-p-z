/*
 * built from ../../pmns/stdpmid
 */
#define LOGGER 106
