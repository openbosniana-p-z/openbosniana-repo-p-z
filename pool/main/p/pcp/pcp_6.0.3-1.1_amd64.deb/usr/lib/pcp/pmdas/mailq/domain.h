/*
 * built from ../../pmns/stdpmid
 */
#define MAILQ 9
