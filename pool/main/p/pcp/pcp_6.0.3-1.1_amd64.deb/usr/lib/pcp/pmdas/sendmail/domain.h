/*
 * built from ../../pmns/stdpmid
 */
#define SENDMAIL 15
