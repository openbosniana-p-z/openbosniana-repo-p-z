/*
 * built from ../../pmns/stdpmid
 */
#define HACLUSTER 155
