/*
 * built from ../../pmns/stdpmid
 */
#define DENKI 156
