/*
 * built from ../../../pmns/stdpmid
 */
#define TRACE 10
