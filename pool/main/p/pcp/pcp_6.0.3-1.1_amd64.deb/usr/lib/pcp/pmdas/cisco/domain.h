/*
 * built from ../../pmns/stdpmid
 */
#define CISCO 5
