/*
 * built from ../../pmns/stdpmid
 */
#define LUSTRECOMM 93
