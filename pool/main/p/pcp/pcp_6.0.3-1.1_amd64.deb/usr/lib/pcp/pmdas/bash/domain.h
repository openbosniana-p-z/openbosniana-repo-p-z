/*
 * built from ../../pmns/stdpmid
 */
#define BASH 112
