/*
 * built from ../../pmns/stdpmid
 */
#define TXMON 248
