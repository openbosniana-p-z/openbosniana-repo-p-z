/*
 * built from ../../pmns/stdpmid
 */
#define APACHE 68
