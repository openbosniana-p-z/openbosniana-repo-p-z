/*
 * built from ../../pmns/stdpmid
 */
#define SOCKETS 154
