/*
 * built from ../../pmns/stdpmid
 */
#define PERFEVENT 127
