/*
 * built from ../../pmns/stdpmid
 */
#define SHPING 19
