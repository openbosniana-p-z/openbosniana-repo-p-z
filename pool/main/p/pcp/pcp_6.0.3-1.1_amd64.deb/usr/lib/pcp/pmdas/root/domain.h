/*
 * built from ../../pmns/stdpmid
 */
#define ROOT 1
