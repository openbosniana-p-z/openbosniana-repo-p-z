var structgauden__t =
[
    [ "det", "structgauden__t.html#a315918a44ff97b95a6fcdf8739d8089b", null ],
    [ "featlen", "structgauden__t.html#aca099d830de926e628ac0b523046b32c", null ],
    [ "lmath", "structgauden__t.html#ae05c9b82d8a586bea347681ebe04bb83", null ],
    [ "mean", "structgauden__t.html#aa76d63009601dcb6b99f17db96167f37", null ],
    [ "n_density", "structgauden__t.html#ab5104d8fa59bc94b12b36104dd4c19ac", null ],
    [ "n_feat", "structgauden__t.html#a6dea221962b4a278dbae4806925a7be0", null ],
    [ "n_mgau", "structgauden__t.html#af15df11bd2f3ab0290e0a33ca15c836c", null ],
    [ "var", "structgauden__t.html#a172cb69c018608ab8c33d54e6f0fdf19", null ]
];