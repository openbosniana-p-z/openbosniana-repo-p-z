var phone__loop__search_8h =
[
    [ "phone_loop_renorm_s", "structphone__loop__renorm__s.html", "structphone__loop__renorm__s" ],
    [ "phone_loop_search_s", "structphone__loop__search__s.html", "structphone__loop__search__s" ],
    [ "phone_loop_search_score", "phone__loop__search_8h.html#ab49609ce2ff4d1827f57693f463e360b", null ]
];