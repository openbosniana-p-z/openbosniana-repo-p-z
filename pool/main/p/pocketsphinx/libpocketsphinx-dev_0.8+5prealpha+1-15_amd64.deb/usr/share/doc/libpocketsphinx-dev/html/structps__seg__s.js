var structps__seg__s =
[
    [ "ascr", "structps__seg__s.html#a6f7706ec4c0d0ec8ecafaf0f29f41f4b", null ],
    [ "ef", "structps__seg__s.html#ab25ecc6af8d2695c6097cf7e934eadd4", null ],
    [ "lback", "structps__seg__s.html#a4d86c21f1ed2dc3eb3b1b1b37ce9bb48", null ],
    [ "lscr", "structps__seg__s.html#a69e605f422eeed1a9c67437e8ddd8b08", null ],
    [ "lwf", "structps__seg__s.html#a2249c012b83c902f4f8ed8d98ded7d20", null ],
    [ "prob", "structps__seg__s.html#ae683244d90d0a5339930b47757778432", null ],
    [ "search", "structps__seg__s.html#a14168ddcb60e094dad36c7c920a79bb3", null ],
    [ "sf", "structps__seg__s.html#a885a599726cd0efba573d106d016e6e2", null ],
    [ "vt", "structps__seg__s.html#a510362a2281e374c839397c3e5488515", null ],
    [ "word", "structps__seg__s.html#a97a0dc7db931c7e3f98d23d21ce27f04", null ]
];