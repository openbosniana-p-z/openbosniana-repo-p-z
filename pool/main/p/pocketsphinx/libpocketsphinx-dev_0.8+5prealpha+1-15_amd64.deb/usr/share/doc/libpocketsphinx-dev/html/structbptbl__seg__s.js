var structbptbl__seg__s =
[
    [ "base", "structbptbl__seg__s.html#ac21f715b189c7e452385252bfcee47fe", null ],
    [ "bpidx", "structbptbl__seg__s.html#a81e3d422fb2307c1a83e9490525dce7f", null ],
    [ "cur", "structbptbl__seg__s.html#a1649196a2c03fb61b31624086ee998b5", null ],
    [ "n_bpidx", "structbptbl__seg__s.html#a8d1f0aa7dd09e2d6321a00b68ab6a051", null ]
];