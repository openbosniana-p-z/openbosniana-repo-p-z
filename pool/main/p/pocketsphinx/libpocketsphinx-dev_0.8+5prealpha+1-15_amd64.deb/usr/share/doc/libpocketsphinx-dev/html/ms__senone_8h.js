var ms__senone_8h =
[
    [ "senone_t", "structsenone__t.html", "structsenone__t" ],
    [ "senprob_t", "ms__senone_8h.html#af5f6b21f81649ae1d6ce57f5564d3be0", null ],
    [ "senone_eval", "ms__senone_8h.html#a0ef3f343c1f7a9504a1ceda2d7383000", null ],
    [ "senone_free", "ms__senone_8h.html#a86881df5bbbd615e2cd8171e3b086fa6", null ],
    [ "senone_init", "ms__senone_8h.html#ab0df190c45b61028c0cb5bf14912173f", null ]
];