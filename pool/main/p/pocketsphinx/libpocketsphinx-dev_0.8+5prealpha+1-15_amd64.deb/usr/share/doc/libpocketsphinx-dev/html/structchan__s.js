var structchan__s =
[
    [ "alt", "structchan__s.html#a52e85d037ca3a8b21ff1eed1d469ca15", null ],
    [ "ciphone", "structchan__s.html#a33da51d8524073abc792519d0738ca0b", null ],
    [ "hmm", "structchan__s.html#a742d6a125ac468b95a1ddd880a956e35", null ],
    [ "next", "structchan__s.html#a260b68eff64150d0ae9ce4db7feb1300", null ],
    [ "penult_phn_wid", "structchan__s.html#a136796f6a13c0d6989120f9aa25b85f1", null ],
    [ "rc_id", "structchan__s.html#acf84a2fa662e7ff626769e7d8152a608", null ]
];