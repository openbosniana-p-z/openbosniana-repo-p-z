var structdict2pid__t =
[
    [ "dict", "structdict2pid__t.html#ae1fecad64884980e9d8355844abc3512", null ],
    [ "ldiph_lc", "structdict2pid__t.html#a609288c1f4cee2ea2e82bc5e391b894a", null ],
    [ "lrdiph_rc", "structdict2pid__t.html#a4eec4de961e2374a6a4c06bb9dde39d8", null ],
    [ "lrssid", "structdict2pid__t.html#a6c1de8a269f6ff37dce3dd8cbec4235a", null ],
    [ "mdef", "structdict2pid__t.html#ab0dcb283a0cf5ad40836bc418fd535b3", null ],
    [ "rssid", "structdict2pid__t.html#a2cf69a0437b33969d54ef2ae669b90aa", null ]
];