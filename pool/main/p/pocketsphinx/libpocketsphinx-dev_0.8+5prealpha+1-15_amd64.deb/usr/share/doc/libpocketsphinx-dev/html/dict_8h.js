var dict_8h =
[
    [ "dictword_t", "structdictword__t.html", "structdictword__t" ],
    [ "dict_t", "structdict__t.html", "structdict__t" ],
    [ "dict_num_real_words", "dict_8h.html#a529d92f69f39e1f8c4a94e60a9509201", null ],
    [ "dict_pron", "dict_8h.html#a8785ab6264a5c6cf0b8da6bf79a46de4", null ],
    [ "dict_size", "dict_8h.html#a361b948b42f9cfdf5c7fa9dfc8a71a94", null ],
    [ "dict_add_word", "dict_8h.html#a24888ac8e24259e553c43c4655b38432", null ],
    [ "dict_ciphone_str", "dict_8h.html#ab362b994a57231754cb21c80b9dc1aaa", null ],
    [ "dict_filler_word", "dict_8h.html#aa5cade4dc6464c620718b86344540aff", null ],
    [ "dict_free", "dict_8h.html#a51ee6c067decce8dbc182f95f7b33e91", null ],
    [ "dict_init", "dict_8h.html#ab5a6823559773fbad0357d086c21a38b", null ],
    [ "dict_real_word", "dict_8h.html#ad2eba4ca92dd1a3721608e003d95d8c1", null ],
    [ "dict_report", "dict_8h.html#a41cca433a75fd2663bee115296639666", null ],
    [ "dict_retain", "dict_8h.html#a4a0771d8ed3425d2bf529b4128eea594", null ],
    [ "dict_word2basestr", "dict_8h.html#a3a128531ae9c077be9882119ed05fe3a", null ],
    [ "dict_wordid", "dict_8h.html#ad3729eb1a02a9a321e17933f7e90c80e", null ],
    [ "dict_write", "dict_8h.html#a4bfa8e3b7b9ff30165375d1c97bb04b8", null ]
];