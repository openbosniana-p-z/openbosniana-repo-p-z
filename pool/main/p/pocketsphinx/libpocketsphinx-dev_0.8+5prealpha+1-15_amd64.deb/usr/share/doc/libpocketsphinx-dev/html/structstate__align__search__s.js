var structstate__align__search__s =
[
    [ "al", "structstate__align__search__s.html#a47b9b509c7416f8952ee452d8ce7dda6", null ],
    [ "base", "structstate__align__search__s.html#ab2a596d687e113c88a271d1397b8d9c5", null ],
    [ "best_score", "structstate__align__search__s.html#a1810f343c6ae382f5ed0a5eb02d33037", null ],
    [ "frame", "structstate__align__search__s.html#aa520abfdb4d0bca2b769f281839637a9", null ],
    [ "hmmctx", "structstate__align__search__s.html#a683e76dbcc87cde89ca5d45b4b91c1e9", null ],
    [ "hmms", "structstate__align__search__s.html#a78ea3ffae6ecc3c004ff60707dc225b0", null ],
    [ "n_emit_state", "structstate__align__search__s.html#a80c74bac917a8203bb74f5738621ce83", null ],
    [ "n_fr_alloc", "structstate__align__search__s.html#a97956b4924cba2b37470ff17f29c37bb", null ],
    [ "n_phones", "structstate__align__search__s.html#ab248827613cdbc892e35e57d5c43c7c3", null ],
    [ "tokens", "structstate__align__search__s.html#a2fae207533462fe6efe19c8a2a3a64e0", null ]
];