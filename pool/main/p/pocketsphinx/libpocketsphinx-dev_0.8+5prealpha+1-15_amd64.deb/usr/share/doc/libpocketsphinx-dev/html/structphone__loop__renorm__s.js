var structphone__loop__renorm__s =
[
    [ "frame_idx", "structphone__loop__renorm__s.html#af54c31c6d417b769b088b898294a135e", null ],
    [ "norm", "structphone__loop__renorm__s.html#a9a76415892efce2e4b53bc5ea6599010", null ]
];