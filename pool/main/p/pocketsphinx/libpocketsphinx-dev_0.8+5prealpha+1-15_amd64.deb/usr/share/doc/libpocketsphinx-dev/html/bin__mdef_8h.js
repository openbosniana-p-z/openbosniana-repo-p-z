var bin__mdef_8h =
[
    [ "mdef_entry_s", "structmdef__entry__s.html", "structmdef__entry__s" ],
    [ "cd_tree_s", "structcd__tree__s.html", "structcd__tree__s" ],
    [ "bin_mdef_s", "structbin__mdef__s.html", "structbin__mdef__s" ],
    [ "BAD_SENID", "bin__mdef_8h.html#ab6c771eca798ab8c94e0933a1f8daafc", null ],
    [ "BAD_SSID", "bin__mdef_8h.html#a8ee283c316e9f4aa8e6d18c1d44026bc", null ],
    [ "bin_mdef_t", "bin__mdef_8h.html#a269082d84ae254593b79f1eafe9b2d12", null ],
    [ "cd_tree_t", "bin__mdef_8h.html#a8cf08e6d9d721c8cf5911f2c3f722645", null ],
    [ "mdef_entry_t", "bin__mdef_8h.html#a424238fea86ab5ecfc89ca0cc885ad38", null ],
    [ "bin_mdef_ciphone_id", "bin__mdef_8h.html#af592f710731474b77166a29530716672", null ],
    [ "bin_mdef_ciphone_id_nocase", "bin__mdef_8h.html#af437f39a8a9b52dd3187f7f0fc098cab", null ],
    [ "bin_mdef_ciphone_str", "bin__mdef_8h.html#ad6e088cba31f842306001ccc1fdc973b", null ],
    [ "bin_mdef_free", "bin__mdef_8h.html#afe7ed87e2a2d22b228c14ed8225e4b2c", null ],
    [ "bin_mdef_phone_id", "bin__mdef_8h.html#a99cd766df3a6a74eab9e316586189d54", null ],
    [ "bin_mdef_phone_str", "bin__mdef_8h.html#a35d0676dd56e11508c62e84947901503", null ],
    [ "bin_mdef_read", "bin__mdef_8h.html#a29fc1015cf8db7719a9838737ce4237e", null ],
    [ "bin_mdef_read_text", "bin__mdef_8h.html#a67c3fe67caeacefe7b147271243b9c3f", null ],
    [ "bin_mdef_retain", "bin__mdef_8h.html#af5eab565d0390a21190d33ae4235c1a1", null ],
    [ "bin_mdef_write", "bin__mdef_8h.html#a982b8e598afed47805fab1509e8fc4bb", null ],
    [ "bin_mdef_write_text", "bin__mdef_8h.html#af89d79226df33947019efcfe7377d586", null ]
];