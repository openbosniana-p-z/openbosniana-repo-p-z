var tied__mgau__common_8h =
[
    [ "GMMSUB", "tied__mgau__common_8h.html#a740dfe5b30e702ba8b2ec7426bd4d57e", null ],
    [ "MAX_NEG_ASCR", "tied__mgau__common_8h.html#a965d50d73044c3f2dc2589662fd2e89e", null ],
    [ "MAX_NEG_MIXW", "tied__mgau__common_8h.html#ad739d757ed78293c18dc2386fd3b750e", null ],
    [ "fast_logmath_add", "tied__mgau__common_8h.html#a947ea19b4351ecbf70330e089994c3a1", null ]
];