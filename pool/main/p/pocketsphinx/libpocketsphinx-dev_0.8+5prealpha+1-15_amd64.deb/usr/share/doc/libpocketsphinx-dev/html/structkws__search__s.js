var structkws__search__s =
[
    [ "bestscore", "structkws__search__s.html#a0a04bba471516468d1b2bea14632f255", null ],
    [ "def_threshold", "structkws__search__s.html#afce4456a796dbc72149d7a47159ccca9", null ],
    [ "delay", "structkws__search__s.html#acf2597fd017db4c2f90a9ba54e08a20c", null ],
    [ "detections", "structkws__search__s.html#ac7bd23ef33f85b4173a8d9a7cc9b9a32", null ],
    [ "frame", "structkws__search__s.html#a68a833afd9d01bdf4c2cc640b575eea7", null ],
    [ "hmmctx", "structkws__search__s.html#a0069d57702f921cbd1e2093148e7b672", null ],
    [ "keyphrases", "structkws__search__s.html#a549b9c11b5ff3c858c2f000b61915026", null ],
    [ "n_pl", "structkws__search__s.html#aab6e42d0c93af992c16e2a75db386df4", null ],
    [ "perf", "structkws__search__s.html#a0cc9f5fcc60e181adfef86acf781076d", null ],
    [ "pl_hmms", "structkws__search__s.html#a7b501f4cc5f4efb7b4ca0259afcf4e05", null ],
    [ "plp", "structkws__search__s.html#a3bfc1d19e39d1cd321ce47280f1abe00", null ]
];