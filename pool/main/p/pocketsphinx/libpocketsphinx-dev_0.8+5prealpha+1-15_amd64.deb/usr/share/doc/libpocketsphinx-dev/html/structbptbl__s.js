var structbptbl__s =
[
    [ "bp", "structbptbl__s.html#a4ca45ebc4a1ac18fc0596195e7e03bc8", null ],
    [ "frame", "structbptbl__s.html#ae52081dde905cf6e7d988cdeb4c9b8b3", null ],
    [ "last2_phone", "structbptbl__s.html#a27b8e54bb7552e6afc15e4f44f42e3b7", null ],
    [ "last_phone", "structbptbl__s.html#aa7704ba76d3dcde6b8a24855362a4289", null ],
    [ "prev_real_wid", "structbptbl__s.html#a83784e3b0121bc365d485151ab277920", null ],
    [ "real_wid", "structbptbl__s.html#a91247e4f807cf780afe8f5ac45e720b8", null ],
    [ "refcnt", "structbptbl__s.html#acdc7410a4069418879aa022f9b61c13d", null ],
    [ "s_idx", "structbptbl__s.html#abf9e4bcf1927aa09fb2b30c59e99f551", null ],
    [ "score", "structbptbl__s.html#aa5643c0c19ce4d39d51ddf7376f4d508", null ],
    [ "valid", "structbptbl__s.html#a4948439666e1e2204a6d1c6d9cfd1cd0", null ],
    [ "wid", "structbptbl__s.html#a143ff0891fafd471000df7c73123b8a7", null ]
];