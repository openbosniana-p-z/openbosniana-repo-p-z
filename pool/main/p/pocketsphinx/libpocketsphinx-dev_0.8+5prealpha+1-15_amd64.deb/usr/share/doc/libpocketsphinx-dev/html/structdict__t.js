var structdict__t =
[
    [ "filler_end", "structdict__t.html#a77c6692e56308968804add1292275cb7", null ],
    [ "filler_start", "structdict__t.html#abd48fdafaaa68a8df2fd82163c51a95c", null ],
    [ "finishwid", "structdict__t.html#a3875be5336e2d9888f6d5cb83ded82c5", null ],
    [ "ht", "structdict__t.html#a7205aae4fbeef3aaa53f94b6af529af2", null ],
    [ "max_words", "structdict__t.html#af6142600cef73f846b58ba9bc36b02ac", null ],
    [ "mdef", "structdict__t.html#a3a01eb5a3ebda5652d434be26e0cfdd2", null ],
    [ "n_word", "structdict__t.html#af00f60319a7025361e291af5addb6b31", null ],
    [ "silwid", "structdict__t.html#aad07b22b94c360923f151c02890f6e68", null ],
    [ "startwid", "structdict__t.html#a22bc6c52ce9e04c4f3f7d0ba1972ee51", null ],
    [ "word", "structdict__t.html#a9e6636bbe45936a03381fea430addd31", null ]
];