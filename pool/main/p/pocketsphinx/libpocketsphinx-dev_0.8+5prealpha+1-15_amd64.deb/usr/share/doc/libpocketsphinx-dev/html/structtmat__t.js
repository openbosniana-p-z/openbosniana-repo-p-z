var structtmat__t =
[
    [ "n_state", "structtmat__t.html#a3633c71659e30cf23bee1f7efb4b4805", null ],
    [ "n_tmat", "structtmat__t.html#ada644af34d54256f1574870d5f7a6788", null ],
    [ "tp", "structtmat__t.html#a9f518c96b30dab9efdb69bd779a7b5bf", null ]
];