var structps__mgau__s =
[
    [ "frame_idx", "structps__mgau__s.html#a19cc836a740e32d0fa88c46fcdc19d75", null ],
    [ "vt", "structps__mgau__s.html#a931f7cbf334b8ed50b0e1c2803a10c67", null ]
];