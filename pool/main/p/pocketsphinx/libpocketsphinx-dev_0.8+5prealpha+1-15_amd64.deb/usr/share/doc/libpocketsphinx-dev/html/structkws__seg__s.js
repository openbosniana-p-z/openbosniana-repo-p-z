var structkws__seg__s =
[
    [ "base", "structkws__seg__s.html#ab8b059f475f5e64301195cf9816bde2a", null ],
    [ "detection", "structkws__seg__s.html#a5de99d98b2be6e0348033c9fc05ec139", null ],
    [ "last_frame", "structkws__seg__s.html#a7c7afd51e8b0484936fe23039f111151", null ]
];