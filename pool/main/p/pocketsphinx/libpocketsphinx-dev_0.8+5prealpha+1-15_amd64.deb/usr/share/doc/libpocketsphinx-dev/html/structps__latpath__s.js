var structps__latpath__s =
[
    [ "next", "structps__latpath__s.html#a614ad4a857fb07f76959d385abf50a6d", null ],
    [ "node", "structps__latpath__s.html#a9672f7a5002d994985039aece2a69250", null ],
    [ "parent", "structps__latpath__s.html#a87acd26322fca11aa1432cdf9d1a2128", null ],
    [ "score", "structps__latpath__s.html#a9249fb528f754db992df1d494a69b580", null ]
];