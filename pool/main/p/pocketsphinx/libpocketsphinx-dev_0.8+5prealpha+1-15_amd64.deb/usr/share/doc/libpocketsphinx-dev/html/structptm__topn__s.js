var structptm__topn__s =
[
    [ "cw", "structptm__topn__s.html#a8a46095488efefa2714214a7a74117b1", null ],
    [ "score", "structptm__topn__s.html#aa2080ad2d4f038cdbfbf46bf90884f56", null ]
];