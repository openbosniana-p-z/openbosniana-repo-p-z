var structphmm__s =
[
    [ "ci", "structphmm__s.html#afe385b65ca02fb4e3a087a0997ea4eac", null ],
    [ "hmm", "structphmm__s.html#a829311265f8df700c9fb628f5bdff0ad", null ],
    [ "lc", "structphmm__s.html#aad9f810256dea9ee491d21eb3a349d1c", null ],
    [ "next", "structphmm__s.html#a62c94d334abbbd2431d5e7e0ace79a14", null ],
    [ "pid", "structphmm__s.html#aee52956004053c676230cd8567366b60", null ],
    [ "rc", "structphmm__s.html#a94ead49959a95398643178d8dc1609f8", null ],
    [ "succlist", "structphmm__s.html#a152d26f99b39098c8027cd2d8372e05c", null ]
];