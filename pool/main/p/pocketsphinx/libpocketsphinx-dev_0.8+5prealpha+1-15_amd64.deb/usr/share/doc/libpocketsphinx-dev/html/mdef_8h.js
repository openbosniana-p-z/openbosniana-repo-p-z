var mdef_8h =
[
    [ "ciphone_t", "structciphone__t.html", "structciphone__t" ],
    [ "phone_t", "structphone__t.html", "structphone__t" ],
    [ "ph_rc_s", "structph__rc__s.html", "structph__rc__s" ],
    [ "ph_lc_s", "structph__lc__s.html", "structph__lc__s" ],
    [ "mdef_t", "structmdef__t.html", "structmdef__t" ],
    [ "mdef_is_fillerphone", "mdef_8h.html#aa75eb2e79e7b9a3c8f4ab3722b997b83", null ],
    [ "N_WORD_POSN", "mdef_8h.html#ac271413770c3e95b993b856967b61487", null ],
    [ "S3_SILENCE_CIPHONE", "mdef_8h.html#a87b279af2566a60666495e16d09a8aee", null ],
    [ "WPOS_NAME", "mdef_8h.html#a89ef0442ded2ff90176ba6d02563923d", null ],
    [ "word_posn_t", "mdef_8h.html#a71b2bcae7b6e79bad584cc5500b20e8f", [
      [ "WORD_POSN_INTERNAL", "mdef_8h.html#a71b2bcae7b6e79bad584cc5500b20e8fa034bedf5019d94429746634bc0d37464", null ],
      [ "WORD_POSN_BEGIN", "mdef_8h.html#a71b2bcae7b6e79bad584cc5500b20e8fa8ca058a8d25d38d074e028460833c8a9", null ],
      [ "WORD_POSN_END", "mdef_8h.html#a71b2bcae7b6e79bad584cc5500b20e8fa85b62e42f20399f933b33099290989c3", null ],
      [ "WORD_POSN_SINGLE", "mdef_8h.html#a71b2bcae7b6e79bad584cc5500b20e8fa34f808e43d8f6e9312054f34a8bd74ac", null ],
      [ "WORD_POSN_UNDEFINED", "mdef_8h.html#a71b2bcae7b6e79bad584cc5500b20e8fa6b0544f6dcc29f8f4f46de22f28ff9b6", null ]
    ] ],
    [ "mdef_ciphone_id", "mdef_8h.html#aa2c122222a6c9826f16df4644eb6cfd1", null ],
    [ "mdef_ciphone_str", "mdef_8h.html#a2cee9855120537c9c9623518fed347bf", null ],
    [ "mdef_free", "mdef_8h.html#a38d2a4b150ecb10a3c80f3504cfdc63d", null ],
    [ "mdef_free_recursive_lc", "mdef_8h.html#a237854c5a842ee89a099209014a68eba", null ],
    [ "mdef_free_recursive_rc", "mdef_8h.html#ab8db39894feff4c891bc062eae5ea6dd", null ],
    [ "mdef_hmm_cmp", "mdef_8h.html#a49424df076ebbabc5c8e34bd9db54616", null ],
    [ "mdef_init", "mdef_8h.html#a75d27e2dba103a613c571695ba5f7775", null ],
    [ "mdef_is_ciphone", "mdef_8h.html#a9e3f89c3fe09a235beafe056be18c6ce", null ],
    [ "mdef_is_cisenone", "mdef_8h.html#ab6d74ce89ba1f174789a8c5a4add9946", null ],
    [ "mdef_phone_id", "mdef_8h.html#a34cafc86f7db4e18389556c8eaca5f02", null ],
    [ "mdef_phone_str", "mdef_8h.html#a2e23174c9285fbb98f60670644c89712", null ],
    [ "mdef_report", "mdef_8h.html#ad6748527975b2653049b80dabfaa69f1", null ]
];