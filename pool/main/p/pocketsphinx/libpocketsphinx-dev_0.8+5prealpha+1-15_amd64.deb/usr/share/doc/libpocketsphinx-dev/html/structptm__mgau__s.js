var structptm__mgau__s =
[
    [ "base", "structptm__mgau__s.html#ac7ccb744c03564e3c1b360b3436cb3a1", null ],
    [ "config", "structptm__mgau__s.html#aa9cd83ce89052bd6d112ecff54d118f9", null ],
    [ "f", "structptm__mgau__s.html#aad0c43234e33c2307ce0df2ddb1c05c9", null ],
    [ "g", "structptm__mgau__s.html#adfba8a590e8d71812ea8082f485e7ad3", null ],
    [ "hist", "structptm__mgau__s.html#a68c75460ebffecc786d7eb2840ed7631", null ],
    [ "mixw", "structptm__mgau__s.html#af0898f6d5b5b863901a4a4858a10d32a", null ],
    [ "n_fast_hist", "structptm__mgau__s.html#ac491c223199ed5374dfb13fc41854601", null ],
    [ "n_sen", "structptm__mgau__s.html#ab0f6c452efe082383e906ac2a4f75de4", null ],
    [ "sen2cb", "structptm__mgau__s.html#a5e677255165b8abda63dd1d6dbed1be7", null ]
];