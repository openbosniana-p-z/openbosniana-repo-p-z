var structmdef__entry__s =
[
    [ "ci", "structmdef__entry__s.html#a93fd91617129c5954df1566091bb47a7", null ],
    [ "ctx", "structmdef__entry__s.html#a8871e34a41ee5f75a6352f3edfe2b0c5", null ],
    [ "ssid", "structmdef__entry__s.html#a12986649de9c59de3cc805e375b2c9a2", null ],
    [ "tmat", "structmdef__entry__s.html#a90758df5d6eb00d3a70135ac4475c7a1", null ]
];