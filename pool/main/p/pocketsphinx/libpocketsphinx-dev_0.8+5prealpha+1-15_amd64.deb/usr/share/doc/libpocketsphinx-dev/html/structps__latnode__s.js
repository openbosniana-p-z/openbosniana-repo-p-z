var structps__latnode__s =
[
    [ "alt", "structps__latnode__s.html#aa4c0a395c74acbacccde561f92fa89e4", null ],
    [ "basewid", "structps__latnode__s.html#ae3b3dc7d14347e6380859c74b9a02589", null ],
    [ "best_exit", "structps__latnode__s.html#a855680c8e26809995d6a341308858984", null ],
    [ "entries", "structps__latnode__s.html#a051a7eed31e29dd75151d1b34cc4eefa", null ],
    [ "exits", "structps__latnode__s.html#a5232eefbc6e800b77e7a3c8ee3f4135d", null ],
    [ "fanin", "structps__latnode__s.html#a74ba4cfd8ebbb73772b8377d4517d9c0", null ],
    [ "fef", "structps__latnode__s.html#a584ee5a303355d851ac903718998df14", null ],
    [ "id", "structps__latnode__s.html#a78243b37753f7a209c15d6adf98ee3f7", null ],
    [ "lef", "structps__latnode__s.html#a5c7b9114d131151d6ce85228ea9f829d", null ],
    [ "next", "structps__latnode__s.html#aca6f3d543a1712a1ca3bb8ec60f71c84", null ],
    [ "node_id", "structps__latnode__s.html#a50d14c033652a4fb387f76881df1c3f6", null ],
    [ "reachable", "structps__latnode__s.html#af9c4c69f5f85bbc36818357a52432565", null ],
    [ "rem_score", "structps__latnode__s.html#ac0e665aedad3044c79b35c4038627a77", null ],
    [ "sf", "structps__latnode__s.html#a4171e956043e7856c04d84498f16cf29", null ],
    [ "velist", "structps__latnode__s.html#ae66af31a8e7e1d1cae25a3f3938ffc34", null ],
    [ "wid", "structps__latnode__s.html#afd85dbd410d6e6d970c73088bc6fb97e", null ]
];