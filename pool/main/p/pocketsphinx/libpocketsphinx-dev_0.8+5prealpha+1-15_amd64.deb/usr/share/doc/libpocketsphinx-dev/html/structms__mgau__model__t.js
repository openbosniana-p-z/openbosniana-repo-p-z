var structms__mgau__model__t =
[
    [ "g", "structms__mgau__model__t.html#a91027cdb757280ac557668068e6f1b07", null ],
    [ "s", "structms__mgau__model__t.html#a551527ce9cd5702d854a1a5600122985", null ],
    [ "topn", "structms__mgau__model__t.html#a0a67ef79bd74c55734b0944f0d61b668", null ]
];