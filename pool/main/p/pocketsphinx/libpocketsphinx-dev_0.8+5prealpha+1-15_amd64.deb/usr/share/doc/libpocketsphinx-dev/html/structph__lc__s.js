var structph__lc__s =
[
    [ "lc", "structph__lc__s.html#adfb4e9553a4e2314543f9f1ef661185e", null ],
    [ "next", "structph__lc__s.html#a5cda7044037678163c2242dde19df13a", null ],
    [ "rclist", "structph__lc__s.html#aac24b848d70d96894c312d16050c4051", null ]
];