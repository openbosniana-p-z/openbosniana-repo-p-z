var structs2__semi__mgau__s =
[
    [ "base", "structs2__semi__mgau__s.html#a9002aae86249006f0b045e5203ec9687", null ],
    [ "f", "structs2__semi__mgau__s.html#ad8cb7f058bcc7402dd6a41c61f1b26e5", null ],
    [ "n_topn_hist", "structs2__semi__mgau__s.html#a3cbc9fe683da5b7befe6b2712adae327", null ],
    [ "topn_hist", "structs2__semi__mgau__s.html#a8892e22acbf81b08972cb6d7968ed4ce", null ],
    [ "topn_hist_n", "structs2__semi__mgau__s.html#acfe1e5d43a25418ef19afba837f85cf7", null ]
];