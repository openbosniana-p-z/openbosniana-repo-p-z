var ptm__mgau_8h =
[
    [ "ptm_topn_s", "structptm__topn__s.html", "structptm__topn__s" ],
    [ "ptm_fast_eval_s", "structptm__fast__eval__s.html", "structptm__fast__eval__s" ],
    [ "ptm_mgau_s", "structptm__mgau__s.html", "structptm__mgau__s" ],
    [ "ptm_mgau_frame_eval", "ptm__mgau_8h.html#ae9fb76ef388e6541bd6c1b20fe8bc094", null ]
];