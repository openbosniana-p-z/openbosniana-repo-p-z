var structbin__mdef__s =
[
    [ "alloc_mode", "structbin__mdef__s.html#a076f73c8dddba8459dcad61e6e564f93", null ],
    [ "cd2cisen", "structbin__mdef__s.html#ad5e814ffa116c85d46359e3ffd40bff7", null ],
    [ "cd_tree", "structbin__mdef__s.html#a0642be2bb56149689ad3fc1dad1e5d55", null ],
    [ "ciname", "structbin__mdef__s.html#afdd0df913746b0656186fc8c3e8a9206", null ],
    [ "filemap", "structbin__mdef__s.html#a3358a80c50bf3f62417596553adf9c5e", null ],
    [ "n_cd_tree", "structbin__mdef__s.html#ad625c3c55d5f42ed275b8b5638a6d80b", null ],
    [ "n_ci_sen", "structbin__mdef__s.html#ad7c318d6db85fd4b8ac13a81c145bbb8", null ],
    [ "n_ciphone", "structbin__mdef__s.html#a84d5f7acc6d85ba8c7611945f9c5e4e7", null ],
    [ "n_ctx", "structbin__mdef__s.html#a31b5cda5136c6f72816da8889719bfe2", null ],
    [ "n_emit_state", "structbin__mdef__s.html#a2ad87254182be424ac6ff1234274f134", null ],
    [ "n_phone", "structbin__mdef__s.html#ad746dbb3f8108f575a95182f96b4b18f", null ],
    [ "n_sen", "structbin__mdef__s.html#a3d1c202165d8e5e153a73d708ca28109", null ],
    [ "n_sseq", "structbin__mdef__s.html#ab9dad211cbc12eb6f848482bcf78d47f", null ],
    [ "n_tmat", "structbin__mdef__s.html#a979557ad4f8369e84d93f633512345ca", null ],
    [ "phone", "structbin__mdef__s.html#a2c73ae900d198460a30bce4f641d8398", null ],
    [ "sen2cimap", "structbin__mdef__s.html#a457e5352e52a57de5d1536bcd6b331a9", null ],
    [ "sil", "structbin__mdef__s.html#a9071b7698132c1c2ce92a6f742e1c82f", null ],
    [ "sseq", "structbin__mdef__s.html#acb58480658812de7a357dcbd25ad7b41", null ],
    [ "sseq_len", "structbin__mdef__s.html#ab534bbd280015795b8e8ca4e296f4946", null ]
];