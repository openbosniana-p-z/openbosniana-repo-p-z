# encoding: utf-8


__author__ = "MetaCommunications Engineering"
__author_email__ = "metacomm@users.sourceforge.net"
__maintainer__ = "Tsuyoshi Hombashi"
__maintainer_email__ = "tsuyoshi.hombashi@gmail.com"
__license__ = "MIT License"
__version__ = "2.5.0"
