# encoding: utf-8

from .__version__ import (
    __author__,
    __author_email__,
    __license__,
    __maintainer__,
    __maintainer_email__,
    __version__,
)
from .allpairs import AllPairs
