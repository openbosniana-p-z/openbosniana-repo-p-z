 alter extension pre_prepare add function discard();
 alter extension pre_prepare add function prepare_all();
 alter extension pre_prepare add function prepare_all(text);
