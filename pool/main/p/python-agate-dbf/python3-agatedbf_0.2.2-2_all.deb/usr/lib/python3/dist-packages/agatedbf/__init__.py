#!/usr/bin/env python

import agatedbf.table
