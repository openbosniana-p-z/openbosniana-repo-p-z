import os.path

# generic system paths
chkconfig_binary = "/sbin/chkconfig"
find_executable = "/usr/bin/find"
killall_executable = "/usr/bin/killall"
rm_executable = "/bin/rm"
ruby_executable = "/usr/bin/ruby"
service_binary = ""
systemctl_binary = "/bin/systemctl"
systemd_unit_path = "/etc/systemd/system:/etc/systemd/system:/run/systemd/system:/usr/local/lib/systemd/system:/lib/systemd/system:/usr/lib/systemd/system:/lib/systemd/system".split(":")
certutil_executable = "/usr/bin/certutil"


# pcs
pcs_version = "0.11.5"
pcs_bundled_packages_dir = os.path.join("/usr/share/pcs/pcs_bundled", "packages")
pcs_data_dir = "/usr/share/pcs/data/"


# pcsd
pcsd_exec_location = "/usr/share/pcsd"
# Set pcsd_gem_path to None if there are no bundled ruby gems and the path does
# not exists.
pcsd_gem_path = "" or None
pcsd_unix_socket = "/var/run/pcsd.socket"
pcsd_ruby_socket = "/var/run/pcsd-ruby.socket"
pcsd_log_location = "/var/log/pcsd/pcsd.log"
pcsd_default_port = 2224
pcsd_config = "/etc/default/pcsd"

pcsd_var_location = "/var/lib/pcsd"
pcsd_cert_location = os.path.join(pcsd_var_location, "pcsd.crt")
pcsd_dr_config_location = os.path.join(pcsd_var_location, "disaster-recovery")
pcsd_key_location = os.path.join(pcsd_var_location, "pcsd.key")
pcsd_known_hosts_location = os.path.join(pcsd_var_location, "known-hosts")
pcsd_settings_conf_location = os.path.join(
    pcsd_var_location, "pcs_settings.conf"
)
pcsd_users_conf_location = os.path.join(pcsd_var_location, "pcs_users.conf")

default_ssl_ciphers = "DEFAULT:!RC4:!3DES:@STRENGTH"
# Ssl options are based on default options in python (maybe with some extra
# options). Format here is the same as the PCSD_SSL_OPTIONS environment
# variable format (string with coma as a delimiter).
default_ssl_options = ",".join(
    [
        "OP_NO_COMPRESSION",
        "OP_CIPHER_SERVER_PREFERENCE",
        "OP_SINGLE_DH_USE",
        "OP_SINGLE_ECDH_USE",
        "OP_NO_SSLv2",
        "OP_NO_SSLv3",
        "OP_NO_TLSv1",
        "OP_NO_TLSv1_1",
        "OP_NO_RENEGOTIATION",
    ]
)
default_request_timeout = 60
gui_session_lifetime_seconds = 60 * 60
pcsd_token_max_bytes = 256

# pcsd task scheduler settings
async_api_scheduler_interval_ms = 100
pcsd_worker_count = 10
pcsd_temporary_workers = 10
pcsd_worker_reset_limit = 100
pcsd_deadlock_threshold_timeout = 5
task_unresponsive_timeout_seconds = 60 * 60
task_abandoned_timeout_seconds = 1 * 60
task_deletion_timeout_seconds = 1 * 60


# corosync
corosync_binaries = "/usr/sbin"
corosync_conf_dir = "/etc/corosync"
corosync_conf_file = os.path.join(corosync_conf_dir, "corosync.conf")
corosync_uidgid_dir = os.path.join(corosync_conf_dir, "uidgid.d")
corosync_authkey_file = os.path.join(corosync_conf_dir, "authkey")
# Must be set to 256 for corosync to work in FIPS environment.
corosync_authkey_bytes = 256
corosync_log_file = "/var/log/corosync/corosync.log"


# corosync qnetd and qdevice
corosync_qnet_binaries = "/usr/bin"
corosync_qdevice_binaries = "/usr/sbin"
corosync_qdevice_conf_dir = "/etc/corosync"
corosync_qdevice_net_server_certs_dir = os.path.join(
    corosync_qdevice_conf_dir, "qnetd/nssdb"
)
corosync_qdevice_net_client_certs_dir = os.path.join(
    corosync_qdevice_conf_dir, "qdevice/net/nssdb"
)
corosync_qdevice_net_client_ca_file_name = "qnetd-cacert.crt"


# pacemaker
pacemaker_binaries = "/usr/sbin"
pacemaker_authkey_file = "/etc/pacemaker/authkey"
# Using the same value as for corosync. Higher values MAY work in FIPS.
pacemaker_authkey_bytes = 256
pacemaker_local_state_dir = os.path.join(
    "/", "/var", "lib/pacemaker"
)
pacemaker_daemon_dir = "/usr/lib/pacemaker"
pacemaker_schedulerd = os.path.join(
    pacemaker_daemon_dir, "pacemaker-schedulerd"
)
pacemaker_controld = os.path.join(pacemaker_daemon_dir, "pacemaker-controld")
pacemaker_based = os.path.join(pacemaker_daemon_dir, "pacemaker-based")
pacemaker_fenced = os.path.join(pacemaker_daemon_dir, "pacemaker-fenced")
crm_resource_binary = "/usr/sbin/crm_resource"
crm_mon = "/usr/sbin/crm_mon"
crm_report = "/usr/sbin/crm_report"
crm_rule = "/usr/sbin/crm_rule"
crm_diff = "/usr/sbin/crm_diff"
cibadmin = "/usr/sbin/cibadmin"
stonith_admin = "/usr/sbin/stonith_admin"
pacemaker_api_result_schema = "/usr/share/pacemaker/api/api-result.rng"
cib_dir = "/var/lib/pacemaker/cib"
pacemaker_uname = "hacluster"
pacemaker_gname = "haclient"
pacemaker_wait_timeout_status = 124


# resource / stonith agents
fence_agent_binaries = "/usr/sbin"


# sbd
sbd_binary = "/usr/sbin/sbd"
sbd_config = "/etc/default/sbd"
# this limit is also mentioned in docs, change there as well
sbd_max_device_num = 3
# message types are also mentioned in docs, change there as well
sbd_message_types = ["test", "reset", "off", "crashdump", "exit", "clear"]
sbd_watchdog_default = "/dev/watchdog"


# booth
# Booth does not support keys longer than 64 bytes.
booth_authkey_bytes = 64
booth_authkey_file_mode = 0o600
booth_binary = "/usr/sbin/booth"
booth_config_dir = "/etc/booth"
booth_enable_authfile_set_enabled = False
booth_enable_authfile_unset_enabled = False or booth_enable_authfile_set_enabled


# path manager
_ocf_1_0_schema_filename = "ocf-1.0.rng"
_ocf_1_1_schema_filename = "ocf-1.1.rng"


class _PathManager:
    @property
    def ocf_1_0_schema(self):
        return os.path.join(pcs_data_dir, _ocf_1_0_schema_filename)

    @property
    def ocf_1_1_schema(self):
        return os.path.join(pcs_data_dir, _ocf_1_1_schema_filename)

    @property
    def pcs_data_dir(self):
        return pcs_data_dir


path = _PathManager()
