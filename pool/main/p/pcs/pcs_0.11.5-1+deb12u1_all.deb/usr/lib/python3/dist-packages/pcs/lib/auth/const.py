from pcs import settings

SUPERUSER = settings.pacemaker_uname
ADMIN_GROUP = settings.pacemaker_gname
