"""
Intention of this package is to provide functions called from
entry points created by setuptools (see setup.py).
"""
