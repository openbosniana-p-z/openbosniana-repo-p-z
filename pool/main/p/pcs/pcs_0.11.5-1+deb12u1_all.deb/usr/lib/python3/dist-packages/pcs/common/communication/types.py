from typing import NewType

CommunicationResultStatus = NewType("CommunicationResultStatus", str)
