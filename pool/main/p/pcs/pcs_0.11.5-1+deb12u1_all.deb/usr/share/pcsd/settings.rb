PCS_VERSION = '0.11.5'
PCS_EXEC = '/usr/sbin/pcs'
PCS_INTERNAL_EXEC = '/usr/share/pcs/pcs_internal'
PCSD_EXEC_LOCATION = '/usr/share/pcsd'
PCSD_VAR_LOCATION = '/var/lib/pcsd'
PCSD_DEFAULT_PORT = 2224
PCSD_RUBY_SOCKET = '/var/run/pcsd-ruby.socket'

CRT_FILE = File.join(PCSD_VAR_LOCATION, 'pcsd.crt')
KEY_FILE = File.join(PCSD_VAR_LOCATION, 'pcsd.key')
KNOWN_HOSTS_FILE_NAME = 'known-hosts'
PCSD_SETTINGS_CONF_LOCATION = File.join(PCSD_VAR_LOCATION, "pcs_settings.conf")
PCSD_DR_CONFIG_LOCATION = File.join(PCSD_VAR_LOCATION, "disaster-recovery")

CRM_MON = "/usr/sbin/crm_mon"
CIBADMIN = "/usr/sbin/cibadmin"
PACEMAKERD = "/usr/sbin/pacemakerd"
CIB_PATH = '/var/lib/pacemaker/cib/cib.xml'
PACEMAKER_AUTHKEY='/etc/pacemaker/authkey'

COROSYNC_BINARIES = "/usr/sbin"
COROSYNC_CONF = '/etc/corosync/corosync.conf'
COROSYNC_LOG_FILE = '/var/log/corosync/corosync.log'

COROSYNC_QDEVICE_NET_SERVER_CA_FILE = "/etc/corosync/qnetd/nssdb/qnetd-cacert.crt"
COROSYNC_AUTHKEY = "/etc/corosync/authkey"

SBD_CONFIG = '/etc/default/sbd'

BOOTH_CONFIG_DIR='/etc/booth'

SUPERUSER = 'hacluster'
ADMIN_GROUP = 'haclient'

SYSTEMD_UNIT_PATHS = '/etc/systemd/system:/etc/systemd/system:/run/systemd/system:/usr/local/lib/systemd/system:/lib/systemd/system:/usr/lib/systemd/system:/lib/systemd/system'.split(':')
