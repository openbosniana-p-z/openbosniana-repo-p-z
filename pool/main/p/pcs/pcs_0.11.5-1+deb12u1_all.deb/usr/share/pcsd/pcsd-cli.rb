#!/usr/bin/ruby

require 'pcsd-cli-main.rb'

pcsd_cli_main()
