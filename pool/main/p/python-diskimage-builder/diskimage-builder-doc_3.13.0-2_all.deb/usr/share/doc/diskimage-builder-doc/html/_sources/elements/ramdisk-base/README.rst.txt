============
ramdisk-base
============
Shared functionality required by all of the different ramdisk elements.
