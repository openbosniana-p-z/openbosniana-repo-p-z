sysprep
=======

This element holds configuration and scripts that are common for all
distributions.
