==============
debian-upstart
==============
By default Debian will use sysvinit for booting. If you want to experiment
with Upstart, or have need of it due to a need for upstart jobs, this
element will build the image with upstart as the init system.

Note that this works with the ``debian`` element, not the
``debian-minimal`` element.

.. element_deps::
