================
deploy-baremetal
================
A ramdisk that will expose the machine primary disk over iSCSI and reboot
once baremetal-deploy-helper signals it is finished.
