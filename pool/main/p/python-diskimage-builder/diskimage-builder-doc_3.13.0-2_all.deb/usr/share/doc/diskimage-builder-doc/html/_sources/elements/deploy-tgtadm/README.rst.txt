deploy-tgtadm
=============

Use tgtadm and tgtd for the deploy ramdisk

Provides the necessary scripts and dependencies to use tgtadm
and tgtd for exporting the iscsi target in the deploy ramdisk.

Will only work with the standard (not dracut) ramdisk.
