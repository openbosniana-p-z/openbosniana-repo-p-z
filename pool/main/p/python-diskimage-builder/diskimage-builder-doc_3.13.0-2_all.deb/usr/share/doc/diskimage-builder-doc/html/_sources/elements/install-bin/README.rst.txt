===========
install-bin
===========

Add any files in an element's bin directory to /usr/local/bin in the created
image with permissions 0755.
