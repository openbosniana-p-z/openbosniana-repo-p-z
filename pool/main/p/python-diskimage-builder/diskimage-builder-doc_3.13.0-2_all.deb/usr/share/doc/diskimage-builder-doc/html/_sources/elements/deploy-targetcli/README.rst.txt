deploy-targetcli
================

Use targetcli for the deploy ramdisk

Provides the necessary scripts and dependencies to use targetcli
for exporting the iscsi target in the deploy ramdisk.

Implemented as a dracut module, so will only work with dracut-based
ramdisks.
