==============
debian-systemd
==============
You may want to use `systemd` instead of the classic sysv init system.
In this case, include this element in your element list.

Note that this works with the ``debian`` element, not the
``debian-minimal`` element.

.. element_deps::
