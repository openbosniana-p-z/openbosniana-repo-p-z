========
hwburnin
========
A hardware test ramdisk - exercises the machine RAM and exercises the hard
disks
