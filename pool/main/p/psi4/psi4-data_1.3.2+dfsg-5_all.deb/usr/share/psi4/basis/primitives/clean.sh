#!/bin/bash

rm cc*gbs *autogen*gbs ma*gbs apr*gbs jun*gbs heavy*gbs feb*gbs aug*gbs d-aug*gbs tmpB.txt tmpR.txt

