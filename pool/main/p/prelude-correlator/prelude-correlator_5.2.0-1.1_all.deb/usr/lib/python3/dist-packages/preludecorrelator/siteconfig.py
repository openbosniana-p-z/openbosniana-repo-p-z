conf_dir = '//etc/prelude-correlator'
lib_dir = '//var/lib/prelude-correlator'
