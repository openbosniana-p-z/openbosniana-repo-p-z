<?php
/**
 */
class Turba_Exception_NotSupported extends Turba_Exception
{
}
