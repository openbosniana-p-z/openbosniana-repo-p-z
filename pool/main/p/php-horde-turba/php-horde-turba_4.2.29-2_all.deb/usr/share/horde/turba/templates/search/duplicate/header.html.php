<br />
<h3><?php echo $this->h(sprintf(_("Duplicates of %s \"%s\""), $this->type, $this->value)) ?></h3>
<div class="turba-duplicate">
