<div id="entry" data-role="page">
 <?php echo $this->smartmobileHeader(array('backlink' => array('#browse', _("Browse")), 'logout' => true, 'title' => _("View Entry"))) ?>

 <div data-role="content">
  <div id="turba-entry-data" data-role="collapsible-set" data-content-theme="d"></div>
 </div>
</div>
