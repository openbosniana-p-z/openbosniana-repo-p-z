#!/usr/bin/python3
# File: plasmid.py

from tkinter import *
from tkinter.messagebox import *
from tkinter.colorchooser import *
from math import *

# global variables

itemcount=0
plascolor=(0, '#000000')
barcolor=(0, '#000000')
tickcolor=(0, '#000000')

# functions

def help_usage():
    showinfo('Help',"Read the README file \nJust try, it's easy!")

def help_about():
    showinfo('About',"Plasmidomics 0.2 \nLicense: GPLv3 \nRobert Winkler, 2007")

def ask_plascolor():
    global plascolor
    plascolor=askcolor(initialcolor='black')
   
def ask_barcolor():
    global barcolor
    barcolor=askcolor(initialcolor='black')
    
def ask_tickcolor():
    global tickcolor
    tickcolor=askcolor(initialcolor='black')
     
def draw_plasmid():
    global itemcount
    global plascolor
    canvas.create_oval(180-100,180-100,180+100,180+100, width=2, outline=plascolor[1])
    Plasmidname=Plasmidname_string.get()
    canvas.create_text(180,170, text=Plasmidname, fill=plascolor[1])
    Plasmidsize=Plasmidsize_int.get()
    canvas.create_text(170,190, text=Plasmidsize, fill=plascolor[1])
    canvas.create_text(195,190, text=' bp', fill=plascolor[1])
    itemcount=itemcount+4

def draw_bar():
    global itemcount
    global barcolor
    
    Arrowstart=Arrow_startint.get()
    Arrowend=Arrow_endint.get()
    Arrowname=Arrow_string.get()
    Plasmidsize=Plasmidsize_int.get()

    Arrowstart_angle=(2*pi*Arrowstart)/Plasmidsize
    Arrowstartarc=(360*Arrowstart)/Plasmidsize
    Arrowstartsinus=sin(Arrowstart_angle)
    Arrowstartcosinus=cos(Arrowstart_angle)

    Arrowend_angle=(2*pi*Arrowend)/Plasmidsize
    Arrowendarc=(360*Arrowend)/Plasmidsize
    Arrowendsinus=sin(Arrowend_angle)
    Arrowendcosinus=cos(Arrowend_angle)

    Arrowname_pos=(Arrowend+Arrowstart)/2
    Arrowname_angle=(2*pi*Arrowname_pos)/Plasmidsize
    Arrownamesinus=sin(Arrowname_angle)
    Arrownamecosinus=cos(Arrowname_angle)
    
    Arrowextent=Arrowendarc-Arrowstartarc

    canvas.create_text(180+(60*Arrownamesinus),180-(60*Arrownamecosinus), text=Arrowname, fill=barcolor[1])
    canvas.create_arc(180-85,180-85,180+85,180+85,style=ARC, start=90-Arrowendarc, extent=Arrowextent, width=10, outline=barcolor[1])
    
    itemcount=itemcount+2

def draw_arrowright():
    global itemcount
    global barcolor
    
    Arrowstart=Arrow_startint.get()
    Arrowend=Arrow_endint.get()
    Arrowname=Arrow_string.get()
    Plasmidsize=Plasmidsize_int.get()

    Arrowstart_angle=(2*pi*Arrowstart)/Plasmidsize
    Arrowstartarc=(360*Arrowstart)/Plasmidsize
    Arrowstartsinus=sin(Arrowstart_angle)
    Arrowstartcosinus=cos(Arrowstart_angle)

    Arrowend_angle=(2*pi*Arrowend)/Plasmidsize
    Arrowendarc=(360*Arrowend)/Plasmidsize
    Arrowendsinus=sin(Arrowend_angle)
    Arrowendcosinus=cos(Arrowend_angle)
    Arrowendarc_corr=Arrowendarc-5
    Arrowend_angle_corr=Arrowendarc_corr*2*pi/360
    Arrowendsinus_corr=sin(Arrowend_angle_corr)
    Arrowendcosinus_corr=cos(Arrowend_angle_corr)

    Arrowname_pos=(Arrowend+Arrowstart)/2
    Arrowname_angle=(2*pi*Arrowname_pos)/Plasmidsize
    Arrownamesinus=sin(Arrowname_angle)
    Arrownamecosinus=cos(Arrowname_angle)
    
    Arrowextent=Arrowendarc-Arrowstartarc

    canvas.create_polygon(180+(75*Arrowendsinus_corr),180-(75*Arrowendcosinus_corr), 180+(95*Arrowendsinus_corr), 180-(95*Arrowendcosinus_corr), 180+(85*Arrowendsinus), 180-(85*Arrowendcosinus), width=0, outline=barcolor[1], fill=barcolor[1])
    canvas.create_arc(180-85,180-85,180+85,180+85,style=ARC, start=95-Arrowendarc, extent=Arrowextent-5, width=10, outline=barcolor[1])
    canvas.create_text(180+(60*Arrownamesinus),180-(60*Arrownamecosinus), text=Arrowname, fill=barcolor[1])
 
    itemcount=itemcount+3

def draw_arrowleft():
    global itemcount
    global barcolor
    
    Arrowstart=Arrow_startint.get()
    Arrowend=Arrow_endint.get()
    Arrowname=Arrow_string.get()
    Plasmidsize=Plasmidsize_int.get()

    Arrowstart_angle=(2*pi*Arrowstart)/Plasmidsize
    Arrowstartarc=(360*Arrowstart)/Plasmidsize
    Arrowstartsinus=sin(Arrowstart_angle)
    Arrowstartcosinus=cos(Arrowstart_angle)
    Arrowstartarc_corr=Arrowstartarc+5
    Arrowstart_angle_corr=Arrowstartarc_corr*2*pi/360
    Arrowstartsinus_corr=sin(Arrowstart_angle_corr)
    Arrowstartcosinus_corr=cos(Arrowstart_angle_corr)

    Arrowend_angle=(2*pi*Arrowend)/Plasmidsize
    Arrowendarc=(360*Arrowend)/Plasmidsize
    Arrowendsinus=sin(Arrowend_angle)
    Arrowendcosinus=cos(Arrowend_angle)

    Arrowname_pos=(Arrowend+Arrowstart)/2
    Arrowname_angle=(2*pi*Arrowname_pos)/Plasmidsize
    Arrownamesinus=sin(Arrowname_angle)
    Arrownamecosinus=cos(Arrowname_angle)
    
    Arrowextent=Arrowendarc-Arrowstartarc
 
    canvas.create_polygon(180+(75*Arrowstartsinus_corr),180-(75*Arrowstartcosinus_corr), 180+(95*Arrowstartsinus_corr), 180-(95*Arrowstartcosinus_corr), 180+(85*Arrowstartsinus), 180-(85*Arrowstartcosinus), width=0, outline=barcolor[1], fill=barcolor[1])
    canvas.create_arc(180-85,180-85,180+85,180+85,style=ARC, start=90-Arrowendarc, extent=Arrowextent-5, width=10, outline=barcolor[1])
    canvas.create_text(180+(60*Arrownamesinus),180-(60*Arrownamecosinus), text=Arrowname, fill=barcolor[1])

    itemcount=itemcount+3

def draw_tick():
    global itemcount
    global tickcolor
    
    Plasmidsize=Plasmidsize_int.get()
    Tickpos=Ticktick_posint.get()
    Tickname=Ticktick_string.get()

    Tickangle=(2*pi*Tickpos)/Plasmidsize
    Ticksinus=sin(Tickangle)
    Tickcosinus=cos(Tickangle)
  
    canvas.create_text(180+(155*Ticksinus),180-(155*Tickcosinus), text=Tickname, fill=tickcolor[1])
    canvas.create_line(180+(95*Ticksinus),180-(95*Tickcosinus), 180+(105*Ticksinus), 180-(105*Tickcosinus), width=2, fill=tickcolor[1])
    canvas.create_text(180+(120*Ticksinus),180-(120*Tickcosinus), text=Tickpos, fill=tickcolor[1])

    itemcount=itemcount+3

def draw_tickplain():
    global itemcount
    global tickcolor
    
    Plasmidsize=Plasmidsize_int.get()
    Tickpos=Ticktick_posint.get()
    Tickname=Ticktick_string.get()

    Tickangle=(2*pi*Tickpos)/Plasmidsize
    Ticksinus=sin(Tickangle)
    Tickcosinus=cos(Tickangle)
  
    canvas.create_line(180+(95*Ticksinus),180-(95*Tickcosinus), 180+(105*Ticksinus), 180-(105*Tickcosinus), width=2, fill=tickcolor[1])
    canvas.create_text(180+(130*Ticksinus),180-(130*Tickcosinus), text=Tickname, fill=tickcolor[1])

    itemcount=itemcount+2
    
def clear_plasmid():
    global itemcount
    listcanvas=canvas.find_all()
    i=0
    j=listcanvas[0]
    while i < itemcount:
        j=listcanvas[i]
        canvas.delete(j)
        i=i+1
    itemcount=0
        
def undo_item():
    global itemcount
    listcanvas=canvas.find_all()
    j=listcanvas[itemcount-1]
    canvas.delete(j)
    itemcount=itemcount-1
      
def ps_export():
    Plasmidsize=Postfile_string.get()
    psoutfile = Plasmidsize + ".ps"
    canvas.postscript(file=psoutfile)

# define initial values

# main window

root=Tk()
root.title("Plasmidomics 0.2")

# main properties of plasmid

features=Frame(root)
features.pack(side=LEFT)

Mainprop_label = Label(features, text="Main Properties")
Mainprop_label.grid(row=1, column=2, sticky=W)

Plasmidname_label = Label(features, text="Plasmid name:")
Plasmidname_label.grid(row=2, column=1, sticky=W)

Plasmidname_string=StringVar()
Plasmidname_entry = Entry(features, textvariable=Plasmidname_string)
Plasmidname_entry.grid(row=2, column=2, sticky=W)

Plasmidsize_label = Label(features, text="Plasmid size (bp):")
Plasmidsize_label.grid(row=3, column=1, sticky=W)

Plasmidsize_int=IntVar()
Plasmidsize_int.set(1)
Plasmidsize_entry = Entry(features, textvariable=Plasmidsize_int)
Plasmidsize_entry.grid(row=3, column=2, sticky=W)

# bars and arrows

Arrow_label = Label(features, text="Bars and Arrows")
Arrow_label.grid(row=4, column=2, sticky=W)

Arrow_stringlabel = Label(features, text="Description:")
Arrow_stringlabel.grid(row=5, column=1, sticky=W)

Arrow_string=StringVar()
Arrow_stringentry = Entry(features, textvariable=Arrow_string)
Arrow_stringentry.grid(row=5, column=2, sticky=W)

Arrow_startlabel = Label(features, text="Begin:")
Arrow_startlabel.grid(row=6, column=1, sticky=W)

Arrow_startint = IntVar()
Arrow_startint_entry = Entry(features, textvariable=Arrow_startint)
Arrow_startint_entry.grid(row=6, column=2, sticky=W)

Arrow_endlabel = Label(features, text="End:")
Arrow_endlabel.grid(row=7, column=1, sticky=W)

Arrow_endint = IntVar()
Arrow_endint_entry = Entry(features, textvariable=Arrow_endint)
Arrow_endint_entry.grid(row=7, column=2, sticky=W)


# Ticks

Ticks_label = Label(features, text="Ticks")
Ticks_label.grid(row=9, column=2, sticky=W)

Ticktick_poslabel = Label(features, text="Position:")
Ticktick_poslabel.grid(row=11, column=1, sticky=W)

Ticktick_posint = IntVar()
Ticktick_posint_entry = Entry(features, textvariable=Ticktick_posint)
Ticktick_posint_entry.grid(row=11, column=2, sticky=W)

Ticktick_stringlabel = Label(features, text="Description:")
Ticktick_stringlabel.grid(row=10, column=1, sticky=W)

Ticktick_string=StringVar()
Ticktick_stringentry = Entry(features, textvariable=Ticktick_string)
Ticktick_stringentry.grid(row=10, column=2, sticky=W)

# Postscript export file

Post_label = Label(features, text="Graphics Export")
Post_label.grid(row=13, column=2, sticky=W)

Postfile_label = Label(features, text="Export file (without .ps):")
Postfile_label.grid(row=14, column=1, sticky=W)

Postfile_string=StringVar()
Postfile_string.set('outplasmid')
Postfile_entry = Entry(features, textvariable=Postfile_string)
Postfile_entry.grid(row=14, column=2, sticky=W)

# Edit functions

Edit_label = Label(features, text=" ")
Edit_label.grid(row=15, column=2, sticky=W)

# And.. Action!

Clear_button=Button(features, text="Clear", command=clear_plasmid)
Clear_button.grid(row=16, column=1)

Draw_button=Button(features, text="Draw", command=draw_plasmid)
Draw_button.grid(row=3, column=3)

Arrow_button=Button(features, text="Arrow left", command=draw_arrowleft)
Arrow_button.grid(row=8, column=1)

Arrow_button=Button(features, text="Bar", command=draw_bar)
Arrow_button.grid(row=8, column=2)

Arrow_button=Button(features, text="Arrow right", command=draw_arrowright)
Arrow_button.grid(row=8, column=3)

Tick_button=Button(features, text="Add +No", command=draw_tick)
Tick_button.grid(row=12, column=3)

Tickplain_button=Button(features, text="Add -No", command=draw_tickplain)
Tickplain_button.grid(row=12, column=1)

Postscript_button=Button(features, text="PS Export", command=ps_export)
Postscript_button.grid(row=14, column=3)

Undo_button=Button(features, text="Undo", command=undo_item)
Undo_button.grid(row=16, column=3)

Colorplas_button=Button(features, text="Color", command=ask_plascolor)
Colorplas_button.grid(row=2, column=3)

Colorbar_button=Button(features, text="Color", command=ask_barcolor)
Colorbar_button.grid(row=5, column=3)

Colortick_button=Button(features, text="Color", command=ask_tickcolor)
Colortick_button.grid(row=10, column=3)

# Canvas drawing window

canvas=Canvas(width=360, height=360, bg='white')
canvas.pack(side=RIGHT, expand=YES, fill=BOTH)

# draw stuff on canvas

# create a menu

menu = Menu(root)
root.config(menu=menu)

filemenu = Menu(menu)
menu.add_cascade(label="File", menu=filemenu)
filemenu.add_command(label="Exit", command=menu.quit)

helpmenu = Menu(menu)
menu.add_cascade(label="Help", menu=helpmenu)
helpmenu.add_command(label="Usage", command=help_usage)
helpmenu.add_command(label="About...", command=help_about)

mainloop()



