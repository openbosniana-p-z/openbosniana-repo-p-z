# Copyright 2018 John Reese
# Licensed under the MIT license

from .smoke import SmokeTest
