"""
Module defining the Core class, which is the central orchestrator
of poezio and contains the main loop, the list of tabs, sets the state
of everything; it also contains global commands, completions and event
handlers but those are defined in submodules in order to avoir cluttering
this file.
"""
from __future__ import annotations

import logging
import asyncio
import curses
import os
import pipes
import sys
import shutil
import time
from collections import defaultdict
from typing import (
    Any,
    Callable,
    Dict,
    List,
    Optional,
    Set,
    Tuple,
    Type,
    TypeVar,
    TYPE_CHECKING,
)
from xml.etree import ElementTree as ET
from pathlib import Path

from slixmpp import Iq, JID, InvalidJID
from slixmpp.util import FileSystemPerJidCache
from slixmpp.xmlstream.xmlstream import InvalidCABundle
from slixmpp.xmlstream.handler import Callback
from slixmpp.exceptions import IqError, IqTimeout, XMPPError

from poezio import connection
from poezio import decorators
from poezio import events
from poezio import theming
from poezio import timed_events
from poezio import windows
from poezio import utils

from poezio.bookmarks import (
    BookmarkList,
    Bookmark,
)
from poezio.tabs import (
    Tab, XMLTab, ChatTab, ConversationTab, PrivateTab, MucTab, OneToOneTab,
    GapTab, RosterInfoTab, StaticConversationTab, DataFormsTab,
    DynamicConversationTab, STATE_PRIORITY
)
from poezio.common import get_error_message
from poezio.config import config
from poezio.contact import Contact, Resource
from poezio.daemon import Executor
from poezio.fifo import Fifo
from poezio.logger import logger
from poezio.plugin_manager import PluginManager
from poezio.roster import roster
from poezio.size_manager import SizeManager
from poezio.user import User
from poezio.text_buffer import TextBuffer
from poezio.timed_events import DelayedEvent
from poezio import keyboard, xdg

from poezio.core.completions import CompletionCore
from poezio.core.tabs import Tabs
from poezio.core.commands import CommandCore
from poezio.core.command_defs import get_commands
from poezio.core.handlers import HandlerCore
from poezio.core.structs import (
    Command,
    Status,
    POSSIBLE_SHOW,
)

from poezio.ui.types import (
    PersistentInfoMessage,
    UIMessage,
)

if TYPE_CHECKING:
    from _curses import _CursesWindow  # pylint: disable=no-name-in-module

log = logging.getLogger(__name__)

T = TypeVar('T', bound=Tab)


class Core:
    """
    “Main” class of poezion
    """

    custom_version: str
    firstrun: bool
    completion: CompletionCore
    command: CommandCore
    handler: HandlerCore
    bookmarks: BookmarkList
    status: Status
    commands: Dict[str, Command]
    room_number_jump: List[str]
    initial_joins: List[JID]
    pending_invites: Dict[str, str]
    configuration_change_handlers: Dict[str, List[Callable[..., None]]]
    own_nick: str
    connection_time: float
    xmpp: connection.Connection
    avatar_cache: FileSystemPerJidCache
    plugins_autoloaded: bool
    previous_tab_nb: int
    tabs: Tabs
    size: SizeManager
    plugin_manager: PluginManager
    events: events.EventHandler
    legitimate_disconnect: bool
    information_buffer: TextBuffer
    information_win_size: int
    stdscr: Optional[_CursesWindow]
    xml_buffer: TextBuffer
    xml_tab: Optional[XMLTab]
    last_stream_error: Optional[Tuple[float, XMPPError]]
    remote_fifo: Optional[Fifo]
    key_func: KeyDict
    tab_win: windows.GlobalInfoBar
    left_tab_win: Optional[windows.VerticalGlobalInfoBar]

    def __init__(self, custom_version: str, firstrun: bool):
        self.completion = CompletionCore(self)
        self.command = CommandCore(self)
        self.handler = HandlerCore(self)
        self.firstrun = firstrun
        # All uncaught exception are given to this callback, instead
        # of being displayed on the screen and exiting the program.
        sys.excepthook = self.on_exception
        self.connection_time = time.time()
        self.last_stream_error = None
        self.stdscr = None
        status = config.getstr('status')
        status = POSSIBLE_SHOW.get(status) or ''
        self.status = Status(show=status, message=config.getstr('status_message'))
        self.custom_version = custom_version
        self.xmpp = connection.Connection(custom_version)
        self.xmpp.core = self
        self.keyboard = keyboard.Keyboard()
        roster.set_node(self.xmpp.client_roster)
        decorators.refresh_wrapper.core = self
        self.bookmarks = BookmarkList()
        self.remote_fifo = None
        self.avatar_cache = FileSystemPerJidCache(
            str(xdg.CACHE_HOME), 'avatars', binary=True)
        # a unique buffer used to store global information
        # that are displayed in almost all tabs, in an
        # information window.
        self.information_buffer = TextBuffer()
        self.information_win_size = config.getint('info_win_height', section='var')

        # Whether the XML tab is opened
        self.xml_tab = None
        self.xml_buffer = TextBuffer()

        self.plugins_autoloaded = False
        self.plugin_manager = PluginManager(self)
        self.events = events.EventHandler()
        self.events.add_event_handler('tab_change', self.on_tab_change)

        self.tabs = Tabs(self.events, GapTab())
        self.previous_tab_nb = 0

        self.own_nick: str = (
            config.getstr('default_nick') or self.xmpp.boundjid.user or
            os.environ.get('USER') or 'poezio_user'
        )

        self.size = SizeManager(self)

        # Set to True whenever we consider that we have been disconnected
        # from the server because of a legitimate reason (bad credentials,
        # or explicit disconnect from the user for example), in that case we
        # should not try to auto-reconnect, even if auto_reconnect is true
        # in the user config.
        self.legitimate_disconnect = False

        # global commands, available from all tabs
        # a command is tuple of the form:
        # (the function executing the command. Takes a string as argument,
        #  a string representing the help message,
        #  a completion function, taking a Input as argument. Can be None)
        #  The completion function should return True if a completion was
        #  made ; False otherwise
        self.commands = {}
        self.register_initial_commands()

        # We are invisible
        if not config.get('send_initial_presence'):
            del self.commands['status']
            del self.commands['show']

        # A list of integers. For example if the user presses Alt+j, 2, 1,
        # we will insert 2, then 1 in that list, and we will finally build
        # the number 21 and use it with command_win, before clearing the
        # list.
        self.room_number_jump = []
        self.key_func = KeyDict()
        # Key bindings associated with handlers
        # and pseudo-keys used to map actions below.
        key_func = {
            "KEY_PPAGE": self.scroll_page_up,
            "KEY_NPAGE": self.scroll_page_down,
            "^B": self.scroll_line_up,
            "^F": self.scroll_line_down,
            "^X": self.scroll_half_down,
            "^S": self.scroll_half_up,
            "KEY_F(5)": self.rotate_rooms_left,
            "^P": self.rotate_rooms_left,
            "M-[-D": self.rotate_rooms_left,
            "M-[1;3D": self.rotate_rooms_left,
            'kLFT3': self.rotate_rooms_left,
            "KEY_F(6)": self.rotate_rooms_right,
            "^N": self.rotate_rooms_right,
            "M-[-C": self.rotate_rooms_right,
            "M-[1;3C": self.rotate_rooms_right,
            'kRIT3': self.rotate_rooms_right,
            "KEY_F(4)": self.toggle_left_pane,
            "KEY_F(7)": self.shrink_information_win,
            "KEY_F(8)": self.grow_information_win,
            "KEY_RESIZE": self.call_for_resize,
            'M-e': self.go_to_important_room,
            'M-r': self.go_to_roster,
            'M-z': self.go_to_previous_tab,
            '^L': self.full_screen_redraw,
            'M-j': self.go_to_room_number,
            'M-D': self.scroll_info_up,
            'M-C': self.scroll_info_down,
            'M-k': self.escape_next_key,
            ######## actions mappings ##########
            '_noop': lambda *args, **kwargs: None,
            '_bookmark': self.command.bookmark,
            '_bookmark_local': self.command.bookmark_local,
            '_close_tab': self.close_tab,
            '_disconnect': self.disconnect,
            '_quit': self.command.quit,
            '_redraw_screen': self.full_screen_redraw,
            '_reload_theme': self.command.theme,
            '_remove_bookmark': self.command.remove_bookmark,
            '_room_left': self.rotate_rooms_left,
            '_room_right': self.rotate_rooms_right,
            '_show_roster': self.go_to_roster,
            '_scroll_down': self.scroll_page_down,
            '_scroll_up': self.scroll_page_up,
            '_scroll_info_up': self.scroll_info_up,
            '_scroll_info_down': self.scroll_info_down,
            '_server_cycle': self.command.server_cycle,
            '_show_bookmarks': self.command.bookmarks,
            '_show_important_room': self.go_to_important_room,
            '_show_invitations': self.command.invitations,
            '_show_plugins': self.command.plugins,
            '_show_xmltab': self.command.xml_tab,
            '_toggle_pane': self.toggle_left_pane,
            "_go_to_room_name": self.go_to_room_name,
            ###### status actions ######
            '_available': lambda: self.command.status('available'),
            '_away': lambda: self.command.status('away'),
            '_chat': lambda: self.command.status('chat'),
            '_dnd': lambda: self.command.status('dnd'),
            '_xa': lambda: self.command.status('xa'),
            ##### Custom actions ########
        }
        self.key_func.update(key_func)
        self.key_func.try_execute = self.try_execute

        # Add handlers
        xmpp_event_handlers = [
            ('attention', self.handler.on_attention),
            ('carbon_received', self.handler.on_carbon_received),
            ('carbon_sent', self.handler.on_carbon_sent),
            ('changed_status', self.handler.on_presence),
            ('chatstate_active', self.handler.on_chatstate_active),
            ('chatstate_composing', self.handler.on_chatstate_composing),
            ('chatstate_gone', self.handler.on_chatstate_gone),
            ('chatstate_inactive', self.handler.on_chatstate_inactive),
            ('chatstate_paused', self.handler.on_chatstate_paused),
            ('connected', self.handler.on_connected),
            ('connection_failed', self.handler.on_failed_connection),
            ('disconnected', self.handler.on_disconnected),
            ('reconnect_delay', self.handler.on_reconnect_delay),
            ('failed_all_auth', self.handler.on_failed_all_auth),
            ('got_offline', self.handler.on_got_offline),
            ('got_online', self.handler.on_got_online),
            ('groupchat_config_status', self.handler.on_status_codes),
            ('groupchat_decline', self.handler.on_groupchat_decline),
            ('groupchat_direct_invite',
             self.handler.on_groupchat_direct_invitation),
            ('groupchat_invite', self.handler.on_groupchat_invitation),
            ('groupchat_message', self.handler.on_groupchat_message),
            ('groupchat_presence', self.handler.on_groupchat_presence),
            ('groupchat_subject', self.handler.on_groupchat_subject),
            ('http_confirm', self.handler.http_confirm),
            ('message', self.handler.on_message),
            ('message_encryption', self.handler.on_encrypted_message),
            ('message_error', self.handler.on_error_message),
            ('message_xform', self.handler.on_data_form),
            ('no_auth', self.handler.on_no_auth),
            ('presence_error', self.handler.on_presence_error),
            ('receipt_received', self.handler.on_receipt),
            ('roster_subscription_authorized',
             self.handler.on_subscription_authorized),
            ('roster_subscription_remove',
             self.handler.on_subscription_remove),
            ('roster_subscription_removed',
             self.handler.on_subscription_removed),
            ('roster_subscription_request',
             self.handler.on_subscription_request),
            ('roster_update', self.handler.on_roster_update),
            ('session_start', self.handler.on_session_start),
            ('session_start', self.handler.on_session_start_features),
            ('session_end', self.handler.on_session_end),
            ('sm_failed', self.handler.on_session_end),
            ('session_resumed', self.handler.on_session_resumed),
            ('ssl_cert', self.handler.validate_ssl),
            ('ssl_invalid_chain', self.handler.ssl_invalid_chain),
            ('stream_error', self.handler.on_stream_error),
        ]
        for name, handler in xmpp_event_handlers:
            self.xmpp.add_event_handler(name, handler)

        if config.getbool('enable_avatars'):
            self.xmpp.add_event_handler("vcard_avatar_update",
                                        self.handler.on_vcard_avatar)
            self.xmpp.add_event_handler("avatar_metadata_publish",
                                        self.handler.on_0084_avatar)
        if config.getbool('enable_user_nick'):
            self.xmpp.add_event_handler("user_nick_publish",
                                        self.handler.on_nick_received)
        all_stanzas = Callback('custom matcher', connection.MatchAll(None),
                               self.handler.incoming_stanza)
        self.xmpp.register_handler(all_stanzas)

        self.initial_joins = []

        self.pending_invites = {}

        # a dict of the form {'config_option': [list, of, callbacks]}
        # Whenever a configuration option is changed (using /set or by
        # reloading a new config using a signal), all the associated
        # callbacks are triggered.
        # Use Core.add_configuration_handler("option", callback) to add a
        # handler
        # Note that the callback will be called when it’s changed in the
        # global section, OR in a special section.
        # As a special case, handlers can be associated with the empty
        # string option (""), they will be called for every option change
        # The callback takes two argument: the config option, and the new
        # value
        self.configuration_change_handlers = defaultdict(list)
        config_handlers: List[Tuple[str, Callable[..., Any]]] = [
            ('', self.on_any_config_change),
            ('ack_message_receipts', self.on_ack_receipts_config_change),
            ('connection_check_interval', self.xmpp.set_keepalive_values),
            ('connection_timeout_delay', self.xmpp.set_keepalive_values),
            ('create_gaps', self.on_gaps_config_change),
            ('enable_carbons', self.on_carbons_switch),
            ('enable_vertical_tab_list',
             self.on_vertical_tab_list_config_change),
            ('hide_user_list', self.on_hide_user_list_change),
            ('password', self.on_password_change),
            ('plugins_conf_dir',
             self.plugin_manager.on_plugins_conf_dir_change),
            ('plugins_dir', self.plugin_manager.on_plugins_dir_change),
            ('request_message_receipts',
             self.on_request_receipts_config_change),
            ('show_timestamps', self.on_show_timestamps_changed),
            ('theme', self.on_theme_config_change),
            ('themes_dir', theming.update_themes_dir),
            ('use_bookmarks_method', self.on_bookmarks_method_config_change),
            ('vertical_tab_list_size',
             self.on_vertical_tab_list_config_change),
        ]
        for option, handler in config_handlers:
            self.add_configuration_handler(option, handler)

    def _create_windows(self):
        """Create the windows (delayed after curses init)"""
        self.information_win = windows.TextWin(300)
        self.information_buffer.add_window(self.information_win)
        self.left_tab_win = None
        self.tab_win = windows.GlobalInfoBar(self)

    def on_tab_change(self, old_tab: Tab, new_tab: Tab):
        """Whenever the current tab changes, change focus and refresh"""
        old_tab.on_lose_focus()
        new_tab.on_gain_focus()
        self.refresh_window()

    def on_any_config_change(self, option, value):
        """
        Update the roster, in case a roster option changed.
        """
        roster.modified()

    def add_configuration_handler(self, option: str, callback: Callable):
        """
        Add a callback, associated with the given option. It will be called
        each time the configuration option is changed using /set or by
        reloading the configuration with a signal
        """
        self.configuration_change_handlers[option].append(callback)

    def trigger_configuration_change(self, option, value):
        """
        Triggers all the handlers associated with the given configuration
        option
        """
        # First call the callbacks associated with any configuration change
        for callback in self.configuration_change_handlers[""]:
            callback(option, value)
        # and then the callbacks associated with this specific option, if
        # any
        if option not in self.configuration_change_handlers:
            return
        for callback in self.configuration_change_handlers[option]:
            callback(option, value)

    def on_hide_user_list_change(self, option, value):
        """
        Called when the hide_user_list option changes
        """
        self.call_for_resize()

    def on_show_timestamps_changed(self, option, value):
        """
        Called when the show_timestamps option changes
        """
        self.call_for_resize(ui_config_changed=True)

    def on_bookmarks_method_config_change(self, option, value):
        """
        Called when the use_bookmarks_method option changes
        """
        if value not in ('pep', 'privatexml'):
            return
        self.bookmarks.preferred = value
        asyncio.create_task(
            self.bookmarks.save(self.xmpp, core=self)
        )

    def on_gaps_config_change(self, option, value):
        """
        Called when the option create_gaps is changed.
        Remove all gaptabs if switching from gaps to nogaps.
        """
        self.tabs.update_gaps(value.lower() != "false")

    def on_request_receipts_config_change(self, option, value):
        """
        Called when the request_message_receipts option changes
        """
        self.xmpp.plugin['xep_0184'].auto_request = config.get(
            option, default=True)

    def on_ack_receipts_config_change(self, option, value):
        """
        Called when the ack_message_receipts option changes
        """
        self.xmpp.plugin['xep_0184'].auto_ack = config.get(
            option, default=True)

    def on_vertical_tab_list_config_change(self, option, value):
        """
        Called when the enable_vertical_tab_list option is changed
        """
        self.call_for_resize()

    def on_theme_config_change(self, option, value):
        """
        Called when the theme option is changed
        """
        error_msg = theming.reload_theme()
        if error_msg:
            self.information(error_msg, 'Warning')
        self.refresh_window()

    def on_password_change(self, option, value):
        """
        Set the new password in the slixmpp.ClientXMPP object
        """
        self.xmpp.password = value

    def on_carbons_switch(self, option, value):
        """Whenever the user enables or disables carbons using /set, we should
        inform the server immediately, this way we do not require a restart
        for the change to take effect
        """
        if value:
            self.xmpp.plugin['xep_0280'].enable()
        else:
            self.xmpp.plugin['xep_0280'].disable()

    def reload_config(self):
        # reload all log files
        log.debug("Reloading the log files…")
        logger.reload_all()
        log.debug("Log files reloaded.")
        # reload the theme
        log.debug("Reloading the theme…")
        theming.reload_theme()
        log.debug("Theme reloaded.")
        # reload the config from the disk
        log.debug("Reloading the config…")
        # Copy the old config in a dict
        old_config = config.to_dict()
        config.read_file()
        # Compare old and current config, to trigger the callbacks of all
        # modified options
        for section in config.sections():
            old_section = old_config.get(section, {})
            for option in config.options(section):
                old_value = old_section.get(option)
                new_value = config.get(option, default="", section=section)
                if new_value != old_value:
                    self.trigger_configuration_change(option, new_value)
        log.debug("Config reloaded.")
        for name, plugin in self.plugin_manager.plugins.items():
            plugin.config.read_file()
            log.debug("Config reloaded for plugin %s", name)
        # in case some roster options have changed
        roster.modified()

    def sigusr_handler(self, num, stack):
        """
        Handle SIGUSR1 (10)
        When caught, reload all the possible files.
        """
        log.debug("SIGUSR1 caught, reloading the files…")
        self.reload_config()

    def exit_from_signal(self, *args, **kwargs):
        """
        Quit when receiving SIGHUP or SIGTERM or SIGPIPE

        do not save the config because it is not a normal exit
        (and only roster UI things are not yet saved)
        """
        sig = args[0]
        signals = {
            1: 'SIGHUP',
            13: 'SIGPIPE',
            15: 'SIGTERM',
        }

        log.error("%s received. Exiting…", signals[sig])
        self.plugin_manager.disable_plugins()
        self.disconnect('%s received' % signals.get(sig))
        self.xmpp.add_event_handler("disconnected", self.exit, disposable=True)

    def autoload_plugins(self):
        """
        Load the plugins on startup.
        """
        plugins = config.getstr('plugins_autoload')
        if ':' in plugins:
            for plugin in plugins.split(':'):
                self.plugin_manager.load(plugin, unload_first=False)
        else:
            for plugin in plugins.split():
                self.plugin_manager.load(plugin, unload_first=False)
        self.plugins_autoloaded = True

    def start(self):
        """
        Init curses, create the first tab, etc
        """
        self.stdscr = curses.initscr()
        self._init_curses(self.stdscr)
        windows.base_wins.TAB_WIN = self.stdscr
        self._create_windows()
        self.call_for_resize()
        default_tab = RosterInfoTab(self)
        default_tab.on_gain_focus()
        self.tabs.append(default_tab)
        self.information('Welcome to poezio!', 'Info')
        if curses.COLORS < 256:
            self.information(
                'Your terminal does not appear to support 256 colors, the UI'
                ' colors will probably be ugly',
                'Error',
            )
        if self.firstrun:
            self.information(
                'It seems that it is the first time you start poezio.\n'
                'The online help is here https://doc.poez.io/\n\n'
                'No room is joined by default, but you can join poezio’s'
                ' room (with \x19b/join poezio@muc.poez.io\x19o), where you can'
                ' ask for help or tell us how great it is.\n\n'
                'Note that all of your discussions are currently logged'
                ' to the disk, you can prevent that with'
                ' \x19b/set use_log false\x19o', 'Help')
        self.refresh_window()
        self.xmpp.plugin['xep_0012'].begin_idle(jid=self.xmpp.boundjid)

    def exit(self, event=None):
        log.debug("exit(%s)", event)
        asyncio.get_event_loop().stop()

    def on_exception(self, typ, value, trace):
        """
        When an exception is raised, just reset curses and call
        the original exception handler (will nicely print the traceback)
        """
        try:
            self.reset_curses()
        except:
            pass
        sys.__excepthook__(typ, value, trace)

    def sigwinch_handler(self, *args):
        """A work-around for ncurses resize stuff, which sucks. Normally, ncurses
        catches SIGWINCH itself. In its signal handler, it updates the
        windows structures (for example the size, etc) and it
        ungetch(KEY_RESIZE). That way, the next time we call getch() we know
        that a resize occurred and we can act on it. BUT poezio doesn’t call
        getch() until it knows it will return something. The problem is we
        can’t know that, because stdin is not affected by this KEY_RESIZE
        value (it is only inserted in a ncurses internal fifo that we can’t
        access).

        The (ugly) solution is to handle SIGWINCH ourself, trigger the
        change of the internal windows sizes stored in ncurses module, using
        sizes that we get using shutil, ungetch the KEY_RESIZE value and
        then call getch to handle the resize on poezio’s side properly.
        """
        size = shutil.get_terminal_size()
        curses.resizeterm(size.lines, size.columns)
        curses.ungetch(curses.KEY_RESIZE)
        self.on_input_readable()

    def on_input_readable(self):
        """
        main loop waiting for the user to press a key
        """

        log.debug("Input is readable.")
        big_char_list = [replace_key_with_bound(key)\
                         for key in self.read_keyboard()]
        log.debug("Got from keyboard: %s", (big_char_list, ))

        # whether to refresh after ALL keys have been handled
        for char_list in separate_chars_from_bindings(big_char_list):
            # Special case for M-x where x is a number
            if len(char_list) == 1:
                char = char_list[0]
                if char.startswith('M-') and len(char) == 3:
                    try:
                        nb = int(char[2])
                    except ValueError:
                        pass
                    else:
                        if self.tabs.current_tab.nb == nb and config.getbool(
                                'go_to_previous_tab_on_alt_number'):
                            self.go_to_previous_tab()
                        else:
                            self.command.win('%d' % nb)
                # search for keyboard shortcut
                func = self.key_func.get(char, None)
                if func:
                    func()
                else:
                    self.do_command(replace_line_breaks(char), False)
            else:
                self.do_command(''.join(char_list), True)
        self.doupdate()

    def loop_exception_handler(self, loop, context) -> None:
        """Do not log unhandled iq errors and timeouts"""
        handled_exceptions = (IqError, IqTimeout, InvalidCABundle)
        if not isinstance(context['exception'], handled_exceptions):
            loop.default_exception_handler(context)
        elif isinstance(context['exception'], InvalidCABundle):
            paths = context['exception'].path
            error = (
                'Poezio could not find a valid CA bundle file automatically. '
                'Ensure the ca_cert_path configuration is set to a valid '
                'CA bundle path, generally provided by the \'ca-certificates\' '
                'package in your distribution.'
            )
            if isinstance(paths, (str, Path)):
                # error += '\nFound the following value: {path}'.format(path=str(path))
                paths = [paths]
            if paths is not None:
                error += f"\nThe following values were tried: {str([str(s) for s in paths])}"
            self.information(error, 'Error')

    def save_config(self):
        """
        Save config in the file just before exit
        """
        ok = roster.save_to_config_file()
        ok = ok and config.silent_set('info_win_height',
                                      self.information_win_size, 'var')
        if not ok:
            self.information(
                'Unable to save runtime preferences'
                ' in the config file', 'Error')

    def on_roster_enter_key(self, roster_row):
        """
        when enter is pressed on the roster window
        """
        if isinstance(roster_row, Contact):
            if not self.get_conversation_by_jid(roster_row.bare_jid, False):
                self.open_conversation_window(JID(roster_row.bare_jid))
            else:
                self.focus_tab_named(roster_row.bare_jid)
        if isinstance(roster_row, Resource):
            if not self.get_conversation_by_jid(
                    roster_row.jid, False, fallback_barejid=False):
                self.open_conversation_window(JID(roster_row.jid))
            else:
                self.focus_tab_named(roster_row.jid)
        self.refresh_window()

    def get_conversation_messages(self) -> Optional[List[Tuple]]:
        """
        Returns a list of all the messages in the current chat.
        If the current tab is not a ChatTab, returns None.

        Messages are namedtuples of the form
        ('txt nick_color time str_time nickname user')
        """
        if not isinstance(self.tabs.current_tab, ChatTab):
            return None
        return self.tabs.current_tab.get_conversation_messages()

    def insert_input_text(self, text: str):
        """
        Insert the given text into the current input
        """
        self.do_command(text, True)

##################### Anything related to command execution ###################

    def execute(self, line: str):
        """
        Execute the /command or just send the line on the current room
        """
        if line == "":
            return
        if line.startswith('/'):
            command = line.strip().split()[0][1:]
            arg = line[2 + len(command):]  # jump the '/' and the ' '
            # example. on "/link 0 open", command = "link" and arg = "0 open"
            if command in self.commands:
                func = self.commands[command].func
                func(arg)
                return
            else:
                self.information("Unknown command (%s)" % (command), 'Error')

    def exec_command(self, command):
        """
        Execute an external command on the local or a remote machine,
        depending on the conf. For example, to open a link in a browser, do
        exec_command(["firefox", "http://poezio.eu"]), and this will call
        the command on the correct computer.

        The command argument is a list of strings, not quoted or escaped in
        any way. The escaping is done here if needed.

        The remote execution is done
        by writing the command on a fifo.  That fifo has to be on the
        machine where poezio is running, and accessible (through sshfs for
        example) from the local machine (where poezio is not running). A
        very simple daemon (daemon.py) reads on that fifo, and executes any
        command that is read in it. Since we can only write strings to that
        fifo, each argument has to be pipes.quote()d. That way the
        shlex.split on the reading-side of the daemon will be safe.

        You cannot use a real command line with pipes, redirections etc, but
        this function supports a simple case redirection to file: if the
        before-last argument of the command is ">" or ">>", then the last
        argument is considered to be a filename where the command stdout
        will be written. For example you can do exec_command(["echo",
        "coucou les amis coucou coucou", ">", "output.txt"]) and this will
        work. If you try to do anything else, your |, [, <<, etc will be
        interpreted as normal command arguments, not shell special tokens.
        """
        if config.getbool('exec_remote'):
            # We just write the command in the fifo
            fifo_path = config.getstr('remote_fifo_path')
            filename = os.path.join(fifo_path, 'poezio.fifo')
            if not self.remote_fifo:
                try:
                    self.remote_fifo = Fifo(filename, 'w')
                except (OSError, IOError) as exc:
                    log.error(
                        'Could not open the fifo for writing (%s)',
                        filename,
                        exc_info=True)
                    self.information(
                        'Could not open the fifo '
                        'file for writing: %s' % exc, 'Error')
                    return

            args = (pipes.quote(arg.replace('\n', ' ')) for arg in command)
            command_str = ' '.join(args) + '\n'
            try:
                self.remote_fifo.write(command_str)
            except IOError as exc:
                log.error(
                    'Could not write in the fifo (%s): %s',
                    filename,
                    repr(command),
                    exc_info=True)
                self.information('Could not execute %s: %s' % (command, exc),
                                 'Error')
                self.remote_fifo = None
        else:
            executor = Executor(command)
            try:
                executor.start()
            except ValueError as exc:
                log.error(
                    'Could not execute command (%s)',
                    repr(command),
                    exc_info=True)
                self.information(str(exc), 'Error')

    def do_command(self, key: str, raw: bool):
        """
        Execute the action associated with a key

        Or if keyboard.continuation_keys_callback is set, call it instead. See
        the comment of this variable.
        """
        if not key:
            return
        if keyboard.continuation_keys_callback is not None:
            # Reset the callback to None BEFORE calling it, because this
            # callback MAY set a new callback itself, and we don’t want to
            # erase it in that case
            cb = keyboard.continuation_keys_callback
            keyboard.continuation_keys_callback = None
            cb(key)
        else:
            self.tabs.current_tab.on_input(key, raw)

    def try_execute(self, line: str):
        """
        Try to execute a command in the current tab
        """
        line = '/' + line
        try:
            self.tabs.current_tab.execute_command(line)
        except:
            log.error('Execute failed (%s)', line, exc_info=True)

########################## TImed Events #######################################

    def remove_timed_event(self, event: DelayedEvent) -> None:
        """Remove an existing timed event"""
        if event.handler is not None:
            event.handler.cancel()

    def add_timed_event(self, event: DelayedEvent) -> None:
        """Add a new timed event"""
        event.handler = asyncio.get_event_loop().call_later(
            event.delay, event.callback, *event.args
        )

####################### XMPP-related actions ##################################

    def get_status(self) -> Status:
        """
        Get the last status that was previously set
        """
        return self.status

    def set_status(self, pres: str, msg: str) -> None:
        """
        Set our current status so we can remember
        it and use it back when needed (for example to display it
        or to use it when joining a new muc)
        """
        self.status = Status(show=pres, message=msg)
        if config.getbool('save_status'):
            ok = config.silent_set('status', pres if pres else '')
            msg = msg.replace('\n', '|') if msg else ''
            ok = ok and config.silent_set('status_message', msg)
            if not ok:
                self.information(
                    'Unable to save the status in '
                    'the config file', 'Error')

    def get_bookmark_nickname(self, room_name: str) -> str:
        """
        Returns the nickname associated with a bookmark
        or the default nickname
        """
        bm = self.bookmarks[room_name]
        if bm and bm.nick:
            return bm.nick
        return self.own_nick

    def disconnect(self, msg: str = '', reconnect: bool = False) -> None:
        """
        Disconnect from remote server and correctly set the states of all
        parts of the client (for example, set the MucTabs as not joined, etc)
        """
        self.legitimate_disconnect = True
        if reconnect:
            self.xmpp.reconnect(wait=0.0, reason=msg)
        else:
            for tab in self.get_tabs(MucTab):
                tab.leave_room(msg)
            self.xmpp.disconnect(reason=msg)

    def send_message(self, msg: str) -> bool:
        """
        Function to use in plugins to send a message in the current
        conversation.
        Returns False if the current tab is not a conversation tab
        """
        if not isinstance(self.tabs.current_tab, ChatTab):
            return False
        asyncio.ensure_future(
            self.tabs.current_tab.command_say(msg)
        )
        return True

    async def invite(self, jid: JID, room: JID, reason: Optional[str] = None, force_mediated: bool = False) -> bool:
        """
        Checks if the sender supports XEP-0249, then send an invitation,
        or a mediated one if it does not.
        TODO: allow passwords
        """
        features = set()

        # force mediated: act as if the other entity does not
        # support direct invites
        if not force_mediated:
            try:
                iq = await self.xmpp.plugin['xep_0030'].get_info(
                    jid=jid,
                    timeout=5,
                )
                features = iq['disco_info'].get_features()
            except (IqError, IqTimeout):
                pass
        supports_direct = 'jabber:x:conference' in features
        if supports_direct:
            self.xmpp.plugin['xep_0249'].send_invitation(
                jid=jid,
                roomjid=room,
                reason=reason
            )
        else:  # fallback
            self.xmpp.plugin['xep_0045'].invite(
                jid=jid,
                room=room,
                reason=reason or '',
            )
        return True

    def _impromptu_room_form(self, room) -> Iq:
        fields = [
            ('hidden', 'FORM_TYPE', 'http://jabber.org/protocol/muc#roomconfig'),
            ('boolean', 'muc#roomconfig_changesubject', True),
            ('boolean', 'muc#roomconfig_allowinvites', True),
            ('boolean', 'muc#roomconfig_persistent', True),
            ('boolean', 'muc#roomconfig_membersonly', True),
            ('boolean', 'muc#roomconfig_publicroom', False),
            ('list-single', 'muc#roomconfig_whois', 'anyone'),
            # MAM
            ('boolean', 'muc#roomconfig_enablearchiving', True),  # Prosody
            ('boolean', 'mam', True),  # Ejabberd community
            ('boolean', 'muc#roomconfig_mam', True),  # Ejabberd saas
        ]

        form = self.xmpp['xep_0004'].make_form()
        form['type'] = 'submit'
        for field in fields:
            form.add_field(
                ftype=field[0],
                var=field[1],
                value=field[2],
            )

        iq = self.xmpp.Iq()
        iq['type'] = 'set'
        iq['to'] = room
        query = ET.Element('{http://jabber.org/protocol/muc#owner}query')
        query.append(form.xml)
        iq.append(query)
        return iq

    async def impromptu(self, jids: Set[JID]) -> None:
        """
        Generates a new "Impromptu" room with a random localpart on the muc
        component of the user who initiated the request. One the room is
        created and the first user has joined, send invites for specified
        contacts to join in.
        """

        results = await self.xmpp['xep_0030'].get_info_from_domain()

        muc_from_identity = ''
        for info in results:
            for identity in info['disco_info']['identities']:
                if identity[0] == 'conference' and identity[1] == 'text':
                    muc_from_identity = info['from'].bare

        # Use config.default_muc_service as muc component if available,
        # otherwise find muc component by disco#items-ing the user domain.
        # If not, give up
        default_muc = config.get('default_muc_service', muc_from_identity)
        if not default_muc:
            self.information(
                "Error finding a MUC service to join. If your server does not "
                "provide one, set 'default_muc_service' manually to a MUC "
                "service that allows room creation.",
                'Error'
            )
            return

        # Retries generating a name until we find a non-existing room.
        # Abort otherwise.
        retries = 3
        while retries > 0:
            localpart = utils.pronounceable()
            room_str = f'{localpart}@{default_muc}'
            try:
                room = JID(room_str)
            except InvalidJID:
                self.information(
                    f'The generated XMPP address is invalid: {room_str}',
                    'Error'
                )
                return None

            try:
                iq = await self.xmpp['xep_0030'].get_info(
                    jid=room,
                    cached=False,
                )
            except IqTimeout:
                pass
            except IqError as exn:
                if exn.etype == 'cancel' and exn.condition == 'item-not-found':
                    log.debug('Found empty room for /impromptu')
                    break

            retries = retries - 1

        if retries == 0:
            self.information(
                'Couldn\'t generate a room name that isn\'t already used.',
                'Error',
            )
            return None

        self.open_new_room(room, self.own_nick).join()

        async def configure_and_invite(_presence):
            iq = self._impromptu_room_form(room)
            try:
                await iq.send()
            except (IqError, IqTimeout):
                self.information('Failed to configure impromptu room.', 'Info')
                # TODO: destroy? leave room.
                return None

            self.information(f'Room {room} created', 'Info')

            for jid in jids:
                await self.invite(jid, room, force_mediated=True)
            jids_str = ', '.join(jids)
            self.information(f'Invited {jids_str} to {room.bare}', 'Info')

        self.xmpp.add_event_handler(
            f'muc::{room.bare}::groupchat_subject',
            configure_and_invite,
            disposable=True,
        )

####################### Tab logic-related things ##############################

### Tab getters ###

    def get_tabs(self, cls: Type[T]) -> List[T]:
        "Get all the tabs of a type"
        return self.tabs.by_class(cls)

    def get_conversation_by_jid(self,
                                jid: JID,
                                create: bool = True,
                                fallback_barejid: bool = True) -> Optional[ChatTab]:
        """
        From a JID, get the tab containing the conversation with it.
        If none already exist, and create is "True", we create it
        and return it. Otherwise, we return None.

        If fallback_barejid is True, then this method will seek other
        tabs with the same barejid, instead of searching only by fulljid.
        """
        jid = JID(jid)
        # We first check if we have a static conversation opened
        # with this precise resource
        conversation: Optional[ConversationTab]
        conversation = self.tabs.by_name_and_class(jid.full,
                                                   StaticConversationTab)
        if jid.bare == jid.full and not conversation:
            conversation = self.tabs.by_name_and_class(
                jid.full, DynamicConversationTab)

        if not conversation and fallback_barejid:
            # If not, we search for a conversation with the bare jid
            conversation = self.tabs.by_name_and_class(
                jid.bare, DynamicConversationTab)
            if not conversation:
                if create:
                    # We create a dynamic conversation with the bare Jid if
                    # nothing was found (and we lock it to the resource
                    # later)
                    conversation = self.open_conversation_window(
                        JID(jid.bare), False)
                else:
                    conversation = None
        return conversation

    def add_tab(self, new_tab: Tab, focus: bool = False) -> None:
        """
        Appends the new_tab in the tab list and
        focus it if focus==True
        """
        self.tabs.append(new_tab)
        if focus:
            self.tabs.set_current_tab(new_tab)

    def insert_tab(self, old_pos: int, new_pos: int = 99999) -> bool:
        """
        Insert a tab at a position, changing the number of the following tabs
        returns False if it could not move the tab, True otherwise
        """
        return self.tabs.insert_tab(old_pos, new_pos,
                                    config.getbool('create_gaps'))

    ### Move actions (e.g. go to next room) ###

    def rotate_rooms_right(self) -> None:
        """
        rotate the rooms list to the right
        """
        self.tabs.next()  # pylint: disable=not-callable

    def rotate_rooms_left(self) -> None:
        """
        rotate the rooms list to the right
        """
        self.tabs.prev()  # pylint: disable=not-callable

    def go_to_room_number(self) -> None:
        """
        Read 2 more chars and go to the tab
        with the given number
        """

        def read_next_digit(digit) -> None:
            try:
                int(digit)
            except ValueError:
                # If it is not a number, we do nothing. If it was the first
                # one, we do not wait for a second one by re-setting the
                # callback
                self.room_number_jump.clear()
            else:
                self.room_number_jump.append(digit)
                if len(self.room_number_jump) == 2:
                    arg = "".join(self.room_number_jump)
                    self.room_number_jump.clear()
                    self.command.win(arg)
                else:
                    # We need to read more digits
                    keyboard.continuation_keys_callback = read_next_digit

        keyboard.continuation_keys_callback = read_next_digit

    def go_to_room_name(self) -> None:
        room_name_jump = []

        def read_next_letter(s) -> None:
            nonlocal room_name_jump
            room_name_jump.append(s)
            any_matched, unique_tab = self.tabs.find_by_unique_prefix(
                "".join(room_name_jump)
            )

            if not any_matched:
                return

            if unique_tab is not None:
                self.tabs.set_current_tab(unique_tab)
                # NOTE: returning here means that as soon as the tab is
                # matched, normal input resumes. If we do *not* return here,
                # any further characters matching the prefix of the tab will
                # be swallowed (and a lot of tab switching will happen...),
                # until a non-matching character or escape or something is
                # pressed.
                # This behaviour *may* be desirable.
                return

            keyboard.continuation_keys_callback = read_next_letter

        keyboard.continuation_keys_callback = read_next_letter

    def go_to_roster(self) -> None:
        "Select the roster as the current tab"
        self.tabs.set_current_tab(self.tabs.first())

    def go_to_previous_tab(self) -> None:
        "Go to the previous tab"
        self.tabs.restore_previous_tab()

    def go_to_important_room(self) -> None:
        """
        Go to the next room with activity, in the order defined in the
        dict STATE_PRIORITY
        """
        # shortcut
        priority = STATE_PRIORITY
        tab_refs: Dict[str, List[Tab]] = {}
        # put all the active tabs in a dict of lists by state
        for tab in self.tabs.get_tabs():
            if not tab:
                continue
            if tab.state not in tab_refs:
                tab_refs[tab.state] = [tab]
            else:
                tab_refs[tab.state].append(tab)
        # sort the state by priority and remove those with negative priority
        states = sorted(
            tab_refs.keys(), key=(lambda x: priority.get(x, 0)), reverse=True)
        states = [state for state in states if priority.get(state, -1) >= 0]

        for state in states:
            for tab in tab_refs[state]:
                if (tab.nb < self.tabs.current_index
                        and tab_refs[state][-1].nb > self.tabs.current_index):
                    continue
                self.tabs.set_current_tab(tab)
                return
        return

    def focus_tab_named(self,
                        tab_name: str,
                        type_: Type[Tab] = None) -> bool:
        """Returns True if it found a tab to focus on"""
        if type_ is None:
            tab = self.tabs.by_name(tab_name)
        else:
            tab = self.tabs.by_name_and_class(tab_name, type_)
        if tab:
            self.tabs.set_current_tab(tab)
            return True
        return False

    def focus_tab(self, tab: Tab) -> bool:
        """Focus a tab"""
        return self.tabs.set_current_tab(tab)

    ### Opening actions ###

    def open_conversation_window(self, jid: JID,
                                 focus=True) -> ConversationTab:
        """
        Open a new conversation tab and focus it if needed. If a resource is
        provided, we open a StaticConversationTab, else a
        DynamicConversationTab
        """
        new_tab: ConversationTab
        if jid.resource:
            new_tab = StaticConversationTab(self, jid)
        else:
            new_tab = DynamicConversationTab(self, jid)
        if not focus:
            new_tab.state = "private"
        self.add_tab(new_tab, focus)
        self.refresh_window()
        return new_tab

    def open_private_window(self, room_name: str, user_nick: str,
                            focus=True) -> Optional[PrivateTab]:
        """
        Open a Private conversation in a MUC and focus if needed.
        """
        complete_jid = room_name + '/' + user_nick
        # if the room exists, focus it and return
        for tab in self.get_tabs(PrivateTab):
            if tab.name == complete_jid:
                self.tabs.set_current_tab(tab)
                return tab
        # create the new tab
        muc_tab = self.tabs.by_name_and_class(room_name, MucTab)
        if not muc_tab:
            return None
        tab = PrivateTab(self, complete_jid, muc_tab.own_nick)
        if hasattr(tab, 'directed_presence'):
            tab.directed_presence = tab.directed_presence
        if not focus:
            tab.state = "private"
        # insert it in the tabs
        self.add_tab(tab, focus)
        self.refresh_window()
        muc_tab.privates.append(tab)
        return tab

    def open_new_room(self,
                      room: JID,
                      nick: str,
                      *,
                      password: Optional[str] = None,
                      focus=True) -> MucTab:
        """
        Open a new tab.MucTab containing a muc Room, using the specified nick
        """
        new_tab = MucTab(self, room, nick, password=password)
        self.add_tab(new_tab, focus)
        self.refresh_window()
        return new_tab

    def open_new_form(self, form, on_cancel: Callable, on_send: Callable,
                      **kwargs) -> None:
        """
        Open a new tab containing the form
        The callback are called with the completed form as parameter in
        addition with kwargs
        """
        form_tab = DataFormsTab(self, form, on_cancel, on_send, kwargs)
        self.add_tab(form_tab, True)

    ### Modifying actions ###

    def rename_private_tabs(self, room_name: str, old_nick: str, user: User) -> None:
        """
        Call this method when someone changes their nick in a MUC,
        this updates the name of all the opened private conversations
        with him/her
        """
        tab = self.tabs.by_name_and_class('%s/%s' % (room_name, old_nick),
                                          PrivateTab)
        if tab:
            tab.rename_user(old_nick, user)

    def on_user_left_private_conversation(self, room_name: str, user: User,
                                          status_message: str) -> None:
        """
        The user left the MUC: add a message in the associated
        private conversation
        """
        tab = self.tabs.by_name_and_class('%s/%s' % (room_name, user.nick),
                                          PrivateTab)
        if tab:
            tab.user_left(status_message, user)

    def on_user_rejoined_private_conversation(self, room_name: str, nick: str) -> None:
        """
        The user joined a MUC: add a message in the associated
        private conversation
        """
        tab = self.tabs.by_name_and_class('%s/%s' % (room_name, nick),
                                          PrivateTab)
        if tab:
            tab.user_rejoined(nick)

    def disable_private_tabs(self,
                             room_name: str,
                             reason: Optional[str] = None) -> None:
        """
        Disable private tabs when leaving a room
        """
        if reason is None:
            reason = '\x195}You left the room\x193}'
        for tab in self.get_tabs(PrivateTab):
            if tab.name.startswith(room_name):
                tab.deactivate(reason=reason)

    def enable_private_tabs(self, room_name: str,
                            reason: Optional[str] = None) -> None:
        """
        Enable private tabs when joining a room
        """
        if reason is None:
            reason = '\x195}You joined the room\x193}'
        for tab in self.get_tabs(PrivateTab):
            if tab.name.startswith(room_name):
                tab.activate(reason=reason)

    def on_user_changed_status_in_private(self, jid: JID, status: Status) -> None:
        tab = self.tabs.by_name_and_class(jid, OneToOneTab)
        if tab is not None:  # display the message in private
            tab.update_status(status)

    def close_tab(self, to_close: Tab = None) -> None:
        """
        Close the given tab. If None, close the current one
        """
        was_current = to_close is None
        tab = to_close or self.tabs.current_tab

        if isinstance(tab, RosterInfoTab):
            return  # The tab 0 should NEVER be closed
        tab.on_close()
        del tab.key_func  # Remove self references
        del tab.commands  # and make the object collectable
        self.tabs.delete(tab, gap=config.getbool('create_gaps'))
        logger.close(tab.name)
        if was_current:
            self.tabs.current_tab.on_gain_focus()
        self.refresh_window()
        import gc
        gc.collect()
        log.debug('___ Referrers of closing tab:\n%s\n______',
                  gc.get_referrers(tab))
        del tab

    def add_information_message_to_conversation_tab(self, jid: JID, msg: str) -> None:
        """
        Search for a ConversationTab with the given jid (full or bare),
        if yes, add the given message to it
        """
        tab = self.tabs.by_name_and_class(jid, ConversationTab)
        if tab is not None:
            tab.add_message(PersistentInfoMessage(msg))
            if self.tabs.current_tab is tab:
                self.refresh_window()

####################### Curses and ui-related stuff ###########################

    def doupdate(self) -> None:
        "Do a curses update"
        curses.doupdate()

    def information(self, msg: str, typ: str = '') -> bool:
        """
        Displays an informational message in the "Info" buffer
        """
        filter_types = config.getlist('information_buffer_type_filter')
        if typ.lower() in filter_types:
            log.debug(
                'Did not show the message:\n\t%s> %s \n\tdue to '
                'information_buffer_type_filter configuration', typ, msg)
            return False
        filter_messages = config.getlist('filter_info_messages')
        for words in filter_messages:
            if words and words in msg:
                log.debug(
                    'Did not show the message:\n\t%s> %s \n\tdue to filter_info_messages configuration',
                    typ, msg)
                return False
        nb_lines = self.information_buffer.add_message(
            UIMessage(
                txt=msg,
                level=typ,
            )
        )
        popup_on = config.getlist('information_buffer_popup_on')
        if isinstance(self.tabs.current_tab, RosterInfoTab):
            self.refresh_window()
        elif typ != '' and typ.lower() in popup_on:
            popup_time = config.getint('popup_time') + (nb_lines - 1) * 2
            self._pop_information_win_up(nb_lines, popup_time)
        else:
            if self.information_win_size != 0:
                self.information_win.refresh()
                self.tabs.current_tab.refresh_input()
        return True

    def _init_curses(self, stdscr) -> None:
        """
        ncurses initialization
        """
        curses.curs_set(1)
        curses.noecho()
        curses.nonl()
        curses.raw()
        stdscr.idlok(1)
        stdscr.keypad(1)
        curses.start_color()
        curses.use_default_colors()
        theming.reload_theme()
        curses.ungetch(" ")  # H4X: without this, the screen is
        stdscr.getkey()  # erased on the first "getkey()"

    def reset_curses(self) -> None:
        """
        Reset terminal capabilities to what they were before ncurses
        init
        """
        curses.echo()
        curses.nocbreak()
        curses.curs_set(1)
        curses.endwin()

    def refresh_window(self) -> None:
        """
        Refresh everything
        """
        nocursor = curses.curs_set(0)
        self.tabs.current_tab.state = 'current'
        self.tabs.current_tab.refresh()
        self.doupdate()
        curses.curs_set(nocursor)

    def refresh_tab_win(self) -> None:
        """
        Refresh the window containing the tab list
        """
        self.tabs.current_tab.refresh_tab_win()
        self.refresh_input()
        self.doupdate()

    def refresh_input(self) -> None:
        """
        Refresh the input if it exists
        """
        if self.tabs.current_tab.input:
            self.tabs.current_tab.input.refresh()
        self.doupdate()

    def scroll_page_down(self):
        """
        Scroll a page down, if possible.
        Returns True on success, None on failure.
        """
        if self.tabs.current_tab.on_scroll_down():
            self.refresh_window()
            return True

    def scroll_page_up(self):
        """
        Scroll a page up, if possible.
        Returns True on success, None on failure.
        """
        if self.tabs.current_tab.on_scroll_up():
            self.refresh_window()
            return True

    def scroll_line_up(self):
        """
        Scroll a line up, if possible.
        Returns True on success, None on failure.
        """
        if self.tabs.current_tab.on_line_up():
            self.refresh_window()
            return True

    def scroll_line_down(self):
        """
        Scroll a line down, if possible.
        Returns True on success, None on failure.
        """
        if self.tabs.current_tab.on_line_down():
            self.refresh_window()
            return True

    def scroll_half_up(self):
        """
        Scroll half a screen down, if possible.
        Returns True on success, None on failure.
        """
        if self.tabs.current_tab.on_half_scroll_up():
            self.refresh_window()
            return True

    def scroll_half_down(self):
        """
        Scroll half a screen down, if possible.
        Returns True on success, None on failure.
        """
        if self.tabs.current_tab.on_half_scroll_down():
            self.refresh_window()
            return True

    def grow_information_win(self, nb=1):
        """
        Expand the information win a number of lines
        """
        if self.information_win_size >= self.tabs.current_tab.height -5 or \
                self.information_win_size+nb >= self.tabs.current_tab.height-4 or\
                self.size.core_degrade_y:
            return 0
        self.information_win_size += nb
        self.resize_global_information_win()
        for tab in self.tabs:
            tab.on_info_win_size_changed()
        self.refresh_window()
        return nb

    def shrink_information_win(self, nb=1):
        """
        Reduce the size of the information win
        """
        if self.information_win_size == 0 or self.size.core_degrade_y:
            return
        self.information_win_size -= nb
        if self.information_win_size < 0:
            self.information_win_size = 0
        self.resize_global_information_win()
        for tab in self.tabs:
            tab.on_info_win_size_changed()
        self.refresh_window()

    def scroll_info_up(self):
        """
        Scroll the information buffer up
        """
        self.information_win.scroll_up(self.information_win.height)
        if not isinstance(self.tabs.current_tab, RosterInfoTab):
            self.information_win.refresh()
        else:
            info = self.tabs.current_tab.information_win
            info.scroll_up(info.height)
            self.refresh_window()

    def scroll_info_down(self):
        """
        Scroll the information buffer down
        """
        self.information_win.scroll_down(self.information_win.height)
        if not isinstance(self.tabs.current_tab, RosterInfoTab):
            self.information_win.refresh()
        else:
            info = self.tabs.current_tab.information_win
            info.scroll_down(info.height)
            self.refresh_window()

    def _pop_information_win_up(self, size, time):
        """
        Temporarily increase the size of the information win of size lines
        during time seconds.
        After that delay, the size will decrease from size lines.
        """
        if time <= 0 or size <= 0:
            return
        result = self.grow_information_win(size)
        timed_event = timed_events.DelayedEvent(
            time, self.shrink_information_win, result)
        self.add_timed_event(timed_event)
        self.refresh_window()

    def toggle_left_pane(self):
        """
        Enable/disable the left panel.
        """
        enabled = config.getbool('enable_vertical_tab_list')
        if not config.silent_set('enable_vertical_tab_list', str(not enabled)):
            self.information('Unable to write in the config file', 'Error')
        self.call_for_resize()

    def resize_global_information_win(self, ui_config_changed: bool = False):
        """
        Resize the global_information_win only once at each resize.
        """
        if self.information_win_size > Tab.height - 6:
            self.information_win_size = Tab.height - 6
        if Tab.height < 6:
            self.information_win_size = 0
        height = (Tab.height - 1 - self.information_win_size -
                  Tab.tab_win_height())
        self.information_win.resize(self.information_win_size, Tab.width,
                                    height, 0, self.information_buffer,
                                    force=ui_config_changed)

    def resize_global_info_bar(self):
        """
        Resize the GlobalInfoBar only once at each resize
        """
        height, width = self.stdscr.getmaxyx()
        if config.getbool('enable_vertical_tab_list'):

            if self.size.core_degrade_x:
                return
            try:
                height, _ = self.stdscr.getmaxyx()
                truncated_win = self.stdscr.subwin(
                    height, config.getint('vertical_tab_list_size'), 0, 0)
            except:
                log.error('Curses error on infobar resize', exc_info=True)
                return
            self.left_tab_win = windows.VerticalGlobalInfoBar(
                self, truncated_win)
        elif not self.size.core_degrade_y:
            self.tab_win.resize(1, Tab.width, Tab.height - 2, 0)
            self.left_tab_win = None

    def full_screen_redraw(self):
        """
        Completely erase and redraw the screen
        """
        self.stdscr.clear()
        self.refresh_window()

    def call_for_resize(self, ui_config_changed: bool = False):
        """
        Called when we want to resize the screen
        """
        # If we have the tabs list on the left, we just give a truncated
        # window to each Tab class, so they draw themself in the portion of
        # the screen that they can occupy, and we draw the tab list on the
        # remaining space, on the left
        if self.stdscr is None:
            raise ValueError('No output available')
        height, width = self.stdscr.getmaxyx()
        if (config.getbool('enable_vertical_tab_list')
                and not self.size.core_degrade_x):
            try:
                scr = self.stdscr.subwin(
                    0,
                    config.getint('vertical_tab_list_size')
                )
            except:
                log.error('Curses error on resize', exc_info=True)
                return
        else:
            scr = self.stdscr
        Tab.initial_resize(scr)
        self.resize_global_info_bar()
        self.resize_global_information_win(ui_config_changed)
        for tab in self.tabs:
            tab.ui_config_changed = True
            if config.getbool('lazy_resize'):
                tab.need_resize = True
            else:
                tab.resize()

        if len(self.tabs):
            self.full_screen_redraw()

    def read_keyboard(self):
        """
        Get the next keyboard key pressed and returns it.  It blocks until
        something can be read on stdin, this function must be called only if
        there is something to read. No timeout ever occurs.
        """
        return self.keyboard.get_user_input(self.stdscr)

    def escape_next_key(self):
        """
        Tell the Keyboard object that the next key pressed by the user
        should be escaped. See Keyboard.get_user_input
        """
        self.keyboard.escape_next_key()

####################### Commands and completions ##############################

    def register_command(self, name, func, **kwargs):
        """
        Add a command
        """
        desc = kwargs.get('desc', '')
        shortdesc = kwargs.get('shortdesc', '')
        completion = kwargs.get('completion')
        usage = kwargs.get('usage', '')
        if name in self.commands:
            return
        if not desc and shortdesc:
            desc = shortdesc
        self.commands[name] = Command(func, desc, completion, shortdesc, usage)

    def register_initial_commands(self):
        """
        Register the commands when poezio starts
        """
        for command in get_commands(self.command, self.completion, self.plugin_manager):
            self.register_command(**command)

    def check_blocking(self, features: List[str]):
        if 'urn:xmpp:blocking' in features and not self.xmpp.anon:
            self.register_command(
                'block',
                self.command.block,
                usage='[jid]',
                shortdesc='Prevent a JID from talking to you.',
                completion=self.completion.block)
            self.register_command(
                'unblock',
                self.command.unblock,
                usage='[jid]',
                shortdesc='Allow a JID to talk to you.',
                completion=self.completion.unblock)

            self.xmpp.del_event_handler('session_start', self.check_blocking)

####################### Random things to move #################################

    def join_initial_rooms(self, bookmarks: List[Bookmark]):
        """Join all rooms given in the iterator `bookmarks`"""
        for bm in bookmarks:
            if not (bm.autojoin or config.getbool('open_all_bookmarks')):
                continue
            tab = self.tabs.by_name_and_class(bm.jid, MucTab)
            nick = bm.nick if bm.nick else self.own_nick
            if not tab:
                tab = self.open_new_room(
                    bm.jid, nick, focus=False, password=bm.password)
            self.initial_joins.append(bm.jid)
            # do not join rooms that do not have autojoin
            # but display them anyway
            if bm.autojoin and tab:
                tab.join()

    async def check_bookmark_storage(self, features: List[str]):
        private = 'jabber:iq:private' in features
        pep_ = 'http://jabber.org/protocol/pubsub#publish' in features
        self.bookmarks.available_storage['private'] = private
        self.bookmarks.available_storage['pep'] = pep_

        if not self.xmpp.anon and config.getbool('use_remote_bookmarks'):
            try:
                await self.bookmarks.get_remote(self.xmpp, self.information)
            except IqError as error:
                type_ = error.iq['error']['type']
                condition = error.iq['error']['condition']
                if not (type_ == 'cancel' and condition == 'item-not-found'):
                    self.information(
                        'Unable to fetch the remote'
                        ' bookmarks; %s: %s' % (type_, condition), 'Error')
                return
            remote_bookmarks = self.bookmarks.remote()
            self.join_initial_rooms(remote_bookmarks)

    def room_error(self, error, room_name: str) -> None:
        """
        Display the error in the tab
        """
        tab = self.tabs.by_name_and_class(room_name, MucTab)
        if not tab:
            return
        error_message = get_error_message(error)
        tab.add_message(
            UIMessage(
                error_message,
                level='Error',
            ),
        )
        code = error['error']['code']
        if code == '401':
            msg = 'To provide a password in order to join the room, type "/join / password" (replace "password" by the real password)'
            tab.add_message(PersistentInfoMessage(msg))
        if code == '409':
            if config.getstr('alternative_nickname') != '':
                if not tab.joined:
                    tab.own_nick += config.getstr('alternative_nickname')
                    tab.join()
            else:
                if not tab.joined:
                    tab.add_message(
                        PersistentInfoMessage(
                            'You can join the room with another nick, '
                            'by typing "/join /other_nick"'
                        )
                    )
        self.refresh_window()


class KeyDict(dict):
    """
    A dict, with a wrapper for get() that will return a custom value
    if the key starts with _exc_
    """
    try_execute: Optional[Callable[[str], Any]]

    def get(self, key: str, default=None) -> Callable:
        if isinstance(key, str) and key.startswith('_exc_') and len(key) > 5:
            if self.try_execute is not None:
                try_execute = self.try_execute
                return lambda: try_execute(key[5:])
            raise ValueError("KeyDict not initialized")
        return dict.get(self, key, default)



def replace_key_with_bound(key: str) -> str:
    """
    Replace an inputted key with the one defined as its replacement
    in the config
    """
    return config.get(key, default=key, section='bindings') or key


def replace_line_breaks(key: str) -> str:
    "replace ^J with \n"
    if key == '^J':
        return '\n'
    return key


def separate_chars_from_bindings(char_list: List[str]) -> List[List[str]]:
    """
    returns a list of lists. For example if you give
    ['a', 'b', 'KEY_BACKSPACE', 'n', 'u'], this function returns
    [['a', 'b'], ['KEY_BACKSPACE'], ['n', 'u']]

    This way, in case of lag (for example), we handle the typed text
    by “batch” as much as possible (instead of one char at a time,
    which implies a refresh after each char, which is very slow),
    but we still handle the special chars (backspaces, arrows,
    ctrl+x ou alt+x, etc) one by one, which avoids the issue of
    printing them OR ignoring them in that case.  This should
    resolve the “my ^W are ignored when I lag ;(”.
    """
    res = []
    current = []
    for char in char_list:
        assert char
        # Transform that stupid char into what we actually meant
        if char == '\x1f':
            char = '^/'
        if len(char) == 1:
            current.append(char)
        else:
            # special case for the ^I key, it’s considered as \t
            # only when pasting some text, otherwise that’s the ^I
            # (or M-i) key, which stands for completion by default.
            if char == '^I' and len(char_list) != 1:
                current.append('\t')
                continue
            if current:
                res.append(current)
                current = []
            res.append([char])
    if current:
        res.append(current)
    return res
