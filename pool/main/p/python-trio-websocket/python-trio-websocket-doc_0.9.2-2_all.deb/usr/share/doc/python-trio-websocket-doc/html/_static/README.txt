This is just a placeholder file because this project doesn't
have any static assets.

