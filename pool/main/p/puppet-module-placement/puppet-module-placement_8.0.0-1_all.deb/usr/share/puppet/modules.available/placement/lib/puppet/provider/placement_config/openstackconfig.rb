Puppet::Type.type(:placement_config).provide(
  :openstackconfig,
  :parent => Puppet::Type.type(:openstack_config).provider(:ruby)
) do

  def self.file_path
    '/etc/placement/placement.conf'
  end

end
