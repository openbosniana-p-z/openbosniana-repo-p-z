# Banned Node.js modules

* cross-spawn: [#958403](https://bugs.debian.org/958403)
* gdal: [#992527](https://bugs.debian.org/992527)
* groove: orphaned; abandoned upstream
* request: [#956423](https://bugs.debian.org/956423)
