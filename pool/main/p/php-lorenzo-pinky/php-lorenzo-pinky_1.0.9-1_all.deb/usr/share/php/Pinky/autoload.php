<?php
require_once __DIR__ . '/pinky.php';
