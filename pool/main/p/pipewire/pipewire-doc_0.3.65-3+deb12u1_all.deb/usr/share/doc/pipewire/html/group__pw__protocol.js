var group__pw__protocol =
[
    [ "protocol.h", "protocol_8h.html", null ],
    [ "pw_protocol_client", "structpw__protocol__client.html", [
      [ "link", "structpw__protocol__client.html#addd42578b59ddffc32a42a52754654be", null ],
      [ "protocol", "structpw__protocol__client.html#a2f6233dcd7a026275a93680ae68ee263", null ],
      [ "core", "structpw__protocol__client.html#a03ad2913f7876e0db722b6d1e318e35f", null ],
      [ "connect", "structpw__protocol__client.html#a020b1da93f4f58c485ff64da4a5ac655", null ],
      [ "connect_fd", "structpw__protocol__client.html#a0f94b0fb5b1f83cbb56529b5c43c4a8f", null ],
      [ "steal_fd", "structpw__protocol__client.html#ae94059a4fa05da14961edb56be183f2a", null ],
      [ "disconnect", "structpw__protocol__client.html#a4b60903a56e79e980b11ea2d14fac80c", null ],
      [ "destroy", "structpw__protocol__client.html#a9ce571a5bc950b3309d0dbd2a55e501f", null ],
      [ "set_paused", "structpw__protocol__client.html#a4f79f140a57922a8c4b7d52f9f433918", null ]
    ] ],
    [ "pw_protocol_server", "structpw__protocol__server.html", [
      [ "link", "structpw__protocol__server.html#a0ac79f449a098fd48ac49f48f56a0ed3", null ],
      [ "protocol", "structpw__protocol__server.html#a0b93bd3cd5a2680d8ece4796826406fc", null ],
      [ "core", "structpw__protocol__server.html#ae953d4026c613d91a0cb34398d3f4367", null ],
      [ "client_list", "structpw__protocol__server.html#a01d6fae5e363f6694f092256c19366ea", null ],
      [ "destroy", "structpw__protocol__server.html#acc7b1e9530a048b084976fc647ab446f", null ]
    ] ],
    [ "pw_protocol_marshal", "structpw__protocol__marshal.html", [
      [ "type", "structpw__protocol__marshal.html#a42d1730a083b2ddfef273c875f5a8da9", null ],
      [ "version", "structpw__protocol__marshal.html#a84d23417562653ce0c3f833914745b4b", null ],
      [ "flags", "structpw__protocol__marshal.html#a3b6e60e3abd02c572dc9717ea6128837", null ],
      [ "n_client_methods", "structpw__protocol__marshal.html#a050ca46939a55d57319f7fe60630088e", null ],
      [ "n_server_methods", "structpw__protocol__marshal.html#a9082278f0db2ef7b0fab5ac315d5d4e6", null ],
      [ "client_marshal", "structpw__protocol__marshal.html#a630f0a301e4fbf67698cf05b24179b30", null ],
      [ "server_demarshal", "structpw__protocol__marshal.html#a1d2f780d6b77da347a46af7bf6577c4a", null ],
      [ "server_marshal", "structpw__protocol__marshal.html#ade451b0a49d73a98a1c3cee60f6f9c8d", null ],
      [ "client_demarshal", "structpw__protocol__marshal.html#ab3d180b20e34b70959086148d1b6c9c5", null ]
    ] ],
    [ "pw_protocol_implementation", "structpw__protocol__implementation.html", [
      [ "version", "structpw__protocol__implementation.html#a8bf7e732f7cac47bba3b798c722f739a", null ],
      [ "new_client", "structpw__protocol__implementation.html#a859abf630e7a562357647c0bb7caccb6", null ],
      [ "add_server", "structpw__protocol__implementation.html#a237c5d6a817a2b5dddb0f2e996d0a0bd", null ]
    ] ],
    [ "pw_protocol_events", "structpw__protocol__events.html", [
      [ "version", "structpw__protocol__events.html#af7bb9abb40f974acecda6bb2c6ad5cad", null ],
      [ "destroy", "structpw__protocol__events.html#ab341415c5d72294c801c580ac9653426", null ]
    ] ],
    [ "pw_protocol", "structpw__protocol.html", null ],
    [ "PW_TYPE_INFO_Protocol", "group__pw__protocol.html#ga910bf17e4410db6f10055da489451604", null ],
    [ "PW_TYPE_INFO_PROTOCOL_BASE", "group__pw__protocol.html#gaf2da98ab0dabd83d281ac8e4495d43d8", null ],
    [ "pw_protocol_client_connect", "group__pw__protocol.html#ga0026bb6385904327d20a8dfcf982ba62", null ],
    [ "pw_protocol_client_connect_fd", "group__pw__protocol.html#ga56a619809f144fb3e27ac9e0644e3830", null ],
    [ "pw_protocol_client_steal_fd", "group__pw__protocol.html#gaeae48475b735761c22837afd53e2ce9e", null ],
    [ "pw_protocol_client_disconnect", "group__pw__protocol.html#ga6673120bfc643d6cbeea97535873b4f0", null ],
    [ "pw_protocol_client_destroy", "group__pw__protocol.html#gad3a30029abadec4f4b76ae2cb28a4585", null ],
    [ "pw_protocol_client_set_paused", "group__pw__protocol.html#gac3c7dce722800fb4c8ab54267ef6303a", null ],
    [ "pw_protocol_server_destroy", "group__pw__protocol.html#ga6c57711ce8eee785b967ed0487a2fe3b", null ],
    [ "PW_PROTOCOL_MARSHAL_FLAG_IMPL", "group__pw__protocol.html#ga64a3293decdd3cfefc715c040180368a", null ],
    [ "PW_VERSION_PROTOCOL_IMPLEMENTATION", "group__pw__protocol.html#ga4d8f6852ba390ba826744d18b58c4021", null ],
    [ "PW_VERSION_PROTOCOL_EVENTS", "group__pw__protocol.html#gac2742efc503c7a6e04238bd9a94af35e", null ],
    [ "pw_protocol_new_client", "group__pw__protocol.html#ga10397b3ea74c80703140242313ab52df", null ],
    [ "pw_protocol_add_server", "group__pw__protocol.html#ga3b9d1f2afdf848863a84c7f2c825dc32", null ],
    [ "pw_protocol_ext", "group__pw__protocol.html#ga91126ea5ca35fb743c9fd04d27316fe1", null ],
    [ "pw_protocol_new", "group__pw__protocol.html#ga6c558d851621e5559e288765a10055bb", null ],
    [ "pw_protocol_destroy", "group__pw__protocol.html#ga6d58875f54dbf541b969c5911b802311", null ],
    [ "pw_protocol_get_context", "group__pw__protocol.html#ga40fede7605dec6bc48c485303c941d90", null ],
    [ "pw_protocol_get_user_data", "group__pw__protocol.html#ga7cd122dc202daa0db9716f5acec0f7b0", null ],
    [ "pw_protocol_get_implementation", "group__pw__protocol.html#gab7976eb54b372c152b8a340ad02fd31b", null ],
    [ "pw_protocol_get_extension", "group__pw__protocol.html#ga9afea9089eed40005c3b52beb6353f49", null ],
    [ "pw_protocol_add_listener", "group__pw__protocol.html#ga253136c71f02f82d59fd79c78c40fe65", null ],
    [ "pw_protocol_add_marshal", "group__pw__protocol.html#ga4b8a7c184d8756e4864538f16a60bec3", null ],
    [ "pw_protocol_get_marshal", "group__pw__protocol.html#ga483e9cea6d734d97fe7b7f59899c7adb", null ],
    [ "pw_context_find_protocol", "group__pw__protocol.html#ga23a2b7b99697b2ff29cb29e4fa8a4f59", null ]
];