var group__spa__interfaces =
[
    [ "hook.h", "hook_8h.html", null ],
    [ "spa_callbacks", "structspa__callbacks.html", [
      [ "funcs", "structspa__callbacks.html#a0c52caccee37692f842b93785b3f7f22", null ],
      [ "data", "structspa__callbacks.html#adc0097ae82d42b5fc92e896f47e13ee5", null ]
    ] ],
    [ "spa_interface", "structspa__interface.html", [
      [ "type", "structspa__interface.html#a99da3754855d6dd1430d21ed97fa0bfb", null ],
      [ "version", "structspa__interface.html#a2572eec5caf615f77e143013373cdcdf", null ],
      [ "cb", "structspa__interface.html#ae748ef778a029468d301c3727c80a85b", null ]
    ] ],
    [ "SPA_CALLBACK_VERSION_MIN", "group__spa__interfaces.html#ga7eadf4e30be75d856d81c9b0d818b0e1", null ],
    [ "SPA_CALLBACK_CHECK", "group__spa__interfaces.html#gafbe7e2c178c8649d89fe3d6cfcb74c65", null ],
    [ "SPA_CALLBACKS_INIT", "group__spa__interfaces.html#ga7cd31fca0faa447261fb4425d8036bb5", null ],
    [ "SPA_INTERFACE_INIT", "group__spa__interfaces.html#gaf9eef5cf634711b4de82fc5f9e3802ee", null ],
    [ "spa_callbacks_call", "group__spa__interfaces.html#ga5f51d2f3b4df5eb44fa6163ba3958f5d", null ],
    [ "spa_callback_version_min", "group__spa__interfaces.html#gab3415032c65751a4b16279a6167f5972", null ],
    [ "spa_callback_check", "group__spa__interfaces.html#ga6492da0e834e92dbbcef7dd3026ce04f", null ],
    [ "spa_callbacks_call_res", "group__spa__interfaces.html#gac11e7999a90fa354ef765abf8a6f9696", null ],
    [ "spa_interface_callback_version_min", "group__spa__interfaces.html#ga1566a7843972b177af627e6e16b86c26", null ],
    [ "spa_interface_callback_check", "group__spa__interfaces.html#ga8ba5c01fe17d8a199516e2d87e59c025", null ],
    [ "spa_interface_call", "group__spa__interfaces.html#ga1facc1b12f5dfb7e3362e9f1a6d3cb6c", null ],
    [ "spa_interface_call_res", "group__spa__interfaces.html#ga0b43b5a0ee8aa8f305d0c9971716e5b0", null ]
];