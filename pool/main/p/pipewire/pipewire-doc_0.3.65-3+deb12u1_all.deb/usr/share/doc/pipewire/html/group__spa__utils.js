var group__spa__utils =
[
    [ "ANSI codes", "group__spa__ansi.html", "group__spa__ansi" ],
    [ "Miscellaneous", "group__spa__utils__defs.html", "group__spa__utils__defs" ],
    [ "Dictionary", "group__spa__dict.html", "group__spa__dict" ],
    [ "List", "group__spa__list.html", "group__spa__list" ],
    [ "Hooks", "group__spa__hooks.html", "group__spa__hooks" ],
    [ "Interfaces", "group__spa__interfaces.html", "group__spa__interfaces" ],
    [ "JSON", "group__spa__json.html", "group__spa__json" ],
    [ "Key Names", "group__spa__keys.html", "group__spa__keys" ],
    [ "Factory Names", "group__spa__names.html", "group__spa__names" ],
    [ "Result handling", "group__spa__result.html", "group__spa__result" ],
    [ "Ringbuffer", "group__spa__ringbuffer.html", "group__spa__ringbuffer" ],
    [ "String handling", "group__spa__string.html", "group__spa__string" ],
    [ "Types", "group__spa__types.html", "group__spa__types" ]
];