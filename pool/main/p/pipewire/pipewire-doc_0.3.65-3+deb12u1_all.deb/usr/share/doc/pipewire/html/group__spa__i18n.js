var group__spa__i18n =
[
    [ "spa/include/spa/support/i18n.h", "spa_2include_2spa_2support_2i18n_8h.html", null ],
    [ "spa_i18n", "structspa__i18n.html", [
      [ "iface", "structspa__i18n.html#a4ca10c865fe33ffff4fd9abb9265c0f8", null ]
    ] ],
    [ "spa_i18n_methods", "structspa__i18n__methods.html", [
      [ "version", "structspa__i18n__methods.html#a3aa971d572e886ab027a897a288f767b", null ],
      [ "text", "structspa__i18n__methods.html#a7ceb5c3a7165fbfb3ee340574881d675", null ],
      [ "ntext", "structspa__i18n__methods.html#a884391486c3277069fb8ee2f9d754234", null ]
    ] ],
    [ "SPA_TYPE_INTERFACE_I18N", "group__spa__i18n.html#gacc03db6ab5181108527ca45e7674b235", null ],
    [ "SPA_VERSION_I18N", "group__spa__i18n.html#gab6c7211ad9795cf4c1c55487c165a555", null ],
    [ "SPA_VERSION_I18N_METHODS", "group__spa__i18n.html#gaf3aa0f8921abf9d572c9fde4a9d0825d", null ],
    [ "spa_i18n_text", "group__spa__i18n.html#gafe48fd94d55ba3db8f10fb1550ec79c8", null ],
    [ "spa_i18n_ntext", "group__spa__i18n.html#gaa4c021574498780906bcc3f2958cc23f", null ]
];