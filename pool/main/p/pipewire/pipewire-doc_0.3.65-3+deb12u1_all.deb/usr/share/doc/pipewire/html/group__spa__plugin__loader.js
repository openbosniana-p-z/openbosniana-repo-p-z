var group__spa__plugin__loader =
[
    [ "plugin-loader.h", "plugin-loader_8h.html", null ],
    [ "spa_plugin_loader", "structspa__plugin__loader.html", [
      [ "iface", "structspa__plugin__loader.html#a17501870cdaf04804cde83d541a31a61", null ]
    ] ],
    [ "spa_plugin_loader_methods", "structspa__plugin__loader__methods.html", [
      [ "version", "structspa__plugin__loader__methods.html#ae2de2d15c28cf425552bb3aa6ca0bad4", null ],
      [ "load", "structspa__plugin__loader__methods.html#ac03d77f832ee680b4a1b68acdbcc05d4", null ],
      [ "unload", "structspa__plugin__loader__methods.html#aa91d4ff3f01f2d7c38a066b3d8bc98ca", null ]
    ] ],
    [ "SPA_TYPE_INTERFACE_PluginLoader", "group__spa__plugin__loader.html#gade61903a8bd06ae84ad4fa6d6f4035d0", null ],
    [ "SPA_VERSION_PLUGIN_LOADER", "group__spa__plugin__loader.html#ga4ad7f76d73f45e3b813415d8eef9652a", null ],
    [ "SPA_VERSION_PLUGIN_LOADER_METHODS", "group__spa__plugin__loader.html#gac0bc09f4a355a4ff599e791ffc725398", null ],
    [ "spa_plugin_loader_load", "group__spa__plugin__loader.html#ga85762c2a7fd3d81e45000c392c56b82f", null ],
    [ "spa_plugin_loader_unload", "group__spa__plugin__loader.html#gaf9dd57a5b0c8889762889183966a6db5", null ]
];