var group__pw__main__loop =
[
    [ "main-loop.h", "main-loop_8h.html", null ],
    [ "pw_main_loop_events", "structpw__main__loop__events.html", [
      [ "version", "structpw__main__loop__events.html#abbfcaf5cd47f231f25979949df15cf29", null ],
      [ "destroy", "structpw__main__loop__events.html#a1713b16265dcafb5944612c5d653a553", null ]
    ] ],
    [ "pw_main_loop", "structpw__main__loop.html", null ],
    [ "PW_VERSION_MAIN_LOOP_EVENTS", "group__pw__main__loop.html#ga3310e380c0368cb007552027a040ff96", null ],
    [ "pw_main_loop_new", "group__pw__main__loop.html#ga97e22c4f950a8d17e6d9aa84f85afb3b", null ],
    [ "pw_main_loop_add_listener", "group__pw__main__loop.html#gae2ca7b19516a0245b0da1756a82ca753", null ],
    [ "pw_main_loop_get_loop", "group__pw__main__loop.html#gab882a83a0c56bd1737b3e0ed2daa0391", null ],
    [ "pw_main_loop_destroy", "group__pw__main__loop.html#ga4248c0e1da7ea6a1f7a4df7cbdc2db72", null ],
    [ "pw_main_loop_run", "group__pw__main__loop.html#ga4cc23752fe4d60ae07d98a481e03734b", null ],
    [ "pw_main_loop_quit", "group__pw__main__loop.html#ga364190789f9f07251fe2c8ee45f5d1c1", null ]
];