var group__pw__memblock =
[
    [ "src/pipewire/mem.h", "src_2pipewire_2mem_8h.html", null ],
    [ "pw_mempool", "structpw__mempool.html", null ],
    [ "pw_memblock", "structpw__memblock.html", [
      [ "pool", "structpw__memblock.html#a66508184497a6f6e211eafa8f6e4edd7", null ],
      [ "id", "structpw__memblock.html#a1ca99934939d8b89c158a0256d6d906c", null ],
      [ "ref", "structpw__memblock.html#ac130234986a5d662d20a3e593448bbbd", null ],
      [ "flags", "structpw__memblock.html#a88d9c260a71ebd2413b9c4f6c6b84889", null ],
      [ "type", "structpw__memblock.html#a8fb4076dc9a00af2a3da6be6859b6a00", null ],
      [ "fd", "structpw__memblock.html#a4731883fd9899d0d668c0f44a16d3b33", null ],
      [ "size", "structpw__memblock.html#a8e96a2d24a5fc723b2a637de4bf700b1", null ],
      [ "map", "structpw__memblock.html#ae9876a344086ff407cf6bf3704b24515", null ]
    ] ],
    [ "pw_memmap", "structpw__memmap.html", [
      [ "block", "structpw__memmap.html#ae80282a00a02c34be7f36975ea52768b", null ],
      [ "ptr", "structpw__memmap.html#a586c7656b932f4c50d0efb007bae6c64", null ],
      [ "flags", "structpw__memmap.html#a62479406415257a935744739aa3434f3", null ],
      [ "offset", "structpw__memmap.html#a2a254ea08d19704537d73b68ef548a12", null ],
      [ "size", "structpw__memmap.html#ae1170cc1555b8b4a5562b4d79cb22cc4", null ],
      [ "tag", "structpw__memmap.html#afa567539bf3c9fd16218032faad070ae", null ]
    ] ],
    [ "pw_mempool_events", "structpw__mempool__events.html", [
      [ "version", "structpw__mempool__events.html#ad9ca75bf0ef8b752ab8d8ca98024c604", null ],
      [ "destroy", "structpw__mempool__events.html#a75c60217ff7346dd1da1211990ff3bbe", null ],
      [ "added", "structpw__mempool__events.html#a8ac5a248f57f94a547cfd5fa1e92c2f2", null ],
      [ "removed", "structpw__mempool__events.html#a74d1debb63e31dc6f7876fc9350b2f7d", null ]
    ] ],
    [ "pw_map_range", "structpw__map__range.html", [
      [ "offset", "structpw__map__range.html#aaf1ff0e5b8623a1c64ee4ac9dbf2008a", null ],
      [ "size", "structpw__map__range.html#a96ecc91bdc991ce5c807a1b79aded4f4", null ]
    ] ],
    [ "pw_memchunk", "structpw__memchunk.html", null ],
    [ "PW_VERSION_MEMPOOL_EVENTS", "group__pw__memblock.html#ga3dbe2152d1ae85434bf57f58e6c37043", null ],
    [ "PW_MAP_RANGE_INIT", "group__pw__memblock.html#ga9d831e5773c3aa8ac62d72f6e4a161b7", null ],
    [ "pw_memblock_flags", "group__pw__memblock.html#gaa754e8d30b01da58829b3e372c78f739", [
      [ "PW_MEMBLOCK_FLAG_NONE", "group__pw__memblock.html#ggaa754e8d30b01da58829b3e372c78f739ad862afa8e27e952be60c34be8107fde1", null ],
      [ "PW_MEMBLOCK_FLAG_READABLE", "group__pw__memblock.html#ggaa754e8d30b01da58829b3e372c78f739a65372cd6e7628ad0d817a8aae9effa7f", null ],
      [ "PW_MEMBLOCK_FLAG_WRITABLE", "group__pw__memblock.html#ggaa754e8d30b01da58829b3e372c78f739a777872c959bb5a9ef7767b0218b1b0ba", null ],
      [ "PW_MEMBLOCK_FLAG_SEAL", "group__pw__memblock.html#ggaa754e8d30b01da58829b3e372c78f739a65f120caa99eb2b3f5e71ee7581c4cd4", null ],
      [ "PW_MEMBLOCK_FLAG_MAP", "group__pw__memblock.html#ggaa754e8d30b01da58829b3e372c78f739a0f28ca9bb22207df34f28448e1948112", null ],
      [ "PW_MEMBLOCK_FLAG_DONT_CLOSE", "group__pw__memblock.html#ggaa754e8d30b01da58829b3e372c78f739af322c38a861c5a1639c666137a045e3a", null ],
      [ "PW_MEMBLOCK_FLAG_DONT_NOTIFY", "group__pw__memblock.html#ggaa754e8d30b01da58829b3e372c78f739a1b17b947d528ddfdd15782f6d48b6907", null ],
      [ "PW_MEMBLOCK_FLAG_READWRITE", "group__pw__memblock.html#ggaa754e8d30b01da58829b3e372c78f739a00bd094c3e2bea25eb5abe2d22d5af1d", null ]
    ] ],
    [ "pw_memmap_flags", "group__pw__memblock.html#ga1daf40887c9a63347e9c59822287747a", [
      [ "PW_MEMMAP_FLAG_NONE", "group__pw__memblock.html#gga1daf40887c9a63347e9c59822287747aac3e5ceea50faacf9d2aac1670f07fd65", null ],
      [ "PW_MEMMAP_FLAG_READ", "group__pw__memblock.html#gga1daf40887c9a63347e9c59822287747aa58334ee09eeba50b788a04f276440475", null ],
      [ "PW_MEMMAP_FLAG_WRITE", "group__pw__memblock.html#gga1daf40887c9a63347e9c59822287747aa8b0a302b83a9d3cd11e2b6ed7f82f546", null ],
      [ "PW_MEMMAP_FLAG_TWICE", "group__pw__memblock.html#gga1daf40887c9a63347e9c59822287747aaf12060ee3328912e62d05650edaa999a", null ],
      [ "PW_MEMMAP_FLAG_PRIVATE", "group__pw__memblock.html#gga1daf40887c9a63347e9c59822287747aafa1af7ca17efbe9d9104e0e9e25996bf", null ],
      [ "PW_MEMMAP_FLAG_LOCKED", "group__pw__memblock.html#gga1daf40887c9a63347e9c59822287747aa1e96926b87805cb6e689ba796fd402f9", null ],
      [ "PW_MEMMAP_FLAG_READWRITE", "group__pw__memblock.html#gga1daf40887c9a63347e9c59822287747aa5e15b1dc0d4d0354a37a841af139411b", null ]
    ] ],
    [ "pw_mempool_new", "group__pw__memblock.html#ga2ac4c816115d56d320c868171597f640", null ],
    [ "pw_mempool_add_listener", "group__pw__memblock.html#ga5c298052be6fe8f5f4ea78b4fe41733d", null ],
    [ "pw_mempool_clear", "group__pw__memblock.html#ga9e39d964e7ba4d39449cb8b569504a3e", null ],
    [ "pw_mempool_destroy", "group__pw__memblock.html#gab253128cb2d2bc7ad5203d2b65e762c8", null ],
    [ "pw_mempool_alloc", "group__pw__memblock.html#ga27f6b0a11cef5a49cde3fab1ae642491", null ],
    [ "pw_mempool_import_block", "group__pw__memblock.html#ga4acd2b36bdd50840f84e9ec5d2feef49", null ],
    [ "pw_mempool_import", "group__pw__memblock.html#ga134aecacce3f6357cb0ca6bf9bd36b47", null ],
    [ "pw_memblock_free", "group__pw__memblock.html#gaa706ad494480f45ba0683ee91b2779d1", null ],
    [ "pw_memblock_unref", "group__pw__memblock.html#ga7e4c55feef88dbb97b91aa87d3c2f496", null ],
    [ "pw_mempool_remove_id", "group__pw__memblock.html#ga4795146fb79f58f2277d535f71bdea34", null ],
    [ "pw_mempool_find_ptr", "group__pw__memblock.html#ga9d39624b18e771eb7184bfd75c226be0", null ],
    [ "pw_mempool_find_id", "group__pw__memblock.html#ga92dbc7bc8f980e8cb518b7feac01df3e", null ],
    [ "pw_mempool_find_fd", "group__pw__memblock.html#ga7c9a4b5c0796b52a4519b4f7c3cc301a", null ],
    [ "pw_memblock_map", "group__pw__memblock.html#gab6f8173f833296d33affcb86ae785316", null ],
    [ "pw_mempool_map_id", "group__pw__memblock.html#ga5c3422b17f5f4bae75efe0603fde6150", null ],
    [ "pw_mempool_import_map", "group__pw__memblock.html#ga6d778c718234eda39ea5632bffa40162", null ],
    [ "pw_mempool_find_tag", "group__pw__memblock.html#ga080fb17973757073bf92c72fc4e6f8d1", null ],
    [ "pw_memmap_free", "group__pw__memblock.html#ga3efb664909dd90a771d5092238a7a603", null ],
    [ "pw_map_range_init", "group__pw__memblock.html#ga845e5b1da192f9dbc8a82212ec33a387", null ]
];