var group__pw__filter =
[
    [ "src/pipewire/filter.h", "src_2pipewire_2filter_8h.html", null ],
    [ "pw_filter_events", "structpw__filter__events.html", [
      [ "version", "structpw__filter__events.html#a5a03c51cf03b2e8408ead88cc66b25cd", null ],
      [ "destroy", "structpw__filter__events.html#adb8416b044c19f8856dac1d2b554f32a", null ],
      [ "state_changed", "structpw__filter__events.html#afb8a57497ec76189b2fd247ce72966c5", null ],
      [ "io_changed", "structpw__filter__events.html#a58d1c6027c07caec0ed77edd5dbdac5b", null ],
      [ "param_changed", "structpw__filter__events.html#a56e04005c73bc3b32cda5b0febfb67cc", null ],
      [ "add_buffer", "structpw__filter__events.html#aca5d0df9b247219e850a94be2bf9d135", null ],
      [ "remove_buffer", "structpw__filter__events.html#aa541b66c8fa1cbf804d9ebf8c9aad239", null ],
      [ "process", "structpw__filter__events.html#a324db3b12bbac07c495395eae521e97a", null ],
      [ "drained", "structpw__filter__events.html#a74a4deeb45f4626823c44cab4ace174a", null ],
      [ "command", "structpw__filter__events.html#a7ded13531102414fec81a846974f5728", null ]
    ] ],
    [ "pw_filter", "structpw__filter.html", null ],
    [ "PW_VERSION_FILTER_EVENTS", "group__pw__filter.html#gacada8cd95dc706273ca3546182496fb6", null ],
    [ "pw_filter_state", "group__pw__filter.html#ga971b3b840bb33e5fb71df1dcf05c4fec", [
      [ "PW_FILTER_STATE_ERROR", "group__pw__filter.html#gga971b3b840bb33e5fb71df1dcf05c4feca53c4a425e810bfd3926df4f50c9d90e5", null ],
      [ "PW_FILTER_STATE_UNCONNECTED", "group__pw__filter.html#gga971b3b840bb33e5fb71df1dcf05c4feca8e4399b573c31254a85fed29eb9b4516", null ],
      [ "PW_FILTER_STATE_CONNECTING", "group__pw__filter.html#gga971b3b840bb33e5fb71df1dcf05c4feca959647e0d6116e3d53ffba718813fe37", null ],
      [ "PW_FILTER_STATE_PAUSED", "group__pw__filter.html#gga971b3b840bb33e5fb71df1dcf05c4fecac98e459383306f2d0d925bff15ce4cdd", null ],
      [ "PW_FILTER_STATE_STREAMING", "group__pw__filter.html#gga971b3b840bb33e5fb71df1dcf05c4feca0c0cb3bff766f69a7d3422c1af0dac7b", null ]
    ] ],
    [ "pw_filter_flags", "group__pw__filter.html#ga0cba81474e0c98ec0bcbe9d347931cdc", [
      [ "PW_FILTER_FLAG_NONE", "group__pw__filter.html#gga0cba81474e0c98ec0bcbe9d347931cdca2a0d0994deb3f0fb6b16a99dbd014434", null ],
      [ "PW_FILTER_FLAG_INACTIVE", "group__pw__filter.html#gga0cba81474e0c98ec0bcbe9d347931cdca9c7ebdaa58ee4f60ad9cb0c989e79d48", null ],
      [ "PW_FILTER_FLAG_DRIVER", "group__pw__filter.html#gga0cba81474e0c98ec0bcbe9d347931cdcafb694fd4c50eb4a78cf3486332183ff7", null ],
      [ "PW_FILTER_FLAG_RT_PROCESS", "group__pw__filter.html#gga0cba81474e0c98ec0bcbe9d347931cdca9e65b23a46f751363be613bd241df42f", null ],
      [ "PW_FILTER_FLAG_CUSTOM_LATENCY", "group__pw__filter.html#gga0cba81474e0c98ec0bcbe9d347931cdca74ea00c97c3d09077a7ae3bf1d49c342", null ]
    ] ],
    [ "pw_filter_port_flags", "group__pw__filter.html#ga7aefc7ac2b8293acd783681cdedf954a", [
      [ "PW_FILTER_PORT_FLAG_NONE", "group__pw__filter.html#gga7aefc7ac2b8293acd783681cdedf954aaddd83bac03ff477f8215bf0c763d9596", null ],
      [ "PW_FILTER_PORT_FLAG_MAP_BUFFERS", "group__pw__filter.html#gga7aefc7ac2b8293acd783681cdedf954aa5d269be9a4e6343515a41d48be8e91f0", null ],
      [ "PW_FILTER_PORT_FLAG_ALLOC_BUFFERS", "group__pw__filter.html#gga7aefc7ac2b8293acd783681cdedf954aa3ca47058ec8dfd69e4d51b6719f8d128", null ]
    ] ],
    [ "pw_filter_state_as_string", "group__pw__filter.html#ga0e04e820d3d1681fa2c88bc043bfe943", null ],
    [ "pw_filter_new", "group__pw__filter.html#gaa078269b499d76bf4293cf21d2d9600f", null ],
    [ "pw_filter_new_simple", "group__pw__filter.html#gafff846bdbb4f52cac93f27a19c073e05", null ],
    [ "pw_filter_destroy", "group__pw__filter.html#gaf54752a2edef1c569fdfb8e6774b4ead", null ],
    [ "pw_filter_add_listener", "group__pw__filter.html#ga3ce0d511241ff91648db30afa18b18c9", null ],
    [ "pw_filter_get_state", "group__pw__filter.html#ga3daf63e40e01aae6c1e922213d4d0339", null ],
    [ "pw_filter_get_name", "group__pw__filter.html#ga08ff79be2ddb144f7773f31ef2a37eb1", null ],
    [ "pw_filter_get_core", "group__pw__filter.html#ga36543616c24b28f6b42512d77b76a552", null ],
    [ "pw_filter_connect", "group__pw__filter.html#ga0e0cd4a72360216e5d2f5df7ceed9d10", null ],
    [ "pw_filter_get_node_id", "group__pw__filter.html#ga42bb454545c27ff0b5992ccbb9fc4e55", null ],
    [ "pw_filter_disconnect", "group__pw__filter.html#ga913200b5d552335932cfe145bdf2a3e6", null ],
    [ "pw_filter_add_port", "group__pw__filter.html#gac20d31739413a44caae6dafcefafa140", null ],
    [ "pw_filter_remove_port", "group__pw__filter.html#ga0bf93d760400b88f26f0958241c781bf", null ],
    [ "pw_filter_get_properties", "group__pw__filter.html#gaea3157cae3f652b66c80d59444be7e9e", null ],
    [ "pw_filter_update_properties", "group__pw__filter.html#gaef043eada2487afbf72cc1490afbb78f", null ],
    [ "pw_filter_set_error", "group__pw__filter.html#ga45f64a8b4869757a5c5f6876e17188e5", null ],
    [ "pw_filter_update_params", "group__pw__filter.html#ga77a07cdde500c35defa592947931ae4d", null ],
    [ "pw_filter_get_time", "group__pw__filter.html#gac5ba311e3a8df6fe521d9b9f2a825ec7", null ],
    [ "pw_filter_dequeue_buffer", "group__pw__filter.html#gad2c604e7809ab43e7731a3b47cddcbb0", null ],
    [ "pw_filter_queue_buffer", "group__pw__filter.html#ga67e9ec5afe20ab5c4c08bc92dcaa21a2", null ],
    [ "pw_filter_get_dsp_buffer", "group__pw__filter.html#gaf86eb47b3adbca1ddfb66235a8a5ae69", null ],
    [ "pw_filter_set_active", "group__pw__filter.html#gaa9ae747610cbf4c82d332b2c2a76b589", null ],
    [ "pw_filter_flush", "group__pw__filter.html#gae17ab8123b31539b441c263fd54ad7bb", null ]
];