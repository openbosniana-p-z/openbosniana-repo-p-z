var group__spa__result =
[
    [ "result.h", "result_8h.html", null ],
    [ "SPA_ASYNC_BIT", "group__spa__result.html#gab20d44383dc08a6c9f29126c9ff54a7d", null ],
    [ "SPA_ASYNC_SEQ_MASK", "group__spa__result.html#ga90c70217108ef23c77b3a3f336fab491", null ],
    [ "SPA_ASYNC_MASK", "group__spa__result.html#ga983f495e5784eb226844b4f540d8dfad", null ],
    [ "SPA_RESULT_IS_OK", "group__spa__result.html#ga94d2e4501333b4073e27b472ba94135f", null ],
    [ "SPA_RESULT_IS_ERROR", "group__spa__result.html#ga1f29cbb3d4dcbcde8d828dca94ebe44e", null ],
    [ "SPA_RESULT_IS_ASYNC", "group__spa__result.html#gac6610ec8c7368e5c1bf18f92018656f2", null ],
    [ "SPA_RESULT_ASYNC_SEQ", "group__spa__result.html#ga6eb31af26e93aca850932671837ad577", null ],
    [ "SPA_RESULT_RETURN_ASYNC", "group__spa__result.html#ga1546730722175618f789f387e8593f35", null ],
    [ "spa_strerror", "group__spa__result.html#ga93ac5a2c6bebade4a7268f61f2dc5731", null ]
];