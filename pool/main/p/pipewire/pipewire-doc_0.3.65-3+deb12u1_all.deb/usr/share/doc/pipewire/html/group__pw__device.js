var group__pw__device =
[
    [ "src/pipewire/device.h", "src_2pipewire_2device_8h.html", null ],
    [ "pw_device_info", "structpw__device__info.html", [
      [ "id", "structpw__device__info.html#a05bdd1fb2e89f763b27fe8784cb3e5c2", null ],
      [ "change_mask", "structpw__device__info.html#a3c53740de36a82a69153911b6777f66e", null ],
      [ "params", "structpw__device__info.html#ad8eb88e166e5527d4d5f418e591274c0", null ],
      [ "n_params", "structpw__device__info.html#accce9f7bcbbb1e5142298f18ce03d799", null ]
    ] ],
    [ "pw_device_events", "structpw__device__events.html", [
      [ "version", "structpw__device__events.html#adbe2ffa9bd2bcf75f82ce7cfd99ebb29", null ],
      [ "info", "structpw__device__events.html#a223b1ad31ee9892baa431d000ec94141", null ],
      [ "param", "structpw__device__events.html#afd599abc733552407c0284871b1e0635", null ]
    ] ],
    [ "pw_device_methods", "structpw__device__methods.html", [
      [ "version", "structpw__device__methods.html#a9141d0e02e0c16303f59f79d4c1569d8", null ],
      [ "add_listener", "structpw__device__methods.html#abe74e1fc28413c676391beffec0ba250", null ],
      [ "subscribe_params", "structpw__device__methods.html#a50406b74540f4535df9b01ae15cfcfe0", null ],
      [ "enum_params", "structpw__device__methods.html#a8210738d5878d65481bc918ff935aa80", null ],
      [ "set_param", "structpw__device__methods.html#a8251c871164651bcff0d7375ebd75440", null ]
    ] ],
    [ "pw_device", "structpw__device.html", null ],
    [ "PW_TYPE_INTERFACE_Device", "group__pw__device.html#ga0ba7369431910f959890554e07d41694", null ],
    [ "PW_VERSION_DEVICE", "group__pw__device.html#gaba1e6fbe53fd95f53555dbbd6f620d5c", null ],
    [ "PW_DEVICE_CHANGE_MASK_PROPS", "group__pw__device.html#ga5cf96207cf2594407d21a890a78eab53", null ],
    [ "PW_DEVICE_CHANGE_MASK_PARAMS", "group__pw__device.html#ga0946f0f3679c5e047014ad998885757d", null ],
    [ "PW_DEVICE_CHANGE_MASK_ALL", "group__pw__device.html#ga7a549e547d4fb8b8d6158e9f3f482f29", null ],
    [ "PW_DEVICE_EVENT_INFO", "group__pw__device.html#ga8369458f9e7293c6a418f8471799d7ee", null ],
    [ "PW_DEVICE_EVENT_PARAM", "group__pw__device.html#ga00d371fbfe50624ef34fcca28881ca34", null ],
    [ "PW_DEVICE_EVENT_NUM", "group__pw__device.html#ga25a3024f8663c52b9f96bff7813297d0", null ],
    [ "PW_VERSION_DEVICE_EVENTS", "group__pw__device.html#ga347b597f50395ecbf0e168579c4062bd", null ],
    [ "PW_DEVICE_METHOD_ADD_LISTENER", "group__pw__device.html#ga13514a8af6940a5de09a8eae80e220d0", null ],
    [ "PW_DEVICE_METHOD_SUBSCRIBE_PARAMS", "group__pw__device.html#gaa88d522ca80427bc978c774c9fadb40a", null ],
    [ "PW_DEVICE_METHOD_ENUM_PARAMS", "group__pw__device.html#gacd1757d2a1cfd632528c190850f96a5f", null ],
    [ "PW_DEVICE_METHOD_SET_PARAM", "group__pw__device.html#ga4c703049ad5a77b9aa1dff828c18e45c", null ],
    [ "PW_DEVICE_METHOD_NUM", "group__pw__device.html#ga1d935a2ae9c5d0dddeddfb8976473622", null ],
    [ "PW_VERSION_DEVICE_METHODS", "group__pw__device.html#ga9a81a89387a9a2c4d1a7cde4a994886f", null ],
    [ "pw_device_method", "group__pw__device.html#ga13a83da0b646fb1d404cd89aabddc080", null ],
    [ "pw_device_add_listener", "group__pw__device.html#gacada6f5cddae87328dc9ecded641a320", null ],
    [ "pw_device_subscribe_params", "group__pw__device.html#gaafc5a1d7f3f6be5651feb9e8c09323c9", null ],
    [ "pw_device_enum_params", "group__pw__device.html#ga974702b816b81fdcd22a8172c0f00915", null ],
    [ "pw_device_set_param", "group__pw__device.html#ga6c6fe9b2af761c9da560b2d9bc041fbe", null ],
    [ "pw_device_info_update", "group__pw__device.html#gadddbb259795b02f6b8f3c25afb03996c", null ],
    [ "pw_device_info_merge", "group__pw__device.html#gab050ce8005a77ca72eb26be15b2931fb", null ],
    [ "pw_device_info_free", "group__pw__device.html#gaa520fd3279ad8c1b34adb414f7726864", null ]
];