var group__pw__profiler =
[
    [ "src/pipewire/extensions/profiler.h", "src_2pipewire_2extensions_2profiler_8h.html", null ],
    [ "pw_profiler_events", "structpw__profiler__events.html", [
      [ "version", "structpw__profiler__events.html#a00e0a36b711bd01ce994d368e0e39629", null ],
      [ "profile", "structpw__profiler__events.html#ab4f32595bfcc74f3c77ccc9cb0bb2acb", null ]
    ] ],
    [ "pw_profiler_methods", "structpw__profiler__methods.html", [
      [ "version", "structpw__profiler__methods.html#a6d6488538db93934b63ad3ee7fc3cc9a", null ],
      [ "add_listener", "structpw__profiler__methods.html#a036f959bbeba1ad5da22f20c0e66a1f8", null ]
    ] ],
    [ "pw_profiler", "structpw__profiler.html", null ],
    [ "PW_TYPE_INTERFACE_Profiler", "group__pw__profiler.html#ga2270ff65dd05ec8d44b575d345b34ef7", null ],
    [ "PW_VERSION_PROFILER", "group__pw__profiler.html#gaa67b89b0b81bd0f644e9dc815910a5a6", null ],
    [ "PW_EXTENSION_MODULE_PROFILER", "group__pw__profiler.html#gadce3d202b44c713a464705f5d1651231", null ],
    [ "PW_PROFILER_EVENT_PROFILE", "group__pw__profiler.html#ga24d59364fcf4c282135018a9d4515174", null ],
    [ "PW_PROFILER_EVENT_NUM", "group__pw__profiler.html#gaf01a5556e210e625e2acbda238290083", null ],
    [ "PW_VERSION_PROFILER_EVENTS", "group__pw__profiler.html#ga8269aa7abfa3353f2c877b7ec85be6e9", null ],
    [ "PW_PROFILER_METHOD_ADD_LISTENER", "group__pw__profiler.html#ga07a9df46d368a90b9917e01c186a820f", null ],
    [ "PW_PROFILER_METHOD_NUM", "group__pw__profiler.html#ga1f3257ff0903e9d284048f1d119c00eb", null ],
    [ "PW_VERSION_PROFILER_METHODS", "group__pw__profiler.html#ga1810f152594c69f1955dd300585cf12a", null ],
    [ "pw_profiler_method", "group__pw__profiler.html#ga95f26236f843ad4afc3de455b45cbcc3", null ],
    [ "pw_profiler_add_listener", "group__pw__profiler.html#gafc2a6db1575319ddccac1e4f6a8c17d9", null ],
    [ "PW_KEY_PROFILER_NAME", "group__pw__profiler.html#ga3a9ba0d4647580d079d96ff5163eabe3", null ]
];