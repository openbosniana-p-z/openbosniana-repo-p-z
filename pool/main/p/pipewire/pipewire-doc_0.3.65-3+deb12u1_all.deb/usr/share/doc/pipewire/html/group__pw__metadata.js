var group__pw__metadata =
[
    [ "metadata.h", "metadata_8h.html", null ],
    [ "pw_metadata_events", "structpw__metadata__events.html", [
      [ "version", "structpw__metadata__events.html#a4d1905b2e0e9965cc9c36461133a6047", null ],
      [ "property", "structpw__metadata__events.html#ac2dd9bc9016f5b10c7af9f292532ef5d", null ]
    ] ],
    [ "pw_metadata_methods", "structpw__metadata__methods.html", [
      [ "version", "structpw__metadata__methods.html#af38a2fe70b07a10b103931f9e03561c6", null ],
      [ "add_listener", "structpw__metadata__methods.html#a3c5f9a58ed230b347bb819e38662bd46", null ],
      [ "set_property", "structpw__metadata__methods.html#af13aa299868c89d4e91411443fdd46f2", null ],
      [ "clear", "structpw__metadata__methods.html#a140aea55bb9350536ef59595585b7a6b", null ]
    ] ],
    [ "pw_metadata", "structpw__metadata.html", null ],
    [ "PW_TYPE_INTERFACE_Metadata", "group__pw__metadata.html#gaa94b57fc941fd4f74843894c74df848c", null ],
    [ "PW_VERSION_METADATA", "group__pw__metadata.html#ga0b1a5ed92883256e75edc853387c0eb5", null ],
    [ "PW_EXTENSION_MODULE_METADATA", "group__pw__metadata.html#ga3b0d2e4b64bdd88c21f946f9fed8dd7d", null ],
    [ "PW_METADATA_EVENT_PROPERTY", "group__pw__metadata.html#gac72ab35c90567fab1c2e367bb64e0a2a", null ],
    [ "PW_METADATA_EVENT_NUM", "group__pw__metadata.html#ga179415667a60226d6ca468834b5cb96f", null ],
    [ "PW_VERSION_METADATA_EVENTS", "group__pw__metadata.html#ga27db7012d25c69d0979feace29c7b4d8", null ],
    [ "PW_METADATA_METHOD_ADD_LISTENER", "group__pw__metadata.html#ga9ff8b808b8c5b2460a8f4e65329f9cba", null ],
    [ "PW_METADATA_METHOD_SET_PROPERTY", "group__pw__metadata.html#ga20c3f47b41cbe435c69024afcdb39bd5", null ],
    [ "PW_METADATA_METHOD_CLEAR", "group__pw__metadata.html#gaddcbfe2a147f61a4fbc978588c7efd41", null ],
    [ "PW_METADATA_METHOD_NUM", "group__pw__metadata.html#gab620cb856d9c137dba7b868c8461f7cf", null ],
    [ "PW_VERSION_METADATA_METHODS", "group__pw__metadata.html#ga3068839c26189e81ff56d19621329a6f", null ],
    [ "pw_metadata_method", "group__pw__metadata.html#gadb1dab39cb48e9b60dfbb35ba32d80b9", null ],
    [ "pw_metadata_add_listener", "group__pw__metadata.html#ga69cd4c94d8630f838be17fb298e287ef", null ],
    [ "pw_metadata_set_property", "group__pw__metadata.html#ga0021965e39d587fccd9e0390f4f2f3f3", null ],
    [ "pw_metadata_clear", "group__pw__metadata.html#gaa690d58ed6185add131dbb88976b54ef", null ],
    [ "PW_KEY_METADATA_NAME", "group__pw__metadata.html#gaef9f80c524a01f3883aff5180e5c2c81", null ]
];