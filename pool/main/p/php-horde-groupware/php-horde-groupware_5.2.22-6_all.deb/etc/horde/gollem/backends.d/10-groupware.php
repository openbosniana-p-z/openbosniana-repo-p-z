<?php
$backends['ftp']['disabled'] = true;
$backends['sqlhome']['disabled'] = false;
$backends['sqlhome']['name'] = 'Home';
