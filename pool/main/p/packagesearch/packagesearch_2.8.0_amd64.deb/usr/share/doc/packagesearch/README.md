# Debian Packagesearch
Last Change: 2022-07-15

Author: Benjamin Mesing (bensmail@gmx.net)  
License: GPL  
Language: C++  
Compiler: gcc  
Platforms: Debian-Linux  
Documentation: Doxygen  

This program provides a UI for package searches on Debian systems. 
In particular it integrates debtags developed by Enrico Zini. 
Debtags is a new approach that allows organisation of packages in a 
more convenient way.

Tags are categories that can be added to a package. They characterise
the program. Multiple Tags may be assigned to one package.


See the programs help page for more information (accessible via 
Help->Content in the menu).

# Developer Info

## Building
* install dependencies listed in debian/control
* generate Make file through cmake; inside root project dir
    * mkdir build-packagesearch
    * cd build-packagesearch
    * cmake ../ --> this will generate a Makefile for debug, to create one for release, define an environment variable PACKAGESEARCH_BUILD_TYPE=release
    * make --> should build packagesearch binary and all plugins
    * use fakeroot debian/rules binary to build a binary to try if everything is working on the packaging side

## Create Debian release
* within git repo
* update version via dch -v XXX
* run ./make-release.pl
* chdir to ../packagesearch-release/packagesearch-yyyy-mm-dd
* debuild
* check generated files with lintian, debdiff, dpkg --content,...
* as root
    * cowbuilder create (if not yet there)
    * cowbuilder update
    * cowbuilder build packagesearch_2.8.0.dsc

## Checklist when adding new Plugins
* add to src/plugins/plugins.pro/plugins-test.pro
* add line to Makefile translations-target
