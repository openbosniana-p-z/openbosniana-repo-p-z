
/* Definitions from missing header files */

#ifndef Py_MISSING_H
#define Py_MISSING_H
#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif
#endif /* !Py_MISSING_H */
