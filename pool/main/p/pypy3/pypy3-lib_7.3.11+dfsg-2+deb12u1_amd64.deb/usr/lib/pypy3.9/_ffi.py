# Backward compatibility hack
from _rawffi.alt import *
