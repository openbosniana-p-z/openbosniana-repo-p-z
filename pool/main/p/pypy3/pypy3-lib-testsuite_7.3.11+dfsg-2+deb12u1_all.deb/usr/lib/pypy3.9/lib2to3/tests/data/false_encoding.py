#!/usr/bin/pypy3
print '#coding=0'
