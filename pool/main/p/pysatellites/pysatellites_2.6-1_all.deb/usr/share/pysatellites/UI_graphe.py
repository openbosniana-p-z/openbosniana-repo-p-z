# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'graphe.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Graphe(object):
    def setupUi(self, Graphe):
        Graphe.setObjectName("Graphe")
        Graphe.resize(302, 516)
        self.buttonBox = QtWidgets.QDialogButtonBox(Graphe)
        self.buttonBox.setGeometry(QtCore.QRect(110, 480, 81, 32))
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Close)
        self.buttonBox.setObjectName("buttonBox")
        self.grapheLabel = QtWidgets.QLabel(Graphe)
        self.grapheLabel.setGeometry(QtCore.QRect(10, 10, 270, 450))
        self.grapheLabel.setText("")
        self.grapheLabel.setObjectName("grapheLabel")

        self.retranslateUi(Graphe)
        self.buttonBox.accepted.connect(Graphe.accept)
        self.buttonBox.rejected.connect(Graphe.reject)
        QtCore.QMetaObject.connectSlotsByName(Graphe)

    def retranslateUi(self, Graphe):
        _translate = QtCore.QCoreApplication.translate
        Graphe.setWindowTitle(_translate("Graphe", "Dialog"))

