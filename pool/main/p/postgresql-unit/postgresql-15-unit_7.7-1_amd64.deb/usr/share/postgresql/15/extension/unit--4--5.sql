CREATE FUNCTION round(unit)
	RETURNS unit
	AS '$libdir/unit', 'unit_round'
	LANGUAGE C IMMUTABLE STRICT;
