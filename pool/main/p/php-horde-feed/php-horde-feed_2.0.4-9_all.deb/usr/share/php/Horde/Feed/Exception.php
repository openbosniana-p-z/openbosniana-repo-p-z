<?php
/**
 * @category Horde
 * @package Feed
 */

/**
 * @category Horde
 * @package Feed
 */
class Horde_Feed_Exception extends Horde_Exception_LastError
{
}
