#pragma once

#include <ATen/cpu/vec/functional_base.h>
#include <ATen/cpu/vec/functional_bfloat16.h>
