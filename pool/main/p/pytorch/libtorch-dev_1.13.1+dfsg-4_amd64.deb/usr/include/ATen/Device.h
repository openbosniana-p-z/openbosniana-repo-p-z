#pragma once
#include <c10/core/Device.h>
