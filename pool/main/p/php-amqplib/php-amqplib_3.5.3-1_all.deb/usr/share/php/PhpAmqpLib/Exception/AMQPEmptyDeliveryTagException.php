<?php

namespace PhpAmqpLib\Exception;

class AMQPEmptyDeliveryTagException extends AMQPRuntimeException
{
}
