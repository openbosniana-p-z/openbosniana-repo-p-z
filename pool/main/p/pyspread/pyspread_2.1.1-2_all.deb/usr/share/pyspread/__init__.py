# -*- coding: utf-8 -*-

APP_NAME = "pyspread"

# Current pyspread version
VERSION = "2.1.1"
