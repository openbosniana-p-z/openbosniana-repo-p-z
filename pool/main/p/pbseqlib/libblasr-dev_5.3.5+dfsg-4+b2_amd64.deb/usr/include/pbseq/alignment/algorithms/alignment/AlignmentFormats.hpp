#ifndef _BLASR_ALIGNMENT_FORMATS_HPP_
#define _BLASR_ALIGNMENT_FORMATS_HPP_

enum AlignmentPrintFormat
{
    StickPrint,
    SummaryPrint,
    CompareXML,
    Vulgar,
    Interval,
    CompareSequencesParsable,
    SAM,
    BAM,
    NOFORMAT
};

#endif
