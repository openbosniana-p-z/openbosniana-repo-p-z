#ifndef TUPLE_OPERATIONS_H_
#define TUPLE_OPERATIONS_H_

#endif
