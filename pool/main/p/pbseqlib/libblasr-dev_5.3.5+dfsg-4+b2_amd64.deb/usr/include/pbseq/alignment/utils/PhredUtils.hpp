#ifndef _BLASR_UTILS_PHRED_UTILS_HPP_
#define _BLASR_UTILS_PHRED_UTILS_HPP_

double InversePhred(double phred);

double Phred(double pvalue);

#endif  // _BLASR_UTILS_PHRED_UTILS_HPP_
