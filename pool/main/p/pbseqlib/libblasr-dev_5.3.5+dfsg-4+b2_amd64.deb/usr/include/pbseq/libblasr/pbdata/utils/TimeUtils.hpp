#ifndef _BLASR_TIME_UTILS_HPP_
#define _BLASR_TIME_UTILS_HPP_

#include <string>

std::string GetTimestamp();

#endif
