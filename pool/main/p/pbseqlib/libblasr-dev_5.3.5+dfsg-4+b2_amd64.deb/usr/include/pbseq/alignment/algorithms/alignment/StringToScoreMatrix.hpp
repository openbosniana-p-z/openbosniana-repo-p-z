#ifndef _BLASR_STRING_TO_SCORE_MATRIX_HPP_
#define _BLASR_STRING_TO_SCORE_MATRIX_HPP_

#include <sstream>
#include <string>
#include <vector>

bool StringToScoreMatrix(std::string &str, int matrix[5][5]);
#endif
