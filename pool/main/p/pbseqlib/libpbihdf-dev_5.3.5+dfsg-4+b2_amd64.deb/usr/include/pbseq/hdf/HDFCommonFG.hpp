#ifndef _BLASR_HDF_COMMON_FG_HPP_
#define _BLASR_HDF_COMMON_FG_HPP_

using namespace H5;

class HDFCommonFG
{
public:
};
#endif
