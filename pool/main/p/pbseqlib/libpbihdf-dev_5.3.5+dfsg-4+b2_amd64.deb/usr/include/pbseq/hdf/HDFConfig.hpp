#ifndef _BLASR_HDF_CONFIG_HPP_
#define _BLASR_HDF_CONFIG_HPP_

#define MAX_DIMS 10

#ifdef HAVE_HDF5_1_10_1
#define CommonFG Group
#define H5Location H5Object
#endif

#endif
