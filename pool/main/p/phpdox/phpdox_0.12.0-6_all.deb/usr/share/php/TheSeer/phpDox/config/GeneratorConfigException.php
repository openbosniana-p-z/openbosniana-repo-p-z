<?php declare(strict_types = 1);
namespace TheSeer\phpDox;

class GeneratorConfigException extends ConfigException {
    public const BuilderNotFound = 1;
}
