<?php declare(strict_types = 1);
namespace TheSeer\phpDox;

class CLIOptionsException extends \Exception {
}
