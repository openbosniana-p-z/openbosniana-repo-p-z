<?php declare(strict_types = 1);
namespace TheSeer\phpDox\Collector;

class ClassObject extends AbstractUnitObject {
    protected $rootName = 'class';
}
