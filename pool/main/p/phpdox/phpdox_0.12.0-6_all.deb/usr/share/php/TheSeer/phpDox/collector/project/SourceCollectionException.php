<?php declare(strict_types = 1);
namespace TheSeer\phpDox\Collector;

class SourceCollectionException extends \Exception {
    public const SourceNotFound = 1;
}
