<?php declare(strict_types = 1);
namespace TheSeer\phpDox\Collector;

class MethodObjectException extends \Exception {
    public const InvalidVisibility = 1;
}
