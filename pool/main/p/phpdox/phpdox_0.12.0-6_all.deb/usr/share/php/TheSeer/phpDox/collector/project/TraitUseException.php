<?php declare(strict_types = 1);
namespace TheSeer\phpDox\Collector;

class TraitUseException extends \Exception {
    public const NotAliased = 1;
}
