<?php declare(strict_types = 1);
namespace TheSeer\phpDox\Collector\Backend;

class ParseResultException extends \Exception {
    public const NoTokenDom = 1;
}
