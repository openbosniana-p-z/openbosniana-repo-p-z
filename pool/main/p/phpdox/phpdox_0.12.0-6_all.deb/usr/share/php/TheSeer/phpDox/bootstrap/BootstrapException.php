<?php declare(strict_types = 1);
namespace TheSeer\phpDox;

class BootstrapException extends \Exception {
    public const RequireFailed = 1;
}
