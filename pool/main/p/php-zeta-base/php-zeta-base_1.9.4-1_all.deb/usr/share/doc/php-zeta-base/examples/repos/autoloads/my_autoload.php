<?php
    return array (
        'erMyClass1' => 'Me/myclass1.php',
        'erMyClass2' => 'Me/myclass2.php',
    );
?>
