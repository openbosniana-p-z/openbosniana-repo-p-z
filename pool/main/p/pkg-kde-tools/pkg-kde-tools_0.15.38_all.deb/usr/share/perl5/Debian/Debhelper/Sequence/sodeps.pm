insert_after("dh_shlibdeps", "dh_sodeps");

1;
