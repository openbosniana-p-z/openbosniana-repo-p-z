#!/usr/bin/env python

#$ python setup.py build_ext --inplace

from distutils.core import setup
from distutils.extension import Extension
from Cython.Build import cythonize

import numpy
import petsc4py

def configure():
    INCLUDE_DIRS = []
    LIBRARY_DIRS = []
    LIBRARIES    = []

    # PETSc
    import os
    PETSC_DIR  = os.environ['PETSC_DIR']
    PETSC_ARCH = os.environ.get('PETSC_ARCH', '')
    PETSC_LIB_EXT = os.environ.get('PETSC_LIB_EXT', '')
    from os.path import join, isdir
    if not PETSC_LIB_EXT:
        from configparser import ConfigParser
        parser = ConfigParser()
        petscvariables = join(PETSC_DIR, PETSC_ARCH, 'lib/petsc/conf/petscvariables')
        with open(petscvariables) as stream: # waiting for https://github.com/python/cpython/pull/2735 to avoid this step
            parser.read_string("[petscvariables]\n" + stream.read())
        PETSC_LIB_EXT = parser['petscvariables'].get('PETSC_LIB_EXT','')
    if PETSC_ARCH and isdir(join(PETSC_DIR, PETSC_ARCH)):
        INCLUDE_DIRS += [join(PETSC_DIR, PETSC_ARCH, 'include'),
                         join(PETSC_DIR, 'include')]
        LIBRARY_DIRS += [join(PETSC_DIR, PETSC_ARCH, 'lib')]
    else:
        if PETSC_ARCH: pass # XXX should warn ...
        INCLUDE_DIRS += [join(PETSC_DIR, 'include')]
        LIBRARY_DIRS += [join(PETSC_DIR, 'lib')]
    LIBRARIES += ['petsc'+PETSC_LIB_EXT]

    # PETSc for Python
    INCLUDE_DIRS += [petsc4py.get_include()]

    # NumPy
    INCLUDE_DIRS += [numpy.get_include()]

    return dict(
        include_dirs=INCLUDE_DIRS + [os.curdir],
        libraries=LIBRARIES,
        library_dirs=LIBRARY_DIRS,
        runtime_library_dirs=LIBRARY_DIRS,
    )

extensions = [
    Extension('Bratu3D',
              sources = ['Bratu3D.pyx',
                         'Bratu3Dimpl.c'],
              depends = ['Bratu3Dimpl.h'],
              **configure()),
]

setup(name = "Bratu3D",
      ext_modules = cythonize(
          extensions, include_path=[petsc4py.get_include()]),
)
