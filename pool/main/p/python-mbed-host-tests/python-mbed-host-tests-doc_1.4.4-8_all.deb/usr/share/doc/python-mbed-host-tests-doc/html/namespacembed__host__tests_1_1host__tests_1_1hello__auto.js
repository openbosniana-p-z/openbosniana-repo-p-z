var namespacembed__host__tests_1_1host__tests_1_1hello__auto =
[
    [ "HelloTest", "classmbed__host__tests_1_1host__tests_1_1hello__auto_1_1HelloTest.html", "classmbed__host__tests_1_1host__tests_1_1hello__auto_1_1HelloTest" ]
];