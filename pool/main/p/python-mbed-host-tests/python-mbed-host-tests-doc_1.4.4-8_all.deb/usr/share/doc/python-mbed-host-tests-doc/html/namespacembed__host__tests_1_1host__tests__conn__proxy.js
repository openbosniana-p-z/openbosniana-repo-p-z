var namespacembed__host__tests_1_1host__tests__conn__proxy =
[
    [ "conn_primitive", "namespacembed__host__tests_1_1host__tests__conn__proxy_1_1conn__primitive.html", "namespacembed__host__tests_1_1host__tests__conn__proxy_1_1conn__primitive" ],
    [ "conn_primitive_fastmodel", "namespacembed__host__tests_1_1host__tests__conn__proxy_1_1conn__primitive__fastmodel.html", "namespacembed__host__tests_1_1host__tests__conn__proxy_1_1conn__primitive__fastmodel" ],
    [ "conn_primitive_remote", "namespacembed__host__tests_1_1host__tests__conn__proxy_1_1conn__primitive__remote.html", "namespacembed__host__tests_1_1host__tests__conn__proxy_1_1conn__primitive__remote" ],
    [ "conn_primitive_serial", "namespacembed__host__tests_1_1host__tests__conn__proxy_1_1conn__primitive__serial.html", "namespacembed__host__tests_1_1host__tests__conn__proxy_1_1conn__primitive__serial" ],
    [ "conn_proxy", "namespacembed__host__tests_1_1host__tests__conn__proxy_1_1conn__proxy.html", "namespacembed__host__tests_1_1host__tests__conn__proxy_1_1conn__proxy" ]
];