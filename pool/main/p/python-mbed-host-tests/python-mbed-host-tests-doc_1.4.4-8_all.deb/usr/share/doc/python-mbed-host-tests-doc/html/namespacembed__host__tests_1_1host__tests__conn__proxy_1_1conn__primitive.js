var namespacembed__host__tests_1_1host__tests__conn__proxy_1_1conn__primitive =
[
    [ "ConnectorPrimitive", "classmbed__host__tests_1_1host__tests__conn__proxy_1_1conn__primitive_1_1ConnectorPrimitive.html", "classmbed__host__tests_1_1host__tests__conn__proxy_1_1conn__primitive_1_1ConnectorPrimitive" ],
    [ "ConnectorPrimitiveException", "classmbed__host__tests_1_1host__tests__conn__proxy_1_1conn__primitive_1_1ConnectorPrimitiveException.html", null ]
];