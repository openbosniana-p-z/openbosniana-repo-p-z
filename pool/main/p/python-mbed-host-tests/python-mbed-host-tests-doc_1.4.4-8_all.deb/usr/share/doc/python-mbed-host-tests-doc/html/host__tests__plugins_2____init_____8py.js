var host__tests__plugins_2____init_____8py =
[
    [ "call_plugin", "host__tests__plugins_2____init_____8py.html#ada93fba54f5cfa22cdabcb5062c59f7e", null ],
    [ "get_plugin_caps", "host__tests__plugins_2____init_____8py.html#a3fda33e0f9eea4a2857d34307cbc6cbd", null ],
    [ "get_plugin_info", "host__tests__plugins_2____init_____8py.html#a4f3b19c21c6f77f59e64f7c3a5a6d46b", null ],
    [ "print_plugin_info", "host__tests__plugins_2____init_____8py.html#aef62ae1c315b0fb5cebea8ed871a0323", null ],
    [ "HOST_TEST_PLUGIN_REGISTRY", "host__tests__plugins_2____init_____8py.html#aed0755e18794c531f35c99947745f9e5", null ]
];