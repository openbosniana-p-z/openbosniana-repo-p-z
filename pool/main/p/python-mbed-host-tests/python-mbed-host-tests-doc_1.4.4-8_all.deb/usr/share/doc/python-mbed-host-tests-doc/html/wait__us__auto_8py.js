var wait__us__auto_8py =
[
    [ "mbed_host_tests.host_tests.wait_us_auto.WaitusTest", "classmbed__host__tests_1_1host__tests_1_1wait__us__auto_1_1WaitusTest.html", "classmbed__host__tests_1_1host__tests_1_1wait__us__auto_1_1WaitusTest" ]
];