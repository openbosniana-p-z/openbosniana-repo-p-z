var classmbed__host__tests_1_1host__tests__plugins_1_1host__test__registry_1_1HostTestRegistry =
[
    [ "__str__", "classmbed__host__tests_1_1host__tests__plugins_1_1host__test__registry_1_1HostTestRegistry.html#a115a049f9ab77c9bcfd4ace09b73a712", null ],
    [ "call_plugin", "classmbed__host__tests_1_1host__tests__plugins_1_1host__test__registry_1_1HostTestRegistry.html#a8d2a435caf1a3ccb69ad3554b31e3b28", null ],
    [ "get_dict", "classmbed__host__tests_1_1host__tests__plugins_1_1host__test__registry_1_1HostTestRegistry.html#ad8d8c47e697a43c313f266c0115e5bc7", null ],
    [ "get_plugin_caps", "classmbed__host__tests_1_1host__tests__plugins_1_1host__test__registry_1_1HostTestRegistry.html#acb874b48ba9ffe29efed293914695644", null ],
    [ "get_string", "classmbed__host__tests_1_1host__tests__plugins_1_1host__test__registry_1_1HostTestRegistry.html#ae363cecb9dcdff0b7753a172e652d67c", null ],
    [ "load_plugin", "classmbed__host__tests_1_1host__tests__plugins_1_1host__test__registry_1_1HostTestRegistry.html#ade404c81e3c0e9f5c76f250ad9e9e7b2", null ],
    [ "print_error", "classmbed__host__tests_1_1host__tests__plugins_1_1host__test__registry_1_1HostTestRegistry.html#aa93f64747de2a90986cbdded4b410464", null ],
    [ "register_plugin", "classmbed__host__tests_1_1host__tests__plugins_1_1host__test__registry_1_1HostTestRegistry.html#ad543b64f39d41b6651bba5322d50835c", null ],
    [ "PLUGINS", "classmbed__host__tests_1_1host__tests__plugins_1_1host__test__registry_1_1HostTestRegistry.html#a4a88253ad3a0862e28310e1fceb884a5", null ]
];