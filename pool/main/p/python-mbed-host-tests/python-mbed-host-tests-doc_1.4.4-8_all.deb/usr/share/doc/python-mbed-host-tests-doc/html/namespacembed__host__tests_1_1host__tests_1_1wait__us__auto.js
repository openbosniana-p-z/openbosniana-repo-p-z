var namespacembed__host__tests_1_1host__tests_1_1wait__us__auto =
[
    [ "WaitusTest", "classmbed__host__tests_1_1host__tests_1_1wait__us__auto_1_1WaitusTest.html", "classmbed__host__tests_1_1host__tests_1_1wait__us__auto_1_1WaitusTest" ]
];