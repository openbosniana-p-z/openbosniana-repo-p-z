var hello__auto_8py =
[
    [ "mbed_host_tests.host_tests.hello_auto.HelloTest", "classmbed__host__tests_1_1host__tests_1_1hello__auto_1_1HelloTest.html", "classmbed__host__tests_1_1host__tests_1_1hello__auto_1_1HelloTest" ]
];