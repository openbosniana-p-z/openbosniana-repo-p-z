var module__copy__jn51xx_8py =
[
    [ "mbed_host_tests.host_tests_plugins.module_copy_jn51xx.HostTestPluginCopyMethod_JN51xx", "classmbed__host__tests_1_1host__tests__plugins_1_1module__copy__jn51xx_1_1HostTestPluginCopyMethod__JN51xx.html", "classmbed__host__tests_1_1host__tests__plugins_1_1module__copy__jn51xx_1_1HostTestPluginCopyMethod__JN51xx" ],
    [ "load_plugin", "module__copy__jn51xx_8py.html#a85531d94987241ec4c8c671b55509592", null ]
];