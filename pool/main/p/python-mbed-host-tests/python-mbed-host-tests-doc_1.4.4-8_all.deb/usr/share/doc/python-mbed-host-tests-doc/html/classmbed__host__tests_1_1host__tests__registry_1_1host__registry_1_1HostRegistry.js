var classmbed__host__tests_1_1host__tests__registry_1_1host__registry_1_1HostRegistry =
[
    [ "get_host_test", "classmbed__host__tests_1_1host__tests__registry_1_1host__registry_1_1HostRegistry.html#aa37c282a9498072c0867707d886098c0", null ],
    [ "is_host_test", "classmbed__host__tests_1_1host__tests__registry_1_1host__registry_1_1HostRegistry.html#a273b3da369aad16691aa0427e883612f", null ],
    [ "register_from_path", "classmbed__host__tests_1_1host__tests__registry_1_1host__registry_1_1HostRegistry.html#a3fdfef4b0636d660d2113791eb1b8375", null ],
    [ "register_host_test", "classmbed__host__tests_1_1host__tests__registry_1_1host__registry_1_1HostRegistry.html#a17e4368ad9fd35c1208c67289af52a33", null ],
    [ "table", "classmbed__host__tests_1_1host__tests__registry_1_1host__registry_1_1HostRegistry.html#adb0f90cfad8c15261f54498ce4536e6b", null ],
    [ "unregister_host_test", "classmbed__host__tests_1_1host__tests__registry_1_1host__registry_1_1HostRegistry.html#a175786d459a93f933c9aea8fb8fc6b71", null ],
    [ "HOST_TESTS", "classmbed__host__tests_1_1host__tests__registry_1_1host__registry_1_1HostRegistry.html#aa66c00ec59f820270df338f251c89838", null ]
];