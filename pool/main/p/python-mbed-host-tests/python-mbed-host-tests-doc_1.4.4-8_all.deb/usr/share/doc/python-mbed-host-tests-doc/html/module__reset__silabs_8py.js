var module__reset__silabs_8py =
[
    [ "mbed_host_tests.host_tests_plugins.module_reset_silabs.HostTestPluginResetMethod_SiLabs", "classmbed__host__tests_1_1host__tests__plugins_1_1module__reset__silabs_1_1HostTestPluginResetMethod__SiLabs.html", "classmbed__host__tests_1_1host__tests__plugins_1_1module__reset__silabs_1_1HostTestPluginResetMethod__SiLabs" ],
    [ "load_plugin", "module__reset__silabs_8py.html#abf45d19ff6eabdb52b477c630f9d2fa9", null ]
];