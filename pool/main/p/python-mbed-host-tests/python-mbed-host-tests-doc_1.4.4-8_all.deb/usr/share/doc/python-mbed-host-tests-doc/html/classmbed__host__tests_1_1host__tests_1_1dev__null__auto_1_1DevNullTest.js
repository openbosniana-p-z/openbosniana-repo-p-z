var classmbed__host__tests_1_1host__tests_1_1dev__null__auto_1_1DevNullTest =
[
    [ "result", "classmbed__host__tests_1_1host__tests_1_1dev__null__auto_1_1DevNullTest.html#ad7b109f375a8fead71ed8641f835da1a", null ],
    [ "setup", "classmbed__host__tests_1_1host__tests_1_1dev__null__auto_1_1DevNullTest.html#a517c5398e0387f7d9a768f7e200da8da", null ]
];