var classmbed__host__tests_1_1host__tests_1_1detect__auto_1_1DetectPlatformTest =
[
    [ "result", "classmbed__host__tests_1_1host__tests_1_1detect__auto_1_1DetectPlatformTest.html#a2a9c09ad78284dbf7615072d3b5904e9", null ],
    [ "test", "classmbed__host__tests_1_1host__tests_1_1detect__auto_1_1DetectPlatformTest.html#ae5f7421720caa91aa4175dd319e99b10", null ],
    [ "PATTERN_MICRO_NAME", "classmbed__host__tests_1_1host__tests_1_1detect__auto_1_1DetectPlatformTest.html#a9f982f3c7adb3bcab645bc8e137734ab", null ],
    [ "re_detect_micro_name", "classmbed__host__tests_1_1host__tests_1_1detect__auto_1_1DetectPlatformTest.html#a839e2d46a3cbe3e28f91e4ffe6b091ed", null ]
];