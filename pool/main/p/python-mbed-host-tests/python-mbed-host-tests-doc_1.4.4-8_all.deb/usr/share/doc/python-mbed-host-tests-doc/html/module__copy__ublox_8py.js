var module__copy__ublox_8py =
[
    [ "mbed_host_tests.host_tests_plugins.module_copy_ublox.HostTestPluginCopyMethod_ublox", "classmbed__host__tests_1_1host__tests__plugins_1_1module__copy__ublox_1_1HostTestPluginCopyMethod__ublox.html", "classmbed__host__tests_1_1host__tests__plugins_1_1module__copy__ublox_1_1HostTestPluginCopyMethod__ublox" ],
    [ "load_plugin", "module__copy__ublox_8py.html#a8db9849a13494d8f57edc2cb98c24964", null ]
];