var module__copy__silabs_8py =
[
    [ "mbed_host_tests.host_tests_plugins.module_copy_silabs.HostTestPluginCopyMethod_Silabs", "classmbed__host__tests_1_1host__tests__plugins_1_1module__copy__silabs_1_1HostTestPluginCopyMethod__Silabs.html", "classmbed__host__tests_1_1host__tests__plugins_1_1module__copy__silabs_1_1HostTestPluginCopyMethod__Silabs" ],
    [ "load_plugin", "module__copy__silabs_8py.html#ab673be962d30b16cf05bc2539aa485d0", null ]
];