var namespacembed__host__tests_1_1host__tests__registry_1_1host__registry =
[
    [ "HostRegistry", "classmbed__host__tests_1_1host__tests__registry_1_1host__registry_1_1HostRegistry.html", "classmbed__host__tests_1_1host__tests__registry_1_1host__registry_1_1HostRegistry" ],
    [ "load_source", "namespacembed__host__tests_1_1host__tests__registry_1_1host__registry.html#a279862363e182c4ecbfee3698a528141", null ]
];