var module__reset__jn51xx_8py =
[
    [ "mbed_host_tests.host_tests_plugins.module_reset_jn51xx.HostTestPluginResetMethod_JN51xx", "classmbed__host__tests_1_1host__tests__plugins_1_1module__reset__jn51xx_1_1HostTestPluginResetMethod__JN51xx.html", "classmbed__host__tests_1_1host__tests__plugins_1_1module__reset__jn51xx_1_1HostTestPluginResetMethod__JN51xx" ],
    [ "load_plugin", "module__reset__jn51xx_8py.html#a8928d0b3bacf6563010fd58ad2ff1761", null ]
];