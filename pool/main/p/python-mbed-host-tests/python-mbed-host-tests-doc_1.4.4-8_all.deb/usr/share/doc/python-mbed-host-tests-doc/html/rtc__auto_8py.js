var rtc__auto_8py =
[
    [ "mbed_host_tests.host_tests.rtc_auto.RTCTest", "classmbed__host__tests_1_1host__tests_1_1rtc__auto_1_1RTCTest.html", "classmbed__host__tests_1_1host__tests_1_1rtc__auto_1_1RTCTest" ]
];