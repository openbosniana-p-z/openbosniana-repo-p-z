var namespacembed__host__tests_1_1host__tests_1_1dev__null__auto =
[
    [ "DevNullTest", "classmbed__host__tests_1_1host__tests_1_1dev__null__auto_1_1DevNullTest.html", "classmbed__host__tests_1_1host__tests_1_1dev__null__auto_1_1DevNullTest" ]
];