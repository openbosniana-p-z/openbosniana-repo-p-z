var namespacembed__host__tests_1_1host__tests__registry =
[
    [ "host_registry", "namespacembed__host__tests_1_1host__tests__registry_1_1host__registry.html", "namespacembed__host__tests_1_1host__tests__registry_1_1host__registry" ]
];