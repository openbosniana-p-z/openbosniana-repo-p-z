var namespacembed__host__tests_1_1host__tests_1_1default__auto =
[
    [ "DefaultAuto", "classmbed__host__tests_1_1host__tests_1_1default__auto_1_1DefaultAuto.html", null ]
];