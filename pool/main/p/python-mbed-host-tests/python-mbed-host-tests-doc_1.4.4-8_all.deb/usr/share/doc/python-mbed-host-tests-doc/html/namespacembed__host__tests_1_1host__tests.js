var namespacembed__host__tests_1_1host__tests =
[
    [ "base_host_test", "namespacembed__host__tests_1_1host__tests_1_1base__host__test.html", "namespacembed__host__tests_1_1host__tests_1_1base__host__test" ],
    [ "default_auto", "namespacembed__host__tests_1_1host__tests_1_1default__auto.html", "namespacembed__host__tests_1_1host__tests_1_1default__auto" ],
    [ "detect_auto", "namespacembed__host__tests_1_1host__tests_1_1detect__auto.html", "namespacembed__host__tests_1_1host__tests_1_1detect__auto" ],
    [ "dev_null_auto", "namespacembed__host__tests_1_1host__tests_1_1dev__null__auto.html", "namespacembed__host__tests_1_1host__tests_1_1dev__null__auto" ],
    [ "echo", "namespacembed__host__tests_1_1host__tests_1_1echo.html", "namespacembed__host__tests_1_1host__tests_1_1echo" ],
    [ "hello_auto", "namespacembed__host__tests_1_1host__tests_1_1hello__auto.html", "namespacembed__host__tests_1_1host__tests_1_1hello__auto" ],
    [ "rtc_auto", "namespacembed__host__tests_1_1host__tests_1_1rtc__auto.html", "namespacembed__host__tests_1_1host__tests_1_1rtc__auto" ],
    [ "wait_us_auto", "namespacembed__host__tests_1_1host__tests_1_1wait__us__auto.html", "namespacembed__host__tests_1_1host__tests_1_1wait__us__auto" ]
];