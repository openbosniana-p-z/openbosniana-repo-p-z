var namespacembed__host__tests_1_1host__tests_1_1detect__auto =
[
    [ "DetectPlatformTest", "classmbed__host__tests_1_1host__tests_1_1detect__auto_1_1DetectPlatformTest.html", "classmbed__host__tests_1_1host__tests_1_1detect__auto_1_1DetectPlatformTest" ]
];