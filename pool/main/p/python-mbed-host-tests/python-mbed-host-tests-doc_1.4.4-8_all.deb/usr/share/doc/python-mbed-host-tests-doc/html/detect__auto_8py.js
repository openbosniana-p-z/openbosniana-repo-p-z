var detect__auto_8py =
[
    [ "mbed_host_tests.host_tests.detect_auto.DetectPlatformTest", "classmbed__host__tests_1_1host__tests_1_1detect__auto_1_1DetectPlatformTest.html", "classmbed__host__tests_1_1host__tests_1_1detect__auto_1_1DetectPlatformTest" ]
];