<div style="<?php echo $rowresource['style'] ?>">
<?php if (isset($rowresource['editLink'])): ?>
  <?php echo $rowresource['editLink'] ?>
<?php endif ?>
  <div class="horde-resource-link">
    <?php echo $rowresource['link'] ?>
  </div>
</div>
