# Copyright (c) 2013 Hesky Fisher
# See LICENSE.txt for details.

"""Various dictionary formats."""
