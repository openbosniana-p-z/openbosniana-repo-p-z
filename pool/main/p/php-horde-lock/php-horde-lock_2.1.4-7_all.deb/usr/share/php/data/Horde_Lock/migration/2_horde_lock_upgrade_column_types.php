<?php
/**
 * Intentionally left empty.
 */
class HordeLockUpgradeColumnTypes extends Horde_Db_Migration_Base
{
    public function up()
    {
    }

    public function down()
    {
    }
}
