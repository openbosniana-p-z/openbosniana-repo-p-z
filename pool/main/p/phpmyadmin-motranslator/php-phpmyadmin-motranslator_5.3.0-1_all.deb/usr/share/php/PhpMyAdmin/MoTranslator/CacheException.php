<?php

declare(strict_types=1);

namespace PhpMyAdmin\MoTranslator;

use DomainException;

final class CacheException extends DomainException
{
}
