# module_name/lib/facter/swift-commented-fstab-entries
Facter.add(:swift_commented_fstab_entries) do
  setcode do
    myhash = {}
    File.open('/etc/fstab').readlines.each{ |line|
      if line.match('^[#]*UUID=')
        mountpoint = line.split[1]
        if mountpoint.match('^/srv/node/')
          drivename = mountpoint.gsub('/srv/node/', '')
          if line.match('^#')
            c = { drivename => 'commented' }
          else
            c = { drivename => 'active' }
          end
          myhash = myhash.merge(c)
        end
      end
    }
    myhash
  end
end
