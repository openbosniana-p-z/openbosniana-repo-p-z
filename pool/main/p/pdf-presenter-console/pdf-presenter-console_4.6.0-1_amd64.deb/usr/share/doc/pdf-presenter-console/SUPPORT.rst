*Important* Since we are missing man power in developing pdfpc I decided to
reject any new feature request if the submitter is not able to help in creating
the feature.

Of course bug reports are still welcome.

Please be responsive when submitting issues and pull requests. If we request
additional information from you we excpect this to be in an adequate time.

Also, please do not edit your issues via the web interface. Edits in the issues
are not send via e-mail (only the initial message). If we respond via e-mail we
might not see your latest changes to the issue.
