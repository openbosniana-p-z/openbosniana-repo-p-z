<?php
interface Horde_Queue_Task
{
    public function run();
}
