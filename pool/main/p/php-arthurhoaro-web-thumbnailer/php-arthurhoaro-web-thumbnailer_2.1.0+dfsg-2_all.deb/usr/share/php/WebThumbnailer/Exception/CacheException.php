<?php

declare(strict_types=1);

namespace WebThumbnailer\Exception;

class CacheException extends WebThumbnailerException
{

}
