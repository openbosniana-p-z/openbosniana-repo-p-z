<?php

declare(strict_types=1);

namespace WebThumbnailer\Exception;

class ThumbnailNotFoundException extends WebThumbnailerException
{

}
