<?php

declare(strict_types=1);

namespace WebThumbnailer\Exception;

abstract class WebThumbnailerException extends \Exception
{

}
