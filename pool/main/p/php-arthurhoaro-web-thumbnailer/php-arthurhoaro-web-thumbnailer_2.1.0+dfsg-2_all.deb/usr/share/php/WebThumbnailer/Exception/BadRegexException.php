<?php

declare(strict_types=1);

namespace WebThumbnailer\Exception;

class BadRegexException extends WebThumbnailerException
{

}
