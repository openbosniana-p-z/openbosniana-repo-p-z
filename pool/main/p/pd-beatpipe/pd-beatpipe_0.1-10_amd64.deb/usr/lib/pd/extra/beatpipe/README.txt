This is a realtime scheduler/event-delay/quantizer.
See the help patch. 

Bugs and reactions  to gml@xs4all.nl



Gerard van Dongen
