int c;
