var searchData=
[
  ['namespaces_2epy_0',['namespaces.py',['../namespaces_8py.html',1,'']]],
  ['number_2epy_1',['number.py',['../number_8py.html',1,'']]]
];
