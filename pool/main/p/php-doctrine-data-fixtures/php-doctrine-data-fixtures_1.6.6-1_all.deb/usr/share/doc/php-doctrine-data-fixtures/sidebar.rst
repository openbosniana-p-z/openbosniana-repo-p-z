.. toc::

   .. tocheader:: How-to guides

   .. toctree::
      :depth: 3

      how-to/loading-fixtures
      how-to/sharing-objects-between-fixtures
      how-to/fixture-ordering

.. toc::

   .. tocheader:: Explanations

   .. toctree::
      :depth: 3

      explanation/transactions-and-purging
