from pylab import *
x = range(10,20)   
y = range(40,50)
plot(x,y, marker = '+', color = 'red', markersize = 10) 
show()

