#Example: big2.py

x = 1
while x < 11:
    if x < 5:
        print( 'Samll ', x)
    else:
        print( 'Big ', x)
print( 'Done')
