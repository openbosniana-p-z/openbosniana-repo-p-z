s = [3, 3.5, 234]   # make a list
s[2] = 'haha'       # Change an element
print( s)
x = 'myname'        # String type
#x[1] = 2            # Will give ERROR
