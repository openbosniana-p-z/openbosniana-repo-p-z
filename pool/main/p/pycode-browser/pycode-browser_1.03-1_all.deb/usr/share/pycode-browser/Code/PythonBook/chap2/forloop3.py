#Example: forloop3.py

mylist = range(5,51,5)
for item in mylist:
    print( item ,)
