#Numpy : Cross

from numpy import *
a = array([1,2,3])
b = array([4,5,6])
c = cross(a,b)
print (c)
