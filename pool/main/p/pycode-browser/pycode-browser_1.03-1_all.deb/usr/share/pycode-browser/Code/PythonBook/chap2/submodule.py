from numpy import *
print( random.normal())

import scipy.special
print( scipy.special.j0(.1))

