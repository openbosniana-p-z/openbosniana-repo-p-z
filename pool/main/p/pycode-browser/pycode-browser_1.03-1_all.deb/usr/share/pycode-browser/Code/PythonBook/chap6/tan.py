from pylab import *

x = linspace(0, 2*pi,400)
y = tan(x)
plot(x,y)
show()
