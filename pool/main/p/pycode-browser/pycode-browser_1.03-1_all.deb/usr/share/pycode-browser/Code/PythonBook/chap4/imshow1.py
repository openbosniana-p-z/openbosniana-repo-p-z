from pylab import *

m = random([50,50])
imshow(m)
show()
