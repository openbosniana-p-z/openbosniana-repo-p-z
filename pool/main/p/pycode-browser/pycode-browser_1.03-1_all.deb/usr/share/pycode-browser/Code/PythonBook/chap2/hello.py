print( 'Hello World')
