from turtle import *

a = Pen()	# Creates a graphics window

for k in range(4):
  a.forward(50)
  a.left(90)
  a.circle(25)
raw_input()