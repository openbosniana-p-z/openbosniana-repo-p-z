#Numpy: Ading, multiplying arrays

from numpy import *
a = array([[2,3], [4,5]])
b = array([[1,2], [3,0]])
print (a + b)
print (a * b)
