#Example mathlocal.py

from math import sin  # sin is imported as local

print( sin(0.5)  )
