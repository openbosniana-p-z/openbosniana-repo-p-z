#Example wfile.py

f = open('test.dat' , 'w')
f.write ('This is a test file')
f.close()
