#Example: third.py

s = [3, 3.5, 234]   # make a list
s[2] = 'haha'       # Change an element
a = (4, 3.2, 'hi')  # Tuple type
a[0] = 6            # Will give ERROR
x = 'myname'        # String type
x[1] = 2            # Will give ERROR
