#Example plot2.py

from pylab import *
x = [1,2,5]
y = [4,5,6]
plot(x,y)
show()
