
#Example:  first.py

'''

This is Python program starting with a multi-line

comment, enclosed within triple quotes.

In a single line, anything after a # sign is a comment 

'''

x = 10 

print( x, type(x))        #print x and its type

y = 10.4

print( y, type(y))

z = 3 + 4j

print( z, type(z))

s1 = 'I am a String '

s2 = 'me too'

print( s1, s2, type(s1))
