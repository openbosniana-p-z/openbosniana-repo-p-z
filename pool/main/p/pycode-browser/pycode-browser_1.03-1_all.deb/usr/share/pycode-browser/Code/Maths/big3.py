#Example: big3.py

x = 1

while x < 100:
   print( x)
   if x > 10:
      print( 'Enough of this')
      break
   x = x  + 1
print( 'Done')
