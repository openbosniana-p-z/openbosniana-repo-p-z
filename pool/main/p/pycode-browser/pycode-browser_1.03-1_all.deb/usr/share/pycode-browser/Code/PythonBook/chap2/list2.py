a = [1,2]
print( a * 2)
print( a + [3,4])
b = [10, 20, a]
print( b)
