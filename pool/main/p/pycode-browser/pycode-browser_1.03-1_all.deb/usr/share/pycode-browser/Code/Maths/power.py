def power(mant, exp = 2.0):
    return mant ** exp
    
print( power(5., 3))
print( power(4.))
