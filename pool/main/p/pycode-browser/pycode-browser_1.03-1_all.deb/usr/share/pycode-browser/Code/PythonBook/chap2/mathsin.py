#Example math.py

import math

print( math.sin(0.5)) # module_name.method_name
