#Example: format.py

a = 2.0 /3 
print( a)
print( 'a = %5.3f' %(a) ) # upto 3 decimal places
