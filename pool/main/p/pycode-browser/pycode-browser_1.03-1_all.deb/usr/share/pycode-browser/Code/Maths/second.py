#Example: second.py

s = 'My name'
print( s[0])             # will print M
print( s[3])
print( s[-1])            # will print the last element
a = [12, 3.4, 'haha']  # List type
print( a, type(a))
print( a[0])
