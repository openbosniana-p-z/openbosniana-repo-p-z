def change(x):
  counter = x

counter = 10      
change(5)
print( counter)