#Example mathlocal2.py

from math import *   # import everything from math

print( sin(0.5))
