from pylab import *
x = range(10)
plot(x)   
show()

