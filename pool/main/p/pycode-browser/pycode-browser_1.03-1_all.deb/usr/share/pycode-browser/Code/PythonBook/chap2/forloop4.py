a = [2, 5, 3, 4, 12]
size = len(a)
for k in range(size):
	if a[k] < 0:
		a[k] = 0
print( a)
		
