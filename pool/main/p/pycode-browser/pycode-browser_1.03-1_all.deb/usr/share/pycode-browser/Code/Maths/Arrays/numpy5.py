#Numpy: array manipulations, scalar multiplication etc

from numpy import *
a = array([ [1.0, 2.0] , [3.0, 4.0] ]) # make a numpy array
print (a)
print (a * 5)
print (a * a)
print (a / a)
