#Numpy: Reshaping

from numpy import *
a = arange(10)
print (a)
a = a.reshape(5,2) # 5 rows and 2 columns
print (a)
