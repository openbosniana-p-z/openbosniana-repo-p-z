#Example plot3.py

from pylab import *
x = [1,2,5]
y = [4,5,6]
plot(x,y,'ro')
xlabel('x-axis')
ylabel('y-axis')
axis([0,6,1,7])
show()
