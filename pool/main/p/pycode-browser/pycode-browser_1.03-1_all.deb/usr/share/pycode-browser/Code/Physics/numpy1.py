from numpy import *
a = array( [ 10, 20, 30, 40 ] )   # create an array out of a list
print( a)
print( a * 3)
print( a / 3 )
b = array([1.0, 2.0, 3.0, 4.0])
c = a + b
a = array([1,2,3,4], dtype='float')
a = array([[1,2],[3,4]])
