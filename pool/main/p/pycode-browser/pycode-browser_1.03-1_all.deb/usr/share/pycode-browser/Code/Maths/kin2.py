#Example: kin2.py

x,y = input('Enter x and y separated by comma ')
print( 'The sum is ', x + y)
s = raw_input('Enter a decimal number ')
print( 'Your input string x 2 = ', s)
a = float(s)
print( a * 2)
