/* set-user-1.6--2.0.sql */

-- complain if script is sourced in psql, rather than via ALTER EXTENSION
\echo Use "ALTER EXTENSION set_user UPDATE to '2.0'" to load this file. \quit

-- just bumping our version to 2.0. no new sql function features here, so nothing to do.
