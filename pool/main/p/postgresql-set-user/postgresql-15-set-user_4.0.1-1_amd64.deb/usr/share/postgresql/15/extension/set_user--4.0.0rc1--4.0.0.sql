/* set-user--4.0.0rc1--4.0.0.sql */

-- complain if script is sourced in psql, rather than via ALTER EXTENSION
\echo Use "ALTER EXTENSION set_user UPDATE" to load this file. \quit

-- Allow users that may have installed 4.0.0RC1 to upgrade to 4.0.0 stable
