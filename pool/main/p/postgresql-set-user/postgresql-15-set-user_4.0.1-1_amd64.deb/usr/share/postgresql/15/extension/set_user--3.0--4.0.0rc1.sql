/* set-user-3.0--4.0.0rc1.sql */

-- complain if script is sourced in psql, rather than via ALTER EXTENSION
\echo Use "ALTER EXTENSION set_user UPDATE" to load this file. \quit

-- just bumping our version to 4.0.0rc1. no new SQL features here, so nothing to do.
