/* set-user-1.5--1.6.sql */

-- complain if script is sourced in psql, rather than via ALTER EXTENSION
\echo Use "ALTER EXTENSION set_user UPDATE to '1.6'" to load this file. \quit

-- just bumping our version to 1.6. no new sql function features here, so nothing to do.
