/* set-user-1.4--1.5.sql */

-- complain if script is sourced in psql, rather than via ALTER EXTENSION
\echo Use "ALTER EXTENSION set_user UPDATE to '1.5'" to load this file. \quit

-- just bumping our version to 1.5. no new sql function features here, so nothing to do.
