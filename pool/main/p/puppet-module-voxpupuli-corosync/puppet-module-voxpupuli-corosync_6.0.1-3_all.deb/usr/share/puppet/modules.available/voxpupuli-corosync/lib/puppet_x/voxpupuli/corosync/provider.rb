module PuppetX
  module Voxpupuli
    module Corosync
      module Provider
      end
    end
  end
end
