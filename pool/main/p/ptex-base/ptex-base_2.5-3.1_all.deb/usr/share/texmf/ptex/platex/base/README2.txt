==================================================-*-indented-text-*-=
				 $BCm0U(B
======================================================================

$B8=:_$N(B pTeX $B$G$O!"(B8 $B%S%C%H%3!<%I$NO"B3$O(B 16 $B%S%C%H%3!<%I$HG'<1(B
$B$5$l$k2DG=@-$,$"$j$^$9!#$=$N$?$a!"%U%i%s%98l$d%-%j%kJ8;z$J$I$N(B 8 $B%S%C(B
$B%H%3!<%I$NO"B3$9$k(B TeX $B%=!<%9$d%O%$%U%s%Q%?!<%s$O$^$:;H$($;$s!#(B

$B$=$N$?$a!"(BpLaTeX2e $B$G$O(B $TEXMF/tex/platex/base/ $B%G%#%l%/%H%j$K(B 
hyphen.cfg $B$rMQ0U$7$F!"ITMQ0U$KB>$N%O%$%U%s%Q%?!<%s$rFI$_9~$^$J$$$h$&(B
$B$KBP:v$r;\$7$F$"$j$^$9!#(B

$B$3$N(B hyphen.cfg $B$rB>$NL>A0(B (phyphen.cfg $B$J$I(B) $B$KJQ99$7$F!"B>$N(B 
hyphen.cfg $B$r;H$&$J$I$H$7$FI8=`0J30$N%O%$%U%s%Q%?!<%s$rFI$_9~$s$@>l9g!"(B
$B4A;z%3!<%I$H0lCW$7$?$H$-$O$=$N$^$^4A;z%3!<%I$HG'<1$7!"4A;z%3!<%I$H0lCW(B
$B$7$J$$>l9g$O%(%i!<$H$J$k>l9g$,$"$j$^$9!#Nc$($P(B cmcyralt $B%Q%C%1!<%8$G$O!"(B
$BESCf$G$D$.$N$h$&$J%(%i!<$K$J$j$^$9!#(B

====
(/prj/ptex-cd/share/texmf/tex/latex/contrib/other/cmcyralt/rhy
phen.tex Russian hyphenation
! Bad \patterns.
l.107  . $B$((B
           2
?
====

$B$3$N$H$-$O!"!H(B?$B!I$N%W%m%s%W%H$KBP$7$F!H(Bx$B!I$G=*N;$7$F$/$@$5$$!#;DG0$J$,(B
$B$i!"$3$N%O%$%U%s%Q%?!<%s$O(B pTeX $B$G$OMxMQ$G$-$^$;$s!#(B


[babel $B%Q%C%1!<%8$rMxMQ$9$k>l9g(B]

SJIS $B$N(B pTeX $B$G%U%i%s%98l$N%O%$%U%s%Q%?!<%s$rMxMQ$9$k$H!"%U%)!<%^%C%H(B
$B%U%!%$%k:n@.;~$K>e=R$N$h$&$J%(%i!<$,5/$3$k$3$H$,J,$+$C$F$$$^$9!#$d$O$j!"(B
8 $B%S%C%H%3!<%I$NO"B3$,(B 16 $B%S%C%H%3!<%I$H8mG'$5$l$F$7$^$&$?$a$G$9!#(B

$B$=$l$G$b!"(Bbabel $B%Q%C%1!<%8$r(B pLaTeX $B$GMxMQ$9$k:]$O!"$^$:(B 
$TEXMF/tex/platex/base/ $B$N(B hyphen.cfg $B$rB>$N(B phyphen.cfg $B$J$I$NL>A0$K(B
$BJQ$($F!"(Bbabel $B%Q%C%1!<%8$N(B hyphen.cfg $B$,;H$o$l$k$h$&$K$7$F$*$$$F$/$@$5(B
$B$$!#$=$N8e$O!"(Bbabel $B%Q%C%1!<%8$N(B install.txt $B$N5-=R$K=>$C$F!"%$%s%9%H!<(B
$B%k:n6H$r9T$C$F$/$@$5$$!#(B

$B%$%s%9%H!<%k:n6HCf$K!"(B8 $B%S%C%H%3!<%I$NJB$S$r(B 16 $B%S%C%H%3!<%I$H8mG'$7$F!"(B
$BESCf$G!">e=R$N$h$&$J%(%i!<$K$J$k$3$H$,$"$k$+$b$7$l$^$;$s!#(B

$B$3$N$H$-$O!"!H(B?$B!I$N%W%m%s%W%H$KBP$7$F!H(Bx$B!I$G=*N;$7$F$/$@$5$$!#;DG0$J$,(B
$B$i!"$3$N%O%$%U%)%M!<%7%g%s%Q%?!<%s$O(B pTeX $B$G$OMxMQ$G$-$^$;$s!#(B

language.dat $B$+$i%(%i!<$N=P$?%O%$%U%s%Q%?!<%s$r:o=|$7$F!"%(%i!<$N$G$J(B
$B$$%O%$%U%)%M!<%7%g%s%Q%?!<%s$@$1$rA*Br$7$F$+$i!"$b$&0lEY%U%)!<%^%C%H%U%!(B
$B%$%k$r:n$jD>$7$F$/$@$5$$!#(B

$B%U%)!<%^%C%H%U%!%$%k$,@5>o$K:n$i$l$F$b!"(B8 $B%S%C%H%3!<%I$NO"B3$,4A;z%3!<(B
$B%I$HG'<1$5$l$?$j!"%(%i!<$,=P$k$J$I$N;w$?8=>]$,!"(BLaTeX $B%=!<%9$r=hM}$9$k(B
$B:]$K5/$3$k2DG=@-$b$"$j$^$9!#(B

==
$BIY3_(B $B=(><(B <hideak-t at ascii.co.jp>
