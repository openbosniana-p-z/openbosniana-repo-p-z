(COMMENT
 tmin10 Propaty List File (Tate kumi)
               by Hisato Hamano at ascii Co.
)
(COMMENT THIS IS A KANJI FORMAT FILE)
(DIRECTION TATE)
(FAMILY MINCHO)
(FACE F MRR)
(CODINGSCHEME JIS X0208)
(DESIGNSIZE R 10.0)
(COMMENT DESIGNSIZE IS IN POINTS)
(COMMENT OTHER SIZES ARE MULTIPLES OF DESIGNSIZE)
(CHECKSUM O 35147750366)
(SEVENBITSAFEFLAG TRUE)
(FONTDIMEN
   (SLANT R 0.0)
   (SPACE R 0.0)
   (STRETCH R 0.091641)
   (SHRINK R 0.0)
   (XHEIGHT R 0.916443)
   (QUAD R 0.962216)
   (EXTRASPACE R 0.229101)
   (EXTRASTRETCH R 0.183283)
   (EXTRASHRINK R 0.114551)
   )
(GLUEKERN
   (LABEL D 0)
   (GLUE D 1 R 0.0      R 0.0      R 0.0     )
   (GLUE D 2 R 0.0      R 0.0      R 0.0     )
   (GLUE D 3 R 0.107391 R 0.0      R 0.107391)
   (GLUE D 5 R 0.0      R 0.0      R 0.0     )
   (GLUE D 6 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 7 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 8 R 0.0      R 0.0      R 0.0     )
   (STOP)
   (LABEL D 1)
   (GLUE D 0 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 1 R 0.0      R 0.0      R 0.0     )
   (GLUE D 2 R 0.0      R 0.0      R 0.0     )
   (GLUE D 3 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 4 R 0.0      R 0.0      R 0.0     )
   (GLUE D 5 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 6 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 7 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 8 R 0.0      R 0.0      R 0.0     )
   (STOP)
   (LABEL D 2)
   (GLUE D 0 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 1 R 0.0      R 0.0      R 0.0     )
   (GLUE D 2 R 0.0      R 0.0      R 0.0     )
   (GLUE D 3 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 4 R 0.0      R 0.0      R 0.0     )
   (GLUE D 5 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 6 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 7 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 8 R 0.0      R 0.0      R 0.0     )
   (STOP)
   (LABEL D 3)
   (GLUE D 0 R 0.107391 R 0.0      R 0.107391)
   (GLUE D 1 R 0.0      R 0.0      R 0.0     )
   (GLUE D 2 R 0.0      R 0.0      R 0.0     )
   (GLUE D 3 R 0.107391 R 0.0      R 0.107391)
   (GLUE D 5 R 0.0      R 0.0      R 0.0     )
   (GLUE D 6 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 7 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 8 R 0.0      R 0.0      R 0.0     )
   (STOP)
   (LABEL D 4)
   (GLUE D 0 R 0.962216 R 0.0      R 0.481108)
   (GLUE D 1 R 0.0      R 0.0      R 0.0     )
   (GLUE D 2 R 0.0      R 0.0      R 0.0     )
   (GLUE D 3 R 0.962216 R 0.0      R 0.481108)
   (GLUE D 5 R 0.0      R 0.0      R 0.0     )
   (GLUE D 6 R 0.962216 R 0.0      R 0.481108)
   (GLUE D 7 R 0.962216 R 0.0      R 0.481108)
   (GLUE D 8 R 0.0      R 0.0      R 0.0     )
   (STOP)
   (LABEL D 5)
   (GLUE D 0 R 0.0      R 0.0      R 0.0     )
   (GLUE D 1 R 0.0      R 0.0      R 0.0     )
   (GLUE D 2 R 0.0      R 0.0      R 0.0     )
   (GLUE D 3 R 0.0      R 0.0      R 0.0     )
   (GLUE D 4 R 0.0      R 0.0      R 0.0     )
   (GLUE D 5 R 0.0      R 0.0      R 0.0     )
   (GLUE D 6 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 7 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 8 R 0.0      R 0.0      R 0.0     )
   (STOP)
   (LABEL D 6)
   (GLUE D 0 R 0.0      R 0.0      R 0.0     )
   (GLUE D 1 R 0.0      R 0.0      R 0.0     )
   (GLUE D 2 R 0.0      R 0.0      R 0.0     )
   (GLUE D 3 R 0.0      R 0.0      R 0.0     )
   (GLUE D 4 R 0.0      R 0.0      R 0.0     )
   (GLUE D 5 R 0.0      R 0.0      R 0.0     )
   (GLUE D 6 R 0.0      R 0.0      R 0.0     )
   (GLUE D 7 R 0.240554 R 0.0      R 0.240554)
   (GLUE D 8 R 0.0      R 0.0      R 0.0     )
   (STOP)
   (LABEL D 7)
   (GLUE D 0 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 1 R 0.240554 R 0.0      R 0.240554)
   (GLUE D 2 R 0.240554 R 0.0      R 0.240554)
   (GLUE D 3 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 4 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 5 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 6 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 7 R 0.0      R 0.183283 R 0.0     )
   (GLUE D 8 R 0.240554 R 0.0      R 0.240554)
   (STOP)
   (LABEL D 8)
   (GLUE D 0 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 1 R 0.0      R 0.0      R 0.0     )
   (GLUE D 2 R 0.0      R 0.0      R 0.0     )
   (GLUE D 3 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 4 R 0.0      R 0.0      R 0.0     )
   (GLUE D 5 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 6 R 0.481108 R 0.183283 R 0.481108)
   (GLUE D 7 R 0.240554 R 0.183283 R 0.240554)
   (GLUE D 8 R 0.0      R 0.0      R 0.0     )
   (STOP)
   )
(CHARSINTYPE D 1
   $B!$(B $B!%(B 
   )
(CHARSINTYPE D 2
   $B!"(B $B!#(B 
   )
(CHARSINTYPE D 3
   $B!3(B $B!4(B $B!5(B $B!6(B $B!7(B $B!9(B
   $B$!(B $B$#(B $B$%(B $B$'(B $B$)(B $B$C(B $B$c(B $B$e(B $B$g(B $B$n(B
   $B%!(B $B%#(B $B%%(B $B%'(B $B%)(B $B%C(B $B%c(B $B%e(B $B%g(B $B%n(B $B%u(B $B%v(B 
   )
(CHARSINTYPE D 4
   $B!)(B $B!*(B 
   )
(CHARSINTYPE D 5
   $B!=(B $B!D(B $B!E(B 
   )
(CHARSINTYPE D 6
   $B!F(B $B!H(B $B!J(B $B!L(B $B!N(B $B!P(B $B!R(B $B!T(B $B!V(B $B!X(B $B!Z(B 
   )
(CHARSINTYPE D 7
   $B!&(B $B!>(B $B!B(B $B!C(B 
   )
(CHARSINTYPE D 8
   $B!G(B $B!I(B $B!K(B $B!M(B $B!O(B $B!Q(B $B!S(B $B!U(B $B!W(B $B!Y(B $B![(B 
   )
(TYPE D 0
   (COMMENT						$BIaDL$N4A;z(B
      )
   (CHARWD R 0.962216)
   (CHARHT R 0.458221)
   (CHARDP R 0.458221)
   (COMMENT
      (GLUE D 1 R 0.0      R 0.0      R 0.0     )	$B!$!%(B
      (GLUE D 2 R 0.0      R 0.0      R 0.0     )	$B!"!#(B
      (GLUE D 3 R 0.107391 R 0.0      R 0.107391)	$B>.$+$J(B
      (GLUE D 5 R 0.0      R 0.0      R 0.0     )	$BA43QLsJ*(B
      (GLUE D 6 R 0.481108 R 0.183283 R 0.481108)	$B%+%C%33+$-(B
      (GLUE D 7 R 0.240554 R 0.183283 R 0.240554)	$BCf%D%-LsJ*(B
      (GLUE D 8 R 0.0      R 0.0      R 0.0     )	$B%+%C%3JD$8(B
      )
   )
(TYPE D 1
   (COMMENT					$B!$!%(B
      (CHARSINTYPE D 1
         $B!$(B $B!%(B 
         )
      )
   (CHARWD R 0.481108)
   (CHARHT R 0.458221)
   (CHARDP R 0.458221)
   (COMMENT
      (GLUE D 0 R 0.481108 R 0.183283 R 0.481108)	$B4A;z(B
      (GLUE D 1 R 0.0      R 0.0      R 0.0     )	$B!$!%(B
      (GLUE D 2 R 0.0      R 0.0      R 0.0     )	$B!"!#(B
      (GLUE D 3 R 0.481108 R 0.183283 R 0.481108)	$B>.%+%J(B
      (GLUE D 4 R 0.0      R 0.0      R 0.0     )	$B!)!*(B
      (GLUE D 5 R 0.481108 R 0.183283 R 0.481108)	$BA43QLsJ*(B
      (GLUE D 6 R 0.481108 R 0.183283 R 0.481108)	$B%+%C%33+$-(B
      (GLUE D 7 R 0.481108 R 0.183283 R 0.481108)	$BCf%D%-LsJ*(B
      (GLUE D 8 R 0.0      R 0.0      R 0.0     )	$B%+%C%3JD$8(B
      )
   )
(TYPE D 2
   (COMMENT					$B!"!#(B
      (CHARSINTYPE D 2
         $B!"(B $B!#(B 
         )
      )
   (CHARWD R 0.481108)
   (CHARHT R 0.458221)
   (CHARDP R 0.458221)
   (COMMENT
      (GLUE D 0 R 0.481108 R 0.183283 R 0.481108)	$B4A;z(B
      (GLUE D 1 R 0.0      R 0.0      R 0.0     )	$B!$!%(B
      (GLUE D 2 R 0.0      R 0.0      R 0.0     )	$B!"!#(B
      (GLUE D 3 R 0.481108 R 0.183283 R 0.481108)	$B>.%+%J(B
      (GLUE D 4 R 0.0      R 0.0      R 0.0     )	$B!)!*(B
      (GLUE D 5 R 0.481108 R 0.183283 R 0.481108)	$BA43QLsJ*(B
      (GLUE D 6 R 0.481108 R 0.183283 R 0.481108)	$B%+%C%33+$-(B
      (GLUE D 7 R 0.481108 R 0.183283 R 0.481108)	$BCf%D%-LsJ*(B
      (GLUE D 8 R 0.0      R 0.0      R 0.0     )	$B%+%C%3JD$8(B
      )
   )
(TYPE D 3
   (COMMENT						$B>.$+$J(B
      (CHARSINTYPE D 3
         $B!3(B $B!4(B $B!5(B $B!6(B $B!7(B $B!9(B
         $B$!(B $B$#(B $B$%(B $B$'(B $B$)(B $B$C(B $B$c(B $B$e(B $B$g(B $B$n(B
         $B%!(B $B%#(B $B%%(B $B%'(B $B%)(B $B%C(B $B%c(B $B%e(B $B%g(B $B%n(B $B%u(B $B%v(B 
         )
      )
   (CHARWD R 0.747434)
   (CHARHT R 0.458221)
   (CHARDP R 0.458221)
   (COMMENT
      (GLUE D 0 R 0.107391 R 0.0      R 0.107391)	$B4A;z(B
      (GLUE D 1 R 0.0      R 0.0      R 0.0     )	$B!$!%(B
      (GLUE D 2 R 0.0      R 0.0      R 0.0     )	$B!"!#(B
      (GLUE D 3 R 0.107391 R 0.0      R 0.107391)	$B>.$+$J(B
      (GLUE D 5 R 0.0      R 0.0      R 0.0     )	$BA43QLsJ*(B
      (GLUE D 6 R 0.481108 R 0.183283 R 0.481108)	$B%+%C%33+$-(B
      (GLUE D 7 R 0.240554 R 0.183283 R 0.240554)	$BCf%D%-LsJ*(B
      (GLUE D 8 R 0.0      R 0.0      R 0.0     )	$B%+%C%3JD$8(B
      )
   )
(TYPE D 4
   (COMMENT						$B!*!)(B
      (CHARSINTYPE D 4
         $B!)(B $B!*(B 
         )
      )
   (CHARWD R 0.962216)
   (CHARHT R 0.458221)
   (CHARDP R 0.458221)
   (COMMENT
      (GLUE D 0 R 0.962216 R 0.0      R 0.481108)	$B4A;z(B
      (GLUE D 1 R 0.0      R 0.0      R 0.0     )	$B!$!%(B
      (GLUE D 2 R 0.0      R 0.0      R 0.0     )	$B!"!#(B
      (GLUE D 3 R 0.962216 R 0.0      R 0.481108)	$B>.$+$J(B
      (GLUE D 5 R 0.0      R 0.0      R 0.0     )	$BA43QLsJ*(B
      (GLUE D 6 R 0.962216 R 0.0      R 0.481108)	$B%+%C%33+$-(B
      (GLUE D 7 R 0.962216 R 0.0      R 0.481108)	$BCf%D%-LsJ*(B
      (GLUE D 8 R 0.0      R 0.0      R 0.0     )	$B%+%C%3JD$8(B
      )
   )
(TYPE D 5
   (COMMENT						$BA43QLsJ*(B
      (CHARSINTYPE D 5
         $B!=(B $B!D(B $B!E(B 
         )
      )
   (CHARWD R 0.962216)
   (CHARHT R 0.458221)
   (CHARDP R 0.458221)
   (COMMENT
      (GLUE D 0 R 0.0      R 0.0      R 0.0     )	$B4A;z(B
      (GLUE D 1 R 0.0      R 0.0      R 0.0     )	$B!$!%(B
      (GLUE D 2 R 0.0      R 0.0      R 0.0     )	$B!"!#(B
      (GLUE D 3 R 0.0      R 0.0      R 0.0     )	$B>.$+$J(B
      (GLUE D 4 R 0.0      R 0.0      R 0.0     )	$B!*!)(B
      (GLUE D 5 R 0.0      R 0.0      R 0.0     )	$BA43QLsJ*(B
      (GLUE D 6 R 0.240554 R 0.183283 R 0.240554)	$B%+%C%33+$-(B
      (GLUE D 7 R 0.240554 R 0.183283 R 0.240554)	$BCf%D%-LsJ*(B
      (GLUE D 8 R 0.0      R 0.0      R 0.0     )	$B%+%C%3JD$8(B
      )
   )
(TYPE D 6
   (COMMENT					$B%+%C%33+$-(B
      (CHARSINTYPE D 6
         $B!F(B $B!H(B $B!J(B $B!L(B $B!N(B $B!P(B $B!R(B $B!T(B $B!V(B $B!X(B $B!Z(B 
         )
      )
   (CHARWD R 0.481108)
   (CHARHT R 0.458221)
   (CHARDP R 0.458221)
   (COMMENT
      (GLUE D 0 R 0.0      R 0.0      R 0.0     )	$B4A;z(B
      (GLUE D 1 R 0.0      R 0.0      R 0.0     )	$B!$!%(B
      (GLUE D 2 R 0.0      R 0.0      R 0.0     )	$B!"!#(B
      (GLUE D 3 R 0.0      R 0.0      R 0.0     )	$B>.$+$J(B
      (GLUE D 4 R 0.0      R 0.0      R 0.0     )	$B!*!)(B
      (GLUE D 5 R 0.0      R 0.0      R 0.0     )	$BA43QLsJ*(B
      (GLUE D 6 R 0.0      R 0.0      R 0.0     )	$B%+%C%33+$-(B
      (GLUE D 7 R 0.240554 R 0.0      R 0.240554)	$BCf%D%-LsJ*(B
      (GLUE D 8 R 0.0      R 0.0      R 0.0     )	$B%+%C%3JD$8(B
      )
   )
(TYPE D 7
   (COMMENT					$BCf%D%-LsJ*(B
      (CHARSINTYPE D 7
         $B!&(B $B!>(B $B!B(B $B!C(B 
         )
      )
   (CHARWD R 0.481108)
   (CHARHT R 0.458221)
   (CHARDP R 0.458221)
   (COMMENT
      (GLUE D 0 R 0.240554 R 0.183283 R 0.240554)	$B4A;z(B
      (GLUE D 1 R 0.240554 R 0.0      R 0.240554)	$B!$!%(B
      (GLUE D 2 R 0.240554 R 0.0      R 0.240554)	$B!"!#(B
      (GLUE D 3 R 0.240554 R 0.183283 R 0.240554)	$B>.%+%J(B
      (GLUE D 4 R 0.240554 R 0.183283 R 0.240554)	$B!)!*(B
      (GLUE D 5 R 0.240554 R 0.183283 R 0.240554)	$BA43QLsJ*(B
      (GLUE D 6 R 0.240554 R 0.183283 R 0.240554)	$B%+%C%33+$-(B
      (GLUE D 7 R 0.0      R 0.183283 R 0.0     )	$BCf%D%-LsJ*(B
      (GLUE D 8 R 0.240554 R 0.0      R 0.240554)	$B%+%C%3JD$8(B
      )
   )
(TYPE D 8
   (COMMENT					$B%+%C%3JD$8(B
      (CHARSINTYPE D 8
         $B!G(B $B!I(B $B!K(B $B!M(B $B!O(B $B!Q(B $B!S(B $B!U(B $B!W(B $B!Y(B $B![(B 
         )
      )
   (CHARWD R 0.481108)
   (CHARHT R 0.458221)
   (CHARDP R 0.458221)
   (COMMENT
      (GLUE D 0 R 0.481108 R 0.183283 R 0.481108)	$B4A;z(B
      (GLUE D 1 R 0.0      R 0.0      R 0.0     )	$B!$!%(B
      (GLUE D 2 R 0.0      R 0.0      R 0.0     )	$B!"!#(B
      (GLUE D 3 R 0.481108 R 0.183283 R 0.481108)	$B>.%+%J(B
      (GLUE D 4 R 0.0      R 0.0      R 0.0     )	$B!)!*(B
      (GLUE D 5 R 0.240554 R 0.183283 R 0.240554)	$BA43QLsJ*(B
      (GLUE D 6 R 0.481108 R 0.183283 R 0.481108)	$B%+%C%33+$-(B
      (GLUE D 7 R 0.240554 R 0.183283 R 0.240554)	$BCf%D%-LsJ*(B
      (GLUE D 8 R 0.0      R 0.0      R 0.0     )	$B%+%C%3JD$8(B
      )
   )
