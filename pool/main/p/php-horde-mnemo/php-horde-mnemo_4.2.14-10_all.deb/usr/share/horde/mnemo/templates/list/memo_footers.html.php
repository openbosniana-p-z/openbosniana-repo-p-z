</tbody>
</table>
<div id="notes_empty">
 <?php echo _("No notes match") ?>
</div>
