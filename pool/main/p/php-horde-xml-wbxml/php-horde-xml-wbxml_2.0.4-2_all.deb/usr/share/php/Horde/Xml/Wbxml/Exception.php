<?php
/**
 * Base exception class for Horde_Xml_Wbxml.
 *
 * Copyright 2010-2017 Horde LLC (http://www.horde.org/)
 *
 * See the enclosed file COPYING for license information (GPL). If you
 * did not receive this file, see http://www.horde.org/licenses/gpl.
 *
 * @author   Your name <you@example.com>
 * @category Horde
 * @license  http://www.horde.org/licenses/gpl GPL
 * @package  Xml_Wbxml
 */
class Horde_Xml_Wbxml_Exception extends Horde_Exception_Wrapped
{
}
