===
GIL
===

Geometry Interaction Library for Pure Data / GEM.


Description
-----------

GIL is a set of Pure Data abstractions, aiming at the interaction of geometric objects or mouse cursor inside GEM.
It does not depend on any external libraries except GEM.

See gil_EXAMPLE.pd for a little example patch.

This library is still work in progress.

For questions or bug reports, contact me:
mail@marianweger.com

Download
--------

https://github.com/m---w/gil


Copyright/License
-----------------

Copyright (C) 2011-2012  Marian Weger

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
