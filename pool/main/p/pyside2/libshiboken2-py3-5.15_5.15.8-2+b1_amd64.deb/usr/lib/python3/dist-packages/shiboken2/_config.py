shiboken_library_soversion = str(5.15)

version = "5.15.8"
version_info = (5, 15, 8, "", "")

__build_date__ = '2023-01-15T15:12:32+00:00'




__setup_py_package_version__ = '5.15.8'
