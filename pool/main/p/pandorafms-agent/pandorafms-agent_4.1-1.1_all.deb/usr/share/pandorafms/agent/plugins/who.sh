#!/bin/sh

echo "<module>";
echo "<name>who</name>";
echo "<type>generic_data_string</type>";
echo "<data><![CDATA["
who
echo "]]></data>"
echo "</module>"

