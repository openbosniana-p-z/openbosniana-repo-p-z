<?php

require_once 'TijsVerkoyen/CssToInlineStyles/autoload.php';

use TijsVerkoyen\CssToInlineStyles\CssToInlineStyles;

// create instance
$cssToInlineStyles = new CssToInlineStyles();

$html = file_get_contents(__DIR__ . '/sumo/index.htm');
$css = file_get_contents(__DIR__ . '/sumo/style.css');

// output
echo $cssToInlineStyles->convert(
    $html,
    $css
);
