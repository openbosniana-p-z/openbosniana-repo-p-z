var searchData=
[
  ['nsockaddr_0',['nsockaddr',['../classpsocksxx_1_1nsockaddr.html#acbb1578eb2aad79790d3f93456a74087',1,'psocksxx::nsockaddr::nsockaddr(const char *node, unsigned short port)'],['../classpsocksxx_1_1nsockaddr.html#aa815e01daccf47de630cd8d6908904ea',1,'psocksxx::nsockaddr::nsockaddr(unsigned short port)'],['../classpsocksxx_1_1nsockaddr.html#a95214f67b4df18b9b582ffa935949267',1,'psocksxx::nsockaddr::nsockaddr(const char *node, const char *service)']]],
  ['nsockstream_1',['nsockstream',['../classpsocksxx_1_1nsockstream.html#a6e1055ed54349147e122a03589c4b69b',1,'psocksxx::nsockstream::nsockstream(sockstreambuf::socket_type_t type, sockstreambuf::socket_protocol_t proto)'],['../classpsocksxx_1_1nsockstream.html#a0e09af89664bf5bf8bf6049ce4fe0703',1,'psocksxx::nsockstream::nsockstream(sockstreambuf *ssb)']]]
];
