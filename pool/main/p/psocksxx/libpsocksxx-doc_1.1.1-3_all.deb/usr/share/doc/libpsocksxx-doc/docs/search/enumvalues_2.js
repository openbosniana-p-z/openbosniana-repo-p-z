var searchData=
[
  ['ipproto_5ficmp_0',['ipproto_icmp',['../classpsocksxx_1_1sockstreambuf.html#a15868c6e1f9f685a15822c2c7d5fc85aa27c79ee7ba08de1ae58d6cc14401cf13',1,'psocksxx::sockstreambuf']]],
  ['ipproto_5fip_1',['ipproto_ip',['../classpsocksxx_1_1sockstreambuf.html#a15868c6e1f9f685a15822c2c7d5fc85aa186227bc26b29142cadcb69ffc2a1c8c',1,'psocksxx::sockstreambuf']]],
  ['ipproto_5fipv6_2',['ipproto_ipv6',['../classpsocksxx_1_1sockstreambuf.html#a15868c6e1f9f685a15822c2c7d5fc85aa138323a62e4760e36063523a79305ee5',1,'psocksxx::sockstreambuf']]],
  ['ipproto_5fraw_3',['ipproto_raw',['../classpsocksxx_1_1sockstreambuf.html#a15868c6e1f9f685a15822c2c7d5fc85aaf3f6a597cbd1c04ae88ec217e5a95319',1,'psocksxx::sockstreambuf']]],
  ['ipproto_5ftcp_4',['ipproto_tcp',['../classpsocksxx_1_1sockstreambuf.html#a15868c6e1f9f685a15822c2c7d5fc85aa33312689adb97abc323d357160eeeb34',1,'psocksxx::sockstreambuf']]],
  ['ipproto_5fudp_5',['ipproto_udp',['../classpsocksxx_1_1sockstreambuf.html#a15868c6e1f9f685a15822c2c7d5fc85aae73ff640af18fcd62645548ce9a66888',1,'psocksxx::sockstreambuf']]]
];
