var indexSectionsWithContent =
{
  0: "_abcefilnoprstuw~",
  1: "ilnostu",
  2: "abcfilnoprstuw~",
  3: "_",
  4: "s",
  5: "aes",
  6: "aeip",
  7: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Enumerations",
  6: "Enumerator",
  7: "Pages"
};

