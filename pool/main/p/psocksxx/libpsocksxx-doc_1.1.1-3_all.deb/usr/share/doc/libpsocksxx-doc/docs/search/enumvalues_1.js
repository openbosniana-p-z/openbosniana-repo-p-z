var searchData=
[
  ['eof_0',['eof',['../classpsocksxx_1_1sockstreambuf.html#a114b38d28cd2689f359ba9c323372537a4a7364678ee412fc9e2a6f1c855954c3',1,'psocksxx::sockstreambuf']]]
];
