var searchData=
[
  ['socket_5fdomain_5ft_0',['socket_domain_t',['../classpsocksxx_1_1sockstreambuf.html#a6393fdbc047b847f3248572341ae7a92',1,'psocksxx::sockstreambuf']]],
  ['socket_5fprotocol_5ft_1',['socket_protocol_t',['../classpsocksxx_1_1sockstreambuf.html#a15868c6e1f9f685a15822c2c7d5fc85a',1,'psocksxx::sockstreambuf']]],
  ['socket_5ftype_5ft_2',['socket_type_t',['../classpsocksxx_1_1sockstreambuf.html#a9c4ff74d3a6f8739dcaa5e50b225abd0',1,'psocksxx::sockstreambuf']]]
];
