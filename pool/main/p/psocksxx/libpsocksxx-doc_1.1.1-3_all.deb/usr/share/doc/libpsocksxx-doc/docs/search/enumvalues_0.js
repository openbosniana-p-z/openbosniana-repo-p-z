var searchData=
[
  ['af_5finet_0',['af_inet',['../classpsocksxx_1_1sockaddr.html#ae6a936e60988ce97bc3358cbaa5903e3a0c619382e7f363cb3612dc77d816b72c',1,'psocksxx::sockaddr']]],
  ['af_5flocal_1',['af_local',['../classpsocksxx_1_1sockaddr.html#ae6a936e60988ce97bc3358cbaa5903e3abe4d720293b8244722d02bdab69e21c8',1,'psocksxx::sockaddr']]]
];
