var searchData=
[
  ['ready_0',['ready',['../classpsocksxx_1_1sockstreambuf.html#abd24b2be82d9066e654474f8983a3e7b',1,'psocksxx::sockstreambuf']]],
  ['resolve_5fnode_1',['resolve_node',['../classpsocksxx_1_1nsockaddr.html#a099eefb66b7f8b76693a27bfd7313574',1,'psocksxx::nsockaddr']]]
];
