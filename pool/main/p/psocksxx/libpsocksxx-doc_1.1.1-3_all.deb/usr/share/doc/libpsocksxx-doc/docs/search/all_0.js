var searchData=
[
  ['_5ferrno_0',['_errno',['../classpsocksxx_1_1sockexception.html#a4d3b260a62a9a9ada6b20ec1855767d5',1,'psocksxx::sockexception']]],
  ['_5fmessage_1',['_message',['../classpsocksxx_1_1sockexception.html#a7ebe2f319b6eb8b33e2a59ed54b55c49',1,'psocksxx::sockexception']]],
  ['_5fsys_5fmsg_2',['_sys_msg',['../classpsocksxx_1_1sockexception.html#a68ea3b9fda4da59501a659d964a75579',1,'psocksxx::sockexception']]]
];
