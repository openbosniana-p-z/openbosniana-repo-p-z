var searchData=
[
  ['socket_5ft_0',['socket_t',['../classpsocksxx_1_1sockstreambuf.html#a6f0e8626eaaebe711b45b36d7fdedc11',1,'psocksxx::sockstreambuf']]]
];
