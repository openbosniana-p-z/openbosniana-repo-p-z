var searchData=
[
  ['eof_5ft_0',['eof_t',['../classpsocksxx_1_1sockstreambuf.html#a114b38d28cd2689f359ba9c323372537',1,'psocksxx::sockstreambuf']]]
];
