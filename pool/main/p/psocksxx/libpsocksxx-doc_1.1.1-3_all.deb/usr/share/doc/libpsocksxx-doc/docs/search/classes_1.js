var searchData=
[
  ['lsockaddr_0',['lsockaddr',['../classpsocksxx_1_1lsockaddr.html',1,'psocksxx']]],
  ['lsockstream_1',['lsockstream',['../classpsocksxx_1_1lsockstream.html',1,'psocksxx']]]
];
