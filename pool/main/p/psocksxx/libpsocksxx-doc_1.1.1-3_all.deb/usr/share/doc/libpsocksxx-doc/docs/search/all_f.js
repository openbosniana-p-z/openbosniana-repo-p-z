var searchData=
[
  ['what_0',['what',['../classpsocksxx_1_1sockexception.html#a2b18403a9a6a0caf5a220dbddc4d7ecb',1,'psocksxx::sockexception']]]
];
