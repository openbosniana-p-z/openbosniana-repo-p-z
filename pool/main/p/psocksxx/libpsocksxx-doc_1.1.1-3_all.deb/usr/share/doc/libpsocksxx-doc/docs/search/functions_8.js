var searchData=
[
  ['psockaddr_0',['psockaddr',['../classpsocksxx_1_1lsockaddr.html#acd19e3a5c83760f40552d9dc8f8595dd',1,'psocksxx::lsockaddr::psockaddr()'],['../classpsocksxx_1_1nsockaddr.html#a83925905e4c2c96f90508bd1d495aef0',1,'psocksxx::nsockaddr::psockaddr()'],['../classpsocksxx_1_1sockaddr.html#a05673ad7d9a0f306ef9b1d4a8959e877',1,'psocksxx::sockaddr::psockaddr()']]]
];
