/* include/psiconfig.h.  Generated from psiconfig.h.in by configure.  */

#ifndef _psi_include_psiconfig_h
#define _psi_include_psiconfig_h

/* Define if you have <stdint.h>.  */
#define HAVE_STDINT_H 1

/* Which integrals standard is used? */
#define PSI_INTEGRALS_STANDARD 1

#endif /* _psi_src_psiconfig_h */

