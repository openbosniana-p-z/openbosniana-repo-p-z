<?php
	/**
	* Romanian language file.
	*/

	//Basic
	$plugin_lang['strplugindescription'] = 'Report plugin';
	$plugin_lang['strnoreportsdb'] = 'Nu aţi creat baza de date pentru rapoarte. Citiţi fişierul INSTALL pentru instrucţiuni.';

	// Reports
	$plugin_lang['strreport'] = 'Raport';
	$plugin_lang['strreports'] = 'Rapoarte';
	$plugin_lang['strshowallreports'] = 'Afişare toate rapoartele';
	$plugin_lang['strnoreports'] = 'Nici un raport găsit.';
	$plugin_lang['strcreatereport'] = 'Creare raport';
	$plugin_lang['strreportdropped'] = 'Report dropped.';
	$plugin_lang['strreportdroppedbad'] = 'Ştergere raport eşuată.';
	$plugin_lang['strconfdropreport'] = 'Sigur ştergeţi raportul "%s"?';
	$plugin_lang['strreportneedsname'] = 'Specificaţi un nume pentru raport.';
	$plugin_lang['strreportneedsdef'] = 'Specificaţi o instrucţiune SQL pentru raport.';
	$plugin_lang['strreportcreated'] = 'Raport salvat.';
	$plugin_lang['strreportcreatedbad'] = 'Salvare raport eşuată.';
?>
