# these variables are set from within bin/@appname@.py.in

APP_ID = 'org.gabmus.giara'
PROFILE = 'default'
APP_NAME = 'Giara'
RESOURCE_PREFIX = '/org/gabmus/giara'
