package azblob

const serviceLibVersion = "0.15"
