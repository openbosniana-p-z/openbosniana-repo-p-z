package godo

// Meta describes generic information about a response.
type Meta struct {
	Total int `json:"total"`
}
