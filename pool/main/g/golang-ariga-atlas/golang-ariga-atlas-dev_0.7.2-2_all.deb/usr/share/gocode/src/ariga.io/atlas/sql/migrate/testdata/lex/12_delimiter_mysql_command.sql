delimiter //
create table t2 (a int) //

delimiter ;
delimiter //

create table t3 (a int) //
delimiter ;

show tables;
drop table t2, t3;
