


-- migrate:up




CREATE TABLE tbl_2 (col INT);