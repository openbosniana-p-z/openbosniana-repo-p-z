CREATE TABLE tbl
(
    col INT
);