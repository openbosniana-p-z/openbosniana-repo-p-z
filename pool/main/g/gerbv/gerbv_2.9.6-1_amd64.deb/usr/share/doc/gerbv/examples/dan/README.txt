# $Id$

This file is from Dan McMahill. This file uses rectangular apertures 
to draw lines which is now supported since release 0.0.9.


top_sr.gbx is the same thing but with a "SR" (step and repeat)
line added near the top.

