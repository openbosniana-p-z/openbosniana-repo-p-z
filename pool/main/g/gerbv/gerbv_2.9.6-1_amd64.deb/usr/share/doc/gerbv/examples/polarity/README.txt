This example is submitted by Richard Lightman and demonstrates 
a combination of image polarity and layer polarity that caused
errors.

$Id$