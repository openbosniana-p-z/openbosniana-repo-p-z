This is an example on a gerber file (with a postscript version as reference) 
with kind permission from Neil Darlow (neil at darlow dot co dot uk) to 
illustrate problems with broken multi quadrant arcs discovered in 0.0.7.

$Id$