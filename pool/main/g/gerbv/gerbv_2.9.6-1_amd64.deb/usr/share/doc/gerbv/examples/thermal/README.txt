A file used to test aperture macro number 7.
Sent to spe by Drew Moore.

$Id$
