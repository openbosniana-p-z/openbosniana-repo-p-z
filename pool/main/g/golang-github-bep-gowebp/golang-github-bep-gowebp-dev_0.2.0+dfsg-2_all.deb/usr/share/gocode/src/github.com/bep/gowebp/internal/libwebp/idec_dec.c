#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/dec/idec_dec.c"
#endif
