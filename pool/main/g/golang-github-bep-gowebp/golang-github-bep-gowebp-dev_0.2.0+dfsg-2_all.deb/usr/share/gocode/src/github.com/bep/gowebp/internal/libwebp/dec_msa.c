#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/dsp/dec_msa.c"
#endif
