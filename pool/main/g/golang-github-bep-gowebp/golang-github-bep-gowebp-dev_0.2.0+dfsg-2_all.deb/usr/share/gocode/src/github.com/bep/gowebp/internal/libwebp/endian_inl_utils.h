#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/utils/endian_inl_utils.h"
#endif
