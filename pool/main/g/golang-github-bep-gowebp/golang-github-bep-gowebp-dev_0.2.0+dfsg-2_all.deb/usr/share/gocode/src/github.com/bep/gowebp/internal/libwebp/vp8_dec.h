#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/dec/vp8_dec.h"
#endif
