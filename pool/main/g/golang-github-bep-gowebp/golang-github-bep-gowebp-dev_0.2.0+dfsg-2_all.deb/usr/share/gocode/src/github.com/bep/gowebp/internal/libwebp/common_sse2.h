#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/dsp/common_sse2.h"
#endif
