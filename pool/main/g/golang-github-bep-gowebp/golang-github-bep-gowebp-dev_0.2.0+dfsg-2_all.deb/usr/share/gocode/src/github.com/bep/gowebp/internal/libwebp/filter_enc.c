#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/enc/filter_enc.c"
#endif
