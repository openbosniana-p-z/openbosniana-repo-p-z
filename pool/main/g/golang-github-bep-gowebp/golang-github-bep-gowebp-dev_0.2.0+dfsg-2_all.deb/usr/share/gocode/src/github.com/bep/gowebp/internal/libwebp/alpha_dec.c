#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/dec/alpha_dec.c"
#endif
