#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/dsp/lossless_enc_sse41.c"
#endif
