#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/enc/picture_rescale_enc.c"
#endif
