#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/enc/vp8i_enc.h"
#endif
