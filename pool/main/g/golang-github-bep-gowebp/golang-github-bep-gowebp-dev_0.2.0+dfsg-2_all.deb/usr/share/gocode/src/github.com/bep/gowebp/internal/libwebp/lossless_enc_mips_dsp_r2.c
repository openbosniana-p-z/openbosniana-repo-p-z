#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/dsp/lossless_enc_mips_dsp_r2.c"
#endif
