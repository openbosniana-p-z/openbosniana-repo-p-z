#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/enc/iterator_enc.c"
#endif
