#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/enc/near_lossless_enc.c"
#endif
