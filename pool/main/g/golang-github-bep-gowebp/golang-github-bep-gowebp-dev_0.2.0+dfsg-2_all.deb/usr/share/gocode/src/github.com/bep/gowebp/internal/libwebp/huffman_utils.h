#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/utils/huffman_utils.h"
#endif
