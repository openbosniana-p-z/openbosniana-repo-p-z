#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/enc/backward_references_enc.h"
#endif
