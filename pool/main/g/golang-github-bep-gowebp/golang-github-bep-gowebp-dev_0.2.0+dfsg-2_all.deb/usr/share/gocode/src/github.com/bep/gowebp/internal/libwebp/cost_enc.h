#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/enc/cost_enc.h"
#endif
