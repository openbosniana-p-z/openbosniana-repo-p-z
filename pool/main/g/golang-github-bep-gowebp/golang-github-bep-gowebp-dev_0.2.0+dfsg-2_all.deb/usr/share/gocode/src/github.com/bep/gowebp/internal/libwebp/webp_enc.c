#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/enc/webp_enc.c"
#endif
