//go:build !dev
// +build !dev

package libwebp

// #cgo linux LDFLAGS: -lm
import "C"
