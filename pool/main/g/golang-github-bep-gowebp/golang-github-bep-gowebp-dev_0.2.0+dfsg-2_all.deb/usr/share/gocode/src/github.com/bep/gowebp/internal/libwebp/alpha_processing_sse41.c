#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/dsp/alpha_processing_sse41.c"
#endif
