#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/dec/tree_dec.c"
#endif
