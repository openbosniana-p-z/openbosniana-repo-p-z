#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/sharpyuv/sharpyuv_sse2.c"
#endif
