#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/enc/frame_enc.c"
#endif
