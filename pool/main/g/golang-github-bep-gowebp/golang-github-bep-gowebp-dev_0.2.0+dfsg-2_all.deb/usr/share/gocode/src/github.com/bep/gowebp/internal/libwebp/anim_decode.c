#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/demux/anim_decode.c"
#endif
