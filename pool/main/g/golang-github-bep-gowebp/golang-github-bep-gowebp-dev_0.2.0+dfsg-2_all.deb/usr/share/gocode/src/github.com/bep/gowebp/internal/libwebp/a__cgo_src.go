//go:build !dev
// +build !dev

package libwebp

// #cgo CFLAGS: -I../../libwebp_src
import "C"
