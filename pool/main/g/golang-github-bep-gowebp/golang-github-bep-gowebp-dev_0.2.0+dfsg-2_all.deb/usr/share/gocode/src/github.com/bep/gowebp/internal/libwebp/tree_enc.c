#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/enc/tree_enc.c"
#endif
