#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/dsp/filters_mips_dsp_r2.c"
#endif
