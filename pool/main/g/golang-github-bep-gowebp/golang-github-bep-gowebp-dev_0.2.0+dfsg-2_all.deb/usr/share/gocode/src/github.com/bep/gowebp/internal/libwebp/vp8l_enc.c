#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/enc/vp8l_enc.c"
#endif
