#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/utils/thread_utils.c"
#endif
