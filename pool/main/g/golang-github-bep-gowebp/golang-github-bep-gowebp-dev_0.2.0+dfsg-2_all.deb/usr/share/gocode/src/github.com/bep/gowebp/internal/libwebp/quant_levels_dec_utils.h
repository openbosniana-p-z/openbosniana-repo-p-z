#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/utils/quant_levels_dec_utils.h"
#endif
