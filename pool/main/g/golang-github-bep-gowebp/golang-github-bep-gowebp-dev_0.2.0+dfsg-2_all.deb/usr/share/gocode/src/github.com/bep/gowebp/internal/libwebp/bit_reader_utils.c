#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/utils/bit_reader_utils.c"
#endif
