#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/mux/anim_encode.c"
#endif
