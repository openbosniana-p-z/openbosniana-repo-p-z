#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/dsp/yuv_neon.c"
#endif
