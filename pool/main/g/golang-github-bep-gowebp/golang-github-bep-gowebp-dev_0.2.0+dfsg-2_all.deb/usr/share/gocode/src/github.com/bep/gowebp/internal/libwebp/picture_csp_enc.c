#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/enc/picture_csp_enc.c"
#endif
