#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/dec/common_dec.h"
#endif
