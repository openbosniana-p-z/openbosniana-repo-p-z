#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/dec/io_dec.c"
#endif
