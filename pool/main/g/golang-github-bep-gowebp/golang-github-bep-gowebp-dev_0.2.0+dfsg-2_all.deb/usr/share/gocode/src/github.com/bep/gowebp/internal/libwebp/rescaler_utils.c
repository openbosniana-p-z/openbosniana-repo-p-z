#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/utils/rescaler_utils.c"
#endif
