#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/dec/webp_dec.c"
#endif
