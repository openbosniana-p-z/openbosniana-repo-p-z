#ifndef LIBWEBP_NO_SRC
#include "../../libwebp_src/src/enc/quant_enc.c"
#endif
