============================
gnome-shell-extensions-extra
============================

------------------------------------------------
Conglomeration package of GNOME Shell extensions
------------------------------------------------

:manual section: 7
:manual group: Progress Linux

Contents
========

| disable-workspace-switcher:
| disables the popup displayed during workspace switching
| https://github.com/jbradaric/disable-workspace-switcher

| hibernate-status:
| adds a hibernate/hybrid suspend button in status menu
| https://github.com/arelange/gnome-shell-extension-hibernate-status

| middleclickclose
| closes apps in overview with a middle click
| https://github.com/p91paul/middleclickclose

| multi-monitors-add-on:
| adds panels and thumbnails for additional monitors
| https://github.com/realh/multi-monitors-add-on

| no-overview:
| disables the switch to overview at login
| https://github.com/fthx/no-overview

| vertical-workspaces:
| changes the horizontal stacking of workspaces to vertical, but also customizes layout, content, appearance and behavior of the Shell
| https://github.com/G-dH/vertical-workspaces

Download
========

| Upstream Releases:
| https://get.progress-linux.org/packages/gnome-shell-extensions-extra/upstream

| Upstream Sources:
| https://git.progress-linux.org/software/progress-linux/gnome-shell-extensions-extra

| Debian Releases:
| https://get.progress-linux.org/packages/gnome-shell-extensions-extra/debian

| Debian Sources:
| https://git.progress-linux.org/users/daniel.baumann/debian/packages/gnome-shell-extensions-extra

Authors
=======

gnome-shell-extensions-extras were written by Daniel Baumann
<daniel.baumann@progress-linux.org> and others.
