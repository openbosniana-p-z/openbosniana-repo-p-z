This text is *emphasized*.
