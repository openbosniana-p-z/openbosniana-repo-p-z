#!/bin/bash

#Gitso is to support others.
#----------------------------------------


#Prerequisites: 
x11vnc xtightvncviewer

#Installation:
1. double-click .deb ;)
or
2. unpack it as used in package/ to your filesystem

#Run:
gitso

#Description:
 We created Gitso as a GUI wrapper to create a reverse VNC connection. It is meant to be easy enough so the 
 person who needs help can get it.  They run this program and type in the IP address given to them by their
 friend offering support.  The person who is giving support needs to have port 5500 open to their machine.


