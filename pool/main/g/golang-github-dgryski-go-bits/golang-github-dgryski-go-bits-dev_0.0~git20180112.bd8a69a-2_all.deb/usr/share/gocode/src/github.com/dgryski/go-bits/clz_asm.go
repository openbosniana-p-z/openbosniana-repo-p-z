// +build !gccgo,amd64,!appengine

package bits

// Clz counts leading zeroes
func Clz(x uint64) uint64
