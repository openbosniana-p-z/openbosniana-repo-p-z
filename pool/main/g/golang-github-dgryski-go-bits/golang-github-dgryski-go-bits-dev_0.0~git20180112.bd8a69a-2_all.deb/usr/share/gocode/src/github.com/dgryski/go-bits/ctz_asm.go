// +build !gccgo,amd64,!appengine

package bits

// Ctz counts trailing zeroes
func Ctz(x uint64) uint64
