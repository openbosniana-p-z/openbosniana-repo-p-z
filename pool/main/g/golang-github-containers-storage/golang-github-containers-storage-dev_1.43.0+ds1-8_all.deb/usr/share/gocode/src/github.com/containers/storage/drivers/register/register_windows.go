package register

import (
	// register the windows graph driver
	_ "github.com/containers/storage/drivers/windows"
)
