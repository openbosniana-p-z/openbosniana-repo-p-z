package mount

import "github.com/moby/sys/mountinfo"

var PidMountInfo = mountinfo.PidMountInfo
