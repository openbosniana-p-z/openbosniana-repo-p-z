// Copyright 2016 Canonical Ltd.
// Licensed under the LGPLv3, see LICENCE.client file for details.

package ussodischarge

const ProtocolName = protocolName

type USSOMacaroon struct {
	ussoMacaroon
}

type USSODischargeRequest ussoDischargeRequest
