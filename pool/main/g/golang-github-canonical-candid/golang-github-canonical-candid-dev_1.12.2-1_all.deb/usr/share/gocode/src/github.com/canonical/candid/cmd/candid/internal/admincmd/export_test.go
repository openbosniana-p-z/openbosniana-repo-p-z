// Copyright 2017 Canonical Ltd.
// Licensed under the AGPLv3, see LICENCE file for details.

package admincmd

var (
	WriteAgentFile = writeAgentFile
	ReadAgentFile  = readAgentFile
)
