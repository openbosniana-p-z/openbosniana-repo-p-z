// Copyright 2016 Canonical Ltd.
// Licensed under the LGPLv3, see LICENCE.client file for details.

package ussologin

var (
	Server  = &server
	UserKey = userKey
	PassKey = passKey
	OTPKey  = otpKey
)
