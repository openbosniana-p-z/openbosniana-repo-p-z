// Copyright 2017 Canonical Ltd.
// Licensed under the AGPLv3, see LICENCE file for details.

package auth

var (
	AuthorizerACLForOp = (*Authorizer).aclForOp
)

const CheckersNamespace = checkersNamespace
