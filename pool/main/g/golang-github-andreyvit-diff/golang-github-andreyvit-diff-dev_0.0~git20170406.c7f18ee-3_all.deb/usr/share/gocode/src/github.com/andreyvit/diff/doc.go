// diff provides quick and easy string diffing functions based on github.com/sergi/go-diff, mainly for diffing strings in tests
package diff
