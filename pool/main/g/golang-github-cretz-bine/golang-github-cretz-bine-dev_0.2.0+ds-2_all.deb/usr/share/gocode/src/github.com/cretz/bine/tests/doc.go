// Package tests contains integration tests.
package tests
