// Package torutil has generic utilities shared across the library.
package torutil
