package tests

// TODO: test several event parsers
