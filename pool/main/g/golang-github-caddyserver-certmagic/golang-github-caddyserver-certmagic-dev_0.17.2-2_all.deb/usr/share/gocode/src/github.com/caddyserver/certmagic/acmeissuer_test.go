package certmagic

const dummyCA = "https://example.com/acme/directory"
