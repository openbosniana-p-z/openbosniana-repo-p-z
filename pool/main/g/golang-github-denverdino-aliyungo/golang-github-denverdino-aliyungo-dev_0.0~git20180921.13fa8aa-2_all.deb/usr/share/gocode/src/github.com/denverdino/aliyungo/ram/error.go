package ram

//common errors
var ()
