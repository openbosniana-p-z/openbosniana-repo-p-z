// Package simd provides parallel implementations of some primitives.
package simd
