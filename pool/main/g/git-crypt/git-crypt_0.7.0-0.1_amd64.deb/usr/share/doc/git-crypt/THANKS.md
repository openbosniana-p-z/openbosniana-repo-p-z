For their contributions to git-crypt, I thank:

 * Michael Mior and @zimbatm for the Homebrew formula.

 * Cyril Cleaud for help with Windows support.

 * The following people for contributing patches:
   * Adam Nelson
   * Caleb Maclennan
   * Darayus Nanavati
   * Jon Sailor
   * Linus G Thiel
   * Michael Schout
   * Simon Kotlinski
   * Kevin Menard
   * Wael M. Nasreddine
   * Kevin Borgolte
   * Adrian Cohea

 * And everyone who has tested git-crypt, provided feedback, reported
   bugs, and participated in discussions about new features.

Thank you!
