package rice

// Debug can be set to true to enable debugging.
var Debug = false
