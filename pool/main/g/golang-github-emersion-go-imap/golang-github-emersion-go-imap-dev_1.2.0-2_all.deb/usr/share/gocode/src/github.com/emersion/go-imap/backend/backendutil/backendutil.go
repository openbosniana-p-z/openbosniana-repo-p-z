// Package backendutil provides utility functions to implement IMAP backends.
package backendutil
