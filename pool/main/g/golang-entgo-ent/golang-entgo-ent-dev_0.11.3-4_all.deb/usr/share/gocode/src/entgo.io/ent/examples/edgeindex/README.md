# City-Street Unique Index Example

In this example, we have a `City` with many `Street`s, and we want to set the
street name to be unique under each city.

### Generate Assets

```console
go generate ./...
```

### Run Example

```console
go test
```
