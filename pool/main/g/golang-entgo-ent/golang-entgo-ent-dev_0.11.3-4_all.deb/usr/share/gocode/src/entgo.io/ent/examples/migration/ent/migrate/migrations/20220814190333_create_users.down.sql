-- reverse: create "users" table
DROP TABLE `users`;
