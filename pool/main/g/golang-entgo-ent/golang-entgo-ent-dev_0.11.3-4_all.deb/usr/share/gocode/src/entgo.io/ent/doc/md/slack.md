---
id: slack
title: Join us on Slack
---

Ent maintainers, contributors and users hang out on the #ent channel in the Gophers Slack workspace.

To join the discussion:

1. Sign up to the Gophers Slack workspace via the [invite link](https://invite.slack.golangbridge.org/).
2. Join the #ent channel manually or via [this link](https://app.slack.com/client/T029RQSE6/C01FMSQDT53). (it will work only if you are logged in to slack from your browser)