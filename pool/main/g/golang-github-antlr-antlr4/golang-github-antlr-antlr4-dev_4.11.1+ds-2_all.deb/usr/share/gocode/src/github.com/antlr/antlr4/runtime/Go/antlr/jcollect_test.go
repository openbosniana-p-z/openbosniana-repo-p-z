package antlr

import "testing"

func Test_try(t *testing.T) {
	tests := []struct {
		name string
	}{
		{"Test_try"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
		})
	}
}
