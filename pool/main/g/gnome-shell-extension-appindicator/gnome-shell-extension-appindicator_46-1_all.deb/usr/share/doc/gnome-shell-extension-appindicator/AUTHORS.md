This extension is based on
[patches made by Giovanni Campagna](https://bugzilla.gnome.org/show_bug.cgi?id=652122).

Authors ordered by first contribution:

* Jonas Kümmerlin <rgcjonas@gmail.com>
* Damián Nohales <damiannohales@gmail.com>
* Dincer Kavraal <dkavraal@gmail.com>
* Thomas Schaberreiter <thomassc@ee.oulu.fi>
* Hugo Josefson <hugo@josefson.org>
* ozamorowski <ozamorowski@gmail.com>
* Anthony Ruhier <anthony.ruhier@gmail.com>
* Emilien Devos <unixfox@users.noreply.github.com>
* Jan Niklas Hasse <jhasse@bixense.com>
* Romeo Calota <kicsyromy@gmail.com>
* JasonLG1979 <jasonlevigray3@gmail.com>
* Martin Wallin <guzzard@gmail.com>
* Andrea Azzarone <andrea.azzarone@canonical.com>
* Marco Trevisan (Treviño) <mail@3v1n0.net>

<!--
created with:
git log --reverse --pretty="%an <%ae>%n%cn <%ce>" | awk '!seen[$0]++'
-->
