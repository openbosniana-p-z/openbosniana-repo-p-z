// Package grpc provides a gRPC binding for endpoints.
package grpc
