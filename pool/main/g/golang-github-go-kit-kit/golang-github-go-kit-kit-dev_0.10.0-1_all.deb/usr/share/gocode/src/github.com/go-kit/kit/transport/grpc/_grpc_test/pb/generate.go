package pb

//go:generate protoc test.proto --go_out=plugins=grpc:.
