// Package transport contains helpers applicable to all supported transports.
package transport
