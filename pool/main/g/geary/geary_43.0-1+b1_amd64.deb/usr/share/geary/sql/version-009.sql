--
-- Add flags column to the ContactTable
--

ALTER TABLE ContactTable ADD COLUMN flags TEXT;

