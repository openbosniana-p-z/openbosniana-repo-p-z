package current

import (
	"github.com/containernetworking/cni/pkg/types"
	types020 "github.com/containernetworking/cni/pkg/types/020"
	types040 "github.com/containernetworking/cni/pkg/types/040"
)

const ImplementedSpecVersion = types040.ImplementedSpecVersion

var (
	NewResult = types040.NewResult
	GetResult = types040.GetResult
	Int       = types040.Int
)

type (
	Result    = types040.Result
	Interface = types040.Interface
	IPConfig  = types040.IPConfig
)

func NewResultFromResult(result types.Result) (*Result, error) {
	if result.Version() == "" {
		switch r := result.(type) {
		case *types020.Result:
			r.CNIVersion = "0.1.0"
		}
	}
	return types040.NewResultFromResult(result)
}
