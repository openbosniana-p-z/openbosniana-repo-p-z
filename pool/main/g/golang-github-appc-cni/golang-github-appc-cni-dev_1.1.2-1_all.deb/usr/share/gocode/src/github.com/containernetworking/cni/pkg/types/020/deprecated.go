package types020

var SupportedVersions = supportedVersions
