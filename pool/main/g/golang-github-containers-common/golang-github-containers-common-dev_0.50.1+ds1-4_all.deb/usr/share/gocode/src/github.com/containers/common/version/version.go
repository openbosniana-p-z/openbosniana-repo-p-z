package version

// Version is the version of the build.
const Version = "0.50.1"
