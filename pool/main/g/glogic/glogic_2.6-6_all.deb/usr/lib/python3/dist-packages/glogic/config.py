# -*- coding: utf-8; indent-tabs-mode: t; tab-width: 4 -*-

DATADIR="/usr/share/glogic"
VERSION="2.6"
BZRREV=""
