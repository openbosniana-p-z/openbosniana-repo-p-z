package does_not_compile_test

import (
	. "github.com/onsi/ginkgo"
	. "github.com/onsi/ginkgo/integration/_fixtures/does_not_compile"
	. "github.com/onsi/gomega"
)

var _ = Describe("DoesNotCompile", func() {

})
