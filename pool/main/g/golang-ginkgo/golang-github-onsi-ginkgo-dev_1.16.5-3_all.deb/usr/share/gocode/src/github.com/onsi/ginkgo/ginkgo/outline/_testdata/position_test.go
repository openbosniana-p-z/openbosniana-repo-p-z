package example_test

import (
	. "github.com/onsi/ginkgo"
)

// Describe start=101, end=237
var _ = Describe("101,237", func() {

	/*
	* block comment
	*
	 */

	// line comment

	// It start=206, end=233
	It("206,233", func() {

	})

})
