package sigstore

import (
	"errors"

	"github.com/containers/image/v5/docker/reference"
	"github.com/containers/image/v5/internal/signature"
)

// SignDockerManifestWithPrivateKeyFileUnstable returns a signature for manifest as the specified dockerReference,
// using a private key and an optional passphrase.
//
// Yes, this returns an internal type, and should currently not be used outside of c/image.
// There is NO COMITTMENT TO STABLE API.
func SignDockerManifestWithPrivateKeyFileUnstable(m []byte, dockerReference reference.Named, privateKeyFile string, passphrase []byte) (signature.Sigstore, error) {
	return signature.Sigstore{}, errors.New(`Debian-local change: sigstore disabled`)
}

