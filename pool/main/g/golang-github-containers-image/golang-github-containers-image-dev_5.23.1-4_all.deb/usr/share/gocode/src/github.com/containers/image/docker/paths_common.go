//go:build !freebsd
// +build !freebsd

package docker

const etcDir = "/etc"
