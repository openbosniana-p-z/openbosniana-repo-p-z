# -*- coding: utf-8 -*-

NOMPROG = "Géophar"
NOMPROG2 = 'Geophar' # sans accent

# Numéro de version (et date de sa sortie)
version = '18.08.7'
date_version = (2021, 1, 6)
git = 'v18.08.6-4-gdc0ed1b'