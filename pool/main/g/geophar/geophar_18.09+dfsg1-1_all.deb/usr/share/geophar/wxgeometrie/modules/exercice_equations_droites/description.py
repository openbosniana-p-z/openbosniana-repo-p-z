# -*- coding: utf-8 -*-

# Informations utilisée par l'installeur sous Windows.
# titre : description sommaire du module
# description : description détaillée
# defaut : par défaut, le module est-il installé ou non ?

description = {
"titre":                    "Exercices - Équations de droites",
"description":              "Série d'exercice sur les équations de droite.",
"groupe":                   "Modules",
"defaut":  True,
}
