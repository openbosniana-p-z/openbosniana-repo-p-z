# -*- coding: utf-8 -*-

# Informations utilisée par l'installeur sous Windows.
# titre : description sommaire du module
# description : description détaillée
# defaut : par défaut, le module est-il installé ou non ?





description = {
"titre":                    "Traceur de courbes",
"description":              "Traceur de courbes dans le plan.",
"groupe":                   "Modules",
"defaut":  True,
}