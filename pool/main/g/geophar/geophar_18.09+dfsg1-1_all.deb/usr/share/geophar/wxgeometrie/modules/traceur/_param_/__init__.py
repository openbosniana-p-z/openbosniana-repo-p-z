# -*- coding: utf-8 -*-


nombre_courbes = 9

afficher_barre_outils = False
afficher_console_geolib = False

# Paramètres concernant les suites
##################################
# Style et épaisseur des traits (suite récurrente)
style_suites_recurrentes = ("-", .5)
afficher_points_de_construction = False

