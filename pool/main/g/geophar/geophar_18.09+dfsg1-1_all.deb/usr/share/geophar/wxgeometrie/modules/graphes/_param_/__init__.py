# -*- coding: iso-8859-1 -*-


ratio = 1
afficher_axes = False

afficher_barre_outils = True
afficher_console_geolib = True
afficher_objets_caches = True

points = {
    "style": "o",
    }

points_ancrage = {
    "style": ".",
    "visible": False,
    "couleur": "b",
    }

segments = {
    "couleur": "k",
    }

arcs = {
    "couleur": "k",
    }

vecteurs = {
    "position": .5,
    "couleur": "k",
    }

arcs_orientes = {
    "position": .5,
    "couleur": "k",
    }
