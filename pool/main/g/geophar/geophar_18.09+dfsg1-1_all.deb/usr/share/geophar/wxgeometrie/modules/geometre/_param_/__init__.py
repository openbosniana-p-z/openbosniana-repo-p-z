# -*- coding: iso-8859-1 -*-


ratio = 1
afficher_axes = False

afficher_barre_outils = True
afficher_console_geolib = True
