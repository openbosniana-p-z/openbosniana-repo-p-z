# -*- coding: utf-8 -*-

afficher_axes = False
afficher_quadrillage = False
