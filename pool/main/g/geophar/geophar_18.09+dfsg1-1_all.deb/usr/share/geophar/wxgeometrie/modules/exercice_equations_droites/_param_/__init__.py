# -*- coding: utf-8 -*-

afficher_axes = True
afficher_quadrillage = True
