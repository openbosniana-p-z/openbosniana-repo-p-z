# -*- coding: utf-8 -*-

# Informations utilisée par l'installeur sous Windows.
# titre : description sommaire du module
# description : description détaillée
# defaut : par défaut, le module est-il installé ou non ?

description = {
"titre":                    "Exercices - Trigonométrie",
"description":              "Repérage sur le cercle, cosinus et sinus remarquables.",
"groupe":                   "Modules en construction",
"defaut":  True,
}
