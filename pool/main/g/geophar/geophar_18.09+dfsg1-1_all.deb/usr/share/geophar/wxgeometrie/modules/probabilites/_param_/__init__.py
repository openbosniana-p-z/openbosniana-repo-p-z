# -*- coding: utf-8 -*-

afficher_axes = False
afficher_quadrillage = False
placement_probabilites = ['dessus', 'longe', 'decale'][1]
