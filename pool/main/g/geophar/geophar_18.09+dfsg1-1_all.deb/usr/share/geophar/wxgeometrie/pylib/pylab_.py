# -*- coding: utf-8 -*-



try:
    from pylab import *
except:
    from numpy import *
