# -*- coding: iso-8859-1 -*-

afficher_axes = False
afficher_quadrillage = False
