package bindings

/*
#cgo linux LDFLAGS: -lsqlite3 -lraft -ldqlite -Wl,-z,now
*/
import "C"
