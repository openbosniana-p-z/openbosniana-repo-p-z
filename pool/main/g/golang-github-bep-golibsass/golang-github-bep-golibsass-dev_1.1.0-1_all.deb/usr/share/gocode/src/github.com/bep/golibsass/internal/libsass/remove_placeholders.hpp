#ifndef USE_LIBSASS_SRC
#include "../../libsass_src/src/remove_placeholders.hpp"
#endif
