gnome-shell-extension-freon
====================================

Freon is forked from [gnome-shell-extension-sensors](https://github.com/xtranophilist/gnome-shell-extension-sensors). Freon is an extension for displaying CPU temperature, disk temperature, video card temperature (NVIDIA/Catalyst/Bumblebee&NVIDIA), voltage and fan RPM in GNOME Shell.

**[For more info, check out the Freon wiki.](https://github.com/UshakovVasilii/gnome-shell-extension-freon/wiki)**
