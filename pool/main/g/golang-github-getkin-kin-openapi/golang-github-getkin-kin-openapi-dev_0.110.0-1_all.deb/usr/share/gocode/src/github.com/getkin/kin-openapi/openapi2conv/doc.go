// Package openapi2conv converts an OpenAPI v2 specification document to v3.
package openapi2conv
